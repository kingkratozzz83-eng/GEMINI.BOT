package main

import (
	"archive/zip"
	"bytes"
	"compress/gzip"
	"context"
	"crypto/rand"
	"crypto/sha256"
	"crypto/tls"
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"math/big"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"reflect"
	"regexp"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"golang.org/x/crypto/ssh"
	_ "golang.org/x/crypto/x509roots/fallback"

	"go.mau.fi/whatsmeow"
	waBinary "go.mau.fi/whatsmeow/binary"
	"go.mau.fi/whatsmeow/proto/waE2E"
	"go.mau.fi/whatsmeow/store"
	"go.mau.fi/whatsmeow/store/sqlstore"
	"go.mau.fi/whatsmeow/types"
	"go.mau.fi/whatsmeow/types/events"
	waLog "go.mau.fi/whatsmeow/util/log"
	"google.golang.org/protobuf/proto"
	_ "modernc.org/sqlite"
)

func ensureAndroidRootCAs() {
	// Jika /etc/ssl/certs/ca-certificates.crt sudah ada (misal di VPS Ubuntu), tidak perlu buat ulang
	if st, err := os.Stat("/etc/ssl/certs/ca-certificates.crt"); err == nil && st.Size() > 1024 {
		return
	}
	// Jika berjalan di Mode Mandiri HP (Android), kumpulkan semua sertifikat Root CA dari sistem Android
	certDirs := []string{
		"/system/etc/security/cacerts",
		"/apex/com.android.conscrypt/cacerts",
		"/system/etc/security/cacerts_google",
	}
	existingDirs := make([]string, 0, len(certDirs))
	var bundleBuf bytes.Buffer

	if data, err := os.ReadFile("cacert.pem"); err == nil && len(data) > 1024 {
		bundleBuf.Write(data)
		bundleBuf.WriteByte(10)
	}

	for _, dir := range certDirs {
		entries, err := os.ReadDir(dir)
		if err != nil || len(entries) == 0 {
			continue
		}
		existingDirs = append(existingDirs, dir)
		for _, ent := range entries {
			if ent.IsDir() {
				continue
			}
			cBytes, err := os.ReadFile(filepath.Join(dir, ent.Name()))
			if err == nil && bytes.Contains(cBytes, []byte("-----BEGIN CERTIFICATE-----")) {
				bundleBuf.Write(cBytes)
				bundleBuf.WriteByte(10)
			}
		}
	}

	if len(existingDirs) > 0 {
		_ = os.Setenv("SSL_CERT_DIR", strings.Join(existingDirs, ":"))
	}
	if bundleBuf.Len() > 1024 {
		bundlePath := filepath.Join(os.TempDir(), "wabot_android_cacerts.pem")
		if err := os.WriteFile(bundlePath, bundleBuf.Bytes(), 0644); err != nil {
			bundlePath = "wabot_android_cacerts.pem"
			_ = os.WriteFile(bundlePath, bundleBuf.Bytes(), 0644)
		}
		if absPath, err := filepath.Abs(bundlePath); err == nil {
			_ = os.Setenv("SSL_CERT_FILE", absPath)
		} else {
			_ = os.Setenv("SSL_CERT_FILE", bundlePath)
		}
	}
}

func init() {
	ensureAndroidRootCAs()
	net.DefaultResolver = &net.Resolver{
		PreferGo: true,
		Dial: func(ctx context.Context, network, address string) (net.Conn, error) {
			d := net.Dialer{Timeout: 5 * time.Second}
			conn, err := d.DialContext(ctx, "udp", "8.8.8.8:53")
			if err != nil {
				return d.DialContext(ctx, "udp", "1.1.1.1:53")
			}
			return conn, nil
		},
	}
	if tr, ok := http.DefaultTransport.(*http.Transport); ok {
		tr.TLSClientConfig = &tls.Config{InsecureSkipVerify: true}
	}
}

type BotConfig struct {
	ApiKey            string `json:"apiKey"`
	Model             string `json:"model"`
	SystemPrompt      string `json:"systemPrompt"`
	ReplyScope        string `json:"replyScope"`
	GroupTrigger      string `json:"groupTrigger"`
	BlacklistNumbers  string `json:"blacklistNumbers"`
	MinDelayMs        int    `json:"minDelayMs"`
	MaxDelayMs        int    `json:"maxDelayMs"`
	PhoneNumber       string `json:"phoneNumber"`
	BotEnabled        bool   `json:"botEnabled"`
	DefaultStatusMode string `json:"defaultStatusMode"`
	StatusExceptList  string `json:"statusExceptList"`
	StatusOnlyList    string `json:"statusOnlyList"`
	StatusCloseList   string `json:"statusCloseList"`
	MenuStyle         string `json:"menuStyle"`
	BotName           string `json:"botName"`
	AutoWelcome       bool   `json:"autoWelcome"`
	AntiLink          bool   `json:"antiLink"`
	AntiSpam          bool   `json:"antiSpam"`
}

type ChatTurn struct {
	Role string `json:"role"`
	Text string `json:"text"`
}

type RpgProfile struct {
	Level int   `json:"level"`
	Exp   int   `json:"exp"`
	Gold  int   `json:"gold"`
	HP    int   `json:"hp"`
	Last  int64 `json:"last"`
}

type UiChatMessage struct {
	ID        string `json:"id"`
	Sender    string `json:"sender"`
	Text      string `json:"text"`
	FromMe    bool   `json:"fromMe"`
	Timestamp string `json:"timestamp"`
}

type UiChatThread struct {
	ChatJID     string          `json:"chatJid"`
	Title       string          `json:"title"`
	IsGroup     bool            `json:"isGroup"`
	LastMessage string          `json:"lastMessage"`
	UpdatedAt   int64           `json:"updatedAt"`
	Messages    []UiChatMessage `json:"messages"`
}

type SessionMeta struct {
	ID              string `json:"id"`
	Phone           string `json:"phone"`
	DBFile          string `json:"dbFile"`
	Active          bool   `json:"active"`
	GuestStatusOnly bool   `json:"guestStatusOnly"`
}

type CachedMoodMedia struct {
	Upload    whatsmeow.UploadResponse
	CreatedAt time.Time
}

type SessionInstance struct {
	ID              string                      `json:"id"`
	Phone           string                      `json:"phone"`
	JID             string                      `json:"jid"`
	PushName        string                      `json:"pushName"`
	DBFile          string                      `json:"dbFile"`
	Active          bool                        `json:"active"`
	GuestStatusOnly bool                        `json:"guestStatusOnly"`
	PairingCode     string                      `json:"pairingCode"`
	State           string                      `json:"state"`
	Container       *sqlstore.Container         `json:"-"`
	Client          *whatsmeow.Client           `json:"-"`
	Chats           map[string]*UiChatThread    `json:"-"`
	MoodMediaCache  map[string]*CachedMoodMedia `json:"-"`
}

type TransientAudienceStore struct {
	store.ContactStore
	mode string
	list []string
}

func (a *TransientAudienceStore) GetAllContacts(ctx context.Context) (map[types.JID]types.ContactInfo, error) {
	baseMap, err := a.ContactStore.GetAllContacts(ctx)
	if err != nil || baseMap == nil {
		baseMap = make(map[types.JID]types.ContactInfo)
	}
	for _, raw := range a.list {
		norm := normalizePhone(raw)
		if len(norm) >= 9 {
			jid := types.NewJID(norm, types.DefaultUserServer)
			if _, exists := baseMap[jid]; !exists {
				baseMap[jid] = types.ContactInfo{Found: true, FirstName: norm, FullName: norm}
			}
		}
	}

	if a.mode == "whitelist" || a.mode == "close_friends" {
		filtered := make(map[types.JID]types.ContactInfo)
		for _, raw := range a.list {
			norm := normalizePhone(raw)
			if norm != "" {
				jid := types.NewJID(norm, types.DefaultUserServer)
				filtered[jid] = types.ContactInfo{Found: true, FirstName: norm, FullName: norm}
			}
		}
		return filtered, nil
	}

	if a.mode == "blacklist" {
		blocked := make(map[string]bool)
		for _, raw := range a.list {
			norm := normalizePhone(raw)
			if norm != "" {
				blocked[norm] = true
			}
		}
		filtered := make(map[types.JID]types.ContactInfo)
		for jid, info := range baseMap {
			if !blocked[normalizePhone(jid.User)] {
				filtered[jid] = info
			}
		}
		return filtered, nil
	}

	return baseMap, nil
}

var (
	mu                   sync.Mutex
	sessions             = make(map[string]*SessionInstance)
	startTime            = time.Now()
	totalReplied         = 0
	config               = BotConfig{
		Model:             "gemini-2.5-flash",
		SystemPrompt:      "Kamu adalah asisten AI pribadi yang ramah, pintar, dan membantu di WhatsApp. Jawab dengan bahasa Indonesia yang natural dan ringkas.",
		ReplyScope:        "all",
		GroupTrigger:      "@bot",
		MinDelayMs:        1500,
		MaxDelayMs:        3000,
		BotEnabled:        true,
		DefaultStatusMode: "contacts",
		MenuStyle:         "both",
		BotName:           "DodosBot",
	}
	logs                 = make([]string, 0, 200)
	memory               = make(map[string][]ChatTurn)
	activeGroups         = make(map[string]bool)
	mutedPrivate         = make(map[string]bool)
	manualPauseUntil     = make(map[string]time.Time)
	botSentIDs           = make(map[string]bool)
	processedIncomingIDs = make(map[string]bool)
	rpgPlayers           = make(map[string]*RpgProfile)
	latestPairCode       = ""
	mentionRegex         = regexp.MustCompile(`@(628[0-9]{7,13}|08[0-9]{7,13})`)
	urlExtractRegex      = regexp.MustCompile(`https?://[^\s<>"]+`)
	ytVideoIdRegex       = regexp.MustCompile(`(?:youtu\.be/|youtube\.com/(?:watch\?(?:.*&)?v=|shorts/|embed/|live/|v/))([a-zA-Z0-9_-]{11})`)
	moodTagRegex         = regexp.MustCompile(`(?i)^\s*\[MOOD\s*:\s*([a-z_]+)\]\s*`)
	lastChatVideoCache   = make(map[string][]byte)
	statusUploadMutex    sync.Mutex
	lastStatusUploadTime = make(map[string]time.Time)
	lastStatusUploadHash = make(map[string]string)
	bannerEnabled        = true
	spamTracker          = make(map[string][]time.Time)
	linkDetectRegex      = regexp.MustCompile(`(?i)(https?://[^\s]+|chat\.whatsapp\.com/[^\s]+|wa\.me/[^\s]+)`)
)

var expressionLabels = map[string]string{
	"ceria":    "😊 Ceria & Senang",
	"tenang":   "😌 Tenang & Kalem",
	"marah":    "😠 Kesal & Tegas",
	"sedih":    "😢 Sedih & Terharu",
	"bingung":  "🤔 Bingung & Mikir",
	"ketawa":   "😆 Ngakak & Seru",
	"malu":     "😳 Malu-Malu",
	"kaget":    "😲 Kaget & Terkejut",
	"bosan":    "😒 Bosan & Datar",
	"keren":    "😎 Santai & Keren",
	"nangis":   "😭 Nangis Kejer",
	"ngantuk":  "😴 Ngantuk Berat",
	"panik":    "😵‍💫 Panik & Pusing",
	"bangga":   "😤 Bangga & Pede",
	"gugup":    "😰 Gugup & Canggung",
	"semangat": "🔥 Semangat Membara",
	"ngambek":  "😣 Ngambek & Cemberut",
	"suka":     "😍 Suka & Gemas",
	"syok":     "😱 Syok Berat",
	"ramah":    "😉 Ramah & Akrab",
}
var expressionBannersB64 = map[string]string{
	"ceria": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwMDAgQDAwMEBAQFBgoGBgUFBgwICQcKDgwPDg4MDQ0PERYTDxAVEQ0NExoTFRcYGRkZDxIbHRsYHRYYGRj/2wBDAQQEBAYFBgsGBgsYEA0QGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBj/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4Poor0OxsU+GkdjrOs6bHc+JrhVubHT7tG8qyi3ECaUAgtKSpCoD8mNzfMAB0HDisUqCSS5py2Xf/ACS6vp62TxdG+G/jnX7X7Tpnhu7aHYrrLPtgWRWGVKGQqHGBnK56j1Faf/CmPiV/0Lf/AJOW/wD8cp2mPr3xS+IVjpOu+IJzJP5myV0DpDtiLHbECqjPlgHGM9TmvQP+Gdf+pw/8p/8A9toem7PnMfnk8BUVPF4iFOTV7eznPTVfEpK+z6L0PPf+FMfEr/oW/wDyct//AI5R/wAKY+JX/Qt/+Tlv/wDHK9C/4Z1/6nD/AMp//wBto/4Z1/6nD/yn/wD22lddzh/1tof9BkP/AATU/wDkzz3/AIUx8Sv+hb/8nLf/AOOUf8KY+JX/AELf/k5b/wDxyvQv+Gdf+pw/8p//ANto/wCGdf8AqcP/ACn/AP22i67h/rbQ/wCgyH/gmp/8mee/8KY+JX/Qt/8Ak5b/APxyj/hTHxK/6Fv/AMnLf/45XoX/AAzr/wBTh/5T/wD7bR/wzr/1OH/lP/8AttF13D/W2h/0GQ/8E1P/AJM89/4Ux8Sv+hb/APJy3/8AjlH/AApj4lf9C3/5OW//AMcr0L/hnX/qcP8Ayn//AG2j/hnX/qcP/Kf/APbaLruH+ttD/oMh/wCCan/yZ57/AMKY+JX/AELf/k5b/wDxyj/hTHxK/wChb/8AJy3/APjlehf8M6/9Th/5T/8A7bR/wzr/ANTh/wCU/wD+20XXcP8AW2h/0GQ/8E1P/kzz3/hTHxK/6Fv/AMnLf/45R/wpj4lf9C3/AOTlv/8AHK9C/wCGdf8AqcP/ACn/AP22j/hnX/qcP/Kf/wDbaLruH+ttD/oMh/4Jqf8AyZ57/wAKY+JX/Qt/+Tlv/wDHKP8AhTHxK/6Fv/yct/8A45XoX/DOv/U4f+U//wC20f8ADOv/AFOH/lP/APttF13D/W2h/wBBkP8AwTU/+TPPf+FMfEr/AKFv/wAnLf8A+OUf8KY+JX/Qt/8Ak5b/APxyvQv+Gdf+pw/8p/8A9to/4Z1/6nD/AMp//wBtouu4f620P+gyH/gmp/8AJnnv/CmPiV/0Lf8A5OW//wAco/4Ux8Sv+hb/APJy3/8Ajlehf8M6/wDU4f8AlP8A/ttH/DOv/U4f+U//AO20XXcP9baH/QZD/wAE1P8A5M89/wCFMfEr/oW//Jy3/wDjlH/CmPiV/wBC3/5OW/8A8cr0L/hnX/qcP/Kf/wDbaP8AhnX/AKnD/wAp/wD9touu4f620P8AoMh/4Jqf/Jnnv/CmPiV/0Lf/AJOW/wD8co/4Ux8Sv+hb/wDJy3/+OV6F/wAM6/8AU4f+U/8A+20f8M6/9Th/5T//ALbRddw/1tof9BkP/BNT/wCTPPf+FMfEr/oW/wDyct//AI5R/wAKY+JX/Qt/+Tlv/wDHK9C/4Z1/6nD/AMp//wBto/4Z1/6nD/yn/wD22i67h/rbQ/6DIf8Agmp/8mee/wDCmPiV/wBC3/5OW/8A8co/4Ux8Sv8AoW//ACct/wD45XoX/DOv/U4f+U//AO20f8M6/wDU4f8AlP8A/ttF13D/AFtof9BkP/BNT/5M89/4Ux8Sv+hb/wDJy3/+OUf8KY+JX/Qt/wDk5b//AByvQv8AhnX/AKnD/wAp/wD9to/4Z1/6nD/yn/8A22i67h/rbQ/6DIf+Can/AMmee/8ACmPiV/0Lf/k5b/8Axyj/AIUx8Sv+hb/8nLf/AOOV6F/wzr/1OH/lP/8AttH/AAzr/wBTh/5T/wD7bRddw/1tof8AQZD/AME1P/kzz3/hTHxK/wChb/8AJy3/APjlH/CmPiV/0Lf/AJOW/wD8cr0L/hnX/qcP/Kf/APbaP+Gdf+pw/wDKf/8AbaLruH+ttD/oMh/4Jqf/ACZ57/wpj4lf9C3/AOTlv/8AHKP+FMfEr/oW/wDyct//AI5XoX/DOv8A1OH/AJT/AP7bR/wzr/1OH/lP/wDttF13D/W2h/0GQ/8ABNT/AOTPPf8AhTHxK/6Fv/yct/8A45R/wpj4lf8AQt/+Tlv/APHK9C/4Z1/6nD/yn/8A22j/AIZ1/wCpw/8AKf8A/baLruH+ttD/AKDIf+Can/yZ57/wpj4lf9C3/wCTlv8A/HKP+FMfEr/oW/8Ayct//jlehf8ADOv/AFOH/lP/APttH/DOv/U4f+U//wC20XXcP9baH/QZD/wTU/8Akzz3/hTHxK/6Fv8A8nLf/wCOUf8ACmPiV/0Lf/k5b/8AxyvQv+Gdf+pw/wDKf/8AbaP+Gdf+pw/8p/8A9touu4f620P+gyH/AIJqf/Jnnv8Awpj4lf8AQt/+Tlv/APHKP+FMfEr/AKFv/wAnLf8A+OV6F/wzr/1OH/lP/wDttH/DOv8A1OH/AJT/AP7bRddw/wBbaH/QZD/wTU/+TPPf+FMfEr/oW/8Ayct//jlH/CmPiV/0Lf8A5OW//wAcr0L/AIZ1/wCpw/8AKf8A/baP+Gdf+pw/8p//ANtouu4f620P+gyH/gmp/wDJnnv/AApj4lf9C3/5OW//AMco/wCFMfEr/oW//Jy3/wDjlehf8M6/9Th/5T//ALbR/wAM6/8AU4f+U/8A+20XXcP9baH/AEGQ/wDBNT/5M89/4Ux8Sv8AoW//ACct/wD45R/wpj4lf9C3/wCTlv8A/HK9C/4Z1/6nD/yn/wD22j/hnX/qcP8Ayn//AG2i67h/rbQ/6DIf+Can/wAmeVaz8N/HOgWv2nU/Dd2sOxnaWDbOsaqMsXMZYIMHOWx0Poa5avTPEVjr3wf8ZQ2eheJp3kntVuXdIhGjZaRArRksr4wSCemeMdarX1inxLjvtZ0bTY7bxNbq1zfafaI3lXsW4AzRAklZQWAZCfnzuX5iQX5nvYXM6jpxr1XGVKW00nG3rGV2l53fmktTzyiiig906n4b6NBr/wAVdE0y5MZha486RJIxIsixqZChU8EME2/j0PSq/ibXbnxN4tv9dul2SXUpcJkHy0AwiZAGdqhRnHOMmtv4Mf8AJb9E/wC2/wD6TyVx9OO55UEpZlUb+zCNvLmlO/38sfuJ7O9vNOvUvNPu57S5jzsmgkMbrkYOGHI4JH41q/8ACa+Mv+ht13/wPl/+KrDoq7HbUw9Ko71IJvzSZuf8Jr4y/wCht13/AMD5f/iqP+E18Zf9Dbrv/gfL/wDFVh0UrIz+pYf/AJ9x+5G5/wAJr4y/6G3Xf/A+X/4qj/hNfGX/AENuu/8AgfL/APFVh0UWQfUsP/z7j9yNz/hNfGX/AENuu/8AgfL/APFUf8Jr4y/6G3Xf/A+X/wCKrDoosg+pYf8A59x+5G5/wmvjL/obdd/8D5f/AIqj/hNfGX/Q267/AOB8v/xVYdFFkH1LD/8APuP3I3P+E18Zf9Dbrv8A4Hy//FUf8Jr4y/6G3Xf/AAPl/wDiqw6KLIPqWH/59x+5G5/wmvjL/obdd/8AA+X/AOKo/wCE18Zf9Dbrv/gfL/8AFVh0UWQfUsP/AM+4/cjc/wCE18Zf9Dbrv/gfL/8AFUf8Jr4y/wCht13/AMD5f/iqw6KLIPqWH/59x+5G5/wmvjL/AKG3Xf8AwPl/+Ko/4TXxl/0Nuu/+B8v/AMVWHRRZB9Sw/wDz7j9yNz/hNfGX/Q267/4Hy/8AxVH/AAmvjL/obdd/8D5f/iqw6KLIPqWH/wCfcfuRuf8ACa+Mv+ht13/wPl/+Ko/4TXxl/wBDbrv/AIHy/wDxVYdFFkH1LD/8+4/cjc/4TXxl/wBDbrv/AIHy/wDxVH/Ca+Mv+ht13/wPl/8Aiqw6KLIPqWH/AOfcfuRuf8Jr4y/6G3Xf/A+X/wCKo/4TXxl/0Nuu/wDgfL/8VWHRRZB9Sw//AD7j9yNz/hNfGX/Q267/AOB8v/xVH/Ca+Mv+ht13/wAD5f8A4qsOiiyD6lh/+fcfuRuf8Jr4y/6G3Xf/AAPl/wDiqP8AhNfGX/Q267/4Hy//ABVYdFFkH1LD/wDPuP3I3P8AhNfGX/Q267/4Hy//ABVH/Ca+Mv8Aobdd/wDA+X/4qsOiiyD6lh/+fcfuRuf8Jr4y/wCht13/AMD5f/iqP+E18Zf9Dbrv/gfL/wDFVh0UWQfUsP8A8+4/cjc/4TXxl/0Nuu/+B8v/AMVR/wAJr4y/6G3Xf/A+X/4qsOiiyD6lh/8An3H7kbn/AAmvjL/obdd/8D5f/iqP+E18Zf8AQ267/wCB8v8A8VWHRRZB9Sw//PuP3I3P+E18Zf8AQ267/wCB8v8A8VR/wmvjL/obdd/8D5f/AIqsOiiyD6lh/wDn3H7kbn/Ca+Mv+ht13/wPl/8AiqP+E18Zf9Dbrv8A4Hy//FVh0UWQfUsP/wA+4/cjc/4TXxl/0Nuu/wDgfL/8VR/wmvjL/obdd/8AA+X/AOKrDoosg+pYf/n3H7kbn/Ca+Mv+ht13/wAD5f8A4qj/AITXxl/0Nuu/+B8v/wAVWHRRZB9Sw/8Az7j9yNz/AITXxl/0Nuu/+B8v/wAVR/wmvjL/AKG3Xf8AwPl/+KrDoosg+pYf/n3H7kbn/Ca+Mv8Aobdd/wDA+X/4qj/hNfGX/Q267/4Hy/8AxVYdFFkH1LD/APPuP3It6hqmp6tcrc6rqN3fTKuxZLqZpWC5JwCxJxknj3NWvDOu3PhnxbYa7arvktZQ5TIHmIRh0yQcblLDOOM5FZVFM1nQpzpui4rlatbpZ9Dd+JGjQaB8Vdb0y2MYhW486NI4xGsayKJAgUcAKH2/h0HSitP4z/8AJb9b/wC2H/pPHRWS2ObKKkqmBoTm7twi36tIPgx/yW/RP+2//pPJXH12HwY/5Lfon/bf/wBJ5K4+qjuZUv8AkY1f8FP/ANKqBRRRVnphRRRQAUUUUAFFauheGde8TXptdC0ue9kX75QAJHwSNznCrnacZIzjArvYPglqFpbR3fizxPo+hW0iABnk3sJCM+WdxRc4Dchj93jI5pNpHnYvN8HhJclaolLtu/uV3+B5bRXrJ8J/Ba0/0W/8bau9zGAkrwxHy2YdSuIW+U9R8x4xyetL/a3wKxn/AIQvW/8Av63/AMkUX7I4/wC3E/4eHqy/7ct/6U4/h8zyWivWv7X+BX/Ql63/AN/m/wDkik/sP4F3R+1f8JNrll5v7z7LsY+TnnZnyWzjp95unU9aLvsH9uW+PDVV/wBuX/8ASWzyaivVj8EzqX/Ip+N9D1ny/wDj4y2zys/d/wBWZM5w3XHTv24XxB4N8T+Fth13R57SOTAWXIkjJOcLvUld3yk7c5wM4oUkzqwuc4LFT9nSqLm7PR/c7P8AAw6Kle3mjt4p3jKxy52Mf4sHB/WoqZ6jTW4UUUUCCiiigAqeys7nUdTt9Ps4/MubmVYYkyBudiABk8DkjrUFdD4K/wCRrf8A7B99/wCkc1BjiajpUp1Fuk39yL0MHh7TY/IXS4tYlHEtzdyypGx/6ZJGyMq8kZcksADhMlak+1aH/wBCbo//AH+vP/j9UK9e+G/gvw9r3gaxvdR0a0vJ7jW3sp5prySGRIBAH/dIsih3B5ACsTk8dx6GGwft5ckdzw83xuHyuh9ZxDm1e2kn2b/miunT5I8w+1aH/wBCbo//AH+vP/j9H2rQ/wDoTdH/AO/15/8AH69V8BeCPCOq6TZ3OqaVLdBtdvLR/Mlkid4I7NpVQhWG07gD2PbpxVDxF8OtOi8O6B/wj8fnza3qzR2d2XY+ZbOqGMMucAruYNwDlTW/9lz9n7RWt+PT/M8xcRZf9aeElzp93J2+1fXm6cre17fO3nP2rQ/+hN0f/v8AXn/x+j7Vof8A0Juj/wDf68/+P13vxN8JeHdL0m01jwnFAtnFcyaddeTfLdh3XmOUlXbYXUN8pxjb0Fc/D4I834Q3Hjr+2rVfJuxa/YCPnbJAznPXnO3HQE5rKpgZQm4WvZX+R24XNMFiMPTxPNKKnLlScpX5m7JOzdr+trGF9q0P/oTdH/7/AF5/8fo+1aH/ANCbo/8A3+vP/j9dN4W0TSZPh94g8U3unf2tcadJBFHYmR0jUOTmWTYQxAxgYI561u+F9I8Da/pupXmr6DcaTLog/tG4treWVheWxX/VfO2UO8rhh/C3cjdTp4Dn5dUr69fP5dGRis0w+H9o3GpJU2otqTerSaVufmfxRV7Wu97annn2rQ/+hN0f/v8AXn/x+j7Vof8A0Juj/wDf68/+P16/ofgzwZrfhDQ5m0Wzhv8AWLTUZ44Y7i689nid/LWIljEFVQAfM5OB1Oa5m90Xw1p/wY8P6sbTRk1PUbe7Mkl896ZpGSUophER8oEDH38DOM55rSWWOMeZtWtfd+X46o5aWf4SrU9jGFXm5+S13v7+uk/h/dy18vW3DfatD/6E3R/+/wBef/H6PtWh/wDQm6P/AN/rz/4/Xq+ueBvDVt8N5NRi0WGGSPw/Zagt1b3Uklw1zIQH3xF2Cxkc7tigc4PYUrjwh4dj+Dv/AAmS+H5RqL2CL/Zn2h9sWZCn2/G/fsOOFPy5PQrTllcotp20V+u33E0uI8DUjGSVTWagve+00mvt7a/LrbS/mv2rQ/8AoTdH/wC/15/8fpjaVpWvyJZ6Zpi6ZqcjBLdIJnaCdieEIkLMrsTgPv28KCqglxTorgdOJ9R9WS1hJp/4pP8ABuzObrf0TRLaex/tbVjN9h8xoI4rdwkk8ihSwDFWCKodSSQc7gAPvMjPGv8AyUvxF/2E7n/0a1bsn/Io+Gv+vCT/ANK7iuKcmo3RFfEylRpyjpz2+Xut7/K1/usw8zQP+hO0j/v/AHf/AMfo8zQP+hO0j/v/AHf/AMfqpXsPwq+FGi+MPC8+ua3d3W0zNBFDbOF24AyzEg888D275rn55dzyMdiaOBpe2rTlb/FL/M8p8zQP+hO0j/v/AHf/AMfo8zQP+hO0j/v/AHf/AMfrq77wRaab8cI/BNzqJNo13FF9o4DbHCsB6BsMB9avap4f0S48LeJL6LQ20WbRtQitYf3sjfald2Uowcn51ADZXAwelHPLuQ8ZR9y0pNSSafNLaTsvtX3+7qcN5mgf9CdpH/f+7/8Aj9HmaB/0J2kf9/7v/wCP17D4m+HnhK1Pii/0iyIttOtfK8hp3JtbkMh3ctllZHyM5GQ3oKxh4Q8O/wDDSlz4V/s7/iUIJCtt50nGLUuPm3bvvc9f0o55dzmpZrh6sHOLnpFy+J7JJv7W/vL/ADPN/M0D/oTtI/7/AN3/APH6PM0D/oTtI/7/AN3/APH69X8K+AvC+u+GfCDtaH+07p5Li7QzOBd26TmNwPm+VlBQ/LjIDVk2uheGbT4d3msXdnpAuU1yaxSTVJLwp5Sxhgii3Od2c8t789KOeXcpZnRcnBc7advil3a/m8n/AFc8+8zQP+hO0j/v/d//AB+jzNA/6E7SP+/93/8AH6qUUc8u563sv70v/Apf5lst4ekUxv4S0+NW4LwXFysij1UtKyhvQlWGeoPSue13Rk04QX1k7yafdM6wmQjzI3XaXjfGMld6fMBhgwPB3KutUuo/8k0v/wDsJ2n/AKKuaunN3sy6cpUZRababSabb3durdrb/gcZRRRXSe0dh8Z/+S363/2w/wDSeOij4z/8lv1v/th/6Tx0Vktjzck/5F2H/wAEP/SUHwY/5Lfon/bf/wBJ5K4+uw+DH/Jb9E/7b/8ApPJXH1UdxUv+RjV/wU//AEqoFFFFWemFFFdl4B8A3PjC+lu7ub7BoVnlry/chQABkopPG7HJJ4UcnsGG7HPi8XSwlJ1qztFf182+iOf0PQNY8SauNM0SxkvLoqX2KQoVR1LMSAo6DJI5IHUivVIfCHw5+Hmyfxpqf9u6wm1v7MtRuSNvkbBTIzjJOZCoZSfkJrO1j4iWWieH4vCvw2WfT7CPeLjUJFAnumOVLA9RkYO7hvugBAuD5tQot7njOjjMz1qydGl/Kvjl/if2V5LXXVnoeufGHxJfQiy0KODQNOSLyUgtFDOE2hcbyPlxg7dgXGe+Aa42BdS8SeI4o57uW5vLp1Rri5kLnpjLMTnAUfgBWdXoukeE9WN5pmgeGdObUvEeonyRFbne/mMT8nYKECksTwMEk4FN2itD2MuyzCYNpUaaiutt2vN7v5s5vxq9k3ji8awAa1BVIyOMqqhR+iivW/hto8V1YRf8Jd+zumpeHpRhtWtnu7O5VSPvxtJNsl+gAz2Nev8Ag/4F+GPholvrPiDf4m8XypvitbTHkW+3qY2YZwv8U7YH90evRS6hrnirUpdHOn/Zr5kR2ijupG2xvnb5pfswUkZwcAHGCKiOyR6td+2qyqpWTd7Hyv4w+EF5/wALFvrT4fW9xqWgsVltJ7mREZVcZCEsRkj1x0xnBrG1H4MfEvTLQ3U/hS7khAyWt2WbH4KSf0r6/wDDnhe60F2u9T0WcWW4rLeWUu+S2IOD5sZBJUYH3eg5wRXos2hanFai405U1e1ZQ3kAokzKeQYnGEfjoGxn+9Vc9jJ00fmNi807UFP7+0u4HDA8xyRsDkH1BBr0zwH49+IB1K3t5Lk6hpasFml1FSVjUtkkzAbt3UKCW64CnAx1PxY8S6Jr/wATLlv7KiSy0l3gBuLbyLid1+8ZAw3JggjaRwOcAnjzSXxLLfhkmvTYWSngIC8jf7i5wOB1P51M5cyskZSynBY1qGOipR87fn09TsdQ0DwP441ybSxrMWgX8G2HT4Y4lSFkLDI2YCsxZmwqsDkk4IFeW+KPCGveD9TWz1yz8rzNxhmRg8cyg4JVh+BwcEAjIGRVe9uftl9JOECKxwqA52qOAPyruPCvxIa00h/DPjG2fWfDskHkCDaDLCByu0kgkZwBk5XClSNuCRg4xR5eaSxdLFTxOF9+k3/D2aSVlyPySXuy36NM8zorvfHHw9i0TSrbxP4XvJNW8N3KqVuTgvAx4xJgDgnjOBg/KQDjdwVNO50YPG0sZS9rRd1t2aa3TXRrsFFFFM6grT8PalFpPiOC8uUdrYh4LgRgF/KkRo5NmSBv2O23PGcZyKzKKCKlNVIOEtmrHXXmn3FnHFOwEtrPk293GCYpwMZKMQM4yMg4KnhgCCKWHVdTt7SK1g1K7ighnF1HEkzKqSgYEigHAfAHzDmue07WtZ0fzf7I1a+sPNx5n2Wd4t+M4ztIzjJ/M1e/4TXxl/0Nuu/+B8v/AMVWyryWxxzpVn7soxkvN2/Cz/P7tjcTxL4ijdnj1/VEZpnuCy3UgJlddrP1+8VJBPUg4plvr+vWkVpFa63qMEdmzPbJFcuogZs7igB+UnJyR1yaxv8AhNfGX/Q267/4Hy//ABVH/Ca+Mv8Aobdd/wDA+X/4qq+sz/pmX1SVrexh9/r/AHfN/ezQS+vY9PlsI7y4W1mYPLAshCSMOhZc4JGTgmq9V/8AhNfGX/Q267/4Hy//ABVH/Ca+Mv8Aobdd/wDA+X/4qpdZvobKNeN7Qjr/AHn/APImlp+p6lpN39q0vULqxnxjzbaVomx6ZUg09tZ1dp7uZtVvTJeLsunM7Ezr6Oc/MOBwc9Kyv+E18Zf9Dbrv/gfL/wDFUf8ACa+Mv+ht13/wPl/+KprESSt+pnKhUlLndKN+9/8A7U3YfE/iS20caTb+IdVhsApUWkd3IsWCSSNgOMEk547miDxP4lttHOkW3iHVYdPKNGbSO7kWLa2dy7AcYOTkY5yawv8AhNfGX/Q267/4Hy//ABVH/Ca+Mv8Aobdd/wDA+X/4qq+tT7/iQ8G3e9GGrvv17/Bv5mwNd1wSeYNZ1AP9m+xbvtD58jp5XX7n+z09qDr2uG6e5Os6gZng+yvKbh9zQ4x5ZOclMcbelY//AAmvjL/obdd/8D5f/iqP+E18Zf8AQ267/wCB8v8A8VS+sz/plfVpf8+off8A/alir9lZIYhqeprNDpEUgWe4UY3YwTFGSMNKQeF98nChmGR/wmvjL/obdd/8D5f/AIqs7UNU1PVrlbnVdRu76ZV2LJdTNKwXJOAWJOMk8e5qHVb6G3JXn7rtFd0238tF9/4MNU1CbVtcvdVuVjWa7ne4kWMEKGdixAyScZPrXU6LK2u6BZaXao0up2AeJLaNSWngLmQFByWdWeTcB/DsIBCuRxdFYSjzKxdbCqcIwjpy7eWlvyOurofDfjnxT4Rini0DVXtopzueMosilsY3AMCAfcelcZ/wmvjL/obdd/8AA+X/AOKo/wCE18Zf9Dbrv/gfL/8AFVj7F9zz6uBq1o8lSEWuzbf/ALabV7fXmo6lNqF9cyT3UzmSSZzlmY96mvta1nU4oo9S1a+vEi/1a3E7yBPoCTiuf/4TXxl/0Nuu/wDgfL/8VR/wmvjL/obdd/8AA+X/AOKo9i+5X1Otp7kdNtXp/wCSnRPrutyNdtJrGoM17gXRa4cm4x08zn5sds5q1L4w8XTFDN4p1qQxsWQvfSnaSpUkZbg4Zh9CR3rk/wDhNfGX/Q267/4Hy/8AxVH/AAmvjL/obdd/8D5f/iqPYvuQ8BUe9OP3/wD2p0EGtaxavaNbatfQtZhhbGOd1MAbO7Zg/LnJzjrmp7LxN4k02F4tO8Q6rZxyOZXS3u5IwznqxAIyTgc+1cx/wmvjL/obdd/8D5f/AIqj/hNfGX/Q267/AOB8v/xVHsX3HLA1Zbwj9/8A9qaRJJyTk0Vm/wDCa+Mv+ht13/wPl/8AiqP+E18Zf9Dbrv8A4Hy//FUexfc0+r4jtH73/wDImrFFLPOkEEbyyyMESNFLMxJwAAOpNReI7pLDQh4eyDePcrc3idfIKKyxx57P+8lLjnHyDhg6jMn8XeK7m2ktrnxPrM0MqlJI5L2VldSMEEFsEEdqxquFLld2aUsJNyUqtrLWy1183Zbdrb216BRRRWp6R2Hxn/5Lfrf/AGw/9J46KPjP/wAlv1v/ALYf+k8dFZLY83JP+Rdh/wDBD/0lB8GP+S36J/23/wDSeSuPrsPgx/yW/RP+2/8A6TyVx9VHcVL/AJGNX/BT/wDSqgUUVpaBod/4k8SWmiaYsZurliq+Y21VABZmJ9AATxk8cAnirPQqVI04OpN2SV2+yR0HgHwDc+ML6W7u5vsGhWeWvL9yFAAGSik8bscknhRyewbW8c+ObbUrGLwp4Ug+weGbPCJGgKm5IOdzZ5255APJPzNzgLd+ImsaVommL8NvCsHlWFlKHvbkSbmupschipw2Djdn+JQAFCDPm1EVfVng4GhLMKkcfiV7q1pxfRdJP+8+n8q8wooqa1tLq+vI7Syt5bi4lYJHDEhd3J6AAck1ofQkcZAlUnGMjrX6Vfs4/Bc+EvhrP461eIT+I/ErvIkhXH2Sxdi6IoPKmUbXbvgqp+6c/Mfwa/Z6nTxTYeIvi3aDS9MifzrfQLohbvUSuG/eRfeigHV2YAsPlUfNkfcfjDxvPpvw1vJLSYC5uWj0+1wMbZp5FhDD3G9m/wCA1hVd9jejCUpKK6j7XQdNlum2xieW8TzppSM741cKo/3MngdOCe5ry74IbfEeufEHW7pd15Jr5JZuSI/K2oPoACK9D8LeNNJb4veK9OtjG9vpltpumQRk8IB5xP47to/AV5z4G8S23gL9qXXPBF7ZwQWWrxmSxlZcLcHLSxFvU7WkTI/iTFYybTR6eEhGdGtFfEkmvRNX/DX5HrqWEUWrRWuzbJcKzrj+IoBn8cEH6Cqmmiw0nxwPCbsIIrobrdHXHlSEFzGB/cdQ7pjuki9gK5X4m/EafStX0O/0a386fT9ad7iCJSzPB9jJl2gdflYED/ZrjfjR42TV/hzD428M3wXxDoE8dyFV8lo1ZZNvuvCSKfQt6sKq/Q5qNB1Gr6J6X8/6/MxP2yPg3Zat4Vk+JHhSHGp6cFXWkjXH2u3X5ftHu0fG4906/cFeK2nwZvr79naOSXS1We6Bu7W64Di4A+RT32OoEfpuIPavtO48Uwa94Bi1nTbaK6gv7JbpbV+VmjkQM0R+qsV+tea6FqOjR+DTo2n3BurFi32FieZE6+S392ZMYKnG7G4ZycaU3Z3Odx6M/ORgVYgggjsaSvUvjT8P5/DXjK58QaXE03h/UpmmhuEBKwSMctC/90g5wDjI9wceW1uc7Vjr/Avjq48J3ktpdw/b9DvMpeWDgMGBGCyg8bscEHhhwexE3j7wDb6TZx+LPCc32/wxeYZJEJY2pJxsbPO3PAJ5B+VucFuKrufh34osNOuLjwv4jto7vQNXZYp1lk2rA+cCTkgKOm5uCNqsD8oBiUeqPBx+FnhajzDCL3vtxX24r/25LZ9dmedUV0njnwnc+DfGVxpE3zQN++tJC4YvCWIUtgDDcEHgcg44wTzdJanr4fEU8RSjWpO8ZK6Ciiig2CiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAOw+M/8AyW/W/wDth/6Tx0UfGf8A5Lfrf/bD/wBJ46KyWx5uSf8AIuw/+CH/AKSg+DH/ACW/RP8Atv8A+k8lcfXYfBj/AJLfon/bf/0nkrj6qO4qX/Ixq/4Kf/pVQK9m8IQ/8K8+C1940nj2axq+LfT96fNGpztIyhxnDSYOVYJH3NeXeGdCufE3i2w0K1bZJdShC+AfLQDLvgkZ2qGOM84wK7r4w65HfeN00KyWCPTtGiFtDHBt2BiAXxgfLjCpt5x5fbJFVa7scWbL67iKWXL4X78/8MXov+3paeiZ55RRRWp9AFKCQwI69qSigD6X+Dq2vhPw5o0tzGbjxB4pMuoMZOTBploHZck8jzJoicd9iHtXtPxL8SjSfCPhtvNYx2uvWxmHU5iSRz+OVzXzd4D1lta+IOp6xEztZ6T4Vj0+AkcRhYYotv4nzT9STXpnxH1q01DRNUSSTMOn67b6k2wFi0DOEkwByfvHp2Yetc9R2Vz08BT55en+dv1Own0rxt4M8E6b4/ns7WOHWA8l2Ekd5kkMv2iFn+XaD8pQAE9cE5NHj2+0r4heF7XU/Oe11LT5EuLK/tziWJHZTkHuBkHHqua4C/v/AIu+MtO0S7n8e6lDfa9bNqGneExbJJYrpweT5TIwAZoxEPv/ADEuoUgrmvU/B3wo1zxL8FtE8VaTdW90b60Jm02TMDjlkYIx4VgwYYPB4OQSRXHCuoLlqNX/AMzulQnpiI6a2Xy0/S3yZzvgWe01j4hal4m+Ld5ZSaNpSvcXMryGO1dyiQIxXICltjkgnnGB1xXGeMdR+GF54ikPwV8Z2eoNfMbb+wAswkIbOYkV1xJH94rg5TJ6g8ez+N/hrEnwBtNffwNBcaroFzFLdaJrKs1retmOBriTY4LIsQBHPy5k9zXldl8AYrrWr+zFqz2smhPPA12qQXcOobI/IMbBiVQT5CkdAzg5GKyVW8+Zv/LTudtDCzdJ16VuWOjv1/q6/pHbfDrX7jTfgN4Jt52dbiKeGyKPwwAuHiIIPop/Ssa107Rf+FheJ7GbTLK6gndb+FnypAlGedpG5N4YHOcEg1zel6jOfG/hbwcNUuNSbT5m1DUL6eQu0xR2kZyT2OU/FvWuK1rxfd6Z8T7PULWYEwT3GnSo33XiZlkUH2Al/SvQpSurnFi8JacYx+J3f+X4fmdl41XVbnQ7jWfA1ylvLGrQ3mhzQrNDPt5KNEwI3cHB/iwO5FfK2oXp1DUZLtra2ty5z5dtEIox9FHAr6Du/Es1l400vWLdzFBqV19klTPBfh0P4Nx9D7V4j44trSz+Jev2tht+zR6hOsYXoq7zwPp0/Cuq2h4lVWZgUUUUjE9bs4f+FkfAOXTVj83XfDmDBtTLSRAHagwn8SKyhRyWiQk814xXcfDfxE3hr4i2F20iJbXDC0uTIwRRG5A3FiDgKQrdvu4yATVX4meG38MfEnULRY40tbhjd2ojVUUROSQoUE4CkMnb7ucAEVlazsfP4BfUcdUwf2J+/Dy199ffql2ZyNaXh7Q7/wAT+LtK8N6UivfaneRWNsrHAMkrhFBPplhWbW14P8R3Pg/4h6F4ts4lluNI1CDUI42OA7RSK4U+x24pn0B9O/FDwd+zf+znqOm+BfEfgPWPiR4oktEutRvJNZl0yK335AEaxZ5OCQpBwCuWOa8h0T4Xy/G74w6lp3wR8N3Wm6FFDHcuutXilNOTYocyz918zft4LFe3Bx7h8bdD+Fv7Sfiqw+KHgn4zeDfDN7cWUVvqekeLrw2EsTJnBXg7jghSACvy5DHNJ+zZ44+G3wd8b/EX4Y61428N6pZ65ZW8dn4iuLV5dKnmWGTfDMpILRbpyuSVVgjcjcKzTsr9SraniPxD/Z48b/D3wLF42bVPDXijw08/2Z9Y8Mah9tt4Jc4CSHapBzxnBGcAnJAPTar+yJ4+0HTNL1XxB4x8AaNpWpWQvItR1PWGtYFLKGWEmSNS0pBztQMBjkjIz6h8WviHPon7NvibwTD4n/Z5Sy1V4imi/DqyuHkuX82ImQssgjiZVjVtzK2dgXriuX/bH8YeGvFGgfCm28N+KNJ1lbDQ2juY9OvY7j7NKVhBVwjHY3y9Dg/L7UJthZGX8TfCvk/sYfCjUv8AhB/BWh/2jcrF/wAJFaXH+m3mVfm6H2VNqjqT5sn3R+GZbfsjeMNagul8F/Er4V+M9Qt4WnOl+HfEQubl1HUhTGo7gckDkV6F4w8V/DDVf2R/gD4c8QeJdMvbSw1eA6/p1jepJdW1r84lLxoxkT5SewPPHOK928JeM/gX4L+PNofDes/AbR/Cs9iy2F9pyouro/lguLi6LCOJCcgBiXbKjHUhczS0HY/MmaGW3uJIJ43iljYo6OMMrA4II7GvpL9kb4JeFPi1qPi7UfF2i6lrMWiWaSWWmQTPaw3szb/3b3C42H5UAG4ffJ5CmvEPiNc2l58Y/Ft3p88NxaTazeSQTQOHjkQzuVZWHBUgggjjFfUfwb8eeHdY/Yztvhr4b+Kmk/DLx3pGtf2qLzVrn7Hb6hiQuu+XGCuCilTk/uVBUqauTdiVueE+PvD+keJvEt1H8Lvg/wCLvDlxo8Up1/R2kl1RLAo2N5fZvRRht3mcDHXrXllfpF8SfiH8PNX+Anjqbwl47+GX/C09W0S30/Xbu11NbeK/RVYSLbPKVErFGlVccjKBjwlfnLYWjahq1rYLPbwNcTJCJrmQRRR7mA3O54VRnJJ4A5oi7g0fZP7MnwF+EOr/AASsfG3xp0b7ZJ4m11dI0FXvLi3BPzKAPKkTJeRJRzn/AFYx1NeA678E9ctv2sb34JadNbwXzaq1lZT37MkbRMN8MjlVYgNGUPAPWvpf4xfHH4I+A4PAvwy0zwXZfEvS/CllbXdlquleKZLOK3u0yuc2wYPJ8gckngyHjrmx458YfDLxX+1J8EPjnpni7w1ZNfrDHr9i+qweZpjrGXQ3HzArje8ZZgo/dr6ioTd7jsjxf/hi74tPrGuaLbar4OuNY0pDL/ZUeq/6XdxYGJYoigYISdoaTYCenBBPXfs6/s7+B/H/AOzh4+8T+LLzwzJrMdnKumS3OrzW7aBKiTr5t8iELGhZUcFw42oxx1B7P4efEPwVa/8ABUnx54t1DxxoEGg3WnyRQavPqUKWs3y2wVUmLbG+4QAD/CfSuV/Z08XeCG8L/HjwBrfjTQvDt34qt5oNLvdWulgtZN6XMefNPy4BljPqQcgHBobdgsjyef8AZp8VDwX408WaV408Da5pHhJUN5d6RqMlzHc7olkxA6xbXIDhTkrhgR2zXO3vwV8VWP7NunfGyW/0dvD+oXpsIrVJZDdhw8iZZfL2bcxN0cnkcen0H8GX8FeHPhD8YP2f/EXxT8E2mqakkclhrsepB9Kui8CnCXBAB2ttVhjOS2A201W+JerfD/R/+Cavh74d6B8RPD/iLWNP10tcRWV0okc+dcM7pCxEnlAuArlRuGG4DCnzO9gsefXH7IPxGsLazg1fxT8P9K168gWeDw3qGvJBqLq3QCNl2k5BHDYyCM1o/B7wvJefsj/F3UZfh/4P1eTTkZW1jVJ9t9pxERz9mX7NJuPf/Wx8/nXvvh/xZ4J8ULbzfG74jfATx34Wt7EwjVbmB4PELAKdg8phlTknIX5uTjk15T8KfFnw90j9k/4/aFZeJdNsI9RmmGh2GoXkcV1dQbGEYSN2DO23aDgHmldtahY8t8E/s63/AI78N6XqWl/Fv4U2l5qQ/c6JqHiAxagrliojaERnDkjgZPUVR0r9nH4p6r8eb34RppFtbeILGE3V09zcBbeK3G3E5kGcod6YwCctjGQcfSvg3VvgB4d+CHgHWPCLfBoX8SQt4mbxnateass2E3m2iyG3+Z5mCSsYG0ggAmj4m/EnTP8Ahv0eKPh78YPBmjq3haO1GqXji+028fzjutJpISQmRh92ePLX1FPmYWR8w/EH4Ha78P8AwsviM+L/AAR4n0v7StpJc+GdZS98mVgxVXXCsM7G5xjivMK+wv2gbj4O3H7OImv5PhPL8T3v0NtJ8NMm2aHcNxmx327s7+d23Hevj2qi7oTCiiiqEFFFFABRRRQAUUUUAdh8Z/8Akt+t/wDbD/0njoo+M/8AyW/W/wDth/6Tx0Vktjzck/5F2H/wQ/8ASUHwY/5Lfon/AG3/APSeSuPrsPgx/wAlv0T/ALb/APpPJXH1UdxUv+RjV/wU/wD0qoepfBKCG01jXfFl3FHLbaPp7OyhQ0oZstmPPGdkci5yPvY6E1wF7eXGoalcX95J5lxcStNK+ANzsSScDgck9K9F8K/6N+y94qvLb9zcSXyQvNH8rvHmAbCw5K4dxjp8zeprzOrhu2cuWJVcbisQ91JQXpGKf4uTYUUUVoe6FFFFAHunwnitrL4NXl8WVZ9W8SWujF+6L5LyKPoxLD8K0PEWn6naaCviAsZLSa3KNF0LxnMZX2IVVwe+0dCAa8S07xBq9loVxodlM4t7q5gu9i53LPFuEbrjowEjj8fYV7/4S8W2vjPTIvDfiCSCC/1CCa0WNQFVLxJGkRAM8ebHPKAP78W3uBWU0rWZ34TEeynGS6fl1PePhpJafEL4TeE7u70G4guNOjYC5msl8u6JciUoxJVkd1LleCkm7jB59muvEfhD4eeHdKs9e1yLS4Zd0drFMrPJcMDuYKFUkkbskAdMdhXxV8I/2hLn4Ja1qHgnxXpZ1PQ47ozCJXEc9kXxueItwyEjJQ4weQRk5+k7742fs+/EvSLTT9R8aWWk3cMiXtqmsRG1lgfacMN42MCrEEBiCD9DXhVqU1J9UfR1cRF8tGbtBPpru+h6DYfEfwx4r1yHw9ov265a7gmInltGihIRQSp34J3KT2wcMK5Hxn4S8TWnh28TwnbadbXVwjRPfzYiWyiwcyAKuWIBO0cAHknsaEXxI+DfgrV473/hYFpr+qvGYrTT9HP2yVi2M7I4t3zEADLEADPqa8Z/aJ+P/jqYWHhTRrIeH9N1aBpJZRKJLsxhsMrsPlj45O0nr96sadOUmlsbwapTawzvB21aPOfCcy6D4U1W+acTalq9z/Z9nNjDGIHAx6DkE++K811a++2+PLg5Bie9doyD98Lhc/kgqeHU76e6ilSXy47aBktRtOIiwIV8cDAyzDnLHb2rmYbWNGu5JbqaSa1haSK4GF2lSAB3yCTjHvXu09lE4cRWhTxE6t7/AD/rp8rm1418WrNr2nW+kODFpMhmEnVZLgsGZh6hdqqPXaT3rh5ZZJ53mmdnkdizMxyWJOSTWlo2qTWevi4EcMqTEpNDIgaORG6qQc8d/UY4qXV9MtlhGoaUC1r92VA27yXz0552njBPfg9q6uZuVmfMzSceZPW+36mLRRRTMgr0/wCJ8jeJPhb4R8akRmYq1ldyugSWWTHX5RjZuimIGRjeMDk48wr07T/9K/ZP137V+++yakn2fzPm8nLQ52Z+799+n99vU1E+jPCzlKnVwuJW8aij8p+6/wBH8jyWiipLe3nu7uK1tYJJ55nEccUSlmdicBVA5JJOABSPdI6KujSNWL3qDS70tYZN2BA2bbDbT5nHyYPHOOeKpUAFFFWbrT7uztbK4uYtkV7Cbi3bcDvQSPGTwePnjcYODxnoRQBWoroW8CeNIrqzt7nwrq9o17cR2lu13avbpJK5wiB3AUEn1Nc9RYAooooAKKKla2uFs0u2glFvI7RpMVOxmUKWUHoSA6kjtuHqKAIqKK0I9B1ybRH1mLRdQk05Mhr1bZzCuPV8bR+dAGfRWvN4U8U2+hDWp/DWrxaYUWUXr2ciwlGxtbeV24ORg55yKL3wp4o024toNR8N6vaS3TiK3juLOSNpnJwFQFfmJyOBTsK5kUVYgsL66FwbWyuJxbRmWfy4y3lICAWfA+UAkDJ45FV6QwooooAKKKKACiiigAooooAKKKKACiiigAooooA7D4z/APJb9b/7Yf8ApPHRR8Z/+S363/2w/wDSeOislsebkn/Iuw/+CH/pKD4Mf8lv0T/tv/6TyVx9dh8GP+S36J/23/8ASeSuPqo7ipf8jGr/AIKf/pVQ9a1f/k0/wx/2En/9Cua8xr07V/8Ak0/wx/2En/8AQrmvMa0p7HLkPwV/+vtT/wBKYUUUVZ7oUUVoaJYvqOuW9pHGJHdwFQ/xHsPoTj8M0m0ldlQg5yUYq7Z0XhbQLy71C0sLDy01O+kjiWeVwiWqyMFXLHhWbcOT91TnqeO7+J3w30PwB4V0rR5bO/m8XeWbq8v7bU0kskRZWAWFETLkrtO8vnO7gEYHWfC248JaP8UNI0qfxDpUd8jysz3NmL5ZZzE4CmM4UsWOFyeCF74r6Cm8P+EtO0GfVfjBpNpZ6baq+pwLLai1jV1wAyKrEjceRGT/ABY24wK8etipOSdtD69ZXRw0XSk1J21s769vkfBXjWw8e6v49tPD3jnR2j8QW0Eck1zcgQzvbModWuCM87GB3EB/mAOSavyraas9zC0cVpPbgpAr/KQnCojD+IYCjI54z6it/wAXeJn1fUdU8WSXb3mo6tIbq8mY8MzH5EXuFQBRg/xBvbGbqFibu2t7eUlXkYs7qcFRGo5H/ApB+VdN3bXdnk0aaUnbWyd/NdPxtr/ke2W1j4T+Dvwd0LX9HNnc6v4gsEuEkkfzJMgbZXcHGxVfKbAQCVx2Y14vrGr3WveLXErTatqLnomZs/RVA3Ee+FGMAAVEujXN7c2kdzfXEsEUiRqjOWCAvnAHYEljj1J9TXpfwOutBtdbuLW6sNSvL/xC+EbTLhbRoYy0m52nZGACjLEblHy87ulZQgoNylqzsq4irOjGFP3U3Zef9afPfpbzGSXV7t2tI9ORAG2NJduDluh+VeODxWRYo9vql5Z6raxxKySRzoo+VRtJDj6EAj/69ek+K/DL+DPEx0WTWNJ1hZYUntbrS5/OikiORktgfMCpDcdcYzkVx/irT5JI3upbhGcgKyKCMFcZDEDuOcZP3RW1OouZNbGEsLz4eUrPnTXpbtr+HzOIs1b7QGUZbov+8eB+XX8K3LBLiISPbxiR0XbNGwyJk5Uhvyznsa2PDnh5fM+1SAPj5UGPlz3wP61reH9KYeLtUswvEYDY9A2CP5miriFd26HfgMglan7VfG2vwb/Q841G1S2uswFmgkG+Jm649D7g5B+lU69B8b+F302L7RGn7iZi6Y/gkA+YfRlGfqtefV1UaqqRUkfPZlgKmAxEqFRar8gr0/4Y/wDJNPiJ/wBgz/2lPXmFen/DH/kmnxE/7Bn/ALSnqp/CfKcSf7hL/FD/ANLieSVveCLiC0+J3hy6up44IIdUtpJJZWCqiiVSWYngAAZJNYNFI909TtPGOiX2kavbSmS2uL6wZtUlkZVF1LGY44xFzlmK+Y5zyWduMDNTaj/wh/8Aa1t/a3/CNf2f/bkX2H+y9mf7Pw+/7R5Xz4/1H+s/effryaiq5ieU9RP9if2ppP8AbH/CKf21svv+PPyPsP8Aql+yed5X7rPmeZ17bN/GawfiDcRz/wDCNxCfSZLiDSTHcrpTRmGOX7XcMVAj+UHDAkLx82RwRXGUUXHY9o1mfT1+Oum68tr4RttP/wCEmguDq1lrSzTSx+fnfJH9pcIuPmJ8tcYHQcHm7M6GPGGky6XZaNdaP9mkEMN3cWsE0b7MM1wbg7GkViGAbKMBhQOQPO6KOYXKetw2VssHim50y48J392l/pqQ3d/a2cNugeC4aSNB/qARtAO07W2FhlttVta1DwMni7w5ptpbaR/wjryvJfzW8CmUr9vuNqtJgyKojEeBwxQrnPy15ktzcLZyWizyrbyOsjwhiEZlDBWI6EgO4B7bj6moqOYOU9bvZ9FbxdpBTwv4eXalyDKut6VJHICgCMyrHHCpQncolXL5IOccc747j0aLSrZbC/0u9vDqVy00tlb28BEZtrQqpWD5Nqv5ygr8pYOR1NcNRQ5AkWrjz/7Os/M+y+Vtfy/K8vzMbjnzNvzZz03846cV2niVZdYNvr2keI9Pg06LS4bdbZr9YprfZAqSQCHO87mD8qpVt+SeTXA0UrjsekeMVt73wxY3dppvhadU0iwjbUV1cG+VkgiVl+z/AGnqCChHlZxk9ea6qbxD4WuPiLeDS76K1VPFtpqd3Pe38ckNzGkzL5luwCqgHmlivzEqc7sIa8Nop8wuU9N8Kax4W8O6OZ9W1e6WTU79/tVvYW0dyXs1Vo2ikJlQxiTzZD0b7inHTPn2q2Uena7eWEV3DdxwTPElxA4dJVBIDqRwQRz+NU6KTY0gooopDCiiigAooooAKKKKACiiigAooooAKKKKAOw+M/8AyW/W/wDth/6Tx0UfGf8A5Lfrf/bD/wBJ46KyWx5uSf8AIuw/+CH/AKSg+DH/ACW/RP8Atv8A+k8lcfXYfBj/AJLfon/bf/0nkrj6qO4qX/Ixq/4Kf/pVQ9Z0P/Sv2Udd+1fvvsmpr9n8z5vJy0Gdmfu/ffp/fb1NeZV6V8Ez/aTeKfCf+q/tTTD/AKT97ytuY/u/xf6/PUfd9+POJoZra5kt7iJ4Zo2KPHIpVkYHBBB5BB7VcOqOXKmqWLxeHe/Mp/KUV+qf5jKKKK0PdCrdlfz6f5r2rbJnQxiQdUB4OPQkZGfc1UopNJqzKhNwfNHc67w/b2Ufg28vkhSfVJZ/s8IY/wCpQIGYger52g+it65rf1/4t/EPxZ4Wi8M6vr9/f2SIsZhlUfOoPR2xkgEA8ntzmvS/hH+y14z8a/D9Na1PWLLw3ZagY7uy82B57iVAGCuUBUIhzkEnJHOMEEzeIv2WvihpvjSw8MafeaHqi6iHcX0MjQCGJMbpJkYFlUZAyu7JIUcmuCpUpOdm7tfgenD2vs1yqyt06nzqlwyGK2dtyoYz9fm5/kK7W0uFl8QKrzY8uJtoAOfmb5scegFe2ap+w940i077Vo/jTQdSvlAZrWS3ltlbH8KSEsPxYAfSvFvFXhnxh4P1620fxJot1oep2UWxEuDtM43E+ZG33XXBC5QkYUUueFX4WaYapPDSvKO9vzT/AELF1M9iqMjKrw7ZQH253Yzx6jIHHIr3r4beMvhr4ziu7nxppejeHvG8lpjT77T/APR7e6YoAxjt8+Us/YkDJDcYxx852+oxPKr3g8sKrKYlwOCD93JHGcd6w9WLNp9jh0eSEkqQ3AOMnGOnPOe2KmdDnW50yx9NSvGLsndfh/kfT/7RE17ZeCvDljrk8669bXEs0NoyWvkx2jQjKp5PzBAyxgbsZJJxXkjTw6l4e0vEV6upafGZIBa2oP2iMSb1d9zLgqWKk/NkEHsccCNV17VL0rfXNxPLMAJLm6cvIFA6hiSTwSOeOa29V1N7++0SykZIzasRFMp27ASOT7j9RmlCEqSS3NaDoYpybk4vSy6O+jV+mmxz8ut6p4f8VyNbvItvvEqWkkm9PLYblU+nBAyK6ifxlZ6Le6prWnrHcXN9HbpbRydEAj3MzY9CQMdz9K4vxDL9reG+mH+lTNJ5p3FtwBAByeTzuGT2ArErrlh4VLSaOSjnGKwLlSpzvZ3T3s7NXV/J/fZnpOn+PpPEtlPoPiSK3Dzr/ot1GuwJKOVDDpgnjPvz7eczIY7h4ypUqxGD1FMBIORTpJHlkMjsWZjkk9z61dOjGm3y7M5MbmVbHRi8Q+aUdL9Wuz9P1G16doP+jfsueKry2/c3El6kLzR/K7R5gGwsOSuHcY6fM3qa8xr0/wCIkU3h74G+DvC9xC5mmd752kUxtEwBYxlDzkG4xnI+5054ufRHyOdtVJ4bDLeVRP5Q95/kl8zySiiike6FFXodPTylkvLgwhhlURN7kHoSMgAH656HGDmpPsWm/wDP9df+Ay//AByq5WK6M2itL7Fpv/P9df8AgMv/AMco+xab/wA/11/4DL/8co5WF0ZtFaX2LTf+f66/8Bl/+OUfYtN/5/rr/wABl/8AjlHKwujNorS+xab/AM/11/4DL/8AHKPsWm/8/wBdf+Ay/wDxyjlYXRm0VpfYtN/5/rr/AMBl/wDjlH2LTf8An+uv/AZf/jlHKwujNorS+xab/wA/11/4DL/8co+xab/z/XX/AIDL/wDHKOVhdGbRWl9i03/n+uv/AAGX/wCOUfYtN/5/rr/wGX/45RysLozaK0vsWm/8/wBdf+Ay/wDxyj7Fpv8Az/XX/gMv/wAco5WF0ZtFaX2LTf8An+uv/AZf/jlH2LTf+f66/wDAZf8A45RysLozaK0vsWm/8/11/wCAy/8Axyj7Fpv/AD/XX/gMv/xyjlYXRm0VpfYtN/5/rr/wGX/45R9i03/n+uv/AAGX/wCOUcrC6M2itL7Fpv8Az/XX/gMv/wAco+xab/z/AF1/4DL/APHKOVhdGbRWl9i03/n+uv8AwGX/AOOUfYtN/wCf66/8Bl/+OUcrC6M2itI2FiwxHqEobsZoNq/iVZj+hqhNDJBM0Uq7XXqOv0IPcd896TTQJjKKKKQzsPjP/wAlv1v/ALYf+k8dFHxn/wCS363/ANsP/SeOislsebkn/Iuw/wDgh/6Sg+DH/Jb9E/7b/wDpPJXH12HwY/5Lfon/AG3/APSeSuPqo7ipf8jGr/gp/wDpVQ3PBviD/hFvHWm66YvMjtpf3qBckxsCj7RkfNtZsZOM4zXW/F7w8+ifEm5uo4NlnqP+lRMNxBc/6wEn+LflsAnAdemcV5tXs+kj/hY/wDk0wR+ZrnhvHkbUy0kQB2qMJ3RWUKOS0SEnmqvZ3OHNH9SxdLMPs/BPyTfuv5S0/wC3jySiiitT6EK9v/Zo+Ccnxa+JH2vV4JB4W0dlm1B+V+0MeUtlPq2CWI6IG7kV5R4Z8Ma14t8Xab4b0Oye41DUZhDbx4wGJ6sT2UAEk9AASelfqb8L/A+ifC74Yad4Q0crItspkuboLtN3cNjzJT9SAAOyqo7Vx43E+xhZbs68JhnWl5I6+CytrKIH5Y44l4RflRFA4GBwAAOB2ArlvDtxJrutaz4kSP5Jbkafbn0htxg4+sskpP09q5n44/FbTvhz8LdR1GWVXvZIzFa24PMsrcIgHuf0DHtXc+AdFl8MfC3QNCvZTPe2tjGLuZuslww3zOfcyO5rwEnytn0EnyWvv+n9fkbMc0VhZxPfzxRmSRYlPQM7HCqPUk8Vn+LvBnhbx74Xl0DxXo1tqlhJyI5h80bf343HzI3+0pBrh/i9ri2j+GNPiuPKuJtUEyAHBPlxSMMevIz+FdX4a8Uw6zpiylglwgAmjz0PqPY0leNmip4aUqftO58M/Gr9nbXvhNdvr2hW/wDb3hN3wLhogbiyJPCTAdR2EgGCeCAcZ8a/tGz1PS5rNUWNnAeHAHEg6AEeoJH41+pvjWO01X4aeILC7CtDNptwrbun+rYg/gQD+FfmN4l0Gys/EWfNW3F4qSRvjAhkbPyuOylgQe4OPWvSoYh1FaW5OGwDUXVg1o7NPqpJr5dvVo5aC8vYz5SO3y8Bev6GtAT3M7KY7OVrjbgsVwq++egHuapzoTNPb30Xlagkh3A9CfT/AANJNbIlpZSmSSSKUOZoxIQCyvjaeuOCp/GvShaSueFVi6c3B9HbX9Sjq0kDXoht5fNjhUJ5vZz1Zh7ZJx7YqhXSx6GL7UPPFqqWwUYghkCnp/ebPXr3NNuPDNy15JILZ7a2IBQJ++PTocHvWntEZPDt6qSetv8Ag69PU5yirEtlPDAssqqu5toQsN3/AHz1FV+9WmnsYSi4/EjovA3h5/E/jzT9L8jzbfzRLdA7gohU5fJXlcj5QeOWAyM1b+LniD+3/ilfbYtkWn/8S9Mrhm8tm3E8nPzl8dONvGc11/hkf8K7+Ct/4zmj2axq2LbT96fNGpztblDjOGkwcqwSPua8XrNu7ufO4N/XswqYr7FK8I+b3m/yj52YVc0uNJNUTzFDqivLtYZDFELAEdwSOfaqdXtI/wCQmf8ArhN/6Kaqjue+9h7MzuzuxZmOSxOST60lFWtM0671jW7PSdPiM13eTpbwRjq7uwVR+JIrURVor2Lx/wDCu00vxN4bgtdNvfC2mXt2+jT3msxSxK8sLgG8/e4wkqOjgZCghwCAOM66+GFjapJavqNzYxPqem2g1DXLAWbIlwt3udClzJE0X+jj5iTkjAZArbwDy6ivVoPh/wCENLm8V2/iK78TwxWWhw39rdTaPEkis19BCZI41vCkq4fYDvwd7ngxqGoa/wDCy38P+BX1i68XaV/akdrBdvpZurTeyzBCERVuDMZAsgYhoVGFYhjxkC55xRXe+Nvh9pnheLXP7L8TS6tLoesjRr9ZLD7MBI3nFGjPmNuH+jyBshcHGNwOau6D4Q0HXPgU1xFasviqXUb1rOcStieK2t7aR7bZnbuKzSupA3ExhedwoC55rRXtF58HNO1fx14nsNKv5NGS31i7sNLt7j7P9nmEXIQSTXSzOwyAQkUhGVJJzgctpfw70y90S3e88TyWurXOjXmuQWKWBkjMMEczhGl8wYd/IbjaQFOck/KQVzgKK9C1b4YjT/hgfFcOryfaYIbae70y8S2iljSbaFZUjuZJduXXBkijyGB9q1fhR8Mz4x8PajfXHhvVNVW7nGj2M9nFKyWNw8bP9plKcBEbyVIf5dsrH+HIB3PKKK6rxXodpo/hTwjPHZtb3t7YXEt9uZstKl9cQjIJwpCxouBjp65NdNqfgNm8D6NY6F4Zgu9Xe2juNSulvW+0WUkm6RBOhbykgaAxsGwMEkM4IK0AeX0V3vwt0XwxrN/4hXxXBus7fSd8c/mun2SWS7t4BP8AKRu2CZm2nIOORXT3vwu0qLSfCfhWSL7D4nutej0nVr/c0oieZUdUEe4KfLWRM4wS24E9MArnjdFeg+B/C9rLY22v3vk3UV5aeIbcWk0AZY3tdK85JQSTk7p1I4G0xgg5PGn4j8FeEo31NPDV1cPLa+GNN1KWLULXyUjkn/s8b45RckbnN07NvXYmWVQfldAZ5XRXq/hHwloOmeF/E934uTwfPdWV1YQwXGo6hdXdmizLcsyh9Ldiznyk6kgbTnBPJp3hHwZceE73WNelkso5PDh1W3fSLOSfyW/to2m7bNcrvOwBADtGx8kb03SArnlFFdfe+Bvsba4Bqm8aXodjrWfIx5v2k2n7r73y7ftn3uc+X0G7it488NaV4Q8bah4a07XJ9Wm066mtLqZ7MWyB43K/J+8Yt05yBg5A3DkgzmaKKKACiiigAp9yol0TzG+9BMqKf9lwxIPsCuR/vN60ypJf+Rfn/wCviL/0GSk9gMuiiisijsPjP/yW/W/+2H/pPHRR8Z/+S363/wBsP/SeOislsebkn/Iuw/8Agh/6Sg+DH/Jb9E/7b/8ApPJXH12HwY/5Lfon/bf/ANJ5K4+qjuKl/wAjGr/gp/8ApVQK3/BfiPUfC3jO01bTIHuZATE9qrMPtCNwU+XqehHBwwU4OMVgV33wo8Z3HgzxZNdWthZXj3EYieK5hVy8ecsisfuk8dM5xg8cVT2PQqYeGJg6NRXjLRrvc0fid4PttMu08U6CIP7D1BwqxRgxm2lK5KFG5GcMcYG05UhcDPIaJp8d3qCyXjpDZxAySyShthA/hyo6k4H49q9r8Y6Y83hO+8afD64nbwtcNv1DS4VCvpMowdjx9PLB5V1+7xnjBrzC1tLrVJtls97eqDvKxckccnA6e5qfaWWpWXZfUoU40Jz53HRNrVrpfu+l+u+50w8RXWma5pVz4dvriwNgFmtpobg7Y9vVUwcDIyCD1BOQ2a+ufEH7SfgrS/hTF41S8ZUuAyR2jAGfzh1hCZ5YZGT90Agk4Iz8Kbn093tUtWAcjj1PI549ecD+lcf4iu4rrUI7aGUXDxZV51bKuxxwPYdM9/piuOth41Em+h7v1+VKTlyq7+SXay9P67+4+DPE3iP9ob9r7wj/AMJOHTR4tQ+2JZ5zFHDD+9YZP32bywpPfIAAGBX6Qz6msUbyzPswCzk8Y7mvy6mSx0vw4lg9o0d3aymKMQktGqBiciRTzySemepz2r0i3/aA8f2HwtTwgkUN0ILZoU1qWWR5UXllkfqCVBAGT/CvpWFbDOdlHodFK0G5VXzNpNta28vX8D3Pxjrdr4q8S32u6hMINK09GitLhjjyipy84PbaVCg99r9Qai+HXxAg8SaDHrukT+VcwuYbmLGCjj1X+6www9jjqDXxcPF+rXXhqDQLvU7s2cGTHDLO7Q5znlPXJz6ewqz4M8b6t4L8SSappuoGNpkMcyMnmxyjsHTIzg4IIIIPsSKqWAlytdeh3U84w/upbPfyPuP4q/FO1sPhJqGnsRBqmpx/Y7dC2VbJG9uudoXOfqBnkV8ba/qtvrDXz36tLd4EYkeTIPzuzkN352gZ55OKy/EfirXPFN++pX97LfTMNomOAI1/uoi/cHt+PJrnzNP5PlPwoGOeOK2w2HlSjZnHmWKwz5VSV2nq76W7dvO5avbiS/gS9nz9pjxDM3GTgABj79PzNWLe0lu9LiEeECOzSF+pfAHyj0AA+pPsKzIby3t7a7U/O7oqoB03Z6n6DP44qH+2dT8nylvZUT0jO3Oeucda6lTklaJxVMXh6tRVa6cm1rbv3b9DqINI1EACK4ZR2whxVhU1q2LAJHKMfN8pUkflXCtcTv8Afmkb6sTSx3NxE26KeRD6q5Bo9lPuQ8XgnoqLX/bz/wAjvfNtrlxHdweVP1VuhH0I/wAaraR4Y0q88bWUGr38dtYmRp7ma5chZUB3FMjG0nBBJIwDntis/QF1zWY7srH59rZwmWa5lIUQ/wB35u5JGAvU89gSLl7cb40uiwKgqiDH3ju5PuMZH4mpV4ys9zixSpYinUp4eo0rW6c0W9vK+z9DN+Ini5fFfir/AEGNINIsFNrYQxblTy1PDhTgKWAHAAwAo525rkKkuBGLqQRZ2ByFz6Z4qOtkrHnYXC08LSjQpK0Y6f159wq9pH/ITP8A1wm/9FNVGnwyyQXEc8TbZI2DqcZwQcimnZnQy7V3SNX1DQtZg1bSrj7PeQEmKXYrFCQRkBgRnBOD1BwRggGq8Ygu13wSwwv/ABQyybNvurNwR7Zz9cZL/scn/Pez/wDAuL/4qtSS7pniTVtIsXsbOW3e1e5ivGt7q1iuY2ljDqjFJVYHAkcEYwc8g4GNS6+Iniu9CR3N1p720csMqWX9mWotVaHzvLAgEflhQbmclduGLkkE4I577HJ/z3s//AuL/wCKo+xyf897P/wLi/8AiqBaHQj4i+KxrP8AaX2qw3C0Nh9l/sy1+yeQZPM8v7N5fk7fM+fGz73PXmq17408Qal4cTRNQlsLq3SNIUmm062e6SNCNiLcmPzlUAAAB8bfl6cVj/Y5P+e9n/4Fxf8AxVH2OT/nvZ/+BcX/AMVQGhf1HxRrurHVzqF9539sX66nffukXzrhfNw/AG3/AF8vC4HzdOBhLHxNrumW2mwWGoPAmm3zalabFXMVwwjBcHGTxDHwcj5enJzR+xyf897P/wAC4v8A4qj7HJ/z3s//AALi/wDiqA0Osg+LHj221G5v4tahN1cXkt+072Fu7pNLjzGjZoyYw+AGVNqkDBFXtE+KD6J8N5/DkWnXNxeyWdzp8d3cTwtHBBOGDoiiDzgMO52+cU3HdtzXC/Y5P+e9n/4Fxf8AxVH2OT/nvZ/+BcX/AMVQGhv3vxB8W6h4Zl0C71KF7GaGGCYLZwJJOkRXyhJKqB3K7FALMSAMZwSKx5tZ1O40rT9Nkuj9l08yNaxooXy2dgzNkAEkkDk5OAB0AqD7HJ/z3s//AALi/wDiqPscn/Pez/8AAuL/AOKoDQ0fEPirXvFd3Fc69erdSxebsYQxxY8yZ5n4RQDmSV2/4F6YFa1t8T/G1nYR2kGqwbUtxZmR7C3eWS3C7RBJK0ZeSLaAPLclcADHArmPscn/AD3s/wDwLi/+Ko+xyf8APez/APAuL/4qgNCWx1a/0611C3sp/Ki1C3+yXS7FPmReYku3kcfPEhyMHjHQkVPZeI9b06ytLSxv3t4rS9Go2/lqoaO4AUCQNjORtXjOOKp/Y5P+e9n/AOBcX/xVH2OT/nvZ/wDgXF/8VQF0dFe/Ebxffm38/UbdFt0u0hjtrG3gjjF3CIbjCRxhfnQYPHBywwxJqtc+N/El3ov9lT3lu1ubFdNdls4Flkt1eJ0jeUIHcKbeHbuYlQuBgEg432OT/nvZ/wDgXF/8VR9jk/572f8A4Fxf/FUBoSw6tqFvoF3osNxtsbyaK4nh2Kd7xBxGc4yMCWTgHB3c5wMaem+NvEmlfZVtby3aO2sm06OC5s4LiI27TtcGN45EZZB5rF/mBIOMdBjH+xyf897P/wAC4v8A4qj7HJ/z3s//AALi/wDiqA0N2fx/4sufC0vh6bUYmsJrWKylUWkIklhidHjR5Qm9ghjTbljtA2jAJBxtW1S/1zX77WtUn8++vriS6uZtqr5kjsWZsKABkknAAFR/Y5P+e9n/AOBcX/xVH2OT/nvZ/wDgXF/8VQGhXoqx9jk/572f/gXF/wDFUfY5P+e9n/4Fxf8AxVAXK9FWPscn/Pez/wDAuL/4qj7HJ/z3s/8AwLi/+KoC5XqSX/kX5/8Ar4i/9BkqQ2uwbpbuzRB1YTq+PwQkn8BVG8ulmCQwgiCMkru+8xOMsfTOBx0GB15JUnZD3KtFFFZFHYfGf/kt+t/9sP8A0njoo+M//Jb9b/7Yf+k8dFZLY83JP+Rdh/8ABD/0lB8GP+S36J/23/8ASeSuPrsPgx/yW/RP+2//AKTyVx9VHcVL/kY1f8FP/wBKqBSqzI4dGKspyCOoNJRVnpnc+HPiLqulavBcrOLaUAJJLGCFnHQeYucH647nIOTXbjTrPxLJN/wjWqJ4ekmYySWdtEPLMhOQflIITPQDIHYDpXh9aGna3qWlyo9ncuhQ5Xn7p9vSp5Va1jrpYucanPKT13to2dV4quPE3hrTb601u6uhNKnkoxfcs5bjcGxzhQeeCOAcVyOhaEIymoaggzt8yGB0Dg+8ikj5enGOc9h19g04eIvGPhWz8SSQ2OpXEJkSO2jbdLDtxukWNuGkOOqksFAwBmuV1C7tp4SRbvNKDu8tUfcx+mM5/WsXGz2sdlaSrS53Ucktr7/n+RmQxTXKM/mSxAj5RGWUSHjnB6Dnnp/WrV9Le2+gXkE1/IkroC9lFkKi7gMyZx8x4woBwDye1dJpOk+IvIu7mKxk0hmVViu7yMxmKLqzqpGQQBgYA6k5HWsrxBB4S03w5cx2usT6pq0+FDMchfnBLNt4zgdyetOMG2rrQ0U6cKUnTl7zTvray1Xe7b6Lon1ODooorrPEFVmU5UkH1FDOzHLMT9TmkooAK3LTwzcSWAvdQuYrCJ0LwpIC00/HGyMc4PHJwOepqhpk1ra3gurqMSiPlYiMhm7Z9hXXabo/izxrfpcWPh9pI5v+X27DLCFDbSdxwGwc5Ay3B4OKynKWyN1UweGpOvjKiiuibt97/TdnJx6TcscO8ER9HkGfyFaCaPZjzw0rvuXEQCncp9eBg16A3h34c/D2QXPjLUhrGsLtf+yrIZSM/I2CmecZJ/eFQyk/KTXn3izx3qfimaOJbe30vToAUgsbJdiBc5G8j7xACjsOOAMmlzOWx42BzeOLqf7PSbp/zvRP/Cmry9bJeZrtqbWulpp9v5kGnKzMsMriJWYgDc/Te2AOSPoAK53UtXj3v5MgmmYbQ6ghIh/s56n3rAJJOSc0UlA9r2sIK1ONv6+S/UKKKKs5wooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA7D4z/8lv1v/th/6Tx0UfGf/kt+t/8AbD/0njorJbHm5J/yLsP/AIIf+koPgx/yW/RP+2//AKTyVx9dh8GP+S36J/23/wDSeSuPqo7ipf8AIxq/4Kf/AKVUCiiirPTCiiigDR0nXtY0OczaTqM9ox6+W3DfUdDXVv8AGT4iSWLWreIZdpXbvCKHx9RyK4Oigd2jr9A+Jni7w9qkl7b6gLoTHMsN2vmI/Bx6FeuflIyQM5xXWSfE/wAEeJJAfGvgJGmKq8l7p8g82WQALz9xgmM8F2xhRzjI8kopNJ6nk4vJsJiavt5RaqfzRbi/vTV/nc9a/s/4FXQ+1f8ACT63Zeb+8+y+Wx8nPOzPktnHT7zdOp60v/CsfBv/AEVvQv8AyF/8erySijXuc/8AZOJh/Bxc16qMvuvH/hz1v/hWPg3/AKK3oX/kL/49Sf2D8ErY/ZrzxzqktxF8kslvETGzjglMQsNpOcYY8dz1ryWijXuH9k4qf8XGTfooR/KJ63F8RPhn4euY7jwv8PpLiYsHaTUJQGiZTlDGWMpByTyNvQde3O+IPi5431/Yv9pf2XEmD5emboNzDPJbcXPXpuxwOM81w1FHKjSjkOCpz9rOLnPvNuT/ABbt8gooopnshRRRQAUUUUAFa/hVbJ/HGkJqMKy2rXkSyIxAUgsB82QQV9R3GRxnNZFFCBnr+iaaLPxRqiW8F9psEWuWX+hy7CsgMz4YfuwQuOVAOMHq1VrXw5otr8VbHz7WTU7a/wDtTfaZGQ27y7XPlhCp5U/LhiDuwcDGD5TRWnP5EcnmegaP4I0zUoVkuIdVtmku3t5YzImdNVVBDz5QZyfZPrmrt9oNpqHwr0e582a7uLKznMVrasFZ189synIOUXHIAzyOg5rzKilzLsPlfc7HT/BbpBqqarY391qVhJHH/ZWnyp5pDjO/IV8qBjoD17VZtPBel3HhdNQee8UvZzXL3e9fItpEJAgcbcljj1B54BrhaKV12Cz7no0vg7wra6NNdT/2xJJbafaXsmy4jVXMxClVBjOACc5Oar33hXTtH1w6DKTMLzVlt4pXA8wQoAWwccFmkVc+qGuBqRridkiRp5CsIxGCxwgzn5fTkk8dzT5l2Dlfc9Mu9I0648GS3UulQwRCCORZ44o40jLQSSfK4XexV0SMh2bJJ6EjGfd+C9AXSJPIub+G7h0211CSaaRGi/esAy7QgIAznO6uSvfEGrahaNb3dxG6uQZHEEaySkdN7hQz/wDAiazKHJdhKLPRtY8C+HNJvLASX2pNby30dtJMI32SRsP9YkhiCAg/whnyO9LqPw90jS9IvLm61SYSWSiC4G5cJcO0Zj7cpskJPfKnkV5xRRzLsPlfc9fuPCWnWfhSfQg17ZWc+tW8Rv7x1ZJl2H95HhQApzjqe3PWsQeA9IbVdPgll1Cxa4+05sLh0NxJ5QyhQ7QBv7ZH0zXndFDkuwlF9z1jWvDVpfW+kW01pqUT2ei+bFpe9ftUreafkzs6jJJ+TOO1UrH4eaLc67qVgtzfztb+V5QUlEQsm5llmWKRVZTxyB/SvNKKOZdg5X3PQLL4fwXXgW61iUyxTQ2c12ksc/mxP5ZPykCIKuQP+ehPfGOmrbeHtP0TwJrk0UOoXEE+m20kl9vXyZtzqzJH8vBHTkn3A7+VUUcy7DcW+p6UPh94fTVbS1n1iZV1CR57Fg6/vLURhlzhSd7M20YH8LYB4FVpPBmgWuqagLl9Wa3tdKN+YCrQSBw4XbulhXcv+0EH6V59RRzLsHK+56c/hjQ7DQPE1pb6ZeajMkVldQEOhnjjdSx2kRnAU53EDBGPu4yaFx4Cs49CutWjN81omm211DPuUo8sjAOudvIGTwORxmuAoo5l2Dlfc9GbwT4al8c6poNtPqKf2dEW2yzB5Lpvl4QJCSoGTnCuTxwOa4/xLpdto3ia40+zluJIY9pU3MLwyDKg4ZXVTxnrgZ696yaKTafQEmuoUUUVJQUUUUAFFFFAHYfGf/kt+t/9sP8A0njoo+M//Jb9b/7Yf+k8dFZLY83JP+Rdh/8ABD/0lHO+Edefwz450vXVaQJa3CtL5aqzNEflkUBuMlCw7deo61s+PvDkHhrxtPa2LxyaZcot5YSxuHV4JMlcHcxIBBXJOTtz3FcZXX+GPEWlS2UPhbxms8uhebvguoD+/wBOdj8zRkg5jb+NMH+8BuHLTsx4qlOlWWLpq+lpJbtbpru466dU3bW1+corvJPhdqeoOJfBWrab4otCiuXtbhIpYQygjzY3YFCTuAGSflOcHimf8Ke+I3/Qu/8Ak3B/8XV8yIWd4C3vV4p9m1F/NOzXzRw1Fdz/AMKe+I3/AELv/k3B/wDF0f8ACnviN/0Lv/k3B/8AF0cy7j/tvLv+giH/AIHH/M4aiu5/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai6OZdw/tvLv+giH/AIHH/M4aiu5/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai6OZdw/tvLv+giH/AIHH/M4aiu5/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai6OZdw/tvLv+giH/AIHH/M4aiu5/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai6OZdw/tvLv+giH/AIHH/M4aiu5/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai6OZdw/tvLv+giH/AIHH/M4aiu5/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai6OZdw/tvLv+giH/AIHH/M4aiu5/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai6OZdw/tvLv+giH/AIHH/M4aiu5/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai6OZdw/tvLv+giH/AIHH/M4aiu5/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai6OZdw/tvLv+giH/AIHH/M4aiu5/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai6OZdw/tvLv+giH/AIHH/M4aiu5/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai6OZdw/tvLv+giH/AIHH/M4aiu5/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai6OZdw/tvLv+giH/AIHH/M4aiu5/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai6OZdw/tvLv+giH/AIHH/M4aiu5/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai6OZdw/tvLv+giH/AIHH/M4aiu5/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai6OZdw/tvLv+giH/AIHH/M4aiu5/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai6OZdw/tvLv+giH/AIHH/M4aiu5/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai6OZdw/tvLv+giH/AIHH/M4aiu5/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai6OZdw/tvLv+giH/AIHH/M4aiu5/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai6OZdw/tvLv+giH/AIHH/M4aiu5/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai6OZdw/tvLv+giH/AIHH/M4aiu5/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai6OZdw/tvLv+giH/AIHH/M4aiu5/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai6OZdw/tvLv+giH/AIHH/M4aiu5/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai6OZdw/tvLv+giH/AIHH/M4aun8A+HIPEvjaC1vnjj0y2Rry/lkcIqQR4LZO5SASQuQcjdnsa1Y/hdqenuZfGurab4XtAjOHurhJZZgqknyo0YlyDtBGQfmGMnisbxP4i0qKym8LeDFni0Lzd891Of3+oup+VpCAMRr/AAJgf3iNx4Tl2MquOWMi6GBldtfGtYx877N9km9d7IyvF2vP4m8c6prrNIUurhmi8xVVliHyxqQvGQgUd+nU9aKxaKk9ajSjRpxpQVlFJL0QUUUUGgUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB//2Q==",
	"tenang": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwMDAgQDAwMEBAQFBgoGBgUFBgwICQcKDgwPDg4MDQ0PERYTDxAVEQ0NExoTFRcYGRkZDxIbHRsYHRYYGRj/2wBDAQQEBAYFBgsGBgsYEA0QGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBj/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4Poor1bTtOT4Oxab4g8QaPFeeMrpFvNN0q+jbyNNh3EC4nAILTMVYJGCPLwWbDBVHfQoOo227RW77f8HsjzMfj1hUoxXNUl8Mdm2vyS6vp5tpPnvD/wAIviT4osvtmj+Eb97cokiTXO21SVHBKtG0pUOCBnK56j1Gdj/hnv4v/wDQof8AlQtf/jtGjSeJ/jZ8VtN0PxN4quTLdeb5c8kYeO32wljshUqq7vKUHbjJ5OTXqn/DJf8A1P8A/wCUr/7dXrYbLY4mLlRpykk7X5ox/Bp/mz4zN+KamU1Y0cwxdKlOSUuX2VWpZXa+JTjfVP7MX5Hlf/DPfxf/AOhQ/wDKha//AB2j/hnv4v8A/Qof+VC1/wDjteqf8Ml/9T//AOUr/wC3Uf8ADJf/AFP/AP5Sv/t1dH9h1P8AnxL/AMDh/wDInlf8RCwv/Qxpf+E9b/5YeV/8M9/F/wD6FD/yoWv/AMdo/wCGe/i//wBCh/5ULX/47Xqn/DJf/U//APlK/wDt1H/DJf8A1P8A/wCUr/7dR/YdT/nxL/wOH/yIf8RCwv8A0MaX/hPW/wDlh5X/AMM9/F//AKFD/wAqFr/8do/4Z7+L/wD0KH/lQtf/AI7Xqn/DJf8A1P8A/wCUr/7dR/wyX/1P/wD5Sv8A7dR/YdT/AJ8S/wDA4f8AyIf8RCwv/Qxpf+E9b/5YeV/8M9/F/wD6FD/yoWv/AMdo/wCGe/i//wBCh/5ULX/47Xqn/DJf/U//APlK/wDt1H/DJf8A1P8A/wCUr/7dR/YdT/nxL/wOH/yIf8RCwv8A0MaX/hPW/wDlh5X/AMM9/F//AKFD/wAqFr/8do/4Z7+L/wD0KH/lQtf/AI7Xqn/DJf8A1P8A/wCUr/7dR/wyX/1P/wD5Sv8A7dR/YdT/AJ8S/wDA4f8AyIf8RCwv/Qxpf+E9b/5YeV/8M9/F/wD6FD/yoWv/AMdo/wCGe/i//wBCh/5ULX/47Xqn/DJf/U//APlK/wDt1H/DJf8A1P8A/wCUr/7dR/YdT/nxL/wOH/yIf8RCwv8A0MaX/hPW/wDlh5X/AMM9/F//AKFD/wAqFr/8do/4Z7+L/wD0KH/lQtf/AI7Xqn/DJf8A1P8A/wCUr/7dR/wyX/1P/wD5Sv8A7dR/YdT/AJ8S/wDA4f8AyIf8RCwv/Qxpf+E9b/5YeV/8M9/F/wD6FD/yoWv/AMdo/wCGe/i//wBCh/5ULX/47Xqn/DJf/U//APlK/wDt1H/DJf8A1P8A/wCUr/7dR/YdT/nxL/wOH/yIf8RCwv8A0MaX/hPW/wDlh5X/AMM9/F//AKFD/wAqFr/8do/4Z7+L/wD0KH/lQtf/AI7Xqn/DJf8A1P8A/wCUr/7dR/wyX/1P/wD5Sv8A7dR/YdT/AJ8S/wDA4f8AyIf8RCwv/Qxpf+E9b/5YeV/8M9/F/wD6FD/yoWv/AMdo/wCGe/i//wBCh/5ULX/47Xqn/DJf/U//APlK/wDt1H/DJf8A1P8A/wCUr/7dR/YdT/nxL/wOH/yIf8RCwv8A0MaX/hPW/wDlh5X/AMM9/F//AKFD/wAqFr/8do/4Z7+L/wD0KH/lQtf/AI7Xqn/DJf8A1P8A/wCUr/7dR/wyX/1P/wD5Sv8A7dR/YdT/AJ8S/wDA4f8AyIf8RCwv/Qxpf+E9b/5YeV/8M9/F/wD6FD/yoWv/AMdo/wCGe/i//wBCh/5ULX/47Xqn/DJf/U//APlK/wDt1H/DJf8A1P8A/wCUr/7dR/YdT/nxL/wOH/yIf8RCwv8A0MaX/hPW/wDlh5X/AMM9/F//AKFD/wAqFr/8do/4Z7+L/wD0KH/lQtf/AI7Xqn/DJf8A1P8A/wCUr/7dR/wyX/1P/wD5Sv8A7dR/YdT/AJ8S/wDA4f8AyIf8RCwv/Qxpf+E9b/5YeV/8M9/F/wD6FD/yoWv/AMdo/wCGe/i//wBCh/5ULX/47Xqn/DJf/U//APlK/wDt1H/DJf8A1P8A/wCUr/7dR/YdT/nxL/wOH/yIf8RCwv8A0MaX/hPW/wDlh5X/AMM9/F//AKFD/wAqFr/8do/4Z7+L/wD0KH/lQtf/AI7Xqn/DJf8A1P8A/wCUr/7dR/wyX/1P/wD5Sv8A7dR/YdT/AJ8S/wDA4f8AyIf8RCwv/Qxpf+E9b/5YeV/8M9/F/wD6FD/yoWv/AMdo/wCGe/i//wBCh/5ULX/47Xqn/DJf/U//APlK/wDt1H/DJf8A1P8A/wCUr/7dR/YdT/nxL/wOH/yIf8RCwv8A0MaX/hPW/wDlh5X/AMM9/F//AKFD/wAqFr/8do/4Z7+L/wD0KH/lQtf/AI7Xqn/DJf8A1P8A/wCUr/7dR/wyX/1P/wD5Sv8A7dR/YdT/AJ8S/wDA4f8AyIf8RCwv/Qxpf+E9b/5YeV/8M9/F/wD6FD/yoWv/AMdo/wCGe/i//wBCh/5ULX/47Xqn/DJf/U//APlK/wDt1H/DJf8A1P8A/wCUr/7dR/YdT/nxL/wOH/yIf8RCwv8A0MaX/hPW/wDlh5X/AMM9/F//AKFD/wAqFr/8do/4Z7+L/wD0KH/lQtf/AI7Xqn/DJf8A1P8A/wCUr/7dR/wyX/1P/wD5Sv8A7dR/YdT/AJ8S/wDA4f8AyIf8RCwv/Qxpf+E9b/5YeV/8M9/F/wD6FD/yoWv/AMdo/wCGe/i//wBCh/5ULX/47Xqn/DJf/U//APlK/wDt1H/DJf8A1P8A/wCUr/7dR/YdT/nxL/wOH/yIf8RCwv8A0MaX/hPW/wDlh5X/AMM9/F//AKFD/wAqFr/8do/4Z7+L/wD0KH/lQtf/AI7Xqn/DJf8A1P8A/wCUr/7dR/wyX/1P/wD5Sv8A7dR/YdT/AJ8S/wDA4f8AyIf8RCwv/Qxpf+E9b/5YeV/8M9/F/wD6FD/yoWv/AMdo/wCGe/i//wBCh/5ULX/47Xqn/DJf/U//APlK/wDt1H/DJf8A1P8A/wCUr/7dR/YdT/nxL/wOH/yIf8RCwv8A0MaX/hPW/wDlh5X/AMM9/F//AKFD/wAqFr/8do/4Z7+L/wD0KH/lQtf/AI7Xqn/DJf8A1P8A/wCUr/7dR/wyX/1P/wD5Sv8A7dR/YdT/AJ8S/wDA4f8AyIf8RCwv/Qxpf+E9b/5YeV/8M9/F/wD6FD/yoWv/AMdo/wCGe/i//wBCh/5ULX/47Xqn/DJf/U//APlK/wDt1H/DJf8A1P8A/wCUr/7dR/YdT/nxL/wOH/yIf8RCwv8A0MaX/hPW/wDlh4n4g+EXxJ8L2X2zWPCN+luEeR5rbbdJEiAFmkaIsEABzlsdD6HHFV7B4t03xP8AAL4hQaf4Z8Y3Ly3Nml3JJHAIo3y0sYV4mZ1fGGILZwW4wRmquo6cnxii1LxB4f0eKz8ZWqNealpVjG3kalDuANxACSVmUsoeMk+ZkMuWLKfMrYOKk6cE1NfZdn9zVrvyt6XPrcBnlV0oYrESjPDzWlSKlG13Zc0JNuK6c3M9dWorVeU0UUV5p9Udr8IvD9v4o+N3hzR7wxG3a68+VJYhKkqRK0xjZScEMIypz/e6HoaXjHxNd+MvHep+Jr5dkt7MXWPIPlIAFRMgDO1Aq5wCcZPJrpf2e/8Ak4/w5/28/wDpLLXn1d22EjbrJ3+Sjb7rv7zwKaU86quX2KVO3lzzqc338kb+iLOn6jqGk6jHqGlX9zY3cWfLuLWVopEyCDhlIIyCR9Ca3P8AhYvxB/6HrxL/AODSf/4quaorGNWcFaMmj1K2Dw9eXNVpqT80n+Z0v/CxfiD/AND14l/8Gk//AMVR/wALF+IP/Q9eJf8AwaT/APxVc1RVfWKv8z+9mX9l4P8A58x/8BX+R0v/AAsX4g/9D14l/wDBpP8A/FUf8LF+IP8A0PXiX/waT/8AxVc1RR9Yq/zP72H9l4P/AJ8x/wDAV/kdL/wsX4g/9D14l/8ABpP/APFUf8LF+IP/AEPXiX/waT//ABVc1RR9Yq/zP72H9l4P/nzH/wABX+R0v/CxfiD/AND14l/8Gk//AMVR/wALF+IP/Q9eJf8AwaT/APxVc1RR9Yq/zP72H9l4P/nzH/wFf5HS/wDCxfiD/wBD14l/8Gk//wAVR/wsX4g/9D14l/8ABpP/APFVzVFH1ir/ADP72H9l4P8A58x/8BX+R0v/AAsX4g/9D14l/wDBpP8A/FUf8LF+IP8A0PXiX/waT/8AxVc1RR9Yq/zP72H9l4P/AJ8x/wDAV/kdL/wsX4g/9D14l/8ABpP/APFUf8LF+IP/AEPXiX/waT//ABVc1RR9Yq/zP72H9l4P/nzH/wABX+R0v/CxfiD/AND14l/8Gk//AMVR/wALF+IP/Q9eJf8AwaT/APxVc1RR9Yq/zP72H9l4P/nzH/wFf5HS/wDCxfiD/wBD14l/8Gk//wAVR/wsX4g/9D14l/8ABpP/APFVzVFH1ir/ADP72H9l4P8A58x/8BX+R0v/AAsX4g/9D14l/wDBpP8A/FUf8LF+IP8A0PXiX/waT/8AxVc1RR9Yq/zP72H9l4P/AJ8x/wDAV/kdL/wsX4g/9D14l/8ABpP/APFUf8LF+IP/AEPXiX/waT//ABVc1RR9Yq/zP72H9l4P/nzH/wABX+R0v/CxfiD/AND14l/8Gk//AMVR/wALF+IP/Q9eJf8AwaT/APxVc1RR9Yq/zP72H9l4P/nzH/wFf5HS/wDCxfiD/wBD14l/8Gk//wAVR/wsX4g/9D14l/8ABpP/APFVzVFH1ir/ADP72H9l4P8A58x/8BX+R0v/AAsX4g/9D14l/wDBpP8A/FUf8LF+IP8A0PXiX/waT/8AxVc1RR9Yq/zP72H9l4P/AJ8x/wDAV/kdL/wsX4g/9D14l/8ABpP/APFUf8LF+IP/AEPXiX/waT//ABVc1RR9Yq/zP72H9l4P/nzH/wABX+R0v/CxfiD/AND14l/8Gk//AMVR/wALF+IP/Q9eJf8AwaT/APxVc1RR9Yq/zP72H9l4P/nzH/wFf5HS/wDCxfiD/wBD14l/8Gk//wAVR/wsX4g/9D14l/8ABpP/APFVzVFH1ir/ADP72H9l4P8A58x/8BX+R0v/AAsX4g/9D14l/wDBpP8A/FUf8LF+IP8A0PXiX/waT/8AxVc1RR9Yq/zP72H9l4P/AJ8x/wDAV/kdL/wsX4g/9D14l/8ABpP/APFUf8LF+IP/AEPXiX/waT//ABVc1RR9Yq/zP72H9l4P/nzH/wABX+R0v/CxfiD/AND14l/8Gk//AMVR/wALF+IP/Q9eJf8AwaT/APxVc1RR9Yq/zP72H9l4P/nzH/wFf5HS/wDCxfiD/wBD14l/8Gk//wAVR/wsX4g/9D14l/8ABpP/APFVzVFH1ir/ADP72H9l4P8A58x/8BX+R0v/AAsX4g/9D14l/wDBpP8A/FUf8LF+IP8A0PXiX/waT/8AxVc1RR9Yq/zP72H9l4P/AJ8x/wDAV/kdL/wsX4g/9D14l/8ABpP/APFUf8LF+IP/AEPXiX/waT//ABVc1RR9Yq/zP72H9l4P/nzH/wABX+R0v/CxfiD/AND14l/8Gk//AMVR/wALF+IP/Q9eJf8AwaT/APxVc1RR9Yq/zP72H9l4P/nzH/wFf5F7Vda1jXbxbvW9WvtSuEQRrNeTvM6qCSFBYk4ySce5q94O8TXfg3x3pniaxXfLZTB2jyB5qEFXTJBxuQsucEjORyKw6KiNSUZqonqtbm1TCUalCWGlFcjTTXSz0aOp+Lvh+38L/G7xHo9mYhbrdefEkUQiSJJVWYRqoOAFEgUY/u9B0BWx+0J/ycf4j/7dv/SWKirx0VDE1Ix2Un+Zw8O1p1sqwtWo7ylTg2+7cU2H7Pf/ACcf4c/7ef8A0llrz6vQf2e/+Tj/AA5/28/+kstefVpL/dYf4pflAxof8jnEf9eqP/pdcKKKK5T3AooooAKKKKACitzwz4O8T+MtRax8M6Lc6jKn+saMBY4shiN8jEKmdrY3EZIwMmvULX9nHVbCziv/AB14z8P+GLOVAFeWXzHWYjIibcUTOA+Srt93jI5HVQwNeuuanBtd9l970PFzHiLLcun7LFVkp/y7y/8AAVeX4HidFe6HwR+znY4s9S+JGvS3kIEc8ltA3lO44LJi3YbSeRhmGCOT1pf+Eg/Zmxn/AIV14k/7/v8A/JVdH9mtfFVgv+3r/kmee+KlL+Dg68v+4fL/AOluN7+V/O2h4VRXun/CQfsy/wDRO/En/f8Af/5KpP8AhHP2Zr0/bf8AhMvEum+f+9+xeUzfZt3Pl5+zvnbnGdzdPvHrR/Zt/hqwfzt+aQv9anH+Jgq8f+4fN/6RKT++x4ZRXuB/ZzOsf8iL8SPDXiDyv+PrL+X5Ofuf6oy5zh+u37vGeceaeKvh94z8FeU3ibQLmxilwEnyssRJ3YXzEJXd8rHbnOBnGKxrYDEUVzThp33X3q6O7AcS5Zj6nscPXXP/ACu8Zf8AgMkpfhtZ9Uc1RUr280VvFPJGVjlzsY/xYOD+tRVxnvNNbhRRRQIKKKKACrOnafd6trFppWnw+dd3cyW8Ee4Lvd2CqMkgDJI5JxVauq+Hn/I6S/8AYJ1P/wBIJ60owU5xi+rRzY2tKhh6lWO8Yt/crl6GPwpo8f2aPQ7fxBMOJry/mnjhdh3gjiaJlXkjMhYsArbYyStSf2n4c/6J74e/8CL/AP8AkqsevXvhv4L8Pa94Gsb3UdGtLye41t7Keaa8khkSAQB/3SLIodweQArE5PHcelhqUq8uSCX3L/Js8HN8RhssofWcQ5tXtpNrWze3NGK22VuyR5z/AGn4c/6J74e/8CL/AP8Akqj+0/Dn/RPfD3/gRf8A/wAlV6Z4C8EeEdV0mzudU0qW6Da7eWj+ZLJE7wR2bSqhCsNp3AHse3TiqHiL4dadF4d0D/hH4/Pm1vVmjs7sux8y2dUMYZc4BXcwbgHKmuj6nV9n7RKNvRX6eXmeYs9y7619Uk6ifdzlb7V9efpyN7Xt87cF/afhz/onvh7/AMCL/wD+SqP7T8Of9E98Pf8AgRf/APyVXafE3wl4d0vSbTWPCcUC2cVzJp115N8t2HdeY5SVdthdQ3ynGNvQVz8PgjzfhDceOv7atV8m7Fr9gI+dskDOc9ec7cdATmsqlCpCbhZOyvstvuO7C4/AYjD08Tzzipy5UnOd+ZuyTtJ2v62sZf8Aafhz/onvh7/wIv8A/wCSqP7T8Of9E98Pf+BF/wD/ACVW74W0TSZPh94g8U3unf2tcadJBFHYmR0jUOTmWTYQxAxgYI561u+F9I8Da/pupXmr6DcaTLog/tG4treWVheWxX/VfO2UO8rhh/C3cjdTp0Jz5fhV9dl5+VujIxWPwuH9o3GrJU2otqcnq0mlbn5n8UVe1rve12cL/afhz/onvh7/AMCL/wD+SqP7T8Of9E98Pf8AgRf/APyVXq2h+DPBmt+ENDmbRbOG/wBYtNRnjhjuLrz2eJ38tYiWMQVVAB8zk4HU5rmb3RfDWn/Bjw/qxtNGTU9Rt7sySXz3pmkZJSimERHygQMffwM4znmrlhKkY8zcbWvsvLy31Ry0s6wVWp7GMKvNz8luaW/v6/H8P7uWvl624/8AtPw5/wBE98Pf+BF//wDJVH9p+HP+ie+Hv/Ai/wD/AJKr07XPA3hq2+G8moxaLDDJH4fstQW6t7qSS4a5kID74i7BYyOd2xQOcHsKVx4Q8Ox/B3/hMl8PyjUXsEX+zPtD7YsyFPt+N+/YccKflyehWnLB1Ytp8uivstvuJpZ7l9SMZJVNZqC99/E0mv8Al5tr8uttL+ff2n4c/wCie+Hv/Ai//wDkqm/2TonimePT9I0aPRtZmYRWkdtPI9rcuThYmWVndHYnAk37MhQVUFpBk0Vwc6ekkreiX6H07wKir05yUujcpNfNOVn6HN1v6JoltPY/2tqxm+w+Y0EcVu4SSeRQpYBirBFUOpJIOdwAH3mSb4i/8lh8Wf8AYZvP/R71qSf8ij4a/wCvCT/0ruK8/EJ024ro7BUxcquHpVI6e0t8rxct/la/3WYeZoH/AEJ2kf8Af+7/APj9HmaB/wBCdpH/AH/u/wD4/VSvYfhV8KNF8YeF59c1u7utpmaCKG2cLtwBlmJB554Ht3zXJzy7nlY7E0cDS9tWnK3+KX+Z5T5mgf8AQnaR/wB/7v8A+P0eZoH/AEJ2kf8Af+7/APj9dXfeCLTTfjhH4JudRJtGu4ovtHAbY4VgPQNhgPrV7VPD+iXHhbxJfRaG2izaNqEVrD+9kb7UruylGDk/OoAbK4GD0o55dyHjKPuWlJqSTT5pbSdl9q+/3dThvM0D/oTtI/7/AN3/APH6PM0D/oTtI/7/AN3/APH69h8TfDzwlanxRf6RZEW2nWvleQ07k2tyGQ7uWyysj5GcjIb0FYw8IeHf+GlLnwr/AGd/xKEEhW286TjFqXHzbt33uev6Uc8u5zUs1w9WDnFz0i5fE9kk39rf3l/meb+ZoH/QnaR/3/u//j9HmaB/0J2kf9/7v/4/Xq/hXwF4X13wz4QdrQ/2ndPJcXaGZwLu3ScxuB83ysoKH5cZAasm10LwzafDu81i7s9IFymuTWKSapJeFPKWMMEUW5zuznlvfnpRzy7lLM6Lk4LnbTt8Uu7X83k/6uefeZoH/QnaR/3/ALv/AOP0eZoH/QnaR/3/ALv/AOP1Uoo55dz1vZf3pf8AgUv8y2W8PSKY38JafGrcF4Li5WRR6qWlZQ3oSrDPUHpXPa7oyacIL6yd5NPumdYTIR5kbrtLxvjGSu9PmAwwYHg7lXWqXUf+SaX/AP2E7T/0Vc1dObvZl05Soyi0202k023u7dW7W3/A4yiiiuk9o9B/aE/5OP8AEf8A27f+ksVFH7Qn/Jx/iP8A7dv/AEliorozH/eqv+KX5s8Thf8A5E2D/wCvVP8A9IQfs9/8nH+HP+3n/wBJZa8+r0H9nv8A5OP8Of8Abz/6Sy159VS/3WH+KX5QFQ/5HOI/69Uf/S64UUUVynuBRRXoPwv+F954+1Ka/v7j+y/DOn5fUNUkIQKFG4ohbjdt5JPCD5j/AAq2tGjOtNU6au2ceYZhQy+hLE4mXLCP9WXdvZJatnK+GvC+v+MNdXRvDemy396UaTy0KqFVerMzEKo6DJI5IHUgV7dB4C+Efwn8u5+Ims/8JLr8e1/7Gsl3JE37tsMmRnGSQZWVXQn5CRWP4h+LWneHPCsHgj4Ppc6VpcW8XWqyooub1zlS4PVdww2/CuPlAEYTB8er0VKhhNIJTn3fwr0XX1enkfNPDZlnnvV5Sw1DpGOlSS7zl9hf3Y66u8kes+Jf2gfGGpwLp3hmK28LaTHD9njtbFVaRU2BceYVG3bg7TGEKg9yAa86jOreKfFEYvL+e8v7t1R7q8lMjHAAyzsc4VR36AVl16Vo/hHVvtOmaD4Y019S8SaifJEVud7+YxP7vnAQIFJYngYJJwK4sTi61bWpK/5fdsfRZRkeX5daOFoqC6tL3mvOT1fq2zmPG7WR8dXh08A2qlUjI4yqqFB/EKK9b+GmixXVhEvi/wDZ2TUvDsww2r20l3Z3SKR9+NpJgkv+6AM9jXsfgz4FeGfhmbfW/EAfxR4wkj3w2lrjyLbb1MZYZwv8U7YH90evRy3+u+KdSk0Y6f8AZb140kMUd1I+2N87fO39mCkjODgA4wRXJHZI92u/bVp1UrJtux8peMfg9eH4j31p8PIJ9S0FtstpPcyojKrjOxi2MkfTpjPNY2pfBX4m6XaNdT+FLuWFRktbMs2PwUk/pX2H4b8LXegO11qeiz/YdxWW9s5d8tsQcHzYyCdowMleg5wRXos2h6nHarc6cI9WtWUN5A2pMynkGJxhGOOgbGf71Vz2MXTR+YKm+0vU0kRriyvbaQOrAmOSJ1OQR0KkHBzXr/w3+LXxQg1W0tp706vo6MEnfVFLCNS4ZmNwBv34yF3FuuApwANv4reJdD8Q/E+4d9JiSx0l3gBnt/IuJ3X7xk3DcmCCNpHAGcBjx5nL4nkvkdJ742Fkp4CAvI/rsXOBwOp/OtaWNrUHehJpnLXyHLczap5lTU4eaV/k/s+q1PQ5/C/w4+JXiG70p/EMHhbVonWHS7WGFI7doy65AjwqszO7AKrhsknDAV4/408BeJ/AOsJp/iSw8jzdxt7iNg8VwqtgsjD8DtOGAZcgZFZ9/d/bdQkuAnlqxwqA52qOAPyxXpfgf4wNp+hSeDfiBaSeIfCUtt9mFttUzW4GSuxiVLAHAGWBTClCu3B66CoVaap1fdl/N0b/ALy/VfceHnH9o4TF1MZgX7Wg2v3TspRilZezl5JL3Jb20km9fH6K9Q+JHwpg8OaHaeM/BWoS654PvEUreHDSWzH5cS4A4LZAOBtb5GAIG7y+uWvh50J8lRa/n5ryO/Lczw+ZUFiMNK62fRpreMk9U11TCiiisTvCtnwrq8Gh+LLa/vEkezZZLa6EQBk8iaNoZTHkgbwkjFc8bsZyMisaiqhJwkpLdGValGtTlSntJNP5nZ6jpF5pscNxIomsrnLWl9EGMF0oxkxsQM4yAVOGU/KwVgQI4dV1O3tIrWDUruKCGcXUcSTMqpKBgSKAcB8AfMOaw9I8ReINA87+wtd1PS/P2+b9hung8zbnG7aRnGTjPTJrS/4WL8Qf+h68S/8Ag0n/APiq6lWp73a/r1Rwzp4r4XCM0urbX4csrffrvpsaaeJfEUbs8ev6ojNM9wWW6kBMrrtZ+v3ipIJ6kHFMt9f160itIrXW9Rgjs2Z7ZIrl1EDNncUAPyk5OSOuTWf/AMLF+IP/AEPXiX/waT//ABVH/CxfiD/0PXiX/wAGk/8A8VV/WIfzP7v+CY/Va1rewp/+BPz/AOnfm/vZOl9ex6fLYR3lwtrMweWBZCEkYdCy5wSMnBNV6X/hYvxB/wCh68S/+DSf/wCKo/4WL8Qf+h68S/8Ag0n/APiqh1aT6v7v+CbJYuN7U4a/3n/8gWdP1PUtJu/tWl6hdWM+MebbStE2PTKkGntrOrtPdzNqt6ZLxdl05nYmdfRzn5hwODnpVP8A4WL8Qf8AoevEv/g0n/8AiqP+Fi/EH/oevEv/AINJ/wD4qqVaCVuZ/d/wSJUcRKXO6ML9+Z//ACBqQ+J/Elto40m38Q6rDYBSotI7uRYsEkkbAcYJJzx3NEHifxLbaOdItvEOqw6eUaM2kd3IsW1s7l2A4wcnIxzk1l/8LF+IP/Q9eJf/AAaT/wDxVH/CxfiD/wBD14l/8Gk//wAVT+sR/mf9fMzeEqu98PT1d/i69/4e/mXxruuCTzBrOoB/s32Ld9ofPkdPK6/c/wBnp7UHXtcN09ydZ1AzPB9leU3D7mhxjyyc5KY429Kof8LF+IP/AEPXiX/waT//ABVH/CxfiD/0PXiX/wAGk/8A8VS9vD+Z/d/wSvq9f/nxT/8AAn/8rErV0vS0kiXWdZS4t9AglC3V4gxvxgmGEkENMwPyr2zubCKzDL/4WL8Qf+h68S/+DSf/AOKrI1XWtY128W71vVr7UrhEEazXk7zOqgkhQWJOMknHuan2tOOqu/69WbOGLqLkkoxT6ptv5XjHXs9bdmGtarca74l1DW7tIkuL+5kupViBCK0jliFBJOMk4yTXTaLK2u6BZaXao0up2AeJLaNSWngLmQFByWdWeTcB/DsIBCuRxdFcVRc97m9XCRlTjThpy7eWlvyOurofDfjnxT4Rini0DVXtopzueMosilsY3AMCAfcelcZ/wmvjL/obdd/8D5f/AIqj/hNfGX/Q267/AOB8v/xVYexfc4KuBq1o8lSEWuzbf/tptXt9eajqU2oX1zJPdTOZJJnOWZj3qa+1rWdTiij1LVr68SL/AFa3E7yBPoCTiuf/AOE18Zf9Dbrv/gfL/wDFUf8ACa+Mv+ht13/wPl/+Ko9i+5X1Otp7kdNtXp/5KdE+u63I120msagzXuBdFrhybjHTzOfmx2zmrUvjDxdMUM3inWpDGxZC99KdpKlSRluDhmH0JHeuT/4TXxl/0Nuu/wDgfL/8VR/wmvjL/obdd/8AA+X/AOKo9i+5DwFR704/f/8AanQQa1rFq9o1tq19C1mGFsY53UwBs7tmD8ucnOOuansvE3iTTYXi07xDqtnHI5ldLe7kjDOerEAjJOBz7VzH/Ca+Mv8Aobdd/wDA+X/4qj/hNfGX/Q267/4Hy/8AxVHsX3HLA1Zbwj9//wBqaRJJyTk0Vm/8Jr4y/wCht13/AMD5f/iqP+E18Zf9Dbrv/gfL/wDFUexfc0+r4jtH73/8iasUUs86QQRvLLIwRI0UszEnAAA6k1F4juksNCHh7IN49ytzeJ18gorLHHns/wC8lLjnHyDhg6jMn8XeK7m2ktrnxPrM0MqlJI5L2VldSMEEFsEEdqxquFLld2aUsJNyUqtrLWy1183Zbdrb216BRRRWp6R6D+0J/wAnH+I/+3b/ANJYqKP2hP8Ak4/xH/27f+ksVFdGY/71V/xS/NnicL/8ibB/9eqf/pCD9nv/AJOP8Of9vP8A6Sy159XoP7Pf/Jx/hz/t5/8ASWWvPqqX+6w/xS/KAqH/ACOcR/16o/8ApdcKKK1/C/hrVPGHi+x8N6MkTXt45VDK+xFAUszMfQKrE4yeOATgVzwi5yUYq7Z7FatChTlVqu0Yptt7JLVt+h1Xwv8AhfeePtSmv7+4/svwzp+X1DVJCEChRuKIW43beSTwg+Y/wq238TPiZZ6xpsPgbwNbf2X4N0/CRxRgob0qc73zzt3fMA3JPzv82Auj8WvEOh+HNGX4P+CLbyNL06ZZNRvBNue9uAoyHKnDYON24cOiqAojGfHq9SvNYWLw1Lf7T7+S8l+PofJ5XhZ5xWjm+NT5FrRg/srpUkru82tv5FtrdhRRU1ra3V9exWdlby3FxKwSOGJC7uT0AA5JrzT7AjjOJlJxwQeelfpd+zj8GT4T+G9x461eIT+IvEjPKkhXb9ksXYuiKDyplG1274KqfunPzD8Gf2d7hPFWn+I/i5aDStMjfz7fQLohbvUSvzfPF96KAdXZgCw+VR82R9z+LvG0+nfDi8ktZgLm5aPT7bGBtmnkEIYY9C5b/gNc9V32OihCUmorqS22habLdsURZpbtPNmkIzvjVwqj/cyeB06nua8t+CWPEWu/EDWrpN15Jr5JLdRH5W1B9AAQK9B8MeM9Jf4ueKtPtjHJDptvpumQxk/KgHnE/juwPwFedeB/E0HgT9qPXPBN7aQQWOrRl7KVlwLg5aSIn1O1pE+qAVjJtNHp4Smp0a8V8SSa9E9fw1+R66lhFFqsdr5eJLhWdcfxFAM/jgg/QVT077DpXjdfCrkQRXQ3W6MuPKkKlzGB/cdQzp7pIvYCuV+J/wAR5dH1XQtR0qFZJNP1p2uYYxlng+xkyhQOp2sCB/s1xvxk8bprHw3i8beGb5R4h0CeO52q+SyKyyY/2lOEkQ+hb1YVV+hz0MO6jV9E9L+f9fmYf7ZHwbstY8KyfEfwrCBqenhV1tI1x9qtlG37R7tHxuPdOv3BXi1p8F73UP2dI3l0pBc3Y+12l3wHWcD5FPfY6gR+m8g9q+07jxRb694Di1nTbaK7gv7JLlbV+VmjkQMYj9VYr9a820HUdFi8Gf2NYXP2uxbd9hYkEyJ18lv7syYwVON23cM5ONKb5Xc5nHoz83mBVipBBHUHtSV6p8bPh7P4a8ZXPiHSomn8PanM00NwgysEjHLwv/dIOcA4yPcHHlddBzNWdjvvhn8TLvwJqE1hf2/9p+Gr/KahpkgDqwYbS6K3G7bwQeHHB/hZbXxR+F1poenw+OfA1x/afgy/w8csZLtZFjjY+edu75QW5B+R/mwW83r0v4S+NtL0i7u/Bfi2zivvC2vukNyk8u1LWTOBMMkKo+7uYYYbEYHKAH0MPVjWh9WrbfZf8r/yfVfM+SzfAVcDWeb5cvf09pBbVIrd2uvfitYvr8Lvc8oorr/iX4Fu/h78QrvQZ/ntmzcWMpkDtJbszBC2AMN8pVhgcqccYJ5CvPq0pUpuE1Zo+jweLpYyhDE0JXhJJp+TCiiiszpCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAPQf2hP+Tj/Ef/AG7f+ksVFH7Qn/Jx/iP/ALdv/SWKiujMf96q/wCKX5s8Thf/AJE2D/69U/8A0hB+z3/ycf4c/wC3n/0llrz6vQf2e/8Ak4/w5/28/wDpLLXn1VL/AHWH+KX5QFQ/5HOI/wCvVH/0uuFfQvgKD/hU/wCzpqfxEuYvK1/XsWmleZH80SHOxhujOM4ebBJR1ji6E14t4O8M3fjLx3pnhmxbZLezBGkwD5SAFnfBIztQM2MgnGBya9J/aB8Sxan8SI/DOnJbRaT4ehFnbxWxQxq5VTJjaBt24SPZkhTF2JIrqwP7inPFPde7H1e7+S/NHl8Qx/tPGUMmT9yX7yr/AIItWj6TnZeiZ5NRRRXnn2AUoJDAg4PbFJRQB9L/AAce08IaHoX2pDc+IvFhm1FjIcm30uzDsuSeR5k0ROO+xD2r3D4leJP7J8J+GmEpMdtr1t5xPrEkjnP/AAJc18ufDvV5dd+MGr63Fvax0XwlFp8BPSICGGLb+LGZvqTXrfxN123vPDOscPNHpuuW+qGKI5aSBnCOF/76P4MK5ZS0bPVwNLml6f52/U6ieTWPB/hrTPGH2HWIv7Yhea+uJrJ0j+0eaLiEKx5b5Qy9O1WfHl/pPxB8K2mqGaS11LT5UuLK+t2xJEjspDA9wCVOPVcivPfEnxj+M9x4TsdR8QSeFD4a1O1S7t/Dj20gk+zGaRFxMgB3RGIbnyNpK8E5FeseFPhTqvib4UaV4r8OyxT22oWpc6XcN5UqqSVKq+NodSGB6K2Aw25KjlhW5I2qnfPD1LrER91bLptp+SsZXwuTxX4r+Kl5qfiDXdNsxYF7h782wmjlYxLANsTEAMwR27gYJxiuc+IvhnRNJ1dh8OPiJo3iS4ud1q+iwXMDXIDbmaIQR8sn32XAynPY8egePPhJqOsfAFDHoup6amlL9o1zRIJvs8uteUYk4mUNiLyVdsDPzZJB28/Pmgfs3andeJYrW70zTrQXi3T2DxTgMi+UfIlDKQSFkMeSRn86yVRuXO5WO7C4OpOEqtG3LHe7S/A9v+HOv3GlfAbwVBcmRbmK4hsSkmVYAXDxEEH0H8qxrPTdF/4WJ4nsZtMsbqC4dL+EvlWAlGedpG5N4YHOdpIPrXOabd20Pjfwp4G0u5luLbS5nvrm6kcu0oSR5DI5JJycp17sBXEaz4wvNM+KVnqNtKD5M9xpsqN914iyyID7AS8fSu+lK6uefi8I1OMF8Ury+WtvwX4naeN01a50K41nwHdLBMitDeaFPCk0E+0co0TAjdwcHo2B3Ir5O1G9Oo6jJdtbWtuXOfLtYhFGPoo4FfRV74lnsvGmlaxayGODU7n7JMhPWTAkjP1DcfQ+1eGeO7azs/ib4gtdP2/Zo9RnWML0VfMPA9h0/Cuy3u3PDrKzOeoooqTE9606D/hb37Lk2kLF53ibwjg2uyPLywBTtQbY8/NGrIEU5Z4Yyx5r55r0b4QeLX8HfFvTL5pY47O6cWN4ZXWNBDIwBZmYHaEYK5PGdmMgE1W+MfhB/Bnxf1SwWKKOyu3N/ZCJFjQQyMSFVFJ2hGDoBxnZnABFejiv9ow8K/2o+7L/ANtf3afI+PymP9l5rXy2/wC7q3q0/Jt2qRXpK0klspeTOCrd8Hap4c0XxtY6n4u8K/8ACUaNCX+06P8AbpLL7SCjBR50YLJhircDnbjoawqK8o+wPt628M/s13H7Gt58ev8Ahnzb9mvRaf2L/wAJZfndmdId3n54+/nGztjPevLH/Z31j4mW8PxE8MaP4T+E/hDV2jh0fTvE/iORjcvtCnypJELvvYMwDAdeMjBrp9P8X+E0/wCCTuq+EH8UaMviF9WWRNHN7ELtl+2xNuEO7eRtBOcdATXqOj/FrwL8Rf2bfAel6XqHwUh13w7YR6ffaZ8U7QtHF5cSRl7V8gDd5YOAGyCoJUrg5XaL0Pl3SP2afiZqf7QcnwbvIdN0fxEls94smoTOLaWFRkOkkaOWB7YHUEHBBFamofsmfFCw8DeIvEkd74Xv5PDvmPqekWOpia+to0yd7xBcJlFLhWIcgfdzxX0F4X+Mml6v+334e17xt8Qvh7PBp3hqeym1jR/MsdPSRndhD5tzKfMIyCGBAO/AGQa5T4CeOvCOmeL/ANoq513xholkusxXJsZL3UIohfsz3ZHlFmHmE71+7n7w9afNIVkeC/D/AOCb/EDwqNaj+K3ww8OO07QLp3iPXfsd2SuPmEflt8pzwc84NT6v+zp8RdA+PGifCfWE0y11XWyp0++Nwz2c6NnDiRVLbcqQRtyPTBFe3fB24+Bth+yfZ6hZD4Rn4gxXUjawPiRC1wvkh3x5EQBdzs8raIxgndnmu8+KfxI+HGr/ALUn7P8Ar2k+M/Csmm6eshvp7O8hjgsFKx7VkAciADkBWPGCMnFHM7hZHg3/AAxd8Wn1jXNFttV8HXGsaUhl/sqPVf8AS7uLAxLFEUDBCTtDSbAT04IJ4X4V/APx38WrXWdQ0V9J0jSdGB+36trtybW1gYAkoW2scgAk8YUYyRkZ+m/h58Q/BVr/AMFSfHni3UPHGgQaDdafJFBq8+pQpazfLbBVSYtsb7hAAP8ACfSub+FPjLwF4q/Zu+LHwO1XxxovhLVNW1mfUtO1TVLgQ2lyheJgpl6dbcA9ysgKhsEUczCyPGvGv7NnjzwF8GI/ibrWp+G5tGlvBZwrYXrXMk25mCSoyp5bRsF3Bg+cEZAOQPIIopZ50hhjeSV2CoiDLMTwAAOpr7c+KOk6d4b/AOCUXhrRLHxFb67DDrvlJqNsGWC4f7Rcs/k7wGaMHeAxA3BSwGCK+Y/gT4v8PeAv2i/Cfi7xVbmbSNPvfMuNsfmGMFGVZQvU7GZXwOfl45qou6E0fR3xt+DvwV+CHw+8PJqHwq8U61a6rZ7ZPGEWrSW89rdlchHtWXywT97awXgEclTXyHrfhnxJ4ZktY/Efh/VdHe7hFzbLqFpJbmeI9JE3gblP94cV+h1p4y+H6+MfHcnxC+OngDxh8KPFjG7i0W6v3m1CxlbbtRIVBZEUAAYIIKIwCkHPzB+2Tr0fiT9os6npviPwzrWgJp8NrpD6BqEV2kECZJjkEbHY+9nODjgjGcVMG9htGn+xf8KfAPxZ+JviLSfiBoP9r2dnpYuIIvtU1vsk81VzmJ1J4JGCcVqX/wAIfhb+z/8ABf8Atn44aSnib4g63Fv0nwnHfTQJYJziSd4HVjg/e5wSNq5IZhL+wb4v8J+D/i14ovPFvijRtAt5tIWKKbVb2K1SR/OQ7VaRgCcAnArcvvGPwu/ay+ErRfEDX9A8C/FbQoNttrWoTx2lpqkYPCszEDBJ5XqhJZMqWWh35vIFseEeBPgqfiJ4cbXoPil8LvC5kuXhTSvEGvGzuhjGCIyjEoc4BJJODXY+CPgjr3w6/bX8CeBviZoemX1rf3ccyqQt3Z38BDDI3DDLlSCGAPHTkZ9K+FkXwS8P/sxoYJPg3N8RrK/mTWm8fkX8LRLJIM2qxlvO+QRbfJyrfNk5rs/in8SPhxq/7Un7P+vaT4z8Kyabp6yG+ns7yGOCwUrHtWQByIAOQFY8YIycUczvYEjwz4j/AAN1/wCIP7bPjrwZ8MPDum2Fhp06Sy7FSzsdPi8pOW2jCgknhQSeTjgkcT8Q/wBnjxv8PfAsXjZtU8NeKPDTz/Zn1jwxqH223glzgJIdqkHPGcEZwCckA/Uvg743/DTRP2r/AI26Lq3iHw9/Zvi7yBpus3YF7pczx27IY5yjYeJvN5+YAhXUsCRXIfFr4hz6J+zb4m8Ew+J/2eUstVeIpovw6srh5Ll/NiJkLLII4mVY1bcytnYF64oUnsFkedj9i/4oC/0C2m8SeB7Ya7ai5sZLrVHhErlQwgVWiDPKVOdqKwAByRkZpaf+x18YtQGrWn/FOW2t6ckk3/CPz6on9oXMKMU86KJQf3bMMKzlQ2RjgivaPix8QfBWo/Hr9m690/xtoF3Y6ObY6jPb6lDJFYnfb7vOYNiPhDndj7p9K2vCfxH8Bwf8FVPHXiu78eeHIvD0+gRW9tq0uqQraSt5FllEmLbGO5ZOAeqt6GlzSsFkfn+ysjlHUqwOCCMEGkrR1+SKbxZqksDpJE93KyOhBVgXOCCOorOrUkKKKKACiiigAooooAKKKKAPQf2hP+Tj/Ef/AG7f+ksVFH7Qn/Jx/iP/ALdv/SWKiujMf96q/wCKX5s8Thf/AJE2D/69U/8A0hB+z3/ycf4c/wC3n/0llrz6vQf2e/8Ak4/w5/28/wDpLLXn1VL/AHWH+KX5QFQ/5HOI/wCvVH/0uue2fs421vYa/wCJvHV/BFPZ6BpTyMoUNMrtlt0QPAOyGVSdw+/joTjyjUb+71XV7vVL+Xzru7me4mk2hd7uxZjgAAZJPAGK9e8Ff6H+xV431C0/0e7l1NLeS4i+SR4s2w8tmHJXEkg2njDt6mvGK6sV7mHo0l2cvvdvyR5+RpYjM8fjHupxpryUIpv73Nv7gooorzz6wKKKKAPd/hFDa2nwfvL3Krc6x4ktNFL91XyXkUH2Ylx9a0vEenalZ6ANeJE1jNamOSA/8tIjmMxn3CqvPfb2IBrw7TfEWr2Og3OhWUzi3urmC7Crnck8O4RumOjASOPx9hX0L4P8X23jTTIfDevvbQX2owTWnlrhVW9R2kRQM8ebHcSgD+/Ft7gVlOOlmejg8T7OcZLp+XX8D3T4OwaX8Tfg/wCF7nUdNuEutHElqbiexBiufm2zYLZV1cqrMvVZAx/iO76K0TSYdH0K00ywG23gBxu+8csWJwAByWJ7Yr89PhT8fdW+BHiXVvDGr2EepaKbrz5rCSTypYmYAGaFyCOcAMpBBwD8pya+qtI/at+Buum3g1bXX0K6ws6Qa3aNGEJGVYSJvToeDuHBrw61Gak7bHvYutLlVO/uptrXTf8Ar+me3tc28lw9lFcxm4VN7Rq3zKpOMkdq8v8AH/h/X7TwndW/grTdOtLq4jaF799kMdhCR88gCrudgM7VGBnkkYwaupftIfCLT5FtNC8QJ4l1Gc5j0/w7CbqWVvcgBF9yzDHevnr9pL4x/EW/07SdBt3h0HRtYEouLS0l3z7F25Es3HBBOQgC8Y3NWMablJRHhIVY+9Fe67HCeEpl0DwdqmotcCbU9ZuBp9lNjDeUDxjrgfMCeeuOtea6nffbfHtwSw8qS9dosH74XC5/JB+tSQ6tf3F9E8cnlxW1uy2vykiIsCFfHAwMs3XLEKegrmYbVI5ryWS8mkmtIGliuFwgUqQAMc5BJxj3r3KeqUScRWhTxE610/n9/nt8r31Nvxx4vWfX9NttHYGLSZPOEn8MlwSCzD2Xaqj12k964SWWSed55nZ5HYszMcliTkk1p6Lqctn4hFwIopUmJSaGRAySI3VSDnjv6jGRU2s6VbJANR0nLWudsyBt3kvnp67Txgnvwe1dXM3KzPl5xTjzqWt9v1MOiiimYhXtXxnmfxh8EvAXxFZYjcMj6dfTyRqk082Dz8oxsDwTkDIx5gwBk48Vr2jSP9N/YY8Tfbf9I+w6wn2Tzvn+zZe2z5efuZ82Tpj77f3jXoYL34VqT2cW/nHX/M+T4lSo18DjY/FGrGP/AG7UTg197T+R4XRRUlvbz3d3Fa2sEk88ziOOKJSzOxOAqgckknAAryz6wjoq6NI1YveoNLvS1hk3YEDZtsNtPmcfJg8c454qlQAUUVZutPu7O1sri5i2RXsJuLdtwO9BI8ZPB4+eNxg4PGehFAFaiuhbwJ40iurO3ufCur2jXtxHaW7Xdq9ukkrnCIHcBQSfU1z1FgCu7+G/xV1f4aHUobPw74W8QWGpeUbrTvEmmJfQO0W/YwBIKkeY/QjOec4GOEootcD0z4p/Hbx38XLPTdM8Qtpmn6Lpf/HloujWotbO3ONuQmSSQOBknAJxjJz5nRUrW1wtml20Eot5HaNJip2MyhSyg9CQHUkdtw9RQlbYCKiit+68DeNrGylvL3wdr9tbQqXkmm0+ZERR1LMVwB7mgDAorcu/BnjDT0ga/wDCmuWqzyrBCZ7GVBJI33UXK8sewHJrMl0+/hW5aaxuYxayiC4LxMPJkO7CPx8rHY3B5+U+hosFytRV9ND1uTUbfT49Hv3u7iITwW627mSWMqWDquMsu0E5HGBmqptrlbJLxreUW7u0SzFDsZ1ALKG6EgMpI7bh60ARUVo6h4f17SbSK61TRNRsYJv9VLc2zxJJ/ulgAfwrOoAKKKKACiiigAooooAKKKKACiiigAooooA9B/aE/wCTj/Ef/bt/6SxUUftCf8nH+I/+3b/0liorozH/AHqr/il+bPE4X/5E2D/69U//AEhB+z3/AMnH+HP+3n/0llrz6vQf2e/+Tj/Dn/bz/wCkstefVUv91h/il+UBUP8Akc4j/r1R/wDS657p4g/5MY8Gf9hiT/0O7rxevaPEH/JjHgz/ALDEn/od3Xi9dWY/FT/wR/I4OEv4WK/6/wBb/wBLYUUUV559WFFFaOhWEmpa9b2cUQld3AWM9HbsD7E4z7ZpNpK7KhCU5KEVds3dA0i5jQG2jP26VNzTf8+sZHGPSRh3/hU+p4pz6dJJNdNAG8q027fLJBBDdu+eGP4ivXdOfwrYOmgRavb3GpbsyrHl3llP3ugILZ6KOe1cnotzomkWslv4ginaSWdpDFGyYcMTjc4cbQMDgcnJ5Xv56ryqSeh9tWynDYGhCFSabd+a2tnayjptq/wOOvj4n+I+qx3OvpbzSacqxXGtSny2uI+qLIVH7yQjOCBuPJbgEjWlW01aS4SSGOxurcbIEf5SqYCpGf7wwFAYemeckVc13WLeK1cWsEVqkSFbe3j+4gb7xHqSfmJHf6Ut5YG9sLS2kYqzsWd1OCBGg5H/AAOQflVt2PFw9P3nbWy1v17L77a79e1vcbO18LfBn4LaHrujz211qniSwjuN8kxkdtuRI8i8BFRyyBQQCRjPysR4nrWsXGv+L3M8k2r6i/TGZh/wFFGW+nCjGMACoo9Cur65tIbm+upbaGSONUaQsEBfOB6AkscepPqTXU+DddTwv4X1jU9KYQarqKSTGZYCWEZZgAJeikNk7f4vlAyeKyo0lGTb1Z1YnFVPq0VD3Y3svPv92nq7t9LclJNq94WtItKC4fy2e7Zcbun3RxweOvWsjTkkh1W7s9WtIoFaOSK4jUfKo2khx/ukBh+XeuqtrlHjlQLuKytDGM8ttAySfzyaoeJdNu7pHubgQq0sYIIYKzbPvZGd2CuSeOqit4T5ZrsYPCqrhpSim5pr0s+/byZwtijG5DqPm+6v+8eB+XX8K3tOjuYhM9tGJXRdk0bcrOnKkN9duc9ia2/DHhtTN9rlAfb8qjGFz3wK1/DmkMvjTVrMLxGA2PZtpH8zUVcQrtroell/D8kqarL4216e62vxR5jqdpHa3mbcs1vKN8Rbrj0PuDkH6VSr0bx74UbS4zcRxnyJ2MiYH+rkAyy/RlGfqtec11UaqqR5kfN5nl9TAYiWHqbr8ugV7V8F/wDkj3xZ/wCwN/7Quq8Vr2r4L/8AJHviz/2Bv/aF1Xq5X/vK9Jf+ks+F41/5FE/8VL/07A8Jre8EXEFp8TvDl1dTxwQQ6pbSSSysFVFEqksxPAAAySawaK8s+rPU7Txjol9pGr20pktri+sGbVJZGVRdSxmOOMRc5ZivmOc8lnbjAzU2o/8ACH/2tbf2t/wjX9n/ANuRfYf7L2Z/s/D7/tHlfPj/AFH+s/effryaiq5ieU9RP9if2ppP9sf8Ip/bWy+/48/I+w/6pfsnneV+6z5nmde2zfxmsH4g3Ec//CNxCfSZLiDSTHcrpTRmGOX7XcMVAj+UHDAkLx82RwRXGUUXHY9o1mfT1+Oum68tr4RttP8A+EmguDq1lrSzTSx+fnfJH9pcIuPmJ8tcYHQcHm7M6GPGGky6XZaNdaP9mkEMN3cWsE0b7MM1wbg7GkViGAbKMBhQOQPO6KOYXKetw2VssHim50y48J392l/pqQ3d/a2cNugeC4aSNB/qARtAO07W2FhlttVta1DwMni7w5ptpbaR/wAI68ryX81vAplK/b7jarSYMiqIxHgcMUK5z8teZLc3C2clos8q28jrI8IYhGZQwViOhIDuAe24+pqKjmDlPW72fRW8XaQU8L+Hl2pcgyrrelSRyAoAjMqxxwqUJ3KJVy+SDnHHO+O49Gi0q2Wwv9Lvbw6lctNLZW9vARGba0KqVg+Tar+coK/KWDkdTXDUUOQJFq48/wDs6z8z7L5W1/L8ry/MxuOfM2/NnPTfzjpxWzqNzbP8LPD9olxE1xFf3zyQhwXRWS22kjqAdrYPfafSucopXKPZddmsB8b7DXVtPCNvYHxJDcHVrLWVmmlj87O+SP7S4RSPmJ8tcYHQcGpHdeHvFHhJ7jU9bsrO7v8AVbKPVElmVJGWBLjfcqCed0boPeQH+8K8lop8xPKe0R+KPD+paxD4n07xDNDf6cuoxx/b4Y7J44prWd4I4gJn3COTco5BzKgxVFte8LQL4O143Fr5Muuzanf2EWGeyYpbq+Y+uzfG7qOhXA7GvJaKOYOU7nVtMtbPwjqtxqviEXuqzXCPDLZ6zFcxXoLcl4FUyKQMtudh1AxmuGoopNjQUUUUhhRRRQAUUUUAFFFFABRRRQAUUUUAeg/tCf8AJx/iP/t2/wDSWKij9oT/AJOP8R/9u3/pLFRXRmP+9Vf8UvzZ4nC//Imwf/Xqn/6Qg/Z7/wCTj/Dn/bz/AOkstefV6D+z3/ycf4c/7ef/AEllrz6ql/usP8UvygKh/wAjnEf9eqP/AKXXPc/Dn+m/sM+Jvtv+kfYdZT7J53z/AGbLW2fLz9zPmydMffb+8a8Yr2T9nM/2w3jbwL/qf7a0dv8ATPveTt3Rfc43f8fOeo+5jvkeP3FvcWl5LaXcEkFxC5jlhlUq8bA4KsDyCCCCDXVi/foUavly/NN/o0efkDVDMMwwb351UXpUiunlKMvXeyurx0UUV559YFXLHUbjTvNktG8uaRDGJR95AeDj0JGRn0JqnRSaTVmVCcoPmi7M7rw1aadaeG/tYkKalcq7LNnBjiBKbI88BnIYMx6L06mp5bu1sIYUgsbeS8ljUqgAbaT2JPUAYJ59fSvRvBn7M3xN8XfB238WQf2faYha50ywndlubqIncDwNqBuSu45IOeAQTwmmfDb4meMPHcfhrS/DV7/bEUUh8mZTAkCLwXZ3woUEgdeSwAzmuKc4ubtLY92lX5cPGKp2ffvr18/P8O0E3gnxl4j8PTa7pPhW81O2sDm5n0mxd0QAgsCyrg8dccjvim6TfxXGrW7yXOFWJ9ihTuIZvmxx6AV+h/g/xZY+C/h1oHhO60RNB1KxsxBNpwdWWOaOJZWVXThvNQSMkg6srA8givj79py08NxfFGHX/Dl+Y7y6MgnhhQLHJKjfNcpjGwurQllI5JYjjOeWniPaS5GvQ3pqWHk6yjppf70/0OJu5nsYo3R0QwbZQshUMWK849eg4ycUyzFtL4WjjmgUGK1Uo4lcjcyhd2NxUH1OPasiw1ZZ5Ul1AbPLVgY0woIIONoJAHOP1qB7iZdNgAdZfJXlFIPXliMe9dKpvuFTMKTTjGF1ra9nukuq0tbp289F8NXBa2jabmVp5IyPQLkn8z/Suv1aLRrnSNI1JbrTo2twf7Ss7y4HmTukpyUTl2DxleAAAQa880K43a/IFbMeXnX/AIEAM12Wm6mPtEwjiSePKxSIysdxzxtKfMGB7jPUgg1UtNTHBNztSvu7fJ6dWl6XZxUWv6p4c8USi0vLie3hmKrDclgJEzxlTypIwfUV2Nx43s9Ev9W1vTUS4ur+O2S2jk6IBHuZmx6EgY7n6VynjC3Se5k1RDEsizfZZY4iSoAX93gkA5CjacgHK5xzgcrWk8PCraRFHOMZl/NRUtU9L62dnF236P77M9OsPiFL4osbjw/4mitxJcD/AEW7iTYElHKBh0wTxkdM88dPNZ4zFcPGQVKsRg9RUYJByDg06SR5ZTJIxZ2OST1J9aunRVNvl2ZyY7Mq2OhF4h8046X6tdn6P8xte0eFv9D/AGKfHF/Z/wCj3cupR28lxF8kjxbrYeWWHJXEkg29MO3qa8Xr2r4rwXHhT9mn4feC7uCQ3Fw8mpSvKpieBgCxhaM5OQbvBJI/1fTnj1sD7satV7KLXzlovzPgeJ2q1TBYJfFOrF2/u07zl6/Cl8762seE0UUV5Z9YFFXodPTylkvLgwhhlURN7kHoSMgAH656HGDmpPsWm/8AP9df+Ay//HKrlYrozaK0vsWm/wDP9df+Ay//AByj7Fpv/P8AXX/gMv8A8co5WF0ZtFaX2LTf+f66/wDAZf8A45R9i03/AJ/rr/wGX/45RysLozaK0vsWm/8AP9df+Ay//HKPsWm/8/11/wCAy/8AxyjlYXRm0VpfYtN/5/rr/wABl/8AjlH2LTf+f66/8Bl/+OUcrC6M2itL7Fpv/P8AXX/gMv8A8co+xab/AM/11/4DL/8AHKOVhdGbRWl9i03/AJ/rr/wGX/45R9i03/n+uv8AwGX/AOOUcrC6M2itL7Fpv/P9df8AgMv/AMco+xab/wA/11/4DL/8co5WF0ZtFaX2LTf+f66/8Bl/+OUfYtN/5/rr/wABl/8AjlHKwujNorS+xab/AM/11/4DL/8AHKPsWm/8/wBdf+Ay/wDxyjlYXRm0VpfYtN/5/rr/AMBl/wDjlH2LTf8An+uv/AZf/jlHKwujNorS+xab/wA/11/4DL/8co+xab/z/XX/AIDL/wDHKOVhdGbRWl9i03/n+uv/AAGX/wCOUfYtN/5/rr/wGX/45RysLozaK0jYWLDEeoShuxmg2r+JVmP6GqE0MkEzRSrtdeo6/Qg9x3z3pNNAmMooopDPQf2hP+Tj/Ef/AG7f+ksVFH7Qn/Jx/iP/ALdv/SWKiujMf96q/wCKX5s8Thf/AJE2D/69U/8A0hB+z3/ycf4c/wC3n/0llrz6vQf2e/8Ak4/w5/28/wDpLLXn1VL/AHWH+KX5QFQ/5HOI/wCvVH/0uudL8PvFX/CFfEzR/EzQ+dFaTfvkC7mMTqUk2jI+bYzbcnGcZ4rt/j54Tl8N/GC9vYrby7DV/wDTYHXeylz/AK4Fm43eZuYqCQA6dMgDyOvoXRF/4W9+y5No4i87xL4Q2/ZtkeXlgCnYg2x/xRqyBFOWeGNmPNdWC/f0Z4br8UfVbr5r8jy89l/ZmYYfN/sP91U8oyd4S7WjPR+UjwaiiivPPsAr3H9mX4JP8W/iV9r1iCQeFtHZZtQflRcMeUtlPq+CWI6IG7kV5N4Z8Ma14u8Xab4b0Kye51DUZhDbx4wGJPJJ7KACSegAJPSv1S+FvgbRPhb8L9O8H6MVkW3UyXN1twbu4bHmSn6kAAdlVR2rjxmI9jCy3Z14TDutLyR2EVpbafD5hKxxQpkKnyqiqOgA4wAOB2xXA/D22W9n1zxLbx5S8v3toCP4YoScgen7x5c+6+1Zfx2+Kun/AA6+FGpX7yq99NGYbW3z80srcIgHXk/oGPau5+Hmgv4T+FHh7w7cuZLqzsIluZD1knYb5mP1kZzXgpe62fRObpxs93+S/wCD+Q/V/DXhnUY7e78TWNpJcjFtFNuZGBc4VVIIOcn5T1BJIxk1Q1L4SfDrWfBc/hfUvC1ld6dMdzecC0wYZ2uJifMDLkgENwOOnFYHxd10WcvhjT4rgR3E2qCZBnBPlxSMMfln8K6vw34nh1jTVlJCXCYEsfofUexpJuOqHOhUlSU+j6Hwr8av2ddf+Et0+uaFajX/AAm78XDRA3NkT0SYDqOwkUYJ4IUkZ8fh1q1vdKuLOPEDSBZIGCjAlXlRkdmBK/iK/UrxtHZ6r8NPEFjdhWhl024Vt3Qfu2IP4EA/hX5i+KPD1la+JN3nLAl6sckT4wIJXB+Vx2UsCD3UkHua9GjiHUXLMeDwUknWpvZ8rT2akmvl2v0bW25xsF4bfVJrlU8t54tu0cbTnJOOx5zXR6ddiw0Q3IPJbeo9T0X+Wa5q8t7hdYWC+iEN2sjrIP7pP9OeK3DA08kcJIS3jGAByTXoKzR4d5UaritGnbs/+AWXEWuJcxXkv76/ZXjlJwEmAbaW9mLbfbOe1cTJG8UzRSIyOhKsrDBBHUGvQYtZ0y38OX2ltbeeqLuQJjCk5zlup5AOB3zXP65bi/8AFEhkZknaOPzvKjL7pvLXfwPfOT65q6MmotNbHXm9GNSVPEQld1Fd9LO9nv3epzlFWZbG4gtlmlVVDNtClhu/756iq3Q4rZNPY8OUJR+JWOt+GnhOXxn8UNJ0X7N59oZhNeg7wot0IaTcycrkfIDx8zKMjOa0fjx4q/4Sn416lsh8uDSv+JVFlcM3lO29m5IP7xpMEY+XbkA5rvfBi/8ACpf2c9T+IlxF5Wv67i00rfH80SnOxhujOM4ebByjrHF0Jr54r0sT/s+GjR+1P3n6fZX5s+Ny2X9qZxWx/wDy6oJ0oecnZ1JL0so362fYKuaXGkmqJ5ih1RXl2sMhiiFgCO4JHPtVOr2kf8hM/wDXCb/0U1eXHc+vew9mZ3Z3YszHJYnJJ9aSirWmadd6xrdnpOnxGa7vJ0t4Ix1d3YKo/EkVqIq0V7F4/wDhXaaX4m8NwWum3vhbTL27fRp7zWYpYleWFwDefvcYSVHRwMhQQ4BAHGddfDCxtUktX1G5sYn1PTbQahrlgLNkS4W73OhS5kiaL/Rx8xJyRgMgVt4B5dRXq0Hw/wDCGlzeK7fxFd+J4YrLQ4b+1uptHiSRWa+ghMkca3hSVcPsB34O9zwY1DUNf+Flv4f8CvrF14u0r+1I7WC7fSzdWm9lmCEIircGYyBZAxDQqMKxDHjIFzziiu98bfD7TPC8Wuf2X4ml1aXQ9ZGjX6yWH2YCRvOKNGfMbcP9HkDZC4OMbgc1d0HwhoOufApriK1ZfFUuo3rWc4lbE8Vtb20j22zO3cVmldSBuJjC87hQFzzWivaLz4Oadq/jrxPYaVfyaMlvrF3YaXb3H2f7PMIuQgkmulmdhkAhIpCMqSTnA5bS/h3pl7olu954nktdWudGvNcgsUsDJGYYI5nCNL5gw7+Q3G0gKc5J+UgrnAUV6Fq3wxGn/DA+K4dXk+0wQ2093pl4ltFLGk20KypHcyS7cuuDJFHkMD7Vq/Cj4Znxj4e1G+uPDeqaqt3ONHsZ7OKVksbh42f7TKU4CI3kqQ/y7ZWP8OQDueUUV1XivQ7TR/CnhGeOza3vb2wuJb7czZaVL64hGQThSFjRcDHT1ya6bU/AbN4H0ax0LwzBd6u9tHcaldLet9ospJN0iCdC3lJA0BjYNgYJIZwQVoA8vorvfhbovhjWb/xCviuDdZ2+k745/NdPsksl3bwCf5SN2wTM205BxyK6e9+F2lRaT4T8KyRfYfE91r0ek6tf7mlETzKjqgj3BT5ayJnGCW3AnpgFc8bor0HwP4XtZbG21+98m6ivLTxDbi0mgDLG9rpXnJKCScndOpHA2mMEHJ40/EfgrwlG+pp4aurh5bXwxpupSxaha+Skck/9njfHKLkjc5unZt67EyyqD8roDPK6K9X8I+EtB0zwv4nu/FyeD57qyurCGC41HULq7s0WZblmUPpbsWc+UnUkDac4J5NO8I+DLjwne6xr0sllHJ4cOq276RZyT+S39tG03bZrld52AIAdo2Pkjem6QFc8oorr73wN9jbXANU3jS9Dsdaz5GPN+0m0/dfe+Xb9s+9zny+g3cVvHnhrSvCHjbUPDWna5Pq02nXU1pdTPZi2QPG5X5P3jFunOQMHIG4ckGczRRRQAUUUUAFPuVEuieY33oJlRT/suGJB9gVyP95vWmVJL/yL8/8A18Rf+gyUnsBl0UUVkUeg/tCf8nH+I/8At2/9JYqKP2hP+Tj/ABH/ANu3/pLFRXRmP+9Vf8UvzZ4nC/8AyJsH/wBeqf8A6Qg/Z7/5OP8ADn/bz/6Sy159XoP7Pf8Aycf4c/7ef/SWWvPqqX+6w/xS/KAqH/I5xH/Xqj/6XXCuo+Hvi/VfA/xBsde0mBruRSYpbMOyi6jbgxnb17EZBAZVODjFcvXoPwk8Zz+DPFs11bWFjePcRCJ4rmFXMkecsisfu5wPXOMHI4rCFSVKSnF2a1PXr4SnjKcsNWjzRmmmu6eljovjL4CsdIvY/G/hQ2h8MatIFjhgBjNpOU3NGY25UHa7YwNh3IVXC5890PTY7zUFkvWWGyiy8ssobYQP4cgdScD8e1e4eMdOll8H3/jT4f3Fx/wi1y27UNJhGx9JkBB2PFyPLDYKuPu8Z4ANeYWtpdarNstWvb5Qd5WLBPTk4HT3OKrE4qNSbnGPLf7r+XkGT5VWwlCOGq1XUcdE2veaWyl3a2b67tXudKfEd1pmtaRN4dvLqwOngT208FwdsZXGVTBAGRkEHqCc7s4r658Q/tLeCNJ+FMXjRbtglxuSOzIBn84fehCZ5YZGT90Agk4Iz8K/PprPaR2zEPjg85PofxwcD+lcV4kvIrvUUtoZRcPCSrThsrITjgew6Z7/AExXl1sPGok29j6N4905OXKrvysl0Vl6f139y8GeJ/En7Q/7YHhFvE4dNHi1D7YlnuzFHDD+9YZP32bYFJ75wABgV+ks+piKF5ZnCAZZye3c1+XcyadpHhldOks2S7tZTHF5JLxhQxORIp55JPTPU57V6NB+0B8QbD4VJ4PWGC6EFq0Sa1JLI8yJyyyP1BKqQBk/wrnOKwrYdzso9DoppQfNVlzNpNta28ttHp6HunjHW7bxV4k1DXtQuRb6TpyNFZ3JIHklDmS4U9tpUKD32v2bmP4c/EGDxLoMeu6TMIrmFzDcw4wUceq/3WGGHscdQa+Kk8Zarc+GYNAu9TuzZwZMcMs7vDnOeU7HPPpnsKteC/HOq+C/E8mq6dqRjMyGOZCnmxyr2DoSMgHBBBBB9iRTll8uV9zup5xhrQino9/L1Pub4rfFK1sPhNf6duEGqaohs7dScqc43t1ztC5z/vAZya+NvEGqWusPqDagrSXZxGJWkyGO9mchu/O0DdzycYrI8SeKtc8U3z6ne3st9Mw2ic4AjX+6iLwg9sD15Nc6Z7jyPKbhQMZPHFb4bDSpqzZx5lisK+VUVeServpbt287/Imv5JdREeo3Pz3EJEU/OC64xuJ9eQfxNQ/abhiLWylmfcdpEg27PYk9/YUkN7bwWt4jfvHkjCoB03Z6n2Az+OK2/h9BoGv/ABH0rSvGXiE6HpU822bUhGreTwcE54AJwCx6dTxXVy8kb9jzcViI4mpGd/ee/re2r81YoJZ3tkiRvHA5klDDaWOCvIGcd6v22natZ3RuogszHlzz84POeffmvs3TvDH7LfgXXx4Q1uCxuvELBHgl8VTPLDdRv9ySKYAwAMOhwMHIPSvHfj/8KPCHhTwy/iHwLBLpl1a3IW/s453Hkq/QGNmYpzgqVYoynKk8gckMSpSUdrnWqcXF+1jzcq6OzS1b6a/M8pSW2vJFjvYTFMOUzgHPsw/xpvhrwjompfEjTrbxBqkNlphma5u5rxyqzRqdxj3DGwkAgsSMAlu2KyvDcHiHXbe/kjgNxZ2EHnXF3MQot+yfOepYjAXknnHAJFu/uN0aXpdSoKpGOzndyfcYBH4mu6nzUpxlON/yaPGxipYujVoYWq1dNdOaEmtPK+qa8uhW+LPjxPHHjYf2bFFbaDpaGx0u3g3LH5KnAkCEAKXAXgKMKqKc7cngqknEYupBFnyw5C59M8VHW1atKtN1J7s8zAYGlgMPDC0FaMVZf5vze7fVhV7SP+Qmf+uE3/opqo0+GWSC4jnibbJGwdTjOCDkVmnZnWy7V3SNX1DQtZg1bSrj7PeQEmKXYrFCQRkBgRnBOD1BwRggGq8Ygu13wSwwv/FDLJs2+6s3BHtnP1xkv+xyf897P/wLi/8Aiq1JLumeJNW0ixexs5bd7V7mK8a3urWK5jaWMOqMUlVgcCRwRjBzyDgY1Lr4ieK70JHc3WnvbRywypZf2Zai1VofO8sCAR+WFBuZyV24YuSQTgjnvscn/Pez/wDAuL/4qj7HJ/z3s/8AwLi/+KoFodCPiL4rGs/2l9qsNwtDYfZf7MtfsnkGTzPL+zeX5O3zPnxs+9z15qte+NPEGpeHE0TUJbC6t0jSFJptOtnukjQjYi3Jj85VAAAAfG35enFY/wBjk/572f8A4Fxf/FUfY5P+e9n/AOBcX/xVAaF/UfFGu6sdXOoX3nf2xfrqd9+6RfOuF83D8Abf9fLwuB83TgYSx8Ta7pltpsFhqDwJpt82pWmxVzFcMIwXBxk8Qx8HI+Xpyc0fscn/AD3s/wDwLi/+Ko+xyf8APez/APAuL/4qgNDrIPix49ttRub+LWoTdXF5LftO9hbu6TS48xo2aMmMPgBlTapAwRV7RPig+ifDefw5Fp1zcXslnc6fHd3E8LRwQThg6Iog84DDudvnFNx3bc1wv2OT/nvZ/wDgXF/8VR9jk/572f8A4Fxf/FUBob978QfFuoeGZdAu9ShexmhhgmC2cCSTpEV8oSSqgdyuxQCzEgDGcEisebWdTuNK0/TZLo/ZdPMjWsaKF8tnYMzZABJJA5OTgAdAKg+xyf8APez/APAuL/4qj7HJ/wA97P8A8C4v/iqA0NHxD4q17xXdxXOvXq3UsXm7GEMcWPMmeZ+EUA5kldv+BemBWtbfE/xtZ2EdpBqsG1LcWZkewt3lktwu0QSStGXki2gDy3JXAAxwK5j7HJ/z3s//AALi/wDiqPscn/Pez/8AAuL/AOKoDQlsdWv9OtdQt7KfyotQt/sl0uxT5kXmJLt5HHzxIcjB4x0JFT2XiPW9OsrS0sb97eK0vRqNv5aqGjuAFAkDYzkbV4zjiqf2OT/nvZ/+BcX/AMVR9jk/572f/gXF/wDFUBdHRXvxG8X35t/P1G3RbdLtIY7axt4I4xdwiG4wkcYX50GDxwcsMMSarXPjfxJd6L/ZU95btbmxXTXZbOBZZLdXidI3lCB3Cm3h27mJULgYBION9jk/572f/gXF/wDFUfY5P+e9n/4Fxf8AxVAaEsOrahb6Bd6LDcbbG8miuJ4dine8QcRnOMjAlk4Bwd3OcDGnpvjbxJpX2VbW8t2jtrJtOjgubOC4iNu07XBjeORGWQeaxf5gSDjHQYx/scn/AD3s/wDwLi/+Ko+xyf8APez/APAuL/4qgNDdn8f+LLnwtL4em1GJrCa1ispVFpCJJYYnR40eUJvYIY025Y7QNowCQcbVtUv9c1++1rVJ/Pvr64kurmbaq+ZI7FmbCgAZJJwABUf2OT/nvZ/+BcX/AMVR9jk/572f/gXF/wDFUBoV6KsfY5P+e9n/AOBcX/xVH2OT/nvZ/wDgXF/8VQFyvRVj7HJ/z3s//AuL/wCKo+xyf897P/wLi/8AiqAuV6kl/wCRfn/6+Iv/AEGSpDa7Bulu7NEHVhOr4/BCSfwFUby6WYJDCCIIySu77zE4yx9M4HHQYHXklSdkPcq0UUVkUeg/tCf8nH+I/wDt2/8ASWKij9oT/k4/xH/27f8ApLFRXRmP+9Vf8UvzZ4nC/wDyJsH/ANeqf/pCD9nv/k4/w5/28/8ApLLXn1eg/s9/8nH+HP8At5/9JZa8+qpf7rD/ABS/KAqH/I5xH/Xqj/6XXClVmRw6MVZTkEdQaSiuU9w77w58StW0zV4LkTi2mACSTR5CzjoPNXOD9cdzkHJruU0+y8SvKPDGqJ4flmYySWdtCPLaQnIPysCEz0AyB2A6V4RWlpuvappLq1lcumw5Xn7p9vSpcI2tY7aWNqRqOcpO73a0b+Z13i658T+GdNv7PXLu7E0q+Sjs+5ZmbjcrY5woPPUcA4rjdA0Dbt1G/QZA8yGB0Dhsd5FJHy9OMc55wOvsemjxF408K2PiSSCw1GeDzUjtYjulh243SiJuGkOOqksFAwBnNcvqF3aTxMywvNLu3+WqPuc/TGc/rWHLbpY7a01XlzyqOSW3M9fz/Iy7eCa6iZ/NliB+6sRZQ59dp6Dn2qzqMl7beHL23lv5UmdFL2UWQiJuAzJnHzHIwoBwDyR0rp9F0rxI0F7dWthLpchRRHd3cRQxQ9XcKRkbQAAcADJOR1rG8RReD9O8M3UdrrNxqmrz4XLncB84JYleM4HcmqUJXTktC1UpxpSdOS5mtdbWWq73bfRW0T67nn9FFFdZ4QqsynKkg+o4pWd3PzMW+pzTaKACt6z8L3Mlgt9qFzFp8MiF4UkBaafjjZGOcH1OB71n6XNaWt4Lu7jEoi5SIjIZu2fYda7vQ/DHjr4halHc6V4WeSC4/wCYjeBktggfYTvOFbaSchdzcHg4NJU6tWXJSjdm0sRgMFQeJx9VQj0u7L5v8luzjGsdSuxEl3eLiFBFGs8+diAk7QOcDJJx7mtGWxS53i81C6ugkSw2+9ndo1ByAOMFeTgcAZr1c+EPhH8KJEu/iFrC+IdfTa/9iaeu6OJv3bYMeRnGSQZWVXQn5CRXlnjr4na141nit0tbXRdIt1MdvpmnL5cYTdlfMIxvYAIOgUbcqq5OerEYL2Ef3s0pfyrV/PsfPZXxGsxrf7HQlKj1qS92L/wJpuXrZLzNR9dnstBGjWbz2+jiRpFtpZFiR2OBvkxjzGwoBJHbAAFcrqmsxl38iUTTEbQ6giOIf7OeSfftXPEknJOaK4GnJ3kz6ONWnTVqMLdfn1eiSu++r8woooqjnCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD0H9oT/k4/xH/27f8ApLFRR+0J/wAnH+I/+3b/ANJYqK6Mx/3qr/il+bPE4X/5E2D/AOvVP/0hB+z3/wAnH+HP+3n/ANJZa8+r0H9nv/k4/wAOf9vP/pLLXn1VL/dYf4pflAVD/kc4j/r1R/8AS64UUUVynuBRRRQBpaRr+s6DOZtI1K4tGPXy24b6joa6x/jR8RnsWtW8RS4ZdpcIofH+8BkVwNFA02juvCfxd8b+D9am1Cw1GO7E/wDr7e+j82OTAbHTDLy2flZckDOQMV3k3xn+G3jCUN8RfhdG1wUSSXUdLlHnTzKoTnmNwmM4BkbGFGDjI8Jorto5hXpQ9mnePZpNfifP5hwzl+Or/Wpwcau3PCUoS++LV/nfp2R7p/ZH7Mt6Ptv/AAmfiTTfP/e/YvJdvs27ny8/Z3ztzjO5un3j1p3/AApf4ff9F38NflB/8kV4TRWv16lL+JQj8rr8mcf+r2Npf7tmNVd+ZU5+lrwuvPe/U92/4Uv8Pv8Aou/hr8oP/kim/wDCLfs4WZ+x3/xK1ue7h/dzy2sLGJ3XhmTFuw2kgkYZhjHJ614XRR9epR+ChH5uT/UP9X8fU0xGY1Gv7qpw++0Hc92g+K/wb8KXkV34L+FMt1cFxI8urTgPAyHKNEWMxBySSRt6L14xyfir48fEjxT5Sf2x/YsEeD5WjF7bcw3fMX3Fzw2Nu7bwDjIzXmtFRUzLETjyJ8se0UkvwNsNwlllGqq9SDq1P5qknN/+TNpdtEgooorgPpQooooAKKKKACtfwqtk/jjSE1GFZbVryJZEYgKQWA+bIIK+o7jI4zmsiihAz1/RNNFn4o1RLeC+02CLXLL/AEOXYVkBmfDD92CFxyoBxg9Wqta+HNFtfirY+fayanbX/wBqb7TIyG3eXa58sIVPKn5cMQd2DgYwfKaK05/Ijk8z0DR/BGmalCslxDqts0l29vLGZEzpqqoIefKDOT7J9c1dvtBtNQ+Fej3PmzXdxZWc5itbVgrOvntmU5Byi45AGeR0HNeZUUuZdh8r7nY6f4LdINVTVbG/utSsJI4/7K0+VPNIcZ35CvlQMdAevarNp4L0u48LpqDz3il7Oa5e73r5FtIhIEDjbksceoPPANcLRSuuwWfc9Gl8HeFbXRprqf8AtiSS20+0vZNlxGquZiFKqDGcAE5yc1XvvCunaPrh0GUmYXmrLbxSuB5ghQAtg44LNIq59UNcDUjXE7JEjTyFYRiMFjhBnPy+nJJ47mnzLsHK+56Zd6Rp1x4MlupdKhgiEEcizxxRxpGWgkk+Vwu9irokZDs2ST0JGM+78F6AukSeRc38N3DptrqEk00iNF+9YBl2hAQBnOd1cle+INW1C0a3u7iN1cgyOII1klI6b3Chn/4ETWZQ5LsJRZ6NrHgXw5pN5YCS+1JreW+jtpJhG+ySNh/rEkMQQEH+EM+R3pdR+HukaXpF5c3WqTCSyUQXA3LhLh2jMfblNkhJ75U8ivOKKOZdh8r7nr9x4S06z8KT6EGvbKzn1q3iN/eOrJMuw/vI8KAFOcdT2561iDwHpDarp8EsuoWLXH2nNhcOhuJPKGUKHaAN/bI+ma87oocl2Eovuesa14atL630i2mtNSiez0XzYtL3r9qlbzT8mdnUZJPyZx2qlY/DzRbnXdSsFub+drfyvKCkoiFk3MssyxSKrKeOQP6V5pRRzLsHK+56BZfD+C68C3WsSmWKaGzmu0ljn82J/LJ+UgRBVyB/z0J74x01bbw9p+ieBNcmih1C4gn022kkvt6+TNudWZI/l4I6ck+4HfyqijmXYbi31PSh8PvD6araWs+sTKuoSPPYsHX95aiMMucKTvZm2jA/hbAPAqtJ4M0C11TUBcvqzW9rpRvzAVaCQOHC7d0sK7l/2gg/SvPqKOZdg5X3PTn8MaHYaB4mtLfTLzUZkisrqAh0M8cbqWO0iM4CnO4gYIx93GTQuPAVnHoV1q0ZvmtE022uoZ9ylHlkYB1zt5AyeByOM1wFFHMuwcr7nozeCfDUvjnVNBtp9RT+zoi22WYPJdN8vCBISVAyc4VyeOBzXH+JdLttG8TXGn2ctxJDHtKm5heGQZUHDK6qeM9cDPXvWTRSbT6Ak11CiiipKCiiigAooooA9B/aE/5OP8R/9u3/AKSxUUftCf8AJx/iP/t2/wDSWKiujMf96q/4pfmzxOF/+RNg/wDr1T/9IRyngPxNJ4O+JWi+JVeVUsrpXnESK7tCfllVQ3GWjZwOR16jrW78UvCVv4O+I1zZaZJFNo94i6hpc0UgdHtpclNrbmJCkMgYnLbd3QiuArvPBvivRJ9Ot/BXxCW6n8Ned5lte2x/0nSJGI3vESGzE/8AHHgj+NRuHzFCcZwdCemt0+z638npr5LoVj6FXD4lZhQTlaPLOK3lG9013cG3ZdVKVtbJ8fRXp03wU1nVZRP8O9c0fxpYFEkaSyuo4J7cMoK+fDI4MZJ3gDJPyHIU8VH/AMKA+Ln/AEKX/k/a/wDxytP7PxPSm36K6+9aGa4oyi3v4qEX2lJRkvWMrSXo0jzWivSv+FAfFz/oUv8Ayftf/jlH/CgPi5/0KX/k/a//AByj+z8V/wA+pf8AgL/yD/WjJv8AoMpf+DIf5nmtFelf8KA+Ln/Qpf8Ak/a//HKP+FAfFz/oUv8Ayftf/jlH9n4r/n1L/wABf+Qf60ZN/wBBlL/wZD/M81or0r/hQHxc/wChS/8AJ+1/+OUf8KA+Ln/Qpf8Ak/a//HKP7PxX/PqX/gL/AMg/1oyb/oMpf+DIf5nmtFelf8KA+Ln/AEKX/k/a/wDxyj/hQHxc/wChS/8AJ+1/+OUf2fiv+fUv/AX/AJB/rRk3/QZS/wDBkP8AM81or0r/AIUB8XP+hS/8n7X/AOOUf8KA+Ln/AEKX/k/a/wDxyj+z8V/z6l/4C/8AIP8AWjJv+gyl/wCDIf5nmtFelf8ACgPi5/0KX/k/a/8Axyj/AIUB8XP+hS/8n7X/AOOUf2fiv+fUv/AX/kH+tGTf9BlL/wAGQ/zPNaK9K/4UB8XP+hS/8n7X/wCOUf8ACgPi5/0KX/k/a/8Axyj+z8V/z6l/4C/8g/1oyb/oMpf+DIf5nmtFelf8KA+Ln/Qpf+T9r/8AHKP+FAfFz/oUv/J+1/8AjlH9n4r/AJ9S/wDAX/kH+tGTf9BlL/wZD/M81or0r/hQHxc/6FL/AMn7X/45R/woD4uf9Cl/5P2v/wAco/s/Ff8APqX/AIC/8g/1oyb/AKDKX/gyH+Z5rRXpX/CgPi5/0KX/AJP2v/xyj/hQHxc/6FL/AMn7X/45R/Z+K/59S/8AAX/kH+tGTf8AQZS/8GQ/zPNaK9K/4UB8XP8AoUv/ACftf/jlH/CgPi5/0KX/AJP2v/xyj+z8V/z6l/4C/wDIP9aMm/6DKX/gyH+Z5rRXpX/CgPi5/wBCl/5P2v8A8co/4UB8XP8AoUv/ACftf/jlH9n4r/n1L/wF/wCQf60ZN/0GUv8AwZD/ADPNaK9K/wCFAfFz/oUv/J+1/wDjlH/CgPi5/wBCl/5P2v8A8co/s/Ff8+pf+Av/ACD/AFoyb/oMpf8AgyH+Z5rRXpX/AAoD4uf9Cl/5P2v/AMco/wCFAfFz/oUv/J+1/wDjlH9n4r/n1L/wF/5B/rRk3/QZS/8ABkP8zzWivSv+FAfFz/oUv/J+1/8AjlH/AAoD4uf9Cl/5P2v/AMco/s/Ff8+pf+Av/IP9aMm/6DKX/gyH+Z5rRXpX/CgPi5/0KX/k/a//AByj/hQHxc/6FL/yftf/AI5R/Z+K/wCfUv8AwF/5B/rRk3/QZS/8GQ/zPNaK9K/4UB8XP+hS/wDJ+1/+OUf8KA+Ln/Qpf+T9r/8AHKP7PxX/AD6l/wCAv/IP9aMm/wCgyl/4Mh/mea0V6V/woD4uf9Cl/wCT9r/8co/4UB8XP+hS/wDJ+1/+OUf2fiv+fUv/AAF/5B/rRk3/AEGUv/BkP8zzWivSv+FAfFz/AKFL/wAn7X/45R/woD4uf9Cl/wCT9r/8co/s/Ff8+pf+Av8AyD/WjJv+gyl/4Mh/mea0V6V/woD4uf8AQpf+T9r/APHKP+FAfFz/AKFL/wAn7X/45R/Z+K/59S/8Bf8AkH+tGTf9BlL/AMGQ/wAzzWivSv8AhQHxc/6FL/yftf8A45R/woD4uf8AQpf+T9r/APHKP7PxX/PqX/gL/wAg/wBaMm/6DKX/AIMh/mea0V6V/wAKA+Ln/Qpf+T9r/wDHKP8AhQHxc/6FL/yftf8A45R/Z+K/59S/8Bf+Qf60ZN/0GUv/AAZD/M81or0r/hQHxc/6FL/yftf/AI5R/wAKA+Ln/Qpf+T9r/wDHKP7PxX/PqX/gL/yD/WjJv+gyl/4Mh/mea0V6V/woD4uf9Cl/5P2v/wAco/4UB8XP+hS/8n7X/wCOUf2fiv8An1L/AMBf+Qf60ZN/0GUv/BkP8zzWuz+FvhK38Y/Ea2stTkih0ezRtQ1SaWQIiW0WC+5tykBiVQsDld27oDW3D8FNZ0qUz/ETXNH8F2AR5FkvbqOee4CqS3kQxuTIQdgIyD84wGPFYPjLxXokGnXHgr4erdQeGvO8y5vbk/6Tq8ik7HlIC4iT+CPAH8bDcflqOHeHaqYhWS+y935W3S7t9NjGvmscyhLC5XPmlJfxI6wgnpdS+GUl0im3f4rK7MXx54mk8Y/ErWvErPKyXt0zwCVFR1hHyxKwXjKxqgPJ6dT1ornaK4Kk3Uk5y3ep7+Gw8MNRhQpK0YpJLySsgoooqDYKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA//9k=",
	"marah": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwMDAgQDAwMEBAQFBgoGBgUFBgwICQcKDgwPDg4MDQ0PERYTDxAVEQ0NExoTFRcYGRkZDxIbHRsYHRYYGRj/2wBDAQQEBAYFBgsGBgsYEA0QGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBj/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4Poors7S0XwQlrqep2ST65KontbO4U+XapniSQcZc4O1c/L1POANpStotzrwOBeKblJ8tOPxS3ST8urfRdfJJtZemeCvFWrwefY6LcNFtV1eXESuGGQVLkbh9M9vUVd/4Vn43/wCgJ/5Mw/8AxdSWLat488YWun6rq8peXftkZdyx4Qk7UBAGdgzjHrXX/wDCm/8AqY//ACT/APtlc1Wt7N2nJJ+jf6n2OUcL082pSrZfhKtWEW483taVO7ST+FwlbRr7Ul5nGf8ACs/G/wD0BP8AyZh/+Lo/4Vn43/6An/kzD/8AF12f/Cm/+pj/APJP/wC2Uf8ACm/+pj/8k/8A7ZWf1uH/AD8X/gL/AMz1f+IfYv8A6FtX/wAKaP8A8rOM/wCFZ+N/+gJ/5Mw//F0f8Kz8b/8AQE/8mYf/AIuuz/4U3/1Mf/kn/wDbKP8AhTf/AFMf/kn/APbKPrcP+fi/8Bf+Yf8AEPsX/wBC2r/4U0f/AJWcZ/wrPxv/ANAT/wAmYf8A4uj/AIVn43/6An/kzD/8XXZ/8Kb/AOpj/wDJP/7ZR/wpv/qY/wDyT/8AtlH1uH/Pxf8AgL/zD/iH2L/6FtX/AMKaP/ys4z/hWfjf/oCf+TMP/wAXR/wrPxv/ANAT/wAmYf8A4uuz/wCFN/8AUx/+Sf8A9so/4U3/ANTH/wCSf/2yj63D/n4v/AX/AJh/xD7F/wDQtq/+FNH/AOVnGf8ACs/G/wD0BP8AyZh/+Lo/4Vn43/6An/kzD/8AF12f/Cm/+pj/APJP/wC2Uf8ACm/+pj/8k/8A7ZR9bh/z8X/gL/zD/iH2L/6FtX/wpo//ACs4z/hWfjf/AKAn/kzD/wDF0f8ACs/G/wD0BP8AyZh/+Lrs/wDhTf8A1Mf/AJJ//bKP+FN/9TH/AOSf/wBso+tw/wCfi/8AAX/mH/EPsX/0Lav/AIU0f/lZxn/Cs/G//QE/8mYf/i6P+FZ+N/8AoCf+TMP/AMXXZ/8ACm/+pj/8k/8A7ZR/wpv/AKmP/wAk/wD7ZR9bh/z8X/gL/wAw/wCIfYv/AKFtX/wpo/8Ays4z/hWfjf8A6An/AJMw/wDxdH/Cs/G//QE/8mYf/i67P/hTf/Ux/wDkn/8AbKP+FN/9TH/5J/8A2yj63D/n4v8AwF/5h/xD7F/9C2r/AOFNH/5WcZ/wrPxv/wBAT/yZh/8Ai6P+FZ+N/wDoCf8AkzD/APF12f8Awpv/AKmP/wAk/wD7ZR/wpv8A6mP/AMk//tlH1uH/AD8X/gL/AMw/4h9i/wDoW1f/AApo/wDys4z/AIVn43/6An/kzD/8XR/wrPxv/wBAT/yZh/8Ai67P/hTf/Ux/+Sf/ANso/wCFN/8AUx/+Sf8A9so+tw/5+L/wF/5h/wAQ+xf/AELav/hTR/8AlZxn/Cs/G/8A0BP/ACZh/wDi6P8AhWfjf/oCf+TMP/xddn/wpv8A6mP/AMk//tlH/Cm/+pj/APJP/wC2UfW4f8/F/wCAv/MP+IfYv/oW1f8Awpo//KzjP+FZ+N/+gJ/5Mw//ABdH/Cs/G/8A0BP/ACZh/wDi67P/AIU3/wBTH/5J/wD2yj/hTf8A1Mf/AJJ//bKPrcP+fi/8Bf8AmH/EPsX/ANC2r/4U0f8A5WcZ/wAKz8b/APQE/wDJmH/4uj/hWfjf/oCf+TMP/wAXXZ/8Kb/6mP8A8k//ALZR/wAKb/6mP/yT/wDtlH1uH/Pxf+Av/MP+IfYv/oW1f/Cmj/8AKzjP+FZ+N/8AoCf+TMP/AMXR/wAKz8b/APQE/wDJmH/4uuz/AOFN/wDUx/8Akn/9so/4U3/1Mf8A5J//AGyj63D/AJ+L/wABf+Yf8Q+xf/Qtq/8AhTR/+VnGf8Kz8b/9AT/yZh/+Lo/4Vn43/wCgJ/5Mw/8Axddn/wAKb/6mP/yT/wDtlH/Cm/8AqY//ACT/APtlH1uH/Pxf+Av/ADD/AIh9i/8AoW1f/Cmj/wDKzjP+FZ+N/wDoCf8AkzD/APF0f8Kz8b/9AT/yZh/+Lrs/+FN/9TH/AOSf/wBso/4U3/1Mf/kn/wDbKPrcP+fi/wDAX/mH/EPsX/0Lav8A4U0f/lZxn/Cs/G//AEBP/JmH/wCLo/4Vn43/AOgJ/wCTMP8A8XXZ/wDCm/8AqY//ACT/APtlH/Cm/wDqY/8AyT/+2UfW4f8APxf+Av8AzD/iH2L/AOhbV/8ACmj/APKzjP8AhWfjf/oCf+TMP/xdH/Cs/G//AEBP/JmH/wCLrs/+FN/9TH/5J/8A2yj/AIU3/wBTH/5J/wD2yj63D/n4v/AX/mH/ABD7F/8AQtq/+FNH/wCVnGf8Kz8b/wDQE/8AJmH/AOLo/wCFZ+N/+gJ/5Mw//F12f/Cm/wDqY/8AyT/+2Uf8Kb/6mP8A8k//ALZR9bh/z8X/AIC/8w/4h9i/+hbV/wDCmj/8rOM/4Vn43/6An/kzD/8AF0f8Kz8b/wDQE/8AJmH/AOLrs/8AhTf/AFMf/kn/APbKP+FN/wDUx/8Akn/9so+tw/5+L/wF/wCYf8Q+xf8A0Lav/hTR/wDlZxn/AArPxv8A9AT/AMmYf/i6P+FZ+N/+gJ/5Mw//ABddn/wpv/qY/wDyT/8AtlH/AApv/qY//JP/AO2UfW4f8/F/4C/8w/4h9i/+hbV/8KaP/wArOM/4Vn43/wCgJ/5Mw/8AxdH/AArPxv8A9AT/AMmYf/i67P8A4U3/ANTH/wCSf/2yj/hTf/Ux/wDkn/8AbKPrcP8An4v/AAF/5h/xD7F/9C2r/wCFNH/5WcZ/wrPxv/0BP/JmH/4uj/hWfjf/AKAn/kzD/wDF12f/AApv/qY//JP/AO2Uf8Kb/wCpj/8AJP8A+2UfW4f8/F/4C/8AMP8AiH2L/wChbV/8KaP/AMrOM/4Vn43/AOgJ/wCTMP8A8XR/wrPxv/0BP/JmH/4uuz/4U3/1Mf8A5J//AGyj/hTf/Ux/+Sf/ANso+tw/5+L/AMBf+Yf8Q+xf/Qtq/wDhTR/+Vnn+p+CvFWkQeffaLcLFtZ2eLEqoFGSWKE7R9cd/Q1gV3es2urfDnxLHbaVrkrPLAszMsexWyXUBkJYNjBxnpmq93aL43S61PTLJINciUz3VnbqfLukzzJGOcOMjcufm6jnIPRGo7KT1i+v/AAD5LHZJSVaeFw8ZQxEHrTk4zvZXfLOKSlLry8q00Tk9HxlFFFbny5v+CtMi1fx/pdjPs8ozeY6ugdXCAuVIPUHbj8e9M1vVZtc8Q3eq3A2vO+4LwdijhVyAM4AAzjnFaHwz/wCSpaX/ANtf/RL1z9RDWq/Rfjf/ACPcrNwyWko/bq1L+fJCny/dzyt6sltrq5s7pbmzuJbeZM7ZYnKMuRg4I56E1of8JN4k/wChh1X/AMC5P8ayqK1cYvdHlUcZiKEeWlUlFeTa/I1f+Em8Sf8AQw6r/wCBcn+NH/CTeJP+hh1X/wAC5P8AGsqil7OHY1/tTG/8/pf+BP8AzNX/AISbxJ/0MOq/+Bcn+NH/AAk3iT/oYdV/8C5P8ayqKPZw7B/amN/5/S/8Cf8Amav/AAk3iT/oYdV/8C5P8aP+Em8Sf9DDqv8A4Fyf41lUUezh2D+1Mb/z+l/4E/8AM1f+Em8Sf9DDqv8A4Fyf40f8JN4k/wChh1X/AMC5P8ayqKPZw7B/amN/5/S/8Cf+Zq/8JN4k/wChh1X/AMC5P8aP+Em8Sf8AQw6r/wCBcn+NZVFHs4dg/tTG/wDP6X/gT/zNX/hJvEn/AEMOq/8AgXJ/jR/wk3iT/oYdV/8AAuT/ABrKoo9nDsH9qY3/AJ/S/wDAn/mav/CTeJP+hh1X/wAC5P8AGj/hJvEn/Qw6r/4Fyf41lUUezh2D+1Mb/wA/pf8AgT/zNX/hJvEn/Qw6r/4Fyf40f8JN4k/6GHVf/AuT/Gsqij2cOwf2pjf+f0v/AAJ/5mr/AMJN4k/6GHVf/AuT/Gj/AISbxJ/0MOq/+Bcn+NZVFHs4dg/tTG/8/pf+BP8AzNX/AISbxJ/0MOq/+Bcn+NH/AAk3iT/oYdV/8C5P8ayqKPZw7B/amN/5/S/8Cf8Amav/AAk3iT/oYdV/8C5P8aP+Em8Sf9DDqv8A4Fyf41lUUezh2D+1Mb/z+l/4E/8AM1f+Em8Sf9DDqv8A4Fyf40f8JN4k/wChh1X/AMC5P8ayqKPZw7B/amN/5/S/8Cf+Zq/8JN4k/wChh1X/AMC5P8aP+Em8Sf8AQw6r/wCBcn+NZVFHs4dg/tTG/wDP6X/gT/zNX/hJvEn/AEMOq/8AgXJ/jR/wk3iT/oYdV/8AAuT/ABrKoo9nDsH9qY3/AJ/S/wDAn/mav/CTeJP+hh1X/wAC5P8AGj/hJvEn/Qw6r/4Fyf41lUUezh2D+1Mb/wA/pf8AgT/zNX/hJvEn/Qw6r/4Fyf40f8JN4k/6GHVf/AuT/Gsqij2cOwf2pjf+f0v/AAJ/5mr/AMJN4k/6GHVf/AuT/Gj/AISbxJ/0MOq/+Bcn+NZVFHs4dg/tTG/8/pf+BP8AzNX/AISbxJ/0MOq/+Bcn+NH/AAk3iT/oYdV/8C5P8ayqKPZw7B/amN/5/S/8Cf8Amav/AAk3iT/oYdV/8C5P8aP+Em8Sf9DDqv8A4Fyf41lUUezh2D+1Mb/z+l/4E/8AM1f+Em8Sf9DDqv8A4Fyf40f8JN4k/wChh1X/AMC5P8ayqKPZw7B/amN/5/S/8Cf+Zq/8JN4k/wChh1X/AMC5P8aP+Em8Sf8AQw6r/wCBcn+NZVFHs4dg/tTG/wDP6X/gT/zNX/hJvEn/AEMOq/8AgXJ/jR/wk3iT/oYdV/8AAuT/ABrKoo9nDsH9qY3/AJ/S/wDAn/mav/CTeJP+hh1X/wAC5P8AGj/hJvEn/Qw6r/4Fyf41lUUezh2D+1Mb/wA/pf8AgT/zNX/hJvEn/Qw6r/4Fyf40f8JN4k/6GHVf/AuT/Gsqij2cOwf2pjf+f0v/AAJ/5li8vr7UJxNf3lxdSBdoeeQuwHXGSenJ/OrGiarNofiG01W3G54H3FeBvU8MuSDjIJGccZrPopuKa5baGNPF1qdeOJjN86aafW61TNPxrpkWkeP9UsYNnlCbzEVECKgcBwoA6Absfh2oq78TP+Spap/2y/8ARKUVjRbdOLfZHpcQ0YUc1xVKmrRjUmkuyUmkHwz/AOSpaX/21/8ARL1z9dB8M/8AkqWl/wDbX/0S9c/Th/Fl6L9TTE/8ibD/APX2t/6RQCiiitzwQooooAKKKKACitDStE1bXLo2+lWMty4+8VGFTgkbmPC5wcZPNdZD8L7y3hS48Qa5pulQOowWfcwc87DnaucZ6MenfrWU69ODtJ6ntZdw7mWYw9rhaLcP5to/+BStH8Tg6K9CPh34aWx8i78Tai06DbI0cZ2s3cr+7PB6jk8dz1pft3wrxn/hGdU/7+N/8dqPrF9oN/L/ADPR/wBVHDStjKEH29pzevwKVredvK+p55RXof2/4Vf9C1qf/fxv/j1N/sn4Vznz/wC29VtfM+fyNpPlZ5258s9OnU9Op60fWH1g/u/yD/VVS/hY2hL/ALicv/pcYr7rnn1Fd+fhgb3/AJF/xPpepbP9dk7fLz937hfrg9cdO/bldX8N65oOw6rp0tuj42ycOhJzxuUkZ4PGc1UK9ObsnqcOP4ZzTAU/bYig+T+ZWlH/AMCi3H8d7rozKoqV7eaO3inkjKxy52Mf4sHBx+NRVseG01uFFFFAgooooAKltbaa8vobO2TfNM6xxrkDcxOAMnjqairZ8Lf8jF/26XX/AKTyUpOybOnB0Y18RTpS2k0vvdi9DaaPZR+UbGPUpOjzTySKhP8A0zVCpA92JJwDheRUm7SP+hc0/wD7+3H/AMdqCvXvhv4L8Pa94Gsb3UdGtLye41t7Keaa8khkSAQB/wB0iyKHcHkAKxOTx3HfhsB7eXJHf1f6HmZvxQsqofWKsFy3tZQg+je8t9urbfmzyjdpH/Quaf8A9/bj/wCO0btI/wChc0//AL+3H/x2vXfAXgjwjquk2dzqmlS3QbXby0fzJZIneCOzaVUIVhtO4A9j26cVQ8RfDrTovDugf8I/H582t6s0dndl2PmWzqhjDLnAK7mDcA5U1v8A2TL2ftFt6u/T/M8xcf0PrTwkopPu6dO32r626cre17fO3mO7SP8AoXNP/wC/tx/8do3aR/0Lmn/9/bj/AOO16L8TfCXh3S9JtNY8JxQLZxXMmnXXk3y3Yd15jlJV22F1DfKcY29BXPw+CPN+ENx46/tq1XybsWv2Aj52yQM5z15ztx0BOayqZc4TcLXsr7vY7cLxhSxGHp4n3YqcuVJ04X5m7JO0Xa/raxzW7SP+hc0//v7cf/HaN2kf9C5p/wD39uP/AI7XXeFtE0mT4feIPFN7p39rXGnSQRR2JkdI1Dk5lk2EMQMYGCOetbvhfSPA2v6bqV5q+g3Gky6IP7RuLa3llYXlsV/1XztlDvK4Yfwt3I3U6eXKfLra+u78/l0ZGK4x+r+0bpcyptRbVOm9Wk0rfE/iir2td721PNN2kf8AQuaf/wB/bj/47Ru0j/oXNP8A+/tx/wDHa9n0PwZ4M1vwhoczaLZw3+sWmozxwx3F157PE7+WsRLGIKqgA+ZycDqc1zN7ovhrT/gx4f1Y2mjJqeo292ZJL570zSMkpRTCIj5QIGPv4GcZzzWksq5Y8zata+78vx1Ry0uPI1ansY0Xzc/Jb2dPf39dPs/u5a+Xrbz7dpH/AELmn/8Af24/+O0btI/6FzT/APv7cf8Ax2vX9c8DeGrb4byajFosMMkfh+y1Bbq3upJLhrmQgPviLsFjI53bFA5wewpXHhDw7H8Hf+EyXw/KNRewRf7M+0PtizIU+34379hxwp+XJ6FaJZRKLab2V93sTS4/pVIxkobzUF+7pfE0mvlr8uttL+W7tI/6FzT/APv7cf8Ax2o5NLsNVZYLCyFlfOQsKRyM0Up7KQ5LKxJwG3begIGSwZRXA6EbafqfVRzGbdqkYuPVKMU/k1G69Tm639E0S2nsf7W1YzfYfMaCOK3cJJPIoUsAxVgiqHUkkHO4AD7zJV8Tf8jtrH/X9P8A+jGrpJP+RR8Nf9eEn/pXcVySm+RSXU87OIywtR4eL+04322v917f5a6h5mgf9CdpH/f+7/8Aj9HmaB/0J2kf9/7v/wCP1Ur2H4VfCjRfGHhefXNbu7raZmgihtnC7cAZZiQeeeB7d81hzy7nzmOxNHA0vbVpyt/il/meU+ZoH/QnaR/3/u//AI/R5mgf9CdpH/f+7/8Aj9dXfeCLTTfjhH4JudRJtGu4ovtHAbY4VgPQNhgPrV7VPD+iXHhbxJfRaG2izaNqEVrD+9kb7UruylGDk/OoAbK4GD0o55dyHjKPuWlJqSTT5pbSdl9q+/3dThvM0D/oTtI/7/3f/wAfo8zQP+hO0j/v/d//AB+vYfE3w88JWp8UX+kWRFtp1r5XkNO5NrchkO7lssrI+RnIyG9BWMPCHh3/AIaUufCv9nf8ShBIVtvOk4xalx827d97nr+lHPLuc1LNcPVg5xc9IuXxPZJN/a395f5nm/maB/0J2kf9/wC7/wDj9HmaB/0J2kf9/wC7/wDj9er+FfAXhfXfDPhB2tD/AGndPJcXaGZwLu3ScxuB83ysoKH5cZAasm10LwzafDu81i7s9IFymuTWKSapJeFPKWMMEUW5zuznlvfnpRzy7lLM6Lk4LnbTt8Uu7X83k/6uefeZoH/QnaR/3/u//j9HmaB/0J2kf9/7v/4/VSijnl3PW9l/el/4FL/MtlvD0imN/CWnxq3BeC4uVkUeqlpWUN6Eqwz1B6Vz2u6MmnCC+sneTT7pnWEyEeZG67S8b4xkrvT5gMMGB4O5V1ql1H/kml//ANhO0/8ARVzV05u9mXTlKjKLTbTaTTbe7t1btbf8DjKKKK6T2joPiZ/yVLVP+2X/AKJSij4mf8lS1T/tl/6JSiuah/Cj6I9/ij/kc4z/AK+1P/S2Hwz/AOSpaX/21/8ARL1z9dB8M/8AkqWl/wDbX/0S9c/VQ/iy9F+osT/yJsP/ANfa3/pFAKKKK3PBCiiuk8JeEp/Ed09xcSfZNKtvmubtiAAAMlVJ4zjknoo5PYGJzjCPNLY7cvy/EZhiI4bDR5py/q77JbtvRIyNL0jUdb1AWOl2r3E5UttUgAAdSScAD69yB3rvovDfg3wftl8TX39q6iuG+wwDKoflPK55xkn5yAwP3aqaj4wtdL0iPQfBay2lom7zbt1AlnY8FgeoyMHdwegAUDFcXWShUrayfLHt1+fY+kWJyzI/doQjia/WUtaUX2hH7bX80tNFaLOw1T4i61dRi10pItJs1Ty1itwCwXaBjdjjGDjaFxn2zXPWsN9r2vxQPcPNc3LhDNO5Y9MZZj2AH5CqFei6T4T1Y3mmaD4Y059T8R6j+6EVu29/MYn5OwQIFJYngYJJwK2jThSXuKx42NznG5pUUsdWlNb2vovSK91fJJHNeNHs38b3jWGGtQVSMjjcqqFB/EKK9c+G2jR3VjF/wl37O6al4elG1tWtpLuzuVBH342km2S+uABnsRXsHg74F+GPhpFb614g3+J/F8qb4rS0x5Ftt6mMsM7V/inbA/uj16GS/wBc8ValLpH9nG1v2jR2jju5HxE+dvmmTswUkZwcAHGCKIvRI4679rVlVSsm72Plfxj8ILwfEa+s/h9BPqWhNtltZ7iREZVYZ2EsRkj1x0xnBrH1H4MfEvTLQ3U/hW7khAyWt2WbH4KSf0r6+8N+F7nw+zXuqaLOLDcVlvLOXfLbkHB82MgnaMD7vQc4Ir0WXQ9Tjthc6eE1e1ZQwtwUSVlPOYnGEc46BsZ/vVXPYydNH5ist1YX2GWa2uYWBwQUeNhyPcEV3fg3xF4yuNRggMxutPDBZp71SUjBbJJlAzu6gAk9cAHiu8+LPibQ9f8AidcMdLiSz0l3gBuLbyLiZ1+8ZNw3JggjaRkDnAJ48ym8Sy6grJNemxsVbhUBd29di5wOB1P51lVUaqs1c9fJcwxOXV1UoV5U1/ddr+vS3rc39b0nwn4o11tNg1JNJntlWCyiWNVjZd2T8vALFmbgMDknqBXnOu+HdW8OXy22qW3l78mOVTuSQA4yp/Lg4IyMgZpL66+2X8k4QRqThUBztUcAfliul0HxmbfT20TxHC2paM8XleVgF4wORtPGR06nIwCCMYOfs6lJXjqu3+R6ssblWcTdLFR9hU15aiu4vsqkenbmjqusWkcNRXW+KfB8el2EOuaFcvqGizqMTHloj0w+AOCeM4GD8pAOM8lW1OpGavE+bzLLMRltd4fExs9Grapp7Si1o0+jQUUUVZwBV/Rr6PTtahuplZocNFKEGW8t1KPt7btrHGeM4zVCik1dWNKNWVGpGrDeLTXyOqntZYI45uJLeXJhuEB2Sgd1J+vI6g8EA8VLDqup29pFawaldxQQzi6jiSZlVJQMCRQDgPgD5hzXNWWp6lp2/wDs/ULq08zG/wCzytHuxnGcHnqfzq3/AMJN4k/6GHVf/AuT/GtVXnHZfjY1nQwNXWbkvLlUkvm5R/LTbXd9GniXxFG7PHr+qIzTPcFlupATK67Wfr94qSCepBxTLfX9etIrSK11vUYI7Nme2SK5dRAzZ3FAD8pOTkjrk1z/APwk3iT/AKGHVf8AwLk/xo/4SbxJ/wBDDqv/AIFyf41X1qr/AE3/AJGX9nZZa13/AOC4+f8Af8397NdL69j0+WwjvLhbWZg8sCyEJIw6FlzgkZOCar1Q/wCEm8Sf9DDqv/gXJ/jR/wAJN4k/6GHVf/AuT/Gpdeb6fj/wDZYbAxvapLX+4v8A5M2dP1PUtJu/tWl6hdWM+MebbStE2PTKkGntrOrtPdzNqt6ZLxdl05nYmdfRzn5hwODnpWH/AMJN4k/6GHVf/AuT/Gj/AISbxJ/0MOq/+Bcn+NNYmola34/8AzlgculLncpX7+zj/wDJnSQ+J/Elto40m38Q6rDYBSotI7uRYsEkkbAcYJJzx3NEHifxLbaOdItvEOqw6eUaM2kd3IsW1s7l2A4wcnIxzk1zf/CTeJP+hh1X/wAC5P8AGj/hJvEn/Qw6r/4Fyf40/rdX+m/8iHlmVu929Xf+HHfv8e/mb413XBJ5g1nUA/2b7Fu+0PnyOnldfuf7PT2oOva4bp7k6zqBmeD7K8puH3NDjHlk5yUxxt6Vgf8ACTeJP+hh1X/wLk/xo/4SbxJ/0MOq/wDgXJ/jR9aq/wBP/gFf2flv8z/8Fx/+TL9WYIEWIX18JItPjfEsyjG7vsQnguR0H4nABIx/+Em8Sf8AQw6r/wCBcn+NUry+vtQnE1/eXF1IF2h55C7AdcZJ6cn86zdWbVrW/r0OiMcJSfOnKbXRxSXzfNLTutL90F9eS6hqlzfzKiyXErTOEGFBYknGe3NdZosra7oFlpdqjS6nYB4kto1JaeAuZAUHJZ1Z5NwH8OwgEK5HF0Vm4Jqx5uMpyxT5pP3r3v56/wCbOurofDfjnxT4Rini0DVXtopzueMosilsY3AMCAfcelcZ/wAJr4y/6G3Xf/A+X/4qj/hNfGX/AENuu/8AgfL/APFVj7F9zyquBq1o8lSEWuzbf/tptXt9eajqU2oX1zJPdTOZJJnOWZj3qa+1rWdTiij1LVr68SL/AFa3E7yBPoCTiuf/AOE18Zf9Dbrv/gfL/wDFUf8ACa+Mv+ht13/wPl/+Ko9i+5X1Otp7kdNtXp/5KdE+u63I120msagzXuBdFrhybjHTzOfmx2zmrUvjDxdMUM3inWpDGxZC99KdpKlSRluDhmH0JHeuT/4TXxl/0Nuu/wDgfL/8VR/wmvjL/obdd/8AA+X/AOKo9i+5DwFR704/f/8AanQQa1rFq9o1tq19C1mGFsY53UwBs7tmD8ucnOOuansvE3iTTYXi07xDqtnHI5ldLe7kjDOerEAjJOBz7VzH/Ca+Mv8Aobdd/wDA+X/4qj/hNfGX/Q267/4Hy/8AxVHsX3HLA1Zbwj9//wBqaRJJyTk0Vm/8Jr4y/wCht13/AMD5f/iqP+E18Zf9Dbrv/gfL/wDFUexfc0+r4jtH73/8iasUUs86QQRvLLIwRI0UszEnAAA6k1F4juksNCHh7IN49ytzeJ18gorLHHns/wC8lLjnHyDhg6jMn8XeK7m2ktrnxPrM0MqlJI5L2VldSMEEFsEEdqxquFLld2aUsJNyUqtrLWy1183Zbdrb216BRRRWp6R0HxM/5Klqn/bL/wBEpRR8TP8AkqWqf9sv/RKUVzUP4UfRHv8AFH/I5xn/AF9qf+lsPhn/AMlS0v8A7a/+iXrn66D4Z/8AJUtL/wC2v/ol65+qh/Fl6L9RYn/kTYf/AK+1v/SKAUUVd0jS7vW9at9LsQhnnbC722qAASST6AAn144zWzaSuzxaNGdepGlSV5SaSS3beiS9TX8JeEp/Ed09xcSfZNKtvmubtiAAAMlVJ4zjknoo5PYHT8UeKILy1j0DQIvsmiW3yqiggzkHO5s84zzg8k8nnpZ8YajYaXYjwXoMXl2ls4a5n35aeTHIYjg4OM57qAAAori6xpQdVqrPbov19fyPrc0xUMnoyyjBNc70rTX2n1pxdlaEXv8AzvfSyCiiprW0ur68jtLK3luLiVgkcMSF3cnoAByTXWfHEcZxMp44IPPSv0q/Zx+C58I/DWfxzq0Qn8ReJHeRJCu37JYuxdEUHlTKNrt3wVU/dOfmP4Nfs9zp4p0/xH8W7QaXpkb+db6BdELd6iVw3zxfeigHV2YAsPlUfNkfcnjDxvNpvw1vJLSYfaLlo9OtdoxtmnkEIYY9N7N/wGsKrvsb0YSk1FdR9roGmy3TMiLNLeJ500vXfGrBVH+5k8Dp1Pc15d8ENviPXPiDrlwmbuXXySW5Ij8rag+gAIr0Lwt4z0pvi74q0+3MUlrpttpul28ZPCBfOJ/HdtH4CvOfAvia38BftS654JvbO3hstWjL2MpUhZzlpIifU7WkTI/iTFYybTR6eEhGdGtFfEkmvRNX/DX5Hry2EMWrxWuzElwrOhH8RQLkfXBB+grEuNX0XwXq97pupM8FhHbvdrGkRd4mVTI0aIOqugZ0xxlJF4xxh/E/4kS6TquhahpECyz6frTtcQoCWaA2ZMu0f7rg4/2a4j42+M4Nf+Hlr4m0K/VdY0y4QT+XcBHMTYKgSEEBNxjkDEY2luRk0SlZNmWEw3tpxjLRN2v/AFf+meX/ALUOm+F/iDcSeK/BFmbe8s7C2ur6aSRIzqkL7UJEX3vPhLAMOSyq3XYM8hafBq8vv2c4pZdNXz7sG7tLoYDifHyKe+x1Aj9NxB7V1l94i8NT/DrRbDT9HaPWIZALrULmQrG8UuZEK7TjZlm27gSFGQTvyPU/CNzZWfw4g8OJfx6iiIVguIl2pNjrFg/clXGChOSRuXOTiMJWk3739eR6GcZdRwqi6beras+y+1p336b7W1PzuYFWIIII7Gkr1H40fD+bw14xudf0qJ7jw9qMzSw3KKSsMjHLQv8A3SDnAOMj3Bx5dXoHzbVjofC3imbQLh7e4i+16XcfLc2rAMCCMFlB4zjgjoRwexDvF3hGHT7dNf0CT7Xodx8yupLGAk42tnnGeATyD8p5wTzldR4P1y0s5ZtC1mBLjSdRKpKsj4ETdA/JwB0yeCMAg/Lg8tam4P2tPfqu/wDwT6vKMfSx1FZRmL9zX2c3vTk9lez9yT0kunxKzRxdFbXirw/N4a8SzadJzEf3lu+4MXiJIUnAHPBB4HIPbFYtaRkpJSWx85jMJVwdeeGrxtOLaa80FFFFUcwUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB0HxM/5Klqn/bL/wBEpRR8TP8AkqWqf9sv/RKUVzUP4UfRHv8AFH/I5xn/AF9qf+lsPhn/AMlS0v8A7a/+iXrn66D4Z/8AJUtL/wC2v/ol65+qh/Fl6L9RYn/kTYf/AK+1v/SKAV6X4bi/4Q/4Z3XiaVNmo6jiG03LyinO08rxnDP6MFSuE0TSptc8Q2mlW52vO+0twdijlmwSM4AJxnnFdZ8RdUS68TrpVqsSWemoIY0i27QxALYwOMYC7e2ztzU1l7ScaXTd+i/zZ6fD0v7MweIzpr34/u6X+OSd5esIXfq0cfRRRXafHBSgkMCDg9sUlFAH0t8HVtfCXhzRZblDca/4paXUHMnJt9MtA7LknkeZNETjvsQ9q9r+JfiX+yfCnhpxLmO2162Mw94o5HP6rmvm3wDrT6z8QtT1qLe1lpPhWOwhyOIwsMUO36k+afqSa9J+J2sf2h4c1WK2EUzWWuW+opFI+1ZIncRsCRyFyxyR0DA1hUdlc9PAU1OXp/nb9TsjBqnhbwXp3jaCfzH1ZJG1FFHz29yJBcQrIOqkqGUA9R0zmk8e3ml/EHwva6n50lpqWnyJcWWoW7YkiR2U5B7gZBx6rnvXDeNfid8Uo/C2mS+NvD3hxknsYprc6Z51ve/ZjJImybcpilWJ4grBtpVypXkk13/gH4ceJfGfwptPE2jpYzWVzFJGts0/lySAEqcAjEbgggoTgkZBG7FccKvJG1Q750J3VeK5ei6bafkrfeaXwQsvEPjL4wXmp+KWtryHTxJPLJEuI5XaNIEO0/dLbHOPbjiud+KHw61WwlvvEXwyim1bw7h7eV413QqpJ3RKf+WqKxOHXhSSoJ5C3/F1n8TfDXwzjsLHQI9D0yWaOPViLaYrsURwCe6dGLyRHKgRRYzlt3AJPmWn+Hfjv4w1SL/hLPGPiXS4bWC4ns7O2mWyhjeFMWyx26rgq0vlIvB4YcjrWKlKU+dM6qFCtyucI3hHfb+r+R3nw8i0ey+EnhfVLnTIZNUuJLTTrhrkFy6xXLRoNjZAK4U5AzkCmWen6MfH/ifT5tMsrm2nZb6FnypxKM87SNybwwOc4ODXNaTqlw/jDwp4Ol1KW/l0+VtQ1G9d9/msjtKzk+mSv/fQri9a8X3emfE6yv7aYHyJ7jT5Ub7skRZZFB9gJf0rvovS5zY3DSc4xveTTfy6L7kdn40Gqz6Bcax4FuVt3jVobzQ54FmhuNvVHiYEbuDg/wAWB3Ir5V1C9OoajJdtbW1uXOfLtohFGv0UcCvoO78SzWXjLStYt3McGo3X2WaMngvw6H6huPofavEfHFvaWnxK1+2sdv2aPUJ1jC9FG88D6dPwrstoeFVVjAoooqTE9Agi/wCE0+Ez2QTfqujYMW1cs8eOFGF7qCoUclkUk815nXV+DNYbRfGNrcF1WCZvs85dgoCMRySRwAcN/wABxnmq3jfRW0Pxrd24RFgmY3EARQqhGJ4AB4AOV7fdzjmuKC9nVdPo9V+p9jm8v7Uyqhmdv3lK1Kp5pK9OT9Y3i293HzRztaGhW0N54p02zuU3wzXUUci5I3KXAIyOehrPrS8OyxQeMNKmmkSONLyFndzhVAcEkk9BXSfHH2v+1J+y98OPD3w4k1T4OeHZLPW9Ent31XTobu4unmtblmjicLK7nIkQgbcZG/P3RU3xE/Zn+EfgX9ivxDqy6Ml38QPDtnaxalqa39wRFeyGCR18sSeXgJOoHy/dKnrzTvjJ+05pnw0/bTj8ZeDbnSPHGhXnhaDT72107VI2heRbiZ0PmoJAroSDjBOHPTOa5PRfivpPir9gf4zzeKfFWjweLPEPiSTUI9KmvY0uZVb7ER5UTNvZFCMowMYQ+hrJc2heh5B4J/Z1v/HfhvS9S0v4t/Cm0vNSH7nRNQ8QGLUFcsVEbQiM4ckcDJ6iquhfs4fEfWf2hbn4M3CaZpHiS3he4ZtQnYW7RqocMrxo5IZSCOPY4IIr6R8G6t8APDvwQ8A6x4Rb4NC/iSFvEzeM7VrzVlmwm820WQ2/zPMwSVjA2kEAE10t78R/hyf+CoOneK4/Hnhc6EPCpt31ZdUg+yiXMnyGbfs3YxxnPSjmYrI+SfEH7PuveFNV0zSvEnjz4faZqN9qf9myWVxrYE1gCGIuLpApMMJCg7m+YblBUE4Gzqf7KvjWLwVq3ibwr41+Hvjm20mE3F9B4U1v7bNDGASWKlFHRWOM5ODgGqfhC8+G2q/tw3OofE+7gu/B91r19NcXLSloJdzSmF3ZDzGXMZJBwQeeM19n+DfHvwf8LeMvGukw+IPgRoul3Gnyf2VL4X8u2uJoMkKl3csyxvIcj90m45BJxxlyk0CSZ4R4I+FOk+Nf+Cast9pfh7w3F4lfXSjeIL+OC3e2gWZd7SXTgFI1XOeenABJAPhPxb+BvjT4NSaPL4lm0nUNP1mEzWGqaPcm4trgAKSFYqp6Oh6YIYEE849ds/GHhmL/AIJUah4QHijSU1+XXRIdH+2xi7eP7RG27yd28r8uc4xxmk/aC8WeFtb/AGMPgloukeJtH1HVNNslS9srS9jmntD9njXEqKxZORjDAdKE2mDsfO3gjQE8V/Evw/4alN2IdS1GC0la0hM0qRvIFdkQAliFJOMdq+m/2k/hj8I/hLfL4H034P8AiWG8vrNW0XxXb6zJcC9ueAY3t2BThiAwXDfMCBgjPnX7JHxD8HfDP9pO08QeN2WDTprKayjvmjLiylfbiUgAkDCshIHAc54zX1h4B8TfD3RLG58LfGn44/Dnx7oP9uR6p4aum1I3F7azecZFNwQMRKGIOS20AurHYcAk2mCR+dmueH9e8Ma1Jo/iTRNR0bUYwrPZ6jbPbzIGGQSjgEAggjjmvpT9mT4JeEfit8BfilqGpeF21nxRptqyaEy3c0JjuGt5TGAqyKjEyKn3wR68Zry39o3Vb/Xv2m/Fet32t6HrIvLrzLa80S+jvLZrcKEhCuhIyI1UEHBBB45r3D9kX4l6H8Ov2d/i7eT+LND0jxCtqbnSLbULuKOS5njtpjGI4nYGU79g2gHJIHenJvluC3Ob+JXw6+Df7P8A8JY/CnirTrfxr8XNRiE0oS+nitdEVl4ysTpvIHKhslj8xAXAbivBf7MHxA8X+AtP8Y3eseE/CekanIItNm8T6n9jN+x4URKFYnODjOM9Rkc16t8RLn4RftPfC1viPY6/4b8CfFSwjWPUtL1XUIrKHV9q8eW8rKGJA+V85HCPxtYeiaT8WPAvxD/Zw8CaTpmofBOLXvDljHp1/pnxStS0cXlxJGXtX3AYbywflDZBUEqVwZu0gsj5YsP2avixffHe5+EraLb2mvW1sb6aW5uAtslqCB9o8wZ3Rkso4BOTggEECj8Qfgdrvw/8LL4jPi/wR4n0v7StpJc+GdZS98mVgxVXXCsM7G5xjivoPWPjNr+rftb6drdv8ZfhlpuqWPhtrA6vaaddDR7pmuNxsZXkd2K4PmecMLwB15qj8fbj4NXH7O6TapJ8KZfiW+oRmCT4ZcwNb7hvMpHfZv8Av/xbcd6fM7oLI808O/sr6/4ts7L/AIRn4s/CXVdTvLdZ4dFtfEW+9JKbzGYvK4cDIIzwQea779kr4baY3xA+KXhr4i+DdLvtR0TSHQ2urWcVybWdXYEpuDAHj7y9RjBxXtOi+JP2dvCHjbwNqXw8vvghZeF2Eaz3epwmXxBDOc4YSMR5AA2lpJmGPm4PAPP+CPiF8PbL9sv47a1ceOPDVvpep6XGljeyanAkF2/lJkROW2yHOeFJ5pOTaHZH5/0UUVqQFFFFABRRRQAUUUUAFFFFABRRRQB0HxM/5Klqn/bL/wBEpRR8TP8AkqWqf9sv/RKUVzUP4UfRHv8AFH/I5xn/AF9qf+lsPhn/AMlS0v8A7a/+iXrn66D4Z/8AJUtL/wC2v/ol65+qh/Fl6L9RYn/kTYf/AK+1v/SKB3nwwhjt9S1XxBcRpJBp1mzEYzICcnKZ4ztRx1H3sdzXKXNxNd3s13cPvmmdpHbAGWJyTgcdTXYeH/3HwL165h/dzPdrE0icMyZiG0kckYZuP9o+tcVRQXNUnPzt9y/4J3Z63h8sy/BrZwlUfm5yaX3KCX39wooorrPkwooooA90+E0dtZ/B28vC4E+r+JLXRi390eS8ij/gRLD8KveJ9M1O28O/24X860uLZopI/wC9GcxlT7hVXnvtHQjNeKad4h1ix0K50KyncW91dQXexc7lni3CN1x0YCRx+PsK+gfCHi6z8Z2EHhzXpLa2vtQgmtfLX5VW9SRpEQDPHmxzygD+/FtHUCspq6szvweI9lOMl0/LqfR3gC0PjvwJ4Y1PXdG1a1kgsoyPtLKEnLxrvmQgHckoCuVz97kgHk+2aZp8GjabZ2VqYbaxhXYolk+YsTnqepJJJPUk18bfB/8AaasvhnA/w4+I+n3EljpT+VZ6jaKGmt4SchHjON8aknDKdyjggjGPpnTPi98HvGqQxWPjLw7dTAB0t710hmUMO0c4B5HoOleBWpzUnfY9+vXk4qmtlf09TudUhh1TQ57YCO5trhGikQ/Mki8qykdx1BryPxp4Z8Q2nhy4PhPStLh1CSNof7RlRYxYxFSHkGAWZgpOAMDPJPY9Tq3xZ+FngbSorO98XaLaRxDy4bK2nE8uM8IkUe5j1wABXz78ff2jNeTSrPw34Y0KbS7XWI5C99f4Fx5S4Dfuh/q8g8biT7A1nThKUkkaYN1IKyWjPIfCUo0Lwlql+03m6nq9x/Z9nKRhvKB7eg5BPvivNtVvhe+PLghswveu0ZB++FwufyUVYj1a/ur6OZJhEltAy2oCkiIsCFfHAwMs3XLHaelcvBbIsl3JLczPLawtLFOMLtKkAA9cgk4x717tPVKJhia0KeInVvf5/f8Ah8r3Nzxr4tWbXtOttHcGLSZDMJP4ZLgkFmHqF2qo9dpPeuHllknneaZ2eR2LMzHJYk5JNaWj6nNZ68JwkUiTExzQyIGSRG6qVIPHf1GMipdY0u2WEahpOXtfuzIG3eS+enPO08YJ+h7V1OTcrM+amk4899b7fqYtFFFMxCu38dO2teBPD3iYhPMIa2uJGULJI/rxxt3RyEem7pyccRXb2v7/AOAGq+f+9+z3q+Tv+bystFnbnp99un94+prlxKs4T7P89D6zhlutQx2Cl8MqUpf9vU2pp/cmvmeeUUVJb2893dxWtrBJPPM4jjiiUszsTgKoHJJJwAK2PkyOiro0jVi96g0u9LWGTdgQNm2w20+Zx8mDxzjniqVABRRVm60+7s7WyuLmLZFewm4t23A70Ejxk8Hj543GDg8Z6EUAVqK6FvAnjSK6s7e58K6vaNe3Edpbtd2r26SSucIgdwFBJ9TXPUWAKKKKACiipWtrhbNLtoJRbyO0aTFTsZlCllB6EgOpI7bh6igCKiir/wDYetG+s7IaRf8A2m9jWW1g+zvvuEb7rRrjLA4OCM5xQBQoqzFp2oTtcrBYXMptEMlwEiZvJQEAs+B8oBIBJ7mrS+HPEL6B/bqaDqbaXyft4tXMHBwf3mNvBBHXrQBmUVObG9GmLqJs5xZtIYVuTGfLMgAJQN03AEHHXBp40zUTdLajT7rz2h+0LF5TbjHs8zeBjO3Z82em3npQBVooooAKKKKACiiigAooooAKKKKACiiigAooooA6D4mf8lS1T/tl/wCiUoo+Jn/JUtU/7Zf+iUormofwo+iPf4o/5HOM/wCvtT/0th8M/wDkqWl/9tf/AES9c/XQfDP/AJKlpf8A21/9EvXP1UP4svRfqLE/8ibD/wDX2t/6RQPQ7/8A5IBof/X63/oU1cRXb3//ACQDQ/8Ar9b/ANCmriKeE+GX+J/mdvFv8XC/9eKP/pCCiiiuo+UCiitDRLGTUtct7SKMSO7gLGf4j2H0J/TNJtJXZUISnJQirtm1oml3ESD7MhF9Ku5pf+faMjt6Ow7/AMIPqeKUthI81z5IYR2uMeWSOQ3bvngn8q9WsP8AhGrGRdCj1W3n1DJMqpl2lk/i6DBPt2rmtEn0TS4JINet7h5ZJ2k8tGUK+Scbn3jAAA4HJyeV7+eq8qknZH2dbKsNgqEI1Jpt35ra2drcunm/wOPvW8TfETU4rnXhbyPp6rDPrMv7tp4+qrJtH7yQjOCBuPJbgE1q3CWetNcJcww2txBxBFJj5VwFSMjuMAAEemeckVb13WIYrV0tYI7ZIU2W9vHkqgbrj1JPzE9z9KS7sWu7C1t3YqzsSzqcECNBz7/PIPyq5OyPFoU1d21stfPsvvt59T1zTdD8MfCD4X6R4ttltb7WtdtFntp5/LZo8ZWRlA5RFY7MHBLLjPXHlmr6xc654tdJnl1XUJDzsBmB+iry304Ue1QR6NdX93aRXV7cy28MiRqjSFlQF84H90Elj9SfXNdP4O1pfDHhrV9S0yQW+q6gjzGZYTuEZZgAJeikNk7f4vlAyazpUkpNyd2deIxVT6ulBcsb29e/6ev3W5SSbVbt2tItLAw+xnu2XBbp90eh4rJ09ZItVu7TVLWOBXjkiuIwPlUbSd4/3SAw/wDr108E6OkigbiJDCgzy20DJJ/PJrP8R6feXCvcT+ShkQEEMFZtmN2Rndgrk9OqitoS5ZrsYPCqphpSim5pr0s+/Y4yzVvtIdfvDhf948D8uv4VuaetxEsjW0YkZF2TRsMiZOVIb64zn1Na/hzw6pl+1SgPt+VRj5c98Vr6BpTL4u1SzAzsAbHoGwR/M1FXEJNtdD0cBkEkqarL421+Df5o841K1S2u8wEtBIN8ZPXHofcHIP0qnXoHjbwu2mxefGn7mZi6YH3JAMsPoyjP1WvP66qNVVI8yPncywFTAYiVCpuvy6BXceCP+RJ8Y/8AXj/7Tlrh67jwR/yJPjH/AK8f/actZ4z+E/Vfmj3eCf8Akbw/w1f/AE1M87re8EXEFp8TvDl1dTxwQQ6pbSSSysFVFEqksxPAAAySawaK1PlD1O08Y6JfaRq9tKZLa4vrBm1SWRlUXUsZjjjEXOWYr5jnPJZ24wM1NqP/AAh/9rW39rf8I1/Z/wDbkX2H+y9mf7Pw+/7R5Xz4/wBR/rP3n368moquYnlPUT/Yn9qaT/bH/CKf21svv+PPyPsP+qX7J53lfus+Z5nXts38ZrB+INxHP/wjcQn0mS4g0kx3K6U0Zhjl+13DFQI/lBwwJC8fNkcEVxlFFx2PaNZn09fjrpuvLa+EbbT/APhJoLg6tZa0s00sfn53yR/aXCLj5ifLXGB0HB5uzOhjxhpMul2WjXWj/ZpBDDd3FrBNG+zDNcG4OxpFYhgGyjAYUDkDzuijmFynrcNlbLB4pudMuPCd/dpf6akN3f2tnDboHguGkjQf6gEbQDtO1thYZbbVbWtQ8DJ4u8OabaW2kf8ACOvK8l/NbwKZSv2+42q0mDIqiMR4HDFCuc/LXmS3NwtnJaLPKtvI6yPCGIRmUMFYjoSA7gHtuPqaio5g5T1u9n0VvF2kFPC/h5dqXIMq63pUkcgKAIzKsccKlCdyiVcvkg5xxzvjuPRotKtlsL/S728OpXLTS2VvbwERm2tCqlYPk2q/nKCvylg5HU1w1FDkCRauPP8A7Os/M+y+Vtfy/K8vzMbjnzNvzZz03846cV6tB410a117QUllEl7Z2mnW9nepIhit0kt7dLlZGzwVCSADsZJM4xXj9FJOw2rnquha14U8PpdXWqaxc7tV1SVriHTreO68yyXfGY5CZU8sSea56Nwitjpm3De+GdIi0jQk1KGfVE0vUdMh1NL+NrJPMuLlV85AOjK4IYuAu9WKkDnx+inzC5T1S7uvCb+DZvBMfiCRprfTVljBhiFmb2PdO7rced8xIeWEfIAfkGeBmSLxLoC+KbGBtN0Msvhlbc6ubmbzVk/ssps/13lbt37vBTOePvc15PRRzByhRRRUlBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAHQfEz/kqWqf9sv/AESlFHxM/wCSpap/2y/9EpRXNQ/hR9Ee/wAUf8jnGf8AX2p/6Ww+Gf8AyVLS/wDtr/6JeufroPhn/wAlS0v/ALa/+iXrn6qH8WXov1Fif+RNh/8Ar7W/9IoHoOk/v/gDqvn/AL37PfDyd/zeVkxZ256ffbp/ePqa4quz+GB+2tr3h/7n26yP7/r5eMp93v8A63PUdPfjjpI5IZnhmjaORGKsjjBUjggjsaeHdpzh53+9Hdn6dfL8vxi25HTfrTk+vnGUfTa7s7NooorqPkwq3ZX8+n+bJasUmdDGJB95AeuPQkZGfc1UopNJqzKhNwfNF6naeH4NPtPDJuVONRuFc+cThkiBK7I+wLYbcx5C8DqasTXdtaJFbwWEEl3KikLtDBCRk7ieoFek+DP2Z/iX4s+EEHiuA6dafumudNsZ3Zbm6iPzA8DagbkruOSDngEGvPbT4e/EfxH4xOh6Z4V1SfV4oXZrZYjGY0XqxZsKADgZzySAM5rhlOLm7S2Pap1pRw8YqnZ9+/8AwTovDHwQ+JvxTtBfeF/D1tPbW8gR75nW0tyQRlAzcOR32g4746Va8ZfD7xV8NPG1lo3jSGC3kktXmtp7SXzoZ1L4kEb7eWXADAgEfQgn7O8KfEfQfD3w6sPC2paJqHgyWwt4LT+zrmIfaFjeLAlhWMtv2vy2MnqTXzN+0p8S/wDhLbTTNNW1axnhvjerbzwMs8Unk+XM6t0RHcKwTJJ+8QoxnkhXlUly20OmNOWHbq200vfrqn+h5ZczvZRJIGRDBiULIQCWI5xjr245xSWYgl8NRpLCoMVspQiVyNzKBuA3FQfU49qy7HUkmdZNRXYEVgUXC5BBxtyQOuKhaaVNPh+ZZPKXlFwevLEV1KD7kzzCm04xhda2vZ7pLtpa3Tt56J4duN1vGZuZWnkjx6AZJ/M/0rrNXh0e40vSNTS602NrdT/aNneXA8y4dJTkonLsHiK9AACD0rgtEn3a84U/u8vMv/AgBXXadqKfaJgsKTxErHKjKx3HPG0p8wIPcZ6kEGremplg5OaVO+7t8turS+9nHR65qXh/xJKtreTz20MxCxXG4CRM8ZU8qSMH1Ga6648ZWei32qa1p6x3FzfR26W8cnRAI9zMwHoSBjufpXL+LIY7i4k1OMRRss32aSKIkqoC5jwSASQo2nIByucc4HMVpKhCraRNHN8ZgOaipap6X1s7NafJ/fqekaf49k8SWU+g+JI7cPcD/RbqNdgSUcqGHTBPGR0zz7edTIY7h4ypUqxGD1FMBIORTpJHlkaSRizMcknufWrp0VTb5dmcmNzKtjoxeIfNKOl+rXZ+n6ja7fS/3HwJ1+4h/dzPdLE0icMyZiG0kckYZhj/AGj61xFdv4yjk0j4W+HNCmjYySs10zONhjOCShX1/fYz/s9OeM8U78kO7/LU9vhdOjTxuNfwwoyV/wC9UtCPp8Tfytpe555RRRWx8mFFXodPTylkvLgwhhlURN7kHoSMgAH656HGDmpPsWm/8/11/wCAy/8Axyq5WK6M2itL7Fpv/P8AXX/gMv8A8co+xab/AM/11/4DL/8AHKOVhdGbRWl9i03/AJ/rr/wGX/45R9i03/n+uv8AwGX/AOOUcrC6M2itL7Fpv/P9df8AgMv/AMco+xab/wA/11/4DL/8co5WF0ZtFaX2LTf+f66/8Bl/+OUfYtN/5/rr/wABl/8AjlHKwujNorS+xab/AM/11/4DL/8AHKPsWm/8/wBdf+Ay/wDxyjlYXRm0VpfYtN/5/rr/AMBl/wDjlH2LTf8An+uv/AZf/jlHKwujNorS+xab/wA/11/4DL/8co+xab/z/XX/AIDL/wDHKOVhdGbRWl9i03/n+uv/AAGX/wCOUfYtN/5/rr/wGX/45RysLozaK0vsWm/8/wBdf+Ay/wDxyj7Fpv8Az/XX/gMv/wAco5WF0ZtFaX2LTf8An+uv/AZf/jlH2LTf+f66/wDAZf8A45RysLozaK0vsWm/8/11/wCAy/8Axyj7Fpv/AD/XX/gMv/xyjlYXRm0VpfYtN/5/rr/wGX/45R9i03/n+uv/AAGX/wCOUcrC6M2itI2FiwxHqEobsZoNq/iVZj+hqhNDJBM0Uq7XXqOv0IPcd896TTQJjKKKKQzoPiZ/yVLVP+2X/olKKPiZ/wAlS1T/ALZf+iUormofwo+iPf4o/wCRzjP+vtT/ANLYfDP/AJKlpf8A21/9EvXP10Hwz/5Klpf/AG1/9EvXP1UP4svRfqLE/wDImw//AF9rf+kUDV8N6v8A2D4qstVKb0hf51xklCCrY5HOCcc9cV0XxD0htM8aTzpFtt7z9/GwyQWP3xk992TgdAw+lcRXpmnf8Vn8JnsQm/VNFx5WFyzx4+VRhe6grtHJKKSeamq/Z1I1emz/AE/E9PIY/wBp5fiMo+2v3tPzlFWnHveUNUu8Tz+iiiu0+OCvb/2Z/gnJ8WviT9r1e3k/4RbR2WbUH5UXDHlLZT6tgliOiBu5FeUeGvDGteLfFum+G9DsnudQ1GYQ28eMBiepJ7KACSegAJPSv1N+F/gfRPhd8L9O8IaOVkW2UyXN1jBurhseZKfqQAB2VVHauPG4n2MLLdnXhMO60vJHXw2lrp8XmsRHFCuQqfKiKo6ADjAAwB2xXn3w7tVvpdd8SW8eY7y/e2gOfuxQk5A9P3jy5919qzvjt8VLD4efCjUr15Ve+miMNrbg/NLI3CIB15P6Bj2ruvh5oDeEvhP4e8O3DGW6srCNLmQ9ZJ2G+Zj9ZHc14FrRbPoXN00l1f5f8P8AkakkGmwW9vcaxHZmYusMbugPzOcBFzzyeKp+LfA3hLx54Ul8PeKNDtNRsH5EbrtaJuzxuPmRh/eUg/UcVxXxe1wWj+F7CK5EVxNqgmQbsE+XFIwx69M/hXV+GvFMOs6YspZUuUwJox2PqPY0leNmip4eUqXtHsfDHxq/Z28QfCe6fXNEgOv+E2fAuHiBuLIk8JMB1HYSKME8EKcZ8di1q1vNLuLSPEDSBXhYAcSLyoyOxBI/Gv1L8apZ6t8NfEFheBWhl024Vs9B+7Yg/gQD+FfmH4n0CytPEOfNWBbxUkR+ghlbPysOylgQe4OPWvSoYh1FyzFhMDJJ1qbWj5Wns1JNfLtfu1scjBdmDUpZ0Xy3nj24HG05yePXmuhsLn7DopuO5beg9T0X+Vc3dW841VYbyMRXSyMrj+6T/wDrrcaB55I4iQkEYwMdTXfujxE5UajitGn6MsERaylzFeSZnvXV45d2Akw3bS3sxbb7de1cdJG8UzRSIyOpKsrDBBHUGu6TWdNt/D97pv2fzgi7k29FJznJ78gHjvmsLWYPt3iWTzNyzGOPzvLQvmXy138D3zn3zWlGbs01sdWb0o1JU8RCV3UV2uz2e/d6mBRViSznht1lkCruO0JuG7/vnqKr9Ditk09jxZRcd0bHhbSG1zxXZ2PleZDvDzg5AEanLZI5GRwD6kcipfiHq/8Aa/jy62ptjs/9DTIwTsJ3E8n+Itj2xxmuk0X/AIo74ZXfiWRNmo6hiGz3LygOdp5U46M/PDBUrzKuSL9pVc+i0X6n1+ZR/svJ6OA/5e12qs/KKuqcX63crdLruFXNLjSTVE8xQ6ory7WGQxRCwBHcEjn2qnV7SP8AkJn/AK4Tf+imrpjufGvYezM7s7sWZjksTkk+tJRVrTNOu9Y1uz0nT4jNd3k6W8EY6u7sFUfiSK1EVaK9i8f/AArtNL8TeG4LXTb3wtpl7dvo095rMUsSvLC4BvP3uMJKjo4GQoIcAgDjOuvhhY2qSWr6jc2MT6nptoNQ1ywFmyJcLd7nQpcyRNF/o4+Yk5IwGQK28A8uor1aD4f+ENLm8V2/iK78TwxWWhw39rdTaPEkis19BCZI41vCkq4fYDvwd7ngxqGoa/8ACy38P+BX1i68XaV/akdrBdvpZurTeyzBCERVuDMZAsgYhoVGFYhjxkC55xRXe+Nvh9pnheLXP7L8TS6tLoesjRr9ZLD7MBI3nFGjPmNuH+jyBshcHGNwOau6D4Q0HXPgU1xFasviqXUb1rOcStieK2t7aR7bZnbuKzSupA3ExhedwoC55rRXtF58HNO1fx14nsNKv5NGS31i7sNLt7j7P9nmEXIQSTXSzOwyAQkUhGVJJzgctpfw70y90S3e88TyWurXOjXmuQWKWBkjMMEczhGl8wYd/IbjaQFOck/KQVzgKK9C1b4YjT/hgfFcOryfaYIbae70y8S2iljSbaFZUjuZJduXXBkijyGB9q1fhR8Mz4x8PajfXHhvVNVW7nGj2M9nFKyWNw8bP9plKcBEbyVIf5dsrH+HIB3PKKK6rxXodpo/hTwjPHZtb3t7YXEt9uZstKl9cQjIJwpCxouBjp65NdNqfgNm8D6NY6F4Zgu9Xe2juNSulvW+0WUkm6RBOhbykgaAxsGwMEkM4IK0AeX0V3vwt0XwxrN/4hXxXBus7fSd8c/mun2SWS7t4BP8pG7YJmbacg45FdPe/C7SotJ8J+FZIvsPie616PSdWv8Ac0oieZUdUEe4KfLWRM4wS24E9MArnjdFeg+B/C9rLY22v3vk3UV5aeIbcWk0AZY3tdK85JQSTk7p1I4G0xgg5PGn4j8FeEo31NPDV1cPLa+GNN1KWLULXyUjkn/s8b45RckbnN07NvXYmWVQfldAZ5XRXq/hHwloOmeF/E934uTwfPdWV1YQwXGo6hdXdmizLcsyh9Ldiznyk6kgbTnBPJp3hHwZceE73WNelkso5PDh1W3fSLOSfyW/to2m7bNcrvOwBADtGx8kb03SArnlFFdfe+Bvsba4Bqm8aXodjrWfIx5v2k2n7r73y7ftn3uc+X0G7it488NaV4Q8bah4a07XJ9Wm066mtLqZ7MWyB43K/J+8Yt05yBg5A3DkgzmaKKKACiiigAp9yol0TzG+9BMqKf8AZcMSD7Arkf7zetMqSX/kX5/+viL/ANBkpPYDLooorIo6D4mf8lS1T/tl/wCiUoo+Jn/JUtU/7Zf+iUormofwo+iPf4o/5HOM/wCvtT/0th8M/wDkqWl/9tf/AES9c/XQfDP/AJKlpf8A21/9EvXP1UP4svRfqLE/8ibD/wDX2t/6RQCtjwxrF9ofie2vrCF7iTPlm3Un98rcFOOp6EdeQDg4rHrvvhR4yuPBviua6tbCyvHuIxE8VzCrl485ZFY/dzx064weOK1lFSTT2PKweIq4evCtQdpxaaa6NbCeOvDUenXK65piRrpl24AjVShhkxkqVPIzgnGBjkEDAzg6Lp8d3qCyXjpFZxZeWSUNsIH8OVHUnA/HtXtPjPTGn8KXvjT4fTSv4Ynfff6XEoWTSZRg7Xj5xGDyrrjHGeMGvM7e0udVmItWvb0KS7LFyenJwOnucVnCThHlk7+Z6eZzo47Fyr0KfJzauK2UuvL2T3S6bbI6ceI7vTNb0m48P31zYtp4We2ngnO2PaclUwQBkZBB6gnO7NfW/iL9pTwXpfwqi8aJdsqXIZI7RgDP5w6whM8sMjJ+6AQScEZ+FQX09ntUtn/eEYHqemDx64OB/SuP8RXcd1qEdtFIJ3hyrTq2Vck9B7Dpnv8ATFc1bDxqJN9A+vypScnFXfyS7WXp/Xf3HwX4l8R/tC/tfeET4mDro8eofbEs85ijhh/euMn77N5YUnvkAADAr9IZ9UWGKSWd9mAWcnjHc1+XU62OleHV0+S0eO7tZTFH5JLRqgYnIkU8/MSemepz2r0a2/aB8fWHwri8IJFBdCC2aFNallkeVF5KyP1BKggDJ/hX0rCthnOyj0OilaDcqsuZtJtrW3l6/ge6+MdbtfFfiW/17UJxBpWno0VpcMceSVOXnBPTBUKD32v1BqH4dfECHxJoMeu6RP5VzC5huYsYKOPVf7rDDD2OOoNfFw8X6vc+GoNButTuzZwZMcMs7tDnOeU9c8+nsKs+DfG2reC/EkmqabqBjeZDHMhTzY5R2DpkZwcEEEEH2JqpYCXLbqd1POMP7qT0e/kfcfxW+KlpYfCPUNPbEGqanH9it0LZRskb2652hc5+oGeRXxv4g1S31c3rX6tLd8IJGkzuO92fDd/4QM88nFZfiTxXrfim/fU768lvp2G0TEACNf7qIvCD2/Hk1z5mnMPlPwoGMnitsNh5Uo2b3OPMsVhnyqkrtPV30t27ed/kOvZJL8R39wN1xERHNzyw24yT69D9SaZ9puDi0spJZNx2kP8ALs9iT39qSK7t4La7VvneSMKgHTdnqfoM/jiup+FXhuP4gfFrRfCd/qy6bFe3GGvCFygCsxAB4LNwBn8j0rpceSLfRHnYissTUjL7Ut/W9vx0MH7JdWMMayLA++UMMMc5XkDOO+KvW1hqtrc/aYlWZiMsefnB5zz+dff+i+A/gV4QvtQ8IxeDLdtStLNriXUdZtUuGuNoJAEsoYHdjgKAMZHBGK+W/wBpvw78O/Det6XcfDywt9Flk3C6tbW4f58jcHCE/KF+7xgdPSuSliVUlyR0udcqShDmrxcklpZ2svu13PNxJb3Ugju4TFN1U9CD7MKo2vhywn8UW8d/drDbb2nnluGIEiA5K5GNp4OTkcc9sVS0SXWNTWdNhngt4/MeeTjyv7vzdySMY+voa0Ly53Il0zKVBVEGPvHdyfcYyPxNdGt3G+pnBQw8qeI5Oam3fll1s9V5p2s2vNdGYPjLxCuv6/8A6KixadaL5FpFHkLsB+9tOME8cYGAFHbNc7UlwIxdSiLPlhyFz6Z4qOtoQUIqK2PPzDHVsfiJ4qu7zk7v/JdktkuiCr2kf8hM/wDXCb/0U1UafDLJBcRzxNtkjYOpxnBByKtOzONl2rukavqGhazBq2lXH2e8gJMUuxWKEgjIDAjOCcHqDgjBANV4xBdrvglhhf8Aihlk2bfdWbgj2zn64yX/AGOT/nvZ/wDgXF/8VWpJd0zxJq2kWL2NnLbvavcxXjW91axXMbSxh1RikqsDgSOCMYOeQcDGpdfETxXehI7m6097aOWGVLL+zLUWqtD53lgQCPywoNzOSu3DFySCcEc99jk/572f/gXF/wDFUfY5P+e9n/4Fxf8AxVAtDoR8RfFY1n+0vtVhuFobD7L/AGZa/ZPIMnmeX9m8vydvmfPjZ97nrzVa98aeINS8OJomoS2F1bpGkKTTadbPdJGhGxFuTH5yqAAAA+Nvy9OKx/scn/Pez/8AAuL/AOKo+xyf897P/wAC4v8A4qgNC/qPijXdWOrnUL7zv7Yv11O+/dIvnXC+bh+ANv8Ar5eFwPm6cDCWPibXdMttNgsNQeBNNvm1K02KuYrhhGC4OMniGPg5Hy9OTmj9jk/572f/AIFxf/FUfY5P+e9n/wCBcX/xVAaHWQfFjx7bajc38WtQm6uLyW/ad7C3d0mlx5jRs0ZMYfADKm1SBgir2ifFB9E+G8/hyLTrm4vZLO50+O7uJ4WjggnDB0RRB5wGHc7fOKbju25rhfscn/Pez/8AAuL/AOKo+xyf897P/wAC4v8A4qgNDfvfiD4t1DwzLoF3qUL2M0MMEwWzgSSdIivlCSVUDuV2KAWYkAYzgkVjzazqdxpWn6bJdH7Lp5ka1jRQvls7BmbIAJJIHJycADoBUH2OT/nvZ/8AgXF/8VR9jk/572f/AIFxf/FUBoaPiHxVr3iu7iudevVupYvN2MIY4seZM8z8IoBzJK7f8C9MCta2+J/jazsI7SDVYNqW4szI9hbvLJbhdogklaMvJFtAHluSuABjgVzH2OT/AJ72f/gXF/8AFUfY5P8AnvZ/+BcX/wAVQGhLY6tf6da6hb2U/lRahb/ZLpdinzIvMSXbyOPniQ5GDxjoSKnsvEet6dZWlpY3728VpejUbfy1UNHcAKBIGxnI2rxnHFU/scn/AD3s/wDwLi/+Ko+xyf8APez/APAuL/4qgLo6K9+I3i+/Nv5+o26LbpdpDHbWNvBHGLuEQ3GEjjC/OgweODlhhiTVa58b+JLvRf7KnvLdrc2K6a7LZwLLJbq8TpG8oQO4U28O3cxKhcDAJBxvscn/AD3s/wDwLi/+Ko+xyf8APez/APAuL/4qgNCWHVtQt9Au9FhuNtjeTRXE8OxTveIOIznGRgSycA4O7nOBjT03xt4k0r7KtreW7R21k2nRwXNnBcRG3adrgxvHIjLIPNYv8wJBxjoMY/2OT/nvZ/8AgXF/8VR9jk/572f/AIFxf/FUBobs/j/xZc+FpfD02oxNYTWsVlKotIRJLDE6PGjyhN7BDGm3LHaBtGASDjatql/rmv32tapP599fXEl1czbVXzJHYszYUADJJOAAKj+xyf8APez/APAuL/4qj7HJ/wA97P8A8C4v/iqA0K9FWPscn/Pez/8AAuL/AOKo+xyf897P/wAC4v8A4qgLleirH2OT/nvZ/wDgXF/8VR9jk/572f8A4Fxf/FUBcr1JL/yL8/8A18Rf+gyVIbXYN0t3Zog6sJ1fH4IST+AqjeXSzBIYQRBGSV3feYnGWPpnA46DA68kqTsh7lWiiisijoPiZ/yVLVP+2X/olKKPiZ/yVLVP+2X/AKJSiuah/Cj6I9/ij/kc4z/r7U/9LYfDP/kqWl/9tf8A0S9c/XQfDP8A5Klpf/bX/wBEvXP1UP4svRfqLE/8ibD/APX2t/6RQClVmRw6MVZTkEdQaSitzwTuvDnxF1XStWhuUnFtMAFkmjBCzjp+8XOD9cdzkHJrtRp1n4lkl/4RrVE8PvMxkks7aIeWZCcg/KQwTPQDIHYDpXiFaGn61qOmSI9pcumw5UZPyn29KnlVrWOuli5xqc8pPXe2jfzOq8VXPibw5pt9a63d3QllTyY2L7lnLcblbHICg88EcA4rktC0IRbNQ1BBnb5kMDoHB/2pFJHy+2Oc9h19f05fEPjHwrZeJJIbHUbiEyJHaxtmWELjdIsTcNIcdVJYKBgDOa5XULu2mjLC3aaUHf5ao+5j9MZz+tYuNnsdlaSrS53Ucktr7/n+RmQRS3MTSGSWIH7oiLKJD64PQc89P61avpbyDQLyCa/lSV0UtZxZCIu4DMmcfMcjCgcA8ntXQaXpmvpb3VzHZvpDPtSG7vUMZjjJyzKpGcgcDA7k5HWs3xBD4R07w7dR2msXGp6rPhQXOQvzgljt4zgdyetOMW2rm3u06LnB6tPrZW276vy6J9ThKKKK6zwhVZlOVJB9RSs7N95ifqc02igArdsvDl19jTUb27j0+MrvgVsmaXuCkY5xnGGOB71n6ZNa2t4Lq6jEoj5WIjIZu2R6CuktrbxD4qvhcW2i+Ysv/L1c7hFtB2k54Bx6DJ4PXFY1ZuPku562WZe8XLlgnOb2jFNv1dk9Pu9UTSeMfiLd2UNldeMtRWKGJ4FEl8d3lsQWQkHcRwOCeKy7iyF7d3VzfX9zeTyjKyys8khPHLHB3enWuhfSPBnhCQT+I7xdQ1EYb7BajKoflOCuffPzkBgfu1x3iHxZf69IkYiisbOIFYrW2G1QueN394gADsOOAMmuenPnf7uOnfb/AIc9bMcmWW0mswrr23Smnztf43flh6avyRum/wDsmnraQK8NmucJI4iVicDL9N7YHJx+FYOo6vEWfyZPOmYYDqCEjH+znqfesEkk5JorZU0jwK2NlVte7a0V3ey7LZL7tOgUUUVocQUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAdB8TP+Spap/2y/wDRKUUfEz/kqWqf9sv/AESlFc1D+FH0R7/FH/I5xn/X2p/6Ww+Gf/JUtL/7a/8Aol65+ug+Gf8AyVLS/wDtr/6JeufqofxZei/UWJ/5E2H/AOvtb/0igFFFFbnghRRRQBo6Tr2saHcGbSdRntGPXy24P1B4NdW/xj+Ib2LWreIJdrLtLhFDY+org6KB3aOl0zx74m0y/e6W/wDtPmHMkVyN6McH6Edc8EZwM5refx34Y1pwfE3hNTJtDPc2j/PI4AH+yduM8FjjA69R55RWM6EJvme/daHvYDifMMFR+qwmpUt+ScYzj90k7fK3Xuz0P7L8Kpx5/wDbmp2vmfP5Gxj5WedufLPTp1PTqetL/wAIR4b/AOig6V/5D/8Ajted0VPsZr4aj/B/odn+sOCq/wC85dSfbldSHre07Py2t0PRP+EI8N/9FB0r/wAh/wDx2k/sv4YQHybjxTfSTR/LI8MZKMw4JXEZGM9OT9TXnlFHsqj+Ko/wX6B/rBgKWuHy6mn/AHnUn9yc1Y9Dj8ZeCdImSbQvCDzSFgzPeSAGMrypQkvg8npjoOvbF1f4h+KNX2L9t+wxrg7LHMWTzyWyW79M44HGa5ainHDU0+Zq789THE8W5nWpOhTmqVP+WnFQX/kqTffVsKKKK3PmgooooAKKKKACtfwqtk/jjSE1GFZbVryJZEYgKQWA+bIIK+o7jI4zmsiihAz1/RNNFn4o1RLeC+02CLXLL/Q5dhWQGZ8MP3YIXHKgHGD1aq1r4c0W1+Ktj59rJqdtf/am+0yMht3l2ufLCFTyp+XDEHdg4GMHymitOfyI5PM9A0fwRpmpQrJcQ6rbNJdvbyxmRM6aqqCHnygzk+yfXNXb7QbTUPhXo9z5s13cWVnOYrW1YKzr57ZlOQcouOQBnkdBzXmVFLmXYfK+52On+C3SDVU1Wxv7rUrCSOP+ytPlTzSHGd+Qr5UDHQHr2qzaeC9LuPC6ag894pezmuXu96+RbSISBA425LHHqDzwDXC0UrrsFn3PRpfB3hW10aa6n/tiSS20+0vZNlxGquZiFKqDGcAE5yc1XvvCunaPrh0GUmYXmrLbxSuB5ghQAtg44LNIq59UNcDUjXE7JEjTyFYRiMFjhBnPy+nJJ47mnzLsHK+56Zd6Rp1x4MlupdKhgiEEcizxxRxpGWgkk+Vwu9irokZDs2ST0JGM+78F6AukSeRc38N3DptrqEk00iNF+9YBl2hAQBnOd1cle+INW1C0a3u7iN1cgyOII1klI6b3Chn/AOBE1mUOS7CUWejax4F8OaTeWAkvtSa3lvo7aSYRvskjYf6xJDEEBB/hDPkd6XUfh7pGl6ReXN1qkwkslEFwNy4S4dozH25TZISe+VPIrziijmXYfK+56/ceEtOs/Ck+hBr2ys59at4jf3jqyTLsP7yPCgBTnHU9uetYg8B6Q2q6fBLLqFi1x9pzYXDobiTyhlCh2gDf2yPpmvO6KHJdhKL7nrGteGrS+t9ItprTUons9F82LS96/apW80/JnZ1GST8mcdqpWPw80W513UrBbm/na38rygpKIhZNzLLMsUiqynjkD+leaUUcy7ByvuegWXw/guvAt1rEplimhs5rtJY5/NifyyflIEQVcgf89Ce+MdNW28PafongTXJoodQuIJ9NtpJL7evkzbnVmSP5eCOnJPuB38qoo5l2G4t9T0ofD7w+mq2lrPrEyrqEjz2LB1/eWojDLnCk72ZtowP4WwDwKrSeDNAtdU1AXL6s1va6Ub8wFWgkDhwu3dLCu5f9oIP0rz6ijmXYOV9z05/DGh2GgeJrS30y81GZIrK6gIdDPHG6ljtIjOApzuIGCMfdxk0LjwFZx6FdatGb5rRNNtrqGfcpR5ZGAdc7eQMngcjjNcBRRzLsHK+56M3gnw1L451TQbafUU/s6IttlmDyXTfLwgSElQMnOFcnjgc1x/iXS7bRvE1xp9nLcSQx7SpuYXhkGVBwyuqnjPXAz171k0Um0+gJNdQoooqSgooooAKKKKAOg+Jn/JUtU/7Zf+iUoo+Jn/JUtU/7Zf8AolKK5qH8KPoj3+KP+RzjP+vtT/0tmN4d1ZtD8VWGqhnCwTAybFDMYzw4APGSpYfj2rV8W6NFonieWC0dHsZ1FzaOjBlaJ+VwcnIHIyTzjPeuXro9C1qwe2j0HxKJZNK8zdFPF/rbJieWTg5Q/wAS4P8AeAyOXK8Zc6+f9eRGBrUsRhnl9ZqLcuaEntGVrNPtGaSu+jjG+l2siiurfwJe3jCTwxqFjrtuVVi0EyRyRggEeYjN8pPzYGSflOcdKb/wrjxn/wBAb/yYi/8Aiqr6xS/mRT4Xze/uYWcl3jFyi/SUbxfqmzlqK6n/AIVx4z/6A3/kxF/8VR/wrjxn/wBAb/yYi/8AiqPrFL+Zfehf6r5z/wBAdX/wXP8AyOWorqf+FceM/wDoDf8AkxF/8VR/wrjxn/0Bv/JiL/4qj6xS/mX3oP8AVfOf+gOr/wCC5/5HLUV1P/CuPGf/AEBv/JiL/wCKo/4Vx4z/AOgN/wCTEX/xVH1il/MvvQf6r5z/ANAdX/wXP/I5aiup/wCFceM/+gN/5MRf/FUf8K48Z/8AQG/8mIv/AIqj6xS/mX3oP9V85/6A6v8A4Ln/AJHLUV1P/CuPGf8A0Bv/ACYi/wDiqP8AhXHjP/oDf+TEX/xVH1il/MvvQf6r5z/0B1f/AAXP/I5aiup/4Vx4z/6A3/kxF/8AFUf8K48Z/wDQG/8AJiL/AOKo+sUv5l96D/VfOf8AoDq/+C5/5HLUV1P/AArjxn/0Bv8AyYi/+Ko/4Vx4z/6A3/kxF/8AFUfWKX8y+9B/qvnP/QHV/wDBc/8AI5aiup/4Vx4z/wCgN/5MRf8AxVH/AArjxn/0Bv8AyYi/+Ko+sUv5l96D/VfOf+gOr/4Ln/kctRXU/wDCuPGf/QG/8mIv/iqP+FceM/8AoDf+TEX/AMVR9YpfzL70H+q+c/8AQHV/8Fz/AMjlqK6n/hXHjP8A6A3/AJMRf/FUf8K48Z/9Ab/yYi/+Ko+sUv5l96D/AFXzn/oDq/8Aguf+Ry1FdT/wrjxn/wBAb/yYi/8AiqP+FceM/wDoDf8AkxF/8VR9YpfzL70H+q+c/wDQHV/8Fz/yOWorqf8AhXHjP/oDf+TEX/xVH/CuPGf/AEBv/JiL/wCKo+sUv5l96D/VfOf+gOr/AOC5/wCRy1FdT/wrjxn/ANAb/wAmIv8A4qj/AIVx4z/6A3/kxF/8VR9YpfzL70H+q+c/9AdX/wAFz/yOWorqf+FceM/+gN/5MRf/ABVH/CuPGf8A0Bv/ACYi/wDiqPrFL+Zfeg/1Xzn/AKA6v/guf+Ry1FdT/wAK48Z/9Ab/AMmIv/iqP+FceM/+gN/5MRf/ABVH1il/MvvQf6r5z/0B1f8AwXP/ACOWorqf+FceM/8AoDf+TEX/AMVR/wAK48Z/9Ab/AMmIv/iqPrFL+Zfeg/1Xzn/oDq/+C5/5HLUV1P8Awrjxn/0Bv/JiL/4qj/hXHjP/AKA3/kxF/wDFUfWKX8y+9B/qvnP/AEB1f/Bc/wDI5aiup/4Vx4z/AOgN/wCTEX/xVH/CuPGf/QG/8mIv/iqPrFL+Zfeg/wBV85/6A6v/AILn/kctRXU/8K48Z/8AQG/8mIv/AIqj/hXHjP8A6A3/AJMRf/FUfWKX8y+9B/qvnP8A0B1f/Bc/8jlqK6n/AIVx4z/6A3/kxF/8VR/wrjxn/wBAb/yYi/8AiqPrFL+Zfeg/1Xzn/oDq/wDguf8AkctRXU/8K48Z/wDQG/8AJiL/AOKo/wCFceM/+gN/5MRf/FUfWKX8y+9B/qvnP/QHV/8ABc/8jlqK6n/hXHjP/oDf+TEX/wAVR/wrjxn/ANAb/wAmIv8A4qj6xS/mX3oP9V85/wCgOr/4Ln/kctRXU/8ACuPGf/QG/wDJiL/4qj/hXHjP/oDf+TEX/wAVR9YpfzL70H+q+c/9AdX/AMFz/wAjlqK6n/hXHjP/AKA3/kxF/wDFUf8ACuPGf/QG/wDJiL/4qj6xS/mX3oP9V85/6A6v/guf+Ry1bnhLRotb8TxQXboljApubt3YKqxJy2TkYB4GQeM57VfTwJe2bGTxPqFjoVuFZg08ySSSAAk+Wit8xHy5GQfmGM9Ky9d1qwS2k0Hw0JY9K8zdLPL/AK29YHhn4GEH8K4H94jJ4mVVTXLTfz6I3w+Uyy2ccVmkOWMX/DlpObWtnH4oxfWTSVvhu7Iz/EWrNrniq/1Us5WeYmPeoVhGOEBA4yFCj8O9FZlFXFKKSR4eJxE8TVnXqu8pNtvzbuwooopmIUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB//Z",
	"sedih": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwMDAgQDAwMEBAQFBgoGBgUFBgwICQcKDgwPDg4MDQ0PERYTDxAVEQ0NExoTFRcYGRkZDxIbHRsYHRYYGRj/2wBDAQQEBAYFBgsGBgsYEA0QGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBj/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4PoorvbKyX4dpZ6vq+nJceI51W4s7C6Q+VZx5IEso4zISCFQH5Mbj82APRw2GdZtt2it32/zb6Lr6XaxlKxj6R8PvGeuW32jTvD900O1XWSbbArqwyChkKhhjuM9vUVo/8Ki+If8A0L3/AJNwf/F0/Tn1v4leO7LTNa12YvPv2Sum5ItsZY7YwVUZ2AHGM9Tmu6/4UH/1Nn/kh/8AbK97BZPHGQc8NRnOKdr88I6+ji7b936mUqji7NnBf8Ki+If/AEL3/k3B/wDF0f8ACoviH/0L3/k3B/8AF13v/Cg/+ps/8kP/ALZR/wAKD/6mz/yQ/wDtldn+rNX/AKBZ/wDg2n/8iT7dd/wZwX/CoviH/wBC9/5Nwf8AxdH/AAqL4h/9C9/5Nwf/ABdd7/woP/qbP/JD/wC2Uf8ACg/+ps/8kP8A7ZR/qzV/6BZ/+Daf/wAiHt13/BnBf8Ki+If/AEL3/k3B/wDF0f8ACoviH/0L3/k3B/8AF13v/Cg/+ps/8kP/ALZR/wAKD/6mz/yQ/wDtlH+rNX/oFn/4Np//ACIe3Xf8GcF/wqL4h/8AQvf+TcH/AMXR/wAKi+If/Qvf+TcH/wAXXe/8KD/6mz/yQ/8AtlH/AAoP/qbP/JD/AO2Uf6s1f+gWf/g2n/8AIh7dd/wZwX/CoviH/wBC9/5Nwf8AxdH/AAqL4h/9C9/5Nwf/ABdd7/woP/qbP/JD/wC2Uf8ACg/+ps/8kP8A7ZR/qzV/6BZ/+Daf/wAiHt13/BnBf8Ki+If/AEL3/k3B/wDF0f8ACoviH/0L3/k3B/8AF13v/Cg/+ps/8kP/ALZR/wAKD/6mz/yQ/wDtlH+rNX/oFn/4Np//ACIe3Xf8GcF/wqL4h/8AQvf+TcH/AMXR/wAKi+If/Qvf+TcH/wAXXe/8KD/6mz/yQ/8AtlH/AAoP/qbP/JD/AO2Uf6s1f+gWf/g2n/8AIh7dd/wZwX/CoviH/wBC9/5Nwf8AxdH/AAqL4h/9C9/5Nwf/ABdd7/woP/qbP/JD/wC2Uf8ACg/+ps/8kP8A7ZR/qzV/6BZ/+Daf/wAiHt13/BnBf8Ki+If/AEL3/k3B/wDF0f8ACoviH/0L3/k3B/8AF13v/Cg/+ps/8kP/ALZR/wAKD/6mz/yQ/wDtlH+rNX/oFn/4Np//ACIe3Xf8GcF/wqL4h/8AQvf+TcH/AMXR/wAKi+If/Qvf+TcH/wAXXe/8KD/6mz/yQ/8AtlH/AAoP/qbP/JD/AO2Uf6s1f+gWf/g2n/8AIh7dd/wZwX/CoviH/wBC9/5Nwf8AxdH/AAqL4h/9C9/5Nwf/ABdd7/woP/qbP/JD/wC2Uf8ACg/+ps/8kP8A7ZR/qzV/6BZ/+Daf/wAiHt13/BnBf8Ki+If/AEL3/k3B/wDF0f8ACoviH/0L3/k3B/8AF13v/Cg/+ps/8kP/ALZR/wAKD/6mz/yQ/wDtlH+rNX/oFn/4Np//ACIe3Xf8GcF/wqL4h/8AQvf+TcH/AMXR/wAKi+If/Qvf+TcH/wAXXe/8KD/6mz/yQ/8AtlH/AAoP/qbP/JD/AO2Uf6s1f+gWf/g2n/8AIh7dd/wZwX/CoviH/wBC9/5Nwf8AxdH/AAqL4h/9C9/5Nwf/ABdd7/woP/qbP/JD/wC2Uf8ACg/+ps/8kP8A7ZR/qzV/6BZ/+Daf/wAiHt13/BnBf8Ki+If/AEL3/k3B/wDF0f8ACoviH/0L3/k3B/8AF13v/Cg/+ps/8kP/ALZR/wAKD/6mz/yQ/wDtlH+rNX/oFn/4Np//ACIe3Xf8GcF/wqL4h/8AQvf+TcH/AMXR/wAKi+If/Qvf+TcH/wAXXe/8KD/6mz/yQ/8AtlH/AAoP/qbP/JD/AO2Uf6s1f+gWf/g2n/8AIh7dd/wZwX/CoviH/wBC9/5Nwf8AxdH/AAqL4h/9C9/5Nwf/ABdd7/woP/qbP/JD/wC2Uf8ACg/+ps/8kP8A7ZR/qzV/6BZ/+Daf/wAiHt13/BnBf8Ki+If/AEL3/k3B/wDF0f8ACoviH/0L3/k3B/8AF13v/Cg/+ps/8kP/ALZR/wAKD/6mz/yQ/wDtlH+rNX/oFn/4Np//ACIe3Xf8GcF/wqL4h/8AQvf+TcH/AMXR/wAKi+If/Qvf+TcH/wAXXe/8KD/6mz/yQ/8AtlH/AAoP/qbP/JD/AO2Uf6s1f+gWf/g2n/8AIh7dd/wZwX/CoviH/wBC9/5Nwf8AxdH/AAqL4h/9C9/5Nwf/ABdd7/woP/qbP/JD/wC2Uf8ACg/+ps/8kP8A7ZR/qzV/6BZ/+Daf/wAiHt13/BnBf8Ki+If/AEL3/k3B/wDF0f8ACoviH/0L3/k3B/8AF13v/Cg/+ps/8kP/ALZR/wAKD/6mz/yQ/wDtlH+rNX/oFn/4Np//ACIe3Xf8GcF/wqL4h/8AQvf+TcH/AMXR/wAKi+If/Qvf+TcH/wAXXe/8KD/6mz/yQ/8AtlH/AAoP/qbP/JD/AO2Uf6s1f+gWf/g2n/8AIh7dd/wZwX/CoviH/wBC9/5Nwf8AxdH/AAqL4h/9C9/5Nwf/ABdd7/woP/qbP/JD/wC2Uf8ACg/+ps/8kP8A7ZR/qzV/6BZ/+Daf/wAiHt13/BnBf8Ki+If/AEL3/k3B/wDF0f8ACoviH/0L3/k3B/8AF13v/Cg/+ps/8kP/ALZR/wAKD/6mz/yQ/wDtlH+rNX/oFn/4Np//ACIe3Xf8GeY6v8PvGeh232jUfD90sO1naSHbOqKoyS5jLBRjucd/Q1zVeja/Za38KPF0VpoviKZnmtluHdItiNlnQBoyWVsYJBPTPGOtVr2yX4iJeavpGnJb+I4Fa4vLC1Q+VeR5AMsQ5xICQGQn587h82QfFxOXQU5UqScakd4tp/dJWTflZeTbNYz6vY4KiiivGNDpfh9pEOufE3R9OuNnktP5siyRiRXWNTIUKnghgm38eh6VD4i1u48R+Kb3Wrldr3Mm4JkHYo4VcgDOFAGcc4zWv8Iv+Sy6N/23/wDRElcrXpt8uAgl1nK/yjG33cz+8z+0TWl5d2F4l3Y3U1rcJnZNA5R1yMHBHI4JH41qf8Jh4t/6GjWv/A2X/wCKrForlhXqU1aEml5MbSZtf8Jh4t/6GjWv/A2X/wCKo/4TDxb/ANDRrX/gbL/8VWLRV/W6/wDO/vYcq7G1/wAJh4t/6GjWv/A2X/4qj/hMPFv/AENGtf8AgbL/APFVi0UfW6/87+9hyrsbX/CYeLf+ho1r/wADZf8A4qj/AITDxb/0NGtf+Bsv/wAVWLRR9br/AM7+9hyrsbX/AAmHi3/oaNa/8DZf/iqP+Ew8W/8AQ0a1/wCBsv8A8VWLRR9br/zv72HKuxtf8Jh4t/6GjWv/AANl/wDiqP8AhMPFv/Q0a1/4Gy//ABVYtFH1uv8Azv72HKuxtf8ACYeLf+ho1r/wNl/+Ko/4TDxb/wBDRrX/AIGy/wDxVYtFH1uv/O/vYcq7G1/wmHi3/oaNa/8AA2X/AOKo/wCEw8W/9DRrX/gbL/8AFVi0UfW6/wDO/vYcq7G1/wAJh4t/6GjWv/A2X/4qj/hMPFv/AENGtf8AgbL/APFVi0UfW6/87+9hyrsbX/CYeLf+ho1r/wADZf8A4qj/AITDxb/0NGtf+Bsv/wAVWLRR9br/AM7+9hyrsbX/AAmHi3/oaNa/8DZf/iqP+Ew8W/8AQ0a1/wCBsv8A8VWLRR9br/zv72HKuxtf8Jh4t/6GjWv/AANl/wDiqP8AhMPFv/Q0a1/4Gy//ABVYtFH1uv8Azv72HKuxtf8ACYeLf+ho1r/wNl/+Ko/4TDxb/wBDRrX/AIGy/wDxVYtFH1uv/O/vYcq7G1/wmHi3/oaNa/8AA2X/AOKo/wCEw8W/9DRrX/gbL/8AFVi0UfW6/wDO/vYcq7G1/wAJh4t/6GjWv/A2X/4qj/hMPFv/AENGtf8AgbL/APFVi0UfW6/87+9hyrsbX/CYeLf+ho1r/wADZf8A4qj/AITDxb/0NGtf+Bsv/wAVWLRR9br/AM7+9hyrsbX/AAmHi3/oaNa/8DZf/iqP+Ew8W/8AQ0a1/wCBsv8A8VWLRR9br/zv72HKuxtf8Jh4t/6GjWv/AANl/wDiqP8AhMPFv/Q0a1/4Gy//ABVYtFH1uv8Azv72HKuxtf8ACYeLf+ho1r/wNl/+Ko/4TDxb/wBDRrX/AIGy/wDxVYtFH1uv/O/vYcq7G1/wmHi3/oaNa/8AA2X/AOKo/wCEw8W/9DRrX/gbL/8AFVi0UfW6/wDO/vYcq7G1/wAJh4t/6GjWv/A2X/4qj/hMPFv/AENGtf8AgbL/APFVi0UfW6/87+9hyrsbX/CYeLf+ho1r/wADZf8A4qj/AITDxb/0NGtf+Bsv/wAVWLRR9br/AM7+9hyrsbX/AAmHi3/oaNa/8DZf/iqP+Ew8W/8AQ0a1/wCBsv8A8VWLRR9br/zv72HKuxtf8Jh4t/6GjWv/AANl/wDiqP8AhMPFv/Q0a1/4Gy//ABVYtFH1uv8Azv72HKuxtf8ACYeLf+ho1r/wNl/+Ko/4TDxb/wBDRrX/AIGy/wDxVYtFH1uv/O/vYcq7Fq+1LUdUuFuNTv7q9mVdgkuZWkYLknGWJ4yTx71Z8O63ceHPFNlrVsu57aTcUyBvU8MuSDjKkjOOM5rMoqI1pxqKqn7yd7+YWVrGz8QdIh0P4m6xp1vs8lZ/NjWOMRqiyKJAgUcAKH2/h0HSitH4u/8AJZdZ/wC2H/oiOitczhGnjK0IqyUpJfexwd4oPhF/yWXRv+2//oiSuVrqvhF/yWXRv+2//oiSuVrWf+40/wDHP8qZP2n8v1CiiiuAoKKKKACiiigAorT0Tw7rfiO8NtoumzXbr98oMInBI3OcKudpxkjOMCu4g+Dt/a28d14o8R6TolvIoAZ33sJCM+WclVzjd0Y9OMjmu/DZZisVHnpU2499l97svxJlOMd2eaUV6ifC/wAILX/Rr3xhqr3MYCyvDEdjMOpXETfKeo5PHc9aX+0/gtjP/CIaz/39b/4/XT/Y7Xx16a/7ev8A+kpk8/kzy2ivUv7U+Cv/AEKGsf8Af1v/AI/Tf7F+C1yftP8AwkWtWfm/P9m2MfJzzsz5TZx0+8enU9af9j3+GvTf/b1vzSD2nkzy+ivTj8HjqH/IseMdG1bZ/r8ts8vP3fuF+uG646d+3F674S8R+Gth1vSZrVHxtlyHjJOcLvUld3yk4znAziubE5Vi8NHnqU3y91qvvV0NTi9mYtFSvbzR28U8kZWOXOxj/Fg4P61FXnmjTW4UUUUCCiiigAqaztLi/wBRt7G0j8y4uJFhiTIG5mOAMngckdahre8Hf8jQ3/Xje/8ApLLWtCmqlWMHs2kJuyuXobbQdPj8kabFq0vSS4uZZUjJ/wCmSIUYDkjLkk4BwmStSefov/QpaV/3+uv/AI9VOvXvhv4L8Pa94Gsb3UdGtLye41t7Keaa8khkSAQB/wB0iyKHcHkAKxOTx3HqYaM68uSCiv8At1f5NnjZvm1LK6H1ium1e2luzfVpdDy3z9F/6FLSv+/11/8AHqPP0X/oUtK/7/XX/wAer1jwF4I8I6rpNnc6ppUt0G128tH8yWSJ3gjs2lVCFYbTuAPY9unFUPEXw606Lw7oH/CPx+fNrerNHZ3Zdj5ls6oYwy5wCu5g3AOVNb/Va3s/aJRt/hV+nl5nmLizBfWvqklJPu7W+1fW/Tkb2vb52828/Rf+hS0r/v8AXX/x6jz9F/6FLSv+/wBdf/Hq9A+JvhLw7pek2mseE4oFs4rmTTrryb5bsO68xykq7bC6hvlOMbegrn4fBHm/CG48df21ar5N2LX7AR87ZIGc5685246AnNZVKdWE3Dli7K/wx2+47sLn2FxGHp4m7ipy5UnvzN2Sdr2v62sc/wCfov8A0KWlf9/rr/49R5+i/wDQpaV/3+uv/j1dT4W0TSZPh94g8U3unf2tcadJBFHYmR0jUOTmWTYQxAxgYI561u+F9I8Da/pupXmr6DcaTLog/tG4treWVheWxX/VfO2UO8rhh/C3cjdTp0pz5fhV9fhXn/dt0ZGKz6lh/aNwlJU2otqz1aTStzcz+KKva13va7POfP0X/oUtK/7/AF1/8eo8/Rf+hS0r/v8AXX/x6vYtD8GeDNb8IaHM2i2cN/rFpqM8cMdxdeezxO/lrESxiCqoAPmcnA6nNcze6L4a0/4MeH9WNpoyanqNvdmSS+e9M0jJKUUwiI+UCBj7+BnGc81pLDVIx5nyWtfZeX93fVHLS4pw9Wp7GNOfNz8lrLf39fi+H93LXy9bcH5+i/8AQpaV/wB/rr/49R5+i/8AQpaV/wB/rr/49XrWueBvDVt8N5NRi0WGGSPw/Zagt1b3Uklw1zIQH3xF2Cxkc7tigc4PYUrjwh4dj+Dv/CZL4flGovYIv9mfaH2xZkKfb8b9+w44U/Lk9CtEsLVi2mo6K/wrb/wEmlxbhKkYyUZazUF8PxNJr7W2vy620v5l5+i/9ClpX/f66/8Aj1MfS9M1t0tdO09dO1GQhIEhldoJmzwhEhZlZicBt23hQVAJcVqK4fa30lFW9EvxSPqNTm639E0S2nsf7W1YzfYfMaCOK3cJJPIoUsAxVgiqHUkkHO4AD7zJF4w/5KHr3/YRuP8A0a1b8n/Io+Gv+vCT/wBK7ivOxUXRlKCezsc+NqyjGKjpzO34N/p/lqHmaB/0J2kf9/7v/wCP0eZoH/QnaR/3/u//AI/VSvYfhV8KNF8YeF59c1u7utpmaCKG2cLtwBlmJB554Ht3zXFzy7niY7E0cDS9tWnK3+KX+Z5T5mgf9CdpH/f+7/8Aj9HmaB/0J2kf9/7v/wCP11d94ItNN+OEfgm51Em0a7ii+0cBtjhWA9A2GA+tXtU8P6JceFvEl9FobaLNo2oRWsP72RvtSu7KUYOT86gBsrgYPSjnl3IeMo+5aUmpJNPmltJ2X2r7/d1OG8zQP+hO0j/v/d//AB+jzNA/6E7SP+/93/8AH69h8TfDzwlanxRf6RZEW2nWvleQ07k2tyGQ7uWyysj5GcjIb0FYw8IeHf8AhpS58K/2d/xKEEhW286TjFqXHzbt33uev6Uc8u5zUs1w9WDnFz0i5fE9kk39rf3l/meb+ZoH/QnaR/3/ALv/AOP0eZoH/QnaR/3/ALv/AOP16v4V8BeF9d8M+EHa0P8Aad08lxdoZnAu7dJzG4HzfKygoflxkBqybXQvDNp8O7zWLuz0gXKa5NYpJqkl4U8pYwwRRbnO7OeW9+elHPLuUszouTgudtO3xS7tfzeT/q5595mgf9CdpH/f+7/+P0eZoH/QnaR/3/u//j9VKKOeXc9b2X96X/gUv8y2W8PSKY38JafGrcF4Li5WRR6qWlZQ3oSrDPUHpXPa7oyacIL6yd5NPumdYTIR5kbrtLxvjGSu9PmAwwYHg7lXWqXUf+SaX/8A2E7T/wBFXNXTm72ZdOUqMotNtNpNNt7u3Vu1t/wOMooorpPaOq+Lv/JZdZ/7Yf8AoiOij4u/8ll1n/th/wCiI6K7c3/36v8A45fmxU/hQfCL/ksujf8Abf8A9ESVytdV8Iv+Sy6N/wBt/wD0RJXK1U/9xp/45/lTF9p/L9QooorgKCiiut8D+B7jxXeSXV1N9i0W0+a7vXIUAAZKqTxuxySeFHJ7A74bDVMTUVKkryYm0ldmFo2h6r4h1Qado1k91clS+xSAFUdSWJAA6DJPUgdSK9Mi8KeAPAeyfxfqP9taqm1v7OthlUPyHlcjOMk/OVDKfu5qjq3j2z0fQovDXw9WaxsY9wnvpFAmuWOVLA9RkYO7hvugBQuD57XrKphcBpTSq1O7+Fei+16vTsiLSlvojvNZ+K/iG9iFnoscOh2CR+UkFqoLBdoGN5Hy4wcbAuM98A1ylumoeIfEMUU93JcXdy6o09xIWPTGWY84AH4AVnV6NpHhPVjd6ZoHhjTX1PxHqJ8kRW53v5jE/u+wQIFJYngYJJwK8/GZhiMT71abf5fJbL5G1GnDmV1p1Oa8atZN44vG08A2oKpGRxlVUKD+IUV658NdGjurGL/hLv2d01Pw7KNratbSXdncqCPvxvJNsl+gAz2NeweDvgX4Y+Gawaz4hDeJvF0qb4bW0x5Ftt6mMsM7V/inbA/uj16GW+1zxVqUujnT/st+6JI0Ud1I+I3zt80ydmCkjODgA4wRXBF6JHVXftqsqqVk3ex8reMPhBef8LFvrT4ewT6loLbZbSe5lRGVXGdhLEZI9cdMZ5rG1H4MfEvTLU3M/hS7khAyWt2WbH4KSf0r7A8N+FrrQHN3qeiT/YyxSa8spd8lsQcHzYyCSowPu9BzgivRJtD1KK0W405U1e2ZQ3kAqkzKeQYnGEb2DYz/AHqrnsZOmj8xiLzT78Eia1uoHDDqjxsDkH1BBr0XwP4z8dvqNvA9wb7TFbbNLfqSsalskmYDdu6gAluuAp4rsfiz4m0PXvibcsdKiSy0p3gBuLbyLiZ1+8ZNw3JggjaRkDnAJ48zl8Sy34ZJ742NkrcBAXkb/cXOBwOp/OujD5hiMM+bDTcX5f5dfma4fDUZzXt37v8AXXodVqmieC/Geuy6ZHq0eh3lvtgsYUjVYmUsM/JgKWLM2FVgck8ECvMvEnhXW/CmoraazaeV5m4wzI26OYA4ypH4HBwQCMgZqG+uvtl9JOEEascKgOdqjgD8q7Hwz8QTa6W/h3xZbvq+gSQ+SIdoMkIHK7TkZGcYycrhSpG3B7sO8LiKapV1yT/nWzf95fqvmmY46t7WvOpBe63ouyWit8jzqiu38ZeA4tH0y38R+G7t9T8PXCri4OC8LHjD4A4J4zgYPykA43cRXFisJUwtT2dVa/g10afVMwjJSV0FFFFcwwrS0HUYtL8QQXdwrtbkPDOEGX8qRDG+3JA3bWbGeM4zxWbRV05unJTjutQaudbdWM9rHFMQJLabJguowTFMB1KkgZxkZHBU8EAginQ6rqdvaRWsGpXcUEM4uo4kmZVSUDAkUA4D4A+Yc1zun6xq2k+Z/ZeqXtj5uPM+zTtFvxnGdpGcZP5mrv8AwmHi3/oaNa/8DZf/AIquxVqO92vlf8br8jGdFT0kkzeTxL4ijdnj1/VEZpnuCy3UgJlddrP1+8VJBPUg4plvr+vWkVpFa63qMEdmzPbJFcuogZs7igB+UnJyR1yaxP8AhMPFv/Q0a1/4Gy//ABVH/CYeLf8AoaNa/wDA2X/4qq9vS/nl93/2xj9So2tyR+5efl5v72aSX17Hp8thHeXC2szB5YFkISRh0LLnBIycE1Xqr/wmHi3/AKGjWv8AwNl/+Ko/4TDxb/0NGtf+Bsv/AMVUupRf2n9y/wDkjZUuW9luamn6nqWk3f2rS9QurGfGPNtpWibHplSDT21nV2nu5m1W9Ml4uy6czsTOvo5z8w4HBz0rI/4TDxb/ANDRrX/gbL/8VR/wmHi3/oaNa/8AA2X/AOKpqtSStzS+5f8AyREsNCUudxV+9jfh8T+JLbRxpNv4h1WGwClRaR3cixYJJI2A4wSTnjuaIPE/iW20c6RbeIdVh08o0ZtI7uRYtrZ3LsBxg5ORjnJrA/4TDxb/ANDRrX/gbL/8VR/wmHi3/oaNa/8AA2X/AOKp/WKf88vu/wDtjN4Cg73px1d9lv3238zaGu64JPMGs6gH+zfYt32h8+R08rr9z/Z6e1B17XDdPcnWdQMzwfZXlNw+5ocY8snOSmONvSsX/hMPFv8A0NGtf+Bsv/xVH/CYeLf+ho1r/wADZf8A4ql7el/PL7l/8kV9TpfyL7l/kWqu2lonlDUdREsOlRSBZp1GN3QmOMkYaQg8L+JwoJGR/wAJh4t/6GjWv/A2X/4qs++1LUdUuFuNTv7q9mVdgkuZWkYLknGWJ4yTx71PtaMdVdvzSS/N/wBdTfkYalfTaprN3qdwqLNdTPO6xghQzMWIGSeMmuq0WVtd0Cy0u1RpdTsA8SW0aktPAXMgKDks6s8m4D+HYQCFcji6K4al6l3LdmeIw/topJ2a1X5fkzrq6Hw3458U+EYp4tA1V7aKc7njKLIpbGNwDAgH3HpXGf8ACa+Mv+ht13/wPl/+Ko/4TXxl/wBDbrv/AIHy/wDxVc/sX3PNq4GrWjyVIRa7Nt/+2m1e315qOpTahfXMk91M5kkmc5ZmPepr7WtZ1OKKPUtWvrxIv9WtxO8gT6Ak4rn/APhNfGX/AENuu/8AgfL/APFUf8Jr4y/6G3Xf/A+X/wCKo9i+5X1Otp7kdNtXp/5KdE+u63I120msagzXuBdFrhybjHTzOfmx2zmrUvjDxdMUM3inWpDGxZC99KdpKlSRluDhmH0JHeuT/wCE18Zf9Dbrv/gfL/8AFUf8Jr4y/wCht13/AMD5f/iqPYvuQ8BUe9OP3/8A2p0EGtaxavaNbatfQtZhhbGOd1MAbO7Zg/LnJzjrmp7LxN4k02F4tO8Q6rZxyOZXS3u5IwznqxAIyTgc+1cx/wAJr4y/6G3Xf/A+X/4qj/hNfGX/AENuu/8AgfL/APFUexfccsDVlvCP3/8A2ppEknJOTRWb/wAJr4y/6G3Xf/A+X/4qj/hNfGX/AENuu/8AgfL/APFUexfc0+r4jtH73/8AImrFFLPOkEEbyyyMESNFLMxJwAAOpNReI7pLDQh4eyDePcrc3idfIKKyxx57P+8lLjnHyDhg6jMn8XeK7m2ktrnxPrM0MqlJI5L2VldSMEEFsEEdqxquFLld2aUsJNyUqtrLWy1183Zbdrb216BRRRWp6R1Xxd/5LLrP/bD/ANER0UfF3/ksus/9sP8A0RHRXbm/+/V/8cvzYqfwoPhF/wAll0b/ALb/APoiSuVrqvhF/wAll0b/ALb/APoiSuVqp/7jT/xz/KmL7T+X6hRRWhoejX3iHxBa6Npyobm4YqvmNtVQASST6AAnjnjgE8VxwhKpJQgrt6Ipuxu+B/A9x4rvJLq6m+xaLafNd3rkKAAMlVJ43Y5JPCjk9gdXxn4zt9Qs4/DHhiH7F4dtMKkaAqbgg53NnnGeQDyT8zc4C3PHuraZo+mr8PfDUPlWNpIHvLgSZa5mxyGKnBwcZz/EoAChBnz2vaxVWOBg8HQfvPScu7/lX91de78jOK5nzP5BRRU1raXV9eR2llby3FxKwWOGJC7uT0AA5JrxjQjjOJlPHBB5r9K/2cfgufCXw3uPHWrRCfxH4ld5EkK4+yWLsXRFB5Uyja7d8FVP3Tn5h+DX7Pc6eKNP8SfFq0Gl6XG/n2+g3RC3eolfm+eL70UA6uzAFvuqPmyPuXxh43n034bXklrMBc3LR6da7eNs08iwhhjuN7N/wGsKrvsb0YSk1FdSS10HTZrttsazy3iedNKRnfGrhVH+5k8DpwT3NeW/BDHiLXPiDrd0u68l18kluSI/K2ov0ABFeh+FvGmkt8XPFWn2xje30y203TIIyeEA84n82wPwFeceBvE1t4B/al1vwRe2kENlq8ZksZSuFuDlpIi3qxVpE47oBWMm00enhIRnRrxXxJJr0TV/w1+R66thFFq0Vr5e17hWdSP4im3I+uCD+FVNNWy0nxuPCjlbeG5G63R1x5UpBcxgf3HUM6Y7pIvYCuV+J/xHm0nVdD1DSIRLPp2tO1xBEpLPAbMmUKB1+VgQP9muN+M/jePWPhzD428NXwHiHw/cR3OxZMlkDLJt91+5Ih9C3qwqjmo0HUavonpfz/r8zE/bI+DVjq3hST4j+FYdup6cqrraRrj7Xbr8v2j3ePjce6dfuCvFrT4NXt/+znG8umKs90DeWt1gBxcBcIp77HUCP03EHtX2nceKbfX/AAFFrOm20V1b39kt0tq/KzRyIGMR+qsV+tea6DqOjR+DTo+nzm6sCW+wMTzInXyW/uzJjBU/eI3DOTjSm7O5zuPRn5xsCrFSCCOoPakr1L40/D648NeMbnxDpcLTeHtTmaaG4QErBIxy0L/3SDnAOMj3Bx5bW5ztWOq8F+NJ/C93Ja3UP23RrvK3dk4DAgjBZQeM44IPDDg9iJPHHgeDS7SPxP4Yl+2+HLvDI6EsbYk42tnnbngE8g/K3OC3I12fgLxJY2E9x4b1+2S60PVWWOZZXwsDZwJOSAB0yeCNqkH5cH18HXhiILBYl6fZl/K//kW9103MpKz5kcBRXQeNPC9x4R8XT6VL80J/fWshcMXhLEKTgD5uCDwOQccYJ5+vJr0Z0KkqVRWadmWndXQUUUVkMKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA6r4u/8AJZdZ/wC2H/oiOij4u/8AJZdZ/wC2H/oiOiu3N/8Afq/+OX5sVP4UHwi/5LLo3/bf/wBESVytdV8Iv+Sy6N/23/8ARElcrVT/ANxp/wCOf5Uxfafy/UK9c8KRf8IH8IL3xfPHs1XVcQWO5PmRTnaeUOM4aTByrBE7mvNvDuiXHiPxTZaLbNte5k2l8A7FHLNgkZwoJxnnGK7X4r6yl74xTRbNYUsNJjFvDHDt2BiAXxgfLjCpt7bO2SK7cr/2WjUxz3Xuw/xNav8A7dX4tEz95qJwdFFFeOaBSgkMCOvakooA+l/g2tr4R8OaLLcxG41/xSZdQYycm30y0DsuSeR5k0ROO+xD259r+JXiT+yfCfhpvNzHba9bedn1iSRzn/gS5r5s8A60+s/EHU9aiLtZ6T4VjsIMjiILDFFt/E+afqSa9L+J2tRX/hrWVjja5XTtbg1MQxsAZoWcI6g/8CPPowrCo7K56eAp88r9v+G/U7GUXfhLwdpnjK3vo5rrVY5H1KFG/ewXAl+0Qh0+8MqGUZHPQdaPHl7pPxB8LW2qGd7TUtOkW4sr+3bEsKMynIPcDg49Vz3rlfF/xK+Kt/4D0nxD418L+BZPD2o28s2nacY51v1gjkCGNLlVIEkQYFuABtJIJ4ruvC3wwm8R/CTSfE3hu8iktb22YPpt03kyBclSFf7ocEMD/C2Nw27to4oVlTjaoeh9XqSarw06L5afloZfwm17Vtb+LtxqfiKH+3JbV5XVNOjGyeUxJApYsQkQIViSzY9OoFQfFP4ZaroNw+r+FNV0mVrwGB/DtrdCaSFW3N5CqcNMv3iCFG35sDb09GvPhPrHi74WRaNoBvfCl/BbSnUIreby7jUZYoQkKRyKTtifaCxBzyR0yT8vQ/s9ajrXii3u9KsbPSYdSvY1ske/ae4t1bPmlpBhmaLkksoyRjA6Vl7S8vaJ2/4B2YXC1J39na0d07Le/Trs/I9v+Hev3OmfAfwTBc+YlzFcQ2LRyAqwAuHiIIPIwvasa107RD8QvE9jNpljdQTul/AXypAmGedpG5N4YHOcHB9axF1PTz8SvDfgzw/uXTNLuZL2Qlix8uOR5AWJ5JxsyT1LVwGteMLzTPihZahbTA+RPcadKjfdeJmWRQfYCXj6V6FKV1dnDi8JaUYx+KSb/wAv68zs/Go1a50K51nwNdLbyxo0N7oc8KzQT7cko0TAjdwcHo2B3Ir5V1C9OoajJdtbWtuXOfLtYhFGPoo4FfQl34mns/GelaxbuYoNSuvskydi/Dofwbj6H2rxDxzbWlp8S9ftrDb9mj1CdYwvRV8w8D6dPwrrtpc8SqrMwKKKKkxPUrWL/hYPwPk09Y/M1rw/gwbUy0kYB2qMJ3QFQo5LRoSea8hrs/h9r7eHvH1ldF0S3nYWtwXYKojcgbixHAUhW7fdxkAmq3xF8PN4c+IV9aqiJbXDG6thGoRRG5J2hQTgKQy9vu5wARXsY7/a8JTxX2o+5L/21/do/NGcfdk4nK1oaDpg1vxVpmjG5S2F9dxWvnyfdi3uF3H2Gc/hWfVrTLe2u9as7S9vVsbaadI5bpkLiBCwDOVHJwCTjvivDND7V+Kfwi+EXwY1S30K4/Zt8aeM9IjtUkufGNvrFyg3HO75IlMQIx0bZ9Mc18z+CPhP4g+MnxO1fSPhfpTJpkMktyJtTmEcdjaFz5Znk5+bbgYGSSCRkAmvsj4SePvFfgbxDYv4r/ay+GXifwFbIwlt7u9D6myBCE2qyCXdnbwztjHQ1x/wY+O/wm0/49/GWwkl0nRdC8ZzF9JvNXsy1g7KJVK3MYxiOQyl9pKjG5SVJFZJtIuyPnr4h/s8eN/h74Fi8bNqnhrxR4aef7M+seGNQ+228EucBJDtUg54zgjOATkgHufBX7Knj/Tdc8B+JfFR8KxQanqVpcL4Y1C/Qahd2vmo0mLZ12yARklowxbGQVzxXoHxV+I8/h/9nTxH4Oh8Sfs8fYtSlidND+HllcO90/nREyMyyCOJgsaksytkIF64rpPiZ4g+Ffxb+Mnwr+OVl8YvDWi2OkvZLfaHe3JS/hdLrzQqxAcfM5VpG2ooXduIp8zFZFbWPAWgQf8ABT268LeGfhl4I1LT10NZV0HUokstPz5CkybUt5gHzyP3fJ7isP4SfDTRvF3wO+P8B8DeHbjxFbancW2mE28L/YH+fCQTyIvlop/i+QADJC9uuh+Inw/H/BVS48Wnxz4aHh86CIRq51OD7IX8hRs87ds3Z4xnNcV4E8c+EdP/AGff2kbCbxholrfavqF62m276hEkt8jiQAwqWzICDj5c5zU62+4Z4Z8Sf2e/G/wy8AaT441DUfDuueHtTl8iLUvD9/8AbIUkwxCM20A/ccZXcuVIznGfKoopZ50hhjeSV2CoiDLMTwAAOpr6k1TxZ4Wl/wCCVOi+El8TaO/iCLXWmbSBexm7RPtEx3GHdvC4YHOMc+9eN/Anxf4e8BftF+E/F3iq3M2kafe+ZcbY/MMYKMqyhep2Myvgc/LxzWibsS0fR3xt+DvwV+CHw+8PJqHwq8U61a6rZ7ZPGEWrSW89rdlchHtWXywT97awXgEclTXyHrfhnxJ4ZktY/Efh/VdHe7hFzbLqFpJbmeI9JE3gblP94cV+h1p4y+H6+MfHcnxC+OngDxh8KPFjG7i0W6v3m1CxlbbtRIVBZEUAAYIIKIwCkHPzB+2Tr0fiT9os6npviPwzrWgJp8NrpD6BqEV2kECZJjkEbHY+9nODjgjGcVMG9htGj+xp8Lfh/wDFP4j+JdO+IegnV7Gw0oXUMYupoNj+aoLZidSeCeCcV1a/sxeE0/bElSVD/wAKfj0c+L/tfnyeWdOKZEXm53/f4zu3+WN2c81kfsNeLfCvhL4j+MLnxX4m0fQoLjQzDDLql7HarK/mqdqmRgCcc4HNcY/7T/iZ/wBkFfgYdKGRi2Ou/av3hshJ5gtvL2evy7t/3Pl296He7sGlj0D9o39nfwvp/wC1B4I+GPwj0mz0BvEGneYBe3lxLEZvMl+ZncyOo2oBhR+FeW+HP2avHXif9ojXfg1Yat4ej17RYXnuLmeeYWrqhjBCMIi5P71eqDofx+ifjr8Wfh9a/t5fCjxvY+LNI1fQ9LtI47680q7jvEt900qksYi3KhwxHXHaut8CX3wl8L/t2+Lfijd/G3wPcWfiLTZDYww6kgEILQF/PlYiNGymFQMWYEnA2mlzNILI+Q/h5+zj4/8Aif4V8Ta54XutEZPD1x9luLa5uHjlmfBP7s7CmODy7KB1OBWlon7L3i3xJ4l1zRfD3jjwBq76LpSatd3Onaq91AFYuPJEkcTDzR5ZypwAGXnmvSPhB418LaR+yX8e9KvPFmj2Op6o84sLSa+jjmvA0bL+6QsGkBzj5QetYn7GHjzwb4U8ZeMtA8ZeIbPQIfEOjG0t9QvnEcCSAn5Wc8LkOSCSB8uM5IzTb1CyPKfDfwV8U+KPgD4k+L1hf6PHonh+4+zXVvPLILl2xGcxqIypH75erDofx6zSv2VPiDqvw28M+PP+Eg8HWGh6/gx3Wpak1qtmDkL57PGFBYjaFQuxJ4GMkevaU3w8+Hv/AAT7+KHw7i+K3hHX/ENzf+d5WnXy7ZiTbALbh9rzgKmS6rtzuAJ2k1y3xl8YeGdT/wCCe/wj8MaX4o0m81WynD3umW17HJPb4jlAMsSsWT72OQOvvS5mFkeT+Mf2f/iX4K+NWm/C2/0mG917VAjaf9gl8yG6VyQGV2C4AKtncF27STxzXoVr+xL8VL3x03hO08TeA57+G38+8WHVnkNgfl2xzosRkRmDEqdm07T83TPtPxM+NXw70D9s34PeOIvE2k61o+naNJZ6jdaXdR3n2QypJFufyyxBXzNxHXAOBXWfA/wt4Vtv27vGvjvw98UtA8VR+IbG7vbex0ac3ElvFLcQuxuWA2R7W2oq7izZzhdppOTsFkfnDqFlLpurXWnTsjS20zwuUJKkqxBxntxVatXxNIk3jbWJYnDo99MysDkEGRsGsqtSQooooAKKKKACiiigAooooA6r4u/8ll1n/th/6Ijoo+Lv/JZdZ/7Yf+iI6K7c3/36v/jl+bFT+FB8Iv8Aksujf9t//RElcrXVfCL/AJLLo3/bf/0RJXK1U/8Acaf+Of5Uxfafy/U9L+DsEVrq2teKLqJJbfSrBnKhQ0gZstlM8Z2xyDOR97HQmuGu7qe+1Ce+upPMnnkaWR8AbmY5JwOBye1d94Z/0f8AZu8TXdv+6uJL1YXmj+V2TMI2kjkrh3GOnzN6mvO67Md+6wmHoLqnJ+sm1+CRMNZNhRRRXkGgUUUUAe6/CWK2s/g7d3hcLcav4ktdG3f3R5LyKP8AgRLD8Kv+I9P1O20Ea4WEtlNbGN4j/HGcxlD7hVXnvtHQjNeJad4h1ex0G50KymcW91cwXexc7lni3CN1x0YCRx+PsK9/8JeLLbxppsPhvXXtre+1CCa08tflVb1HeRFAzx5sc8oA/vxbR1ArKa0szvweI9lOLXT8up7h8NNVl8f/AAU8MxXlleyPppJaaayQJNKhMTvHIwIYOBiRT/ECSAeT7NpPhe4/s6KJXeC2RSBGGxtyST0GOpNfE/wo/aAvPgf4g1Pwl4k0z+09DW7897TeIp7dmADSwseCDgbkPGQCCOc/VGmftRfAnxBbR2epeI49IklVJPseuWrRDBwyncA0ZHQj5q8GvRnfyPp6mOdKPs6aW71+Z3k3hq4S3Jsbk5BIyr5wRwa4LxR4Z8ZWfh68Tw0tpDdXMbRy387CNLVD9+TABZ27gcDPJPY6d1+0B8H9DtYNL8P6/ba5cNkW2l+HUN3IcknA2/KgyScsQBXzx+0h8ZviFf6ZpWhWoh0HR9W80T29tLvuNi7ciSUcYIJyEGOMbjWVOk5SSRpQxmIlDVKz6nBeFJl0HwrquoGfz9T1e4/s+zmIwxiBxx6DkE89cV5pq1+L3x7cENmJ712jIP3wuFz+SCpYNVv57yOWOURx21uy2oCkiIsCFfHAwMs3XLHb2rmoLVElu5JbqeSW1gaWKcYXaVIAB65BJxj3r3aeyicGIrQp4idW9/n99vl8r3Nzxr4tWbXtOt9HcGLSZDMJP4ZLgsCzD1C7VUeu0nvXDyyyTzvNM7PI7FmZjksSckmtLRtUmstfFwI4pEmJSaGRAySI3VSDnjv6jGRUur6ZbLCNQ0oFrX7syBt3kvnpzztPGCfoe1dXM3KzPmppOPPfW+36mLRRRTMQr0b4kSN4h+GvhXxeQhlKtZ3UroFkkk9flGNu6OUjkY3DA5OPOa9Gsf8ASf2Yda+0/vvsuoL9n8z5vJy0Odmfu/ffp/eb1Nevlnv0sRQezg384+8v1XzM56NM8tooqS3t57u7itbWCSeeZxHHFEpZnYnAVQOSSTgAV4hoR0VdGkasXvUGl3pawybsCBs22G2nzOPkweOcc8VSoAKKKs3Wn3dna2VxcxbIr2E3Fu24HegkeMng8fPG4wcHjPQigCtRXQt4E8aRXVnb3PhXV7Rr24jtLdru1e3SSVzhEDuAoJPqa56iwBRRRQAUUVK1tcLZpdtBKLeR2jSYqdjMoUsoPQkB1JHbcPUUARUUVfm0TWbfR4tXuNIv4tPlOI7x7d1ic+iuRg/gaAKFFbl34M8YaekDX/hTXLVZ5VghM9jKgkkb7qLleWPYDk1De+F/E2m3tvZ6j4d1a0uLlxHBDcWkkbzMTgKikZYkkDA9admFzJoqZ7S6jtFupLaZYGkaJZWQhS6gFlB6ZAZSR1GR60lzbXNneS2l5by29xExSSKVCjow6gg8g+1ICKiiigC/omsX3h7xNp2v6W6JfaddRXlu8kayKskbh1JVgQwyo4Iwe9e03f7WfxEXwpqOi+GfDngfwc+pRmK91Hw1oy2d1cAgg7n3EA4J+YAEZ4INeD0UmkwuFFFFMAooooAKKKKACiiigAooooA6r4u/8ll1n/th/wCiI6KPi7/yWXWf+2H/AKIjortzf/fq/wDjl+bFT+FB8Iv+Sy6N/wBt/wD0RJXK11Xwi/5LLo3/AG3/APRElcrVT/3Gn/jn+VMX2n8v1PUtU/5Ng8Of9hB//QrivOa9G1T/AJNg8Of9hB//AEK4rzmuzOPio/8AXuH/AKSiafX1YUUUV5BoFFFaGiWEmpa5b2kUYld2AWM/xnsPpnH4ZpNpK7KhCU5KEVds2tD0y4ijBtkP26VctL/z7Rn09HYd/wCEH1PFKawkea5MIYR2uMeUSOQ3Y+vBP4ivV9PPhqylTQotVgn1HdmRY8u8snfoOTn+Ec9q5fRrjQ9It5IPEMMzvJOz+VGybXBJxucONoGBwOTnqvfz1WlUk7I+zr5VhsDQhGpNNu/NbWz2S083+ByN6fE3xF1SO615beaTTwsdxrMp8triPqiOVH7yQgHBA3Hkt0JrUkNrq0twksUdldQgrAjYUomAqxn+8MBQGHpnnJFWtb1eCG2cWsEVqkSbbe3jyVVW6kepJ+Y47/Si8sftmn2ttIxVnYl5FOCBGg5/77kH5VctDxaFOzdtbLXz7L77a79T3K1s/C3wa+DWh6/pM1tdap4jsI7gNJMZJG25EjyLxsVHLIFGASMZ4YjxXWtZutf8Xv57zavqLnGFzMP+AquN36KMYwAKhj0W6vru0hub25lt4XSNUeQsEUyZwP7oJLHHqT3Oa6jwbraeF/Der6ppb+Rqt+jzNMsJJEZZgB5nRSGydv8AF8oGTWVGkoybbuzqxGKqfV0oLljey8/609Xfytykk+rXTNaRaUBhtjPdMuN3T7o9DxWTpySQ6td2mqWkcCvHJFcRgfKo2k7x/ukKw/8Ar109vcRtHKoG4iUwoM8ttAySfzyaz/Edjd3CyXEwhBlQFSGCsxTG7IzuwV56dVFbwlyzXYxeGVTDSnFNzTXpZ9+3kcZZg/aQ6/e6L/vHgfl1/CtywWeISPbRiVkXZNGw4mTlSG/LOexrX8OeHQZTdSgNtyqjGFz3xWv4f0pl8X6pZ4yIwGx6BsEfzNRVxCTbXQ9HAZBK1NVl8ba9NG/0PONRtUtrrMBZoJBvjZuuPQ+4OQfpVOvQPG/hdtNjNxGh8mZi6AfwSAfMPoyjP1WvP66qNVVI8yPncywFTAYiVCotV+QV6P8ADn/knnj3/sHf+0p684r0f4c/8k88e/8AYO/9pT17mRf75H0n/wCkSPNq/CeWVveCLiC0+J3hy6up44IIdUtpJJZWCqiiVSWYngAAZJNYNFeIaHqdp4x0S+0jV7aUyW1xfWDNqksjKoupYzHHGIucsxXzHOeSztxgZqbUf+EP/ta2/tb/AIRr+z/7ci+w/wBl7M/2fh9/2jyvnx/qP9Z+8+/Xk1FVzE8p6if7E/tTSf7Y/wCEU/trZff8efkfYf8AVL9k87yv3WfM8zr22b+M1g/EG4jn/wCEbiE+kyXEGkmO5XSmjMMcv2u4YqBH8oOGBIXj5sjgiuMoouOx7RrM+nr8ddN15bXwjbaf/wAJNBcHVrLWlmmlj8/O+SP7S4RcfMT5a4wOg4PN2Z0MeMNJl0uy0a60f7NIIYbu4tYJo32YZrg3B2NIrEMA2UYDCgcged0UcwuU9bhsrZYPFNzplx4Tv7tL/TUhu7+1s4bdA8Fw0kaD/UAjaAdp2tsLDLbara1qHgZPF3hzTbS20j/hHXleS/mt4FMpX7fcbVaTBkVRGI8DhihXOflrzJbm4WzktFnlW3kdZHhDEIzKGCsR0JAdwD23H1NRUcwcp63ez6K3i7SCnhfw8u1LkGVdb0qSOQFAEZlWOOFShO5RKuXyQc4453x3Ho0WlWy2F/pd7eHUrlppbK3t4CIzbWhVSsHybVfzlBX5Swcjqa4aihyBItXHn/2dZ+Z9l8ra/l+V5fmY3HPmbfmznpv5x04rudTaDU/Bl1qWr6lp0N0un28FtJp+phmvPLMaLFLakllwi5JwigpnBzXnlFJMdj2XXZrAfG+w11bTwjb2B8SQ3B1ay1lZppY/Ozvkj+0uEUj5ifLXGB0HBq+E5bfwtfJb67r+ktHd65YTW9vb6hFcpB5dyHe4do2ZIwE3LkkE7+mAa8kop8wuU7tNd0iy+GcFtcaRpGsznW7yXybuacNEhitwHAhlQ4YgjJyPlOOhrH+IF1bXvxT8Q3dnPFPby38zxywuHR1LnBUjqPeucopXGkFFFFIYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB1Xxd/wCSy6z/ANsP/REdFHxd/wCSy6z/ANsP/REdFdub/wC/V/8AHL82Kn8KD4Rf8ll0b/tv/wCiJK5Wuq+EX/JZdG/7b/8AoiSuVqp/7jT/AMc/ypi+0/l+p6hov+k/sxa19p/ffZdRX7P5nzeTloc7M/d++/T+83qa87r0L4PH+0G8S+GP9X/aWnH/AEjr5eMx/d7/AOuz1H3ffjgJoZbe4kgnieKWNijxupVlYHBBB6EHtXZmH7zDYauv5XH5xb/RomGjaGUUUV5BoFW7K/uNPMslq5jmdDGJB95AeDj0JGRn3NVKKTSasyoTlB80XZnZ6BbWFp4c+1ByuoXKuwmzho4gdmyPsGchgzHovTqallvLSxhhWCygkvJY1IUANtJ7MT1wMHrXpfg39mb4l+LvhBB4sgOn2n7lrnTbCd2W5uoidwPA2oG5K7jkg54BBrgdL+GnxJ8X+O08NaX4avP7YjikJhmXyEgRers74UAEgdeSwAzmuKU4ub97Y9qnWccPGPs7Pv39fPzIZPBXjLxJ4fm13SfCt7qdtYHNxcaVYu6IAcsCyrg4745HfFR6XfxXGqwNJchVWJti4OTub5scegFfoj4N8W2Pgz4deH/CV1oi6FqdjZi3m04OrLHNFEsrKrrw3moJXSQdWVgeRivj79pm08NRfFGLXfD16Y7y6MgnghjCRySo3zXKYxsLq0JZSOWLEcZrmp4j2suVr0N4xlh26qWml/vT/Q4W5nayjSUMqGDEoWQgEsRz069Bxzim2gt5vDccc0KgxW6lWErkFmUDdjcVB9Tj2rKsdTjmdX1EFQisCi4XIIONoJA64qJppE06HDLKIRyi4J55YjHvXQoPuE8wp2cYwutbXs90l20tbp289Dw3Pm3jMwzK08kZHoBkn8z/AErq9Wh0afStI1OO601HtwRqNneXAEk7pKclE5dg8ZXgAAEHpXBaHcbtecKcx5eZf+BACuu0/Uk8+YJBHPESscqMrHcc8bSnzAj1GepBBqnpqZYOTmlSvu7fLbul97OPj1zUvD/iSVbW7uJ7eGYhYrjcBImeMqeRkYPYjNdbceMrPRr/AFTWtPWO4ub6O3S3jk6IBHuZmx6EgY7n6Vy/iuGO5uJNTjEaOs32aSKMkqoC5jwSASQo2nIByue+BzNazoQqWkTRzfGYByoqWqel9bOzTt8n9+p6RYePpPElncaF4jitw86/6LdRpsCSjlQw6YJ4z2zzXnUyGK4eMqVKsRg9RTASDkU6SR5ZDJIxZmOST3NVToxpt8uzOTG5lWx0Y/WHzSjpfq12fp+o2vRtF/0b9mzxNd2/7qeS8SF5Y/ldkzCNpI5K4dxjp8x9TXnNej+PYpdC+DPhPw3PE5lmd7x2cGNomALGMqe4M+M5H3OnPHu5V7kK9d7Rg185e6vz/A8qfRHllFFFeIaBRV6HT08pZLy4MIYZVETe5B6EjIAB+uehxg5qT7Fpv/P9df8AgMv/AMcquViujNorS+xab/z/AF1/4DL/APHKPsWm/wDP9df+Ay//AByjlYXRm0VpfYtN/wCf66/8Bl/+OUfYtN/5/rr/AMBl/wDjlHKwujNorS+xab/z/XX/AIDL/wDHKPsWm/8AP9df+Ay//HKOVhdGbRWl9i03/n+uv/AZf/jlH2LTf+f66/8AAZf/AI5RysLozaK0vsWm/wDP9df+Ay//AByj7Fpv/P8AXX/gMv8A8co5WF0ZtFaX2LTf+f66/wDAZf8A45R9i03/AJ/rr/wGX/45RysLozaK0vsWm/8AP9df+Ay//HKPsWm/8/11/wCAy/8AxyjlYXRm0VpfYtN/5/rr/wABl/8AjlH2LTf+f66/8Bl/+OUcrC6M2itL7Fpv/P8AXX/gMv8A8co+xab/AM/11/4DL/8AHKOVhdGbRWl9i03/AJ/rr/wGX/45R9i03/n+uv8AwGX/AOOUcrC6M2itL7Fpv/P9df8AgMv/AMco+xab/wA/11/4DL/8co5WF0ZtFaX2LTf+f66/8Bl/+OUfYtN/5/rr/wABl/8AjlHKwujNorSNhYsMR6hKG7GaDav4lWY/oaoTQyQTNFKu116jr9CD3HfPek00CYyiiikM6r4u/wDJZdZ/7Yf+iI6KPi7/AMll1n/th/6Ijortzf8A36v/AI5fmxU/hQfCL/ksujf9t/8A0RJXK11Xwi/5LLo3/bf/ANESVytVP/caf+Of5Uxfafy/U2vCWu/8I1410/WzH5iW8n7xQMkowKvgZHzbWOOcZxmup+Kmgvo/xBublIdlrqH+kxMNxBY/6wEn+LdlsAnAZemcV55Xrulj/hYHwPk04J5mteH8eTtTLSRYO1RhO6KVCjktGpJ5rty1fWsNUwX2vjj6pe8vmvyJn7rUjy6iiivHNAr2/wDZo+Ccnxa+JP2rV4JB4W0hlm1B+VFwx5S2U+r4JYjogbuRXlHhrwxrXi3xbpvhvQ7J7jUNRmENvHjAYk8knsoAJJ6AAk9K/U34X+CNF+F3ww07who5WRbZTJc3W3BurhseZKfqQAB2VVHauPG4n2MLLdnXhMM60vJHXxWlrp8PmsRHFCuQqDaiKo6ADjAAwB2xXn/w7thfTa54lt48peX720Bz92KEnIHoPMeXPuvtWb8dvirYfDz4T6lfPKr300RitbcHmWRuEUDryf0DHtXdfDzQW8JfCfw94duGMt1Z2EaXUh6yTsN8zH6yO5rwUnytn0Tm6aUXu/y/4f8AIXWPDHhfU0trzxRY2ctyMWsU5LIwZzhVUgg5yTtPUEkjGTVLUvhJ8OdZ8FT+FtR8LWV3p8x3N52WmDDOHEx/eBlyQCG4HHTiue+L2ui0fwxp8NwIribVBMgDYP7uKRh9emfwrq/DXimHWtMWVmVLlMCaP0PqPY1KbjZplToTlS53s+h8K/Gr9nTX/hLdPrmh239v+E3fAuGiBubIk8JOB1HYSKME8EKSM+Px6za3mlz2seIWkCvCwUcSLyoyOxBI/Gv1M8apaar8NPEFhdhTDNptwrbug/dsQfwIB/CvzA8T6BZ2niDPmrAt4qSIxGBDI+flYdgWBB9Dj1r06GIdRcsycJgpRTrU2tHytPZqSa+Xa/RtbHJQXZh1GWdV8t549uBxtOcniui0+5+w6KbnPzFt6D1PRf5VzdzBONVWG8jEV0sjK49Cf/18VuNbvM8cRISCMYGOprv3R4acqNRxWjT9GWMRaytzFeyjzr51eOUtgJN820t7MW2+2c9q4+SN4pmikRkdCVZWGCCOoNdymsabb6Be6Z9n84INybegJznLfUA8d81h61D9u8SyeYWWZo4/O8uMvul8td/A985981dGbs01sdeb0o1JU8RCV3UV30s9n9+5gUVYks54bdZZAq7jgJuG7/vnqKr962TT2PFlCUfiVje8GaC/iPxtYab5PmweYJLkHcAIlOXyV5GR8oPHLAZGas/FPXf7c+JV5tj2RWP+gpkYY7GbcTyf4y+OnGOM5rrPDo/4QH4P3vi6ZNmq6pi3sNycopztPKHHRpMH5WCJ3NeQV7OLX1TBQw/2qnvy9Nor839xjH3pN9gq5pcaSaonmKHVFeXawyGKIWAI7gkc+1U6vaR/yEz/ANcJv/RTV4kdy3sPZmd2d2LMxyWJySfWkoq1pmnXesa3Z6Tp8Rmu7ydLeCMdXd2CqPxJFaiKtFexeP8A4V2ml+JvDcFrpt74W0y9u30ae81mKWJXlhcA3n73GElR0cDIUEOAQBxnXXwwsbVJLV9RubGJ9T020Goa5YCzZEuFu9zoUuZImi/0cfMSckYDIFbeAeXUV6tB8P8Awhpc3iu38RXfieGKy0OG/tbqbR4kkVmvoITJHGt4UlXD7Ad+Dvc8GNQ1DX/hZb+H/Ar6xdeLtK/tSO1gu30s3VpvZZghCIq3BmMgWQMQ0KjCsQx4yBc84orvfG3w+0zwvFrn9l+JpdWl0PWRo1+slh9mAkbzijRnzG3D/R5A2QuDjG4HNXdB8IaDrnwKa4itWXxVLqN61nOJWxPFbW9tI9tszt3FZpXUgbiYwvO4UBc81or2i8+Dmnav468T2GlX8mjJb6xd2Gl29x9n+zzCLkIJJrpZnYZAISKQjKkk5wOW0v4d6Ze6JbveeJ5LXVrnRrzXILFLAyRmGCOZwjS+YMO/kNxtICnOSflIK5wFFehat8MRp/wwPiuHV5PtMENtPd6ZeJbRSxpNtCsqR3Mku3LrgyRR5DA+1avwo+GZ8Y+HtRvrjw3qmqrdzjR7GezilZLG4eNn+0ylOAiN5KkP8u2Vj/DkA7nlFFdV4r0O00fwp4Rnjs2t729sLiW+3M2WlS+uIRkE4UhY0XAx09cmum1PwGzeB9GsdC8MwXervbR3GpXS3rfaLKSTdIgnQt5SQNAY2DYGCSGcEFaAPL6K734W6L4Y1m/8Qr4rg3WdvpO+OfzXT7JLJd28An+UjdsEzNtOQcciunvfhdpUWk+E/CskX2HxPda9HpOrX+5pRE8yo6oI9wU+WsiZxgltwJ6YBXPG6K9B8D+F7WWxttfvfJuory08Q24tJoAyxva6V5ySgknJ3TqRwNpjBByeNPxH4K8JRvqaeGrq4eW18MabqUsWoWvkpHJP/Z43xyi5I3Obp2beuxMsqg/K6AzyuivV/CPhLQdM8L+J7vxcng+e6srqwhguNR1C6u7NFmW5ZlD6W7FnPlJ1JA2nOCeTTvCPgy48J3usa9LJZRyeHDqtu+kWck/kt/bRtN22a5XedgCAHaNj5I3pukBXPKKK6+98DfY21wDVN40vQ7HWs+RjzftJtP3X3vl2/bPvc58voN3Fbx54a0rwh421Dw1p2uT6tNp11NaXUz2YtkDxuV+T94xbpzkDByBuHJBnM0UUUAFFFFABT7lRLonmN96CZUU/7LhiQfYFcj/eb1plSS/8i/P/ANfEX/oMlJ7AZdFFFZFHVfF3/ksus/8AbD/0RHRR8Xf+Sy6z/wBsP/REdFdub/79X/xy/Nip/Cg+EX/JZdG/7b/+iJK5Wuq+EX/JZdG/7b/+iJK5Wqn/ALjT/wAc/wAqYvtP5fqFbvhDX9Q8N+L7TU9Oge5kB8trVSw89W4KcdT0I4OCAcHFYVd78KPGdx4L8WS3dtYWV41xGIniuYVcvHnLIrH7pPHTOcYORxXJSqzozVSm7NaplqPO+XuXPiP4Tg026TxJoohGjXzgLGgKG3lK5KFDyM4Y4wNvKkDAzyui6fHd6gsl46Q2ceXkklDbCB/DlR1JwPx7V7T4z0uSfwlfeNfh9PO3ha4fff6VEoV9JlGDsePkCMHlXXG3jPGDXmNva3Wpz7LZr29UEuUi5I45OB09zitMZi4Vqjqwhy33XS/W3l5dNjopYbXlvd9ranTjxHeabrmk3Hh6+ubA6eFmtpobg7YtpyVTBAGRkEEcgnOc19c+If2lPBWl/CqLxol2wjuAyR2hAM4mH3oQmeWGRk/dAIJOCM/CYL6c7WqWz4cjj1PIwePXnA/pXIeIbuK61BLeGX7Q8WVadWyrsccD2HTPf6YryK2HjUSb6Hp/X5UpOTirv5JdrL0/rv7l4M8TeI/2hf2vvCJ8TB00eLUPtiWecxRww/vWGT99m8sKT3yAABgV+kU+prFFJLO+zALOT27mvy4nFlpfh5dOktGS6tZTHF5JLxqgYnIdTz8zE9M9TntXpFv+0D4/sPhbH4QSKG7WC2aFNallkeVF5ZZH6glQQBk/wrnOKwrYZzso9DopWg3KrLmbSba1t5baP8D3PxjrVt4r8TX+vahOLfStORorS4Y48oqcvcKe20qFB77X6g1F8OfiDD4l0GPXdIm8q4hcw3MWMFHHqv8AdYYYexx1Br4u/wCEv1e68NQaDdandmzgyY4ZZ3eHOc8p65OfT2FWfBnjfV/BfiSXVdN1AxtMhjmRk82KUdt6EjODggggg+xNVLAS5WuvQ7qecYf3Utnv5H3H8Vvipa6f8JL/AE9iINU1OP7HboTlGyRvY852hc5+oGckV8a+IdUttYN9JfI8t2RsEjyZyd7s5DfxfwgbueTisvxJ4q1vxTqD6lf3kt9Mw2iY4AjX+6iL9we348msDzpzD5T8KBjJ44rbDYeVONmceZYrDPlVJXaervpbt2+fyHXjy36xahcDdcRERzc8sMYyT69D+JqP7VcN/ollLK+47SHG3Z7En+QpYru3gtrtW+dpIwqAdN2ep+gz+OK2/AFroGv/ABF0vSvGPiFtD0qebbLqSxq3k8HBOeACcAsenU11cnLE83E144icZX957+t7avzVjNWzvbNY45EhcvKGG0seV5Azjvir9vp+q2lx9oiVZnIyx5+YHnPNfZmm+Ff2XfA3iAeENbtbG58RMEaCXxVM8sF3G/CSwzAGAKw6HAwcg9K8f+Pvwo8J+FfDj+IfBFvLps9tchb+0SZ18oP0HlszFecFSpKMrZUkAgcsMQpSUVpc61Tjyv2keblXR2aWr7a/M8mSS2um8u8gMU3VSeCPow/xqtpnhrTbrxjaRarfJb2Zkae4luWIEqA5KZGNpOCCSRgHPbFUdDOtatFdYTzra0i82W4lIUQ/3fm7kkYA6nnsDi5eXO+NLssCgKogI+8d3J9xjI/E130uahUhUqRur38ml+h59VU5RfspPl890/66roZXj7xSvifxN/oaJDpViptrGGLITywfvhTjaWGOABgBR2zXK1JOIxdSCLPlhiFz6Z4qOtsTiJ4irKtUerPPS5VYKvaR/wAhM/8AXCb/ANFNVGnwyyQXEc8TbZI2DqcZwQcisU7MbLtXdI1fUNC1mDVtKuPs95ASYpdisUJBGQGBGcE4PUHBGCAarxiC7XfBLDC/8UMsmzb7qzcEe2c/XGS/7HJ/z3s//AuL/wCKrUku6Z4k1bSLF7Gzlt3tXuYrxre6tYrmNpYw6oxSVWBwJHBGMHPIOBjUuviJ4rvQkdzdae9tHLDKll/ZlqLVWh87ywIBH5YUG5nJXbhi5JBOCOe+xyf897P/AMC4v/iqPscn/Pez/wDAuL/4qgWh0I+Ivisaz/aX2qw3C0Nh9l/sy1+yeQZPM8v7N5fk7fM+fGz73PXmq17408Qal4cTRNQlsLq3SNIUmm062e6SNCNiLcmPzlUAAAB8bfl6cVj/AGOT/nvZ/wDgXF/8VR9jk/572f8A4Fxf/FUBoX9R8Ua7qx1c6hfed/bF+up337pF864XzcPwBt/18vC4HzdOBhLHxNrumW2mwWGoPAmm3zalabFXMVwwjBcHGTxDHwcj5enJzR+xyf8APez/APAuL/4qj7HJ/wA97P8A8C4v/iqA0Osg+LHj221G5v4tahN1cXkt+072Fu7pNLjzGjZoyYw+AGVNqkDBFXtE+KD6J8N5/DkWnXNxeyWdzp8d3cTwtHBBOGDoiiDzgMO52+cU3HdtzXC/Y5P+e9n/AOBcX/xVH2OT/nvZ/wDgXF/8VQGhv3vxB8W6h4Zl0C71KF7GaGGCYLZwJJOkRXyhJKqB3K7FALMSAMZwSKx5tZ1O40rT9Nkuj9l08yNaxooXy2dgzNkAEkkDk5OAB0AqD7HJ/wA97P8A8C4v/iqPscn/AD3s/wDwLi/+KoDQ0fEPirXvFd3Fc69erdSxebsYQxxY8yZ5n4RQDmSV2/4F6YFa1t8T/G1nYR2kGqwbUtxZmR7C3eWS3C7RBJK0ZeSLaAPLclcADHArmPscn/Pez/8AAuL/AOKo+xyf897P/wAC4v8A4qgNCWx1a/0611C3sp/Ki1C3+yXS7FPmReYku3kcfPEhyMHjHQkVPZeI9b06ytLSxv3t4rS9Go2/lqoaO4AUCQNjORtXjOOKp/Y5P+e9n/4Fxf8AxVH2OT/nvZ/+BcX/AMVQF0dFe/Ebxffm38/UbdFt0u0hjtrG3gjjF3CIbjCRxhfnQYPHBywwxJqtc+N/El3ov9lT3lu1ubFdNdls4Flkt1eJ0jeUIHcKbeHbuYlQuBgEg432OT/nvZ/+BcX/AMVR9jk/572f/gXF/wDFUBoSw6tqFvoF3osNxtsbyaK4nh2Kd7xBxGc4yMCWTgHB3c5wMaem+NvEmlfZVtby3aO2sm06OC5s4LiI27TtcGN45EZZB5rF/mBIOMdBjH+xyf8APez/APAuL/4qj7HJ/wA97P8A8C4v/iqA0N2fx/4sufC0vh6bUYmsJrWKylUWkIklhidHjR5Qm9ghjTbljtA2jAJBxtW1S/1zX77WtUn8++vriS6uZtqr5kjsWZsKABkknAAFR/Y5P+e9n/4Fxf8AxVH2OT/nvZ/+BcX/AMVQGhXoqx9jk/572f8A4Fxf/FUfY5P+e9n/AOBcX/xVAXK9FWPscn/Pez/8C4v/AIqj7HJ/z3s//AuL/wCKoC5XqSX/AJF+f/r4i/8AQZKkNrsG6W7s0QdWE6vj8EJJ/AVRvLpZgkMIIgjJK7vvMTjLH0zgcdBgdeSVJ2Q9yrRRRWRR1Xxd/wCSy6z/ANsP/REdFHxd/wCSy6z/ANsP/REdFdub/wC/V/8AHL82Kn8KD4Rf8ll0b/tv/wCiJK5Wuq+EX/JZdG/7b/8AoiSuVqp/7jT/AMc/ypi+0/l+oUqsyOHRirA5BHUGkorgKO48OfETVdK1aC5S4FrKAEkmjyFnHT94ucH647nIOTXbjT7PxJJKPDWpp4fkmYySWdtEPLMhOVPykMEz0AyB2A6V4hWhp2tajpcivZ3DIUOV5+6fb0qeVWtY66WLnGpzyk9d7btep1XiqfxN4b06+tdbu7oTSp5KMX3LOTxuDY5AUHngjgHFcjoWhiMrqGoIM7fMhgdA4PvIpI+XpxjnPYdfX9OTxF4x8K2XiSSKx1G4hMiR20bZlhC43SLG3DSHHVSWCgYArldQu7WeIlbd5pQd3lqr7mP0xnP61i4Wex2VpqtLndRyS2u9fz/IzIIZbmJpDLLCD91Yyyhzxzg9Bzz/AJNWr2W9g0C8hnv5EmdAXsoshUXcBmTOPmPGFA4B5I6V0Ok6V4hEF3cx2Umku4VIru8jMZiiPLOqkZBA4GAOpOR1rN1+Dwlpvh26itNYn1PVp8LuY5A+cEsdvGcDuT1qlCV02tDVShClJwl7zT62stV31b6Lon1OEooorqPDFDFTlSQfahnZvvMT9TmkooAK3LTw1cPYC+1C5isIXQtCkgLTT8cbIxzg8cnA9zVDTZrW1vBdXUYlEfKxEZDN2yPQV1VhpfifxjfLcWegmRJv+X263CEKG2k7jgHB6gZbg8HFOFGtXmqdCLb8tTsoQw8YOpXl6L/O35aXOca01G6ESXV4pEMYjjWafdsQEnaBk4GSTj3NaEtoLkuLq/uroJEIbcOzu0ag5AHGNvJwOAM12LaD4A8CSC48W6guq6qCrf2ZZjKRn5DgrnnGSf3hUMpPymuE8UeNtS8SyxxCCDTbCEFIbKzGxAueN2PvEAKOw44Aya7cXlv1WH7+olP+Vatf4mnZfi/I56daN9rrua76l9m0tbC3EkNgrMVildYlYnA3P0LtgDJI9gAK5/UdVi3uYZBNMwwHUEJEP9nPU+9YRJJyaK8yV5O8nc1liFa0F9/6bIKKKKZzBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB1Xxd/5LLrP/bD/ANER0UfF3/ksus/9sP8A0RHRXbm/+/V/8cvzYqfwoPhF/wAll0b/ALb/APoiSuVrqvhF/wAll0b/ALb/APoiSuVqp/7jT/xz/KmL7T+X6hRRRXAUFFFFAGjpOvaxoc5m0nUZ7Rj18tuG+o6Guqf4x/EOSxa1bxDLtZdu8IofH1HSuEooGm0dXovxG8V6Hqcl5Dfi6805lhu13o5wfoV65+UjOBnOK6eT4keDvELg+L/BCGXarSXdi/7ySQALz9xguM8F2xgDnqPLaK9LDZticPT9lGV4fytKS+53/AzlBN36nqX2H4K3I+0/8JHrFn5vz/ZvLY+TnnZnymzjp949Op60v/CufCX/AEVLRf8AyF/8eryyit/7UoT/AIuGg/Tmj+Uhcj6M9T/4Vz4S/wCipaL/AOQv/j1J/Yvwdtj9nu/GepSzx/JI8EZMbMOCVxEw256YY8dz1ry2ij+08PH+HhY/Nyf/ALcHI+sj1OLx98O9CuI5/DfgSSeUsHaS/lAaJlOVMZYyYOSeRt6Dr25/Xfin4y1zYv8AaP8AZsS4Pl6duh3EZ5LZLd+mccDjPNcZRWdXOsXUh7OMuWPaKUV+FvxGqcVqFFFFeUWFFFFABRRRQAVr+FVsn8caQmowrLateRLIjEBSCwHzZBBX1HcZHGc1kUUIGev6Jpos/FGqJbwX2mwRa5Zf6HLsKyAzPhh+7BC45UA4werVWtfDmi2vxVsfPtZNTtr/AO1N9pkZDbvLtc+WEKnlT8uGIO7BwMYPlNFac/kRyeZ6Bo/gjTNShWS4h1W2aS7e3ljMiZ01VUEPPlBnJ9k+uau32g2mofCvR7nzZru4srOcxWtqwVnXz2zKcg5RccgDPI6DmvMqKXMuw+V9zsdP8FukGqpqtjf3WpWEkcf9lafKnmkOM78hXyoGOgPXtVm08F6XceF01B57xS9nNcvd718i2kQkCBxtyWOPUHngGuFopXXYLPuejS+DvCtro011P/bEkltp9peybLiNVczEKVUGM4AJzk5qvfeFdO0fXDoMpMwvNWW3ilcDzBCgBbBxwWaRVz6oa4GpGuJ2SJGnkKwjEYLHCDOfl9OSTx3NPmXYOV9z0y70jTrjwZLdS6VDBEII5FnjijjSMtBJJ8rhd7FXRIyHZsknoSMZ934L0BdIk8i5v4buHTbXUJJppEaL96wDLtCAgDOc7q5K98QatqFo1vd3Ebq5BkcQRrJKR03uFDP/AMCJrMocl2Eos9G1jwL4c0m8sBJfak1vLfR20kwjfZJGw/1iSGIICD/CGfI70uo/D3SNL0i8ubrVJhJZKILgblwlw7RmPtymyQk98qeRXnFFHMuw+V9z1+48JadZ+FJ9CDXtlZz61bxG/vHVkmXYf3keFACnOOp7c9axB4D0htV0+CWXULFrj7TmwuHQ3EnlDKFDtAG/tkfTNed0UOS7CUX3PWNa8NWl9b6RbTWmpRPZ6L5sWl71+1St5p+TOzqMkn5M47VSsfh5otzrupWC3N/O1v5XlBSURCybmWWZYpFVlPHIH9K80oo5l2Dlfc9Asvh/BdeBbrWJTLFNDZzXaSxz+bE/lk/KQIgq5A/56E98Y6att4e0/RPAmuTRQ6hcQT6bbSSX29fJm3OrMkfy8EdOSfcDv5VRRzLsNxb6npQ+H3h9NVtLWfWJlXUJHnsWDr+8tRGGXOFJ3szbRgfwtgHgVWk8GaBa6pqAuX1Zre10o35gKtBIHDhdu6WFdy/7QQfpXn1FHMuwcr7npz+GNDsNA8TWlvpl5qMyRWV1AQ6GeON1LHaRGcBTncQMEY+7jJoXHgKzj0K61aM3zWiabbXUM+5SjyyMA6528gZPA5HGa4CijmXYOV9z0ZvBPhqXxzqmg20+op/Z0RbbLMHkum+XhAkJKgZOcK5PHA5rj/Eul22jeJrjT7OW4khj2lTcwvDIMqDhldVPGeuBnr3rJopNp9ASa6hRRRUlBRRRQAUUUUAdV8Xf+Sy6z/2w/wDREdFHxd/5LLrP/bD/ANER0V25v/v1f/HL82Kn8KMHwrrbeHPGmm60rOFtp1aXy1DM0Z+V1AbjJQsO3XqOta/jjQIfD3jGa2snSTTrhRd2MkbhlaB+VwdxyAcrknnbnvXIV1fhvX9MktIvDXi4Ty6L5m+G5hP77T2J+Zozg5Rv4kwf7wG4crDVIVKTw1R21vFvZPZp+T016NK+lwkteZGBRXbSfDbUb9xL4P1TTvElqVVy9tOkUsQYAjzY3bKEncAMk/Kc4PFM/wCFT+P/APoAf+TUH/xdaPKcb9mlJruk2vk1dP5Mnnj3OMors/8AhU/j/wD6AH/k1B/8XR/wqfx//wBAD/yag/8Ai6P7Jx3/AD4n/wCAv/IOePc4yiuz/wCFT+P/APoAf+TUH/xdH/Cp/H//AEAP/JqD/wCLo/snHf8APif/AIC/8g549zjKK7P/AIVP4/8A+gB/5NQf/F0f8Kn8f/8AQA/8moP/AIuj+ycd/wA+J/8AgL/yDnj3OMors/8AhU/j/wD6AH/k1B/8XR/wqfx//wBAD/yag/8Ai6P7Jx3/AD4n/wCAv/IOePc4yiuz/wCFT+P/APoAf+TUH/xdH/Cp/H//AEAP/JqD/wCLo/snHf8APif/AIC/8g549zjKK7P/AIVP4/8A+gB/5NQf/F0f8Kn8f/8AQA/8moP/AIuj+ycd/wA+J/8AgL/yDnj3OMors/8AhU/j/wD6AH/k1B/8XR/wqfx//wBAD/yag/8Ai6P7Jx3/AD4n/wCAv/IOePc4yiuz/wCFT+P/APoAf+TUH/xdH/Cp/H//AEAP/JqD/wCLo/snHf8APif/AIC/8g549zjKK7P/AIVP4/8A+gB/5NQf/F0f8Kn8f/8AQA/8moP/AIuj+ycd/wA+J/8AgL/yDnj3OMors/8AhU/j/wD6AH/k1B/8XR/wqfx//wBAD/yag/8Ai6P7Jx3/AD4n/wCAv/IOePc4yiuz/wCFT+P/APoAf+TUH/xdH/Cp/H//AEAP/JqD/wCLo/snHf8APif/AIC/8g549zjKK7P/AIVP4/8A+gB/5NQf/F0f8Kn8f/8AQA/8moP/AIuj+ycd/wA+J/8AgL/yDnj3OMors/8AhU/j/wD6AH/k1B/8XR/wqfx//wBAD/yag/8Ai6P7Jx3/AD4n/wCAv/IOePc4yiuz/wCFT+P/APoAf+TUH/xdH/Cp/H//AEAP/JqD/wCLo/snHf8APif/AIC/8g549zjKK7P/AIVP4/8A+gB/5NQf/F0f8Kn8f/8AQA/8moP/AIuj+ycd/wA+J/8AgL/yDnj3OMors/8AhU/j/wD6AH/k1B/8XR/wqfx//wBAD/yag/8Ai6P7Jx3/AD4n/wCAv/IOePc4yiuz/wCFT+P/APoAf+TUH/xdH/Cp/H//AEAP/JqD/wCLo/snHf8APif/AIC/8g549zjKK7P/AIVP4/8A+gB/5NQf/F0f8Kn8f/8AQA/8moP/AIuj+ycd/wA+J/8AgL/yDnj3OMors/8AhU/j/wD6AH/k1B/8XR/wqfx//wBAD/yag/8Ai6P7Jx3/AD4n/wCAv/IOePc4yiuz/wCFT+P/APoAf+TUH/xdH/Cp/H//AEAP/JqD/wCLo/snHf8APif/AIC/8g549zjKK7P/AIVP4/8A+gB/5NQf/F0f8Kn8f/8AQA/8moP/AIuj+ycd/wA+J/8AgL/yDnj3OMors/8AhU/j/wD6AH/k1B/8XR/wqfx//wBAD/yag/8Ai6P7Jx3/AD4n/wCAv/IOePc4yiuz/wCFT+P/APoAf+TUH/xdH/Cp/H//AEAP/JqD/wCLo/snHf8APif/AIC/8g549zjKK7P/AIVP4/8A+gB/5NQf/F0f8Kn8f/8AQA/8moP/AIuj+ycd/wA+J/8AgL/yDnj3OMro/A+gQ+IfGMNteukenW6m7vpJHCqsCctk7hgE4XIPG7PatOP4bajYOZfGGqad4btQrOHuZ0lllCgk+VGjZcg7QRkH5hjJ4rI8Sa/pkdpL4a8IieLRfM3zXMx/fagwPytIcDCL/CmB/eI3Hi4YR4Rqti42SfwvSUvK26Xdu2m12F+bSJmeKtbbxH401LWmZytzOzReYoVljHyopC8ZCBR36dT1orHorzKtSVWcqk3dt3fzNErKwUUUVmMKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA//9k=",
	"bingung": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwMDAgQDAwMEBAQFBgoGBgUFBgwICQcKDgwPDg4MDQ0PERYTDxAVEQ0NExoTFRcYGRkZDxIbHRsYHRYYGRj/2wBDAQQEBAYFBgsGBgsYEA0QGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBj/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4Poor1jTtOT4NRab4h8Q6PFe+M7pEvNN0m/jbyNNh3EC4nAILTMVYJGCPLwWbDBVGeLxaoJRiuacvhj1b/RLq+nm2k7oUHVbbdord9v8ANvov0uznvD3wf+Jfimy+2aN4Qv3tyiSpNc7bVJUcEq0bSlRICBnK56j1Gdj/AIZ3+MX/AEJ//lQtf/jtGiyeKPjf8WNM0LxP4rujLdeb5c8kYkjt9sJc7IVKqu7ylB24yeTk16t/wyN/1UH/AMpP/wBur5jM+IJ5bUVLG4mnTm1fl9nUnpqviUo31T+yvQ9nCZXHFwc8PRlOKdr88Y/g07b92eU/8M7/ABi/6E//AMqFr/8AHaP+Gd/jF/0J/wD5ULX/AOO16t/wyN/1UH/yk/8A26j/AIZG/wCqg/8AlJ/+3V53+umG/wCg+n/4Iq//ACZ1f6v1f+gaX/gyH/yJ5T/wzv8AGL/oT/8AyoWv/wAdo/4Z3+MX/Qn/APlQtf8A47Xq3/DI3/VQf/KT/wDbqP8Ahkb/AKqD/wCUn/7dR/rphv8AoPp/+CKv/wAmH+r9X/oGl/4Mh/8AInlP/DO/xi/6E/8A8qFr/wDHaP8Ahnf4xf8AQn/+VC1/+O16t/wyN/1UH/yk/wD26j/hkb/qoP8A5Sf/ALdR/rphv+g+n/4Iq/8AyYf6v1f+gaX/AIMh/wDInlP/AAzv8Yv+hP8A/Kha/wDx2j/hnf4xf9Cf/wCVC1/+O16t/wAMjf8AVQf/ACk//bqP+GRv+qg/+Un/AO3Uf66Yb/oPp/8Agir/APJh/q/V/wCgaX/gyH/yJ5T/AMM7/GL/AKE//wAqFr/8do/4Z3+MX/Qn/wDlQtf/AI7Xq3/DI3/VQf8Ayk//AG6j/hkb/qoP/lJ/+3Uf66Yb/oPp/wDgir/8mH+r9X/oGl/4Mh/8ieU/8M7/ABi/6E//AMqFr/8AHaP+Gd/jF/0J/wD5ULX/AOO16t/wyN/1UH/yk/8A26j/AIZG/wCqg/8AlJ/+3Uf66Yb/AKD6f/gir/8AJh/q/V/6Bpf+DIf/ACJ5T/wzv8Yv+hP/APKha/8Ax2j/AIZ3+MX/AEJ//lQtf/jterf8Mjf9VB/8pP8A9uo/4ZG/6qD/AOUn/wC3Uf66Yb/oPp/+CKv/AMmH+r9X/oGl/wCDIf8AyJ5T/wAM7/GL/oT/APyoWv8A8do/4Z3+MX/Qn/8AlQtf/jterf8ADI3/AFUH/wApP/26j/hkb/qoP/lJ/wDt1H+umG/6D6f/AIIq/wDyYf6v1f8AoGl/4Mh/8ieU/wDDO/xi/wChP/8AKha//HaP+Gd/jF/0J/8A5ULX/wCO16t/wyN/1UH/AMpP/wBuo/4ZG/6qD/5Sf/t1H+umG/6D6f8A4Iq//Jh/q/V/6Bpf+DIf/InlP/DO/wAYv+hP/wDKha//AB2j/hnf4xf9Cf8A+VC1/wDjterf8Mjf9VB/8pP/ANuo/wCGRv8AqoP/AJSf/t1H+umG/wCg+n/4Iq//ACYf6v1f+gaX/gyH/wAieU/8M7/GL/oT/wDyoWv/AMdo/wCGd/jF/wBCf/5ULX/47Xq3/DI3/VQf/KT/APbqP+GRv+qg/wDlJ/8At1H+umG/6D6f/gir/wDJh/q/V/6Bpf8AgyH/AMieU/8ADO/xi/6E/wD8qFr/APHaP+Gd/jF/0J//AJULX/47Xq3/AAyN/wBVB/8AKT/9uo/4ZG/6qD/5Sf8A7dR/rphv+g+n/wCCKv8A8mH+r9X/AKBpf+DIf/InlP8Awzv8Yv8AoT//ACoWv/x2j/hnf4xf9Cf/AOVC1/8Ajterf8Mjf9VB/wDKT/8AbqP+GRv+qg/+Un/7dR/rphv+g+n/AOCKv/yYf6v1f+gaX/gyH/yJ5T/wzv8AGL/oT/8AyoWv/wAdo/4Z3+MX/Qn/APlQtf8A47Xq3/DI3/VQf/KT/wDbqP8Ahkb/AKqD/wCUn/7dR/rphv8AoPp/+CKv/wAmH+r9X/oGl/4Mh/8AInlP/DO/xi/6E/8A8qFr/wDHaP8Ahnf4xf8AQn/+VC1/+O16t/wyN/1UH/yk/wD26j/hkb/qoP8A5Sf/ALdR/rphv+g+n/4Iq/8AyYf6v1f+gaX/AIMh/wDInlP/AAzv8Yv+hP8A/Kha/wDx2j/hnf4xf9Cf/wCVC1/+O16t/wAMjf8AVQf/ACk//bqP+GRv+qg/+Un/AO3Uf66Yb/oPp/8Agir/APJh/q/V/wCgaX/gyH/yJ5T/AMM7/GL/AKE//wAqFr/8do/4Z3+MX/Qn/wDlQtf/AI7Xq3/DI3/VQf8Ayk//AG6j/hkb/qoP/lJ/+3Uf66Yb/oPp/wDgir/8mH+r9X/oGl/4Mh/8ieU/8M7/ABi/6E//AMqFr/8AHaP+Gd/jF/0J/wD5ULX/AOO16t/wyN/1UH/yk/8A26j/AIZG/wCqg/8AlJ/+3Uf66Yb/AKD6f/gir/8AJh/q/V/6Bpf+DIf/ACJ5T/wzv8Yv+hP/APKha/8Ax2j/AIZ3+MX/AEJ//lQtf/jterf8Mjf9VB/8pP8A9uo/4ZG/6qD/AOUn/wC3Uf66Yb/oPp/+CKv/AMmH+r9X/oGl/wCDIf8AyJ5T/wAM7/GL/oT/APyoWv8A8do/4Z3+MX/Qn/8AlQtf/jterf8ADI3/AFUH/wApP/26j/hkb/qoP/lJ/wDt1H+umG/6D6f/AIIq/wDyYf6v1f8AoGl/4Mh/8ieU/wDDO/xi/wChP/8AKha//HaP+Gd/jF/0J/8A5ULX/wCO16t/wyN/1UH/AMpP/wBuo/4ZG/6qD/5Sf/t1H+umG/6D6f8A4Iq//Jh/q/V/6Bpf+DIf/InlP/DO/wAYv+hP/wDKha//AB2j/hnf4xf9Cf8A+VC1/wDjterf8Mjf9VB/8pP/ANuo/wCGRv8AqoP/AJSf/t1H+umG/wCg+n/4Iq//ACYf6v1f+gaX/gyH/wAieU/8M7/GL/oT/wDyoWv/AMdo/wCGd/jF/wBCf/5ULX/47Xq3/DI3/VQf/KT/APbqP+GRv+qg/wDlJ/8At1H+umG/6D6f/gir/wDJh/q/V/6Bpf8AgyH/AMieU/8ADO/xi/6E/wD8qFr/APHaP+Gd/jF/0J//AJULX/47Xq3/AAyN/wBVB/8AKT/9uo/4ZG/6qD/5Sf8A7dR/rphv+g+n/wCCKv8A8mH+r9X/AKBpf+DIf/IniPiH4P8AxL8LWX2zWfCF+luEeV5rbbdJEiAFmkaIsIwAc5bHQ+hxxFexeLtM8Ufs/fES30/wx4zunlubJLySSOARRvlpYwrxMzq+MMQWzgtwARmquo6cnxli1LxD4e0eKy8Z2qPealpNhG3kalDuANxACSVmUsoeMk+ZkMuWLKfpMJmtT2UMRWcZUZbVIpxtf+aMrtLpfmfmktV5NfBQ55UqaaqL7Ls/ukrXflZeTbPJ6KKK+gPLO3+EHh628U/HDw5o14YjbvdefKk0QlSVIVaYxspOCHEZU5/vZweho+MvE954z8eap4nvl2S30xdYsg+VGAFjTIAztQKucAnGTya6b9nf/k5Pw3/29f8ApLLXnleTRSlmtVy+zThby5pVOb7+WP3I7pu2Cgl1lK/yUbfdd/eWtP1LUdI1KPUNKv7qxvIs+XcWsrRSJkEHDKQRkEj6E1uf8LH+If8A0Pnib/waT/8AxVczRXp1cLRqvmqQTfmkzkhWqQVoSa9GdN/wsf4h/wDQ+eJv/BpP/wDFUf8ACx/iH/0Pnib/AMGk/wD8VXM0Vl/Z+F/59R/8BX+RX1qt/O/vZ03/AAsf4h/9D54m/wDBpP8A/FUf8LH+If8A0Pnib/waT/8AxVczRR/Z+F/59R/8BX+QfWq387+9nTf8LH+If/Q+eJv/AAaT/wDxVH/Cx/iH/wBD54m/8Gk//wAVXM0Uf2fhf+fUf/AV/kH1qt/O/vZ03/Cx/iH/AND54m/8Gk//AMVR/wALH+If/Q+eJv8AwaT/APxVczRR/Z+F/wCfUf8AwFf5B9arfzv72dN/wsf4h/8AQ+eJv/BpP/8AFUf8LH+If/Q+eJv/AAaT/wDxVczRR/Z+F/59R/8AAV/kH1qt/O/vZ03/AAsf4h/9D54m/wDBpP8A/FUf8LH+If8A0Pnib/waT/8AxVczRR/Z+F/59R/8BX+QfWq387+9nTf8LH+If/Q+eJv/AAaT/wDxVH/Cx/iH/wBD54m/8Gk//wAVXM0Uf2fhf+fUf/AV/kH1qt/O/vZ03/Cx/iH/AND54m/8Gk//AMVR/wALH+If/Q+eJv8AwaT/APxVczRR/Z+F/wCfUf8AwFf5B9arfzv72dN/wsf4h/8AQ+eJv/BpP/8AFUf8LH+If/Q+eJv/AAaT/wDxVczRR/Z+F/59R/8AAV/kH1qt/O/vZ03/AAsf4h/9D54m/wDBpP8A/FUf8LH+If8A0Pnib/waT/8AxVczRR/Z+F/59R/8BX+QfWq387+9nTf8LH+If/Q+eJv/AAaT/wDxVH/Cx/iH/wBD54m/8Gk//wAVXM0Uf2fhf+fUf/AV/kH1qt/O/vZ03/Cx/iH/AND54m/8Gk//AMVR/wALH+If/Q+eJv8AwaT/APxVczRR/Z+F/wCfUf8AwFf5B9arfzv72dN/wsf4h/8AQ+eJv/BpP/8AFUf8LH+If/Q+eJv/AAaT/wDxVczRR/Z+F/59R/8AAV/kH1qt/O/vZ03/AAsf4h/9D54m/wDBpP8A/FUf8LH+If8A0Pnib/waT/8AxVczRR/Z+F/59R/8BX+QfWq387+9nTf8LH+If/Q+eJv/AAaT/wDxVH/Cx/iH/wBD54m/8Gk//wAVXM0Uf2fhf+fUf/AV/kH1qt/O/vZ03/Cx/iH/AND54m/8Gk//AMVR/wALH+If/Q+eJv8AwaT/APxVczRR/Z+F/wCfUf8AwFf5B9arfzv72dN/wsf4h/8AQ+eJv/BpP/8AFUf8LH+If/Q+eJv/AAaT/wDxVczRR/Z+F/59R/8AAV/kH1qt/O/vZ03/AAsf4h/9D54m/wDBpP8A/FUf8LH+If8A0Pnib/waT/8AxVczRR/Z+F/59R/8BX+QfWq387+9nTf8LH+If/Q+eJv/AAaT/wDxVH/Cx/iH/wBD54m/8Gk//wAVXM0Uf2fhf+fUf/AV/kH1qt/O/vZ03/Cx/iH/AND54m/8Gk//AMVR/wALH+If/Q+eJv8AwaT/APxVczRR/Z+F/wCfUf8AwFf5B9arfzv72dN/wsf4h/8AQ+eJv/BpP/8AFUf8LH+If/Q+eJv/AAaT/wDxVczRR/Z+F/59R/8AAV/kH1qt/O/vZ03/AAsf4h/9D54m/wDBpP8A/FUf8LH+If8A0Pnib/waT/8AxVczRR/Z+F/59R/8BX+QfWq387+9nTf8LH+If/Q+eJv/AAaT/wDxVH/Cx/iH/wBD54m/8Gk//wAVXM0Uf2fhf+fUf/AV/kH1qt/O/vZ03/Cx/iH/AND54m/8Gk//AMVR/wALH+If/Q+eJv8AwaT/APxVczRR/Z+F/wCfUf8AwFf5B9arfzv72XtV1vWdevVvNc1e+1O4RBGs17cPM6oCSFDMScZJOPc1f8G+J7zwZ480vxPYrvlsZg7RZA82MgrImSDjchZc4JGcjkVhUVrPDUp0nQlFcjTTXSz3REa04zVRP3k738zq/jB4etvC3xw8R6NZmIW6XXnxJDEIkiSZVmEaqDgBBIFGP7ucDoCtj9oj/k5PxJ/26/8ApLFRXn5JVlVy7D1Ju7cIN+rijqzGEYYqrCOylL82H7O//Jyfhv8A7ev/AEllrzyvQ/2d/wDk5Pw3/wBvX/pLLXnlTh/+RpX/AOvdL/0qqOr/ALnT/wAU/wAoBRRRXsnAFFFFABRRRQAUVu+GPBvijxnqTWPhjRbrUZU/1jRgLHFkMRvkYhUztbG4jJGBk16la/s26rp9nDf+O/Gvh7wvZTIAryy+Y6zEZETbiiZwHyVdvu8ZHI8rHZ5gMDP2eIqpS/l3l/4Crv8AA7cPl2JxMealBtd9l970PEKK92Pgf9m+xxZ6l8StelvIQI55LaBvKdxwzJi3YbSeRhmGCOT1p3/CQ/sw4z/wrnxL/wB/3/8AkquH/WLm1pYWtJf4Lf8ApTjf5fM6f7JcfjrQX/b1/wAkzweivd/+Eh/Zh/6Jz4l/7/v/APJVJ/wjn7MV8ftv/CaeJtN8/wDe/YfKdvs27ny8/Z3ztzjO9un3j1J/rC4/xMJWX/bl/wD0ly/EP7Kv8Nem/wDt635pHhNFe5n9m86x/wAiJ8SvDPiHyv8Aj6y/l+Rn7n+qMuc4frt+7xnnHmXiv4eeNPBHlN4n8P3VjFLgJPlZYSTuwvmISu75GO3OcDOMV2YPP8vxk/ZUaq5/5XeMv/AZWf4fmYYjLMVh489SD5e61X3q6OZoqV7eaO3ineMrHLnYx/iwcH9air1zhaa3CiiigQUUUUAFWtN0+81fWbTStPh868vJkt4ItwXfI7BVGSQBkkck4qrXV/Dv/kdZf+wRqn/pvuKwxVV0qM6kd0m/uRpRgp1IwfVovQp4T0aP7LHodv4hnHE17fzzxwuw7wRxNEyryRmQsWAVtsZJSpP7U8Of9E78O/8AgRqH/wAlVjV698N/Bfh7XvA1je6jo1peT3GtvZTzTXkkMiQCAP8AukWRQ7g8gBWJyeO47MNk0MRLkUpX/wAUl+CdvuSXoeVm/EEMqofWK0fdvbSMezf2rdu9zzr+1PDn/RO/Dv8A4Eah/wDJVH9qeHP+id+Hf/AjUP8A5Kr0vwF4I8I6rpNnc6ppUt0G128tH8yWSJ3gjs2lVCFYbTuAPY9unFUPEXw606Lw7oH/AAj8fnza3qzR2d2XY+ZbOqGMMucAruYNwDlTW/8Aq8vZ+0Tdv8c79PPzPMXG2F+tfVJJp93GNvtX18uRva9vnbg/7U8Of9E78O/+BGof/JVH9qeHP+id+Hf/AAI1D/5Krs/ib4S8O6XpNprHhOKBbOK5k0668m+W7DuvMcpKu2wuob5TjG3oK5+HwR5vwhuPHX9tWq+Tdi1+wEfO2SBnOevOduOgJzWVTI4wm4e87K/xz2+87cLxRQxGHp4n4VOXKk4xvzN2Sdk7X9bWMz+1PDn/AETvw7/4Eah/8lUf2p4c/wCid+Hf/AjUP/kqtzwtomkyfD7xB4pvdO/ta406SCKOxMjpGocnMsmwhiBjAwRz1rd8L6R4G1/TdSvNX0G40mXRB/aNxbW8srC8tiv+q+dsod5XDD+Fu5G6nTyOnPl95q+vxz8/O3RkYriiOH9o3TclTai2owerSaVr8z+KKva13va7OG/tTw5/0Tvw7/4Eah/8lUf2p4c/6J34d/8AAjUP/kqvVdD8GeDNb8IaHM2i2cN/rFpqM8cMdxdeezxO/lrESxiCqoAPmcnA6nNcze6L4a0/4MeH9WNpoyanqNvdmSS+e9M0jJKUUwiI+UCBj7+BnGc81pLh+EY8zk7Wv8c/Lz31Ry0uM6VWp7GNKXNz8luSG/v67/D+7lr5etuQ/tTw5/0Tvw7/AOBGof8AyVR/anhz/onfh3/wI1D/AOSq9N1zwN4atvhvJqMWiwwyR+H7LUFure6kkuGuZCA++IuwWMjndsUDnB7ClceEPDsfwd/4TJfD8o1F7BF/sz7Q+2LMhT7fjfv2HHCn5cnoVpy4ejFtNvRX+Oe33k0uN8PUjGSg9ZqC92HxNJrrtr8uttL+f/2p4c/6J34d/wDAjUP/AJKpv9k6H4ruI9O0jRY9F1qZhFaR21xI9rcuThYmWVndJGJwJN+zIQFVBaQZFFefLL4Jfu5ST6Pmk/wbsz6lYqV/eSa9EvxSObrf0TRLaex/tbVjN9h8xoI4rdwkk8ihSwDFWCKodSSQc7gAPvMk/wAR/wDksni3/sNXn/o9605P+RR8Nf8AXhJ/6V3FY067qUY1UrcyT+9XOLM3Ki1Si95Wv6Jv5bf5a6h5mgf9CdpH/f8Au/8A4/R5mgf9CdpH/f8Au/8A4/VSvYfhV8KNF8YeF59c1u7utpmaCKG2cLtwBlmJB554Ht3zUc8u54GOxNHA0vbVpyt/il/meU+ZoH/QnaR/3/u//j9HmaB/0J2kf9/7v/4/XV33gi00344R+CbnUSbRruKL7RwG2OFYD0DYYD61e1Tw/olx4W8SX0Whtos2jahFaw/vZG+1K7spRg5PzqAGyuBg9KOeXch4yj7lpSakk0+aW0nZfavv93U4bzNA/wChO0j/AL/3f/x+jzNA/wChO0j/AL/3f/x+vYfE3w88JWp8UX+kWRFtp1r5XkNO5NrchkO7lssrI+RnIyG9BWMPCHh3/hpS58K/2d/xKEEhW286TjFqXHzbt33uev6Uc8u5zUs1w9WDnFz0i5fE9kk39rf3l/meb+ZoH/QnaR/3/u//AI/R5mgf9CdpH/f+7/8Aj9er+FfAXhfXfDPhB2tD/ad08lxdoZnAu7dJzG4HzfKygoflxkBqybXQvDNp8O7zWLuz0gXKa5NYpJqkl4U8pYwwRRbnO7OeW9+elHPLuUszouTgudtO3xS7tfzeT/q5595mgf8AQnaR/wB/7v8A+P0eZoH/AEJ2kf8Af+7/APj9VKKOeXc9b2X96X/gUv8AMtlvD0imN/CWnxq3BeC4uVkUeqlpWUN6Eqwz1B6Vz2u6MmnCC+sneTT7pnWEyEeZG67S8b4xkrvT5gMMGB4O5V1ql1H/AJJpf/8AYTtP/RVzV05u9mXTlKjKLTbTaTTbe7t1btbf8DjKKKK6T2j0P9oj/k5PxJ/26/8ApLFRR+0R/wAnJ+JP+3X/ANJYqK8Th/8A5FeF/wCvcP8A0lHoZp/vlb/FL82H7O//ACcn4b/7ev8A0llrzyvQ/wBnf/k5Pw3/ANvX/pLLXnlVh/8AkaV/+vdL/wBKqiq/7nT/AMU/ygFFFFeycAUUV6H8LPhZefEDUpr+/uP7L8Mafl9R1SQhFUKNxjRm43beSTwg+Y9VVuXG42jgqMsRiJWiv6su7fRdTbD4epiKipUlds5Twz4V8QeMdeXRvDWmS396UaTy0KqFRerMzEKo6DJI5IHUgV7hB4B+EHwk8u6+I2tf8JN4gj2v/Ytku6OJv3TYZMjOMkgysquhPyEisfxF8XdO8N+FIPA/wcS50nSofMF1qsqKLm+cgoXB6ruGG34Vx8oURhMHxuvC+rY/N/erSdCj0itKkv8AFL7C/ux11d2en7XDYHSmlUqd38K9F9r1enZHrnib9oTxlqluum+GIrbwrpEcP2eO1sVVpFTYq48wqNu3B2mNUKg9yAa83RtW8U+J4/tt/Pe3926o91eSmRjgAZZ2JOFUd+gFZdei6T4T1Y3emaD4Y059T8Raj+5EVud7+YxP7vsFCBSWJ4GCScCvYwWV4PLocuFpKPnbV+r3fzbOSpjK2LmniJtr+tlsjmvGjWbeN7xrAA2wKpGRxlVUKD+IUV658NtGjurGL/hLv2d01Lw9KMNq1s93Z3KqR9+NpJtkp74AGexr2Dwd8DPDHw0jt9a8Q7/E3i+VN8VraY8i22jkxlhnC/xTtgf3R69BLf654p1KXRjp/wBlvmjR2ijupH2xvnb5pfswUkZwcAHGCK7YvRImu/bVZVUrJu9j5Y8Y/CC8/wCFjX1n8PYJ9S0FtstpPcyIjKrjOwliMkeuOmM4NY2o/Bn4l6ZaNdT+FbuSFRktbss2PwUk/pX1/wCHfC91oMjXep6LMLHcVmvbOXfJbFTg+bGQTtGB93oOcEV6JLoepR2ouNPVNXtWUN5AKJMynkGJxhH46BsZ/vVXPYydNH5kK19peppIjXFle20gdGUmOSJ1OQQeCpBwc17B8OPi/wDFG11O1t5746xo6MEnfVVLCNS4Zm+0Ab9+Mhdxcc4CnAA1Pix4m0PxB8TLhjpUUdlpLvADPbeRczuv3jJuG5MEEbSOBzgE8eZy+JZb9WSa9NjZKeAgLSN67FzgcDqfzrz8wwGFzCn7PEUlP1W3o918jvy2rLD1VJVHFeTtf16feekf8Ir8OPiZr93pcviODwtrEbrDpdtDCkdu6FlyBHhVZ2ZmAVXDZJOGAryHxr4A8UfD/WU0/wAS6f5Hm7zb3EbB4bhVbBZGH4HacMAy5AyKzb25+130k4QRqThUBztUcAZ78V6f4G+MT6foMngz4hWcniLwjLbfZhbbVM1uBkrsYlSwBwACwKbUKFduD5tbD5hl8nWwr9rT0vTdlJL+5Lr/AIZb9GmzpxGKwmPqyVSPs30ktvJSXppdbdUzxyivUviV8J7fw3oVn408E6jLrvg68RSt4cNJbOflxLgDgtkA4G1vkYBgN3ltetgMfRx1JVqDutn0aa3TW6a6pnkYnDVMNP2dRa/g10afVBRRRXYc4VteFNYg0LxbbX94kj2bLJbXQiAMnkTRtDKY8kDeEkcrnjdjORkVi0VFWmqsJU5bNW+8qE3CSkt0dnqOj3mmxwXEiiaxuctaX8IYwXSjGWjYgZxkAqcMp+VgrAgRw6rqdvaRWsGpXcUEM4uo4kmZVSUDAkUA4D4A+Yc1h6R4j8Q+H/O/sHXtT0vz9vm/Ybp4PM2527thGcZOM9MmtP8A4WP8Q/8AofPE3/g0n/8AiqlYjFw0UYvz5nG/y5X+fnpsE6GHqfFf0sn+q/I0k8S+Io3Z49f1RGaZ7gst1ICZXXaz9fvFSQT1IOKZb6/r1pFaRWut6jBHZsz2yRXLqIGbO4oAflJyckdcmqH/AAsf4h/9D54m/wDBpP8A/FUf8LH+If8A0Pnib/waT/8AxVV9dxv8i/8AA3/8gY/UMFa1v/JF5+fm/vZMl9ex6fLYR3lwtrMweWBZCEkYdCy5wSMnBNV6d/wsf4h/9D54m/8ABpP/APFUf8LH+If/AEPnib/waT//ABVS8Vi3/wAu4/8Agb/+QN1Qw8b2k9f7q/8Akixp+p6lpN39q0vULqxnxjzbaVomx6ZUg09tZ1dp7uZtVvTJeLsunM7Ezr6Oc/MOBwc9Kqf8LH+If/Q+eJv/AAaT/wDxVH/Cx/iH/wBD54m/8Gk//wAVTWLxiVuSP/gb/wDkDOWDwkpc7378q/8AkjTh8T+JLbRxpNv4h1WGwClRaR3cixYJJI2A4wSTnjuaIPE/iW20c6RbeIdVh08o0ZtI7uRYtrZ3LsBxg5ORjnJrM/4WP8Q/+h88Tf8Ag0n/APiqP+Fj/EP/AKHzxN/4NJ//AIqn9dxv8i/8Df8A8gZvLsC73W7v8C3777+ZeGu64JPMGs6gH+zfYt32h8+R08rr9z/Z6e1B17XDdPcnWdQMzwfZXlNw+5ocY8snOSmONvSqP/Cx/iH/AND54m/8Gk//AMVR/wALH+If/Q+eJv8AwaT/APxVH1zGfyR/8Df/AMgV9Rwf9RX+Y2tbStKSSJdZ1lLi28PwTBLq8QY34wTDCSCGnYH5V7Z3NhFZhl/8LH+If/Q+eJv/AAaT/wDxVY+q63rOvXq3muavfancIgjWa9uHmdUBJChmJOMknHuazlVxVRcrSjfqm2/l7q17Pp2Z0KNGLum35NW/V/11DW9VuNe8Tajrl4kSXF/dS3cqxAhFeRyxCgknGScZJrptFlbXdAstLtUaXU7APEltGpLTwFzICg5LOrPJuA/h2EAhXI4uirVKKgoR0S2OPF0XiFdv3r3v56/5s66uh8N+OfFPhGKeLQNVe2inO54yiyKWxjcAwIB9x6Vxn/Ca+Mv+ht13/wAD5f8A4qj/AITXxl/0Nuu/+B8v/wAVWfsX3PMq4GrWjyVIRa7Nt/8AtptXt9eajqU2oX1zJPdTOZJJnOWZj3qa+1rWdTiij1LVr68SL/VrcTvIE+gJOK5//hNfGX/Q267/AOB8v/xVH/Ca+Mv+ht13/wAD5f8A4qj2L7lfU62nuR021en/AJKdE+u63I120msagzXuBdFrhybjHTzOfmx2zmrUvjDxdMUM3inWpDGxZC99KdpKlSRluDhmH0JHeuT/AOE18Zf9Dbrv/gfL/wDFUf8ACa+Mv+ht13/wPl/+Ko9i+5DwFR704/f/APanQQa1rFq9o1tq19C1mGFsY53UwBs7tmD8ucnOOuansvE3iTTYXi07xDqtnHI5ldLe7kjDOerEAjJOBz7VzH/Ca+Mv+ht13/wPl/8AiqP+E18Zf9Dbrv8A4Hy//FUexfccsDVlvCP3/wD2ppEknJOTRWb/AMJr4y/6G3Xf/A+X/wCKo/4TXxl/0Nuu/wDgfL/8VR7F9zT6viO0fvf/AMiasUUs86QQRvLLIwRI0UszEnAAA6k1F4juksNCHh7IN49ytzeJ18gorLHHns/7yUuOcfIOGDqMyfxd4rubaS2ufE+szQyqUkjkvZWV1IwQQWwQR2rGq4UuV3ZpSwk3JSq2stbLXXzdlt2tvbXoFFFFanpHof7RH/JyfiT/ALdf/SWKij9oj/k5PxJ/26/+ksVFeJw//wAivC/9e4f+ko9DNP8AfK3+KX5sP2d/+Tk/Df8A29f+ksteeV6H+zv/AMnJ+G/+3r/0llrzyqw//I0r/wDXul/6VVFV/wBzp/4p/lAKKK2PCvhnVPGPjCx8NaMkTXt45RDK+xFAUszMfQKrE4yeOATgV6tWrClCVSo7RSu2+iW7OKEJTkoRV29EdX8LPhZefEDUpr+/uP7L8Mafl9R1SQhFUKNxjRm43beSTwg+Y9VVtv4nfE6z1nTYPAvgW2/svwZp+EjijBRr0qc73zzt3fMA3JPzv8xAXS+LviLQ/Deir8HPA9r5GladMsupXgmDPfXAUZDlThsHG7cOHRVCoIxnxuvnstw080qxzPFr3VrSg+i6TlveT6fyrzPWxVWODg8JQfvfbl3f8q/urr3fkFFFTWtpdX17HZ2VvLcXErBI4YkLu5PQADkmvqTxyOM4lUnGMjrX6U/s4/Bc+EfhrP461aIT+IvErvIkhXb9ksXYuiKDyplG1274KqfunPzH8Gv2e518U6f4i+LVoNL0yN/OttAuiFu9RK/N88X3ooB1dmALD5VHzZH3J4w8bz6b8NbyW0lH2m5aPTrXaMbZp5FhDDHcb2b/AIDWFV32N6MJSkorqSWug6bNdtsjWaW8TzppSM741cKo/wBzJ4HTqe5ry34IbfEWufEHW7pd15Jr5JZuSI/K2oPoACBXofhbxppLfF3xVp9sY5LfTbbTdMgjJ+WML5xP47sD8BXnPgfxNb+Av2pNc8EXtpbw2OrxmSxlZcCc5aWIt6na0iZH8SAVjJtNHp4SEZ0a0V8SSa9E9fw1+R64thFFq8VqI8SXCs6kfxFAufxwQfwqppwsdJ8cr4UYi3iuhut0dceVIQXMYH9x1DOmO6SL2Arlvid8SJdI1XQ9R0mJZJdP1p2uYY1JZ4DZky7QOvysCB/s1xnxm8cR6v8ADmLxr4avwPEPh+4judqvksissm33XhJEPoW9WFVc5qNB1Gr6J6X8/wCvzMT9sj4N2WreFJPiR4VhxqenBV1tI1x9rtlG37R7vHxuPdOv3BXi9n8Gb2+/Z0jkm0tVuLofbLW74DicD5EPfY6gR+m4g9q+0p/FEGveAYtZ022iuoL+yW5W1k5WaORAzRH6qxX615roWoaNH4N/sbTrg3Vgxb7CxPMidfJb+7MuMFTjdjcM5ONKb5Xc53Hoz85GBViCCCOxpK9S+NPw+n8NeMbnxBpcLTeH9SmaaG4QErBIxy0L/wB0g5wDjI9wceW1uc7Vj0D4YfE+78B6jNYX9t/anhnUMpqGlyAOrKw2l0VuN23gg8OPlP8ACy2/in8LLTQtPh8d+BLj+1PBeoYeOWMl2sWY42Pnnbu+UM3IPyP82C3mlenfCLxvpej3d34J8X2UV94V8QOkNyk8u1LWTOFmGWCqPu7mGGGxGBygB+azTBVMJVeZ4Fe9pzwX24rr09+K1i+vwu9z1cHiIV4LB4h6fZl/K/8A5FvddNzyWiuw+JvgS8+HfxEu9AuPntWzcWMpkDtLbMzBC2AMN8pVhgcqccYJ4+vawuJp4qjGvRd4yV0zza1GdGbp1FZrRhRRRW5mFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAeh/tEf8AJyfiT/t1/wDSWKij9oj/AJOT8Sf9uv8A6SxUV4nD/wDyK8L/ANe4f+ko9DNP98rf4pfmw/Z3/wCTk/Df/b1/6Sy155Xof7O//Jyfhv8A7ev/AEllrzyqw/8AyNK//Xul/wClVRVf9zp/4p/lAK+iPAMH/CpP2cdU+I11D5XiDX8WmleZH80SHOxhujOM4eYgko6xxdCa8U8G+GLzxn480vwxYtslvpgjS4B8qMAtI+CRnagZsZBOMDk16X+0J4mi1T4lR+GNNS2i0jw7CLO3itShjVyqmTG0DbtwkezJCmI9CSK4c6j/AGhiqOVL4X79T/BFqy/7elp6JnTlz+rUamNe692P+JrV/Jfi0eR0UUV9WeOFKCQwIOD2xSUUAfS/wcW08JeHNGluozceIPFJl1BjJyYNMtA7LknkeZNETjvsQ9ufaviT4k/srwp4bIlylrr1sZs+sSSOc/8AAlzXzb4C1p9a+IOpazEzmz0jwrHp8BI4iCxRRbfxJlP1Jr0j4oa2t94X1lbdFuG0/WoNTWHftEsTNscZ7DLHJ9GFYVHZXPTwFPnl6f52/U6qS6uPCWgaV4jFzNDqOswSz31tNC8UiyrKLiFhuA3rgMuVJ7DvVrx9d6X8QfDFpqfnPaanp8qT2V/A2JIkZlOR6gEg49VzXBeJPiP8ZLXwTp8/jXVdF1LQdYs1u4fDEmnPGYofOeNljuFXKNCUUFnOQWXh8E16x4e+Emqa98L9K8TeGrqO9tNQtBKtjP8A6PL5bA8Kfuq4OVI+6SNwIzgcMK3s42qf1c9CeHqXVeK5Vsum2n/A+8xPhbe+KvEfxVutT1OxstYmsWkeWRpRbWgdokgR5CQSN2xztUMTjgY6YfxS8DpoWrK/hPxpoGqXV4JIX0GxuU8yMEM7QrEWZ3jUFiCcFTnjBwPQ/Gfww8RX/wCz8W0ax1TQZdOt3uNbsreTyrrUxCsaeXFIA21HiV2JGTkYIPOfnDRv2ddT1XxJGh0CzsbHUJpFsWkmDOkLRsUkDjBkKMyZbHJXphqzVTml7S9v+AduEwlWcXUpW5Y73aW/l5nuPw71+40z4EeCoLhnW4iuIbEo/DAC4eIgj2U1jWunaKPiF4nsZtMsrqC4db6BnypAlGedpG5N4YHOcEg1z9pf2C+P/C/gnQRt03SpnvJCpz8kbtJuY+uNmT6tXDa14vu9N+J9lqFrMCYJ7jTpUb7rxMyyKD7AS8fSu+lK6ucGLwlpRgvid3/l+X4nZeNV1a40K41nwNcrbyxq0N5oc0KzQT7eqNEwI3cHB/iwO5FfKuoXp1DUJLtra2ty5z5dtEIox9FHAr6FvPEs1n400vWLZzHBqV19klTPBfh4z9Q3H0PtXh/jm3tLT4l6/bWG37NHqE6xheirvPA+nT8K7Le7c8OqrMwKKKKkyPftNg/4XD+yxNo6w+d4n8H7Ta7I8vNAFOxBtjz80asgRTlnhjZjzXzrXpHwd8XP4N+L2l37SxR2d24sL0yusaCGRgCzOwO0IwRyeM7MZAJqr8ZvB7+C/jFqtgsUUdldub+yESLGghkYkKqKTtCMHQDjOzOACK+Uy6P9nZjVwH2Kl6kPK79+K9HaSXZ+TPYxb+tYWGJ+1H3Jf+2v7tPkcDWhoVtDeeKdNs7lN8M11FHIuSNylwCMjnoaz60vDssUHjDSpppEjjS8hZ3c4VQHBJJPQV9OeOfoZ4m/Z1+C+l/H3Qvh1pv7NuvahomqWYuLjxdZ6zqP2fTnLSjY4ZmjyBGp5cH94PlPGfDPhr8NvDui/wDBQnXPAHhTQ/Dfj/R7CO5S3tfEtwotmAjVmDutvMC8bMyZ8vkqeRX0V8RfFcGuftO+EvHPhP8Aaj8C6J4K0uC3XVtGTxYpN6UnkeUC2QmN98bIm5juGOnyivK/BnxM+FN3/wAFQ9W8b6Pruj6R4Yl0+WJtUvJUsra4uPJRXcGQqBuYHnqxBbnNYpuxbseI6T+zt46+KF/8Q/EXhOLw7ZW/h7V7iCfSzcvHg72OyA+UE2KBjc5jAAyQo6YnxJ/Z78b/AAy8AaT441DUfDuueHtTl8iLUvD9/wDbIUkwxCM20A/ccZXcuVIznGfc/Anjnwjp/wCz7+0jYTeMNEtb7V9QvW023fUIklvkcSAGFS2ZAQcfLnOa56/8YeFv+HWOg+Fl8R6LN4gt9fM7aMbyNrpU+0TNuMO7eFwwOcYwfequ7isjkLb9kT4qy+G/D+o3l74W0y+15k+w6HqGpiHUJEYrmQQlfmCqwdlUs4GflzxVSL9lj4gzftHz/BRdY8NDX4bAag1ybif7IY9qtgN5O/dhhxsx719I+OtQ+Hfxy+Pfwi+Lvh74q6HY/Y7iwtp/DUsrHVPPF2JEjigUE5LvsZ22oAobLCneJ/iD4X+H/wDwVouNW8VanDp+my6NFYS3kp/d27vboyFz/CCQoz0G4E4GTS5mFkfKHgj4BeMfHrePBo+paHD/AMITG8uo/a5pV84L5ufJ2xtuP7h/vbeo98b+lfsqfEHVfht4Z8ef8JB4OsND1/BjutS1JrVbMHIXz2eMKCxG0KhdiTwMZI+hPhwfhh8NbX48xz/GbwVq174jsp57FLPUUEZjZboxoHchZJiZMFI923C5PzAV5h8ZfGHhnU/+Ce/wj8MaX4o0m81WynD3umW17HJPb4jlAMsSsWT72OQOvvT5m2FkeT+Mf2f/AIl+CvjVpvwtv9Jhvde1QI2n/YJfMhulckBldguACrZ3Bdu0k8c16Fa/sS/FS98dN4TtPE3gOe/ht/PvFh1Z5DYH5dsc6LEZEZgxKnZtO0/N0z7T8TPjV8O9A/bN+D3jiLxNpOtaPp2jSWeo3Wl3Ud59kMqSRbn8ssQV8zcR1wDgV1nwP8LeFbb9u7xr478PfFLQPFUfiGxu723sdGnNxJbxS3ELsblgNke1tqKu4s2c4XaaTk7BZH5w6hZS6bq11p07I0ttM8LlCSpKsQcZ7cV9Sfs2fAzwf4y+AHjH4l+I/A2seNdT0udotP8AD8N3LYRXaqisxSZBl3yzjaCcbQMEsK+Z/E0iTeNtYlicOj30zKwOQQZGwa+2fB/xK0jxH+z18LYfhv8AGLwt8PPEngo7NS0bxLdmytdQ+TbIzcYlDfOwAB/1rcqwBqp3toJHyb4x0XTvEF7qPiv4ZfD7xRpfhWyjQX63Ie9i06YnBVrgKAFPy434bJPtXJ6FbQ3ninTbO5TfDNdRRyLkjcpcAjI56Gvu39pPxr8Mta/Zk8T2fwf8WeBFu9X1mK98T2dtqKQ3F8yKhZreNyplG9ImJQYbDkZYtXwp4dlig8YaVNNIkcaXkLO7nCqA4JJJ6CnF3QNH2v8AtSfsvfDjw98OJNU+Dnh2Sz1vRJ7d9V06G7uLp5rW5Zo4nCyu5yJEIG3GRvz90VN8RP2Z/hH4F/Yr8Q6sujJd/EDw7Z2sWpamt/cERXshgkdfLEnl4CTqB8v3Sp68074yftOaZ8NP204/GXg250jxxoV54Wg0+9tdO1SNoXkW4mdD5qCQK6Eg4wThz0zmuT0X4r6T4q/YH+M83inxVo8HizxD4kk1CPSpr2NLmVW+xEeVEzb2RQjKMDGEPoahc2hWhheKPCsMH7MvwQ1K5+Hfgywh1HVreOTWLKQSX2pKS2VukNqgCkdvNk6D8On/AGgf2ctQ8bfta32g/DHw94d8L6Fp2gwXt/etEun6bZ/60lpDGhAZgvZScAk4AJGf438Z+D7v9kD4B6Na+K9En1LS9Xt5b+yivomms0BfLSoG3RgZHLAV7h8WvjD8IPin4g8RfAjV/H+laTpeqadDeaf4u0zU42szcruJguXV9hA2KdrHDA4+VghJdoD5s+GHgyFf2XfjJNB4W8BeLo9K3Rr4nmndZ7XER+eyElmWYdxl4ufzriPBX7NHj7x58G0+Jmjan4bg0b7W1pKL+9a3e3CkB5pGZPLWNQckl846AnAPq3wsv/DXgL9kv47+BNb8b+FH1aYNFYpa6vbyrqI8kgNbEN+9ByPujIPBAIIrMs/GHhqH/glRqHhBfFGkpr82uCQ6P9tjF28X2iNt3k7t5X5c5xjjNO76CPnLxf4c/wCER8aX3h3+3tE137Iyr/aOh3X2qzm3IrZjlwNwG7B46gjtWJRRWhIUUUUAFFFFABRRRQAUUUUAeh/tEf8AJyfiT/t1/wDSWKij9oj/AJOT8Sf9uv8A6SxUV4nD/wDyK8L/ANe4f+ko9DNP98rf4pfmw/Z3/wCTk/Df/b1/6Sy155Xof7O//Jyfhv8A7ev/AEllrzyqw/8AyNK//Xul/wClVRVf9zp/4p/lA9v/AGbbW30/xB4n8d38EU9l4f0l5GUKGnV2y26IHgHZDKpO4ffA6E48l1HULvVtYu9V1Cbzru7me4nk2hd7uxZjgAAZJPAGK9h8E/6H+xL451Cz/wBHu5tTjtpLiL5JHizbDy2YclcSSDaeMO3qa8VrmyZKvj8binupKmvJRin+Lk2b49+zw2Hors5fNtr8Egooor6Y8kKcEdkZ1Riq/eIHA+tNr1b9nvXNO0/4yW+geIoBceHPEsD6JqsTKWAhlxtk/wBkpIqPu/h2k8VM5csXIqEeaSRv/CaK2tPg5d3hdVuNX8SWujFj/AvkvIoPsxLD6ir3iKw1K20P+3S3nWM1sY5IiOJIzmNoz7hVXnvtHQjNcZD4M+IFp8T9Y+C3hqCS/vDqayoqOqAtb7zFdByQqL5UjNuJxtb6V6T4W8VW3jGyTwvr8tnBe30M9mI4CPLF6kjyIF5xiaOeULjgtGAOorNuMlY78LWlRmntbT/NHvHwouLf4lfBrwrLf6femfSVaA3U1ou2Z1PlyMrMCrq+xS6nJDrng8n361/szw14ds4Zru3sLCECFDcOFLMSSADwCSdxwBk9ulfn58Kvj5qvwJ8Tar4Y1qwXUtFN0JprCSTypIWYAGaFiCOcAMpGDgHg5NfSOpftC/s+fEzwynhzxXrU+iF3gvEg1i1aPY6kOjB03oR7EjKsfWvDrUZqXke/iK10qbfup+u77f1dnv8AZ6vpmtWksmi6pbXflN5cjW0oYxtjo2OVPsa8u8a+GfEGm+FryPwfYaZa3M8bwm/cJDHp8TffkAUbmIBOFGBnkn1wrH4wfBfwVdSx+HfE6+KNXvlSNLDw/ALh2VclR8gCIPmJJZhj2rxb9pH4x/EHUtN0rQYDDoejat5guLS1l3zlFxkSTDHBBOQoA4xuasYU5Sko7GlGEqbbpax01tv/AEzg/CUy6D4S1XUDOJtS1i4/s+zlxhvKB7eg5BPPXFebarfC88fXBBzE967RkH74XC5/JBUkGqX897FIkojitoGW1AU4iLAhXxwMDLN1yx29hXNwWyLLdyS3czzWsDSxTjC7SpAAPXIJOMe9e7T2UTmxFaFPETq3v8/vt8vle5t+NfFqza9p1tpDAxaTIZhJ/DJcFgWYeoXaqj12k964eWWSed5pnZ5HYszMcliTkk1paNqk1lr4uBHFKkxMc0MiB0kRuqkHPHf1GMipdX0u2WEahpQLWv3Zk3bvJfPT12njBPfg9q6uZuVmfNTScee+t9v1MWiiimYhXtvxpmfxj8D/AAD8R2WI3DI+m308kaxzzzYPPyjHlh4LggZGPMGAMnHiVe16P/p37CXif7b/AKT9h1lPsnnfP9my9tny8/cz5snTH32/vHPzPECVKtg8WvijUUflUvFr72n8j1ssfPTr0Xs4N/OOq/VfM8IooqS3t57u7itbWCSeeZxHHFEpZnYnAVQOSSTgAV9EeSR0VdGkasXvUGl3pawybsCBs22G2nzOPkweOcc8VSoAKKKs3Wn3dna2VxcxbIr2E3Fu24HegkeMng8fPG4wcHjPQigD2nwn+1N428H6Lpttp/g74fXGp6ZaR2Nnr91oStqMMSII0AmVlyQoAyQScc5ryLxL4l1zxh4tv/E/iXUZdR1a/lM1zdS4y7HjoOAAAAAAAAAAABVxvAnjSK6s7e58K6vaNe3Edpbtd2r26SSucIgdwFBJ9TXPUctgvcKKKKAL+iaxfeHvE2na/pbol9p11FeW7yRrIqyRuHUlWBDDKjgjB717Td/tZ/ERfCmo6L4Z8OeB/Bz6lGYr3UfDWjLZ3VwCCDufcQDgn5gARngg14PUrW1wtml20Eot5HaNJip2MyhSyg9CQHUkdtw9RSaTC5FRRWrceGfElnosesXfh/VYNOkVXS8ltJFhdW+6Q5G0g5GOec0wMqirraPq6Wk12+l3qwQJFJLKYGCRrKMxsxxgBxypPXtmn2uha3e6imn2Wjahc3bxrMlvDbu8jIwDK4UDJUggg9CCDQBn0Vcm0rVLee6guNNvIpbRQ9ykkLK0ClgoLgj5RllGT3YDvSxaPq88HnQaXeyx/Z2u96QMw8lWKNLkD7gYFS3QEEUAUqKtw6VqlzNaw2+m3c0l2C1skcLMZwCVJQAfNyrDjuCO1Go6Xqej3ps9W067sLgDcYbqFonx67WANAFSiiigAooooAKKKKACiiigAooooAKKKKAPQ/2iP+Tk/En/AG6/+ksVFH7RH/JyfiT/ALdf/SWKivE4f/5FeF/69w/9JR6Gaf75W/xS/Nh+zv8A8nJ+G/8At6/9JZa88r0P9nf/AJOT8N/9vX/pLLXnlVh/+RpX/wCvdL/0qqKr/udP/FP8oHu/iH/kxLwX/wBhmT/0O8rxSva/EP8AyYl4L/7DMn/od5Xilc/DP8LEf9fqv/pbN83+Ol/17h/6SFFFFfSnkhX1v+ydaeE/DfgPXPH93qdsPEDzvYQIJmjmggVFdivBRixIJVuqxkDqRXyRXoPwi+I+ufDXxo2s6QlvdxFAbjTboZiuwpBA9nUbmU9cjHeufFU5TpuMdzpwc4Qqp1FofZ2raZpdv8GPHfxdurGDTPEraTd6TZ3Mf7rZHLtG1U6DdI52ZG5VIHsPhGfT2a9uo4A4+yYHyEg5B4OfX73P0r3H4rfHeb4s2Qtk0uPSdOjnW5cNJl5HQfKWwdoHJPcnjkYxXn2g2tg2nbpZhDNdgySNdyIijCkj5zgYwDwec4AJzx59CM6cby3Po4/V69Rwk0ovW/yen32OJ1CfxH8Q/EMK66sV1c2MQa41d8o01uDhfNKj53P3QQNxJ5z1G1Ktrqs9xG8UdldQLtgRsKVTAVUP94YCjI9M88itXXWsNN0J49GU4hG6aUEEXEpOCwwOgGAO2dxHByYNSs/ttvbwMcGRy7OpwVEaj/2aQflXS3Y4KFJKTtrZO/mun421+Z7ZbWnhf4N/BrRNe0ia2udT8R2MdwGkmMkjbciR5F42KjlkCjAJGM8MR4rrWsXOu+LnE7zavqDnHy5mH/AVXBb6cKMYwAKhTRbq/u7SK5vbmWCGRI1R5CwRS+cD+6CSxx6k9yTXUeDdbXwv4b1fU9MfyNV1BHmaZYCSIyzKB5vRCGySv8XygZNZ0aSUm27s6cRian1dKC5Y3svP+tPV38rcpJNq107WcWlgYbYz3brjd0+6PQ8VkaekkWq3dpqlrHAHjkiuIwPlVdpO8f7pAYf/AF66iC4RklUKWIkMKDPLbQMkn65yaoeJLC8uEe4mEKmRAwIYKzFMbsjO7BXnp1UVvCXLNdjB4VVMNKcU3NNelvPscVZq32kOoy3Rf948fp1/CtzT1uI1ke3jEjIuyaNhkTJypDflnPY1r+G/DoMpuZQG2kqox8ue+K2PD+ksvi7VLML9wBsegbBH8zUVcQrtroejgMglamqy+Ntfg3+h5vqNrHbXeYCWgkG+Inrj0PuDkH6VTr0Dxv4XbTYjcRofImYugA+5IBlh9GUZ+q15/XVRqqpHmR87mWAqYDESoVFqvyCvbfgp/wAkb+Ln/YF/9oXVeJV7b8FP+SN/Fz/sC/8AtC6rwOLf+RZP/FT/APTkDoyT/fI+kv8A0iR4NW94IuILT4neHLq6njggh1S2kkllYKqKJVJZieAABkk1g0V9AeSep2njHRL7SNXtpTJbXF9YM2qSyMqi6ljMccYi5yzFfMc55LO3GBmptR/4Q/8Ata2/tb/hGv7P/tyL7D/ZezP9n4ff9o8r58f6j/WfvPv15NRVcxPKeon+xP7U0n+2P+EU/trZff8AHn5H2H/VL9k87yv3WfM8zr22b+M1g/EG4jn/AOEbiE+kyXEGkmO5XSmjMMcv2u4YqBH8oOGBIXj5sjgiuMoouOx7RrM+nr8ddN15bXwjbaf/AMJNBcHVrLWlmmlj8/O+SP7S4RcfMT5a4wOg4PN2Z0MeMNJl0uy0a60f7NIIYbu4tYJo32YZrg3B2NIrEMA2UYDCgcged0UcwuU9bhsrZYPFNzplx4Tv7tL/AE1Ibu/tbOG3QPBcNJGg/wBQCNoB2na2wsMttqtrWoeBk8XeHNNtLbSP+EdeV5L+a3gUylft9xtVpMGRVEYjwOGKFc5+WvMlubhbOS0WeVbeR1keEMQjMoYKxHQkB3APbcfU1FRzBynrd7PoreLtIKeF/Dy7UuQZV1vSpI5AUARmVY44VKE7lEq5fJBzjjnfHcejRaVbLYX+l3t4dSuWmlsre3gIjNtaFVKwfJtV/OUFflLByOprhqKHIEi1cef/AGdZ+Z9l8ra/l+V5fmY3HPmbfmznpv5x04r1fU7/AE3/AIRG5kL+H4I5/DNnai/ttSWW9mlSGH9w1v5rbRvTaT5aEBc7vXx6iknYbVz13/hKdI0/RbtJbu3u7S6ttCtLy1ilUvLCLCVJwoz95GK/7rhc80uvvptza6n4W0bxLpb3Ih0oC6F4kEN9DBaeW8YlYhVIcq21iOR6rivIaKfMLlPSnTQo9T1rQtO1kBtR0KO3jbUNSjuI4rhbmGYw/aQqR7dsRAbhcnGau2HiG38L2a29vqWnz32meGvszhJ1lhmlfVFnaBWBxIPKkIYKSCN/YGvKKKOYOU9hvLvw7DpcOi+HvEFnA954feKyuJLgL9mL37zm2lf/AJZuYiUJOAT7NmuG8W2WmWGm6Pb2l9LLeLE4urf+0or+KE5GDG8ShVDfMduWI4ya5eihu40rBRRRUjCiiigAooooAKKKKACiiigAooooA9D/AGiP+Tk/En/br/6SxUUftEf8nJ+JP+3X/wBJYqK8Th//AJFeF/69w/8ASUehmn++Vv8AFL82H7O//Jyfhv8A7ev/AEllrzyvQ/2d/wDk5Pw3/wBvX/pLLXnlVh/+RpX/AOvdL/0qqKr/ALnT/wAU/wAoHu3hz/Tv2E/E/wBt/wBJ+w6yn2Tzvn+zZe2z5efuZ82Tpj77f3jnxWvZ/wBm8/2w3jfwJ/qf7b0Zv9M+95G3dF9zjd/x85+8PuY75HjtzbXFneS2l3BLb3ELmOWGVSjxsDgqwPIIIIINc2SNUcbjcK9+dTXpOK6eTi/zsr675gvaYfD1l/K4/OLf6NEVFFFfTHkhW14bMJvp4XZRNLbyJBuOMyEfKAexPOD64rFoHWgadnc6iytbCKRheOTKpwFlB+Qj68Z+o4rTv5EltLdEchPNXDRnkDBGR9K9g8AfsweNviX4N0/xTf6lp/huK7gVoFuonmluUxhZdi42KwAI3HJ6gYIqlrX7MHxZ0fx3p/hG3g0zUY73fLBqUE+2GONMbnlDDfGBuA6NkkAEk4rglVpqbjzbHpQhUULqOjPErm6W4tYo541FwsqrJIoxuXPftXT2s8MniBVeYII42AHJLAt82OD2Ar2zVf2JfHa6Us+k+MNA1C6X949o0UtuHb+6sjZHX+8B+FeM+LvC3irwrqlvo/inRLvQtUs4tkYn488BifMVs7XGNq5QkYUVKnCrpFm9CrPDScpx3t+af6Et3M1jGkgdE8jEoWQgEsRz069Bxk4ptmLeXw3FHNCB5VspQiVyCzKAWxuKg+px7VmWepRySh9RXZsVgY1woIIONuSB1x39agaaVdNgwwl8leUXB6/eI/GqUH3OmeYU2nFQutbXs90l20tbp289E8OXG63jM3MjTyRkegXJP5n+ldXq0Ojz6TpGpR3emo1uD/aNneTjzJ3SQ5KJy7B4yvQAAg9K4LQ592vOFP7vLzL/AMCAFddp2pqJ51jgjnjJWKVGVjuOeNpX5gR6jPUgg1T01MsHJzSp33dvlt3S+9nHR65qXh/xLKtreXE9tDMyrFcbgJEzxlTyMjB7EZrrbjxlZ6Lf6prOnrHcXN9HbpbxydEAj3MzY9CQMdz9K5jxZBHcXMmpxiJHWb7NJFGSyqAuY8EgEkKNpyAcrnHOBzFaSoQq2l0Jo5vjMA5UVLVPS+tnZp2+T+/U9J0/x9J4lsp9B8SRW4e4X/RbqNdgSUcqGHTBPGe2efbzmZDHcPGVKlWIweopgJByKdI7ySGR2LMxySe5q6dFU2+XZnJjcyrY6MXiHzSjpfq12fp+o2va/Cn+hfsR+OdQs/8AR7uXUo7aS4h+SR4t1sPLZhyVxJINp4w7eprxSvbvi1b3HhP9mX4e+Cru3lNxcySalK8qmJ4GALmFozk5BuypJI/1fTnA8DiJqrPCYRbzqxdvKF5v8kvn12NcrXJGvXe0YNfOXur8/wADwWiiivoTyQoq9Dp6eUsl5cGEMMqiJvcg9CRkAA/XPQ4wc1J9i03/AJ/rr/wGX/45VcrFdGbRWl9i03/n+uv/AAGX/wCOUfYtN/5/rr/wGX/45RysLozaK0vsWm/8/wBdf+Ay/wDxyj7Fpv8Az/XX/gMv/wAco5WF0ZtFaX2LTf8An+uv/AZf/jlH2LTf+f66/wDAZf8A45RysLozaK0vsWm/8/11/wCAy/8Axyj7Fpv/AD/XX/gMv/xyjlYXRm0VpfYtN/5/rr/wGX/45R9i03/n+uv/AAGX/wCOUcrC6M2itL7Fpv8Az/XX/gMv/wAco+xab/z/AF1/4DL/APHKOVhdGbRWl9i03/n+uv8AwGX/AOOUfYtN/wCf66/8Bl/+OUcrC6M2itL7Fpv/AD/XX/gMv/xyj7Fpv/P9df8AgMv/AMco5WF0ZtFaX2LTf+f66/8AAZf/AI5R9i03/n+uv/AZf/jlHKwujNorS+xab/z/AF1/4DL/APHKPsWm/wDP9df+Ay//AByjlYXRm0VpfYtN/wCf66/8Bl/+OUfYtN/5/rr/AMBl/wDjlHKwujNorS+xab/z/XX/AIDL/wDHKPsWm/8AP9df+Ay//HKOVhdGbRWkbCxYYj1CUN2M0G1fxKsx/Q1QmhkgmaKVdrr1HX6EHuO+e9JpoExlFFFIZ6H+0R/ycn4k/wC3X/0lioo/aI/5OT8Sf9uv/pLFRXicP/8AIrwv/XuH/pKPQzT/AHyt/il+bD9nf/k5Pw3/ANvX/pLLXnleh/s7/wDJyfhv/t6/9JZa88qsP/yNK/8A17pf+lVRVf8Ac6f+Kf5QOm+Hniv/AIQj4naP4naHzorOb98gXcxidTHJtG4fNsdtuTjOM8V3Px/8JS+GvjHe30Vr5Wn6x/p0DrvZS5/1wLNxu8zcxUEgCROmQB5BX0Toa/8AC4P2WJtGEXneJ/B+37Nsjy80AU7EG2PPzRqyBFOWeGNmPNcOby/s/HUMz+w/3c/JSfuy/wC3ZaP/ABHVgF9aw9TB/a+OPqlqvmvyPAqKKK+rPGCvb/2aPgnJ8WviR9q1eCQeFtIZZtQfoLhjylsp9XwSxHRQx6kV5R4Z8Ma14t8Xab4b0Oze41DUZhDbx4wGJ6knsoAJJ6AAntX6m/C/wRovwu+F+neENHZZFtlL3N1t2m6uGx5kp+pAAHZVUdq48biPYwst2deEwzrS8kdfFZ29pGrkrHFEvCp8qIoHTA7ADgdsVyvh2+PiXV9W8TQR5hef+zbYnr5UH3vzleTP+6PSuX+OnxV0/wCHnwo1O+eVWvpojDaQA/NLKwwige5/QMe1d38PdCk8KfCnw94fu3828tLGNbqU9ZLhhvmY/WRnNeByvlbPoJPktff9P6/I2kmhsLOKTUJ4o2kkWIHoC7HCqPUk8VneMPBXhX4geF5dA8WaNa6pYPyI5h80Tf343HzRsP7ykGuI+L2ui0k8L6fDceVcTaoJkw2D+7ikYY9eR09q6vw14oh1nTFlJVLlMCaPPQ+o9jUq8bNFTw0pU/aPqfC/xq/Z28QfCW6fXNDt/wC3/CTvxcNEDc2RJ4ScDqOwkAwTwQpxnx+LWbW80u4tY8QtIqvCwA4lXkDI9QSPxr9SvGqWeq/DXxBYXYVoZtNuFbceP9WxB/AgH8K/MPxP4fs7TxCCJVt1vFSRGxgQyNn5WHZSwIPcHHrXp0MQ6i5ZBhMFKKdam1o+Vp9VJNfLtfo2jkYLsw6jLOi+W88e3A42nOTx6810On3IsdENznlm3oPU9F/lXN3VvOurLDexiK6WRlcehP8A+utxrd5njiLBIIxgY6mu/Ro8ROVGo4rRp27MnIi1lbmK8lHnXzq8cpbASYbtpb2Ytt9s57Vx8kbxTNFIjI6kqysMEEdQa7pNZ0238P3mmG384INybMYBOc5P1APHvWHrUP27xNJ5hZZ2jj87y4y+6Xy138D3zn3zWlGbs01sdWb0o1JU8RCV3UV2uz2f3vU5+irEtlPDbrLKFXccBNw3f989RVfvWyaex4soSj8Ssdd8MvCUvjX4paTon2Xz7QzLPeg7wot0IaTcycrkfIDx8zKMjOa0vj34r/4Sr43ansh8qDSv+JVFuXazeU7b2b5iD+8aTBGPl25AOa77wUv/AAqP9nDVPiLcxeV4g17FnpO+P5okOdjDdGcZw82CSjrHFyCa+da+WwUv7RzSrjP+XdFOnHzlo5v8o+dn2PWxK+q4OFD7U/efp9lfmwq5pcaSaonmKHVFeXawyGKIWAI7gkc+1U6vaR/yEz/1wm/9FNX08dzxnsPZmd2d2LMxyWJySfWkoq1pmnXesa3Z6Tp8Rmu7ydLeCMdXd2CqPxJFaiKtFexeP/hXaaX4m8NwWum3vhbTL27fRp7zWYpYleWFwDefvcYSVHRwMhQQ4BAHGddfDCxtUktX1G5sYn1PTbQahrlgLNkS4W73OhS5kiaL/Rx8xJyRgMgVt4B5dRXq0Hw/8IaXN4rt/EV34nhistDhv7W6m0eJJFZr6CEyRxreFJVw+wHfg73PBjUNQ1/4WW/h/wACvrF14u0r+1I7WC7fSzdWm9lmCEIircGYyBZAxDQqMKxDHjIFzziiu98bfD7TPC8Wuf2X4ml1aXQ9ZGjX6yWH2YCRvOKNGfMbcP8AR5A2QuDjG4HNXdB8IaDrnwKa4itWXxVLqN61nOJWxPFbW9tI9tszt3FZpXUgbiYwvO4UBc81or2i8+Dmnav468T2GlX8mjJb6xd2Gl29x9n+zzCLkIJJrpZnYZAISKQjKkk5wOW0v4d6Ze6JbveeJ5LXVrnRrzXILFLAyRmGCOZwjS+YMO/kNxtICnOSflIK5wFFehat8MRp/wAMD4rh1eT7TBDbT3emXiW0UsaTbQrKkdzJLty64MkUeQwPtWr8KPhmfGPh7Ub648N6pqq3c40exns4pWSxuHjZ/tMpTgIjeSpD/LtlY/w5AO55RRXVeK9DtNH8KeEZ47Nre9vbC4lvtzNlpUvriEZBOFIWNFwMdPXJrptT8Bs3gfRrHQvDMF3q720dxqV0t632iykk3SIJ0LeUkDQGNg2BgkhnBBWgDy+iu9+Fui+GNZv/ABCviuDdZ2+k745/NdPsksl3bwCf5SN2wTM205BxyK6e9+F2lRaT4T8KyRfYfE91r0ek6tf7mlETzKjqgj3BT5ayJnGCW3AnpgFc8bor0HwP4XtZbG21+98m6ivLTxDbi0mgDLG9rpXnJKCScndOpHA2mMEHJ40/EfgrwlG+pp4aurh5bXwxpupSxaha+Skck/8AZ43xyi5I3Obp2beuxMsqg/K6AzyuivV/CPhLQdM8L+J7vxcng+e6srqwhguNR1C6u7NFmW5ZlD6W7FnPlJ1JA2nOCeTTvCPgy48J3usa9LJZRyeHDqtu+kWck/kt/bRtN22a5XedgCAHaNj5I3pukBXPKKK6+98DfY21wDVN40vQ7HWs+RjzftJtP3X3vl2/bPvc58voN3Fbx54a0rwh421Dw1p2uT6tNp11NaXUz2YtkDxuV+T94xbpzkDByBuHJBnM0UUUAFFFFABT7lRLonmN96CZUU/7LhiQfYFcj/eb1plSS/8AIvz/APXxF/6DJSewGXRRRWRR6H+0R/ycn4k/7df/AElioo/aI/5OT8Sf9uv/AKSxUV4nD/8AyK8L/wBe4f8ApKPQzT/fK3+KX5sP2d/+Tk/Df/b1/wCksteeV6H+zv8A8nJ+G/8At6/9JZa88qsP/wAjSv8A9e6X/pVUVX/c6f8Ain+UArqfh34w1XwN8Q7DX9It3u5EJilsg7KLqNuDGdvU9CMggMqnBxiuWrvvhR4zuPBniyW6ttPsr17iMRPFcwq5ePOWRWP3SeOmc4weOK9PEUKeIpSo1leMlZryZy0JzhUjOm7ST09Tp/jR4B0/SL2Pxz4Sazbwvq0irHDADGbScpuMZjblQdrtjA2HchVdq5850XT47u/WS8dIbOPLySShthA/hyo6k4H49q9s8Y6fNL4Q1Dxl8Pbq4/4RW6bdqOkwgK+lSKQ2x4+nlhsFXH3eM8YNeYW1rdapOUtnvb5QS5WLkjjk4HT3OK5cupVcJh40Ks+fl0Unu10v3a2b677nfiIQxFZzpx5b7x8+tvLy6HTDxFd6brmk3Hh29ubBtPCzW00FwdsW05KpggDIyCD1BOd2a+uPEX7SngrS/hVF40S8ZUuAyR2jAGfzh1hCZ5YZGT90Agk4Iz8Kgvp8j2sds2HI49Tz149cHA/pXHeIrqK51FLeGX7Q8RKtOGyrk44HsOme/wBMU62HjUSb6HR9flSk5OKu/kl2svT+u/uXgzxN4j/aF/a98I/8JOHTRotQ+2JZ5zFHDD+9YZP32bywpPfIAAGBX6Q3GprFE8sz7MAs5Pbua/LqdbHSvDi6dJaPHd2spjjEBLRqgYnIdTz8xJ6Z6nPavR7f9oHx/YfCyPwgsUF0IbZoY9allkeZF5ZZH6glQQBk9VXrisK2Gc7KJ0UrQblVfM2k21rby8n+B7p4x1u18V+Jb/XdQmWDStORorS5Y48oqcvOpPTaVCg99r9Qah+HPxBg8SaDHr2kzeVcQuYLmHGCjj1X+6www9jjqDXxd/wl2rXXhqDQLrU7s2cGSkMs7vDnOeU9c8+nsKteDPG2reC/EkmqabqBjaZDHMjJ5sco7B0yM4OCCCCD7EiqlgJcrXU76ecYf3Uuu/kfcfxW+KlrYfCPUNPYiHVNTj+x26Fsq2SN7dc7Quc/UDPNfG3iHVbfWGvXv0aW7+4JWkzk73ZyG787QM88nFZfiTxXrfim/fUr68lvp2G0THAEa/3URfuD2/Hk1z5mnMIifhRxkjFbYbDypxszizHFYZ8qpK7Tu3fS3bt53+Q69eXUFiv7gb54SIpueWXGMk+vQ/Umo/tVw3+iWUkr7jtIf5dnsSe/sKWK7t4La7RvneSMKgHTdnqfYDP44rb8AW2ga/8AEXS9K8Y+IToelTzbZtSEat5PBxnPABOAWPTrXVycsWzzcTXjiKkZX957+t7avz0M1bO8s0jjkSFy8oYbSx5XkDOO+Kv2+n6raXH2mJFlYjc55+YHnPPvzX2Zpvhb9l3wN4hHhDWraxufELBHgl8VTPLBdxvwkkMwBgCsOhwMHIPSvH/j78KPCfhXw2/iHwRby6bcW1wFv7NJnXyg/QeWzMV5wVKko6tlScEDlhiFJqK0udapR5X7SPNyro7NLV9tfmeTLJb3cgS8gMU3Vexz7MKf4X8JaHqfxJ0618RapBZaWZjcXc947Ks0ancY9wI2E4ILEjAJbtisrw5a+ItetNQkig8+y06Dz7i7mIVbf+4N56sxGAvJPPYEixe3G6NLpnBAKogx947uT7jGR+JpVf3sZ0IT5ZWtdbxutH69VfyOZqEOWpFNwetpeT/HtddLjPi349Txz44H9mRRW2gaWhsdKtoNyx+SpIEgQgBC4C8BRhVRTnbk8DUlwI1upRFnyw5C59M8VHW2CwdLB0IYeirRirL+u73fmefiK869SVWpuwq9pH/ITP8A1wm/9FNVGnwyyQXEc8TbZI2DqcZwQciupOzMWXau6Rq+oaFrMGraVcfZ7yAkxS7FYoSCMgMCM4JweoOCMEA1XjEF2u+CWGF/4oZZNm33Vm4I9s5+uMl/2OT/AJ72f/gXF/8AFVqSXdM8SatpFi9jZy272r3MV41vdWsVzG0sYdUYpKrA4EjgjGDnkHAxqXXxE8V3oSO5utPe2jlhlSy/sy1FqrQ+d5YEAj8sKDczkrtwxckgnBHPfY5P+e9n/wCBcX/xVH2OT/nvZ/8AgXF/8VQLQ6EfEXxWNZ/tL7VYbhaGw+y/2Za/ZPIMnmeX9m8vydvmfPjZ97nrzVa98aeINS8OJomoS2F1bpGkKTTadbPdJGhGxFuTH5yqAAAA+Nvy9OKx/scn/Pez/wDAuL/4qj7HJ/z3s/8AwLi/+KoDQv6j4o13Vjq51C+87+2L9dTvv3SL51wvm4fgDb/r5eFwPm6cDCWPibXdMttNgsNQeBNNvm1K02KuYrhhGC4OMniGPg5Hy9OTmj9jk/572f8A4Fxf/FUfY5P+e9n/AOBcX/xVAaHWQfFjx7bajc38WtQm6uLyW/ad7C3d0mlx5jRs0ZMYfADKm1SBgir2ifFB9E+G8/hyLTrm4vZLO50+O7uJ4WjggnDB0RRB5wGHc7fOKbju25rhfscn/Pez/wDAuL/4qj7HJ/z3s/8AwLi/+KoDQ3734g+LdQ8My6Bd6lC9jNDDBMFs4EknSIr5QklVA7ldigFmJAGM4JFY82s6ncaVp+myXR+y6eZGtY0UL5bOwZmyACSSBycnAA6AVB9jk/572f8A4Fxf/FUfY5P+e9n/AOBcX/xVAaGj4h8Va94ru4rnXr1bqWLzdjCGOLHmTPM/CKAcySu3/AvTArWtvif42s7CO0g1WDaluLMyPYW7yyW4XaIJJWjLyRbQB5bkrgAY4Fcx9jk/572f/gXF/wDFUfY5P+e9n/4Fxf8AxVAaEtjq1/p1rqFvZT+VFqFv9kul2KfMi8xJdvI4+eJDkYPGOhIqey8R63p1laWljfvbxWl6NRt/LVQ0dwAoEgbGcjavGccVT+xyf897P/wLi/8AiqPscn/Pez/8C4v/AIqgLo6K9+I3i+/Nv5+o26LbpdpDHbWNvBHGLuEQ3GEjjC/OgweODlhhiTVa58b+JLvRf7KnvLdrc2K6a7LZwLLJbq8TpG8oQO4U28O3cxKhcDAJBxvscn/Pez/8C4v/AIqj7HJ/z3s//AuL/wCKoDQlh1bULfQLvRYbjbY3k0VxPDsU73iDiM5xkYEsnAODu5zgY09N8beJNK+yra3lu0dtZNp0cFzZwXERt2na4MbxyIyyDzWL/MCQcY6DGP8AY5P+e9n/AOBcX/xVH2OT/nvZ/wDgXF/8VQGhuz+P/Flz4Wl8PTajE1hNaxWUqi0hEksMTo8aPKE3sEMabcsdoG0YBIONq2qX+ua/fa1qk/n319cSXVzNtVfMkdizNhQAMkk4AAqP7HJ/z3s//AuL/wCKo+xyf897P/wLi/8AiqA0K9FWPscn/Pez/wDAuL/4qj7HJ/z3s/8AwLi/+KoC5Xoqx9jk/wCe9n/4Fxf/ABVH2OT/AJ72f/gXF/8AFUBcr1JL/wAi/P8A9fEX/oMlSG12DdLd2aIOrCdXx+CEk/gKo3l0swSGEEQRkld33mJxlj6ZwOOgwOvJKk7Ie5VooorIo9D/AGiP+Tk/En/br/6SxUUftEf8nJ+JP+3X/wBJYqK8Th//AJFeF/69w/8ASUehmn++Vv8AFL82H7O//Jyfhv8A7ev/AEllrzyvQ/2d/wDk5Pw3/wBvX/pLLXnlVh/+RpX/AOvdL/0qqKr/ALnT/wAU/wAoBSqzI4dSVYHII7Gkor2TgO58OfETVdK1WC5WcW0wAWSaPIWYdB5i5wfrjucg5NduNPtPEsko8Naonh+SZjJJZ20Q8syE5U/KQwTPQDIHYDpXh9aGna3qWlyq9ncuhU5Xn7p9vSpcVa1jrpYucanPKT13tu0dX4quPE3hvTr+11y7uhNKnkxsX3LMzcblbHIChueCOAcVyOhaEI9uo6ggyF8yGB4w4P8AtSKSPl6cY5z2HX1/Tl8ReMvCll4jkisdRuIDIkdtG2ZYQuN0ixNw0hx1UlgoGAM1yuoXdtNESsDzSg7vLVH3MfpjOf1rFxs9rHbWmq8ud1HJLa+/5/kZkEM1zGzmWWIH7ixllDnjnB6Dn/PWrV9LewaBeQT30iSuilrKLIVE3AZkzj5jxhQOAeT2rpdH0bxI8F5c2+nS6W5RRHd3URQww9WkCkZG1RgHAAyTkdayPEEHhHTvD11Haaxcanqs+FDOdwX5wWY7eM4HfPWiKvKz6GqcadFyg/eafW1lqu+r8uifU4Siiiuw8IUMVOVJB9qGdmOWYn6nNJRQAVuWnhqd7AX2oXUVhC6FoUkBaabjjZGOcHjk4HPU1Q0ya1tbwXV1GJhHysRGQzdsj0Fd1oHhHx18QtRjuNJ8LSSQXHP9pXoZLYKH2Md5wrbTnIXc3DYBwa48Zi6eGg6lWajFdW0l+J6WCwsKu+sntFXfzdv+B6o4xrPUbpYkurxSIU8uNZp92xASdoGTgZJOPc1oS2Yut4ur+6utkSw24kZ3aNQcgDjBXk4HAGa9dPg74QfCWRLv4iayPEXiBCr/ANh6cu6OJv3TYaPIzjcSDKyq6E/ISK8p8efE7WfG9xFAtnZ6LpFspjttM05fLjVN2V3kY3sAFHQKNuVVcnPk4LOZZhVX1Sk3S/nfup/4U1eXrovM2rYKGDi/bzXP/KtX8+i/Fl6TXJrXQ10a1ee30dZGkS2lkWJGYgDfJjHmNhQNxHbAAHFcxqOrRFn8iQTTMMB1BCRD/Zz1PvWCSSck0V7FOhGnpFW6+r8zjqYty2Wvm729NkvuCiiitjjCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD0P9oj/k5PxJ/wBuv/pLFRR+0R/ycn4k/wC3X/0liorxOH/+RXhf+vcP/SUehmn++Vv8UvzYfs7/APJyfhv/ALev/SWWvPK9D/Z3/wCTk/Df/b1/6Sy155VYf/kaV/8Ar3S/9Kqiq/7nT/xT/KAUUUV7JwBRRRQBo6Tr2saFOZtJ1Ge0Y9fLbhvqOhrq3+MnxEewa1bxDLtZdpcIofH+8ORXB0UDTaO68IfF7xx4M1mbUNO1GO7Fwcz299H5scuAwHIwy8tn5WXJAzkDFd/N8afhp4xlDfEf4WRtcFEkm1HSpR508yqE55jcR4zgGRsYUYOMjwaivGxuQYLF1vrEouNT+aLcZffFq/zud+HzTEUIeyTvDs0mvuf6Hu/9j/sw3w+2/wDCaeJdN8/979h8l2+zbufLz9nfO3OM726fePUu/wCFKfDz/ovXhn8oP/kmvBqK5v7FxlP+Bjqi/wAShP7rx0/U2/tGhP8Ai4aL9OaP5M95/wCFKfDz/ovXhn8oP/kmm/8ACKfs2WR+x6h8TNbnu4f3U8trAxid14ZkIt3G0kEjDMMY+Y9a8Ioo/sbG1NK2OqNf3VCP5Rdw/tDDx/h4aPzcn+p71b/Fr4MeE7yG78FfCeW7uC4kebVpwHgZDlGiLGYg5JJI29F68Y5HxX8e/iV4q8pP7Z/sSCPB8nRS9tuYbvmL7i54bG3dt4BxkZrzOitKHDWApVPbTg6k/wCabc3/AOTNpfJIirm+KnH2cZcse0Uor8Aooor3jzAooooAKKKKACtfwqtk/jjSE1GFZbVryJZEYgKQWA+bIIK+o7jI4zmsiihAz1/RNNFn4o1RLeC+02CLXLL/AEOXYVkBmfDD92CFxyoBxg9Wqta+HNFtfirY+fayanbX/wBqb7TIyG3eXa58sIVPKn5cMQd2DgYwfKaK05/Ijk8z0DR/BGmalCslxDqts0l29vLGZEzpqqoIefKDOT7J9c1dvtBtNQ+Fej3PmzXdxZWc5itbVgrOvntmU5Byi45AGeR0HNeZUUuZdh8r7nY6f4LdINVTVbG/utSsJI4/7K0+VPNIcZ35CvlQMdAevarNp4L0u48LpqDz3il7Oa5e73r5FtIhIEDjbksceoPPANcLRSuuwWfc9Gl8HeFbXRprqf8AtiSS20+0vZNlxGquZiFKqDGcAE5yc1XvvCunaPrh0GUmYXmrLbxSuB5ghQAtg44LNIq59UNcDUjXE7JEjTyFYRiMFjhBnPy+nJJ47mnzLsHK+56Zd6Rp1x4MlupdKhgiEEcizxxRxpGWgkk+Vwu9irokZDs2ST0JGM+78F6AukSeRc38N3DptrqEk00iNF+9YBl2hAQBnOd1cle+INW1C0a3u7iN1cgyOII1klI6b3Chn/4ETWZQ5LsJRZ6NrHgXw5pN5YCS+1JreW+jtpJhG+ySNh/rEkMQQEH+EM+R3pdR+HukaXpF5c3WqTCSyUQXA3LhLh2jMfblNkhJ75U8ivOKKOZdh8r7nr9x4S06z8KT6EGvbKzn1q3iN/eOrJMuw/vI8KAFOcdT2561iDwHpDarp8EsuoWLXH2nNhcOhuJPKGUKHaAN/bI+ma87oocl2Eovuesa14atL630i2mtNSiez0XzYtL3r9qlbzT8mdnUZJPyZx2qlY/DzRbnXdSsFub+drfyvKCkoiFk3MssyxSKrKeOQP6V5pRRzLsHK+56BZfD+C68C3WsSmWKaGzmu0ljn82J/LJ+UgRBVyB/z0J74x01bbw9p+ieBNcmih1C4gn022kkvt6+TNudWZI/l4I6ck+4HfyqijmXYbi31PSh8PvD6araWs+sTKuoSPPYsHX95aiMMucKTvZm2jA/hbAPAqtJ4M0C11TUBcvqzW9rpRvzAVaCQOHC7d0sK7l/2gg/SvPqKOZdg5X3PTn8MaHYaB4mtLfTLzUZkisrqAh0M8cbqWO0iM4CnO4gYIx93GTQuPAVnHoV1q0ZvmtE022uoZ9ylHlkYB1zt5AyeByOM1wFFHMuwcr7nozeCfDUvjnVNBtp9RT+zoi22WYPJdN8vCBISVAyc4VyeOBzXH+JdLttG8TXGn2ctxJDHtKm5heGQZUHDK6qeM9cDPXvWTRSbT6Ak11CiiipKCiiigAooooA9D/aI/5OT8Sf9uv/AKSxUUftEf8AJyfiT/t1/wDSWKivE4f/AORXhf8Ar3D/ANJR6Gaf75W/xS/NnJ+AfE8ngz4maL4mV5VjsrpXnEKK7tCfllVQ3GWjZ1HI69R1rd+KnhC28G/Ei5stMkim0a8RdQ0uaGQOj2suSm1tzEhSGQMTltm7owrz+u98GeLNDn0638E/ERbqfwz5/mW17bH/AErSJGI3vESGzE/8ceCP41G4fNWLp1KFdY2kubTllFbtXumu7i72XVSdtbJqhONSk8PN21un0T2afk9NejS6HHUV6hN8Eda1WUT/AA513R/GtgUSRpLK6igntwygr58MjgxkneAMk/IchTxUf/DPnxe/6FH/AMn7X/47TXEOWW97EQi+0pKLXrGVmvmgeV4zpSk/NJtfJq6fyPM6K9M/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdo/1hyv8A6Cqf/gcf8w/svG/8+Zf+Av8AyPM6K9M/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdo/1hyv8A6Cqf/gcf8w/svG/8+Zf+Av8AyPM6K9M/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdo/1hyv8A6Cqf/gcf8w/svG/8+Zf+Av8AyPM6K9M/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdo/1hyv8A6Cqf/gcf8w/svG/8+Zf+Av8AyPM6K9M/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdo/1hyv8A6Cqf/gcf8w/svG/8+Zf+Av8AyPM6K9M/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdo/1hyv8A6Cqf/gcf8w/svG/8+Zf+Av8AyPM6K9M/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdo/1hyv8A6Cqf/gcf8w/svG/8+Zf+Av8AyPM6K9M/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdo/1hyv8A6Cqf/gcf8w/svG/8+Zf+Av8AyPM6K9M/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdo/1hyv8A6Cqf/gcf8w/svG/8+Zf+Av8AyPM6K9M/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdo/1hyv8A6Cqf/gcf8w/svG/8+Zf+Av8AyPM6K9M/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdo/1hyv8A6Cqf/gcf8w/svG/8+Zf+Av8AyPM6K9M/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdo/1hyv8A6Cqf/gcf8w/svG/8+Zf+Av8AyPM6K9M/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdo/1hyv8A6Cqf/gcf8w/svG/8+Zf+Av8AyPM6K9M/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdo/1hyv8A6Cqf/gcf8w/svG/8+Zf+Av8AyPM6K9M/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdo/1hyv8A6Cqf/gcf8w/svG/8+Zf+Av8AyPM6K9M/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdo/1hyv8A6Cqf/gcf8w/svG/8+Zf+Av8AyPM6K9M/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdo/1hyv8A6Cqf/gcf8w/svG/8+Zf+Av8AyPM6K9M/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdo/1hyv8A6Cqf/gcf8w/svG/8+Zf+Av8AyPM6K9M/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdo/1hyv8A6Cqf/gcf8w/svG/8+Zf+Av8AyPM6K9M/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdo/1hyv8A6Cqf/gcf8w/svG/8+Zf+Av8AyPM6K9M/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdo/1hyv8A6Cqf/gcf8w/svG/8+Zf+Av8AyPM6K9M/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdo/1hyv8A6Cqf/gcf8w/svG/8+Zf+Av8AyPM6K9M/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdo/1hyv8A6Cqf/gcf8w/svG/8+Zf+Av8AyPM6K9M/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdo/1hyv8A6Cqf/gcf8w/svG/8+Zf+Av8AyPM67T4V+ELbxl8SLay1OSKHRrNG1DVJppAiJaxYL7m3KQGJVCwOV37uimtyH4I61pUpn+I2u6P4KsAjyLJe3UU89wFUlvIhjcmQg7ARkH5xgMeKwPGfizQ4NOuPBPw7W6g8M+f5lze3J/0rV5FJ2PKQFxEn8EeAP42G4/LjXzKOOjLD5dO7kvjWsYrvzbOS6JNu+9ldmlPCPDNVcVGyX2Xu/K26XdvptdmL4+8TyeM/iZrXiZnlaO9umeATIqOsI+WJWC8ZWNUU8np1PWiucor1aFGFCnGlTVoxSS9FojhqVJVJuct27v5hRRRWpAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB//2Q==",
	"ketawa": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwMDAgQDAwMEBAQFBgoGBgUFBgwICQcKDgwPDg4MDQ0PERYTDxAVEQ0NExoTFRcYGRkZDxIbHRsYHRYYGRj/2wBDAQQEBAYFBgsGBgsYEA0QGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBj/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4Poor0iwsE+F0dhret6XHdeKbhFurDTbxG8qwi3ECaYAgtKSpCoD8mNzYYADWc+XRat7I4cTiVRSSV5PZd/8AJLq+nrZPD0T4ZePfENp9q0vwzePBsSRZZ9tusisMqyGQqHBAzlc9R6itT/hSPxP/AOhY/wDJ23/+OU7Sn8QfFn4j2Gka/wCIrgyXHmbJnQOkO2IsdkQKqufLAOMZ6nJr0X/hmr/qdP8Aynf/AG2uOtiXRfLUmk+1m/xueBjs6lgpqniq8ISavbknLTb4lJX27L0POP8AhSPxP/6Fj/ydt/8A45R/wpH4n/8AQsf+Ttv/APHK9H/4Zq/6nT/ynf8A22j/AIZq/wCp0/8AKd/9trL6/D/n6v8AwGX+Zxf600f+guH/AIKqf/JnnH/Ckfif/wBCx/5O2/8A8co/4Uj8T/8AoWP/ACdt/wD45Xo//DNX/U6f+U7/AO20f8M1f9Tp/wCU7/7bR9fh/wA/V/4DL/MP9aaP/QXD/wAFVP8A5M84/wCFI/E//oWP/J23/wDjlH/Ckfif/wBCx/5O2/8A8cr0f/hmr/qdP/Kd/wDbaP8Ahmr/AKnT/wAp3/22j6/D/n6v/AZf5h/rTR/6C4f+Cqn/AMmecf8ACkfif/0LH/k7b/8Axyj/AIUj8T/+hY/8nbf/AOOV6P8A8M1f9Tp/5Tv/ALbR/wAM1f8AU6f+U7/7bR9fh/z9X/gMv8w/1po/9BcP/BVT/wCTPOP+FI/E/wD6Fj/ydt//AI5R/wAKR+J//Qsf+Ttv/wDHK9H/AOGav+p0/wDKd/8AbaP+Gav+p0/8p3/22j6/D/n6v/AZf5h/rTR/6C4f+Cqn/wAmecf8KR+J/wD0LH/k7b//AByj/hSPxP8A+hY/8nbf/wCOV6P/AMM1f9Tp/wCU7/7bR/wzV/1On/lO/wDttH1+H/P1f+Ay/wAw/wBaaP8A0Fw/8FVP/kzzj/hSPxP/AOhY/wDJ23/+OUf8KR+J/wD0LH/k7b//AByvR/8Ahmr/AKnT/wAp3/22j/hmr/qdP/Kd/wDbaPr8P+fq/wDAZf5h/rTR/wCguH/gqp/8mecf8KR+J/8A0LH/AJO2/wD8co/4Uj8T/wDoWP8Aydt//jlej/8ADNX/AFOn/lO/+20f8M1f9Tp/5Tv/ALbR9fh/z9X/AIDL/MP9aaP/AEFw/wDBVT/5M84/4Uj8T/8AoWP/ACdt/wD45R/wpH4n/wDQsf8Ak7b/APxyvR/+Gav+p0/8p3/22j/hmr/qdP8Aynf/AG2j6/D/AJ+r/wABl/mH+tNH/oLh/wCCqn/yZ5x/wpH4n/8AQsf+Ttv/APHKP+FI/E//AKFj/wAnbf8A+OV6P/wzV/1On/lO/wDttH/DNX/U6f8AlO/+20fX4f8AP1f+Ay/zD/Wmj/0Fw/8ABVT/AOTPOP8AhSPxP/6Fj/ydt/8A45R/wpH4n/8AQsf+Ttv/APHK9H/4Zq/6nT/ynf8A22j/AIZq/wCp0/8AKd/9to+vw/5+r/wGX+Yf600f+guH/gqp/wDJnnH/AApH4n/9Cx/5O2//AMco/wCFI/E//oWP/J23/wDjlej/APDNX/U6f+U7/wC20f8ADNX/AFOn/lO/+20fX4f8/V/4DL/MP9aaP/QXD/wVU/8Akzzj/hSPxP8A+hY/8nbf/wCOUf8ACkfif/0LH/k7b/8AxyvR/wDhmr/qdP8Aynf/AG2j/hmr/qdP/Kd/9to+vw/5+r/wGX+Yf600f+guH/gqp/8AJnnH/Ckfif8A9Cx/5O2//wAco/4Uj8T/APoWP/J23/8Ajlej/wDDNX/U6f8AlO/+20f8M1f9Tp/5Tv8A7bR9fh/z9X/gMv8AMP8AWmj/ANBcP/BVT/5M84/4Uj8T/wDoWP8Aydt//jlH/Ckfif8A9Cx/5O2//wAcr0f/AIZq/wCp0/8AKd/9to/4Zq/6nT/ynf8A22j6/D/n6v8AwGX+Yf600f8AoLh/4Kqf/JnnH/Ckfif/ANCx/wCTtv8A/HKP+FI/E/8A6Fj/AMnbf/45Xo//AAzV/wBTp/5Tv/ttH/DNX/U6f+U7/wC20fX4f8/V/wCAy/zD/Wmj/wBBcP8AwVU/+TPOP+FI/E//AKFj/wAnbf8A+OUf8KR+J/8A0LH/AJO2/wD8cr0f/hmr/qdP/Kd/9to/4Zq/6nT/AMp3/wBto+vw/wCfq/8AAZf5h/rTR/6C4f8Agqp/8mecf8KR+J//AELH/k7b/wDxyj/hSPxP/wChY/8AJ23/APjlej/8M1f9Tp/5Tv8A7bR/wzV/1On/AJTv/ttH1+H/AD9X/gMv8w/1po/9BcP/AAVU/wDkzzj/AIUj8T/+hY/8nbf/AOOUf8KR+J//AELH/k7b/wDxyvR/+Gav+p0/8p3/ANto/wCGav8AqdP/ACnf/baPr8P+fq/8Bl/mH+tNH/oLh/4Kqf8AyZ5x/wAKR+J//Qsf+Ttv/wDHKP8AhSPxP/6Fj/ydt/8A45Xo/wDwzV/1On/lO/8AttH/AAzV/wBTp/5Tv/ttH1+H/P1f+Ay/zD/Wmj/0Fw/8FVP/AJM84/4Uj8T/APoWP/J23/8AjlH/AApH4n/9Cx/5O2//AMcr0f8A4Zq/6nT/AMp3/wBto/4Zq/6nT/ynf/baPr8P+fq/8Bl/mH+tNH/oLh/4Kqf/ACZ5x/wpH4n/APQsf+Ttv/8AHKP+FI/E/wD6Fj/ydt//AI5Xo/8AwzV/1On/AJTv/ttH/DNX/U6f+U7/AO20fX4f8/V/4DL/ADD/AFpo/wDQXD/wVU/+TPOP+FI/E/8A6Fj/AMnbf/45R/wpH4n/APQsf+Ttv/8AHK9H/wCGav8AqdP/ACnf/baP+Gav+p0/8p3/ANto+vw/5+r/AMBl/mH+tNH/AKC4f+Cqn/yZ5x/wpH4n/wDQsf8Ak7b/APxyj/hSPxP/AOhY/wDJ23/+OV6P/wAM1f8AU6f+U7/7bR/wzV/1On/lO/8AttH1+H/P1f8AgMv8w/1po/8AQXD/AMFVP/kzyTW/hl498PWn2rVPDN4kGx5Glg23CxqoyzOYywQAHOWx0Poa5OvUfEth4g+DHjaGy0DxTcPJcWq3LyJCI0bLSIFeMsyvjBIJ6buMHmq1/YJ8UY7/AFvRNLjtfFNujXV/ptmjeVfxbgDNCCSVlBYBkJ+fO5csSD1wrPlU5WcX1Wn3p/5nuYbMZuEa1VqVKW00nG3rF3aXnd+aS1PN6KKK6T2jrPhjokHiH4t6Fpd0YzA1x50iSRiRZFiUylCp4IYJt/HoelVvFPiC58U+MdQ1+7XZJdylxHkHy0A2omQBnaoVc45xk81u/BH/AJLvoX/bx/6TyVxdZQ1rS8kvxbv+SPMiubMJt/ZhG3lzSnf7+VfcWLK+vdNvkvdOvLizuY87J7eQxuuQQcMDkZBI/Gtf/hOfG3/Q4a//AODCb/4qsCit5QjLVo7KmHpVHecU35o3/wDhOfG3/Q4a/wD+DCb/AOKo/wCE58bf9Dhr/wD4MJv/AIqsCip9lD+VGf1PD/8APtfcjf8A+E58bf8AQ4a//wCDCb/4qj/hOfG3/Q4a/wD+DCb/AOKrAoo9lD+VB9Tw/wDz7X3I3/8AhOfG3/Q4a/8A+DCb/wCKo/4Tnxt/0OGv/wDgwm/+KrAoo9lD+VB9Tw//AD7X3I3/APhOfG3/AEOGv/8Agwm/+Ko/4Tnxt/0OGv8A/gwm/wDiqwKKPZQ/lQfU8P8A8+19yN//AITnxt/0OGv/APgwm/8AiqP+E58bf9Dhr/8A4MJv/iqwKKPZQ/lQfU8P/wA+19yN/wD4Tnxt/wBDhr//AIMJv/iqP+E58bf9Dhr/AP4MJv8A4qsCij2UP5UH1PD/APPtfcjf/wCE58bf9Dhr/wD4MJv/AIqj/hOfG3/Q4a//AODCb/4qsCij2UP5UH1PD/8APtfcjf8A+E58bf8AQ4a//wCDCb/4qj/hOfG3/Q4a/wD+DCb/AOKrAoo9lD+VB9Tw/wDz7X3I3/8AhOfG3/Q4a/8A+DCb/wCKo/4Tnxt/0OGv/wDgwm/+KrAoo9lD+VB9Tw//AD7X3I3/APhOfG3/AEOGv/8Agwm/+Ko/4Tnxt/0OGv8A/gwm/wDiqwKKPZQ/lQfU8P8A8+19yN//AITnxt/0OGv/APgwm/8AiqP+E58bf9Dhr/8A4MJv/iqwKKPZQ/lQfU8P/wA+19yN/wD4Tnxt/wBDhr//AIMJv/iqP+E58bf9Dhr/AP4MJv8A4qsCij2UP5UH1PD/APPtfcjf/wCE58bf9Dhr/wD4MJv/AIqj/hOfG3/Q4a//AODCb/4qsCij2UP5UH1PD/8APtfcjf8A+E58bf8AQ4a//wCDCb/4qj/hOfG3/Q4a/wD+DCb/AOKrAoo9lD+VB9Tw/wDz7X3I3/8AhOfG3/Q4a/8A+DCb/wCKo/4Tnxt/0OGv/wDgwm/+KrAoo9lD+VB9Tw//AD7X3I3/APhOfG3/AEOGv/8Agwm/+Ko/4Tnxt/0OGv8A/gwm/wDiqwKKPZQ/lQfU8P8A8+19yN//AITnxt/0OGv/APgwm/8AiqP+E58bf9Dhr/8A4MJv/iqwKKPZQ/lQfU8P/wA+19yN/wD4Tnxt/wBDhr//AIMJv/iqP+E58bf9Dhr/AP4MJv8A4qsCij2UP5UH1PD/APPtfcjf/wCE58bf9Dhr/wD4MJv/AIqj/hOfG3/Q4a//AODCb/4qsCij2UP5UH1PD/8APtfcjf8A+E58bf8AQ4a//wCDCb/4qj/hOfG3/Q4a/wD+DCb/AOKrAoo9lD+VB9Tw/wDz7X3I3/8AhOfG3/Q4a/8A+DCb/wCKo/4Tnxt/0OGv/wDgwm/+KrAoo9lD+VB9Tw//AD7X3I3/APhOfG3/AEOGv/8Agwm/+Ko/4Tnxt/0OGv8A/gwm/wDiqwKKPZQ/lQfU8P8A8+19yN//AITnxt/0OGv/APgwm/8AiqP+E58bf9Dhr/8A4MJv/iqwKKPZQ/lQfU8P/wA+19yN/wD4Tnxt/wBDhr//AIMJv/iqP+E58bf9Dhr/AP4MJv8A4qsCij2UP5UH1PD/APPtfci5qOq6prF0tzq2pXl/OqCNZbqZpWC5J2gsScZJOPc1b8L+ILnwt4x0/X7Rd8lpKHMeQPMQja6ZIONyllzjjORzWRRVOEXHla0NJUKcqbpOPutWt0szoPidokHh74t67pdqYxAtx50aRxiNY1lUShAo4AUPt/DoOlFanxu/5Lvrv/bv/wCk8dFc+HblSg32X5HPlVSVTBUZzd24Rb+5B8Ef+S76F/28f+k8lcXXafBH/ku+hf8Abx/6TyVxdOn/ABpei/ORnT/3+r/gh/6VUCiiiuk9EKKKKACiiigAorX8P+FvEHim+NpoGlXF9Iv32QAJHkEje5wq52nGSM4wOa9Ct/gVqNnax3njDxVovh+1kQBWkk8xllIz5Z3FFzgNyrH7vGRyMKmJpU3aUtfx+48/FZrhMLLkrVEpdt39yu/wPJqK9gPhH4G2eLXUPHWsyXUQCSvBEfLdh1ZMQMNpPIwzcY5PWl/tn4A4z/wg2vf9/n/+SKz+t3+GEn8v87HL/bV/gw9R/wDbtv8A0pr8Dx6ivYf7a+AH/Qj67/3+f/5Ipv8AYPwBuz9q/wCEp1+x87959k8tj5GedmfJbO3OPvN06nrR9aa3py+7/K4f21b48PUX/bt//SWzyCivXT8Czqf/ACKHjvQdb8v/AI+Mts8rP3f9WZM5w3XHTv24HxF4J8VeE/LPiDRbizjkwFmyskZJzhd6Eru+UnbnOBnGK0p4qlUfLGWvbZ/czow2b4PEy5KVRc3Z6P7nZ/gYFFSvbzR28U7xlY5c7GP8WDg/rUVbnptNbhRRRQIKKKKACrFjZXOpapbadZRebc3MqwQx7gu52IVRk8DJI61Xro/A3/I2v/2DdQ/9IpqmbtFtGOIqOnSlNbpN/gXoYfDelx/Z10mHWphxLdXksyRMR3hSNo2VeSMuWLAKcJkrUn2zQf8AoSdF/wC/97/8kVnV698N/Bfh7XvA1je6jo1peT3GtvZTzTXkkMiQCAP+6RZFDuDyAFYnJ47jvw2XqvLkjv6v9DxM3x1DK6H1nEOTV7aSfZv+aK6dPkjzL7ZoP/Qk6L/3/vf/AJIo+2aD/wBCTov/AH/vf/kivU/AXgjwjquk2dzqmlS3QbXby0fzJZIneCOzaVUIVhtO4A9j26cVQ8RfDrTovDugf8I/H582t6s0dndl2PmWzqhjDLnAK7mDcA5U1v8A2RL2ftFt6u/T/M8xcR4D619Ulzp923b7V9ebpyN7Xt87ed/bNB/6EnRf+/8Ae/8AyRR9s0H/AKEnRf8Av/e//JFd38TfCXh3S9JtNY8JxQLZxXMmnXXk3y3Yd15jlJV22F1DfKcY29BXPw+CPN+ENx46/tq1XybsWv2Aj52yQM5z15ztx0BOayqZa4TcLXsr7vY7cLmuCxGHp4nmlFTlypNyvzN2Sdm7X9bWMT7ZoP8A0JOi/wDf+9/+SKPtmg/9CTov/f8Avf8A5IrpPC2iaTJ8PvEHim907+1rjTpIIo7EyOkahycyybCGIGMDBHPWt3wvpHgbX9N1K81fQbjSZdEH9o3FtbyysLy2K/6r52yh3lcMP4W7kbqdPLVPl1tfXd+fy6MjFZrh8P7RuNSSptRbTb1aTStz8z+KKva13va7PPvtmg/9CTov/f8Avf8A5Io+2aD/ANCTov8A3/vf/kivXdD8GeDNb8IaHM2i2cN/rFpqM8cMdxdeezxO/lrESxiCqoAPmcnA6nNcze6L4a0/4MeH9WNpoyanqNvdmSS+e9M0jJKUUwiI+UCBj7+BnGc81pLKeWPM2rWvu/L8dUctLiDCVansYwq83PyWu9/f1+P4f3ctfL1txH2zQf8AoSdF/wC/97/8kUfbNB/6EnRf+/8Ae/8AyRXquueBvDVt8N5NRi0WGGSPw/Zagt1b3Uklw1zIQH3xF2Cxkc7tigc4PYUrjwh4dj+Dv/CZL4flGovYIv8AZn2h9sWZCn2/G/fsOOFPy5PQrTlk7i2m9lfd7E0uJMDUjGSVTWagve+00mvt7a/LrbS/m/2zQf8AoSdF/wC/97/8kUxtK0nxDKllpelppeqysI7ZIJne3nYniNhIWZHYnAfftyFBVQWcUaK894eNtN/Vn1H1dLWEmn6t/g3qc3W/omiW09j/AGtqxm+w+Y0EcVu4SSeRQpYBirBFUOpJIOdwAH3mQ8c/8lQ8Sf8AYVuv/RzVtSf8ij4a/wCvCT/0ruK5XN8ikupniMRKVGm46c9vlo3+lr/dZh5mgf8AQnaR/wB/7v8A+P0eZoH/AEJ2kf8Af+7/APj9VK9h+FXwo0Xxh4Xn1zW7u62mZoIobZwu3AGWYkHnnge3fNYc8u55GOxNHA0vbVpyt/il/meU+ZoH/QnaR/3/ALv/AOP0eZoH/QnaR/3/ALv/AOP11d94ItNN+OEfgm51Em0a7ii+0cBtjhWA9A2GA+tXtU8P6JceFvEl9FobaLNo2oRWsP72RvtSu7KUYOT86gBsrgYPSjnl3IeMo+5aUmpJNPmltJ2X2r7/AHdThvM0D/oTtI/7/wB3/wDH6PM0D/oTtI/7/wB3/wDH69h8TfDzwlanxRf6RZEW2nWvleQ07k2tyGQ7uWyysj5GcjIb0FYw8IeHf+GlLnwr/Z3/ABKEEhW286TjFqXHzbt33uev6Uc8u5zUs1w9WDnFz0i5fE9kk39rf3l/meb+ZoH/AEJ2kf8Af+7/APj9HmaB/wBCdpH/AH/u/wD4/Xq/hXwF4X13wz4QdrQ/2ndPJcXaGZwLu3ScxuB83ysoKH5cZAasm10LwzafDu81i7s9IFymuTWKSapJeFPKWMMEUW5zuznlvfnpRzy7lLM6Lk4LnbTt8Uu7X83k/wCrnn3maB/0J2kf9/7v/wCP0eZoH/QnaR/3/u//AI/VSijnl3PW9l/el/4FL/MtlvD0imN/CWnxq3BeC4uVkUeqlpWUN6Eqwz1B6Vz2u6MmnCC+sneTT7pnWEyEeZG67S8b4xkrvT5gMMGB4O5V1ql1H/kml/8A9hO0/wDRVzV05u9mXTlKjKLTbTaTTbe7t1btbf8AA4yiiiuk9o7T43f8l313/t3/APSeOij43f8AJd9d/wC3f/0njorkwv8ABh6L8jz8m/3DD/4I/wDpKD4I/wDJd9C/7eP/AEnkri67T4I/8l30L/t4/wDSeSuLqqf8aXovzkKn/v8AV/wQ/wDSqgUUUV0nohRRXbfD34e3XjO/lvLyf+z9Assve6g5CgADcUQnjdjkk8KOT2DRUqRpxcpPQ58ViqWFpOtWdor+vvOc0Hw9rXifWF0vQbCS8uihk2KQoVR1ZmYgKOgySOSB1Ir1uHwZ8M/htsuPHGq/2/rSbW/sq0G5I2/dtgpkZxknMhVXUn5CazNa+JVjoXh2Hwl8MEn07To94uNRkUCe7Y5UuD1XIw27hh8oAQLg+YVzqnVr6yfLHt1fq+nojyXRxeY61JOlS/lXxv8AxP7Pote7PSde+NPie/hWx8Px2/h7TUi8mO3tFVnVNoXG8gbcYO3YFxnvgGuIhGp+JfEkSXN5NdXt06o1xdSF26YyzMc4Cj8AKza9F0jwnqxvNM0Dwzpzal4j1E+SIrc738xifk7BQgUlieBgknAreFGnQj+7Vj1svy3C4VpUoKK623fq9382c341eybxxeNYANagqkZHGVVQo/RRXrfw20eK6sIv+Eu/Z3TUvD0ow2rWz3dncqpH342km2S/QAZ7GvX/AAf8C/DHw0S31nxBv8TeL5U3xWtpjyLfb1MbMM4X+KdsD+6PXopdQ1zxVqUujnT/ALNfMiO0Ud1I22N87fNL9mCkjODgA4wRVR2SPUrv21WVVKybvY+V/GHwgvP+Fi31p8Pre41LQWKy2k9zIiMquMhCWIyR646Yzg1jaj8GPiXplobqfwpdyQgZLW7LNj8FJP6V9f8AhzwvdaC7Xep6LOLLcVlvLKXfJbEHB82MgkqMD7vQc4Ir0WbQtTitRcacqavasobyAUSZlPIMTjCPx0DYz/equexk6aPzGH23TdRVh59pd27hlPMckTg5BHQgg16j4A+InxEXUra3lujqWlIwWaTUlJWNS4JJmA3bsZC5LdcBTgY6T4seJdE1/wCJly39lRJZaS7wA3Ft5FxO6/eMgYbkwQRtI4HOATx5pL4llvwyTXpsLJTwEBeRv9xc4HA6n86xrQhWjyyimZvKsHjGo42KlH5fn09Ttrzw94E8e67PpX9txeHtRgKw6fBHEiQshYZGzAVmLM2FVgcknBAryvxX4M8QeC9UWy16y8rzNxgnRg8c6qcEqw/A4OGAIyBkVUvbn7ZfSThAiscKgOdqjgD8q73wj8Tms9Hk8LeNbZ9b8NSQeQINqmWADJXYSQSM4Ay2VwpUjbg5eyq0VzQfMu3X5P8ARnm5nLFU8TPE4X36TfwbNJKy5H5JL3X8mmeXUV6F48+HEOhaRbeKvCl9Jq/hi6VSt0cNJAx4xJgDgtxnAwflYA43ee1vSqxqx5om2ExdLF0/a0ndbeafVNdGuwUUUVodIVq+HNUh0fxLb3tyjvbEPBcCMAv5MqNFIUyQN+x2254zjORxWVRSaurMipBVIuEtnodfe6bc2UcU7gS2lxk215GCYbhRjJRiBnGRkHBU8MAQQCHVdTt7SK1g1K7ighnF1HEkzKqSgYEigHAfAHzDmuf0zXNb0Xzf7H1i/wBP83HmfZLh4t+M43bSM4ycZ9TWh/wnPjb/AKHDX/8AwYTf/FVoq9SOy/G36HJOlVfuyjGS83b8LP8AP/I2U8S+Io3Z49f1RGaZ7gst1ICZXXaz9fvFSQT1IOKZb6/r1pFaRWut6jBHZsz2yRXLqIGbO4oAflJyckdcmsn/AITnxt/0OGv/APgwm/8AiqP+E58bf9Dhr/8A4MJv/iqr61W7fi/8jH6o7W9lD7/X+75v72XUvr2PT5bCO8uFtZmDywLIQkjDoWXOCRk4JqvUX/Cc+Nv+hw1//wAGE3/xVH/Cc+Nv+hw1/wD8GE3/AMVUuvUf2V9//AN1CtG9oR183/8AIl/T9T1LSbv7VpeoXVjPjHm20rRNj0ypBp7azq7T3czaremS8XZdOZ2JnX0c5+YcDg56Vm/8Jz42/wChw1//AMGE3/xVH/Cc+Nv+hw1//wAGE3/xVNYmqla34v8AyM5UJylzunG/e/8A9qbUPifxJbaONJt/EOqw2AUqLSO7kWLBJJGwHGCSc8dzRB4n8S22jnSLbxDqsOnlGjNpHdyLFtbO5dgOMHJyMc5NYv8AwnPjb/ocNf8A/BhN/wDFUf8ACc+Nv+hw1/8A8GE3/wAVT+t1v6b/AMjN4K970Yau/wA+/wAO/mao13XBJ5g1nUA/2b7Fu+0PnyOnldfuf7PT2oOva4bp7k6zqBmeD7K8puH3NDjHlk5yUxxt6Vlf8Jz42/6HDX//AAYTf/FUf8Jz42/6HDX/APwYTf8AxVH1qr2/F/5FfVZf8+off/8AaktaFhYI0Q1XVVng0aKQLcXKjG7GCYoyRhpSDwvvuOFDMMr/AITnxt/0OGv/APgwm/8AiqzNR1XVNYuludW1K8v51QRrLdTNKwXJO0FiTjJJx7ms3Vm1a1vn/wAA35K8/ddku6bb+Wi+/wDBhquoz6xr19q1ykaT3lxJcyLGCFDOxYgAknGT6muo0WVtd0Cy0u1RpdTsA8SW0aktPAXMgKDks6s8m4D+HYQCFcji6KzcE1ylVsKqkIwjpy7eWlvyZ11dD4b8c+KfCMU8Wgaq9tFOdzxlFkUtjG4BgQD7j0rjP+E18Zf9Dbrv/gfL/wDFUf8ACa+Mv+ht13/wPl/+KrL2L7nn1cDVrR5KkItdm2//AG02r2+vNR1KbUL65knupnMkkznLMx71Nfa1rOpxRR6lq19eJF/q1uJ3kCfQEnFc/wD8Jr4y/wCht13/AMD5f/iqP+E18Zf9Dbrv/gfL/wDFUexfcr6nW09yOm2r0/8AJTon13W5Gu2k1jUGa9wLotcOTcY6eZz82O2c1al8YeLpihm8U61IY2LIXvpTtJUqSMtwcMw+hI71yf8AwmvjL/obdd/8D5f/AIqj/hNfGX/Q267/AOB8v/xVHsX3IeAqPenH7/8A7U6CDWtYtXtGttWvoWswwtjHO6mANndswflzk5x1zU9l4m8SabC8WneIdVs45HMrpb3ckYZz1YgEZJwOfauY/wCE18Zf9Dbrv/gfL/8AFUf8Jr4y/wCht13/AMD5f/iqPYvuOWBqy3hH7/8A7U0iSTknJorN/wCE18Zf9Dbrv/gfL/8AFUf8Jr4y/wCht13/AMD5f/iqPYvuafV8R2j97/8AkTViilnnSCCN5ZZGCJGilmYk4AAHUmovEd0lhoQ8PZBvHuVubxOvkFFZY489n/eSlxzj5BwwdRmT+LvFdzbSW1z4n1maGVSkkcl7KyupGCCC2CCO1Y1XClyu7NKWEm5KVW1lrZa6+bstu1t7a9AooorU9I7T43f8l313/t3/APSeOij43f8AJd9d/wC3f/0njorkwv8ABh6L8jz8m/3DD/4I/wDpKD4I/wDJd9C/7eP/AEnkri67T4I/8l30L/t4/wDSeSuLqqf8aXovzkKn/v8AV/wQ/wDSqgUUVp+HtB1DxP4mtNB0tYzdXTlU8xtqqACzMT6BQTxk8cAniuiUlFNvY7qlSNOLnN2S1b8jo/h78Pbrxnfy3l5P/Z+gWWXvdQchQABuKITxuxySeFHJ7Btfx94+tdUsIvCHhCD+z/C1lhI40BU3RBzvbPO3PIB5J+ZvmwFvfEnWtI0LSl+GHhK38nTrGUSX10Jdz3c4HIYqcNg43Z6MoAChBnzCuahTdaSrVNvsr9fX8jxMHRlj6ix2IXurWEX0X8z/ALz6fyrzCiiprW0ur68jtLK3luLiVgkcMSF3cnoAByTXce8RxkCVScYyOtfpV+zj8Fz4S+Gs/jrV4hP4j8Su8iSFcfZLF2Loig8qZRtdu+Cqn7pz8x/Br9nqdPFNh4i+LdoNL0yJ/Ot9AuiFu9RK4b95F96KAdXZgCw+VR82R9x+MPG8+m/DW8ktJgLm5aPT7XAxtmnkWEMPcb2b/gNYVXfY3owlKSiuo+10HTZbptsYnlvE86aUjO+NXCqP9zJ4HTgnua8u+CG3xHrnxB1u6XdeSa+SWbkiPytqD6AAivQ/C3jTSW+L3ivTrYxvb6ZbabpkEZPCAecT+O7aPwFec+BvEtt4C/al1zwRe2cEFlq8ZksZWXC3By0sRb1O1pEyP4kxWMm00enhIRnRrRXxJJr0TV/w1+R66lhFFq0Vrs2yXCs64/iKAZ/HBB+gqpposNJ8cDwm7CCK6G63R1x5UhBcxgf3HUO6Y7pIvYCuV+JvxGn0rV9Dv9Gt/On0/Wne4giUszwfYyZdoHX5WBA/2a4340eNk1f4cw+NvDN8F8Q6BPHchVfJaNWWTb7rwkin0LerCqv0OajQdRq+iel/P+vzMT9sj4N2WreFZPiR4UhxqenBV1pI1x9rt1+X7R7tHxuPdOv3BXitp8Gb6+/Z2jkl0tVnugbu1uuA4uAPkU99jqBH6biD2r7TuPFMGveAYtZ022iuoL+yW6W1flZo5EDNEfqrFfrXmuhajo0fg06Np9wbqxYt9hYnmROvkt/dmTGCpxuxuGcnGlN2dzncejPzkYFWIIII7Gkr1L40/D+fw14yufEGlxNN4f1KZpobhASsEjHLQv8A3SDnAOMj3Bx5bW5ztWOz8A+Prnwfey2d5B/aGg3uUvdPcBgwI2l1B43Y4IPDDg9is/xD+HltpFlF4v8ACE39oeFb3DpIhLG0JONj55254BPIPyt82C3C133w18Wafplxc+FPEtrHeeHtZZIrhZpNq275wJeSAo6bm4I2qwOUAPFXpOEvbUt+q7r/ADXT7jw8dhp4ao8dhV7324/zr/5JLZ9djzWium8feELnwT42udGm+a3bM9pIXDmSAsQhbAGG+Ug8DkHHGCeZreE1OKlHZnq0K8K9ONWm7xaugoooqjYKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA7T43f8l313/t3/wDSeOij43f8l313/t3/APSeOiuTC/wYei/I8/Jv9ww/+CP/AKSg+CP/ACXfQv8At4/9J5K4uu0+CP8AyXfQv+3j/wBJ5K4uqp/xpei/OQqf+/1f8EP/AEqoFe3eDIf+FbfA3UPHFxF5etazi207enzRoc7GG5DjOGlwcq6pH3NeUeF/D9z4p8Y6foFo2yS7lCGTAPloBud8EjO1QzYzzjA5rvvjTr0d/wCO08P2K28em6JELWCO3KlFcqpfG0DbjCptyceX2yRUYhe1qRodN36L/NnFmi+t16WXr4X70/8ACnov+3paeiZ5tRRRXoHvBSgkMCOvakooA+l/g6tr4T8OaNLcxm48QeKTLqDGTkwaZaB2XJPI8yaInHfYh7V7T8S/Eo0nwj4bbzWMdrr1sZh1OYkkc/jlc183eA9ZbWviDqesRM7Wek+FY9PgJHEYWGKLb+J80/Uk16Z8R9atNQ0TVEkkzDp+u2+pNsBYtAzhJMAcn7x6dmHrXPUdlc9PAU+eXp/nb9TsJ9K8beDPBOm+P57O1jh1gPJdhJHeZJDL9ohZ/l2g/KUABPXBOTR49vtK+IXhe11PzntdS0+RLiyv7c4liR2U5B7gZBx6rmuAv7/4u+MtO0S7n8e6lDfa9bNqGneExbJJYrpweT5TIwAZoxEPv/MS6hSCua9T8HfCjXPEvwW0TxVpN1b3RvrQmbTZMwOOWRgjHhWDBhg8Hg5BJFccK6guWo1f/M7pUJ6YiOmtl8tP0t8mc74FntNY+IWpeJvi3eWUmjaUr3FzK8hjtXcokCMVyApbY5IJ5xgdcVxnjHUfhheeIpD8FfGdnqDXzG2/sALMJCGzmJFdcSR/eK4OUyeoPHs/jf4axJ8AbTX38DQXGq6BcxS3WiayrNa3rZjga4k2OCyLEARz8uZPc15XZfAGK61q/sxas9rJoTzwNdqkF3DqGyPyDGwYlUE+QpHQM4ORislVvPmb/wAtO520MLN0nXpW5Y6O/X+rr+kdt8OtfuNN+A3gm3nZ1uIp4bIo/DAC4eIgg+in9KxrXTtF/wCFheJ7GbTLK6gndb+FnypAlGedpG5N4YHOcEg1zel6jOfG/hbwcNUuNSbT5m1DUL6eQu0xR2kZyT2OU/FvWuK1rxfd6Z8T7PULWYEwT3GnSo33XiZlkUH2Al/SvQpSurnFi8JacYx+J3f+X4fmdl41XVbnQ7jWfA1ylvLGrQ3mhzQrNDPt5KNEwI3cHB/iwO5FfK2oXp1DUZLtra2ty5z5dtEIox9FHAr6Du/Es1l400vWLdzFBqV19klTPBfh0P4Nx9D7V4j44trSz+Jev2tht+zR6hOsYXoq7zwPp0/Cuq2h4lVWZgUUUUjE9jsof+Fnfs8y6YsXm6/4ZwbfamXkiCnag2pn5kVkCjktEhY814hXefDHxK/hf4l6feNJGlrcsLO6MjqiiJyAWLEHAUhX7fdxkAmqvxS8MP4V+J+o2axxpa3Lm8tBGiooikYkKFBO0KwZO33c4AIrz6S9jWlS6PVfqv1PBwK+p42phPsT9+P/ALcvv1S7M42tDQraG88U6bZ3Kb4ZrqKORckblLgEZHPQ1n1peHZYoPGGlTTSJHGl5Czu5wqgOCSSegrsPePu34kfsefDbS/jVF4ieOLwX8JdG0aK81id76WV7q586YGJGld3XKCIHHqoUFm4+XNW8N6N8Z/j2vhX9n74dNpGnvuS1t5LyaWSSNeWubh5pHEYx2BAHA+Zjz9mfF79pb4WS/GmH4ZeKrvQPF/ww8QaJCt7faZcR3Y0+7M8wLl4ieirESAdyYV19D5L8Jb34afsxftf3M5+Ifh/xH4K17TZbKy1vTb+G8ksSZY5FW6SEsU/1e0tja2Q3GGC5RbtqW0jx7xl+y58QvCPgfVPFdrrPhLxTYaO+zVl8N6n9sl00jr5yFVK47gZIGSeATXs/iP9lPwJ/wAMheDtY0zxh8OtH8VXN6Pt3ivUPEcyabfRkTnyYXbMZkGI8hUU/un54Oeg8T/EaPwX8PPGsOi+Lf2ZbTTdX064g+z+ENOna/1MGORY45I4pQqOd7DLlghYnkZzydu/g74u/wDBO7wR8N7H4oeCPDPiLQNVe6u7XxPqYsQVDXQAXIJbInRgQCOoJBFF2KyPIPB37ON/420LTr7S/i98Jre81AlYdHvfEJjvt+4qEMIiPzEjIGeQR61j2HwD8d3P7RkfwU1I6ZoniWVmEbajOwtnxEZVKyRo5IZV+XjrwcHIr6c8G6t8APDvwQ8A6x4Rb4NC/iSFvEzeM7VrzVlmwm820WQ2/wAzzMElYwNpBABNcN+0z8TvD1l+3l4W+Ing/wAQaZrdlpUGn3ElzpV1HcxuY53MkZeMkZKcEZzhqak27BZHl+k/szfEfWNM+I19bvpMaeAZZ4NSSWWUNcvCrs4tsRnf8seRu2ZDL68VJf2fvE9l8P8AwN4x1nxN4T0bTvGVz9nsTqV7JAbdfmPnXBMWxIsKDuDMfnXjk4+1fHPxi+E/hP40+EtM8MeNPDupaF4w1+6v/FEtnqUMsEKvYJZL5zqxCISwkO4jlGNeX/FTxf8AA/VP2o/hH8PdZ1/TNZ+GPhXRxay3VrdrPa+c0ZRBI8RIKgw227B7nPGaFJsLI8W1P9lXxrF4K1bxN4V8a/D3xzbaTCbi+g8Ka39tmhjAJLFSijorHGcnBwDXhVfpx4N8e/B/wt4y8a6TD4g+BGi6XcafJ/ZUvhfy7a4mgyQqXdyzLG8hyP3SbjkEnHGfzHpxbe4mj6Z+I3wo8AaD/wAE8fh98TdJ0D7P4q1bU47e91D7VM/nIUuiR5bOY15ij5VQfl9znx/4XfCTxr8X/FM2h+DbGGRraLz7u8upRDb2kecbpHPTJ6AAk4OBwcfU1/aeE/il/wAE7Ph18O7D4s/DnQNd068W+ubfxDr0VqY1UXSFSo3OG/fIQCo4zz0zV/Z513wV8BPE/jL4aeMviB8PdXXxXpMM9pren3J1TSEkX7RH9muyAnUPuKHA2nBYFhSUmkx2PBPiH+zx43+HvgWLxs2qeGvFHhp5/sz6x4Y1D7bbwS5wEkO1SDnjOCM4BOSAeuf9jX4lwXXh+O98UeBbGHXrZJ7K5vdVeBHdwpS3AeIM8xDfdjVunJGRn0j4tfEOfRP2bfE3gmHxP+zyllqrxFNF+HVlcPJcv5sRMhZZBHEyrGrbmVs7AvXFd5+0D4L8PeNp/gpBrHxM0LwbJp+lJdMdcmNvHLBi3LtDJjb5q7B8jFd2Rg/KaOZhZHx9cfBDxRpHxxn+Fvi/WfDXhDU4UaU6hr+ofZrBk27lZZgpyHH3eOvBwQQNvxl+zR418KfDS78f6b4k8GeMvD1lII7y98Kar9uW1JIGXyi8ZZc4zjIJwOa+ite+JX7O3xU/4KCf2j43u9LvfC2meHl0yxvtQO2xub1JmkLOTgFAssigv8pK55yprdvvH3w7tP2Xvi34Ul8QfBXTtWlsJVtbLwKFtIbvdE3lgF2BuZhjkxrhcgZJJAOZhZHzHo37LPjnUvAOi+K9W8V+BPC8OuQC50uz8Q60LS5vYyAVaNdpByGU43A4YZxmvIPEOg6j4X8V6j4c1eONL/T7h7WdYpFkUOhwcMpIYcdRX2x8JfFel6v8OfBujfEH4jfAnxR4P0+zhjnsvF0Bh1jTI9i77eAONrFMBA/8QQHPSvkv4vHwIfjh4lPwz/5FT7Wf7Pxu27do3bd3Ozfu25/hxTi23ZiaOJoooqxBRRRQAUUUUAFFFFABRRRQAUUUUAdp8bv+S767/wBu/wD6Tx0UfG7/AJLvrv8A27/+k8dFcmF/gw9F+R5+Tf7hh/8ABH/0lB8Ef+S76F/28f8ApPJXF12nwR/5LvoX/bx/6TyVxdVT/jS9F+chU/8Af6v+CH/pVQ9Z+BVvDZ614g8YXkMc1roums7KFDSqzZbdHnjOyKRc5H3sdCa85vr251HU7nUL2Tzbm5laaV8BdzsSWOBwOSelemeE/wDRf2UPFt7bfubmTUEgknj+V3jzANhYclcSOMdPnb1NeWUYZc1WpPzt9y/4Jy5alVxeJrvpJQXpFJ/i5BRRRXae2FFFFAHunwnitrL4NXl8WVZ9W8SWujF+6L5LyKPoxLD8K0PEWn6naaCviAsZLSa3KNF0LxnMZX2IVVwe+0dCAa8S07xBq9loVxodlM4t7q5gu9i53LPFuEbrjowEjj8fYV7/AOEvFtr4z0yLw34gkggv9QgmtFjUBVS8SRpEQDPHmxzygD+/Ft7gVlNK1md+ExHspxkun5dT3j4aSWnxC+E3hO7u9BuILjTo2AuZrJfLuiXIlKMSVZHdS5XgpJu4wefZrrxH4Q+Hnh3SrPXtci0uGXdHaxTKzyXDA7mChVJJG7JAHTHYV8VfCP8AaEufglrWoeCfFelnU9DjujMIlcRz2RfG54i3DISMlDjB5BGTn6TvvjZ+z78S9ItNP1HxpZaTdwyJe2qaxEbWWB9pww3jYwKsQQGIIP0NeFWpTUn1R9HVxEXy0Zu0E+mu76HoNh8R/DHivXIfD2i/brlruCYieW0aKEhFBKnfgncpPbBwwrkfGfhLxNaeHbxPCdtp1tdXCNE9/NiJbKLBzIAq5YgE7RwAeSexoRfEj4N+CtXjvf8AhYFpr+qvGYrTT9HP2yVi2M7I4t3zEADLEADPqa8Z/aJ+P/jqYWHhTRrIeH9N1aBpJZRKJLsxhsMrsPlj45O0nr96sadOUmlsbwapTawzvB21aPOfCcy6D4U1W+acTalq9z/Z9nNjDGIHAx6DkE++K811a++2+PLg5Bie9doyD98Lhc/kgqeHU76e6ilSXy47aBktRtOIiwIV8cDAyzDnLHb2rmYbWNGu5JbqaSa1haSK4GF2lSAB3yCTjHvXu09lE4cRWhTxE6t7/P8Arp8rm1418WrNr2nW+kODFpMhmEnVZLgsGZh6hdqqPXaT3rh5ZZJ53mmdnkdizMxyWJOSTWlo2qTWevi4EcMqTEpNDIgaORG6qQc8d/UY4qXV9MtlhGoaUC1r92VA27yXz0552njBPfg9q6uZuVmfMzSceZPW+36mLRRRTMgr1b4qyv4n+E3g3xyVjMxVrG7ldFSWWXHX5RjZuimIGRjeMAZOPKa9V03/AEv9kHxB9q/f/Y9UT7N5vzeRloM7M/d/1knT++3qa4sYrSpz6p2+/Q8TN17OrhsQt4zS+U/df6P5Hj1FFSW9vPd3cVrawSTzzOI44olLM7E4CqBySScACuk9sjoq6NI1YveoNLvS1hk3YEDZtsNtPmcfJg8c454qlQAUUVZutPu7O1sri5i2RXsJuLdtwO9BI8ZPB4+eNxg4PGehFAFaiuhbwJ40iurO3ufCur2jXtxHaW7Xdq9ukkrnCIHcBQSfU1z1FgCiiigAooqVra4WzS7aCUW8jtGkxU7GZQpZQehIDqSO24eooAiooq2NK1Qu6DTbvdHALpx5LZWEgMJDxwhDKd3TBHrQBUr0f4q/GrxT8X7Xw3b+JbDR7VfD9l9htDp0UiF0wozJvkfLfIOmB14rmX8B+OYnhSTwZ4hRpm2RBtOmBkbaWwvy8narHA7AntUN54O8Xac9umoeFdbtGuZRBAJ7GWMzSHoiZX5mPoOaOULmJRVltO1BEZ3sblVWb7OSYmAEv/PM8fe/2etOm0vU7d7pLjTruJrSQRXKyQspgckgK+R8pyCMH0NAFSip7yyvNOv5bLULSe0uYjtkgnjMbofQqeRUFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAHafG7/AJLvrv8A27/+k8dFHxu/5Lvrv/bv/wCk8dFcmF/gw9F+R5+Tf7hh/wDBH/0lB8Ef+S76F/28f+k8lcXXafBH/ku+hf8Abx/6TyVxdVT/AI0vRfnIVP8A3+r/AIIf+lVD2HWv+TQfCv8A2FJP/Q7mvKq9V1r/AJNB8K/9hST/ANDua8qp4L4Z/wCKX5nNknwVv+vlT/0phRRRXYe0FFFaGiWL6jrlvaRxiR3cBUP8R7D6E4/DNJtJXZUIOclGKu2dF4W0C8u9QtLCw8tNTvpI4lnlcIlqsjBVyx4Vm3Dk/dU56nju/id8N9D8AeFdK0eWzv5vF3lm6vL+21NJLJEWVgFhREy5K7TvL5zu4BGB1nwtuPCWj/FDSNKn8Q6VHfI8rM9zZi+WWcxOApjOFLFjhcnghe+K+gpvD/hLTtBn1X4waTaWem2qvqcCy2otY1dcAMiqxI3HkRk/xY24wK8etipOSdtD69ZXRw0XSk1J21s769vkfBXjWw8e6v49tPD3jnR2j8QW0Eck1zcgQzvbModWuCM87GB3EB/mAOSavyraas9zC0cVpPbgpAr/ACkJwqIw/iGAoyOeM+orf8XeJn1fUdU8WSXb3mo6tIbq8mY8MzH5EXuFQBRg/wAQb2xm6hYm7tre3lJV5GLO6nBURqOR/wACkH5V03dtd2eTRppSdtbJ3810/G2v+R7ZbWPhP4O/B3Qtf0c2dzq/iCwS4SSR/MkyBtldwcbFV8psBAJXHZjXi+savda94tcStNq2oueiZmz9FUDcR74UYwABUS6Nc3tzaR3N9cSwRSJGqM5YIC+cAdgSWOPUn1Nel/A660G11u4tbqw1K8v/ABC+EbTLhbRoYy0m52nZGACjLEblHy87ulZQgoNylqzsq4irOjGFP3U3Zef9afPfpbzGSXV7t2tI9ORAG2NJduDluh+VeODxWRYo9vql5Z6raxxKySRzoo+VRtJDj6EAj/69ek+K/DL+DPEx0WTWNJ1hZYUntbrS5/OikiORktgfMCpDcdcYzkVx/irT5JI3upbhGcgKyKCMFcZDEDuOcZP3RW1OouZNbGEsLz4eUrPnTXpbtr+HzOIs1b7QGUZbov8AvHgfl1/CtywS4iEj28YkdF2zRsMiZOVIb8s57Gtjw54eXzPtUgD4+VBj5c98D+ta3h/SmHi7VLMLxGA2PQNgj+Zoq4hXduh34DIJWp+1Xxtr8G/0PONRtUtrrMBZoJBviZuuPQ+4OQfpVOvQfG/hd9Ni+0Rp+4mYumP4JAPmH0ZRn6rXn1dVGqqkVJHz2ZYCpgMRKhUWq/IK9W+FX/JL/iT/ANgr/wBo3FeU16t8Kv8Akl/xJ/7BX/tG4rDH/wAB+q/NHy/EP+4y9Yf+lxPHa3vBFxBafE7w5dXU8cEEOqW0kksrBVRRKpLMTwAAMkmsGiug9o9TtPGOiX2kavbSmS2uL6wZtUlkZVF1LGY44xFzlmK+Y5zyWduMDNTaj/wh/wDa1t/a3/CNf2f/AG5F9h/svZn+z8Pv+0eV8+P9R/rP3n368moquYnlPUT/AGJ/amk/2x/win9tbL7/AI8/I+w/6pfsnneV+6z5nmde2zfxmsH4g3Ec/wDwjcQn0mS4g0kx3K6U0Zhjl+13DFQI/lBwwJC8fNkcEVxlFFx2PaNZn09fjrpuvLa+EbbT/wDhJoLg6tZa0s00sfn53yR/aXCLj5ifLXGB0HB5uzOhjxhpMul2WjXWj/ZpBDDd3FrBNG+zDNcG4OxpFYhgGyjAYUDkDzuijmFynrcNlbLB4pudMuPCd/dpf6akN3f2tnDboHguGkjQf6gEbQDtO1thYZbbVbWtQ8DJ4u8OabaW2kf8I68ryX81vAplK/b7jarSYMiqIxHgcMUK5z8teZLc3C2clos8q28jrI8IYhGZQwViOhIDuAe24+pqKjmDlPW72fRW8XaQU8L+Hl2pcgyrrelSRyAoAjMqxxwqUJ3KJVy+SDnHHO+O49Gi0q2Wwv8AS728OpXLTS2VvbwERm2tCqlYPk2q/nKCvylg5HU1w1FDkCRauPP/ALOs/M+y+Vtfy/K8vzMbjnzNvzZz03846cV6N4q1TS9a8HWmkaTqdpZ3dppdjLdp5yhNS2WsQ2l88SREMPKJwecDfkN5fRSTHY9I+Ki2914h1TU7LTfCwt5tQeSPUNN1cXNzcKS2C8QuX2g9SRGuCAOOhn+3+H4vHuoeIbzWhFFaaLZwW0lkEuJTcPZxQ5RC6BjH+8JO4bWUZ54rzCinzC5T2S21Xwtc63qGpf21bvazxW3iNFvNkMkl7bMySwtGHba8paRwuTkMvJptrq3hyWz0bWNT1i2Y3Uq6vqkKukk3mWcAiiRoyy7nllaRtpIyGJzjkeO0Ucwcp2Pjm60jWLbStd07WLjULlojZ3rXkSQXDvFjZI0ayP8AKY2RQ245MbdOlcdRRSbuUgooopAFFFFABRRRQAUUUUAFFFFABRRRQB2nxu/5Lvrv/bv/AOk8dFHxu/5Lvrv/AG7/APpPHRXJhf4MPRfkefk3+4Yf/BH/ANJQfBH/AJLvoX/bx/6TyVxddp8Ef+S76F/28f8ApPJXF1VP+NL0X5yFT/3+r/gh/wClVD1/Qv8AS/2Qtf8AtX7/AOx6ov2bzfm8jLQZ2Z+7/rJOn99vU15ZXqPwLP8AabeLPCH+q/tXSz/pX3vK25j+5xu/1+eo+7jvx5lPBNbXUltcwyQzRMUkikUqyMDggg8gg9qMK+WpUh53+9f8A5csap4rFYd78yl8pRX6pkdFFFdp7YVbsr+fT/Ne1bZM6GMSDqgPBx6EjIz7mqlFJpNWZUJuD5o7nXeH7eyj8G3l8kKT6pLP9nhDH/UoEDMQPV87QfRW9c1v6/8AFv4h+LPC0XhnV9fv7+yRFjMMqj51B6O2MkAgHk9uc16X8I/2WvGfjX4fprWp6xZeG7LUDHd2XmwPPcSoAwVygKhEOcgk5I5xggmbxF+y18UNN8aWHhjT7zQ9UXUQ7i+hkaAQxJjdJMjAsqjIGV3ZJCjk1wVKlJzs3dr8D04e19muVWVunU+dUuGQxWztuVDGfr83P8hXa2lwsviBVebHlxNtABz8zfNjj0Ar2zVP2HvGkWnfatH8aaDqV8oDNayW8tsrY/hSQlh+LAD6V4t4q8M+MPB+vW2j+JNFutD1Oyi2IlwdpnG4nzI2+664IXKEjCilzwq/CzTDVJ4aV5R3t+af6Fi6mexVGRlV4dsoD7c7sZ49RkDjkV718NvGXw18ZxXdz400vRvD3jeS0xp99p/+j290xQBjHb58pZ+xIGSG4xjj5zt9RieVXvB5YVWUxLgcEH7uSOM471h6sWbT7HDo8kJJUhuAcZOMdOec9sVM6HOtzplj6aleMXZO6/D/ACPp/wDaImvbLwV4csdcnnXXra4lmhtGS18mO0aEZVPJ+YIGWMDdjJJOK8kaeHUvD2l4ivV1LT4zJALW1B+0RiTervuZcFSxUn5sgg9jjgRquvapelb65uJ5ZgBJc3Tl5AoHUMSSeCRzxzW3qupvf32iWUjJGbViIplO3YCRyfcfqM0oQlSSW5rQdDFOTcnF6WXR30av002Ofl1vVPD/AIrka3eRbfeJUtJJN6eWw3Kp9OCBkV1E/jKz0W91TWtPWO4ub6O3S2jk6IBHuZmx6EgY7n6VxfiGX7W8N9MP9KmaTzTuLbgCADk8nncMnsBWJXXLDwqWk0clHOMVgXKlTnezunvZ2aur+T++zPSdP8fSeJbKfQfEkVuHnX/RbqNdgSUcqGHTBPGffn285mQx3DxlSpViMHqKYCQcinSSPLIZHYszHJJ7n1q6dGNNvl2ZyY3Mq2OjF4h80o6X6tdn6fqNr1Xw9/ov7J/i69tf3FzJfpA80fyu8e6AbCw5K4dxjp87epryqvVviTDN4c+AngrwpcwyGad3v5HkUxtCwBYxFDzkG5xnI+5054wxju4U+7X4anyecPnnh8Ot5TT+Ufef5fieO0UUV0nthRV6HT08pZLy4MIYZVETe5B6EjIAB+uehxg5qT7Fpv8Az/XX/gMv/wAcquViujNorS+xab/z/XX/AIDL/wDHKPsWm/8AP9df+Ay//HKOVhdGbRWl9i03/n+uv/AZf/jlH2LTf+f66/8AAZf/AI5RysLozaK0vsWm/wDP9df+Ay//AByj7Fpv/P8AXX/gMv8A8co5WF0ZtFaX2LTf+f66/wDAZf8A45R9i03/AJ/rr/wGX/45RysLozaK0vsWm/8AP9df+Ay//HKPsWm/8/11/wCAy/8AxyjlYXRm0VpfYtN/5/rr/wABl/8AjlH2LTf+f66/8Bl/+OUcrC6M2itL7Fpv/P8AXX/gMv8A8co+xab/AM/11/4DL/8AHKOVhdGbRWl9i03/AJ/rr/wGX/45R9i03/n+uv8AwGX/AOOUcrC6M2itL7Fpv/P9df8AgMv/AMco+xab/wA/11/4DL/8co5WF0ZtFaX2LTf+f66/8Bl/+OUfYtN/5/rr/wABl/8AjlHKwujNorS+xab/AM/11/4DL/8AHKPsWm/8/wBdf+Ay/wDxyjlYXRm0VpfYtN/5/rr/AMBl/wDjlH2LTf8An+uv/AZf/jlHKwujNorSNhYsMR6hKG7GaDav4lWY/oaoTQyQTNFKu116jr9CD3HfPek00CYyiiikM7T43f8AJd9d/wC3f/0njoo+N3/Jd9d/7d//AEnjorkwv8GHovyPPyb/AHDD/wCCP/pKD4I/8l30L/t4/wDSeSuLrtPgj/yXfQv+3j/0nkri6qn/ABpei/OQqf8Av9X/AAQ/9KqG/wCCfEX/AAifj/TPEBi82O2l/eoF3ExspR9oyPm2s2MnGcZ4rr/jL4bk0L4n3V3Hb+XZan/pcLLuILn/AFoJP8W/LEAnAdemcV5jXt+kD/hZv7PMuliPzdf8MY8jamWkhCnao2p/EisgUHJaJCx5qK79lVjW6bP57P5P8zjzJ/VMVSx32fgn6N+6/lLT5njlFFFege6Fe3/s0fBOT4tfEj7Xq8Eg8LaOyzag/K/aGPKWyn1bBLEdEDdyK8o8M+GNa8W+LtN8N6HZPcahqMwht48YDE9WJ7KACSegAJPSv1N+F/gfRPhd8MNO8IaOVkW2UyXN0F2m7uGx5kp+pAAHZVUdq48bifYwst2deEwzrS8kdfBZW1lED8sccS8IvyoigcDA4AAHA7AVy3h24k13WtZ8SJH8ktyNPtz6Q24wcfWWSUn6e1cz8cfitp3w5+Fuo6jLKr3skZitbcHmWVuEQD3P6Bj2rufAOiy+GPhboGhXspnvbWxjF3M3WS4Yb5nPuZHc14CT5Wz6CT5LX3/T+vyNmOaKws4nv54ozJIsSnoGdjhVHqSeKz/F3gzwt498Ly6B4r0a21Swk5Ecw+aNv78bj5kb/aUg1w/xe1xbR/DGnxXHlXE2qCZADgny4pGGPXkZ/Cur8NeKYdZ0xZSwS4QATR56H1HsaSvGzRU8NKVP2nc+GfjV+ztr3wmu317Qrf8At7wm74Fw0QNxZEnhJgOo7CQDBPBAOM+Nf2jZ6npc1mqLGzgPDgDiQdACPUEj8a/U3xrHaar8NPEFhdhWhm024Vt3T/VsQfwIB/CvzG8S6DZWfiLPmrbi8VJI3xgQyNn5XHZSwIPcHHrXpUMQ6itLcnDYBqLqwa0dmn1Uk18u3q0ctBeXsZ8pHb5eAvX9DWgJ7mdlMdnK1xtwWK4VffPQD3NU50Jmnt76LytQSQ7gehPp/gaSa2RLSylMkkkUoczRiQgFlfG09ccFT+NelC0lc8KrF05uD6O2v6lHVpIGvRDby+bHCoTzeznqzD2yTj2xVCulj0MX2oeeLVUtgoxBDIFPT+82evXuabceGblrySQWz21sQCgT98enQ4PetPaIyeHb1Uk9bf8AB16epzlFWJbKeGBZZVVdzbQhYbv++eoqv3q009jCUXH4kdL4B8NyeKviDpuk/Z/OtvNEt2DuCiBTl8svK5Hyg8fMyjIzVz4x+Iv+Ei+LN/si8uLTv+JdHlcM3ls24nk5+dnwePl28ZzXZ+Fh/wAK1+BmoeN54/L1rWMW2nb0+aNTnYw3IcZw8uDlXVI+5rw+uGD9tXlU6R0Xr1/yPn8I/rmPqYn7FP3I+b3k/wAl8mFXNLjSTVE8xQ6ory7WGQxRCwBHcEjn2qnV7SP+Qmf+uE3/AKKauyO57r2HszO7O7FmY5LE5JPrSUVa0zTrvWNbs9J0+IzXd5OlvBGOru7BVH4kitRFWivYvH/wrtNL8TeG4LXTb3wtpl7dvo095rMUsSvLC4BvP3uMJKjo4GQoIcAgDjOuvhhY2qSWr6jc2MT6nptoNQ1ywFmyJcLd7nQpcyRNF/o4+Yk5IwGQK28A8uor1aD4f+ENLm8V2/iK78TwxWWhw39rdTaPEkis19BCZI41vCkq4fYDvwd7ngxqGoa/8LLfw/4FfWLrxdpX9qR2sF2+lm6tN7LMEIRFW4MxkCyBiGhUYViGPGQLnnFFd742+H2meF4tc/svxNLq0uh6yNGv1ksPswEjecUaM+Y24f6PIGyFwcY3A5q7oPhDQdc+BTXEVqy+KpdRvWs5xK2J4ra3tpHttmdu4rNK6kDcTGF53CgLnmtFe0Xnwc07V/HXiew0q/k0ZLfWLuw0u3uPs/2eYRchBJNdLM7DIBCRSEZUknOBy2l/DvTL3RLd7zxPJa6tc6Nea5BYpYGSMwwRzOEaXzBh38huNpAU5yT8pBXOAor0LVvhiNP+GB8Vw6vJ9pghtp7vTLxLaKWNJtoVlSO5kl25dcGSKPIYH2rV+FHwzPjHw9qN9ceG9U1VbucaPYz2cUrJY3Dxs/2mUpwERvJUh/l2ysf4cgHc8oorqvFeh2mj+FPCM8dm1ve3thcS325my0qX1xCMgnCkLGi4GOnrk102p+A2bwPo1joXhmC71d7aO41K6W9b7RZSSbpEE6FvKSBoDGwbAwSQzggrQB5fRXe/C3RfDGs3/iFfFcG6zt9J3xz+a6fZJZLu3gE/ykbtgmZtpyDjkV0978LtKi0nwn4Vki+w+J7rXo9J1a/3NKInmVHVBHuCny1kTOMEtuBPTAK543RXoPgfwvay2Ntr975N1FeWniG3FpNAGWN7XSvOSUEk5O6dSOBtMYIOTxp+I/BXhKN9TTw1dXDy2vhjTdSli1C18lI5J/7PG+OUXJG5zdOzb12JllUH5XQGeV0V6v4R8JaDpnhfxPd+Lk8Hz3VldWEMFxqOoXV3Zosy3LMofS3Ys58pOpIG05wTyad4R8GXHhO91jXpZLKOTw4dVt30izkn8lv7aNpu2zXK7zsAQA7RsfJG9N0gK55RRXX3vgb7G2uAapvGl6HY61nyMeb9pNp+6+98u37Z97nPl9Bu4rePPDWleEPG2oeGtO1yfVptOuprS6mezFsgeNyvyfvGLdOcgYOQNw5IM5miiigAooooAKfcqJdE8xvvQTKin/ZcMSD7Arkf7zetMqSX/kX5/wDr4i/9BkpPYDLooorIo7T43f8AJd9d/wC3f/0njoo+N3/Jd9d/7d//AEnjorkwv8GHovyPPyb/AHDD/wCCP/pKD4I/8l30L/t4/wDSeSuLrtPgj/yXfQv+3j/0nkri6qn/ABpei/OQqf8Av9X/AAQ/9KqBXQ+CPE2peEvG9nrGlwPdSAmJ7RWYfaEbgodvU9CODhgpwcYrnq774UeM7jwZ4smurWwsrx7iMRPFcwq5ePOWRWP3SeOmc4weOK3nFSi4y2Z3VKEMRF0Zq6lo13ua3xU8GWml3ieLPDv2f+wNRkCpFEDGbaYrkxlG5GdrHGBtOVIXAzxeiafHd6gsl46Q2cQMkskobYQP4cqOpOB+Pava/GOmvN4Tv/Gnw+uJ28LXDb9Q0uFQr6TKMHY8fTyweVdfu8Z4ANeYWtpdapNstnvb1Qd5WLkjjk4HT3NZUpSpwUZO9upeX5fUo01RnPna0Wmtul+78+u+50w8RXWma5pVz4dvriwNgFmtpobg7Y9vVUwcDIyCD1BOQ2a+ufEH7SfgrS/hTF41S8ZUuAyR2jAGfzh1hCZ5YZGT90Agk4Iz8Kbn093tUtWAcjj1PI549ecD+lcf4iu4rrUI7aGUXDxZV51bKuxxwPYdM9/piueth41Em+h7n1+VKTlyq7+SXay9P67+4+DPE3iP9ob9r7wj/wAJOHTR4tQ+2JZ5zFHDD+9YZP32bywpPfIAAGBX6Qz6msUbyzPswCzk8Y7mvy6mSx0vw4lg9o0d3aymKMQktGqBiciRTzySemepz2r0i3/aA8f2HwtTwgkUN0ILZoU1qWWR5UXllkfqCVBAGT/CvpWFbDOdlHodFK0G5VXzNpNta28vX8D3Pxjrdr4q8S32u6hMINK09GitLhjjyipy84PbaVCg99r9Qai+HXxAg8SaDHrukT+VcwuYbmLGCjj1X+6www9jjqDXxcPF+rXXhqDQLvU7s2cGTHDLO7Q5znlPXJz6ewqz4M8b6t4L8SSappuoGNpkMcyMnmxyjsHTIzg4IIIIPsSKqWAlytdeh3U84w/upbPfyPuP4q/FO1sPhJqGnsRBqmpx/Y7dC2VbJG9uudoXOfqBnkV8ba/qtvrDXz36tLd4EYkeTIPzuzkN352gZ55OKy/EfirXPFN++pX97LfTMNomOAI1/uoi/cHt+PJrnzNP5PlPwoGOeOK2w2HlSjZnHmWKwz5VSV2nq76W7dvO5avbiS/gS9nz9pjxDM3GTgABj79PzNWLe0lu9LiEeECOzSF+pfAHyj0AA+pPsKzIby3t7a7U/O7oqoB03Z6n6DP44qH+2dT8nylvZUT0jO3Oeucda6lTklaJxVMXh6tRVa6cm1rbv3b9DqINI1EACK4ZR2whxVhU1q2LAJHKMfN8pUkflXCtcTv9+aRvqxNLHc3ETbop5EPqrkGj2U+5DxeCeiotf9vP/I73zba5cR3cHlT9VboR9CP8ag0TwvpF747sbfWdQjtbAyNPczXTkLKgO4pkY2k4IJJGASe2KzvD8eu61FeMsfn2tlCZprqUhRB/d+Y9SxGAvU89gSLd7cb40uiwKgqiDH3ju5PuMZH4ms3e7jez8jjxKpV6c6eHqNK1ul4t7eV9n6FD4leMV8XeLf8AQI44NG09TaadBDuVPKU8OEOApYAcADACqc7c1xtSXAjF1IIs7A5C59M8VHWtOmqcVCOyPOw2GhhqUaNNaR0Cr2kf8hM/9cJv/RTVRp8MskFxHPE22SNg6nGcEHIrROzN2Xau6Rq+oaFrMGraVcfZ7yAkxS7FYoSCMgMCM4JweoOCMEA1XjEF2u+CWGF/4oZZNm33Vm4I9s5+uMl/2OT/AJ72f/gXF/8AFVqSXdM8SatpFi9jZy272r3MV41vdWsVzG0sYdUYpKrA4EjgjGDnkHAxqXXxE8V3oSO5utPe2jlhlSy/sy1FqrQ+d5YEAj8sKDczkrtwxckgnBHPfY5P+e9n/wCBcX/xVH2OT/nvZ/8AgXF/8VQLQ6EfEXxWNZ/tL7VYbhaGw+y/2Za/ZPIMnmeX9m8vydvmfPjZ97nrzVa98aeINS8OJomoS2F1bpGkKTTadbPdJGhGxFuTH5yqAAAA+Nvy9OKx/scn/Pez/wDAuL/4qj7HJ/z3s/8AwLi/+KoDQv6j4o13Vjq51C+87+2L9dTvv3SL51wvm4fgDb/r5eFwPm6cDCWPibXdMttNgsNQeBNNvm1K02KuYrhhGC4OMniGPg5Hy9OTmj9jk/572f8A4Fxf/FUfY5P+e9n/AOBcX/xVAaHWQfFjx7bajc38WtQm6uLyW/ad7C3d0mlx5jRs0ZMYfADKm1SBgir2ifFB9E+G8/hyLTrm4vZLO50+O7uJ4WjggnDB0RRB5wGHc7fOKbju25rhfscn/Pez/wDAuL/4qj7HJ/z3s/8AwLi/+KoDQ3734g+LdQ8My6Bd6lC9jNDDBMFs4EknSIr5QklVA7ldigFmJAGM4JFY82s6ncaVp+myXR+y6eZGtY0UL5bOwZmyACSSBycnAA6AVB9jk/572f8A4Fxf/FUfY5P+e9n/AOBcX/xVAaGj4h8Va94ru4rnXr1bqWLzdjCGOLHmTPM/CKAcySu3/AvTArWtvif42s7CO0g1WDaluLMyPYW7yyW4XaIJJWjLyRbQB5bkrgAY4Fcx9jk/572f/gXF/wDFUfY5P+e9n/4Fxf8AxVAaEtjq1/p1rqFvZT+VFqFv9kul2KfMi8xJdvI4+eJDkYPGOhIqey8R63p1laWljfvbxWl6NRt/LVQ0dwAoEgbGcjavGccVT+xyf897P/wLi/8AiqPscn/Pez/8C4v/AIqgLo6K9+I3i+/Nv5+o26LbpdpDHbWNvBHGLuEQ3GEjjC/OgweODlhhiTVa58b+JLvRf7KnvLdrc2K6a7LZwLLJbq8TpG8oQO4U28O3cxKhcDAJBxvscn/Pez/8C4v/AIqj7HJ/z3s//AuL/wCKoDQlh1bULfQLvRYbjbY3k0VxPDsU73iDiM5xkYEsnAODu5zgY09N8beJNK+yra3lu0dtZNp0cFzZwXERt2na4MbxyIyyDzWL/MCQcY6DGP8AY5P+e9n/AOBcX/xVH2OT/nvZ/wDgXF/8VQGhuz+P/Flz4Wl8PTajE1hNaxWUqi0hEksMTo8aPKE3sEMabcsdoG0YBIONq2qX+ua/fa1qk/n319cSXVzNtVfMkdizNhQAMkk4AAqP7HJ/z3s//AuL/wCKo+xyf897P/wLi/8AiqA0K9FWPscn/Pez/wDAuL/4qj7HJ/z3s/8AwLi/+KoC5Xoqx9jk/wCe9n/4Fxf/ABVH2OT/AJ72f/gXF/8AFUBcr1JL/wAi/P8A9fEX/oMlSG12DdLd2aIOrCdXx+CEk/gKo3l0swSGEEQRkld33mJxlj6ZwOOgwOvJKk7Ie5VooorIo7T43f8AJd9d/wC3f/0njoo+N3/Jd9d/7d//AEnjorkwv8GHovyPPyb/AHDD/wCCP/pKD4I/8l30L/t4/wDSeSuLrtPgj/yXfQv+3j/0nkri6qn/ABpei/OQqf8Av9X/AAQ/9KqBSqzI4dGKspyCOoNJRXSeidz4c+Iuq6Vq8Fys4tpQAkksYIWcdB5i5wfrjucg5NduNOs/Esk3/CNaonh6SZjJJZ20Q8syE5B+UghM9AMgdgOleH1oadrepaXKj2dy6FDlefun29KnlVrWOuli5xqc8pPXe2jZ1Xiq48TeGtNvrTW7q6E0qeSjF9yzluNwbHOFB54I4BxXI6FoQjKahqCDO3zIYHQOD7yKSPl6cY5z2HX2DTh4i8Y+FbPxJJDY6lcQmRI7aNt0sO3G6RY24aQ46qSwUDAGa5W/u7aeEkW7zSg7vLVH3MfpjOf1rFxs9rHZWkq0ud1HJLa+/wCf5GZDFNcoz+ZLECPlEZZRIeOcHoOeen9atX0t7b6BeQTX8iSugL2UWQqLuAzJnHzHjCgHAPJ7V0mk6T4i8i7uYbCTSXZVWK7u4zGYourOqkZGAMDAHUnI61leIIPCWm+HLmO11ifVNWnwoZjkL84JZtvGcDuT1ojFtq5op04UpOEvead9bWWq73bfRdE+pwdFFFdh4gqsynKkg+ooZ2Y5Zifqc0lFABW5aeGbiSwF7qFzFYROheFJAWmn442RjnB45OBz1NUNMmtbW8F1dRiUR8rERkM3bPsK7HStC8YeOb9LjT/DrSRT/wDL9dhlgChtpO84DYOchdzcHg4rCtU5Fduy7nQp4TD0nXxdRRXRN2+9/puzkI9JuWOHeCI+jyDP5CtBNHsx54MrvuXEQCncp9eBg16OfDPwz+G8i3PjbVBrWtLtf+ybFcpG37tsFM84ySPMZVdSfkJFedeMPH+qeLJ4oltrbStNgBSCwsV2IFzkbyPvkAKOgA28KMnOEMRKtL3F7vfb7u55GCzWOKqfuKbdP+d6J/4U1d+tkvM1X1V7XSU022MsGmq7MsMrrErMQBufGN7YUDJH0AFc5qWrx738mQTTMNodQQkQ/wBnPU+9YBJJyTmito00j1/awirU42/r5L9QooorQ5wooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA7T43f8l313/t3/8ASeOij43f8l313/t3/wDSeOiuTC/wYei/I8/Jv9ww/wDgj/6Sg+CP/Jd9C/7eP/SeSuLrtPgj/wAl30L/ALeP/SeSuLqqf8aXovzkKn/v9X/BD/0qoFFFFdJ6IUUUUAaOk69rGhzmbSdRntGPXy24b6joa6t/jJ8RJLFrVvEMu0rt3hFD4+o5FcHRQO7R2Ph34oeMPDWqy3trqC3QmOZoLxPMR+Djphl5OflIyQM5xiuxk+KvgPxPID45+HqNMUV5b7TpB5ssqqF5+4wTGeC7Ywo5xkeO0Vz1MLTqS52rPutH+B5eKyjC4mp7aUWp/wA0W4v701f5nsP9m/AC7H2r/hKtdsfO/efZPKY+RnnZnyWztzj7zdOp60v/AAqrwT/0WLQP/IP/AMfrx2ip+r1F8NV/Oz/Qw/svEQ/hYqa9eWX5x/4c9i/4VV4J/wCixaB/5B/+P0n/AAj3wJtT9lvfHurS3MX7uWS3iYxu44YpiFhtJzjDNx3PWvHqKPYVX8VV/Ky/QP7LxM/4uLn8lCP/ALaexQ/En4W+HLqK58KfDiS5mLB2k1KYBoWU5QxljKQck5I29B17c14i+MfjvxF5af2p/ZUSYPl6Vug3MM8l9xc8N03beAcZGa4KinHB0k+Zq77vX8zSjkeDpz9pKPPLvJuT/G/4BRRRXSesFFFFABRRRQAVr+FVsn8caQmowrLateRLIjEBSCwHzZBBX1HcZHGc1kUUIGev6Jpos/FGqJbwX2mwRa5Zf6HLsKyAzPhh+7BC45UA4werVWtfDmi2vxVsfPtZNTtr/wC1N9pkZDbvLtc+WEKnlT8uGIO7BwMYPlNFac/kRyeZ6Bo/gjTNShWS4h1W2aS7e3ljMiZ01VUEPPlBnJ9k+uau32g2mofCvR7nzZru4srOcxWtqwVnXz2zKcg5RccgDPI6DmvMqKXMuw+V9zsdP8FukGqpqtjf3WpWEkcf9lafKnmkOM78hXyoGOgPXtVm08F6XceF01B57xS9nNcvd718i2kQkCBxtyWOPUHngGuFopXXYLPuejS+DvCtro011P8A2xJJbafaXsmy4jVXMxClVBjOACc5Oar33hXTtH1w6DKTMLzVlt4pXA8wQoAWwccFmkVc+qGuBqRridkiRp5CsIxGCxwgzn5fTkk8dzT5l2Dlfc9Mu9I0648GS3UulQwRCCORZ44o40jLQSSfK4XexV0SMh2bJJ6EjGfd+C9AXSJPIub+G7h0211CSaaRGi/esAy7QgIAznO6uSvfEGrahaNb3dxG6uQZHEEaySkdN7hQz/8AAiazKHJdhKLPRtY8C+HNJvLASX2pNby30dtJMI32SRsP9YkhiCAg/wAIZ8jvS6j8PdI0vSLy5utUmElkoguBuXCXDtGY+3KbJCT3yp5FecUUcy7D5X3PX7jwlp1n4Un0INe2VnPrVvEb+8dWSZdh/eR4UAKc46ntz1rEHgPSG1XT4JZdQsWuPtObC4dDcSeUMoUO0Ab+2R9M153RQ5LsJRfc9Y1rw1aX1vpFtNaalE9novmxaXvX7VK3mn5M7OoySfkzjtVKx+Hmi3Ou6lYLc387W/leUFJRELJuZZZlikVWU8cgf0rzSijmXYOV9z0Cy+H8F14FutYlMsU0NnNdpLHP5sT+WT8pAiCrkD/noT3xjpq23h7T9E8Ca5NFDqFxBPpttJJfb18mbc6syR/LwR05J9wO/lVFHMuw3FvqelD4feH01W0tZ9YmVdQkeexYOv7y1EYZc4UnezNtGB/C2AeBVaTwZoFrqmoC5fVmt7XSjfmAq0EgcOF27pYV3L/tBB+lefUUcy7ByvuenP4Y0Ow0DxNaW+mXmozJFZXUBDoZ443UsdpEZwFOdxAwRj7uMmhceArOPQrrVozfNaJpttdQz7lKPLIwDrnbyBk8DkcZrgKKOZdg5X3PRm8E+GpfHOqaDbT6in9nRFtssweS6b5eECQkqBk5wrk8cDmuP8S6XbaN4muNPs5biSGPaVNzC8MgyoOGV1U8Z64Gevesmik2n0BJrqFFFFSUFFFFABRRRQB2nxu/5Lvrv/bv/wCk8dFHxu/5Lvrv/bv/AOk8dFcmF/gw9F+R5+Tf7hh/8Ef/AElHN+DfED+FvHula+rSKlrcK03lorM0R+WRQG4yULDt16jrW18Q/DUHhfx1cWthJHLpd0i3unyxuHV7eTJXB3MSAQy5Jy23d3FcTXZeFfEmkS2MPhPxutxNoHm74LqA/wCkaY7H5mjJBzG38ceD/eA3DlzThL2kfmv67fqPE050qqxVNX0tJLdrdNd3HXTqm7a2vzNFegS/CfVNSkE3gbV9L8V2ZRXZ7W4jhmgDKCPOidgYyTuAGSflOcHimf8AClviZ/0LX/k5b/8Axyq+t0es0vV2/MhZxgftVop9m0n807NfNHBUV3v/AApb4mf9C1/5OW//AMco/wCFLfEz/oWv/Jy3/wDjlP61Q/nX3oP7YwH/AD/h/wCBR/zOCorvf+FLfEz/AKFr/wAnLf8A+OUf8KW+Jn/Qtf8Ak5b/APxyj61Q/nX3oP7YwH/P+H/gUf8AM4Kiu9/4Ut8TP+ha/wDJy3/+OUf8KW+Jn/Qtf+Tlv/8AHKPrVD+dfeg/tjAf8/4f+BR/zOCorvf+FLfEz/oWv/Jy3/8AjlH/AApb4mf9C1/5OW//AMco+tUP5196D+2MB/z/AIf+BR/zOCorvf8AhS3xM/6Fr/yct/8A45R/wpb4mf8AQtf+Tlv/APHKPrVD+dfeg/tjAf8AP+H/AIFH/M4Kiu9/4Ut8TP8AoWv/ACct/wD45R/wpb4mf9C1/wCTlv8A/HKPrVD+dfeg/tjAf8/4f+BR/wAzgqK73/hS3xM/6Fr/AMnLf/45R/wpb4mf9C1/5OW//wAco+tUP5196D+2MB/z/h/4FH/M4Kiu9/4Ut8TP+ha/8nLf/wCOUf8AClviZ/0LX/k5b/8Axyj61Q/nX3oP7YwH/P8Ah/4FH/M4Kiu9/wCFLfEz/oWv/Jy3/wDjlH/ClviZ/wBC1/5OW/8A8co+tUP5196D+2MB/wA/4f8AgUf8zgqK73/hS3xM/wCha/8AJy3/APjlH/ClviZ/0LX/AJOW/wD8co+tUP5196D+2MB/z/h/4FH/ADOCorvf+FLfEz/oWv8Ayct//jlH/ClviZ/0LX/k5b//AByj61Q/nX3oP7YwH/P+H/gUf8zgqK73/hS3xM/6Fr/yct//AI5R/wAKW+Jn/Qtf+Tlv/wDHKPrVD+dfeg/tjAf8/wCH/gUf8zgqK73/AIUt8TP+ha/8nLf/AOOUf8KW+Jn/AELX/k5b/wDxyj61Q/nX3oP7YwH/AD/h/wCBR/zOCorvf+FLfEz/AKFr/wAnLf8A+OUf8KW+Jn/Qtf8Ak5b/APxyj61Q/nX3oP7YwH/P+H/gUf8AM4Kiu9/4Ut8TP+ha/wDJy3/+OUf8KW+Jn/Qtf+Tlv/8AHKPrVD+dfeg/tjAf8/4f+BR/zOCorvf+FLfEz/oWv/Jy3/8AjlH/AApb4mf9C1/5OW//AMco+tUP5196D+2MB/z/AIf+BR/zOCorvf8AhS3xM/6Fr/yct/8A45R/wpb4mf8AQtf+Tlv/APHKPrVD+dfeg/tjAf8AP+H/AIFH/M4Kiu9/4Ut8TP8AoWv/ACct/wD45R/wpb4mf9C1/wCTlv8A/HKPrVD+dfeg/tjAf8/4f+BR/wAzgqK73/hS3xM/6Fr/AMnLf/45R/wpb4mf9C1/5OW//wAco+tUP5196D+2MB/z/h/4FH/M4Kiu9/4Ut8TP+ha/8nLf/wCOUf8AClviZ/0LX/k5b/8Axyj61Q/nX3oP7YwH/P8Ah/4FH/M4Kiu9/wCFLfEz/oWv/Jy3/wDjlH/ClviZ/wBC1/5OW/8A8co+tUP5196D+2MB/wA/4f8AgUf8zgqK73/hS3xM/wCha/8AJy3/APjlH/ClviZ/0LX/AJOW/wD8co+tUP5196D+2MB/z/h/4FH/ADOCorvf+FLfEz/oWv8Ayct//jlH/ClviZ/0LX/k5b//AByj61Q/nX3oP7YwH/P+H/gUf8zgqK73/hS3xM/6Fr/yct//AI5R/wAKW+Jn/Qtf+Tlv/wDHKPrVD+dfeg/tjAf8/wCH/gUf8zgq6r4eeGoPFHjqC1v5I4tLtUa91CWRwipbx4LZO5SASVXIOV3buxrWi+E+qabIZvHOr6X4UswjOr3VxHNNOFUk+TEjEyEHaCMg/MMZPFYvirxJpEVjN4T8ELcQ6B5u+e6nP+kam6n5WkIAxGv8EeB/eI3HiJ1lUThSevfovn3IqY1YuLo4OV218S1jHzvs32Sb13sjJ8ZeIH8U+PdV19mkZLq4ZofMRVZYh8sakLxkIFHfp1PWisOitIxUUorZHp0qUaUI04KySSXogoooqjQKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA//9k=",
	"malu": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwMDAgQDAwMEBAQFBgoGBgUFBgwICQcKDgwPDg4MDQ0PERYTDxAVEQ0NExoTFRcYGRkZDxIbHRsYHRYYGRj/2wBDAQQEBAYFBgsGBgsYEA0QGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBj/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4Poor0SxsU+GUdjrWtaZHdeJ7hVubHTrtG8qxi3ECaUAgtKSpCoD8mNzfMAB1Rjc2wuFdZuUnywju+3+bfRdfS7WLo3w28da/a/adM8N3bQbFkWWfbbrIrDKlDIVDggZyueo9RWn/AMKX+Jf/AELX/k5b/wDxynaW+v8AxU+IdjpOveIJzJP5myV0DpDtiLHbECqjPlgHGM9Tk16D/wAM5/8AU4/+U/8A+21oqaeyPocBkkcfTdTCYedSKdr+0hDXR/C4u266v1PPP+FL/Ev/AKFr/wAnLf8A+OUf8KX+Jf8A0LX/AJOW/wD8cr0P/hnP/qcf/Kf/APbaP+Gc/wDqcf8Ayn//AG2q9j5fid3+qdf/AKA5/wDg6n/8geef8KX+Jf8A0LX/AJOW/wD8co/4Uv8AEv8A6Fr/AMnLf/45Xof/AAzn/wBTj/5T/wD7bR/wzn/1OP8A5T//ALbR7Hy/EP8AVOv/ANAc/wDwdT/+QPPP+FL/ABL/AOha/wDJy3/+OUf8KX+Jf/Qtf+Tlv/8AHK9D/wCGc/8Aqcf/ACn/AP22j/hnP/qcf/Kf/wDbaPY+X4h/qnX/AOgOf/g6n/8AIHnn/Cl/iX/0LX/k5b//AByj/hS/xL/6Fr/yct//AI5Xof8Awzn/ANTj/wCU/wD+20f8M5/9Tj/5T/8A7bR7Hy/EP9U6/wD0Bz/8HU//AJA88/4Uv8S/+ha/8nLf/wCOUf8ACl/iX/0LX/k5b/8AxyvQ/wDhnP8A6nH/AMp//wBto/4Zz/6nH/yn/wD22j2Pl+If6p1/+gOf/g6n/wDIHnn/AApf4l/9C1/5OW//AMco/wCFL/Ev/oWv/Jy3/wDjleh/8M5/9Tj/AOU//wC20f8ADOf/AFOP/lP/APttHsfL8Q/1Tr/9Ac//AAdT/wDkDzz/AIUv8S/+ha/8nLf/AOOUf8KX+Jf/AELX/k5b/wDxyvQ/+Gc/+px/8p//ANto/wCGc/8Aqcf/ACn/AP22j2Pl+If6p1/+gOf/AIOp/wDyB55/wpf4l/8AQtf+Tlv/APHKP+FL/Ev/AKFr/wAnLf8A+OV6H/wzn/1OP/lP/wDttH/DOf8A1OP/AJT/AP7bR7Hy/EP9U6//AEBz/wDB1P8A+QPPP+FL/Ev/AKFr/wAnLf8A+OUf8KX+Jf8A0LX/AJOW/wD8cr0P/hnP/qcf/Kf/APbaP+Gc/wDqcf8Ayn//AG2j2Pl+If6p1/8AoDn/AODqf/yB55/wpf4l/wDQtf8Ak5b/APxyj/hS/wAS/wDoWv8Ayct//jleh/8ADOf/AFOP/lP/APttH/DOf/U4/wDlP/8AttHsfL8Q/wBU6/8A0Bz/APB1P/5A88/4Uv8AEv8A6Fr/AMnLf/45R/wpf4l/9C1/5OW//wAcr0P/AIZz/wCpx/8AKf8A/baP+Gc/+px/8p//ANto9j5fiH+qdf8A6A5/+Dqf/wAgeef8KX+Jf/Qtf+Tlv/8AHKP+FL/Ev/oWv/Jy3/8Ajleh/wDDOf8A1OP/AJT/AP7bR/wzn/1OP/lP/wDttHsfL8Q/1Tr/APQHP/wdT/8AkDzz/hS/xL/6Fr/yct//AI5R/wAKX+Jf/Qtf+Tlv/wDHK9D/AOGc/wDqcf8Ayn//AG2j/hnP/qcf/Kf/APbaPY+X4h/qnX/6A5/+Dqf/AMgeef8ACl/iX/0LX/k5b/8Axyj/AIUv8S/+ha/8nLf/AOOV6H/wzn/1OP8A5T//ALbR/wAM5/8AU4/+U/8A+20ex8vxD/VOv/0Bz/8AB1P/AOQPPP8AhS/xL/6Fr/yct/8A45R/wpf4l/8AQtf+Tlv/APHK9D/4Zz/6nH/yn/8A22j/AIZz/wCpx/8AKf8A/baPY+X4h/qnX/6A5/8Ag6n/APIHnn/Cl/iX/wBC1/5OW/8A8co/4Uv8S/8AoWv/ACct/wD45Xof/DOf/U4/+U//AO20f8M5/wDU4/8AlP8A/ttHsfL8Q/1Tr/8AQHP/AMHU/wD5A88/4Uv8S/8AoWv/ACct/wD45R/wpf4l/wDQtf8Ak5b/APxyvQ/+Gc/+px/8p/8A9to/4Zz/AOpx/wDKf/8AbaPY+X4h/qnX/wCgOf8A4Op//IHnn/Cl/iX/ANC1/wCTlv8A/HKP+FL/ABL/AOha/wDJy3/+OV6H/wAM5/8AU4/+U/8A+20f8M5/9Tj/AOU//wC20ex8vxD/AFTr/wDQHP8A8HU//kDzz/hS/wAS/wDoWv8Ayct//jlH/Cl/iX/0LX/k5b//AByvQ/8AhnP/AKnH/wAp/wD9to/4Zz/6nH/yn/8A22j2Pl+If6p1/wDoDn/4Op//ACB55/wpf4l/9C1/5OW//wAco/4Uv8S/+ha/8nLf/wCOV6H/AMM5/wDU4/8AlP8A/ttH/DOf/U4/+U//AO20ex8vxD/VOv8A9Ac//B1P/wCQPPP+FL/Ev/oWv/Jy3/8AjlH/AApf4l/9C1/5OW//AMcr0P8A4Zz/AOpx/wDKf/8AbaP+Gc/+px/8p/8A9to9j5fiH+qdf/oDn/4Op/8AyB55/wAKX+Jf/Qtf+Tlv/wDHKP8AhS/xL/6Fr/yct/8A45Xof/DOf/U4/wDlP/8AttH/AAzn/wBTj/5T/wD7bR7Hy/EP9U6//QHP/wAHU/8A5A88/wCFL/Ev/oWv/Jy3/wDjlH/Cl/iX/wBC1/5OW/8A8cr0P/hnP/qcf/Kf/wDbaP8AhnP/AKnH/wAp/wD9to9j5fiH+qdf/oDn/wCDqf8A8geef8KX+Jf/AELX/k5b/wDxyj/hS/xL/wCha/8AJy3/APjleh/8M5/9Tj/5T/8A7bR/wzn/ANTj/wCU/wD+20ex8vxD/VOv/wBAc/8AwdT/APkDynWvht460C1+06n4bu1g2PI0sG24WNVGWLmMsEABzlsdD6GuVr03xHY6/wDB3xnDZ6D4nneSe1W5d0iEaNlpECtGSyvjBIJ6buMHmq19Yp8TY77WtF0yO18T26tc32nWiN5V9FuAM0QJJWUFgGQn587l+YkHOUOx4OJy2n7SVCkpRqx3g2pX9JRsm/Ky8m3oed0UUVmeIdV8NtGg1/4raJplyYzA1x50iSRiRZFjUyFCp4IYJt/HoelV/E2vXPifxdf69drskupS4TIPloBhEyAM7VCjOOcZPNbfwX/5Ljon/bf/ANJ5K46tF8J6dRuOXU0vtTnfz5Ywt93NL7yezvb3Tr1LzT7ue0uY87JoJDG65GDhhyOCR+Na3/CbeM/+ht13/wAD5f8A4qsKindnBTxFWkrU5tLybRu/8Jt4z/6G3Xf/AAPl/wDiqP8AhNvGf/Q267/4Hy//ABVYVFF2afXsT/z8l97N3/hNvGf/AENuu/8AgfL/APFUf8Jt4z/6G3Xf/A+X/wCKrCoouw+vYn/n5L72bv8Awm3jP/obdd/8D5f/AIqj/hNvGf8A0Nuu/wDgfL/8VWFRRdh9exP/AD8l97N3/hNvGf8A0Nuu/wDgfL/8VR/wm3jP/obdd/8AA+X/AOKrCoouw+vYn/n5L72bv/CbeM/+ht13/wAD5f8A4qj/AITbxn/0Nuu/+B8v/wAVWFRRdh9exP8Az8l97N3/AITbxn/0Nuu/+B8v/wAVR/wm3jP/AKG3Xf8AwPl/+KrCoouw+vYn/n5L72bv/CbeM/8Aobdd/wDA+X/4qj/hNvGf/Q267/4Hy/8AxVYVFF2H17E/8/Jfezd/4Tbxn/0Nuu/+B8v/AMVR/wAJt4z/AOht13/wPl/+KrCoouw+vYn/AJ+S+9m7/wAJt4z/AOht13/wPl/+Ko/4Tbxn/wBDbrv/AIHy/wDxVYVFF2H17E/8/Jfezd/4Tbxn/wBDbrv/AIHy/wDxVH/CbeM/+ht13/wPl/8AiqwqKLsPr2J/5+S+9m7/AMJt4z/6G3Xf/A+X/wCKo/4Tbxn/ANDbrv8A4Hy//FVhUUXYfXsT/wA/Jfezd/4Tbxn/ANDbrv8A4Hy//FUf8Jt4z/6G3Xf/AAPl/wDiqwqKLsPr2J/5+S+9m7/wm3jP/obdd/8AA+X/AOKo/wCE28Z/9Dbrv/gfL/8AFVhUUXYfXsT/AM/Jfezd/wCE28Z/9Dbrv/gfL/8AFUf8Jt4z/wCht13/AMD5f/iqwqKLsPr2J/5+S+9m7/wm3jP/AKG3Xf8AwPl/+Ko/4Tbxn/0Nuu/+B8v/AMVWFRRdh9exP/PyX3s3f+E28Z/9Dbrv/gfL/wDFUf8ACbeM/wDobdd/8D5f/iqwqKLsPr2J/wCfkvvZu/8ACbeM/wDobdd/8D5f/iqP+E28Z/8AQ267/wCB8v8A8VWFRRdh9exP/PyX3s3f+E28Z/8AQ267/wCB8v8A8VR/wm3jP/obdd/8D5f/AIqsKii7D69if+fkvvZu/wDCbeM/+ht13/wPl/8AiqP+E28Z/wDQ267/AOB8v/xVYVFF2H17E/8APyX3s3f+E28Z/wDQ267/AOB8v/xVH/CbeM/+ht13/wAD5f8A4qsKii7D69if+fkvvZu/8Jt4z/6G3Xf/AAPl/wDiqP8AhNvGf/Q267/4Hy//ABVYVFF2H17E/wDPyX3s3f8AhNvGf/Q267/4Hy//ABVH/CbeM/8Aobdd/wDA+X/4qsKii7D69if+fkvvZu/8Jt4z/wCht13/AMD5f/iqP+E28Z/9Dbrv/gfL/wDFVhUUXYfXsT/z8l97N3/hNvGf/Q267/4Hy/8AxVH/AAm3jP8A6G3Xf/A+X/4qsKii7D69if8An5L72W9Q1TU9WuludV1G7vplXYsl1M0rBck4BYk4yTx7mrfhnXrnwx4usNetF3yWsocpkDzEIw6ZIONylhnHGcjmsmii/UyhXqQqKspPmTvfrddTe+JOjQaB8Vtb0y2MYgW486NI4xGsayKJAgUcAKH2/h0HSitP40f8lx1v/th/6Tx0VE1aTO3N6caeOrwgrJTkl6JsPgv/AMlx0T/tv/6TyVx1dj8F/wDkuOif9t//AEnkrjqpfCVW/wCRdR/x1P8A0mmFFFFB5YUUUUAFFFFABRWtoPhnX/E96bTQdLnvZF++UACR8Ejc5wq52nGSM4wOa763+CGoWdtHeeLfFGjaDbSIAGkk3sJCM+WdxRc4Dchj93jI5qlFvY9LCZRjMZHnoU2499l97svxPK6K9bPhP4J2n+i3/jfV5LmIBJXgiPlsw6lcQsNpPI+Y8Y5PWl/tf4EYz/whWuf9/X/+SKfJ5nX/AGE46VMRSi/8d/8A0lSt8/keR0V63/bHwI/6ErXP+/zf/JFJ/YfwJuj9q/4SfXbHzf3n2XYx8jPOzPktnHT7zdOp60cnmH9h3+DE0n/2/b/0pI8lor1g/BI6l/yKXjjQ9Z8v/j4y2zys/d/1ZkznDdcdO/bhPEHgzxP4V8s69o89pHJgLNkSRknOF3qSu75Sduc4GcYpOLW5zYrJcbhYe0q03y91qvvV1+JhUVK9vNHbxTyRlY5c7GP8WDg/rUVSeY01uFFFFAgooooAKnsrO51HU7bT7OPzbm5lWGJMhdzsQFGTwOSOtQV0Pgn/AJGt/wDsH3//AKRzU0ruxth6aqVYQezaX3svwweHdMj8hdKh1mUcS3N3LKkbH/pkkbIyryRlyxYAHCZK0/7VoX/QmaN/3+vP/j9UK9e+G/gvw9r3gaxvdR0a0vJ7jW3sp5prySGRIBAH/dIsih3B5ACsTk8dx6OGwrry5IWPKzfiOOVUPrFWK5b2sowfRv7Vu3V3fmzzD7VoX/QmaN/3+vP/AI/R9q0L/oTNG/7/AF5/8fr1XwF4I8I6rpNnc6ppUt0G128tH8yWSJ3gjs2lVCFYbTuAPY9unFUPEXw606Lw7oH/AAj8fnza3qzR2d2XY+ZbOqGMMucAruYNwDlTW/8AZs/Z+0Vrfj0/zPMXHOG+tfVJRs+7hC32r6+XI3te3zt5z9q0L/oTNG/7/Xn/AMfo+1aF/wBCZo3/AH+vP/j9d78TfCXh3S9JtNY8JxQLZxXMmnXXk3y3Yd15jlJV22F1DfKcY29BXPw+CPN+ENx46/tq1XybsWv2Aj52yQM5z15ztx0BOayqYKcJuFk7K/yO7C8V0cRh6eJ0ipy5UnCN+ZuyTsna/raxhfatC/6EzRv+/wBef/H6PtWhf9CZo3/f68/+P103hbRNJk+H3iDxTe6d/a1xp0kEUdiZHSNQ5OZZNhDEDGBgjnrW74X0jwNr+m6leavoNxpMuiD+0bi2t5ZWF5bFf9V87ZQ7yuGH8LdyN1OngnPl1Svr+flboyMVxWsP7Rum5Km1FtQg9Wk0rfE/iir2td72uzzz7VoX/QmaN/3+vP8A4/R9q0L/AKEzRv8Av9ef/H69f0PwZ4M1vwhoczaLZw3+sWmozxwx3F157PE7+WsRLGIKqgA+ZycDqc1zN7ovhrT/AIMeH9WNpoyanqNvdmSS+e9M0jJKUUwiI+UCBj7+BnGc81pLLpRjzNq1r/l5b6o5aXG1OrU9jGk+bn5LckN/f1/w/u5a+XrbhvtWhf8AQmaN/wB/rz/4/R9q0L/oTNG/7/Xn/wAfr1fXPA3hq2+G8moxaLDDJH4fstQW6t7qSS4a5kID74i7BYyOd2xQOcHsKVx4Q8Ox/B3/AITJfD8o1F7BF/sz7Q+2LMhT7fjfv2HHCn5cnoVolls4tp20V/l9xNLjqhUjGShvNQXu0/iaTXXbX5dbaX81+1aF/wBCZo3/AH+vP/j9MbStK1+RLPTNMTTNTkYJbpBM7W87E8IRIWZXYnAfftyFBVQWcU6K4HBPofUrGSb9+Ka6+7FfildHN1v6JoltPY/2tqxm+w+Y0EcVu4SSeRQpYBirBFUOpJIOdwAH3mRvjb/kpniL/sJ3P/o1q3JP+RR8Nf8AXhJ/6V3FcVVuK0OHNebDz9jF/acb+ib+V7f5a6h5mgf9CdpH/f8Au/8A4/R5mgf9CdpH/f8Au/8A4/VSvYfhV8KNF8YeF59c1u7utpmaCKG2cLtwBlmJB554Ht3zXNzy7nz2OxNHA0vbVpyt/il/meU+ZoH/AEJ2kf8Af+7/APj9HmaB/wBCdpH/AH/u/wD4/XV33gi00344R+CbnUSbRruKL7RwG2OFYD0DYYD61e1Tw/olx4W8SX0Whtos2jahFaw/vZG+1K7spRg5PzqAGyuBg9KOeXch4yj7lpSakk0+aW0nZfavv93U4bzNA/6E7SP+/wDd/wDx+jzNA/6E7SP+/wDd/wDx+vYfE3w88JWp8UX+kWRFtp1r5XkNO5NrchkO7lssrI+RnIyG9BWMPCHh3/hpS58K/wBnf8ShBIVtvOk4xalx827d97nr+lHPLuc1LNcPVg5xc9IuXxPZJN/a395f5nm/maB/0J2kf9/7v/4/R5mgf9CdpH/f+7/+P16v4V8BeF9d8M+EHa0P9p3TyXF2hmcC7t0nMbgfN8rKCh+XGQGrJtdC8M2nw7vNYu7PSBcprk1ikmqSXhTyljDBFFuc7s55b356Uc8u5SzOi5OC5207fFLu1/N5P+rnn3maB/0J2kf9/wC7/wDj9HmaB/0J2kf9/wC7/wDj9VKKOeXc9b2X96X/AIFL/MtlvD0imN/CWnxq3BeC4uVkUeqlpWUN6Eqwz1B6Vz2u6MmnCC+sneTT7pnWEyEeZG67S8b4xkrvT5gMMGB4O5V1ql1H/kml/wD9hO0/9FXNXTm72ZdOUqMotNtNpNNt7u3Vu1t/wOMooorpPaOx+NH/ACXHW/8Ath/6Tx0UfGj/AJLjrf8A2w/9J46KmfxM9XO/+RjiP8c//SmHwX/5Ljon/bf/ANJ5K46ux+C//JcdE/7b/wDpPJXHVS+EVb/kXUf8dT/0mmFFFFB5YUUV2fgDwBc+Mb6W7u5vsGg2eWvb9yFAAGSik8bscknhRyewZpX0R04TCVcXVVGiryf9fJLqzntC8P6x4l1ddM0OxkvLoqX2KQoVR1LMSAo6DJI5IHUivVofB/w4+Heyfxrqn9u6wm1v7MtRuSNvkbBTIzjJOZCqspPyE1m6z8RbLRPD8XhX4arPp+nx7xcahIoE90xypcHquRg7uG+6AEC4PmtaJKJ7KrYLLNKUVWq/zP4I/wCFfafm9NNEei658Y/Et9CtloMcGgackXkpBaKGcJtC43kfLjB27AuM98A1xcC6l4j8RxR3F5Lc3l06o1xcyFz0xlmJzgKPwArOr0bSPCerG70zQPDGmvqfiPUT5IitzvfzGJ/d9ggQKSxPAwSTgVM5u1zzsRmGIx1RPFVHJdui9FsvkjmvGrWTeOLxtPANqCqRkcZVVCg/iFFeufDXRo7qxi/4S79ndNT8Oyja2rW0l3Z3Kgj78byTbJfoAM9jXsHg74F+GPhmsGs+IQ3ibxdKm+G1tMeRbbepjLDO1f4p2wP7o9ehlvtc8ValLo50/wCy37okjRR3Uj4jfO3zTJ2YKSM4OADjBFZReiRlXftqsqqVk3ex8reMPhBef8LFvrT4ewT6loLbZbSe5lRGVXGdhLEZI9cdMZ5rG1H4MfEvTLU3M/hS7khAyWt2WbH4KSf0r7A8N+FrrQHN3qeiT/YyxSa8spd8lsQcHzYyCSowPu9BzgivRJtD1KK0W405U1e2ZQ3kAqkzKeQYnGEb2DYz/equexk6aPzG/wBM07UFb9/aXcDhgeY5I2ByD6gg16b4C8ffEH+0ra3kuTqOlq22aXUVJWNSwJJmA3bsZCgluuAp4x1PxZ8TaHr3xNuWOlRJZaU7wA3Ft5FxM6/eMm4bkwQRtIyBzgE8eZy+JZb8Mk98bGyVuAgLyN/uLnA4HU/nSdV293c9LKsTUwlZThVcF5O1/Xp952V/oHgbx1rs2ljWYvD9/AVh0+CONUhZCwyNmArMWZsKrA5JOCBXlvijwfr/AIO1NbPXLPyvM3GGZGDxzKDglWH4HBwwBGQMiq19dfbL6ScII1Y4VAc7VHAH5V3PhT4ktZ6Q/hjxlbPrXhySDyBBtBlhAyV2kkEjOAMnK4UqRtwbhBcqT3O2ti8DmVRxrR9lLpNbPspx9NOZbdU0eZUV33jn4eQ6JpNt4n8LXsmreGrlVK3JwXgY8YkwBwTxnAwflYA43cDSaa0Z4eMwVXB1fZVlZ79009mn1T7hRRRSOUK1PDupxaR4jt7y5R2tiHguBGAX8qRGjkKZIG/Y7bc8ZxnIrLooTsXTqOnNTjunc6+80+4s44p2AltZ8m3u4wTFOBjJRiBnGRkHBU8MAQRRDqup29pFawaldxQQzi6jiSZlVJQMCRQDgPgD5hzXPabres6P5v8AZGr39h5uPM+yXDxb8ZxnaRnGT+Zq/wD8Jt4z/wCht13/AMD5f/iq3VaxU6GFq/E2vKydvndfl5a7m2niXxFG7PHr+qIzTPcFlupATK67Wfr94qSCepBxTLfX9etIrSK11vUYI7Nme2SK5dRAzZ3FAD8pOTkjrk1j/wDCbeM/+ht13/wPl/8AiqP+E28Z/wDQ267/AOB8v/xVX9Zl3Zj/AGfgLW/9sj5/3vN/ey+l9ex6fLYR3lwtrMweWBZCEkYdCy5wSMnBNV6g/wCE28Z/9Dbrv/gfL/8AFUf8Jt4z/wCht13/AMD5f/iqh1rmyw+Fje0nr/dX/wAkaOn6nqWk3f2rS9QurGfGPNtpWibHplSDT21nV2nu5m1W9Ml4uy6czsTOvo5z8w4HBz0rL/4Tbxn/ANDbrv8A4Hy//FUf8Jt4z/6G3Xf/AAPl/wDiqpYhpWIlg8FKXO279+Rf/JG5D4n8SW2jjSbfxDqsNgFKi0ju5FiwSSRsBxgknPHc0QeJ/Etto50i28Q6rDp5RozaR3cixbWzuXYDjBycjHOTWH/wm3jP/obdd/8AA+X/AOKo/wCE28Z/9Dbrv/gfL/8AFU/rUu7M3luXu91u7/BHfv8AFv5muNd1wSeYNZ1AP9m+xbvtD58jp5XX7n+z09qDr2uG6e5Os6gZng+yvKbh9zQ4x5ZOclMcbelZH/CbeM/+ht13/wAD5f8A4qj/AITbxn/0Nuu/+B8v/wAVS+svuyvqGB/qC/8Akier9jYoYhqeprNDo8UgWe5UY3YwTFGSMNKQeF99xwoZhk/8Jt4z/wCht13/AMD5f/iqzdQ1TU9WuludV1G7vplXYsl1M0rBck4BYk4yTx7modXsdCjh4PmTcvJpJfPV6eX4oNU1CbVtcvdVuVjWa7ne4kWMEKGdixAyScZPrXU6LK2u6BZaXao0up2AeJLaNSWngLmQFByWdWeTcB/DsIBCuRxdFc8o8yszhxdJ4nVv3r3v56/5s66uh8N+OfFPhGKeLQNVe2inO54yiyKWxjcAwIB9x6Vxn/Ca+Mv+ht13/wAD5f8A4qj/AITXxl/0Nuu/+B8v/wAVWPsX3PLq4GrWjyVIRa7Nt/8AtptXt9eajqU2oX1zJPdTOZJJnOWZj3qa+1rWdTiij1LVr68SL/VrcTvIE+gJOK5//hNfGX/Q267/AOB8v/xVH/Ca+Mv+ht13/wAD5f8A4qj2L7lfU62nuR021en/AJKdE+u63I120msagzXuBdFrhybjHTzOfmx2zmrUvjDxdMUM3inWpDGxZC99KdpKlSRluDhmH0JHeuT/AOE18Zf9Dbrv/gfL/wDFUf8ACa+Mv+ht13/wPl/+Ko9i+5DwFR704/f/APanQQa1rFq9o1tq19C1mGFsY53UwBs7tmD8ucnOOuansvE3iTTYXi07xDqtnHI5ldLe7kjDOerEAjJOBz7VzH/Ca+Mv+ht13/wPl/8AiqP+E18Zf9Dbrv8A4Hy//FUexfccsDVlvCP3/wD2ppEknJOTRWb/AMJr4y/6G3Xf/A+X/wCKo/4TXxl/0Nuu/wDgfL/8VR7F9zT6viO0fvf/AMiasUUs86QQRvLLIwRI0UszEnAAA6k1F4juksNCHh7IN49ytzeJ18gorLHHns/7yUuOcfIOGDqMyfxd4rubaS2ufE+szQyqUkjkvZWV1IwQQWwQR2rGq4UuV3ZpSwk3JSq2stbLXXzdlt2tvbXoFFFFanpHY/Gj/kuOt/8AbD/0njoo+NH/ACXHW/8Ath/6Tx0VM/iZ6ud/8jHEf45/+lMPgv8A8lx0T/tv/wCk8lcdXY/Bf/kuOif9t/8A0nkrjqpfCKt/yLqP+Op/6TTCiitLQNCv/EviS00PTFjN1csVXzG2qoALMxPoACeMnjgE8UHnU6cqs1TgrtuyXds6HwB4AufGN9Ld3c32DQbPLXt+5CgADJRSeN2OSTwo5PYNreOvHVtqVjF4T8JwfYPDFnhEjQFTdEHO9s87c8gHkn5m5wFu/EXWdJ0TS1+GvhWDytPspQ97ciTc91NjkMVOGwcbs/xKAAoQZ81rX4dEe9jq8cupywGGfvPSpJdX1iv7q6/zPyCiiprW0ur68jtLK3luLiVgscMSF3cnoAByTSPniOM4mU8cEHmv0r/Zx+C58JfDe48datEJ/EfiV3kSQrj7JYuxdEUHlTKNrt3wVU/dOfmH4Nfs9zp4o0/xJ8WrQaXpcb+fb6DdELd6iV+b54vvRQDq7MAW+6o+bI+5fGHjefTfhteSWswFzctHp1rt42zTyLCGGO43s3/Aawqu+xvRhKTUV1JLXQdNmu22xrPLeJ500pGd8auFUf7mTwOnBPc15b8EMeItc+IOt3S7ryXXySW5Ij8rai/QAEV6H4W8aaS3xc8VafbGN7fTLbTdMgjJ4QDzifzbA/AV5x4G8TW3gH9qXW/BF7aQQ2WrxmSxlK4W4OWkiLerFWkTjugFYybTR6eEhGdGvFfEkmvRNX/DX5Hrq2EUWrRWvl7XuFZ1I/iKbcj64IP4VU01bLSfG48KOVt4bkbrdHXHlSkFzGB/cdQzpjuki9gK5X4n/EebSdV0PUNIhEs+na07XEESks8BsyZQoHX5WBA/2a434z+N49Y+HMPjbw1fAeIfD9xHc7FkyWQMsm33X7kiH0LerCqOajQdRq+iel/P+vzMT9sj4NWOreFJPiP4Vh26npyqutpGuPtduvy/aPd4+Nx7p1+4K8WtPg1e3/7Ocby6Yqz3QN5a3WAHFwFwinvsdQI/TcQe1fadx4pt9f8AAUWs6bbRXVvf2S3S2r8rNHIgYxH6qxX615roOo6NH4NOj6fObqwJb7AxPMidfJb+7MmMFT94jcM5ONKbs7nO49GfnGwKsVIII6g9qSvUvjT8Prjw14xufEOlwtN4e1OZpobhASsEjHLQv/dIOcA4yPcHHltbnO1Y7DwJ47uPCV5LZ3kP2/QrzKXlg4DBgRgsoPG7HBB4YcHsRN4/8AW+k2cfizwnN9v8L3mGSRCWNqScbGzztzwCeQflb5sFuJruvh14psNOuLjwt4jtY7vQNYZIp1mk2rA+cCTkgKOm5uCNqsD8oBe+jPdy/FU8VTWX4t+79iT+xJ/+2t7rpujzmiuk8deErnwZ4zuNIm+aBv31pIXDGSEsQpbAGG4IPA5Bxxgnm6zatoePiMPUw9WVGqrSi7MKKKKRiFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAdj8aP8AkuOt/wDbD/0njoo+NH/Jcdb/AO2H/pPHRUz+Jnq53/yMcR/jn/6Uw+C//JcdE/7b/wDpPJXHV2PwX/5Ljon/AG3/APSeSuOql8Iq3/Iuo/46n/pNMK9o8Hw/8K7+Cl/41nj8vWNXxb6fvT5o0OdpGUOM4aTByrKkfc15b4Z0G58T+LrDQbRtkl1KEL4B8tAMu+CRnaoY4zzjA5ru/jHrkd944TQbJYI9O0aIW0McG3YGIUvjaPlxhU2848vtkitIae8duUP6lh6uYv4l7kP8Ulq/+3Y6+rR51RRRQfPBSgkMCOvakooA+l/g2tr4R8OaLLcxG41/xSZdQYycm30y0DsuSeR5k0ROO+xD259r+JXiT+yfCfhpvNzHba9bedn1iSRzn/gS5r5s8A60+s/EHU9aiLtZ6T4VjsIMjiILDFFt/E+afqSa9L+J2tRX/hrWVjja5XTtbg1MQxsAZoWcI6g/8CPPowrCo7K56eAp88r9v+G/U7GUXfhLwdpnjK3vo5rrVY5H1KFG/ewXAl+0Qh0+8MqGUZHPQdaPHl7pPxB8LW2qGd7TUtOkW4sr+3bEsKMynIPcDg49Vz3rlfF/xK+Kt/4D0nxD418L+BZPD2o28s2nacY51v1gjkCGNLlVIEkQYFuABtJIJ4ruvC3wwm8R/CTSfE3hu8iktb22YPpt03kyBclSFf7ocEMD/C2Nw27to4oVlTjaoeh9XqSarw06L5afloZfwm17Vtb+LtxqfiKH+3JbV5XVNOjGyeUxJApYsQkQIViSzY9OoFQfFP4ZaroNw+r+FNV0mVrwGB/DtrdCaSFW3N5CqcNMv3iCFG35sDb09GvPhPrHi74WRaNoBvfCl/BbSnUIreby7jUZYoQkKRyKTtifaCxBzyR0yT8vQ/s9ajrXii3u9KsbPSYdSvY1ske/ae4t1bPmlpBhmaLkksoyRjA6Vl7S8vaJ2/4B2YXC1J39na0d07Le/Trs/I9v+Hev3OmfAfwTBc+YlzFcQ2LRyAqwAuHiIIPIwvasa107RD8QvE9jNpljdQTul/AXypAmGedpG5N4YHOcHB9axF1PTz8SvDfgzw/uXTNLuZL2Qlix8uOR5AWJ5JxsyT1LVwGteMLzTPihZahbTA+RPcadKjfdeJmWRQfYCXj6V6FKV1dnDi8JaUYx+KSb/wAv68zs/Go1a50K51nwNdLbyxo0N7oc8KzQT7cko0TAjdwcHo2B3Ir5V1C9OoajJdtbWtuXOfLtYhFGPoo4FfQl34mns/GelaxbuYoNSuvskydi/Dofwbj6H2rxDxzbWlp8S9ftrDb9mj1CdYwvRV8w8D6dPwrrtpc8SqrMwKKKKkxPXbOH/hZPwBl01Y/N13w3g2+1MtJEAdqDCZ+ZFZQo5LRISea8Wrufht4jfwz8RrC7aREtrhhaXJkZUURuQCxYg4CkK/b7uMgE1V+Jvhp/C/xK1CzWONLW4Y3lqI0VFETkkKFBOApDJ2+7nABFE9Vc+hx7+vYGnjftw9yfnp7kvu0b7o5CtDQraG88U6bZ3Kb4ZrqKORckblLgEZHPQ1n1peHZYoPGGlTTSJHGl5Czu5wqgOCSSegrM+ePtf8Aak/Ze+HHh74cSap8HPDslnreiT276rp0N3cXTzWtyzRxOFldzkSIQNuMjfn7oqb4ifsz/CPwL+xX4h1ZdGS7+IHh2ztYtS1Nb+4IivZDBI6+WJPLwEnUD5fulT15p3xk/ac0z4aftpx+MvBtzpHjjQrzwtBp97a6dqkbQvItxM6HzUEgV0JBxgnDnpnNcnovxX0nxV+wP8Z5vFPirR4PFniHxJJqEelTXsaXMqt9iI8qJm3sihGUYGMIfQ1kubQvQ8g8E/s63/jvw3pepaX8W/hTaXmpD9zomoeIDFqCuWKiNoRGcOSOBk9RXoP7Nnwhm8PftyN8OPir4S0y+ltNPuHlsdQgjvLeT92GSRQwKsCCCD1HsQRXo3g3VvgB4d+CHgHWPCLfBoX8SQt4mbxnateass2E3m2iyG3+Z5mCSsYG0ggAmulvfiP8OT/wVB07xXH488LnQh4VNu+rLqkH2US5k+Qzb9m7GOM56UOTd0JJHyvqPwL8Q+KLH4p/ELw9caFY6B4T1i7inspHeKXasjELCiRlMBSAAWXpXOXvwV8U2P7NunfG2a/0dvD9/emxitklkN2rh5Eyy+XsC5ibo5OCOPT6I+FHjLwFrXgX49/C/VvHeg+HbzxJqd1c6XqOqXSxWc6szgES/dxlUPHJD5UNg1S+JOr+ANG/4Jr+Hvh54f8AiJ4e8Raxp+ul54rK6USOfOuGd0hYiTygXADlRuGG4DCnzPYLHx7X3n8Sv2XvhVJ+ynaat4D0A2HjxfD8PiIBb25ma9hjSM3QEckjKP8AWg/KoO7YBwSK8I+LP7XPxI+Mfw4l8FeJ9E8LWmnyXEdwZdNtp45dyHIGXmcY554r2n4tfH3SPAer/Afxf4K1vRvE0ujaFPaatpdjqUb5SSC2VoJim/yySpI3LwydDgih30BWL/gH9l74VW37JWpar440A33xAj8NzeIn3XtzE1lHLHM1qDGkipx5JJDKTuDg8ACvnHwT+zrf+O/Del6lpfxb+FNpeakP3Oiah4gMWoK5YqI2hEZw5I4GT1Fe+/Cr496R47X9oXxb411zRvDlzruiQW2k6XfajGh2R214iwQ79plI3LnavLPnA3Yq14N1b4AeHfgh4B1jwi3waF/EkLeJm8Z2rXmrLNhN5tosht/meZgkrGBtIIAJpXaDRngnwy+F+p+EP24/C3w4+JHh60llj1OOO6sbpEube4jZCynBBV0YEHn8QCCK634gfs+6p8RP2rvirpPw8j8NaDp3hkJePZyhrWFYjCp2wpDEwByGOMKOetd/8UvHPga//wCCn/gPxXp3jHw9daFbwWgudWt9Qhe1iKmbO+YNsUgFc5PGRWt4I+Kfw3sv24fjNb6t410ez0jxTZLbWGufaUezZ1iUEecDs6MxBJAyhGc4FF3uFkfKXhv4K+KfFHwB8SfF6wv9Hj0Tw/cfZrq3nlkFy7YjOY1EZUj98vVh0P48r4O1Tw5ovjax1Pxd4V/4SjRoS/2nR/t0ll9pBRgo86MFkwxVuBztx0NfWmlN8PPh7/wT7+KHw7i+K3hHX/ENzf8AneVp18u2Yk2wC24fa84Cpkuq7c7gCdpNfF1Wne4mfb1t4Z/ZruP2Nbz49f8ADPm37Nei0/sX/hLL87szpDu8/PH3842dsZ715nr37OGoeLrbT/HuhxeBPhXoPiC2juNF8OeIfFTvczp5a5eOSVMvvyHwSCA4HFdBp/i/wmn/AASd1Xwg/ijRl8QvqyyJo5vYhdsv22Jtwh3byNoJzjoCa7j4S+K9L1f4c+DdG+IPxG+BPijwfp9nDHPZeLoDDrGmR7F328AcbWKYCB/4ggOelRqij5vsf2d/Hd74B8d+K3vNDtrfwTcSWuqW0t07Su6AE+SY0ZHHPBLjNZl78FfFNj+zbp3xtmv9Hbw/f3psYrZJZDdq4eRMsvl7AuYm6OTgjj0+m/Avin4IX/hv47/CTwr4y0bwrpGvT+boF3rMxt7R1MIVgHfkKJF4B+bawIBwRXPfEvVvh/pH/BNXw/8ADrQPiJ4f8Raxp+ulriKyulEjnzrhndIWIk8oFwFcqNww3AYU+ZiscO37GfxOjvfD0N14k8D2kWv2yz2Vxd6o8CPI4BS3AeIM8zBs7Y1bpyRkZ4SD4AfE25/aCm+DUWjRN4mgbMo80eQkW0P55k/557WU5xnkDG7ivoL4++O/CGsfEv8AZ5m0fxlol/a6Qto1/JaahFKliwltixlKsRGQEOd2Pun0rtl+N/w18L/8FM9Y8SXXijSLrw9rHh6HSl1uyuUuLaCX9043SRkgLmLaT2JGcAE0c0gsjn/gj+zva+D/AA78XIfHdj4F8Ym00Yizv7F4dTSyuUjnMkYLpvgmX92SCqnpjOOPnH4dfs9eOPiN4JufGkWoeHfDXhi3l8g634lvxZWryZwVVtrE8kDOMZ4zkEV9MfBu2+G3wg0L4zaRefHDwXrl1rWms1n9k1JAkiCO5CAu5CyTsZOUjL7eMn5hVT4MfFnwNr37Gmk/DCa/+GFn4n0K7kcWXxKtTJplyjSyyCVGyAsmJiM8kEN8uGBCu9Qsj521f9nD4j6F8avD3w01VNLgvPETD+y9UW4aSwulI++sqKTgcZG3IyDjBBM/jz9m3xp8ObbUB4h8ReDzqVtcxW9toltqZfUNS8x1RZLa2KB2Tc3VgpwpIBGCfftb+LFteftD/BbTPEfjf4UTaf4e1CV3k8HxTW1hpUPloiIZ5pDGUIXAChQuwZ6ivHvit8QtE0//AIKI3fxHs7221/R9P8QWV+s1jOk8dxFCsJIjcEqcBCBzgEVSbYWROv7GXxZMKWb6t4Lj8SPa/bE8KPrKjVGjx1Ee3b7Z3496+fryzutP1G4sL63ltrq3kaGaCVSrxupwysDyCCCCK/SHxL8V/DOpfEqL4mfD3xp+zhDbvCjrqniaymXxBAfK8t1Ox1kb5cqB8p2nbg9T8A/EvXz4p+MninxEbqyu/t+qXFwLmxge3hnDSHEiRuzMgb721iSM8miLb3E0jlqKKKsQUUUUAdj8aP8AkuOt/wDbD/0njoo+NH/Jcdb/AO2H/pPHRUz+Jnq53/yMcR/jn/6Uw+C//JcdE/7b/wDpPJXHV2PwX/5Ljon/AG3/APSeSuOql8Iq3/Iuo/46n/pNM9U+CFvDZ6xr3i28hjltdH05nZQoaUM2WzHnjOyORc5H3sdCa8+vby41DUri/vJPMuLiVppXwBudiSTgcDknpXo/hX/Rv2W/Fd5bfubmS/SB5o/ld48wDYWHJXDuMdPmb1NeY1rskjqzRulgsJh1s4ub9ZSa/BRSCiiikeCFFFFAHuvwlitrP4O3d4XC3Gr+JLXRt390eS8ij/gRLD8Kv+I9P1O20Ea4WEtlNbGN4j/HGcxlD7hVXnvtHQjNeJad4h1ex0G50KymcW91cwXexc7lni3CN1x0YCRx+PsK9/8ACXiy28aabD4b117a3vtQgmtPLX5VW9R3kRQM8ebHPKAP78W0dQKymtLM78HiPZTi10/Lqe4fDTVZfH/wU8MxXlleyPppJaaayQJNKhMTvHIwIYOBiRT/ABAkgHk+zaT4XuP7OiiV3gtkUgRhsbckk9BjqTXxP8KP2gLz4H+INT8JeJNM/tPQ1u/Pe03iKe3ZgA0sLHgg4G5DxkAgjnP1Rpn7UXwJ8QW0dnqXiOPSJJVST7Hrlq0QwcMp3ANGR0I+avBr0Z38j6epjnSj7Omlu9fmd5N4auEtybG5OQSMq+cEcGuC8UeGfGVn4evE8NLaQ3VzG0ct/OwjS1Q/fkwAWdu4HAzyT2OndftAfB/Q7WDS/D+v22uXDZFtpfh1DdyHJJwNvyoMknLEAV88ftIfGb4hX+maVoVqIdB0fVvNE9vbS77jYu3IklHGCCchBjjG41lTpOUkkaUMZiJQ1Ss+pwXhSZdB8K6rqBn8/U9XuP7Ps5iMMYgcceg5BPPXFeaatfi98e3BDZie9doyD98Lhc/kgqWDVb+e8jljlEcdtbstqApIiLAhXxwMDLN1yx29q5qC1RJbuSW6nkltYGlinGF2lSAAeuQScY9692nsonBiK0KeInVvf5/fb5fK9zc8a+LVm17TrfR3Bi0mQzCT+GS4LAsw9Qu1VHrtJ71w8ssk87zTOzyOxZmY5LEnJJrS0bVJrLXxcCOKRJiUmhkQMkiN1Ug547+oxkVLq+mWywjUNKBa1+7Mgbd5L56c87Txgn6HtXVzNysz5qaTjz31vt+pi0UUUzEK9Q+KMj+JfhX4Q8bERmYq1ldyuipLLJjr8oxs3RTEDIxvGByceX16fp/+lfsma99q/f8A2TUk+zeZ83kZaDOzP3f9Y/T++3qaa1TR72St1KWKwz2lTcvnD3l+q+Z5JRRUlvbz3d3Fa2sEk88ziOOKJSzOxOAqgckknAArI8Ejoq6NI1YveoNLvS1hk3YEDZtsNtPmcfJg8c454qlQAUUVZutPu7O1sri5i2RXsJuLdtwO9BI8ZPB4+eNxg4PGehFAFaiuhbwJ40iurO3ufCur2jXtxHaW7Xdq9ukkrnCIHcBQSfU1z1FgCiiigAooqVra4WzS7aCUW8jtGkxU7GZQpZQehIDqSO24eooAiooq/wD2HrRvrOyGkX/2m9jWW1g+zvvuEb7rRrjLA4OCM5xQBQoqzFp2oTtcrBYXMptEMlwEiZvJQEAs+B8oBIBJ7mo5LW5hhgmmt5Y47hS8LuhAlUMVJU9xuVhkdwR2oAioq0+m6jFcXkElhdJLZZN1G0TBrfDhD5gx8uGZV5xyQOpqrQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAdj8aP+S463/2w/8ASeOij40f8lx1v/th/wCk8dFTP4mernf/ACMcR/jn/wClMPgv/wAlx0T/ALb/APpPJXHV2PwX/wCS46J/23/9J5K46qXwirf8i6j/AI6n/pNM9b1j/k0zwv8A9hJ//QrmvMK9P1j/AJNM8L/9hJ//AEK5rzCtX0OnP/4lD/r1T/8ASUFFFFI8IKKK0NEsJNS1y3tIoxK7sAsZ/jPYfTOPwzSbSV2VCEpyUIq7ZtaHplxFGDbIft0q5aX/AJ9oz6ejsO/8IPqeKU1hI81yYQwjtcY8okchux9eCfxFer6efDVlKmhRarBPqO7Mix5d5ZO/QcnP8I57Vy+jXGh6RbyQeIYZneSdn8qNk2uCTjc4cbQMDgcnPVe/nqtKpJ2R9nXyrDYGhCNSabd+a2tnslp5v8Dkb0+JviLqkd1ry280mnhY7jWZT5bXEfVEcqP3khAOCBuPJboTWpIbXVpbhJYo7K6hBWBGwpRMBVjP94YCgMPTPOSKta3q8ENs4tYIrVIk229vHkqqt1I9ST8xx3+lF5Y/bNPtbaRirOxLyKcECNBz/wB9yD8quWh4tCnZu2tlr59l99td+p7la2fhb4NfBrQ9f0ma2utU8R2EdwGkmMkjbciR5F42KjlkCjAJGM8MR4rrWs3Wv+L3895tX1FzjC5mH/AVXG79FGMYAFQx6LdX13aQ3N7cy28LpGqPIWCKZM4H90Eljj1J7nNdR4N1tPC/hvV9U0t/I1W/R5mmWEkiMswA8zopDZO3+L5QMmsqNJRk23dnViMVU+rpQXLG9l5/1p6u/lblJJ9Wuma0i0oDDbGe6Zcbun3R6HisnTkkh1a7tNUtI4FeOSK4jA+VRtJ3j/dIVh/9eunt7iNo5VA3ESmFBnltoGST+eTWf4jsbu4WS4mEIMqAqQwVmKY3ZGd2CvPTqoreEuWa7GLwyqYaU4puaa9LPv28jjLMH7SHX73Rf948D8uv4VuWCzxCR7aMSsi7Jo2HEycqQ35Zz2Na/hzw6DKbqUBtuVUYwue+K1/D+lMvi/VLPGRGA2PQNgj+ZqKuISba6Ho4DIJWpqsvjbXpo3+h5xqNqltdZgLNBIN8bN1x6H3ByD9Kp16B438LtpsZuI0PkzMXQD+CQD5h9GUZ+q15/XVRqqpHmR87mWAqYDESoVFqvyCvUfhh/wAkz+Iv/YM/9pT15dXqPww/5Jn8Rf8AsGf+0p63jud/Df8AyMI/4Z/+kSPIq3vBFxBafE7w5dXU8cEEOqW0kksrBVRRKpLMTwAAMkmsGisTwj1O08Y6JfaRq9tKZLa4vrBm1SWRlUXUsZjjjEXOWYr5jnPJZ24wM1NqP/CH/wBrW39rf8I1/Z/9uRfYf7L2Z/s/D7/tHlfPj/Uf6z959+vJqKrmJ5T1E/2J/amk/wBsf8Ip/bWy+/48/I+w/wCqX7J53lfus+Z5nXts38ZrB+INxHP/AMI3EJ9JkuINJMdyulNGYY5ftdwxUCP5QcMCQvHzZHBFcZRRcdj2jWZ9PX466bry2vhG20//AISaC4OrWWtLNNLH5+d8kf2lwi4+Yny1xgdBwebszoY8YaTLpdlo11o/2aQQw3dxawTRvswzXBuDsaRWIYBsowGFA5A87oo5hcp63DZWyweKbnTLjwnf3aX+mpDd39rZw26B4LhpI0H+oBG0A7TtbYWGW21W1rUPAyeLvDmm2ltpH/COvK8l/NbwKZSv2+42q0mDIqiMR4HDFCuc/LXmS3NwtnJaLPKtvI6yPCGIRmUMFYjoSA7gHtuPqaio5g5T1u9n0VvF2kFPC/h5dqXIMq63pUkcgKAIzKsccKlCdyiVcvkg5xxzvjuPRotKtlsL/S728OpXLTS2VvbwERm2tCqlYPk2q/nKCvylg5HU1w1FDkCRauPP/s6z8z7L5W1/L8ry/MxuOfM2/NnPTfzjpxXq0HjXRrXXtBSWUSXtnaadb2d6kiGK3SS3t0uVkbPBUJIAOxkkzjFeP0Uk7Daueq6FrXhTw+l1daprFzu1XVJWuIdOt47rzLJd8ZjkJlTyxJ5rno3CK2OmczxRoO/w1okemazoV7DpFrdQTOurWqO228uHBWNpA7bkKsAoOdwxk157RTuKx6d4im0+HUPHviKPV9NuLbxArDT4oLpJJm8y8iuPnjB3R7VjYHeBzgDNeY0UUm7jSsFFFFIYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB2Pxo/wCS463/ANsP/SeOij40f8lx1v8A7Yf+k8dFTP4mernf/IxxH+Of/pTD4L/8lx0T/tv/AOk8lcdXY/Bf/kuOif8Abf8A9J5K46qXwirf8i6j/jqf+k0z1rQ/9K/ZN137V+/+yamv2bzPm8jLQZ2Z+7/rH6f329TXmNemfBI/2k3irwl/qv7U0w/6T97ytuY/u/xf6/PUfd9+PNpoZra5kt7iJ4Zo2KSRyKVZGBwQQeQQe1a7pM6s1Tq4TCYhbcrh84yf6NfkMooopHghVuyv7jTzLJauY5nQxiQfeQHg49CRkZ9zVSik0mrMqE5QfNF2Z2egW1haeHPtQcrqFyrsJs4aOIHZsj7BnIYMx6L06mpZby0sYYVgsoJLyWNSFADbSezE9cDB616X4N/Zm+Jfi74QQeLIDp9p+5a502wndlubqIncDwNqBuSu45IOeAQa4HS/hp8SfF/jtPDWl+Grz+2I4pCYZl8hIEXq7O+FABIHXksAM5rilOLm/e2Pap1nHDxj7Oz79/Xz8yGTwV4y8SeH5td0nwre6nbWBzcXGlWLuiAHLAsq4OO+OR3xUel38VxqsDSXIVVibYuDk7m+bHHoBX6I+DfFtj4M+HXh/wAJXWiLoWp2NmLebTg6ssc0USysquvDeagldJB1ZWB5GK+Pv2mbTw1F8UYtd8PXpjvLoyCeCGMJHJKjfNcpjGwurQllI5YsRxmuaniPay5WvQ3jGWHbqpaaX+9P9DhbmdrKNJQyoYMShZCASxHPTr0HHOKbaC3m8NxxzQqDFbqVYSuQWZQN2NxUH1OPasqx1OOZ1fUQVCKwKLhcgg42gkDriommkTTocMsohHKLgnnliMe9dCg+4TzCnZxjC61tez3SXbS1unbz0PDc+beMzDMrTyRkegGSfzP9K6vVodGn0rSNTjutNR7cEajZ3lwBJO6SnJROXYPGV4AABB6VwWh3G7XnCnMeXmX/AIEAK67T9STz5gkEc8RKxyoysdxzxtKfMCPUZ6kEGqemplg5OaVK+7t8tu6X3s4+PXNS8P8AiSVbW7uJ7eGYhYrjcBImeMqeRkYPYjNdbceMrPRr/VNa09Y7i5vo7dLeOTogEe5mbHoSBjufpXL+K4Y7m4k1OMRo6zfZpIoySqgLmPBIBJCjacgHK574HM1rOhCpaRNHN8ZgHKipap6X1s7NO3yf36npFh4+k8SWdxoXiOK3Dzr/AKLdRpsCSjlQw6YJ4z2zzXnUyGK4eMqVKsRg9RTASDkU6SR5ZDJIxZmOST3NVToxpt8uzOTG5lWx0Y/WHzSjpfq12fp+o2vUNA/0X9lnxXeW37m4kvkgeaP5XaPMA2FhyVw7jHT5m9TXl9eo/EWKbw98C/Bvhe4hczTu99I0imNomALGMoecg3GM5H3OnPG60TZ25InThicS9o02vnP3V+bfyPIqKKKyPBCir0Onp5SyXlwYQwyqIm9yD0JGQAD9c9DjBzUn2LTf+f66/wDAZf8A45VcrFdGbRWl9i03/n+uv/AZf/jlH2LTf+f66/8AAZf/AI5RysLozaK0vsWm/wDP9df+Ay//AByj7Fpv/P8AXX/gMv8A8co5WF0ZtFaX2LTf+f66/wDAZf8A45R9i03/AJ/rr/wGX/45RysLozaK0vsWm/8AP9df+Ay//HKPsWm/8/11/wCAy/8AxyjlYXRm0VpfYtN/5/rr/wABl/8AjlH2LTf+f66/8Bl/+OUcrC6M2itL7Fpv/P8AXX/gMv8A8co+xab/AM/11/4DL/8AHKOVhdGbRWl9i03/AJ/rr/wGX/45R9i03/n+uv8AwGX/AOOUcrC6M2itL7Fpv/P9df8AgMv/AMco+xab/wA/11/4DL/8co5WF0ZtFaX2LTf+f66/8Bl/+OUfYtN/5/rr/wABl/8AjlHKwujNorS+xab/AM/11/4DL/8AHKPsWm/8/wBdf+Ay/wDxyjlYXRm0VpfYtN/5/rr/AMBl/wDjlH2LTf8An+uv/AZf/jlHKwujNorS+xab/wA/11/4DL/8co+xab/z/XX/AIDL/wDHKOVhdGbRWkbCxYYj1CUN2M0G1fxKsx/Q1QmhkgmaKVdrr1HX6EHuO+e9JpoExlFFFIZ2Pxo/5Ljrf/bD/wBJ46KPjR/yXHW/+2H/AKTx0VM/iZ6ud/8AIxxH+Of/AKUw+C//ACXHRP8Atv8A+k8lcdXY/Bf/AJLjon/bf/0nkrjqpfCKt/yLqP8Ajqf+k0zd8GeIP+EW8d6brxi82O2l/eoF3ExsCj7RkfNtZsZOM4zxXW/F/wAPSaH8Srq6jg2Wepf6VEw3EFz/AKwEn+LflsAnAdemcV5rXtGkj/hZHwBk0wR+brvhvHkbUy0kQB2qMJ3RWQKOS0SFjzWkNVY7crX13CVcv+18cPNpe8vnHX/t08jooooPngr2/wDZo+Ccnxa+JP2rV4JB4W0hlm1B+VFwx5S2U+r4JYjogbuRXlHhrwxrXi3xbpvhvQ7J7jUNRmENvHjAYk8knsoAJJ6AAk9K/U34X+CNF+F3ww07who5WRbZTJc3W3BurhseZKfqQAB2VVHauPG4n2MLLdnXhMM60vJHXxWlrp8PmsRHFCuQqDaiKo6ADjAAwB2xXn/w7thfTa54lt48peX720Bz92KEnIHoPMeXPuvtWb8dvirYfDz4T6lfPKr300RitbcHmWRuEUDryf0DHtXdfDzQW8JfCfw94duGMt1Z2EaXUh6yTsN8zH6yO5rwUnytn0Tm6aUXu/y/4f8AIXWPDHhfU0trzxRY2ctyMWsU5LIwZzhVUgg5yTtPUEkjGTVLUvhJ8OdZ8FT+FtR8LWV3p8x3N52WmDDOHEx/eBlyQCG4HHTiue+L2ui0fwxp8NwIribVBMgDYP7uKRh9emfwrq/DXimHWtMWVmVLlMCaP0PqPY1KbjZplToTlS53s+h8K/Gr9nTX/hLdPrmh239v+E3fAuGiBubIk8JOB1HYSKME8EKSM+Px6za3mlz2seIWkCvCwUcSLyoyOxBI/Gv1M8apaar8NPEFhdhTDNptwrbug/dsQfwIB/CvzA8T6BZ2niDPmrAt4qSIxGBDI+flYdgWBB9Dj1r06GIdRcsycJgpRTrU2tHytPZqSa+Xa/RtbHJQXZh1GWdV8t549uBxtOcniui0+5+w6KbnPzFt6D1PRf5VzdzBONVWG8jEV0sjK49Cf/18VuNbvM8cRISCMYGOprv3R4acqNRxWjT9GWMRaytzFeyjzr51eOUtgJN820t7MW2+2c9q4+SN4pmikRkdCVZWGCCOoNdymsabb6Be6Z9n84INybegJznLfUA8d81h61D9u8SyeYWWZo4/O8uMvul8td/A985981dGbs01sdeb0o1JU8RCV3UV30s9n9+5gUVYks54bdZZAq7jgJuG7/vnqKr962TT2PFlCUfiVjovAvh6TxP4907S/I86380S3QO4KIVOXyV5XI+UHjlgMjNXPi74g/4SD4qX22LZFp//ABL48rhm8tm3E8nPzl8dPl28ZzXYeGB/wrn4J3/jSaPy9Y1fFtp+9PmjU52tyhxnDSYOVYJH3NeK05aKx7+MX1HL6eF+3VtOXktoL85eV0FXNLjSTVE8xQ6ory7WGQxRCwBHcEjn2qnV7SP+Qmf+uE3/AKKaojufOvYezM7s7sWZjksTkk+tJRVrTNOu9Y1uz0nT4jNd3k6W8EY6u7sFUfiSK1EVaK9i8f8AwrtNL8TeG4LXTb3wtpl7dvo095rMUsSvLC4BvP3uMJKjo4GQoIcAgDjOuvhhY2qSWr6jc2MT6nptoNQ1ywFmyJcLd7nQpcyRNF/o4+Yk5IwGQK28A8uor1aD4f8AhDS5vFdv4iu/E8MVlocN/a3U2jxJIrNfQQmSONbwpKuH2A78He54MahqGv8Awst/D/gV9YuvF2lf2pHawXb6Wbq03sswQhEVbgzGQLIGIaFRhWIY8ZAuecUV3vjb4faZ4Xi1z+y/E0urS6HrI0a/WSw+zASN5xRoz5jbh/o8gbIXBxjcDmrug+ENB1z4FNcRWrL4ql1G9aznErYnitre2ke22Z27is0rqQNxMYXncKAuea0V7RefBzTtX8deJ7DSr+TRkt9Yu7DS7e4+z/Z5hFyEEk10szsMgEJFIRlSSc4HLaX8O9MvdEt3vPE8lrq1zo15rkFilgZIzDBHM4RpfMGHfyG42kBTnJPykFc4CivQtW+GI0/4YHxXDq8n2mCG2nu9MvEtopY0m2hWVI7mSXbl1wZIo8hgfatX4UfDM+MfD2o31x4b1TVVu5xo9jPZxSsljcPGz/aZSnARG8lSH+XbKx/hyAdzyiiuq8V6HaaP4U8Izx2bW97e2FxLfbmbLSpfXEIyCcKQsaLgY6euTXTan4DZvA+jWOheGYLvV3to7jUrpb1vtFlJJukQToW8pIGgMbBsDBJDOCCtAHl9Fd78LdF8Mazf+IV8VwbrO30nfHP5rp9klku7eAT/ACkbtgmZtpyDjkV0978LtKi0nwn4Vki+w+J7rXo9J1a/3NKInmVHVBHuCny1kTOMEtuBPTAK543RXoPgfwvay2Ntr975N1FeWniG3FpNAGWN7XSvOSUEk5O6dSOBtMYIOTxp+I/BXhKN9TTw1dXDy2vhjTdSli1C18lI5J/7PG+OUXJG5zdOzb12JllUH5XQGeV0V6v4R8JaDpnhfxPd+Lk8Hz3VldWEMFxqOoXV3Zosy3LMofS3Ys58pOpIG05wTyad4R8GXHhO91jXpZLKOTw4dVt30izkn8lv7aNpu2zXK7zsAQA7RsfJG9N0gK55RRXX3vgb7G2uAapvGl6HY61nyMeb9pNp+6+98u37Z97nPl9Bu4rePPDWleEPG2oeGtO1yfVptOuprS6mezFsgeNyvyfvGLdOcgYOQNw5IM5miiigAooooAKfcqJdE8xvvQTKin/ZcMSD7Arkf7zetMqSX/kX5/8Ar4i/9BkpPYDLooorIo7H40f8lx1v/th/6Tx0UfGj/kuOt/8AbD/0njoqZ/Ez1c7/AORjiP8AHP8A9KYfBf8A5Ljon/bf/wBJ5K46ux+C/wDyXHRP+2//AKTyVx1UvhFW/wCRdR/x1P8A0mmFdB4K8R6j4V8aWeraZA9zICYntVZh9oRuCny9T0I4OGCnBxiufrvfhR4zuPBfiyW7trCyvGuIxE8VzCrl485ZFY/dJ46ZzjByOKL21OLDValKrGpSdpJpr1NP4n+DrXS7tPFWgCD+wtRkCpFGDGbaUrkoUbkZwxxgbTlSFwM8dounx3eoLJeOkNnHl5JJQ2wgfw5UdScD8e1e1eMtMkm8I3/jT4fXE58LXD79Q0qFQr6TKMHY8fIEYOCrr93jPGDXmFva3Wpz7LZr29UEuUi5I45OB09zilKr5HoYxU8ViHVpQ5b6uK79bdl5dNjpx4jvNN1zSbjw9fXNgdPCzW00NwdsW05KpggDIyCCOQTnOa+ufEP7SngrS/hVF40S7YR3AZI7QgGcTD70ITPLDIyfugEEnBGfhMF9OdrVLZ8ORx6nkYPHrzgf0rkPEN3FdaglvDL9oeLKtOrZV2OOB7Dpnv8ATFcNbDxqJN9DX6/KlJycVd/JLtZen9d/cvBnibxH+0L+194RPiYOmjxah9sSzzmKOGH96wyfvs3lhSe+QAAMCv0in1NYopJZ32YBZye3c1+XE4stL8PLp0loyXVrKY4vJJeNUDE5DqefmYnpnqc9q9It/wBoHx/YfC2PwgkUN2sFs0Ka1LLI8qLyyyP1BKggDJ/hXOcVhWwznZR6HRStBuVWXM2k21rby20f4HufjHWrbxX4mv8AXtQnFvpWnI0VpcMceUVOXuFPbaVCg99r9Qai+HPxBh8S6DHrukTeVcQuYbmLGCjj1X+6www9jjqDXxd/wl+r3XhqDQbrU7s2cGTHDLO7w5znlPXJz6ewqz4M8b6v4L8SS6rpuoGNpkMcyMnmxSjtvQkZwcEEEEH2JqpYCXK116HdTzjD+6ls9/I+4/it8VLXT/hJf6exEGqanH9jt0JyjZI3sec7Quc/UDOSK+NfEOqW2sG+kvkeW7I2CR5M5O92chv4v4QN3PJxWX4k8Va34p1B9Sv7yW+mYbRMcARr/dRF+4Pb8eTWB505h8p+FAxk8cVthsPKnGzOPMsVhnyqkrtPV30t27fP5Drx5b9YtQuBuuIiI5ueWGMZJ9eh/E1H9quG/wBEspZX3HaQ427PYk/yFLFd28Ftdq3ztJGFQDpuz1P0GfxxW34AtdA1/wCIul6V4x8QtoelTzbZdSWNW8ng4JzwATgFj06murk5Ynm4mvHETjK/vPf1vbV+asZq2d7ZrHHIkLl5Qw2ljyvIGcd8Vft9P1W0uPtESrM5GWPPzA855r7M03wr+y74G8QDwhrdrY3PiJgjQS+Kpnlgu434SWGYAwBWHQ4GDkHpXj/x9+FHhPwr4cfxD4It5dNntrkLf2iTOvlB+g8tmYrzgqVJRlbKkgEDlhiFKSitLnWqceV+0jzcq6OzS1fbX5nkySW103l3kBim6qTwR9GH+NRaP4Y0q98b2cGs38drYmRp7mW6cqJUB3FMjG0nBBJIwDntis7QV1zWIbsrH51rZwmaa5lIUQ/3fm7liMBep57AkW7y53xpdlgUBVEGPvHdyfcYyPxNdUbxkrmCUKTjWUeam9bS62e3n2uul13M/wCIvi5fFfir/QY0g0iwU2mnwRblTy1PDhTgKWAHAAwAo525rkKknEYupBFnywxC59M8VHWrd3c8/F4mpiq0q9V+9J/18uwVe0j/AJCZ/wCuE3/opqo0+GWSC4jnibbJGwdTjOCDkUJ2Zzsu1d0jV9Q0LWYNW0q4+z3kBJil2KxQkEZAYEZwTg9QcEYIBqvGILtd8EsML/xQyybNvurNwR7Zz9cZL/scn/Pez/8AAuL/AOKrUku6Z4k1bSLF7Gzlt3tXuYrxre6tYrmNpYw6oxSVWBwJHBGMHPIOBjUuviJ4rvQkdzdae9tHLDKll/ZlqLVWh87ywIBH5YUG5nJXbhi5JBOCOe+xyf8APez/APAuL/4qj7HJ/wA97P8A8C4v/iqBaHQj4i+KxrP9pfarDcLQ2H2X+zLX7J5Bk8zy/s3l+Tt8z58bPvc9earXvjTxBqXhxNE1CWwurdI0hSabTrZ7pI0I2ItyY/OVQAAAHxt+XpxWP9jk/wCe9n/4Fxf/ABVH2OT/AJ72f/gXF/8AFUBoX9R8Ua7qx1c6hfed/bF+up337pF864XzcPwBt/18vC4HzdOBhLHxNrumW2mwWGoPAmm3zalabFXMVwwjBcHGTxDHwcj5enJzR+xyf897P/wLi/8AiqPscn/Pez/8C4v/AIqgNDrIPix49ttRub+LWoTdXF5LftO9hbu6TS48xo2aMmMPgBlTapAwRV7RPig+ifDefw5Fp1zcXslnc6fHd3E8LRwQThg6Iog84DDudvnFNx3bc1wv2OT/AJ72f/gXF/8AFUfY5P8AnvZ/+BcX/wAVQGhv3vxB8W6h4Zl0C71KF7GaGGCYLZwJJOkRXyhJKqB3K7FALMSAMZwSKx5tZ1O40rT9Nkuj9l08yNaxooXy2dgzNkAEkkDk5OAB0AqD7HJ/z3s//AuL/wCKo+xyf897P/wLi/8AiqA0NHxD4q17xXdxXOvXq3UsXm7GEMcWPMmeZ+EUA5kldv8AgXpgVrW3xP8AG1nYR2kGqwbUtxZmR7C3eWS3C7RBJK0ZeSLaAPLclcADHArmPscn/Pez/wDAuL/4qj7HJ/z3s/8AwLi/+KoDQlsdWv8ATrXULeyn8qLULf7JdLsU+ZF5iS7eRx88SHIweMdCRU9l4j1vTrK0tLG/e3itL0ajb+Wqho7gBQJA2M5G1eM44qn9jk/572f/AIFxf/FUfY5P+e9n/wCBcX/xVAXR0V78RvF9+bfz9Rt0W3S7SGO2sbeCOMXcIhuMJHGF+dBg8cHLDDEmq1z438SXei/2VPeW7W5sV012WzgWWS3V4nSN5Qgdwpt4du5iVC4GASDjfY5P+e9n/wCBcX/xVH2OT/nvZ/8AgXF/8VQGhLDq2oW+gXeiw3G2xvJorieHYp3vEHEZzjIwJZOAcHdznAxp6b428SaV9lW1vLdo7aybTo4LmzguIjbtO1wY3jkRlkHmsX+YEg4x0GMf7HJ/z3s//AuL/wCKo+xyf897P/wLi/8AiqA0N2fx/wCLLnwtL4em1GJrCa1ispVFpCJJYYnR40eUJvYIY025Y7QNowCQcbVtUv8AXNfvta1Sfz76+uJLq5m2qvmSOxZmwoAGSScAAVH9jk/572f/AIFxf/FUfY5P+e9n/wCBcX/xVAaFeirH2OT/AJ72f/gXF/8AFUfY5P8AnvZ/+BcX/wAVQFyvRVj7HJ/z3s//AALi/wDiqPscn/Pez/8AAuL/AOKoC5XqSX/kX5/+viL/ANBkqQ2uwbpbuzRB1YTq+PwQkn8BVG8ulmCQwgiCMkru+8xOMsfTOBx0GB15JUnZD3KtFFFZFHY/Gj/kuOt/9sP/AEnjoo+NH/Jcdb/7Yf8ApPHRUz+Jnq53/wAjHEf45/8ApTD4L/8AJcdE/wC2/wD6TyVx1dj8F/8AkuOif9t//SeSuOql8Iq3/Iuo/wCOp/6TTClVmRw6MVYHII6g0lFB5Z3Hhz4iarpWrQXKXAtZQAkk0eQs46fvFzg/XHc5Bya7cafZ+JJJR4a1NPD8kzGSSztoh5ZkJyp+UhgmegGQOwHSvEK0NO1rUdLkV7O4ZChyvP3T7elTyq1rHXSxc41OeUnrvbdr1Oq8VT+JvDenX1rrd3dCaVPJRi+5ZyeNwbHICg88EcA4rkdC0MRldQ1BBnb5kMDoHB95FJHy9OMc57Dr6/pyeIvGPhWy8SSRWOo3EJkSO2jbMsIXG6RY24aQ46qSwUDAFcrqF3azxErbvNKDu8tVfcx+mM5/WsXCz2OytNVpc7qOSW13r+f5GZBDLcxNIZZYQfurGWUOeOcHoOef8mrV7LewaBeQz38iTOgL2UWQqLuAzJnHzHjCgcA8kdK6LSdJ8ReRd3MVjJpTsqrFd3cZjMUXVnVSMjA4GAOpOR1rM1+Dwlpvh26itNYn1PVp8LuY5A+cEsdvGcDuT1pqLbV1obe7TouUH7zT62SW3fV+XRPqcJRRRXWeEKGKnKkg+1DOzfeYn6nNJRQAVuWnhq4ewF9qFzFYQuhaFJAWmn442RjnB45OB7mqGmzWtreC6uoxKI+ViIyGbtkegrrtM0TxZ41v0uLDw80kc3/L9dhlgChtpO44DYPUDLcHg4rOXO3aJ6eAwca7tZyk9opNv1dv+B6o5hrTUboRJdXikQxiONZp92xASdoGTgZJOPc1oS2guS4ur+6ugkQhtw7O7RqDkAcEbeTgcAZrvG8OfDf4eSLc+M9SXWdYUq/9lWQykbfIcFM84yT+8ZQyk/KTXnvi3x5qniqaOJbe30vToAUhsbJdiBc8byPvkAKOwGOAMnLlF9zrxOWwwEH9aqL2n8i95r/E9o+mr8jUk1VrbSV02382HTldmWGV1iVmOBufGC7YABJHsABxXPajqsW9zDIJpmGA6ghIh/s56n3rCJJOTRWfJ3PNq4tz6a+bvb02S+4KKKKs4wooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA7H40f8lx1v/th/wCk8dFHxo/5Ljrf/bD/ANJ46KmfxM9XO/8AkY4j/HP/ANKYfBf/AJLjon/bf/0nkrjq7H4L/wDJcdE/7b/+k8lcdVL4RVv+RdR/x1P/AEmmFFFFB5YUUUUAaOk69rGhzmbSdRntGPXy24b6joa6p/jH8Q5LFrVvEMu1l27wih8fUdK4SigabR1/h/4meLvDuqy3ttfrdeccyw3aeYj8HHoy8nPykZIGc4rrZPih4H8SyA+NvACNNsV5L3T5B5ssoAXn7jBMZ4LtjCjnGR5HRVKbR6mFzrF4an7CMlKn/LJKS+5p2+Vj1v8As/4EXQ+1f8JRrlj5v7z7L5bHyM87M+S2cdPvN06nrTv+FYeDP+iuaF/5C/8Aj9eRUVXP3R0f2vhp/wAbCQfo5R++0v8Ahj13/hWHgz/ormhf+Qv/AI/Sf2B8ELU/Zrzx1qktxF8kslvETGzjglMQsNpOcYY8dz1ryOijn8g/tbCw1pYOC9XOX5yPXYviL8MvD1zHceF/h5JcTFg7SajKA0TKcoYyxlIOSckbeg69uc8QfF3xx4g8tf7T/suJMHy9M3QbmGeS24ueD03beBxnmuFoqXNszrZ/jakPZQkoQ7QSiv8AyVK/zCiiipPGCiiigAooooAK1/Cq2T+ONITUYVltWvIlkRiApBYD5sggr6juMjjOayKKEDPX9E00WfijVEt4L7TYItcsv9Dl2FZAZnww/dghccqAcYPVqrWvhzRbX4q2Pn2smp21/wDam+0yMht3l2ufLCFTyp+XDEHdg4GMHymitOfyI5PM9A0fwRpmpQrJcQ6rbNJdvbyxmRM6aqqCHnygzk+yfXNXb7QbTUPhXo9z5s13cWVnOYrW1YKzr57ZlOQcouOQBnkdBzXmVFLmXYfK+52On+C3SDVU1Wxv7rUrCSOP+ytPlTzSHGd+Qr5UDHQHr2qzaeC9LuPC6ag894pezmuXu96+RbSISBA425LHHqDzwDXC0UrrsFn3PRpfB3hW10aa6n/tiSS20+0vZNlxGquZiFKqDGcAE5yc1XvvCunaPrh0GUmYXmrLbxSuB5ghQAtg44LNIq59UNcDUjXE7JEjTyFYRiMFjhBnPy+nJJ47mnzLsHK+56Zd6Rp1x4MlupdKhgiEEcizxxRxpGWgkk+Vwu9irokZDs2ST0JGM+78F6AukSeRc38N3DptrqEk00iNF+9YBl2hAQBnOd1cle+INW1C0a3u7iN1cgyOII1klI6b3Chn/wCBE1mUOS7CUWejax4F8OaTeWAkvtSa3lvo7aSYRvskjYf6xJDEEBB/hDPkd6XUfh7pGl6ReXN1qkwkslEFwNy4S4dozH25TZISe+VPIrziijmXYfK+56/ceEtOs/Ck+hBr2ys59at4jf3jqyTLsP7yPCgBTnHU9uetYg8B6Q2q6fBLLqFi1x9pzYXDobiTyhlCh2gDf2yPpmvO6KHJdhKL7nrGteGrS+t9ItprTUons9F82LS96/apW80/JnZ1GST8mcdqpWPw80W513UrBbm/na38rygpKIhZNzLLMsUiqynjkD+leaUUcy7ByvuegWXw/guvAt1rEplimhs5rtJY5/NifyyflIEQVcgf89Ce+MdNW28PafongTXJoodQuIJ9NtpJL7evkzbnVmSP5eCOnJPuB38qoo5l2G4t9T0ofD7w+mq2lrPrEyrqEjz2LB1/eWojDLnCk72ZtowP4WwDwKrSeDNAtdU1AXL6s1va6Ub8wFWgkDhwu3dLCu5f9oIP0rz6ijmXYOV9z05/DGh2GgeJrS30y81GZIrK6gIdDPHG6ljtIjOApzuIGCMfdxk0LjwFZx6FdatGb5rRNNtrqGfcpR5ZGAdc7eQMngcjjNcBRRzLsHK+56M3gnw1L451TQbafUU/s6IttlmDyXTfLwgSElQMnOFcnjgc1x/iXS7bRvE1xp9nLcSQx7SpuYXhkGVBwyuqnjPXAz171k0Um0+gJNdQoooqSgooooAKKKKAOx+NH/Jcdb/7Yf8ApPHRR8aP+S463/2w/wDSeOipn8TPVzv/AJGOI/xz/wDSmc74Q15/DHjrS9dVpAlrcK0vlqrM0R+WRQG4yULDt16jrWz8QPDkHhnxvPa2Dxy6Zcot5YSxuHV4JMlcHcxIBBXJOTtz3FcXXX+F/EWlS2UPhbxos8uhebvguoD+/wBNdj8zRkg5jb+NMH+8BuHLi+jFhqkK1F4So7a3i3sns0+ylpr0aV9L25yiu9k+Fmp6i4l8E6tpnii0KK5e1uEhlhDKCPNidgUJO4AZJ+U5weKZ/wAKc+I//Quf+TkH/wAXV8r7A8kzC/u0JNd0nJfJq6fyZwtFd1/wpz4j/wDQuf8Ak5B/8XR/wpz4j/8AQuf+TkH/AMXRyy7B/YmY/wDQPP8A8Al/kcLRXdf8Kc+I/wD0Ln/k5B/8XR/wpz4j/wDQuf8Ak5B/8XRyy7B/YmY/9A8//AJf5HC0V3X/AApz4j/9C5/5OQf/ABdH/CnPiP8A9C5/5OQf/F0csuwf2JmP/QPP/wAAl/kcLRXdf8Kc+I//AELn/k5B/wDF0f8ACnPiP/0Ln/k5B/8AF0csuwf2JmP/AEDz/wDAJf5HC0V3X/CnPiP/ANC5/wCTkH/xdH/CnPiP/wBC5/5OQf8AxdHLLsH9iZj/ANA8/wDwCX+RwtFd1/wpz4j/APQuf+TkH/xdH/CnPiP/ANC5/wCTkH/xdHLLsH9iZj/0Dz/8Al/kcLRXdf8ACnPiP/0Ln/k5B/8AF0f8Kc+I/wD0Ln/k5B/8XRyy7B/YmY/9A8//AACX+RwtFd1/wpz4j/8AQuf+TkH/AMXR/wAKc+I//Quf+TkH/wAXRyy7B/YmY/8AQPP/AMAl/kcLRXdf8Kc+I/8A0Ln/AJOQf/F0f8Kc+I//AELn/k5B/wDF0csuwf2JmP8A0Dz/APAJf5HC0V3X/CnPiP8A9C5/5OQf/F0f8Kc+I/8A0Ln/AJOQf/F0csuwf2JmP/QPP/wCX+RwtFd1/wAKc+I//Quf+TkH/wAXR/wpz4j/APQuf+TkH/xdHLLsH9iZj/0Dz/8AAJf5HC0V3X/CnPiP/wBC5/5OQf8AxdH/AApz4j/9C5/5OQf/ABdHLLsH9iZj/wBA8/8AwCX+RwtFd1/wpz4j/wDQuf8Ak5B/8XR/wpz4j/8AQuf+TkH/AMXRyy7B/YmY/wDQPP8A8Al/kcLRXdf8Kc+I/wD0Ln/k5B/8XR/wpz4j/wDQuf8Ak5B/8XRyy7B/YmY/9A8//AJf5HC0V3X/AApz4j/9C5/5OQf/ABdH/CnPiP8A9C5/5OQf/F0csuwf2JmP/QPP/wAAl/kcLRXdf8Kc+I//AELn/k5B/wDF0f8ACnPiP/0Ln/k5B/8AF0csuwf2JmP/AEDz/wDAJf5HC0V3X/CnPiP/ANC5/wCTkH/xdH/CnPiP/wBC5/5OQf8AxdHLLsH9iZj/ANA8/wDwCX+RwtFd1/wpz4j/APQuf+TkH/xdH/CnPiP/ANC5/wCTkH/xdHLLsH9iZj/0Dz/8Al/kcLRXdf8ACnPiP/0Ln/k5B/8AF0f8Kc+I/wD0Ln/k5B/8XRyy7B/YmY/9A8//AACX+RwtFd1/wpz4j/8AQuf+TkH/AMXR/wAKc+I//Quf+TkH/wAXRyy7B/YmY/8AQPP/AMAl/kcLRXdf8Kc+I/8A0Ln/AJOQf/F0f8Kc+I//AELn/k5B/wDF0csuwf2JmP8A0Dz/APAJf5HC0V3X/CnPiP8A9C5/5OQf/F0f8Kc+I/8A0Ln/AJOQf/F0csuwf2JmP/QPP/wCX+RwtFd1/wAKc+I//Quf+TkH/wAXR/wpz4j/APQuf+TkH/xdHLLsH9iZj/0Dz/8AAJf5HC0V3X/CnPiP/wBC5/5OQf8AxdH/AApz4j/9C5/5OQf/ABdHLLsH9iZj/wBA8/8AwCX+RwtdR8P/AA5B4m8bwWt+8cWmWyNeX8sjhFSCPBbJ3KQCSFyDkbs9jWrH8LNT05zL421bTPC9oEZw91cJNLMFUk+VEjEuQdoIyD8wxk8Vi+KPEWlRWU3hbwWs8Whebvnupz+/1J1PytIQBiNf4EwP7xG48L4dWa0sBLByVfHRsk/gekpeVt0u7aWm12Zfi/Xn8T+OtU11mkKXVwzReYqqyxD5Y1IXjIQKO/TqetFYlFZN31PMrVZVqkqs3dybb9WFFFFBmFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAf/Z",
	"kaget": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwMDAgQDAwMEBAQFBgoGBgUFBgwICQcKDgwPDg4MDQ0PERYTDxAVEQ0NExoTFRcYGRkZDxIbHRsYHRYYGRj/2wBDAQQEBAYFBgsGBgsYEA0QGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBj/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4Poor0ywsE+FMen65rmlR3fiy5Rbqw0y9jbybCLcQJ5gCC0pKkKgPyYLNhgoCxOJVFKMVeb2Xf/JLq+nrZPbC4V1m5SfLCO77f5t9F19LtYWh/C34geI7T7VpXhe9eDYkiy3G23WRXBKshlKhwQM5XPUeorV/4UX8VP8AoVv/ACetv/jlLpMniL4vfEvT9G8Q+JLgyXHmbJnjDpBtiLHZEpVVz5ag4xk8nJr0n/hmL/qd/wDym/8A26vAx+cywNRU8VXhCTV7eznLTb4lJX2fReh9DgMkjj6bqYTDzqRTtf2kIa6P4XF23XV+p5r/AMKL+Kn/AEK3/k9bf/HKP+FF/FT/AKFb/wAnrb/45XpX/DMX/U7/APlN/wDt1H/DMX/U7/8AlN/+3Vw/600P+gyH/gmp/wDJnd/qnX/6A5/+Dqf/AMgea/8ACi/ip/0K3/k9bf8Axyj/AIUX8VP+hW/8nrb/AOOV6V/wzF/1O/8A5Tf/ALdR/wAMxf8AU7/+U3/7dR/rTQ/6DIf+Can/AMmH+qdf/oDn/wCDqf8A8gea/wDCi/ip/wBCt/5PW3/xyj/hRfxU/wChW/8AJ62/+OV6V/wzF/1O/wD5Tf8A7dR/wzF/1O//AJTf/t1H+tND/oMh/wCCan/yYf6p1/8AoDn/AODqf/yB5r/wov4qf9Ct/wCT1t/8co/4UX8VP+hW/wDJ62/+OV6V/wAMxf8AU7/+U3/7dR/wzF/1O/8A5Tf/ALdR/rTQ/wCgyH/gmp/8mH+qdf8A6A5/+Dqf/wAgea/8KL+Kn/Qrf+T1t/8AHKP+FF/FT/oVv/J62/8Ajlelf8Mxf9Tv/wCU3/7dR/wzF/1O/wD5Tf8A7dR/rTQ/6DIf+Can/wAmH+qdf/oDn/4Op/8AyB5r/wAKL+Kn/Qrf+T1t/wDHKP8AhRfxU/6Fb/yetv8A45XpX/DMX/U7/wDlN/8At1H/AAzF/wBTv/5Tf/t1H+tND/oMh/4Jqf8AyYf6p1/+gOf/AIOp/wDyB5r/AMKL+Kn/AEK3/k9bf/HKP+FF/FT/AKFb/wAnrb/45XpX/DMX/U7/APlN/wDt1H/DMX/U7/8AlN/+3Uf600P+gyH/AIJqf/Jh/qnX/wCgOf8A4Op//IHmv/Ci/ip/0K3/AJPW3/xyj/hRfxU/6Fb/AMnrb/45XpX/AAzF/wBTv/5Tf/t1H/DMX/U7/wDlN/8At1H+tND/AKDIf+Can/yYf6p1/wDoDn/4Op//ACB5r/wov4qf9Ct/5PW3/wAco/4UX8VP+hW/8nrb/wCOV6V/wzF/1O//AJTf/t1H/DMX/U7/APlN/wDt1H+tND/oMh/4Jqf/ACYf6p1/+gOf/g6n/wDIHmv/AAov4qf9Ct/5PW3/AMco/wCFF/FT/oVv/J62/wDjlelf8Mxf9Tv/AOU3/wC3Uf8ADMX/AFO//lN/+3Uf600P+gyH/gmp/wDJh/qnX/6A5/8Ag6n/APIHmv8Awov4qf8AQrf+T1t/8co/4UX8VP8AoVv/ACetv/jlelf8Mxf9Tv8A+U3/AO3Uf8Mxf9Tv/wCU3/7dR/rTQ/6DIf8Agmp/8mH+qdf/AKA5/wDg6n/8gea/8KL+Kn/Qrf8Ak9bf/HKP+FF/FT/oVv8Ayetv/jlelf8ADMX/AFO//lN/+3Uf8Mxf9Tv/AOU3/wC3Uf600P8AoMh/4Jqf/Jh/qnX/AOgOf/g6n/8AIHmv/Ci/ip/0K3/k9bf/AByj/hRfxU/6Fb/yetv/AI5XpX/DMX/U7/8AlN/+3Uf8Mxf9Tv8A+U3/AO3Uf600P+gyH/gmp/8AJh/qnX/6A5/+Dqf/AMgea/8ACi/ip/0K3/k9bf8Axyj/AIUX8VP+hW/8nrb/AOOV6V/wzF/1O/8A5Tf/ALdR/wAMxf8AU7/+U3/7dR/rTQ/6DIf+Can/AMmH+qdf/oDn/wCDqf8A8gea/wDCi/ip/wBCt/5PW3/xyj/hRfxU/wChW/8AJ62/+OV6V/wzF/1O/wD5Tf8A7dR/wzF/1O//AJTf/t1H+tND/oMh/wCCan/yYf6p1/8AoDn/AODqf/yB5r/wov4qf9Ct/wCT1t/8co/4UX8VP+hW/wDJ62/+OV6V/wAMxf8AU7/+U3/7dR/wzF/1O/8A5Tf/ALdR/rTQ/wCgyH/gmp/8mH+qdf8A6A5/+Dqf/wAgea/8KL+Kn/Qrf+T1t/8AHKP+FF/FT/oVv/J62/8Ajlelf8Mxf9Tv/wCU3/7dR/wzF/1O/wD5Tf8A7dR/rTQ/6DIf+Can/wAmH+qdf/oDn/4Op/8AyB5r/wAKL+Kn/Qrf+T1t/wDHKP8AhRfxU/6Fb/yetv8A45XpX/DMX/U7/wDlN/8At1H/AAzF/wBTv/5Tf/t1H+tND/oMh/4Jqf8AyYf6p1/+gOf/AIOp/wDyB5r/AMKL+Kn/AEK3/k9bf/HKP+FF/FT/AKFb/wAnrb/45XpX/DMX/U7/APlN/wDt1H/DMX/U7/8AlN/+3Uf600P+gyH/AIJqf/Jh/qnX/wCgOf8A4Op//IHmv/Ci/ip/0K3/AJPW3/xyj/hRfxU/6Fb/AMnrb/45XpX/AAzF/wBTv/5Tf/t1H/DMX/U7/wDlN/8At1H+tND/AKDIf+Can/yYf6p1/wDoDn/4Op//ACB5r/wov4qf9Ct/5PW3/wAco/4UX8VP+hW/8nrb/wCOV6V/wzF/1O//AJTf/t1H/DMX/U7/APlN/wDt1H+tND/oMh/4Jqf/ACYf6p1/+gOf/g6n/wDIHmv/AAov4qf9Ct/5PW3/AMco/wCFF/FT/oVv/J62/wDjlelf8Mxf9Tv/AOU3/wC3Uf8ADMX/AFO//lN/+3Uf600P+gyH/gmp/wDJh/qnX/6A5/8Ag6n/APIHmv8Awov4qf8AQrf+T1t/8co/4UX8VP8AoVv/ACetv/jlelf8Mxf9Tv8A+U3/AO3Uf8Mxf9Tv/wCU3/7dR/rTQ/6DIf8Agmp/8mH+qdf/AKA5/wDg6n/8gea/8KL+Kn/Qrf8Ak9bf/HKP+FF/FT/oVv8Ayetv/jlelf8ADMX/AFO//lN/+3Uf8Mxf9Tv/AOU3/wC3Uf600P8AoMh/4Jqf/Jh/qnX/AOgOf/g6n/8AIHkGufC34geHLT7Vqvhe9SDY8jS2+24WNUALM5iLBAAc5bHQ+hrkK9V8T6f4i+CXjmGx8PeK7h5Li0S6eRIRGj5aRArxMzq+MMQT0LcYIzVa/sE+K0eoa5oelR2niy2Rrq/0yyjbyb+LcAZ4QSSsoLAMhPz5DLliwPu4bMKns416rjKlLaaTjb1i7tLzu/NJang4nLaftJUKSlGrHeDalf0lGyb8rLybeh5nRRRXsniHX/C3Q4PEfxg0HSroxmBrnzpEliEiyLEplKMp4IYJtOf73Q9KqeK/EV14s8Z6j4hvF2SXkpcR5B8tAAqJkAZ2qFXOMnGTya6D4F/8l+0D/t4/9Jpa4evOpJSzCo39mEbeXNKd/v5Y/cenUbjl1NL7U538+WMLfdzS+8sWN/faZfx32m3txZ3Uedk9vIY3XIIOGUgjIJH41sf8J545/wChz8Q/+DGb/wCKrn6K76mHpVHecE35pM4KeIq0lanNpeTaOg/4Tzxz/wBDn4h/8GM3/wAVR/wnnjn/AKHPxD/4MZv/AIqufoqPqWH/AOfcfuRp9exP/PyX3s6D/hPPHP8A0OfiH/wYzf8AxVH/AAnnjn/oc/EP/gxm/wDiq5+ij6lh/wDn3H7kH17E/wDPyX3s6D/hPPHP/Q5+If8AwYzf/FUf8J545/6HPxD/AODGb/4qufoo+pYf/n3H7kH17E/8/JfezoP+E88c/wDQ5+If/BjN/wDFUf8ACeeOf+hz8Q/+DGb/AOKrn6KPqWH/AOfcfuQfXsT/AM/JfezoP+E88c/9Dn4h/wDBjN/8VR/wnnjn/oc/EP8A4MZv/iq5+ij6lh/+fcfuQfXsT/z8l97Og/4Tzxz/ANDn4h/8GM3/AMVR/wAJ545/6HPxD/4MZv8A4qufoo+pYf8A59x+5B9exP8Az8l97Og/4Tzxz/0OfiH/AMGM3/xVH/CeeOf+hz8Q/wDgxm/+Krn6KPqWH/59x+5B9exP/PyX3s6D/hPPHP8A0OfiH/wYzf8AxVH/AAnnjn/oc/EP/gxm/wDiq5+ij6lh/wDn3H7kH17E/wDPyX3s6D/hPPHP/Q5+If8AwYzf/FUf8J545/6HPxD/AODGb/4qufoo+pYf/n3H7kH17E/8/JfezoP+E88c/wDQ5+If/BjN/wDFUf8ACeeOf+hz8Q/+DGb/AOKrn6KPqWH/AOfcfuQfXsT/AM/JfezoP+E88c/9Dn4h/wDBjN/8VR/wnnjn/oc/EP8A4MZv/iq5+ij6lh/+fcfuQfXsT/z8l97Og/4Tzxz/ANDn4h/8GM3/AMVR/wAJ545/6HPxD/4MZv8A4qufoo+pYf8A59x+5B9exP8Az8l97Og/4Tzxz/0OfiH/AMGM3/xVH/CeeOf+hz8Q/wDgxm/+Krn6KPqWH/59x+5B9exP/PyX3s6D/hPPHP8A0OfiH/wYzf8AxVH/AAnnjn/oc/EP/gxm/wDiq5+ij6lh/wDn3H7kH17E/wDPyX3s6D/hPPHP/Q5+If8AwYzf/FUf8J545/6HPxD/AODGb/4qufoo+pYf/n3H7kH17E/8/JfezoP+E88c/wDQ5+If/BjN/wDFUf8ACeeOf+hz8Q/+DGb/AOKrn6KPqWH/AOfcfuQfXsT/AM/JfezoP+E88c/9Dn4h/wDBjN/8VR/wnnjn/oc/EP8A4MZv/iq5+ij6lh/+fcfuQfXsT/z8l97Og/4Tzxz/ANDn4h/8GM3/AMVR/wAJ545/6HPxD/4MZv8A4qufoo+pYf8A59x+5B9exP8Az8l97Og/4Tzxz/0OfiH/AMGM3/xVH/CeeOf+hz8Q/wDgxm/+Krn6KPqWH/59x+5B9exP/PyX3s6D/hPPHP8A0OfiH/wYzf8AxVH/AAnnjn/oc/EP/gxm/wDiq5+ij6lh/wDn3H7kH17E/wDPyX3s6D/hPPHP/Q5+If8AwYzf/FUf8J545/6HPxD/AODGb/4qufoo+pYf/n3H7kH17E/8/JfezoP+E88c/wDQ5+If/BjN/wDFUf8ACeeOf+hz8Q/+DGb/AOKrn6KPqWH/AOfcfuQfXsT/AM/JfezoP+E88c/9Dn4h/wDBjN/8VR/wnnjn/oc/EP8A4MZv/iq5+ij6lh/+fcfuQfXsT/z8l97Og/4Tzxz/ANDn4h/8GM3/AMVR/wAJ545/6HPxD/4MZv8A4qufoo+pYf8A59x+5B9exP8Az8l97Lmpavqus3a3WsaneahOqCNZbuZpWCgk7QWJOMknHuaueFPEV14T8Z6d4hs13yWcocx5A8xCCrpkg43KWXOMjORyKx6K0nQpzpui4+61a3Sz6GUK9SFRVlJ8yd79brqdH8UtDg8OfGDXtKtTGIFufOjSKIRrGsqiUIqjgBQ+0Y/u9B0orV+On/Jftf8A+3f/ANJoqK4cqqSqYKhObu3CLf3I7c3pxp46vCCslOSXomw+Bf8AyX7QP+3j/wBJpa4eu4+Bf/JftA/7eP8A0mlrh6VD/kYVf8FP/wBKqFVv+RdR/wAdT/0mmFFFFeoeWFFFFABRRRQAUVseHfCniLxZftZ+HtIuL6RfvsgASPIJG92wq52tjJGSMDmvRrf4B6lZWsV74y8W6H4dtJUAVpJPMZZSM+W24omcBslXP3eMjkedi82weElyVqiUu27+5Xf4HpYTKMZjI89Cm3Hvsvvdl+J5DRXsp8HfAay/0TUPH2tSXcQCTSQQny3cdWTEDDaTyMM3BHJ60v8Abf7PWM/8IHr/AP3+f/5Jrk/tvm/h4erL/ty3/pTj+B1/2E4/xMRSi/8AHf8A9JUrfP5HjNFezf23+zz/ANCJr/8A3+f/AOSaT+wP2erw/a/+Es8QWHnfvPsfls3kZ58vPkNnbnH3m6dT1p/2218eGqr/ALdv/wCkth/Yd/gxNJ/9v2/9KSPGqK9iPwFOq/8AIm+PvD+ueX/x85bZ5Ofuf6syZzhuuOnGecee+JPA3izwh5beItEuLOOTAWbKyREnOF8xCV3fKx25zgZxiujC5xgsVL2dKoubs9H9zs/wObFZLjcLD2lWm+XutV96uvxOfoqV7eaO3ineMrHLnYx/iwcH9air0zzGmtwooooEFFFFABViwsbrU9VtdNsYvNurqVIIY9wXc7EKoycAZJHJ4qvXS+BP+Rvk/wCwZqP/AKRTVliKjp0pTW6TZth6aqVYQezaX3svQw+GtKj+zpo8OuTDiW7vJpkiYjvDHG0bKvJGXLFgFOI8lak+3aB/0I2h/wDf+9/+SKzK9e+G/gvw9r3gaxvdR0a0vJ7jW3sp5prySGRIBAH/AHSLIodweQArE5PHcdmGymOIlyJu/wDil+j/ACVjys34jjlVD6xViuW9rKMH0b+1bt1d35s80+3aB/0I2h/9/wC9/wDkij7doH/QjaH/AN/73/5Ir1HwF4I8I6rpNnc6ppUt0G128tH8yWSJ3gjs2lVCFYbTuAPY9unFUPEXw606Lw7oH/CPx+fNrerNHZ3Zdj5ls6oYwy5wCu5g3AOVNb/2D+79om7f4pX6efmeYuOcN9a+qSjZ93CFvtX18uRva9vnbz37doH/AEI2h/8Af+9/+SKPt2gf9CNof/f+9/8Akiu5+JvhLw7pek2mseE4oFs4rmTTrryb5bsO68xykq7bC6hvlOMbegrn4fBHm/CG48df21ar5N2LX7AR87ZIGc5685246AnNZVMmUJuGrsr/ABS2+87sLxXRxGHp4nSKnLlScI35m7JOydr+trGN9u0D/oRtD/7/AN7/APJFH27QP+hG0P8A7/3v/wAkV0XhbRNJk+H3iDxTe6d/a1xp0kEUdiZHSNQ5OZZNhDEDGBgjnrW74X0jwNr+m6leavoNxpMuiD+0bi2t5ZWF5bFf9V87ZQ7yuGH8LdyN1VTyaE+X3mr6/FPz87dGRiuK1h/aN03JU2otqEHq0mlb4n8UVe1rve12cB9u0D/oRtD/AO/97/8AJFH27QP+hG0P/v8A3v8A8kV63ofgzwZrfhDQ5m0Wzhv9YtNRnjhjuLrz2eJ38tYiWMQVVAB8zk4HU5rmb3RfDWn/AAY8P6sbTRk1PUbe7Mkl896ZpGSUophER8oEDH38DOM55q5ZFGMeZy0tf45eXnvqjlpcbU6tT2MaT5ufktyQ39/X/D+7lr5etuK+3aB/0I2h/wDf+9/+SKPt2gf9CNof/f8Avf8A5Ir1PXPA3hq2+G8moxaLDDJH4fstQW6t7qSS4a5kID74i7BYyOd2xQOcHsKVx4Q8Ox/B3/hMl8PyjUXsEX+zPtD7YsyFPt+N+/YccKflyehWnLIVFtNvRX+Ke33k0uOqFSMZKG81Be7T+JpNddtfl1tpfzn7doH/AEI2h/8Af+9/+SKY2laP4kmjsdL0pNJ1aVhHbR280j21wxOFjYSFnR2JwH37chQVUFpBn0V58sDC3uNp9NZP8G7M+pWMk378U1192K/FK6Obrf0TRLaex/tbVjN9h8xoI4rdwkk8ihSwDFWCKodSSQc7gAPvMi+PP+Sq+Jv+wtdf+jmrZk/5FHw1/wBeEn/pXcVhCs50o1ErXSf3nDmvNh5+xi/tON/RN/K9v8tdQ8zQP+hO0j/v/d//AB+jzNA/6E7SP+/93/8AH6qV7D8KvhRovjDwvPrmt3d1tMzQRQ2zhduAMsxIPPPA9u+az55dz57HYmjgaXtq05W/xS/zPKfM0D/oTtI/7/3f/wAfo8zQP+hO0j/v/d//AB+urvvBFppvxwj8E3Ook2jXcUX2jgNscKwHoGwwH1q9qnh/RLjwt4kvotDbRZtG1CK1h/eyN9qV3ZSjByfnUANlcDB6Uc8u5DxlH3LSk1JJp80tpOy+1ff7upw3maB/0J2kf9/7v/4/R5mgf9CdpH/f+7/+P17D4m+HnhK1Pii/0iyIttOtfK8hp3JtbkMh3ctllZHyM5GQ3oKxh4Q8O/8ADSlz4V/s7/iUIJCtt50nGLUuPm3bvvc9f0o55dzmpZrh6sHOLnpFy+J7JJv7W/vL/M838zQP+hO0j/v/AHf/AMfo8zQP+hO0j/v/AHf/AMfr1fwr4C8L674Z8IO1of7TunkuLtDM4F3bpOY3A+b5WUFD8uMgNWTa6F4ZtPh3eaxd2ekC5TXJrFJNUkvCnlLGGCKLc53Zzy3vz0o55dylmdFycFztp2+KXdr+byf9XPPvM0D/AKE7SP8Av/d//H6PM0D/AKE7SP8Av/d//H6qUUc8u563sv70v/Apf5lst4ekUxv4S0+NW4LwXFysij1UtKyhvQlWGeoPSue13Rk04QX1k7yafdM6wmQjzI3XaXjfGMld6fMBhgwPB3KutUuo/wDJNL//ALCdp/6KuaunN3sy6cpUZRababSabb3durdrb/gcZRRRXSe0dx8dP+S/a/8A9u//AKTRUUfHT/kv2v8A/bv/AOk0VFeTk3/Ivw/+CP8A6Sj1c7/5GOI/xz/9KYfAv/kv2gf9vH/pNLXD13HwL/5L9oH/AG8f+k0tcPVUP+RhV/wU/wD0qoKt/wAi6j/jqf8ApNMKKKK9Q8sKKK7n4c/Dm68bahLe3s/9neHrHL32ouQoUAbiiFuN2OSTwo5PYNz4rFUsJSdas7RX9ff2R04TCVcXVVGiryf9fJLqzmvD/hzW/FWtLpOgafJe3ZRpNiEKFUdWZmICjoMkjkgdSK9gh8E/C/4ZeXcePNW/4SHW02v/AGTaLuSNv3bYZMjOMkgyFVdSfkJFZeufE6w0Dw3D4P8AhWlxpunRbxc6lKgFxducqXB6rkYbf8rD5QAgXB8rryfq+MzL3qsnRpfyr45f4n9leS111Z7KrYLLNKUVWq/zP4I/4V9p+b000R6b4g+N/irUIVsPD0Vv4c0xIvIjt7NVZ1TaFxvKjbjB27AmM98A1wkQ1TxN4ljW6vZru9unVGuLqUux4AyzMc4Cj8AKza9F0jwnqxvNM0Dwzpzal4j1E+SIrc738xifk7BQgUlieBgknAr08Ll+FwMLYemo+fV+r3fzZ52IzDEY6opYqo5Lt0Xotl8kc341eybxxeNYANagqkZHGVVQo/RRXrfw20eK6sIv+Eu/Z3TUvD0ow2rWz3dncqpH342km2S/QAZ7GvX/AAf8C/DHw0S31nxBv8TeL5U3xWtpjyLfb1MbMM4X+KdsD+6PXopdQ1zxVqUujnT/ALNfMiO0Ud1I22N87fNL9mCkjODgA4wRXTHZIyrv21WVVKybvY+V/GHwgvP+Fi31p8Pre41LQWKy2k9zIiMquMhCWIyR646Yzg1jaj8GPiXplobqfwpdyQgZLW7LNj8FJP6V9f8AhzwvdaC7Xep6LOLLcVlvLKXfJbEHB82MgkqMD7vQc4Ir0WbQtTitRcacqavasobyAUSZlPIMTjCPx0DYz/equexk6aPzHH23TdSVwZ7O7t3DKRmOSJwcgjoVIOK9U+H3xL+I8ep21vLdnU9JRgs8mpKSsalwSTOBv3YyFyW64CnAx0HxY8S6Jr/xMuW/sqJLLSXeAG4tvIuJ3X7xkDDcmCCNpHA5wCePNJfEst+GSa9NhZKeAgLyN/uLnA4HU/nXFjcHh8bDkrU1L1X5dV8j0sqxNTCVlOFVwXk7X9en3nd3XhzwD8QNduNKOuQ+HNThZYdOgjiRIHQsuRswqsxZmwqsDkk4IFeT+LfBXiLwTqq2Ov2Pk+buME8bB4p1U4LKw/A4OGAZcgZFU725+2X0k4QIrHCoDnao4A/KvQfB/wAU2stFk8J+OLWTXfDEtv5At9qmWADJXYxIJGcAZbK4UqRtweGpQxuCftcO/aQ6we6/wP8A9te/RpnbWxeBzKo41o+yl0mtn2U16acy26po8qor0bx/8NIdB0e18WeEb6TWfCt0ilbo4aS3Y8YkwBwW4zgYb5GAON3nNejg8ZSxdP2tF6bdmmt010a7Hh4zBVcHV9lWVnv3TT2afVPuFFFFdRyhWt4a1WHRvE9ve3SSPalZLe5EQBfyZY2ikKZIG/Y7Fc8bsZyOKyaKipBVIuEtnoXTqOnNTjunc7C+0y6sI4Z3US2dxk215ECYbhRjJRiBnGQCDhlPDAEEBIdV1O3tIrWDUruKCGcXUcSTMqpKBgSKAcB8AfMOawNL17XNE83+xdZ1DTvOx5v2O5eHfjON20jOMnGfU1of8J545/6HPxD/AODGb/4qhYjEw0ST87tfhZ/n92xU6GFq/E2vKydvndfl5a7mwniXxFG7PHr+qIzTPcFlupATK67Wfr94qSCepBxTLfX9etIrSK11vUYI7Nme2SK5dRAzZ3FAD8pOTkjrk1lf8J545/6HPxD/AODGb/4qj/hPPHP/AEOfiH/wYzf/ABVV9cxf8q/8Cf8A8iY/2fgLW/8AbI+f97zf3suJfXseny2Ed5cLazMHlgWQhJGHQsucEjJwTVeo/wDhPPHP/Q5+If8AwYzf/FUf8J545/6HPxD/AODGb/4qpeJxL+wv/An/APImyw+Fje0nr/dX/wAkXtP1PUtJu/tWl6hdWM+MebbStE2PTKkGntrOrtPdzNqt6ZLxdl05nYmdfRzn5hwODnpWd/wnnjn/AKHPxD/4MZv/AIqj/hPPHP8A0OfiH/wYzf8AxVNYvFJW5F/4E/8A5EiWDwUpc7bv35F/8kbMPifxJbaONJt/EOqw2AUqLSO7kWLBJJGwHGCSc8dzRB4n8S22jnSLbxDqsOnlGjNpHdyLFtbO5dgOMHJyMc5NY3/CeeOf+hz8Q/8Agxm/+Ko/4Tzxz/0OfiH/AMGM3/xVV9dxf8q/8Cf/AMiZvLcvd7rd3+CO/f4t/M1BruuCTzBrOoB/s32Ld9ofPkdPK6/c/wBnp7UHXtcN09ydZ1AzPB9leU3D7mhxjyyc5KY429Ky/wDhPPHP/Q5+If8AwYzf/FUf8J545/6HPxD/AODGb/4ql9bxX8q/8Cf/AMiV9QwP9QX/AMkSVpadpyNEurass8GiQyhbi6QY3YwTFESMNMQeF7Z3NhQzDJ/4Tzxz/wBDn4h/8GM3/wAVWXqWr6rrN2t1rGp3moTqgjWW7maVgoJO0FiTjJJx7ms5VcRNcrSj5ptv5aLXz/BnQo4eD5k3LyaSXz1enl+KDV9Sn1nxBfaxdJGk97cSXMixAhQzsWIAJJxk+prqNFlbXdAstLtUaXU7APEltGpLTwFzICg5LOrPJuA/h2EAhXI4uin7OKioLRI4cXSeJ1b9697+ev8Amzrq6Hw3458U+EYp4tA1V7aKc7njKLIpbGNwDAgH3HpXGf8ACa+Mv+ht13/wPl/+Ko/4TXxl/wBDbrv/AIHy/wDxVZ+xfc8urgataPJUhFrs23/7abV7fXmo6lNqF9cyT3UzmSSZzlmY96mvta1nU4oo9S1a+vEi/wBWtxO8gT6Ak4rn/wDhNfGX/Q267/4Hy/8AxVH/AAmvjL/obdd/8D5f/iqPYvuV9Trae5HTbV6f+SnRPrutyNdtJrGoM17gXRa4cm4x08zn5sds5q1L4w8XTFDN4p1qQxsWQvfSnaSpUkZbg4Zh9CR3rk/+E18Zf9Dbrv8A4Hy//FUf8Jr4y/6G3Xf/AAPl/wDiqPYvuQ8BUe9OP3//AGp0EGtaxavaNbatfQtZhhbGOd1MAbO7Zg/LnJzjrmp7LxN4k02F4tO8Q6rZxyOZXS3u5IwznqxAIyTgc+1cx/wmvjL/AKG3Xf8AwPl/+Ko/4TXxl/0Nuu/+B8v/AMVR7F9xywNWW8I/f/8AamkSSck5NFZv/Ca+Mv8Aobdd/wDA+X/4qj/hNfGX/Q267/4Hy/8AxVHsX3NPq+I7R+9//ImrFFLPOkEEbyyyMESNFLMxJwAAOpNReI7pLDQh4eyDePcrc3idfIKKyxx57P8AvJS45x8g4YOozJ/F3iu5tpLa58T6zNDKpSSOS9lZXUjBBBbBBHasarhS5XdmlLCTclKray1stdfN2W3a29tegUUUVqekdx8dP+S/a/8A9u//AKTRUUfHT/kv2v8A/bv/AOk0VFeTk3/Ivw/+CP8A6Sj1c7/5GOI/xz/9KYfAv/kv2gf9vH/pNLXD13HwL/5L9oH/AG8f+k0tcPVUP+RhV/wU/wD0qoKt/wAi6j/jqf8ApNMKKK1PDnh/UfFXimz0DSVja7u3Kp5r7VUAFmYn0CgnjJ44BOBXo1KkacHObslq32SPOp05VZqnBXbdku7Z0vw5+HN1421CW9vZ/wCzvD1jl77UXIUKANxRC3G7HJJ4UcnsG2PiF8QrXVdPh8HeDoP7O8KWOEjiQFTdkHO9887c/MAeSfmb5sBb/wATtc0fQNJX4V+D7fydOsJVkv7oS7nu5wOQ5U4bBxuyOGUABQgz5XXi4HDyzCpHH4le6tacX0XST/vPp/KvM97HV45dTlgMM/eelSS6vrFf3V1/mfkFFFTWtpdX15HaWVvLcXErBI4YkLu5PQADkmvoT54jjIEqk4xkda/Sr9nH4Lnwl8NZ/HWrxCfxH4ld5EkK4+yWLsXRFB5Uyja7d8FVP3Tn5j+DX7PU6eKbDxF8W7QaXpkT+db6BdELd6iVw37yL70UA6uzAFh8qj5sj7j8YeN59N+Gt5JaTAXNy0en2uBjbNPIsIYe43s3/Aawqu+xvRhKUlFdR9roOmy3TbYxPLeJ500pGd8auFUf7mTwOnBPc15d8ENviPXPiDrd0u68k18ks3JEflbUH0ABFeh+FvGmkt8XvFenWxje30y203TIIyeEA84n8d20fgK858DeJbbwF+1Lrngi9s4ILLV4zJYysuFuDlpYi3qdrSJkfxJisZNpo9PCQjOjWiviSTXomr/hr8j11LCKLVorXZtkuFZ1x/EUAz+OCD9BVTTRYaT44HhN2EEV0N1ujrjypCC5jA/uOod0x3SRewFcr8TfiNPpWr6Hf6Nb+dPp+tO9xBEpZng+xky7QOvysCB/s1xvxo8bJq/w5h8beGb4L4h0CeO5Cq+S0assm33XhJFPoW9WFVfoc1Gg6jV9E9L+f9fmYn7ZHwbstW8KyfEjwpDjU9OCrrSRrj7Xbr8v2j3aPjce6dfuCvFbT4M319+ztHJLparPdA3drdcBxcAfIp77HUCP03EHtX2nceKYNe8AxazpttFdQX9kt0tq/KzRyIGaI/VWK/WvNdC1HRo/Bp0bT7g3Vixb7CxPMidfJb+7MmMFTjdjcM5ONKbs7nO49GfnIwKsQQQR2NJXqXxp+H8/hrxlc+INLiabw/qUzTQ3CAlYJGOWhf8AukHOAcZHuDjy2tznasdt8PfiFc+DL6WyvYP7R8P3uUvtOkAYMCNpdA3G7HBB4YcHsVsfEf4cW2jWMXjLwbP/AGj4TvcPHIhLGzJONj5525+UE8g/K3zYLcDXoPwx8Xadpdzc+EfFFpHeeHNbZIrhJpNq275wJeSAo6bm4YbVYHKAHwcwwk8NUePwi977cV9tL/25LZ9dme7l+Kp4qmsvxb937En9iT/9tb3XTdHmVFdT8QfBt14G8c3OizfNbtmezlLhzJAzEIWwBhvlIIwOQccYJ5avUw9eGIpRrUneMldHj4jD1MPVlRqq0ouzCiiitjEKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA7j46f8l+1/wD7d/8A0mioo+On/Jftf/7d/wD0miorycm/5F+H/wAEf/SUernf/IxxH+Of/pTD4F/8l+0D/t4/9Jpa4eu4+Bf/ACX7QP8At4/9Jpa4eqof8jCr/gp/+lVBVv8AkXUf8dT/ANJphXungmH/AIVl8B9R8eXEXl63rWLbTd6fNGhzsYbkOM4eXByrqkfc15H4U8O3Xizxnp3h6zbZJeShDJgHy0ALO+CRnaoZsZycYHJr0H43+II9Q8fp4esFt49M0OIWsEVuVKK5VS+NoG3GFj2ZOPL7ZIrkzWP13EUsuXwv35/4YvRf9vS09Eztyh/UsPVzF/Evch/iktX/ANux19WjzKiiivoz54KUEhgR17UlFAH0v8HVtfCfhzRpbmM3HiDxSZdQYycmDTLQOy5J5HmTRE477EPavafiX4lGk+EfDbeaxjtdetjMOpzEkjn8crmvm7wHrLa18QdT1iJnaz0nwrHp8BI4jCwxRbfxPmn6kmvTPiPrVpqGiaokkmYdP1231JtgLFoGcJJgDk/ePTsw9a56jsrnp4Cnzy9P87fqdhPpXjbwZ4J03x/PZ2scOsB5LsJI7zJIZftELP8ALtB+UoACeuCcmjx7faV8QvC9rqfnPa6lp8iXFlf25xLEjspyD3AyDj1XNcBf3/xd8Zadol3P491KG+162bUNO8Ji2SSxXTg8nymRgAzRiIff+Yl1CkFc16n4O+FGueJfgtonirSbq3ujfWhM2myZgccsjBGPCsGDDB4PByCSK44V1BctRq/+Z3SoT0xEdNbL5afpb5M53wLPaax8QtS8TfFu8spNG0pXuLmV5DHau5RIEYrkBS2xyQTzjA64rjPGOo/DC88RSH4K+M7PUGvmNt/YAWYSENnMSK64kj+8Vwcpk9QePZ/G/wANYk+ANpr7+BoLjVdAuYpbrRNZVmtb1sxwNcSbHBZFiAI5+XMnua8rsvgDFda1f2YtWe1k0J54Gu1SC7h1DZH5BjYMSqCfIUjoGcHIxWSq3nzN/wCWnc7aGFm6Tr0rcsdHfr/V1/SO2+HWv3Gm/AbwTbzs63EU8NkUfhgBcPEQQfRT+lY1rp2i/wDCwvE9jNplldQTut/Cz5UgSjPO0jcm8MDnOCQa5vS9RnPjfwt4OGqXGpNp8zahqF9PIXaYo7SM5J7HKfi3rXFa14vu9M+J9nqFrMCYJ7jTpUb7rxMyyKD7AS/pXoUpXVzixeEtOMY/E7v/AC/D8zsvGq6rc6Hcaz4GuUt5Y1aG80OaFZoZ9vJRomBG7g4P8WB3Ir5W1C9OoajJdtbW1uXOfLtohFGPoo4FfQd34lmsvGml6xbuYoNSuvskqZ4L8Oh/BuPofavEfHFtaWfxL1+1sNv2aPUJ1jC9FXeeB9On4V1W0PEqqzMCiiikYntNjD/wtL9nGXS1i83xD4XwbfamXlhCnag2pn5kVkCKclokLHmvCq774WeJ38K/E/TrxpI0tblxZ3ZkdUURSMAWLEHaFYK/b7uMgE1W+K/hZ/CfxT1KyWONLS6c3toIkVFEUjEhQoJ2hWDJ2+5nABFfOYKP1HHVMH9ifvw8tffX36pdmfQ49/XsDTxv24e5Pz09yX3aN90cVWhoVtDeeKdNs7lN8M11FHIuSNylwCMjnoaz60vDssUHjDSpppEjjS8hZ3c4VQHBJJPQV7588fdvxI/Y8+G2l/GqLxE8cXgv4S6No0V5rE730sr3Vz50wMSNK7uuUEQOPVQoLNx8ta3pfw8+KfxzbQ/hfaeG/hr4bEcgtrvxNq88cUwQE+ZNLK0mx26Ki8Dgcnmvs74vftLfCyX40w/DLxVd6B4v+GHiDRIVvb7TLiO7Gn3ZnmBcvET0VYiQDuTCuvofEPAPw0/Z9+Hv7Wr2fjbx54Q8X+B7uxll0S8OpwXEMVxvTEd6sbEIwQyYLgRtwevyrlFu2pbseWeMv2aPGvhT4aXfj/TfEngzxl4espBHeXvhTVfty2pJAy+UXjLLnGcZBOBzS+H/ANmL4j6/8I7X4hvd+G9G0/UG26Xa6zqS2lzqbHO1YFYbSzYO0Myluo4INfU194++Hdp+y98W/CkviD4K6dq0thKtrZeBQtpDd7om8sAuwNzMMcmNcLkDJJIHn3jnVPh18d/2UfhhFD8U/DvhHUfBtotlqelapIyzuFiiiZreFAWmb9yCiqMHzMFlINNSYrI8Q+IP7OHxG+HnxH8N+BLtNO1nXfEUIlsbXSJJHPLFdrmRE2kYJJ6AAkkYNdFrH7H3xS0vSNUms9W8H65q2kwfadQ8PaPqwn1G0TGcvDsHOOgBJPbNfTH7QHxE0L4X/t4/Cbxb4iEx06z0WaO6bbvlgjm86ESlRknaWJOMkgMBk1Y1D4p6V4c+IuseOvCHjv8AZl07S75pJP7Uj0+eTXZonYOVnjhlV5HLBSeRuIBwOgXM9B2R5L4G/Zn8CeJP2Eb/AMYXfiDwTbeLbm5iltfEl7r00NnpcTPb5trrH7uObDSKVKMd0iDPQj5M8QaR/wAI/wCKtR0P+1NN1T7FcPb/AG7TJ/PtrjaSN8UmBvQ4yDgZFfV3wk13wf47/YM8d/CS98e+EvCPiXUtcF/Amv3osbYx+bbS5V2zx+5kXA3EYGRg5r5N1rTf7G8Saho/2+x1D7FcyW32ywl823uNjlfMifA3I2Mq2BkEGqje7uSz6f8A2bPgZ4P8ZfADxj8S/EfgbWPGup6XO0Wn+H4buWwiu1VFZikyDLvlnG0E42gYJYV4d4x0XTvEF7qPiv4ZfD7xRpfhWyjQX63Ie9i06YnBVrgKAFPy434bJPtX1l4P+JWkeI/2evhbD8N/jF4W+HniTwUdmpaN4luzZWuofJtkZuMShvnYAA/61uVYA1f/AGk/Gvwy1r9mTxPZ/B/xZ4EW71fWYr3xPZ22opDcXzIqFmt43KmUb0iYlBhsORli1SpO47aHw/4O1Tw5ovjax1Pxd4V/4SjRoS/2nR/t0ll9pBRgo86MFkwxVuBztx0NfYNt4Z/ZruP2Nbz49f8ADPm37Nei0/sX/hLL87szpDu8/PH3842dsZ718Q19Zaf4v8Jp/wAEndV8IP4o0ZfEL6ssiaOb2IXbL9tibcId28jaCc46AmqkhI5h/wBnfWPiZbw/ETwxo/hP4T+ENXaOHR9O8T+I5GNy+0KfKkkQu+9gzAMB14yMGuV0j9mn4man+0HJ8G7yHTdH8RJbPeLJqEzi2lhUZDpJGjlge2B1BBwQRX1Fo/xa8C/EX9m3wHpel6h8FIdd8O2Een32mfFO0LRxeXEkZe1fIA3eWDgBsgqCVK4NPwv8ZNL1f9vvw9r3jb4hfD2eDTvDU9lNrGj+ZY6ekjO7CHzbmU+YRkEMCAd+AMg1PMx2R498OvgHdeC/2jfAtl4+1PwPqputfFhd+F1vo727VNkjCSe2K4WJggI38/MoKgnAv/FH9nTWvFX7QHxP1jwzD4a8GeCPDtwvmahqObGwiPkxkxRLFG2W+bO1V6kDqwB474deItHt/wDgoPaeKNT12xh0s+K7m6k1S4uUWDy2lkIkMpO3acg7s45r6U+MPxB+F37Q2neL/hTdfELRPC+o+H737doWrvqqR6TrClAcSSbvLZgzsp5JB+Zc/OtNtphpY+ZPCP7Lnj7xX4Ls/Ftxr3hDwzo2ozeTpd14j1I2X9pHJCmBShY7sfKGCkjkDFJ4L+FnivwJ+2T4Z+H/AIy8IaTf6l9uT/iV6tKPsN9GyttJkEcoMZwedjcgggEED6etPih4J8b/ALP3grw9Yan8DU8Q+FrRdL1DTviZEJ4IzFGkRks5kbYyt5W7KbgwK8grzwdz8Qb34g/8FEvhZcX/AIk8IeIbmw8q2kvfCtrPDaq2+ZjEGmdzJtyDvXC/PjGQaOZhZHCeKvgF4q+JX7SvxO03wzp3g7wp/wAI2qXl1pdvcSfZIkMQOy3ZLZd33SeY0GT+NeZ+G/gr4p8UfAHxJ8XrC/0ePRPD9x9mureeWQXLtiM5jURlSP3y9WHQ/j9c+HfHvgzwt+318btA8Y+IrPQYPENotnb6heuEgSRYkBVnPCnDkjJA+UjOSM8hpTfDz4e/8E+/ih8O4vit4R1/xDc3/neVp18u2Yk2wC24fa84Cpkuq7c7gCdpNCkwsh/iP9lPwJ/wyF4O1jTPGHw60fxVc3o+3eK9Q8RzJpt9GROfJhdsxmQYjyFRT+6fng5+LpY/KneLej7GK7kOVbB6g+lfYtu/g74u/wDBO7wR8N7H4oeCPDPiLQNVe6u7XxPqYsQVDXQAXIJbInRgQCOoJBFfG9OF9biYUUUVYgooooAKKKKACiiigDuPjp/yX7X/APt3/wDSaKij46f8l+1//t3/APSaKivJyb/kX4f/AAR/9JR6ud/8jHEf45/+lMPgX/yX7QP+3j/0mlrh67j4F/8AJftA/wC3j/0mlrh6qh/yMKv+Cn/6VUFW/wCRdR/x1P8A0mmevfAO3gstb8Q+Mr2GOa00TTHdlChplZstujB4B2RSrnI+9joTjzW+vbrUtUudRvZfNubmVp5pNoXc7EsxwMAZJPSvUPCH+ifsjeML61/cXUuoJBJPF8rvHm3GwsOSuJHGOnzt6mvJ6xytKrjMViHupKC9IxT/ABcmdWaN0sFhMOtnFzfrKTX4KKQUUUV7x4IUUUUAe6fCeK2svg1eXxZVn1bxJa6MX7ovkvIo+jEsPwrQ8RafqdpoK+ICxktJrco0XQvGcxlfYhVXB77R0IBrxLTvEGr2WhXGh2Uzi3urmC72Lncs8W4RuuOjASOPx9hXv/hLxba+M9Mi8N+IJIIL/UIJrRY1AVUvEkaREAzx5sc8oA/vxbe4FZTStZnfhMR7KcZLp+XU94+Gklp8QvhN4Tu7vQbiC406NgLmayXy7olyJSjElWR3UuV4KSbuMHn2a68R+EPh54d0qz17XItLhl3R2sUys8lwwO5goVSSRuyQB0x2FfFXwj/aEufglrWoeCfFelnU9DjujMIlcRz2RfG54i3DISMlDjB5BGTn6TvvjZ+z78S9ItNP1HxpZaTdwyJe2qaxEbWWB9pww3jYwKsQQGIIP0NeFWpTUn1R9HVxEXy0Zu0E+mu76HoNh8R/DHivXIfD2i/brlruCYieW0aKEhFBKnfgncpPbBwwrkfGfhLxNaeHbxPCdtp1tdXCNE9/NiJbKLBzIAq5YgE7RwAeSexoRfEj4N+CtXjvf+FgWmv6q8ZitNP0c/bJWLYzsji3fMQAMsQAM+prxn9on4/+OphYeFNGsh4f03VoGkllEokuzGGwyuw+WPjk7Sev3qxp05SaWxvBqlNrDO8HbVo858JzLoPhTVb5pxNqWr3P9n2c2MMYgcDHoOQT74rzXVr77b48uDkGJ712jIP3wuFz+SCp4dTvp7qKVJfLjtoGS1G04iLAhXxwMDLMOcsdvauZhtY0a7kluppJrWFpIrgYXaVIAHfIJOMe9e7T2UThxFaFPETq3v8AP+unyubXjXxas2vadb6Q4MWkyGYSdVkuCwZmHqF2qo9dpPeuHllknneaZ2eR2LMzHJYk5JNaWjapNZ6+LgRwypMSk0MiBo5EbqpBzx39RjipdX0y2WEahpQLWv3ZUDbvJfPTnnaeME9+D2rq5m5WZ8zNJx5k9b7fqYtFFFMyCvW/i1K/ir4QeCvHhWMzlXsLyaSNUmmlx1+UY2boZiBkY3jAGTjySvWtM/0z9jbxD9r/AH/2PVU+y+b83kZeDOzP3f8AWSdMffb1NeDnSVOphsSt4zUflP3X+j+R72St1KWKwz2lTcvnD3l+q+Z4zRRUlvbz3d3Fa2sEk88ziOOKJSzOxOAqgckknAAr2jwSOiro0jVi96g0u9LWGTdgQNm2w20+Zx8mDxzjniqVABXr/gH9onxN8P8Awtpuh2/gzwFrq6Uztp17rmiLcXVkWkaU+XMrK333ZhnOM+mK8gqzdafd2drZXFzFsivYTcW7bgd6CR4yeDx88bjBweM9CKGrhc3/AIgfELxZ8T/HNz4t8Z6o1/qU6iPdtCJFGv3Y0UcKoyeB3JJySSeXroW8CeNIrqzt7nwrq9o17cR2lu13avbpJK5wiB3AUEn1Nc9RawXuFFFFABRRUrW1wtml20Eot5HaNJip2MyhSyg9CQHUkdtw9RQBFRRVsaVqhd0Gm3e6OAXTjyWysJAYSHjhCGU7umCPWgCpRU81je29pb3VxZ3EUFyGaCWSMqswB2koTwwBBBx3q1qHh/XtJtIrrVNE1Gxgm/1UtzbPEkn+6WAB/CgDOoroX8B+OYnhSTwZ4hRpm2RBtOmBkbaWwvy8narHA7AntVTVfC/ibQrZLjW/DurabDI2xJL20khVmxnALAAnAPFOzFdGTXoXwk+L+t/BvxJd6/4d8PeGtS1KaIRw3Ws2TXD2R5y8DK6lGIYgnnI4rz2ik1cZp+I/EOr+LPFupeJtfvGu9T1G4e6uZ2AG92OTgDgD0A4AwBWZRRQAUUUUAFFFFABRRRQAUUUUAFFFFAHcfHT/AJL9r/8A27/+k0VFHx0/5L9r/wD27/8ApNFRXk5N/wAi/D/4I/8ApKPVzv8A5GOI/wAc/wD0ph8C/wDkv2gf9vH/AKTS1w9dx8C/+S/aB/28f+k0tcPVUP8AkYVf8FP/ANKqCrf8i6j/AI6n/pNM9m1v/kzbwn/2FZP/AEO6ryWvWtb/AOTNvCf/AGFZP/Q7qvJaxyD+HX/6+1P/AEpnTn/8Sh/16p/+koKKKK948IKKK0NEsX1HXLe0jjEju4Cof4j2H0Jx+GaTaSuyoQc5KMVds6LwtoF5d6haWFh5aanfSRxLPK4RLVZGCrljwrNuHJ+6pz1PHd/E74b6H4A8K6Vo8tnfzeLvLN1eX9tqaSWSIsrALCiJlyV2neXzndwCMDrPhbceEtH+KGkaVP4h0qO+R5WZ7mzF8ss5icBTGcKWLHC5PBC98V9BTeH/AAlp2gz6r8YNJtLPTbVX1OBZbUWsauuAGRVYkbjyIyf4sbcYFePWxUnJO2h9esro4aLpSak7a2d9e3yPgrxrYePdX8e2nh7xzo7R+ILaCOSa5uQIZ3tmUOrXBGedjA7iA/zAHJNX5VtNWe5haOK0ntwUgV/lIThURh/EMBRkc8Z9RW/4u8TPq+o6p4sku3vNR1aQ3V5Mx4ZmPyIvcKgCjB/iDe2M3ULE3dtb28pKvIxZ3U4KiNRyP+BSD8q6bu2u7PJo00pO2tk7+a6fjbX/ACPbLax8J/B34O6Fr+jmzudX8QWCXCSSP5kmQNsruDjYqvlNgIBK47Ma8X1jV7rXvFriVptW1Fz0TM2foqgbiPfCjGAAKiXRrm9ubSO5vriWCKRI1RnLBAXzgDsCSxx6k+pr0v4HXWg2ut3FrdWGpXl/4hfCNplwto0MZaTc7TsjABRliNyj5ed3SsoQUG5S1Z2VcRVnRjCn7qbsvP8ArT579LeYyS6vdu1pHpyIA2xpLtwct0PyrxweKyLFHt9UvLPVbWOJWSSOdFHyqNpIcfQgEf8A169J8V+GX8GeJjosmsaTrCywpPa3Wlz+dFJEcjJbA+YFSG464xnIrj/FWnySRvdS3CM5AVkUEYK4yGIHcc4yfuitqdRcya2MJYXnw8pWfOmvS3bX8PmcRZq32gMoy3Rf948D8uv4VuWCXEQke3jEjou2aNhkTJypDflnPY1seHPDy+Z9qkAfHyoMfLnvgf1rW8P6Uw8XapZheIwGx6BsEfzNFXEK7t0O/AZBK1P2q+Ntfg3+h5xqNqltdZgLNBIN8TN1x6H3ByD9Kp16D438LvpsX2iNP3EzF0x/BIB8w+jKM/Va8+rqo1VUipI+ezLAVMBiJUKi1X5BXrfwl/5JV8Tv+wT/AO0bivJK9b+Ev/JKvid/2Cf/AGjcV4/En+4S/wAUP/S4nfw3/wAjCP8Ahn/6RI8Yre8EXEFp8TvDl1dTxwQQ6pbSSSysFVFEqksxPAAAySawaK9k8I9TtPGOiX2kavbSmS2uL6wZtUlkZVF1LGY44xFzlmK+Y5zyWduMDNTaj/wh/wDa1t/a3/CNf2f/AG5F9h/svZn+z8Pv+0eV8+P9R/rP3n368moquYnlPUT/AGJ/amk/2x/win9tbL7/AI8/I+w/6pfsnneV+6z5nmde2zfxmsH4g3Ec/wDwjcQn0mS4g0kx3K6U0Zhjl+13DFQI/lBwwJC8fNkcEVxlFFx2PaNZn09fjrpuvLa+EbbT/wDhJoLg6tZa0s00sfn53yR/aXCLj5ifLXGB0HB5uzOhjxhpMul2WjXWj/ZpBDDd3FrBNG+zDNcG4OxpFYhgGyjAYUDkDzuijmFynrcNlbLB4pudMuPCd/dpf6akN3f2tnDboHguGkjQf6gEbQDtO1thYZbbVbWtQ8DJ4u8OabaW2kf8I68ryX81vAplK/b7jarSYMiqIxHgcMUK5z8teZLc3C2clos8q28jrI8IYhGZQwViOhIDuAe24+pqKjmDlPW72fRW8XaQU8L+Hl2pcgyrrelSRyAoAjMqxxwqUJ3KJVy+SDnHHO+O49Gi0q2Wwv8AS728OpXLTS2VvbwERm2tCqlYPk2q/nKCvylg5HU1w1FDkCRauPP/ALOs/M+y+Vtfy/K8vzMbjnzNvzZz03846cV6X4hvtM8R+GtP0DSNYsNPu4NOsGu/NuEjh1DbbRLhpScK8R3DyycdSBuBDeVUUkxtHtSeIfAbataRprVzcWvh6/tbi1ju7SOKMQR7IJfKIlYysxEc2Nqk7GOOcDjtW0y1s/COq3Gq+IRe6rNcI8MtnrMVzFegtyXgVTIpAy252HUDGa4aim5XEo2PSPiotvdeIdU1Oy03wsLebUHkj1DTdXFzc3CktgvELl9oPUkRrggDjoea8c3Ntd+MBNaXEU8f2CxTfE4Zdy2cKsMjuGBBHYgiucopN3GlYKKKKQwooooAKKKKACiiigAooooAKKKKACiiigDuPjp/yX7X/wDt3/8ASaKij46f8l+1/wD7d/8A0miorycm/wCRfh/8Ef8A0lHq53/yMcR/jn/6Uw+Bf/JftA/7eP8A0mlrh67j4F/8l+0D/t4/9Jpa4eqof8jCr/gp/wDpVQVb/kXUf8dT/wBJpnsugf6Z+xv4h+1/v/serL9l835vIy0Gdmfu/wCsk6Y++3qa8mr1b4Cn+1W8X+Df9V/a2lH/AEv73k7cx/c43f6/PUfdx348tngntbqW2uYZIZ4nMckUilWRgcFSDyCDxiscpapYrFYd78yn8pRX6p/mdWap1cJhMQtuVw+cZP8ARr8iOiiivePBCrdlfz6f5r2rbJnQxiQdUB4OPQkZGfc1UopNJqzKhNwfNHc67w/b2Ufg28vkhSfVJZ/s8IY/6lAgZiB6vnaD6K3rmt/X/i38Q/FnhaLwzq+v39/ZIixmGVR86g9HbGSAQDye3Oa9L+Ef7LXjPxr8P01rU9YsvDdlqBju7LzYHnuJUAYK5QFQiHOQSckc4wQTN4i/Za+KGm+NLDwxp95oeqLqIdxfQyNAIYkxukmRgWVRkDK7skhRya4KlSk52bu1+B6cPa+zXKrK3TqfOqXDIYrZ23KhjP1+bn+QrtbS4WXxAqvNjy4m2gA5+Zvmxx6AV7Zqn7D3jSLTvtWj+NNB1K+UBmtZLeW2VsfwpISw/FgB9K8W8VeGfGHg/XrbR/Emi3Wh6nZRbES4O0zjcT5kbfddcELlCRhRS54VfhZphqk8NK8o72/NP9CxdTPYqjIyq8O2UB9ud2M8eoyBxyK96+G3jL4a+M4ru58aaXo3h7xvJaY0++0//R7e6YoAxjt8+Us/YkDJDcYxx852+oxPKr3g8sKrKYlwOCD93JHGcd6w9WLNp9jh0eSEkqQ3AOMnGOnPOe2KmdDnW50yx9NSvGLsndfh/kfT/wC0RNe2Xgrw5Y65POuvW1xLNDaMlr5Mdo0IyqeT8wQMsYG7GSScV5I08OpeHtLxFerqWnxmSAWtqD9ojEm9Xfcy4KlipPzZBB7HHAjVde1S9K31zcTyzACS5unLyBQOoYkk8EjnjmtvVdTe/vtEspGSM2rERTKduwEjk+4/UZpQhKkktzWg6GKcm5OL0sujvo1fppsc/LreqeH/ABXI1u8i2+8SpaSSb08thuVT6cEDIrqJ/GVnot7qmtaesdxc30dultHJ0QCPczNj0JAx3P0ri/EMv2t4b6Yf6VM0nmncW3AEAHJ5PO4ZPYCsSuuWHhUtJo5KOcYrAuVKnO9ndPezs1dX8n99mek6f4+k8S2U+g+JIrcPOv8Aot1GuwJKOVDDpgnjPvz7eczIY7h4ypUqxGD1FMBIORTpJHlkMjsWZjkk9z61dOjGm3y7M5MbmVbHRi8Q+aUdL9Wuz9P1G1614c/0T9kTxje2v7i6lv0gkni+V3j3W42FhyVxI4x0w7epryWvXPibDP4a/Z98D+ErmGQzzu+oSPIpiaFgCxiKHnINzjOR9zpzx4+eNVJYbDLeVRP5Q95/kl8ztyROnDE4l7RptfOfur82/keL0UUV7R4IUVeh09PKWS8uDCGGVRE3uQehIyAAfrnocYOak+xab/z/AF1/4DL/APHKrlYrozaK0vsWm/8AP9df+Ay//HKPsWm/8/11/wCAy/8AxyjlYXRm0VpfYtN/5/rr/wABl/8AjlH2LTf+f66/8Bl/+OUcrC6M2itL7Fpv/P8AXX/gMv8A8co+xab/AM/11/4DL/8AHKOVhdGbRWl9i03/AJ/rr/wGX/45R9i03/n+uv8AwGX/AOOUcrC6M2itL7Fpv/P9df8AgMv/AMco+xab/wA/11/4DL/8co5WF0ZtFaX2LTf+f66/8Bl/+OUfYtN/5/rr/wABl/8AjlHKwujNorS+xab/AM/11/4DL/8AHKPsWm/8/wBdf+Ay/wDxyjlYXRm0VpfYtN/5/rr/AMBl/wDjlH2LTf8An+uv/AZf/jlHKwujNorS+xab/wA/11/4DL/8co+xab/z/XX/AIDL/wDHKOVhdGbRWl9i03/n+uv/AAGX/wCOUfYtN/5/rr/wGX/45RysLozaK0vsWm/8/wBdf+Ay/wDxyj7Fpv8Az/XX/gMv/wAco5WF0ZtFaX2LTf8An+uv/AZf/jlH2LTf+f66/wDAZf8A45RysLozaK0jYWLDEeoShuxmg2r+JVmP6GqE0MkEzRSrtdeo6/Qg9x3z3pNNAmMooopDO4+On/Jftf8A+3f/ANJoqKPjp/yX7X/+3f8A9JoqK8nJv+Rfh/8ABH/0lHq53/yMcR/jn/6Uw+Bf/JftA/7eP/SaWuHruPgX/wAl+0D/ALeP/SaWuHqqH/Iwq/4Kf/pVQVb/AJF1H/HU/wDSaZ0HgbxJ/wAIh8QtK8RNF5sdrL+9QLuJjZSj7RkfNtZsZOM4zxXZfGvwzJoHxTu7yO38uy1T/TIWXcQXP+tBLfxb8sQCcB16ZwPLa910df8AhaP7OMulCPzfEPhbH2famXlhCnYg2p/EisgRTktEhY81yZlL6li6WP8Asv3J+Sb91/KWn/bx25WvruEq5f8Aa+OHm0veXzjr/wBuni1FFFfRnzwV7f8As0fBOT4tfEj7Xq8Eg8LaOyzag/K/aGPKWyn1bBLEdEDdyK8o8M+GNa8W+LtN8N6HZPcahqMwht48YDE9WJ7KACSegAJPSv1N+F/gfRPhd8MNO8IaOVkW2UyXN0F2m7uGx5kp+pAAHZVUdq48bifYwst2deEwzrS8kdfBZW1lED8sccS8IvyoigcDA4AAHA7AVy3h24k13WtZ8SJH8ktyNPtz6Q24wcfWWSUn6e1cz8cfitp3w5+Fuo6jLKr3skZitbcHmWVuEQD3P6Bj2rufAOiy+GPhboGhXspnvbWxjF3M3WS4Yb5nPuZHc14CT5Wz6CT5LX3/AE/r8jZjmisLOJ7+eKMySLEp6BnY4VR6knis/wAXeDPC3j3wvLoHivRrbVLCTkRzD5o2/vxuPmRv9pSDXD/F7XFtH8MafFceVcTaoJkAOCfLikYY9eRn8K6vw14ph1nTFlLBLhABNHnofUexpK8bNFTw0pU/adz4Z+NX7O2vfCa7fXtCt/7e8Ju+BcNEDcWRJ4SYDqOwkAwTwQDjPjX9o2ep6XNZqixs4Dw4A4kHQAj1BI/Gv1N8ax2mq/DTxBYXYVoZtNuFbd0/1bEH8CAfwr8xvEug2Vn4iz5q24vFSSN8YEMjZ+Vx2UsCD3Bx616VDEOorS3Jw2Aai6sGtHZp9VJNfLt6tHLQXl7GfKR2+XgL1/Q1oCe5nZTHZytcbcFiuFX3z0A9zVOdCZp7e+i8rUEkO4HoT6f4GkmtkS0spTJJJFKHM0YkIBZXxtPXHBU/jXpQtJXPCqxdObg+jtr+pR1aSBr0Q28vmxwqE83s56sw9sk49sVQrpY9DF9qHni1VLYKMQQyBT0/vNnr17mm3Hhm5a8kkFs9tbEAoE/fHp0OD3rT2iMnh29VJPW3/B16epzlFWJbKeGBZZVVdzbQhYbv++eoqv3q009jCUXH4kdP8PvDMniz4i6ZpH2fzrYyia7B3BRApy+WXlcj5QePmZRkZq98afEn/CSfF7UNkXlw6b/xLY8rhm8tm3k8kH52fB4+XbkA5rtfCa/8Kx+A2o+O54/L1vWcWum70+aNTnYw3IcZw8uDlXVI+5rwmvnsLL69mFTE/Ype5Hze83+UfOzPfxi+o5fTwv26tpy8ltBfnLyugq5pcaSaonmKHVFeXawyGKIWAI7gkc+1U6vaR/yEz/1wm/8ARTV78dz517D2ZndndizMclickn1pKKtaZp13rGt2ek6fEZru8nS3gjHV3dgqj8SRWoirRXsXj/4V2ml+JvDcFrpt74W0y9u30ae81mKWJXlhcA3n73GElR0cDIUEOAQBxnXXwwsbVJLV9RubGJ9T020Goa5YCzZEuFu9zoUuZImi/wBHHzEnJGAyBW3gHl1FerQfD/whpc3iu38RXfieGKy0OG/tbqbR4kkVmvoITJHGt4UlXD7Ad+Dvc8GNQ1DX/hZb+H/Ar6xdeLtK/tSO1gu30s3VpvZZghCIq3BmMgWQMQ0KjCsQx4yBc84orvfG3w+0zwvFrn9l+JpdWl0PWRo1+slh9mAkbzijRnzG3D/R5A2QuDjG4HNXdB8IaDrnwKa4itWXxVLqN61nOJWxPFbW9tI9tszt3FZpXUgbiYwvO4UBc81or2i8+Dmnav468T2GlX8mjJb6xd2Gl29x9n+zzCLkIJJrpZnYZAISKQjKkk5wOW0v4d6Ze6JbveeJ5LXVrnRrzXILFLAyRmGCOZwjS+YMO/kNxtICnOSflIK5wFFehat8MRp/wwPiuHV5PtMENtPd6ZeJbRSxpNtCsqR3Mku3LrgyRR5DA+1avwo+GZ8Y+HtRvrjw3qmqrdzjR7GezilZLG4eNn+0ylOAiN5KkP8ALtlY/wAOQDueUUV1XivQ7TR/CnhGeOza3vb2wuJb7czZaVL64hGQThSFjRcDHT1ya6bU/AbN4H0ax0LwzBd6u9tHcaldLet9ospJN0iCdC3lJA0BjYNgYJIZwQVoA8vorvfhbovhjWb/AMQr4rg3WdvpO+OfzXT7JLJd28An+UjdsEzNtOQcciunvfhdpUWk+E/CskX2HxPda9HpOrX+5pRE8yo6oI9wU+WsiZxgltwJ6YBXPG6K9B8D+F7WWxttfvfJuory08Q24tJoAyxva6V5ySgknJ3TqRwNpjBByeNPxH4K8JRvqaeGrq4eW18MabqUsWoWvkpHJP8A2eN8couSNzm6dm3rsTLKoPyugM8ror1fwj4S0HTPC/ie78XJ4PnurK6sIYLjUdQuruzRZluWZQ+luxZz5SdSQNpzgnk07wj4MuPCd7rGvSyWUcnhw6rbvpFnJP5Lf20bTdtmuV3nYAgB2jY+SN6bpAVzyiiuvvfA32NtcA1TeNL0Ox1rPkY837SbT91975dv2z73OfL6DdxW8eeGtK8IeNtQ8Nadrk+rTaddTWl1M9mLZA8blfk/eMW6c5AwcgbhyQZzNFFFABRRRQAU+5US6J5jfegmVFP+y4YkH2BXI/3m9aZUkv8AyL8//XxF/wCgyUnsBl0UUVkUdx8dP+S/a/8A9u//AKTRUUfHT/kv2v8A/bv/AOk0VFeTk3/Ivw/+CP8A6Sj1c7/5GOI/xz/9KYfAv/kv2gf9vH/pNLXD13HwL/5L9oH/AG8f+k0tcPVUP+RhV/wU/wD0qoKt/wAi6j/jqf8ApNMK6PwL4o1Pwf46stZ0uB7qRSYpLRWYC5RuCh29T0I4IDBTg4xXOV33wo8Z3HgzxZNdWthZXj3EYieK5hVy8ecsisfuk8dM5xg8cV316MK1OVKorxas15M4sNVqUqsalJ2kmmvU2vix4Js9KvE8X+GzbHw9qcgVIogYzazFcmMo3IztZsYG05UquBnh9E0+O71BZLx0hs4gZJZJQ2wgfw5UdScD8e1e1+MdNkl8J3/jP4fXM7eFblt2o6VCAr6VKMHY8fTyweVcfd4zwAa8wtbS61SbZbPe3qg7ysXJHHJwOnua5sFCphqKo1J89tE3vbpfu/Prud+M9nisQ6tKHLfVxXfrbsvLpsdMPEV1pmuaVc+Hb64sDYBZraaG4O2Pb1VMHAyMgg9QTkNmvrnxB+0n4K0v4UxeNUvGVLgMkdowBn84dYQmeWGRk/dAIJOCM/Cm59Pd7VLVgHI49TyOePXnA/pXH+IruK61CO2hlFw8WVedWyrsccD2HTPf6YpVsPGok30Nvr8qUnLlV38ku1l6f139x8GeJvEf7Q37X3hH/hJw6aPFqH2xLPOYo4Yf3rDJ++zeWFJ75AAAwK/SGfU1ijeWZ9mAWcnjHc1+XUyWOl+HEsHtGju7WUxRiElo1QMTkSKeeST0z1Oe1ekW/wC0B4/sPhanhBIoboQWzQprUssjyovLLI/UEqCAMn+FfSsK2Gc7KPQ6KVoNyqvmbSba1t5ev4HufjHW7XxV4lvtd1CYQaVp6NFaXDHHlFTl5we20qFB77X6g1F8OviBB4k0GPXdIn8q5hcw3MWMFHHqv91hhh7HHUGvi4eL9WuvDUGgXep3Zs4MmOGWd2hznPKeuTn09hVnwZ431bwX4kk1TTdQMbTIY5kZPNjlHYOmRnBwQQQQfYkVUsBLla69Dup5xh/dS2e/kfcfxV+KdrYfCTUNPYiDVNTj+x26Fsq2SN7dc7Quc/UDPIr421/VbfWGvnv1aW7wIxI8mQfndnIbvztAzzycVl+I/FWueKb99Sv72W+mYbRMcARr/dRF+4Pb8eTXPmafyfKfhQMc8cVthsPKlGzOPMsVhnyqkrtPV30t27edy1e3El/Al7Pn7THiGZuMnAADH36fmasW9pLd6XEI8IEdmkL9S+APlHoAB9SfYVmQ3lvb212p+d3RVQDpuz1P0GfxxUP9s6n5PlLeyonpGduc9c4611KnJK0TiqYvD1aiq105NrW3fu36HUQaRqIAEVwyjthDirCprVsWASOUY+b5SpI/KuFa4nf780jfViaWO5uIm3RTyIfVXINHsp9yHi8E9FRa/wC3n/kd75ttcuI7uDyp+qt0I+hH+NRaD4W0e/8AH1hb63qMVpp5lae6munKrMincUyMbScEFiRgEt2xWb4dh17XIb1ki8+0soDNPdTEKIP7vznqWIwF6nnsCRavbjfGl0WBUFUQY+8d3J9xjI/E1zVL1FOlGdpWtdbq6/Prr5FWhTcayjzU3raXWz28+110uuhT+J3jRPGPi/8A4l8cdvounIbPTYIdyx+UpwJAhAClgBwAMKEU525PFVJcCMXUgizsDkLn0zxUda4XDU8LSjRpL3Y6Hn4vE1MVWlXqv3pP+vl2Cr2kf8hM/wDXCb/0U1UafDLJBcRzxNtkjYOpxnBByK6U7M52Xau6Rq+oaFrMGraVcfZ7yAkxS7FYoSCMgMCM4JweoOCMEA1XjEF2u+CWGF/4oZZNm33Vm4I9s5+uMl/2OT/nvZ/+BcX/AMVWpJd0zxJq2kWL2NnLbvavcxXjW91axXMbSxh1RikqsDgSOCMYOeQcDGpdfETxXehI7m6097aOWGVLL+zLUWqtD53lgQCPywoNzOSu3DFySCcEc99jk/572f8A4Fxf/FUfY5P+e9n/AOBcX/xVAtDoR8RfFY1n+0vtVhuFobD7L/Zlr9k8gyeZ5f2by/J2+Z8+Nn3uevNVr3xp4g1Lw4miahLYXVukaQpNNp1s90kaEbEW5MfnKoAAAD42/L04rH+xyf8APez/APAuL/4qj7HJ/wA97P8A8C4v/iqA0L+o+KNd1Y6udQvvO/ti/XU7790i+dcL5uH4A2/6+XhcD5unAwlj4m13TLbTYLDUHgTTb5tStNirmK4YRguDjJ4hj4OR8vTk5o/Y5P8AnvZ/+BcX/wAVR9jk/wCe9n/4Fxf/ABVAaHWQfFjx7bajc38WtQm6uLyW/ad7C3d0mlx5jRs0ZMYfADKm1SBgir2ifFB9E+G8/hyLTrm4vZLO50+O7uJ4WjggnDB0RRB5wGHc7fOKbju25rhfscn/AD3s/wDwLi/+Ko+xyf8APez/APAuL/4qgNDfvfiD4t1DwzLoF3qUL2M0MMEwWzgSSdIivlCSVUDuV2KAWYkAYzgkVjzazqdxpWn6bJdH7Lp5ka1jRQvls7BmbIAJJIHJycADoBUH2OT/AJ72f/gXF/8AFUfY5P8AnvZ/+BcX/wAVQGho+IfFWveK7uK5169W6li83Ywhjix5kzzPwigHMkrt/wAC9MCta2+J/jazsI7SDVYNqW4szI9hbvLJbhdogklaMvJFtAHluSuABjgVzH2OT/nvZ/8AgXF/8VR9jk/572f/AIFxf/FUBoS2OrX+nWuoW9lP5UWoW/2S6XYp8yLzEl28jj54kORg8Y6Eip7LxHrenWVpaWN+9vFaXo1G38tVDR3ACgSBsZyNq8ZxxVP7HJ/z3s//AALi/wDiqPscn/Pez/8AAuL/AOKoC6OivfiN4vvzb+fqNui26XaQx21jbwRxi7hENxhI4wvzoMHjg5YYYk1WufG/iS70X+yp7y3a3Niumuy2cCyyW6vE6RvKEDuFNvDt3MSoXAwCQcb7HJ/z3s//AALi/wDiqPscn/Pez/8AAuL/AOKoDQlh1bULfQLvRYbjbY3k0VxPDsU73iDiM5xkYEsnAODu5zgY09N8beJNK+yra3lu0dtZNp0cFzZwXERt2na4MbxyIyyDzWL/ADAkHGOgxj/Y5P8AnvZ/+BcX/wAVR9jk/wCe9n/4Fxf/ABVAaG7P4/8AFlz4Wl8PTajE1hNaxWUqi0hEksMTo8aPKE3sEMabcsdoG0YBIONq2qX+ua/fa1qk/n319cSXVzNtVfMkdizNhQAMkk4AAqP7HJ/z3s//AALi/wDiqPscn/Pez/8AAuL/AOKoDQr0VY+xyf8APez/APAuL/4qj7HJ/wA97P8A8C4v/iqAuV6KsfY5P+e9n/4Fxf8AxVH2OT/nvZ/+BcX/AMVQFyvUkv8AyL8//XxF/wCgyVIbXYN0t3Zog6sJ1fH4IST+AqjeXSzBIYQRBGSV3feYnGWPpnA46DA68kqTsh7lWiiisijuPjp/yX7X/wDt3/8ASaKij46f8l+1/wD7d/8A0miorycm/wCRfh/8Ef8A0lHq53/yMcR/jn/6Uw+Bf/JftA/7eP8A0mlrh67j4F/8l+0D/t4/9Jpa4eqof8jCr/gp/wDpVQVb/kXUf8dT/wBJphSqzI4dGKspyCOoNJRXqHlnc+HPiLqulavBcrOLaUAJJLGCFnHQeYucH647nIOTXbjTrPxLJN/wjWqJ4ekmYySWdtEPLMhOQflIITPQDIHYDpXh9aGna3qWlyo9ncuhQ5Xn7p9vSp5Va1jrpYucanPKT13to2dV4quPE3hrTb601u6uhNKnkoxfcs5bjcGxzhQeeCOAcVyOhaEIymoaggzt8yGB0Dg+8ikj5enGOc9h19g04eIvGPhWz8SSQ2OpXEJkSO2jbdLDtxukWNuGkOOqksFAwBmuVv7u2nhJFu80oO7y1R9zH6Yzn9axcbPax2VpKtLndRyS2vv+f5GZDFNcoz+ZLECPlEZZRIeOcHoOeen9atX0t7b6BeQTX8iSugL2UWQqLuAzJnHzHjCgHAPJ7V0mkaR4jMF5cwWEukuyqIru7iKGGLq0gUjIwBgYAxknI61leIIPCWm+HLmO11ifVNWnwoZjkL84JZtvGcDuT1oim5amvu06LlB+80+tklqu+r8uifU4Oiiiuw8MVWZTlSQfUUM7McsxP1OaSigArctPDNxJYC91C5isInQvCkgLTT8cbIxzg8cnA56mqGmTWtreC6uoxKI+ViIyGbtn2FdnpHh/xl471CO407w48kU//L/eBlgChtpO84VsHOQu5uDwcVy4rEwoR56klGK6t2/M9PAYONfTWUntFJt+rsv8vVHHR6TcscO8ER9HkGfyFaCaPZjzwZXfIxEAp3KfXgYNenHwt8L/AIZyLdeOdVGua2u1/wCyLBdyRN+7bBTIzjJI8xlV1J+QkV5r4z+Ieq+L54oVtbXSdMt1Mdvp9guxAucjeR98gBR0AG3hVyc+bhc1ljai+r026f8AO/dT/wAKesvXReZ14nLKeAg/rNRe0/kVpNf4ntH01fkaj6tJbaQml2xlg0tXZ1glkWJWYgDdJjG9sKBkj6ADiub1LV497+TIJpmG0OoISIf7Oep96wCSTknNFenCjGGyPNq4tz6a+bvb02S+4KKKK1OMKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAO4+On/Jftf/AO3f/wBJoqKPjp/yX7X/APt3/wDSaKivJyb/AJF+H/wR/wDSUernf/IxxH+Of/pTD4F/8l+0D/t4/wDSaWuHruPgX/yX7QP+3j/0mlrh6qh/yMKv+Cn/AOlVBVv+RdR/x1P/AEmmFFFFeoeWFFFFAGjpOvaxoc5m0nUZ7Rj18tuG+o6Gurf4yfESSxa1bxDLtK7d4RQ+PqORXB0UDu0dp4a+KnjLwvq0t9Z6gl0JjmaC9TzEk4IHoy8nPykZIGc4xXZy/FrwB4qkB8efDlGnKK8t/psg82aVVC8/cYJjPBkbGFHOMjxiivLxWTYXE1Pbyi1U/mi3F/emr/M9TC51i8NT9hGSlT/lklJfc07fKx7N/Zn7PN4Ptf8Awlmv2HnfvPsflO3kZ58vPkNnbnH3m6dT1pf+FS+Bv+i0eHvyh/8Aj9eMUVh/ZWJh/Bxc16qMvuvH/hzo/tfDT/jYSD9HKP32l/wx7P8A8Kl8Df8ARaPD35Q//H6T/hHPgHaH7Le/EHV5rqH93NJbQsYnccMUxAw2k5xhmGO5614zRR/ZeKn/ABcZN+ihH8oh/a2FhrSwcF6ucvzke0Q/E34UeGrqK58JfDSW5nLiRpdTmAaFkOUaIsZSDkkkjb0Xr25jxJ8afH3iTy0/tX+yIUwfK0ndb7mGfmL7i54bGN23gHGRmvPqKujkWDpz9rOLnPvNuT/Fv8DOtn+NqQ9lCShDtBKK/wDJUr/MKKKK9g8YKKKKACiiigArX8KrZP440hNRhWW1a8iWRGICkFgPmyCCvqO4yOM5rIooQM9f0TTRZ+KNUS3gvtNgi1yy/wBDl2FZAZnww/dghccqAcYPVqrWvhzRbX4q2Pn2smp21/8Aam+0yMht3l2ufLCFTyp+XDEHdg4GMHymitOfyI5PM9A0fwRpmpQrJcQ6rbNJdvbyxmRM6aqqCHnygzk+yfXNXb7QbTUPhXo9z5s13cWVnOYrW1YKzr57ZlOQcouOQBnkdBzXmVFLmXYfK+52On+C3SDVU1Wxv7rUrCSOP+ytPlTzSHGd+Qr5UDHQHr2qzaeC9LuPC6ag894pezmuXu96+RbSISBA425LHHqDzwDXC0UrrsFn3PRpfB3hW10aa6n/ALYkkttPtL2TZcRqrmYhSqgxnABOcnNV77wrp2j64dBlJmF5qy28UrgeYIUALYOOCzSKufVDXA1I1xOyRI08hWEYjBY4QZz8vpySeO5p8y7ByvuemXekadceDJbqXSoYIhBHIs8cUcaRloJJPlcLvYq6JGQ7Nkk9CRjPu/BegLpEnkXN/Ddw6ba6hJNNIjRfvWAZdoQEAZzndXJXviDVtQtGt7u4jdXIMjiCNZJSOm9woZ/+BE1mUOS7CUWejax4F8OaTeWAkvtSa3lvo7aSYRvskjYf6xJDEEBB/hDPkd6XUfh7pGl6ReXN1qkwkslEFwNy4S4dozH25TZISe+VPIrziijmXYfK+56/ceEtOs/Ck+hBr2ys59at4jf3jqyTLsP7yPCgBTnHU9uetYg8B6Q2q6fBLLqFi1x9pzYXDobiTyhlCh2gDf2yPpmvO6KHJdhKL7nrGteGrS+t9ItprTUons9F82LS96/apW80/JnZ1GST8mcdqpWPw80W513UrBbm/na38rygpKIhZNzLLMsUiqynjkD+leaUUcy7ByvuegWXw/guvAt1rEplimhs5rtJY5/NifyyflIEQVcgf89Ce+MdNW28PafongTXJoodQuIJ9NtpJL7evkzbnVmSP5eCOnJPuB38qoo5l2G4t9T0ofD7w+mq2lrPrEyrqEjz2LB1/eWojDLnCk72ZtowP4WwDwKrSeDNAtdU1AXL6s1va6Ub8wFWgkDhwu3dLCu5f9oIP0rz6ijmXYOV9z05/DGh2GgeJrS30y81GZIrK6gIdDPHG6ljtIjOApzuIGCMfdxk0LjwFZx6FdatGb5rRNNtrqGfcpR5ZGAdc7eQMngcjjNcBRRzLsHK+56M3gnw1L451TQbafUU/s6IttlmDyXTfLwgSElQMnOFcnjgc1x/iXS7bRvE1xp9nLcSQx7SpuYXhkGVBwyuqnjPXAz171k0Um0+gJNdQoooqSgooooAKKKKAO4+On/Jftf/AO3f/wBJoqKPjp/yX7X/APt3/wDSaKivJyb/AJF+H/wR/wDSUernf/IxxH+Of/pTOZ8FeIn8KfEHSPEKtIqWlyrTCJFZmiPyyKobjJQsB069R1ra+I/heDwr49uLTT5I5dKu0W+06WJw6vbyZK7TuYkAhlBJy23d0Irh67Xwn4m0eawg8I+OluJvD3neZb3duf8ASNLdj8zREg5jb+OPB/vKNw+asRCdGssXTV9LSS3a3TXdx106pu2trrDVIVqLwlR21vFvZPZp9lLTXo0r6Xty1FeiS/CLVtTkE3gPWdK8W2RRXaS0uY4ZoAygjzonYGMk7gBkn5DnaeKZ/wAKQ+KH/Qsf+Ttv/wDHKazrAW96tFPs2ov5p2a+aB5JmF/doSa7pOS+TV0/kzz6ivQf+FIfFD/oWP8Aydt//jlH/CkPih/0LH/k7b//AByj+2sv/wCgiH/gUf8AMP7EzH/oHn/4BL/I8+or0H/hSHxQ/wChY/8AJ23/APjlH/CkPih/0LH/AJO2/wD8co/trL/+giH/AIFH/MP7EzH/AKB5/wDgEv8AI8+or0H/AIUh8UP+hY/8nbf/AOOUf8KQ+KH/AELH/k7b/wDxyj+2sv8A+giH/gUf8w/sTMf+gef/AIBL/I8+or0H/hSHxQ/6Fj/ydt//AI5R/wAKQ+KH/Qsf+Ttv/wDHKP7ay/8A6CIf+BR/zD+xMx/6B5/+AS/yPPqK9B/4Uh8UP+hY/wDJ23/+OUf8KQ+KH/Qsf+Ttv/8AHKP7ay//AKCIf+BR/wAw/sTMf+gef/gEv8jz6ivQf+FIfFD/AKFj/wAnbf8A+OUf8KQ+KH/Qsf8Ak7b/APxyj+2sv/6CIf8AgUf8w/sTMf8AoHn/AOAS/wAjz6ivQf8AhSHxQ/6Fj/ydt/8A45R/wpD4of8AQsf+Ttv/APHKP7ay/wD6CIf+BR/zD+xMx/6B5/8AgEv8jz6ivQf+FIfFD/oWP/J23/8AjlH/AApD4of9Cx/5O2//AMco/trL/wDoIh/4FH/MP7EzH/oHn/4BL/I8+or0H/hSHxQ/6Fj/AMnbf/45R/wpD4of9Cx/5O2//wAco/trL/8AoIh/4FH/ADD+xMx/6B5/+AS/yPPqK9B/4Uh8UP8AoWP/ACdt/wD45R/wpD4of9Cx/wCTtv8A/HKP7ay//oIh/wCBR/zD+xMx/wCgef8A4BL/ACPPqK9B/wCFIfFD/oWP/J23/wDjlH/CkPih/wBCx/5O2/8A8co/trL/APoIh/4FH/MP7EzH/oHn/wCAS/yPPqK9B/4Uh8UP+hY/8nbf/wCOUf8ACkPih/0LH/k7b/8Axyj+2sv/AOgiH/gUf8w/sTMf+gef/gEv8jz6ivQf+FIfFD/oWP8Aydt//jlH/CkPih/0LH/k7b//AByj+2sv/wCgiH/gUf8AMP7EzH/oHn/4BL/I8+or0H/hSHxQ/wChY/8AJ23/APjlH/CkPih/0LH/AJO2/wD8co/trL/+giH/AIFH/MP7EzH/AKB5/wDgEv8AI8+or0H/AIUh8UP+hY/8nbf/AOOUf8KQ+KH/AELH/k7b/wDxyj+2sv8A+giH/gUf8w/sTMf+gef/AIBL/I8+or0H/hSHxQ/6Fj/ydt//AI5R/wAKQ+KH/Qsf+Ttv/wDHKP7ay/8A6CIf+BR/zD+xMx/6B5/+AS/yPPqK9B/4Uh8UP+hY/wDJ23/+OUf8KQ+KH/Qsf+Ttv/8AHKP7ay//AKCIf+BR/wAw/sTMf+gef/gEv8jz6ivQf+FIfFD/AKFj/wAnbf8A+OUf8KQ+KH/Qsf8Ak7b/APxyj+2sv/6CIf8AgUf8w/sTMf8AoHn/AOAS/wAjz6ivQf8AhSHxQ/6Fj/ydt/8A45R/wpD4of8AQsf+Ttv/APHKP7ay/wD6CIf+BR/zD+xMx/6B5/8AgEv8jz6ivQf+FIfFD/oWP/J23/8AjlH/AApD4of9Cx/5O2//AMco/trL/wDoIh/4FH/MP7EzH/oHn/4BL/I8+or0H/hSHxQ/6Fj/AMnbf/45R/wpD4of9Cx/5O2//wAco/trL/8AoIh/4FH/ADD+xMx/6B5/+AS/yPPqK9B/4Uh8UP8AoWP/ACdt/wD45R/wpD4of9Cx/wCTtv8A/HKP7ay//oIh/wCBR/zD+xMx/wCgef8A4BL/ACPPqK9B/wCFIfFD/oWP/J23/wDjlH/CkPih/wBCx/5O2/8A8co/trL/APoIh/4FH/MP7EzH/oHn/wCAS/yPPqK9B/4Uh8UP+hY/8nbf/wCOUf8ACkPih/0LH/k7b/8Axyj+2sv/AOgiH/gUf8w/sTMf+gef/gEv8jz6us+HHheDxV49t7TUJI4tKtEa+1GWVwipbx4LbjuUgElVJByu7d0BrYi+EWraZIZvHms6V4SsgjOsl3cxzTThVJPkxIxMhB2gjIPzjG48VieLPE2jw2E/hHwKtxD4e87zLi7uD/pGqOp+VpSAMRr/AAR4H95huPy5VcfHFxdHBSu2viWsY+d9m+yTeu9ka0sBLByVfHRsk/gekpeVt0u7aWm12ZHjXxE/iv4g6v4hZpGS7uWaESoqssQ+WNWC8ZCBQevTqetFYNFehRpRowjTgrJJJeiPMrVZVqkqs3dybb9WFFFFaGYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB//9k=",
	"bosan": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwMDAgQDAwMEBAQFBgoGBgUFBgwICQcKDgwPDg4MDQ0PERYTDxAVEQ0NExoTFRcYGRkZDxIbHRsYHRYYGRj/2wBDAQQEBAYFBgsGBgsYEA0QGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBj/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4Poor1XTtOT4PRab4g8QaRFeeMbpFvNO0q+jbydOh3ECecAgtMSrBIwR5eCzYYKo6oxuZN2Of8P8Awj+JHiey+2aP4SvntyiSJNc7bZJUcEq0bSlQ4IGcrnqPUZ1/+GfPi9/0KP8A5P2v/wAdo0aTxP8AGr4q6bofibxTcmW583y55Iw8dvthLHZCpVV3eUoO3GTycmvU/wDhk3/qfv8Aylf/AG6tFTT2Rm523Z5Z/wAM+fF7/oUf/J+1/wDjtH/DPnxe/wChR/8AJ+1/+O16n/wyb/1P3/lK/wDt1H/DJv8A1P3/AJSv/t1V7Hy/EXtPM8s/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdr1P/AIZN/wCp+/8AKV/9uo/4ZN/6n7/ylf8A26j2Pl+Ie08zyz/hnz4vf9Cj/wCT9r/8do/4Z8+L3/Qo/wDk/a//AB2vU/8Ahk3/AKn7/wApX/26j/hk3/qfv/KV/wDbqPY+X4h7TzPLP+GfPi9/0KP/AJP2v/x2j/hnz4vf9Cj/AOT9r/8AHa9T/wCGTf8Aqfv/AClf/bqP+GTf+p+/8pX/ANuo9j5fiHtPM8s/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdr1P/AIZN/wCp+/8AKV/9uo/4ZN/6n7/ylf8A26j2Pl+Ie08zyz/hnz4vf9Cj/wCT9r/8do/4Z8+L3/Qo/wDk/a//AB2vU/8Ahk3/AKn7/wApX/26j/hk3/qfv/KV/wDbqPY+X4h7TzPLP+GfPi9/0KP/AJP2v/x2j/hnz4vf9Cj/AOT9r/8AHa9T/wCGTf8Aqfv/AClf/bqP+GTf+p+/8pX/ANuo9j5fiHtPM8s/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdr1P/AIZN/wCp+/8AKV/9uo/4ZN/6n7/ylf8A26j2Pl+Ie08zyz/hnz4vf9Cj/wCT9r/8do/4Z8+L3/Qo/wDk/a//AB2vU/8Ahk3/AKn7/wApX/26j/hk3/qfv/KV/wDbqPY+X4h7TzPLP+GfPi9/0KP/AJP2v/x2j/hnz4vf9Cj/AOT9r/8AHa9T/wCGTf8Aqfv/AClf/bqP+GTf+p+/8pX/ANuo9j5fiHtPM8s/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdr1P/AIZN/wCp+/8AKV/9uo/4ZN/6n7/ylf8A26j2Pl+Ie08zyz/hnz4vf9Cj/wCT9r/8do/4Z8+L3/Qo/wDk/a//AB2vU/8Ahk3/AKn7/wApX/26j/hk3/qfv/KV/wDbqPY+X4h7TzPLP+GfPi9/0KP/AJP2v/x2j/hnz4vf9Cj/AOT9r/8AHa9T/wCGTf8Aqfv/AClf/bqP+GTf+p+/8pX/ANuo9j5fiHtPM8s/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdr1P/AIZN/wCp+/8AKV/9uo/4ZN/6n7/ylf8A26j2Pl+Ie08zyz/hnz4vf9Cj/wCT9r/8do/4Z8+L3/Qo/wDk/a//AB2vU/8Ahk3/AKn7/wApX/26j/hk3/qfv/KV/wDbqPY+X4h7TzPLP+GfPi9/0KP/AJP2v/x2j/hnz4vf9Cj/AOT9r/8AHa9T/wCGTf8Aqfv/AClf/bqP+GTf+p+/8pX/ANuo9j5fiHtPM8s/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdr1P/AIZN/wCp+/8AKV/9uo/4ZN/6n7/ylf8A26j2Pl+Ie08zyz/hnz4vf9Cj/wCT9r/8do/4Z8+L3/Qo/wDk/a//AB2vU/8Ahk3/AKn7/wApX/26j/hk3/qfv/KV/wDbqPY+X4h7TzPLP+GfPi9/0KP/AJP2v/x2j/hnz4vf9Cj/AOT9r/8AHa9T/wCGTf8Aqfv/AClf/bqP+GTf+p+/8pX/ANuo9j5fiHtPM8s/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdr1P/AIZN/wCp+/8AKV/9uo/4ZN/6n7/ylf8A26j2Pl+Ie08zyz/hnz4vf9Cj/wCT9r/8do/4Z8+L3/Qo/wDk/a//AB2vU/8Ahk3/AKn7/wApX/26j/hk3/qfv/KV/wDbqPY+X4h7TzPLP+GfPi9/0KP/AJP2v/x2j/hnz4vf9Cj/AOT9r/8AHa9T/wCGTf8Aqfv/AClf/bqP+GTf+p+/8pX/ANuo9j5fiHtPM8s/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdr1P/AIZN/wCp+/8AKV/9uo/4ZN/6n7/ylf8A26j2Pl+Ie08zyz/hnz4vf9Cj/wCT9r/8do/4Z8+L3/Qo/wDk/a//AB2vU/8Ahk3/AKn7/wApX/26j/hk3/qfv/KV/wDbqPY+X4h7TzPFfEHwj+JHhiy+2ax4SvktwjyPNbbblIkQAs0jRFggAOctjofQ44qvX/Fmm+J/gH8QYNP8M+Mbl5bmzS7kkjgEUb5aWMK8TM6vjDEFs4LcYIzVXUdOT4wxal4g8P6RFZ+MbVGvNR0qxjbydRh3AGeAEkrMCyh4yT5mQy5YspzlDsWpdzyqiiisyztfhH4ft/E/xs8O6PeGI27XXnypLEJUlSJWlMbKTghhGVOf73Q9DS8YeJrvxj461PxNerslvZi6x5B8pAAqJkAZ2oFXOATjJ5NdJ+z5/wAnG+Hf+3n/ANJZa8/rRfCQ/iLOn6jqGk6jHqGlX1zY3cWfLuLaVopEyCDhlIIyCR9Ca3P+FifED/oevEv/AIM5/wD4quaop3Y7HS/8LE+IH/Q9eJf/AAZz/wDxVH/CxPiB/wBD14l/8Gc//wAVXNUUXYrI6X/hYnxA/wCh68S/+DOf/wCKo/4WJ8QP+h68S/8Agzn/APiq5qii7CyOl/4WJ8QP+h68S/8Agzn/APiqP+FifED/AKHrxL/4M5//AIquaoouwsjpf+FifED/AKHrxL/4M5//AIqj/hYnxA/6HrxL/wCDOf8A+KrmqKLsLI6X/hYnxA/6HrxL/wCDOf8A+Ko/4WJ8QP8AoevEv/gzn/8Aiq5qii7CyOl/4WJ8QP8AoevEv/gzn/8AiqP+FifED/oevEv/AIM5/wD4quaoouwsjpf+FifED/oevEv/AIM5/wD4qj/hYnxA/wCh68S/+DOf/wCKrmqKLsLI6X/hYnxA/wCh68S/+DOf/wCKo/4WJ8QP+h68S/8Agzn/APiq5qii7CyOl/4WJ8QP+h68S/8Agzn/APiqP+FifED/AKHrxL/4M5//AIquaoouwsjpf+FifED/AKHrxL/4M5//AIqj/hYnxA/6HrxL/wCDOf8A+KrmqKLsLI6X/hYnxA/6HrxL/wCDOf8A+Ko/4WJ8QP8AoevEv/gzn/8Aiq5qii7CyOl/4WJ8QP8AoevEv/gzn/8AiqP+FifED/oevEv/AIM5/wD4quaoouwsjpf+FifED/oevEv/AIM5/wD4qj/hYnxA/wCh68S/+DOf/wCKrmqKLsLI6X/hYnxA/wCh68S/+DOf/wCKo/4WJ8QP+h68S/8Agzn/APiq5qii7CyOl/4WJ8QP+h68S/8Agzn/APiqP+FifED/AKHrxL/4M5//AIquaoouwsjpf+FifED/AKHrxL/4M5//AIqj/hYnxA/6HrxL/wCDOf8A+KrmqKLsLI6X/hYnxA/6HrxL/wCDOf8A+Ko/4WJ8QP8AoevEv/gzn/8Aiq5qii7CyOl/4WJ8QP8AoevEv/gzn/8AiqP+FifED/oevEv/AIM5/wD4quaoouwsjpf+FifED/oevEv/AIM5/wD4qj/hYnxA/wCh68S/+DOf/wCKrmqKLsLI6X/hYnxA/wCh68S/+DOf/wCKo/4WJ8QP+h68S/8Agzn/APiq5qii7CyOl/4WJ8QP+h68S/8Agzn/APiqP+FifED/AKHrxL/4M5//AIquaoouwsjpf+FifED/AKHrxL/4M5//AIqj/hYnxA/6HrxL/wCDOf8A+KrmqKLsLI6X/hYnxA/6HrxL/wCDOf8A+Ko/4WJ8QP8AoevEv/gzn/8Aiq5qii7CyOl/4WJ8QP8AoevEv/gzn/8AiqP+FifED/oevEv/AIM5/wD4quaoouwsi9qutaxrl4t3rerX2pXCoI1mvJ2mdVBJCgsScZJOPc1e8H+Jrvwd460zxNZLvlspg7R5A81CCrpkg43IWXOCRnI5FYdFF+o7HU/Fzw/b+GPjZ4i0ezMQt1uvPiSKIRJEkqrKI1UHACiQKMf3eg6ArX/aD/5ON8Rf9u3/AKSxUVE1aTCOyD9nz/k43w7/ANvP/pLLXn9egfs+f8nG+Hf+3n/0llrz+qXwi+0FFFFAwooooAKKKKACitzwz4P8T+MdRay8M6Nc6hKn+saMBY4shiN8jEKmdrY3EZIwMmvTrb9nPVLCziv/ABz4y8P+GbOVAFeWXzHWYjIibcUTOA+Srt93jI5FKLewnJLc8Vor3I+Cf2dbHFnqXxH12W8hAjnktoG8p3HBZMW7DaTyMMwwRyetL/b/AOzRjP8AwrvxJ/3/AH/+SqfJ5i5vI8Mor3P/AISD9mf/AKJ54j/7/v8A/JVN/wCEd/ZovT9s/wCEy8S6d5/737F5TN9n3c+Xn7O+ducZ3N0+8etHJ5hzeR4dRXt5/Z1Or/8AIjfEfw34g8r/AI+sv5fk5+5/qjLnOH67fu8Z5x5r4p+H/jLwV5beJtAubGKXASfKyxEndhfMQld3ysduc4GcYpOLW4KSZzVFSvbzRW8U8kZWOXOxj/Fg4P61FUltNbhRRRQIKKKKACrOnafd6trFppWnw+dd3cyW8Ee4Lvd2CqMkgDJI5JxVaup+Hv8AyOkv/YJ1P/0gnppXdhPYvQx+FdHj+zR6Jb+IJhxNeX008cTMO8EcTRsq8kZkLFgFO2MkrUn9peHf+ifeH/8AwIv/AP5JrIr174b+C/D2veBrG91HRrS8nuNbeynmmvJIZEgEAf8AdIsih3B5ACsTk8dx6OGwrry5IWPHzfN6WV0PrFdNq9tLdm+rS6dzzj+0vDv/AET7w/8A+BF//wDJNH9peHf+ifeH/wDwIv8A/wCSa9N8BeCPCOq6TZ3OqaVLdBtdvLR/Mlkid4I7NpVQhWG07gD2PbpxVDxF8OtOi8O6B/wj8fnza3qzR2d2XY+ZbOqGMMucAruYNwDlTW/9mz9n7RWt+PT/ADPMXFuC+tfVJKSfdpW+1fW/Tkb2vb524H+0vDv/AET7w/8A+BF//wDJNH9peHf+ifeH/wDwIv8A/wCSa7X4m+EvDul6Taax4TigWziuZNOuvJvluw7rzHKSrtsLqG+U4xt6Cufh8Eeb8Ibjx1/bVqvk3YtfsBHztkgZznrznbjoCc1lUwU4TcLJ2V/kduFz/C4jD08TdxU5cqT35m7JO17X9bWMr+0vDv8A0T7w/wD+BF//APJNH9peHf8Aon3h/wD8CL//AOSa3vC2iaTJ8PvEHim907+1rjTpIIo7EyOkahycyybCGIGMDBHPWt3wvpHgbX9N1K81fQbjSZdEH9o3FtbyysLy2K/6r52yh3lcMP4W7kbqdPBOfLqlfX8/K3RkYrP6WH9o3CUlTai2rPVpNK3NzP4oq9rXe9rs4T+0vDv/AET7w/8A+BF//wDJNH9peHf+ifeH/wDwIv8A/wCSa9X0PwZ4M1vwhoczaLZw3+sWmozxwx3F157PE7+WsRLGIKqgA+ZycDqc1zN7ovhrT/gx4f1Y2mjJqeo292ZJL570zSMkpRTCIj5QIGPv4GcZzzWksulGPM2rWv8Al5b6o5aXFWHq1PYxpz5ufktZb+/r8Xw/u5a+Xrbjv7S8O/8ARPvD/wD4EX//AMk0f2l4d/6J94f/APAi/wD/AJJr0/XPA3hq2+G8moxaLDDJH4fstQW6t7qSS4a5kID74i7BYyOd2xQOcHsKVx4Q8Ox/B3/hMl8PyjUXsEX+zPtD7YsyFPt+N+/YccKflyehWiWWzi2nbRX+X3E0uLcJUjGSjLWagvh+JpNfa21+XW2l/Pf7S8O/9E+8P/8AgRf/APyTTTpOieKZ49P0nRk0bWZmEVpHbTyPa3Dk4WJllZ3R2JwJN+zIUFVBaQZVFcDgn0Pqbs5ut/RNEtp7H+1tWM32HzGgjit3CSTyKFLAMVYIqh1JJBzuAA+8yTfET/ksHiv/ALDN5/6PetST/kUfDX/XhJ/6V3FcVVuK0ObG1ZRjGMXbmdvwb/T/AC1DzNA/6E7SP+/93/8AH6PM0D/oTtI/7/3f/wAfqpXsPwq+FGi+MPC8+ua3d3W0zNBFDbOF24AyzEg888D275rm55dzxMdiaOBpe2rTlb/FL/M8p8zQP+hO0j/v/d//AB+jzNA/6E7SP+/93/8AH66u+8EWmm/HCPwTc6iTaNdxRfaOA2xwrAegbDAfWr2qeH9EuPC3iS+i0NtFm0bUIrWH97I32pXdlKMHJ+dQA2VwMHpRzy7kPGUfctKTUkmnzS2k7L7V9/u6nDeZoH/QnaR/3/u//j9HmaB/0J2kf9/7v/4/XsPib4eeErU+KL/SLIi20618ryGncm1uQyHdy2WVkfIzkZDegrGHhDw7/wANKXPhX+zv+JQgkK23nScYtS4+bdu+9z1/Sjnl3OalmuHqwc4uekXL4nskm/tb+8v8zzfzNA/6E7SP+/8Ad/8Ax+jzNA/6E7SP+/8Ad/8Ax+vV/CvgLwvrvhnwg7Wh/tO6eS4u0MzgXduk5jcD5vlZQUPy4yA1ZNroXhm0+Hd5rF3Z6QLlNcmsUk1SS8KeUsYYIotzndnPLe/PSjnl3KWZ0XJwXO2nb4pd2v5vJ/1c8+8zQP8AoTtI/wC/93/8fo8zQP8AoTtI/wC/93/8fqpRRzy7nrey/vS/8Cl/mWy3h6RTG/hLT41bgvBcXKyKPVS0rKG9CVYZ6g9K57XdGTThBfWTvJp90zrCZCPMjddpeN8YyV3p8wGGDA8Hcq61S6j/AMk0v/8AsJ2n/oq5q6c3ezLpylRlFptptJptvd26t2tv+BxlFFFdJ7R6B+0H/wAnG+Iv+3b/ANJYqKP2g/8Ak43xF/27f+ksVFTP4mEfhQfs+f8AJxvh3/t5/wDSWWvP69A/Z8/5ON8O/wDbz/6Sy15/VL4RfaCiiigYUUV6B8MPhheePdRmv7+4/szwzYZfUNTkIQKANxRC3G7HJJ4QfMf4VZpX0Qm7HLeG/C+v+L9dXR/Dmmy394UaTy0KqFVerMzEKo6DJI5IHUgV7ZB4D+Enwo8u5+Ies/8ACS6/Htf+xrJdyRN+7bDJkZxkkGVlV0J+QkVkeIPizp/hzwtB4J+ECXOlaXFvF1qsqKLm9c5UuD1XIw2/CuPlAEYTB8frRJRJ1Z6x4k+P/jDU4F07wzFbeF9Jjh+zx2tiqtIqbAuPMKjbtwdpjCFQe+Aa87jOq+KfFEYvL+e8vrt1R7q7lMjHAAyzsc4VR36AVl16Vo/hHVvtOmaD4Y019S8SaifJEVud7+YxP7vnAQIFJYngYJJwKmc3a5tRhFyXNt1OY8btZHx1eHTwDaqVSMjjKqoUH8Qor1v4aaLFdWES+L/2dk1Lw7MMNq9tJd2d0ikffjaSYJL/ALoAz2Nex+DPgV4Z+GZt9b8QB/FHjCSPfDaWuPIttvUxlhnC/wAU7YH90evRy3+u+KdSk0Y6f9lvXjSQxR3Uj7Y3zt87f2YKSM4OADjBFZR2SOuu/bVp1UrJtux8peMfg9eH4j31p8PIJ9S0FtstpPcyojKrjOxi2MkfTpjPNY2pfBX4m6XaNdT+FLuWFRktbMs2PwUk/pX2H4b8LXegO11qeiz/AGHcVlvbOXfLbEHB82MgnaMDJXoOcEV6LNoepx2q3OnCPVrVlDeQNqTMp5BicYRjjoGxn+9Vc9jF00fmCpvtL1NJENxZXltIHVgTHJE6nII6FSDg5r174cfFj4nwapa2096dX0dGCTvqilhGpcMzG4A378ZC7i3XAU4AG58VvEuh+IfifcO+kxJY6S7wAz2/kXE7r94ybhuTBBG0jgDOAx48zl8TyXyOk98bCyU8BAXkf12LnA4HU/nSdV29zc2w2GpSqL2793+uvQ9Cn8L/AA5+JPiG60p/EEHhfVYnWHTLWKFI7dkLrkCPCqzMzMAquGyScMBXkHjPwH4n8A6wmn+JLDyPN3G3uI2DxXCq2CyMPwO04YBlyBkVn3939t1CS4CeWrHCoDnao4A/LFeleCPi81hoUng7x/aSeIfCctt9nFttUzW4GSuxiVLAHAGWBTClCu3BuEEopPcxx1ZVq86kF7rei7JaL8DyCivT/iP8KoPDuh2njLwXqEuueELxFK3Zw0lsx+XEuAOC2QDgbW+RgCBu8wpNNaM5k7hRRRSGFbPhXV4ND8V219dpI9oyyW10IgDJ5E0bRSmPJA3hJGK543YzkZFY1FCdgOy1HSLzTo4biRRNZXOTa30QYwXSjGTGxAzjIBU4ZT8rBWBAZDqup29pFawaldxQQzi6jiSZlVJQMCRQDgPgD5hzWFpPiLxBoHnf2FrupaX523zfsV08Hmbc43bSM4ycZ9TWn/wsT4gf9D14l/8ABnP/APFVuq1jGdGM9JK5pp4l8RRuzx6/qiM0z3BZbqQEyuu1n6/eKkgnqQcUy31/XrSK0itdb1GCOzZntkiuXUQM2dxQA/KTk5I65NZ//CxPiB/0PXiX/wAGc/8A8VR/wsT4gf8AQ9eJf/BnP/8AFVf1mXdmP1Kja3IvuXn/AJv72TpfXseny2Ed5cLazMHlgWQhJGHQsucEjJwTVel/4WJ8QP8AoevEv/gzn/8AiqP+FifED/oevEv/AIM5/wD4qoda5uqSjey3LOn6nqWk3f2rS9QurGfGPNtpWibHplSDT21nV2nu5m1W9Ml4uy6czsTOvo5z8w4HBz0qn/wsT4gf9D14l/8ABnP/APFUf8LE+IH/AEPXiX/wZz//ABVUsQ0rGcsLTlLncVfvY1IfE/iS20caTb+IdVhsApUWkd3IsWCSSNgOMEk547miDxP4lttHOkW3iHVYdPKNGbSO7kWLa2dy7AcYOTkY5yay/wDhYnxA/wCh68S/+DOf/wCKo/4WJ8QP+h68S/8Agzn/APiqf1qXdmbwFB3vTjq77Lfv6+ZfGu64JPMGs6gH+zfYt32h8+R08rr9z/Z6e1B17XDdPcnWdQMzwfZXlNw+5ocY8snOSmONvSqH/CxPiB/0PXiX/wAGc/8A8VR/wsT4gf8AQ9eJf/BnP/8AFUvrL7sr6nS/kX3IStXS9LR4l1jWEuLfQIJQt1eIMb8YJhiJBDTMD8q9s7mwgZhl/wDCxPiB/wBD14l/8Gc//wAVWRqutaxrl4t3rerX2pXCoI1mvJ2mdVBJCgsScZJOPc1Dq9jfkDWtVuNc8Sahrd2kSXF9cyXUqxAhFZ2LEKCScZJxkmum0WVtd0Cy0u1RpdTsA8SW0aktPAXMgKDks6s8m4D+HYQCFcji6K55R5lZmeIw/topJ2a1X5fqddXQ+G/HPinwjFPFoGqvbRTnc8ZRZFLYxuAYEA+49K4z/hNfGX/Q267/AOB8v/xVH/Ca+Mv+ht13/wAD5f8A4qsfYvuebVwNWtHkqQi12bb/APbTavb681HUptQvrmSe6mcySTOcszHvU19rWs6nFFHqWrX14kX+rW4neQJ9AScVz/8AwmvjL/obdd/8D5f/AIqj/hNfGX/Q267/AOB8v/xVHsX3K+p1tPcjptq9P/JTon13W5Gu2k1jUGa9wLotcOTcY6eZz82O2c1al8YeLpihm8U61IY2LIXvpTtJUqSMtwcMw+hI71yf/Ca+Mv8Aobdd/wDA+X/4qj/hNfGX/Q267/4Hy/8AxVHsX3IeAqPenH7/AP7U6CDWtYtXtGttWvoWswwtjHO6mANndswflzk5x1zU9l4m8SabC8WneIdVs45HMrpb3ckYZz1YgEZJwOfauY/4TXxl/wBDbrv/AIHy/wDxVH/Ca+Mv+ht13/wPl/8AiqPYvuOWBqy3hH7/AP7U0iSTknJorN/4TXxl/wBDbrv/AIHy/wDxVH/Ca+Mv+ht13/wPl/8AiqPYvuafV8R2j97/APkTViilnnSCCN5ZZGCJGilmYk4AAHUmovEd0lhoQ8PZBvHuVubxOvkFFZY489n/AHkpcc4+QcMHUZk/i7xXc20ltc+J9ZmhlUpJHJeysrqRgggtggjtWNVwpcruzSlhJuSlVtZa2Wuvm7Lbtbe2vQKKKK1PSPQP2g/+TjfEX/bt/wCksVFH7Qf/ACcb4i/7dv8A0lioqZ/Ewj8KD9nz/k43w7/28/8ApLLXn9egfs+f8nG+Hf8At5/9JZa8/ql8IvtBRRWv4X8N6n4v8XWPhzR0ia8vHKoZX2IoClmZj6BVYnGTxwCcCgZ1Pww+GF5491Ga/v7j+zPDNhl9Q1OQhAoA3FELcbscknhB8x/hVtv4l/Euz1jTofA/ge3/ALM8HWGEjijBQ3hBzvfPO3d8wDck/O/zYC6PxZ8QaJ4c0ZfhB4JtvI0vTplk1G8E25724CjIcqcNg43bhw6KoCiMZ8frX4dEQlfVhRRU1ra3V9exWdlby3FxKwSOGJC7uT0AA5JpFkcZxMpOOCDz0r9Lv2cfgyfCfw3uPHWrxCfxF4kZ5UkK7fsli7F0RQeVMo2u3fBVT905+Yfgz+zvcJ4q0/xH8XLQaVpkb+fb6BdELd6iV+b54vvRQDq7MAWHyqPmyPufxd42n074cXklrMBc3LR6fbYwNs08ghDDHoXLf8Brnqu+x0UISk1FdSW20LTZbtiiLNLdp5s0hGd8auFUf7mTwOnU9zXlvwSx4i134ga1dJuvJNfJJbqI/K2oPoACBXoPhjxnpL/FzxVp9sY5IdNt9N0yGMn5UA84n8d2B+ArzrwP4mg8CftR654JvbSCCx1aMvZSsuBcHLSRE+p2tIn1QCsZNpo9PCU1OjXiviSTXonr+GvyPXUsIotVjtfLxJcKzrj+IoBn8cEH6CqenfYdK8br4VciCK6G63Rlx5UhUuYwP7jqGdPdJF7AVyvxP+I8uj6roWo6VCskmn607XMMYyzwfYyZQoHU7WBA/wBmuN+MnjdNY+G8XjbwzfKPEOgTx3O1XyWRWWTH+0pwkiH0LerCqv0Oehh3Uavonpfz/r8zD/bI+DdlrHhWT4j+FYQNT08KutpGuPtVso2/aPdo+Nx7p1+4K8WtPgve6h+zpG8ulILm7H2u0u+A6zgfIp77HUCP03kHtX2nceKLfXvAcWs6bbRXcF/ZJcravys0ciBjEfqrFfrXm2g6josXgz+xrC5+12LbvsLEgmROvkt/dmTGCpxu27hnJxpTfK7nM49Gfm8wKsVIII6g9qSvVPjZ8PZ/DXjK58Q6VE0/h7U5mmhuEGVgkY5eF/7pBzgHGR7g48rroOZqzsd78NPiXd+BdQmsL+3/ALT8NX+U1DTJAHVgw2l0DcbscEHhxwf4WW18UPhfaaHp8PjjwPcf2n4Nv8PHLGS7WRY42Pnnbu+UFuQfkf5sFvOK9K+E3jXTNIurvwX4ts4r7wvrzpDcpPLtS1kzgTDJCqPu7mGGGxWBygBe+jIatqjymiuu+JXga7+H3xButCn+a2bNxYymQO0luzMELYAw3ylWGBypxxgnkazatoNO4UUUUhhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAHoH7Qf/JxviL/t2/8ASWKij9oP/k43xF/27f8ApLFRUz+JhH4UH7Pn/Jxvh3/t5/8ASWWvP69A/Z8/5ON8O/8Abz/6Sy15/VL4RfaCvoPwHB/wqj9nbU/iHcxeVr+vYtNK3x/NEhzsYbozjOHmwSUdY4uhNeMeD/DN34x8daZ4Zsm2S3swRpMA+UgBZ3wSM7UDNjIJxgcmvSPj/wCJItT+I8fhnTktotJ8Pwi0t4rYoY1cqpkxtA27cJHsyQpi7ZIrSGnvEy1djyeiiigsKUEhgQcHtikooA+l/g49p4Q0PQvtSG58ReLDNqLGQ5NvpdmHZck8jzJoicd9iHtXuHxK8Sf2T4T8NMJSY7bXrbzifWJJHOf+BLmvlz4d6vLrvxg1fW4t7WOi+EotPgJ6RAQwxbfxYzN9Sa9b+Juu2954Z1jh5o9N1y31QxRHLSQM4Rwv/fR/BhXLKWjZ6uBpc0vT/O36nUTyax4P8NaZ4w+w6xF/bELzX1xNZOkf2jzRcQhWPLfKGXp2qz48v9J+IPhW01QzSWupafKlxZX1u2JIkdlIYHuASpx6rkV574k+MfxnuPCdjqPiCTwofDWp2qXdv4ce2kEn2YzSIuJkAO6IxDc+RtJXgnIr1jwp8KdV8TfCjSvFfh2WKe21C1LnS7hvKlVSSpVXxtDqQwPRWwGG3JUcsK3JG1U754epdYiPurZdNtPyVjK+FyeK/FfxUvNT8Qa7ptmLAvcPfm2E0crGJYBtiYgBmCO3cDBOMVznxF8M6JpOrsPhx8RNG8SXFzutX0WC5ga5AbczRCCPlk++y4GU57Hj0Dx58JNR1j4AoY9F1PTU0pftGuaJBN9nl1ryjEnEyhsReSrtgZ+bJIO3n580D9m7U7rxLFa3emadaC8W6eweKcBkXyj5EoZSCQshjySM/nWSqNy53Kx3YXB1JwlVo25Y73aX4Ht/w51+40r4DeCoLkyLcxXENiUkyrAC4eIgg+g/lWNZ6bov/CxPE9jNpljdQXDpfwl8qwEozztI3JvDA5ztJB9a5zTbu2h8b+FPA2l3MtxbaXM99c3Ujl2lCSPIZHJJOTlOvdgK4jWfGF5pnxSs9RtpQfJnuNNlRvuvEWWRAfYCXj6V30pXVzz8XhGpxgvileXy1t+C/E7TxumrXOhXGs+A7pYJkVobzQp4Umgn2jlGiYEbuDg9GwO5FfJ2o3p1HUZLtra1ty5z5drEIox9FHAr6KvfEs9l400rWLWQxwanc/ZJkJ6yYEkZ+obj6H2rwzx3bWdn8TfEFrp+37NHqM6xheir5h4HsOn4V2W9254dZWZz1FFFSYnvGnQf8Ld/Zem0hYvO8S+EcG12R5eWAKdqDbHn5o1ZAinLPDGWPNfPdei/CHxa/g/4taZfNLHHZ3TixvDK6xoIZGALMzA7QrBXJ4zsxkAmq3xi8Iv4N+L2qWCxRR2d25v7IRIsaCGRiQqopO0IwdAOM7M4AIonqrkLR2ODrQ0K2hvPFOm2dym+Ga6ijkXJG5S4BGRz0NZ9aXh2WKDxhpU00iRxpeQs7ucKoDgkknoKzLP0M8Tfs6/BfS/j7oXw6039m3XtQ0TVLMXFx4us9Z1H7PpzlpRscMzR5AjU8uD+8HynjPyF4p+CdzqX7WmufCP4RM/iKK3uiltM0yERxhFaTzZOFAjLFC3crjGSBX2p8RfFcGuftO+EvHPhP9qPwLongrS4LddW0ZPFik3pSeR5QLZCY33xsibmO4Y6fKK8r8K/H74P+HP+CjvijxlZTw23hTW9OGmHV4oCsX2n9yzTlQMhGaIqWxySHPBJrGLZbseI+Lf2UfiP4X8Fav4ostY8JeKrTRSw1aLw5qf2ubTtoy/nIUUgqASQMkAEkYBNN0b9lnxzqXgHRfFereK/AnheHXIBc6XZ+IdaFpc3sZAKtGu0g5DKcbgcMM4zXtngS9+HH7N3w8+KWqX3xe8K+NbvxNbG10nTNBu/tcs3EwRrgDiMkzDdngANgsSBV34S+K9L1f4c+DdG+IPxG+BPijwfp9nDHPZeLoDDrGmR7F328AcbWKYCB/4ggOelVzMVkfLXhv4P6jrnxE13wZq/jXwR4Qv9GZknm8S6utrbyur7CkUqqwc9+O3NaXxJ/Z88a/DXwVY+M7jVPDfiTwzeTfZ49a8Nah9sthJzhS21TztYZwRkYznAr2/4VL+y5J8f/ik3/FK/YwFPg4eLGZdLLbH8zd5nGzzdmN3zbPu85rpvi94+8Bal+wFrfhay8QfC6PX4tWhB0nwSq2ls5W4jLPBA7eZINucy7QGwccDJOZ3C2h4437GfxOjvfD0N14k8D2kWv2yz2Vxd6o8CPI4BS3AeIM8zBs7Y1bpyRkZ8a8feBPEfw1+IWo+C/Fdoltqlg4WRY33o6soZXRu6srAj68gHIr6s+PvjvwhrHxL/AGeZtH8ZaJf2ukLaNfyWmoRSpYsJbYsZSrERkBDndj7p9K8u/bK8Q+H/ABR+1ZqWr+Gdc03WdPextUW8025S4iZhGAQHQkEjoeacW3uDSKX7KXwl8N/GH48f8I/4vi1GTR7WwkvJEswyiR1ZQsckij92p3Mc5BJUAHJp/wAXPB/h29+IM/gH4c/A7xb4a8Y6bdSR3Ok295NrC3NuoJEyqVMgJ+VgRlCrZz0ruP2ZvHPg2P8AZ6+IPwqvfHNr4A8U65KtxYeIbqU28bKqoBE0wxsAKuDkjiZsZIIr6N0r4leCE8Em81r4pfCjUPjXp/h650+08RQ6msdpKGI2bp3CoXLBCV653lQFZqltpglofmPJHJFK0UqMjoSrIwwVI6gjsa+x/DXwK8CeGP2UvCvxJvfg94i+Lur68PPubfTNSntU06M5xhbcF2xgA5DfNuyVGBXx1cRyQ3ksUzo8iOVZkkEikg8kMpIYe4JBr61+COpeOvCngPSJfAH7VHw90WxmQT3fhzxVciAWcjHLxqkiN3ycoU3E+9VPYSPD/FumeCPFfxm07QvAejv8PbK6WO2uoPFd+whsbks29pJmBZYgNnLDI54rrNT/AGVfGsXgrVvE3hXxr8PfHNtpMJuL6Dwprf22aGMAksVKKOiscZycHANez/GH4g/s/fET9uDwHN4i1DTtV8OWNk1trurW6strcTYcwqzDlo1fblgSMNgkgGvXPBvj34P+FvGXjXSYfEHwI0XS7jT5P7Kl8L+XbXE0GSFS7uWZY3kOR+6Tccgk44zLk0h2R8VeDv2a/Hvjj4ML8TtI1Pw3Bov2w2kov75rZ7cKwDzSM6CNI1zkkvnHQEkA2PEX7NPjDwT8R/COgeKte8I2+l+JSZLLxD/aZGmOqqHYNMUBXKlcHbhi64J5x3tn4w8Mxf8ABKjUPCA8UaSmvy66JDo/22MXbx/aI23eTu3lflznGOM1N8dPGfhTUf2Q/gTp2l+JNI1LU9It4/t1jZ3sc09rtgjG2RFYshypGGA5FVd3CyLH7Wn7Ofgj4e62da8A634O8OaZa6VDLJ4ZvNbmfVbyVriRDLDDLvZ02lB94D92/HBzwXh39lfX/FtnZf8ACM/Fn4S6rqd5brPDotr4i33pJTeYzF5XDgZBGeCDzXpX7ZEfgz4na3YfGDwh8UfBOo6baaPa2MuiR6mo1WQm5kJMdvgngTgkMVICtxxXrui+JP2dvCHjbwNqXw8vvghZeF2Eaz3epwmXxBDOc4YSMR5AA2lpJmGPm4PAM8zSCyufP37NHw+1aHx58SfDWvfDTwnr+p6Pprx3Np4onEf2CRXYF4SLacM/HbaCMENXzBX6AeCPiF8PbL9sv47a1ceOPDVvpep6XGljeyanAkF2/lJkROW2yHOeFJ5r8/6qLuxMKKKKsQUUUUAFFFFABRRRQAUUUUAegftB/wDJxviL/t2/9JYqKP2g/wDk43xF/wBu3/pLFRUz+JhH4UH7Pn/Jxvh3/t5/9JZa8/r0D9nz/k43w7/28/8ApLLXn9UvhF9o9q/Zztrew17xN45v4Ip7PQNKeRlChpldstuiB4B2QyrnI+/joTjyrUL+71XV7rVL+Xzru7me4mk2hd7uxZjgAAZJPAGK9c8F/wCh/sW+NtQtP9Hu5dTS3kuIvkkeLNsPLLDkriSQY6YdvU141WuySFHdsKKKKRQUUUUAe7/CKG1tPg/eXuVW51jxJaaKX7qvkvIoPsxLj61peI9O1Kz0Aa8SJrGa1MckB/5aRHMZjPuFVee+3sQDXh2m+ItXsdBudCspnFvdXMF2FXO5J4dwjdMdGAkcfj7CvoXwf4vtvGmmQ+G9fe2gvtRgmtPLXCqt6jtIigZ482O4lAH9+Lb3ArKcdLM9HB4n2c4yXT8uv4Hunwdg0v4m/B/wvc6jptwl1o4ktTcT2IMVz822bBbKurlVZl6rIGP8R3fRWiaTDo+hWmmWA228AON33jlixOAAOSxPbFfnp8Kfj7q3wI8S6t4Y1ewj1LRTdefNYSSeVLEzAAzQuQRzgBlIIOAflOTX1VpH7VvwN1028Gra6+hXWFnSDW7RowhIyrCRN6dDwdw4NeHWozUnbY97F1pcqp391Nta6b/1/TPb2ubeS4eyiuYzcKm9o1b5lUnGSO1eX+P/AA/r9p4TurfwVpunWl1cRtC9++yGOwhI+eQBV3OwGdqjAzySMYNXUv2kPhFp8i2mheIE8S6jOcx6f4dhN1LK3uQAi+5ZhjvXz1+0l8Y/iLf6dpOg27w6Do2sCUXFpaS759i7ciWbjggnIQBeMbmrGNNykojwkKsfeivddjhPCUy6B4O1TUWuBNqes3A0+ymxhvKB4x1wPmBPPXHWvNdTvvtvj24JYeVJeu0WD98Lhc/kg/WpIdWv7i+ieOTy4ra3ZbX5SREWBCvjgYGWbrliFPQVzMNqkc15LJeTSTWkDSxXC4QKVIAGOcgk4x717lPVKJOIrQp4ida6fz+/z2+V76m3448XrPr+m22jsDFpMnnCT+GS4JBZh7LtVR67Se9cJLLJPO88zs8jsWZmOSxJySa09F1OWz8Qi4EUUqTEpNDIgZJEbqpBzx39RjIqbWdKtkgGo6TlrXO2ZA27yXz09dp4wT34PaurmblZny84px51LW+36mHRRRTMQr2n4yzP4v8Agp4D+IjLEbhkfTr6eSNUmmmweflGNgeGcgZGPMGAMnHi1ez6T/pv7Dfib7Z/pH2HWE+yed8/2fL2+fLz9zPmydMffb+8aa1TRMujPDKKKkt7ee7u4rW1gknnmcRxxRKWZ2JwFUDkkk4AFZFEdFXRpGrF71Bpd6WsMm7AgbNthtp8zj5MHjnHPFUqACiirN1p93Z2tlcXMWyK9hNxbtuB3oJHjJ4PHzxuMHB4z0IoArUV0LeBPGkV1Z29z4V1e0a9uI7S3a7tXt0klc4RA7gKCT6mueosAUUUUAFFFStbXC2aXbQSi3kdo0mKnYzKFLKD0JAdSR23D1FAEVFFatx4Z8SWeix6xd+H9Vg06RVdLyW0kWF1b7pDkbSDkY55zQBlUVoz6Brtro0Wr3Oi6jDp8uPLvJLZ1ifPTDkYP502bRNZt9Hi1e40i/i0+U4jvHt3WJz6K5GD+BoC5Qoqeaxvba0t7q4s54oLkM0EskZVJgp2koTwwBBBx3qa40fVrS7urW70u9gntEElzFLAyvApKgM4Iyoy6jJ/vD1FAFKiiigAooooAKKKKACiiigAooooAKKKKACiiigD0D9oP/k43xF/27f+ksVFH7Qf/JxviL/t2/8ASWKipn8TCPwoP2fP+TjfDv8A28/+kstef16B+z5/ycb4d/7ef/SWWvP6pfCL7R7n4g/5Mb8G/wDYYk/9Du68Yr2fxB/yY34N/wCwxJ/6Hd14xWr6Cj1CiiikUFFFaOhWEmpa9b2cUQld3AWM9HbsD7E4z7ZpNpK7KhCU5KEVds3dA0i5jQG2jP26VNzTf8+sZHGPSRh3/hU+p4pz6dJJNdNAG8q027fLJBBDdu+eGP4ivXdOfwrYOmgRavb3GpbsyrHl3llP3ugILZ6KOe1cnotzomkWslv4ginaSWdpDFGyYcMTjc4cbQMDgcnJ5Xv56ryqSeh9tWynDYGhCFSabd+a2tnayjptq/wOOvj4n+I+qx3OvpbzSacqxXGtSny2uI+qLIVH7yQjOCBuPJbgEjWlW01aS4SSGOxurcbIEf5SqYCpGf7wwFAYemeckVc13WLeK1cWsEVqkSFbe3j+4gb7xHqSfmJHf6Ut5YG9sLS2kYqzsWd1OCBGg5H/AAOQflVt2PFw9P3nbWy1v17L77a79e1vcbO18LfBn4LaHrujz211qniSwjuN8kxkdtuRI8i8BFRyyBQQCRjPysR4nrWsXGv+L3M8k2r6i/TGZh/wFFGW+nCjGMACoo9Cur65tIbm+upbaGSONUaQsEBfOB6AkscepPqTXU+DddTwv4X1jU9KYQarqKSTGZYCWEZZgAJeikNk7f4vlAyeKyo0lGTb1Z1YnFVPq0VD3Y3svPv92nq7t9LclJNq94WtItKC4fy2e7Zcbun3RxweOvWsjTkkh1W7s9WtIoFaOSK4jUfKo2khx/ukBh+XeuqtrlHjlQLuKytDGM8ttAySfzyaoeJdNu7pHubgQq0sYIIYKzbPvZGd2CuSeOqit4T5ZrsYPCqrhpSim5pr0s+/byZwtijG5DqPm+6v+8eB+XX8K3tOjuYhM9tGJXRdk0bcrOnKkN9duc9ia2/DHhtTN9rlAfb8qjGFz3wK1/DmkMvjTVrMLxGA2PZtpH8zUVcQrtroell/D8kqarL4216e62vxR5jqdpHa3mbcs1vKN8Rbrj0PuDkH6VSr0bx74UbS4zcRxnyJ2MiYH+rkAyy/RlGfqtec11UaqqR5kfN5nl9TAYiWHqbr8ugV7R8Gf+SP/Fj/ALA3/tC5rxevaPgz/wAkf+LH/YG/9oXNbx3POnseF1veCLiC0+J3hy6up44IIdUtpJJZWCqiiVSWYngAAZJNYNFYlHqdp4x0S+0jV7aUyW1xfWDNqksjKoupYzHHGIucsxXzHOeSztxgZqbUf+EP/ta2/tb/AIRr+z/7ci+w/wBl7M/2fh9/2jyvnx/qP9Z+8+/Xk1FVzE8p6if7E/tTSf7Y/wCEU/trZff8efkfYf8AVL9k87yv3WfM8zr22b+M1g/EG4jn/wCEbiE+kyXEGkmO5XSmjMMcv2u4YqBH8oOGBIXj5sjgiuMoouOx7RrM+nr8ddN15bXwjbaf/wAJNBcHVrLWlmmlj8/O+SP7S4RcfMT5a4wOg4PN2Z0MeMNJl0uy0a60f7NIIYbu4tYJo32YZrg3B2NIrEMA2UYDCgcged0UcwuU9bhsrZYPFNzplx4Tv7tL/TUhu7+1s4bdA8Fw0kaD/UAjaAdp2tsLDLbara1qHgZPF3hzTbS20j/hHXleS/mt4FMpX7fcbVaTBkVRGI8DhihXOflrzJbm4WzktFnlW3kdZHhDEIzKGCsR0JAdwD23H1NRUcwcp63ez6K3i7SCnhfw8u1LkGVdb0qSOQFAEZlWOOFShO5RKuXyQc4453x3Ho0WlWy2F/pd7eHUrlppbK3t4CIzbWhVSsHybVfzlBX5Swcjqa4aihyBItXHn/2dZ+Z9l8ra/l+V5fmY3HPmbfmznpv5x04r1u71LSI/DklxOvh9LaXw5ZWzXltqSyXtxIkUGbdoPNbaNybSfLQgDO718aopJ2G1c9W1G8hh8TeLPE9z4l0690fVbS6itbaO7V5ZvNUiCMwA7o/KJRvmAC+XwTxmjdRQ674ZkutW1bSbW7aytbW2ntNVXF0UMUaxz25JKBVG4sQigpnnNeb0U+YXKen+LtR8Jax4Vv8ASdI1y5mbRnifT47u2jgjMSqsEqxOJWMjORHL91T8rHHOBreJ9f0TXD4+v31ayOoQpLYW585T9vt2vYpIjGc/OUCSA4z8hjxwprxqijmDlCiiipKCiiigAooooAKKKKACiiigAooooAKKKKAPQP2g/wDk43xF/wBu3/pLFRR+0H/ycb4i/wC3b/0lioqZ/Ewj8KD9nz/k43w7/wBvP/pLLXn9egfs+f8AJxvh3/t5/wDSWWvP6pfCL7R7j4d/039h3xL9s/0j7DrCfZPO+f7PlrfPl5+5nzZOmPvt/eNeNV7H+zqf7Xbxr4G/1P8AbOjt/pn3vJ27ovucbv8Aj4z1H3Md8jyC4t7i0vJbS7gkguIXMcsUqlXRgcFWB5BBGCDWu6TFHdojooopFBVyx1G407zZLRvLmkQxiUfeQHg49CRkZ9Cap0Umk1ZlQnKD5ouzO68NWmnWnhv7WJCmpXKuyzZwY4gSmyPPAZyGDMei9OpqeW7tbCGFILG3kvJY1KoAG2k9iT1AGCefX0r0bwZ+zN8TfF3wdt/FkH9n2mIWudMsJ3Zbm6iJ3A8DagbkruOSDngEE8Jpnw2+JnjDx3H4a0vw1e/2xFFIfJmUwJAi8F2d8KFBIHXksAM5rinOLm7S2PdpV+XDxiqdn3769fPz/DtBN4J8ZeI/D02u6T4VvNTtrA5uZ9JsXdEAILAsq4PHXHI74puk38Vxq1u8lzhVifYoU7iGb5scegFfof4P8WWPgv4daB4TutETQdSsbMQTacHVljmjiWVlV04bzUEjJIOrKwPIIr4+/actPDcXxRh1/wAOX5jvLoyCeGFAsckqN81ymMbC6tCWUjkliOM55aeI9pLka9DempYeTrKOml/vT/Q4m7mexijdHRDBtlCyFQxYrzj16DjJxTLMW0vhaOOaBQYrVSjiVyNzKF3Y3FQfU49qyLDVlnlSXUBs8tWBjTCggg42gkAc4/WoHuJl02AB1l8leUUg9eWIx710qm+4VMwpNOMYXWtr2e6S6rS1unbz0Xw1cFraNpuZWnkjI9AuSfzP9K6/VotGudI0jUlutOja3B/tKzvLgeZO6SnJROXYPGV4AABBrzzQrjdr8gVsx5edf+BADNdlpupj7RMI4knjysUiMrHcc8bSnzBge4z1IINVLTUxwTc7Ur7u3yenVpel2cVFr+qeHPFEotLy4nt4Ziqw3JYCRM8ZU8qSMH1FdjceN7PRL/Vtb01EuLq/jtkto5OiAR7mZsehIGO5+lcp4wt0nuZNUQxLIs32WWOIkqAF/d4JAOQo2nIByucc4HK1pPDwq2kRRzjGZfzUVLVPS+tnZxdt+j++zPTrD4hS+KLG48P+JorcSXA/0W7iTYElHKBh0wTxkdM88dPNZ4zFcPGQVKsRg9RUYJByDg06SR5ZTJIxZ2OST1J9aunRVNvl2ZyY7Mq2OhF4h8046X6tdn6P8xtez+Fv9D/Ys8b39n/o93LqUdvJcRfJI8W62HllhyVxJIMdMO3qa8Yr2n4rQXHhX9mv4f8Agy7gkNxcPJqUryqYngYAsYWjOTkG6wSSP9X0543WibPLl0R4VRRRWRQUVeh09PKWS8uDCGGVRE3uQehIyAAfrnocYOak+xab/wA/11/4DL/8cquViujNorS+xab/AM/11/4DL/8AHKPsWm/8/wBdf+Ay/wDxyjlYXRm0VpfYtN/5/rr/AMBl/wDjlH2LTf8An+uv/AZf/jlHKwujNorS+xab/wA/11/4DL/8co+xab/z/XX/AIDL/wDHKOVhdGbRWl9i03/n+uv/AAGX/wCOUfYtN/5/rr/wGX/45RysLozaK0vsWm/8/wBdf+Ay/wDxyj7Fpv8Az/XX/gMv/wAco5WF0ZtFaX2LTf8An+uv/AZf/jlH2LTf+f66/wDAZf8A45RysLozaK0vsWm/8/11/wCAy/8Axyj7Fpv/AD/XX/gMv/xyjlYXRm0VpfYtN/5/rr/wGX/45R9i03/n+uv/AAGX/wCOUcrC6M2itL7Fpv8Az/XX/gMv/wAco+xab/z/AF1/4DL/APHKOVhdGbRWl9i03/n+uv8AwGX/AOOUfYtN/wCf66/8Bl/+OUcrC6M2itL7Fpv/AD/XX/gMv/xyj7Fpv/P9df8AgMv/AMco5WF0ZtFaX2LTf+f66/8AAZf/AI5R9i03/n+uv/AZf/jlHKwujNorSNhYsMR6hKG7GaDav4lWY/oaoTQyQTNFKu116jr9CD3HfPek00CYyiiikM9A/aD/AOTjfEX/AG7f+ksVFH7Qf/JxviL/ALdv/SWKipn8TCPwoP2fP+TjfDv/AG8/+kstef16B+z5/wAnG+Hf+3n/ANJZa8/ql8IvtHS/D/xT/wAIV8S9I8TND50VpN++QLuYxOpSTaMj5tjNtycZxniu2+PXhSXw58X7y9itvLsNX/02B13spc/64Fm43eZuYqCQA6dMgDySvoTRF/4W5+y9Lo4i87xL4R2/ZtkeXlgCnYg2x/xRqyBFOWeGNmPNaQ1VhS0dzweiiigoK9x/Zl+CT/Fv4lfa9YgkHhbR2WbUH5UXDHlLZT6vgliOiBu5FeTeGfDGteLvF2m+G9CsnudQ1GYQ28eMBiTySeygAknoACT0r9Uvhb4G0T4W/C/TvB+jFZFt1MlzdbcG7uGx5kp+pAAHZVUdq48ZiPYwst2deEw7rS8kdhFaW2nw+YSscUKZCp8qoqjoAOMADgdsVwPw9tlvZ9c8S28eUvL97aAj+GKEnIHp+8eXPuvtWX8dvirp/wAOvhRqV+8qvfTRmG1t8/NLK3CIB15P6Bj2rufh5oL+E/hR4e8O3LmS6s7CJbmQ9ZJ2G+Zj9ZGc14KXutn0Tm6cbPd/kv8Ag/kP1fw14Z1GO3u/E1jaSXIxbRTbmRgXOFVSCDnJ+U9QSSMZNUNS+Enw61nwXP4X1LwtZXenTHc3nAtMGGdriYnzAy5IBDcDjpxWB8XddFnL4Y0+K4EdxNqgmQZwT5cUjDH5Z/Cur8N+J4dY01ZSQlwmBLH6H1HsaSbjqhzoVJUlPo+h8K/Gr9nXX/hLdPrmhWo1/wAJu/Fw0QNzZE9EmA6jsJFGCeCFJGfH4datb3SrizjxA0gWSBgowJV5UZHZgSv4iv1K8bR2eq/DTxBY3YVoZdNuFbd0H7tiD+BAP4V+Yvijw9ZWviTd5ywJerHJE+MCCVwflcdlLAg91JB7mvRo4h1FyzHg8FJJ1qb2fK09mpJr5dr9G1tucbBeG31Sa5VPLeeLbtHG05yTjsec10enXYsNENyDyW3qPU9F/lmuavLe4XWFgvohDdrI6yD+6T/TnitwwNPJHCSEt4xgAck16Cs0eHeVGq4rRp27P/gFlxFriXMV5L++v2V45ScBJgG2lvZi232zntXEyRvFM0UiMjoSrKwwQR1Br0GLWdMt/Dl9pbW3nqi7kCYwpOc5bqeQDgd81z+uW4v/ABRIZGZJ2jj87yoy+6by138D3zk+uaujJqLTWx15vRjUlTxEJXdRXfSzvZ793qc5RVmWxuILZZpVVQzbQpYbv++eoqt0OK2TT2PDlCUfiVjrPhr4Ul8ZfE/StF+zefaGYTXoO8KLdCDJuZeVyPlB4+ZlGRnNaPx28U/8JR8atS2Q+XBpf/EqjyuGbynbeW5IP7xpMEY+XbkA5rvPBq/8Kn/Z11P4h3EXla/ruLTSt8fzRKc7GG6M4zh5sHKOscXQmvnqnLRWMlq7hVzS40k1RPMUOqK8u1hkMUQsAR3BI59qp1e0j/kJn/rhN/6KaojuU9h7MzuzuxZmOSxOST60lFWtM0671jW7PSdPiM13eTpbwRjq7uwVR+JIrURVor2Lx/8ACu00vxN4bgtdNvfC2mXt2+jT3msxSxK8sLgG8/e4wkqOjgZCghwCAOM66+GFjapJavqNzYxPqem2g1DXLAWbIlwt3udClzJE0X+jj5iTkjAZArbwDy6ivVoPh/4Q0ubxXb+IrvxPDFZaHDf2t1No8SSKzX0EJkjjW8KSrh9gO/B3ueDGoahr/wALLfw/4FfWLrxdpX9qR2sF2+lm6tN7LMEIRFW4MxkCyBiGhUYViGPGQLnnFFd742+H2meF4tc/svxNLq0uh6yNGv1ksPswEjecUaM+Y24f6PIGyFwcY3A5q7oPhDQdc+BTXEVqy+KpdRvWs5xK2J4ra3tpHttmdu4rNK6kDcTGF53CgLnmtFe0Xnwc07V/HXiew0q/k0ZLfWLuw0u3uPs/2eYRchBJNdLM7DIBCRSEZUknOBy2l/DvTL3RLd7zxPJa6tc6Nea5BYpYGSMwwRzOEaXzBh38huNpAU5yT8pBXOAor0LVvhiNP+GB8Vw6vJ9pghtp7vTLxLaKWNJtoVlSO5kl25dcGSKPIYH2rV+FHwzPjHw9qN9ceG9U1VbucaPYz2cUrJY3Dxs/2mUpwERvJUh/l2ysf4cgHc8oorqvFeh2mj+FPCM8dm1ve3thcS325my0qX1xCMgnCkLGi4GOnrk102p+A2bwPo1joXhmC71d7aO41K6W9b7RZSSbpEE6FvKSBoDGwbAwSQzggrQB5fRXe/C3RfDGs3/iFfFcG6zt9J3xz+a6fZJZLu3gE/ykbtgmZtpyDjkV0978LtKi0nwn4Vki+w+J7rXo9J1a/wBzSiJ5lR1QR7gp8tZEzjBLbgT0wCueN0V6D4H8L2stjba/e+TdRXlp4htxaTQBlje10rzklBJOTunUjgbTGCDk8afiPwV4SjfU08NXVw8tr4Y03UpYtQtfJSOSf+zxvjlFyRuc3Ts29diZZVB+V0BnldFer+EfCWg6Z4X8T3fi5PB891ZXVhDBcajqF1d2aLMtyzKH0t2LOfKTqSBtOcE8mneEfBlx4TvdY16WSyjk8OHVbd9Is5J/Jb+2jabts1yu87AEAO0bHyRvTdICueUUV1974G+xtrgGqbxpeh2OtZ8jHm/aTafuvvfLt+2fe5z5fQbuK3jzw1pXhDxtqHhrTtcn1abTrqa0upnsxbIHjcr8n7xi3TnIGDkDcOSDOZooooAKKKKACn3KiXRPMb70Eyop/wBlwxIPsCuR/vN60ypJf+Rfn/6+Iv8A0GSk9gMuiiisij0D9oP/AJON8Rf9u3/pLFRR+0H/AMnG+Iv+3b/0lioqZ/Ewj8KD9nz/AJON8O/9vP8A6Sy15/XoH7Pn/Jxvh3/t5/8ASWWvP6pfCL7QV0/w+8Xap4I+IFjr2kwNdSKTFJZh2UXUbcGM7evYjIIDKpwcYrmK9B+EnjOfwZ4tmurawsbx7iIRPFcwq5kjzlkVj93OB65xg5HFF7alRjzvl7nQ/GTwHY6Rex+NvCptD4Z1aQLHDADGbScplozG3K52u2MDYdyFVwufPtD02O81BZL1lhsosvLLKG2ED+HIHUnA/HtXuHjLTpZvCF/40+H9xcf8Itctu1DSYRtfSZAQdjxcjyw2Crj7vGeADXmFraXWqzbLVr2+UHeViwT05OB09zilKt5HVTwt3yp3fa2p0p8R3Wma1pE3h28urA6eBPbTwXB2xlcZVMEAZGQQeoJzuzivrnxD+0t4I0n4UxeNFu2CXG5I7MgGfzh96EJnlhkZP3QCCTgjPwr8+ms9pHbMQ+ODzk+h/HBwP6VxXiS8iu9RS2hlFw8JKtOGyshOOB7Dpnv9MVw1sPGok29j03j3Tk5cqu/KyXRWXp/Xf3LwZ4n8SftD/tgeEW8Th00eLUPtiWe7MUcMP71hk/fZtgUnvnAAGBX6Sz6mIoXlmcIBlnJ7dzX5dzJp2keGV06SzZLu1lMcXkkvGFDE5Einnkk9M9TntXo0H7QHxBsPhUng9YYLoQWrRJrUksjzInLLI/UEqpAGT/Cuc4rCth3Oyj0OimlB81WXM2k21rby20enoe6eMdbtvFXiTUNe1C5FvpOnI0VnckgeSUOZLhT22lQoPfa/ZuY/hz8QYPEugx67pMwiuYXMNzDjBRx6r/dYYYexx1Br4qTxlqtz4Zg0C71O7NnBkxwyzu8Oc55Tsc8+mewq14L8c6r4L8Tyarp2pGMzIY5kKebHKvYOhIyAcEEEEH2JFOWXy5X3O6nnGGtCKej38vU+5vit8UrWw+E1/p24QapqiGzt1Jypzje3XO0LnP8AvAZya+NvEGqWusPqDagrSXZxGJWkyGO9mchu/O0DdzycYrI8SeKtc8U3z6ne3st9Mw2ic4AjX+6iLwg9sD15Nc6Z7jyPKbhQMZPHFb4bDSpqzZx5lisK+VUVeServpbt287/ACJr+SXURHqNz89xCRFPzguuMbifXkH8TUP2m4Yi1spZn3HaRINuz2JPf2FJDe28FreI37x5IwqAdN2ep9gM/jitv4fQaBr/AMR9K0rxl4hOh6VPNtm1IRq3k8HBOeACcAsenU8V1cvJG/Y83FYiOJqRnf3nv63tq/NWKCWd7ZIkbxwOZJQw2ljgryBnHer9tp2rWd0bqILMx5c8/ODznn35r7N07wx+y34F18eENbgsbrxCwR4JfFUzyw3Ub/ckimAMADDocDByD0rx34//AAo8IeFPDL+IfAsEumXVrchb+zjnceSr9AY2ZinOCpVijKcqTyByQxKlJR2udapxcX7WPNyro7NLVvpr8zylJba8kWO9hMUw5TOAc+zD/GmeG/COial8R9PtvEGqQ2emGVrm7mvHKrNGp3GPcMbCQCCxIwCW7YrL8Nw+Idct7944DcWdhB51xdzEKLfsnznqWIwF5J57AkW7+43Rpel1KgqkY/vHdyfcYBH4muuN4yVzgqqnKD9k3yvo90/yfqulyr8WPHaeN/Gw/s2KO20HTENlpdvBuWPyVOBIEIAUsAvAUYVUU525PB1JOIxdSCLPlhyFz6Z4qOtW7u55qVtAq9pH/ITP/XCb/wBFNVGnwyyQXEc8TbZI2DqcZwQcihOzBl2rukavqGhazBq2lXH2e8gJMUuxWKEgjIDAjOCcHqDgjBANV4xBdrvglhhf+KGWTZt91ZuCPbOfrjJf9jk/572f/gXF/wDFVqSXdM8SatpFi9jZy272r3MV41vdWsVzG0sYdUYpKrA4EjgjGDnkHAxqXXxE8V3oSO5utPe2jlhlSy/sy1FqrQ+d5YEAj8sKDczkrtwxckgnBHPfY5P+e9n/AOBcX/xVH2OT/nvZ/wDgXF/8VQLQ6EfEXxWNZ/tL7VYbhaGw+y/2Za/ZPIMnmeX9m8vydvmfPjZ97nrzVa98aeINS8OJomoS2F1bpGkKTTadbPdJGhGxFuTH5yqAAAA+Nvy9OKx/scn/AD3s/wDwLi/+Ko+xyf8APez/APAuL/4qgNC/qPijXdWOrnUL7zv7Yv11O+/dIvnXC+bh+ANv+vl4XA+bpwMJY+Jtd0y202Cw1B4E02+bUrTYq5iuGEYLg4yeIY+DkfL05OaP2OT/AJ72f/gXF/8AFUfY5P8AnvZ/+BcX/wAVQGh1kHxY8e22o3N/FrUJuri8lv2newt3dJpceY0bNGTGHwAyptUgYIq9onxQfRPhvP4ci065uL2SzudPju7ieFo4IJwwdEUQecBh3O3zim47tua4X7HJ/wA97P8A8C4v/iqPscn/AD3s/wDwLi/+KoDQ3734g+LdQ8My6Bd6lC9jNDDBMFs4EknSIr5QklVA7ldigFmJAGM4JFY82s6ncaVp+myXR+y6eZGtY0UL5bOwZmyACSSBycnAA6AVB9jk/wCe9n/4Fxf/ABVH2OT/AJ72f/gXF/8AFUBoaPiHxVr3iu7iudevVupYvN2MIY4seZM8z8IoBzJK7f8AAvTArWtvif42s7CO0g1WDaluLMyPYW7yyW4XaIJJWjLyRbQB5bkrgAY4Fcx9jk/572f/AIFxf/FUfY5P+e9n/wCBcX/xVAaEtjq1/p1rqFvZT+VFqFv9kul2KfMi8xJdvI4+eJDkYPGOhIqey8R63p1laWljfvbxWl6NRt/LVQ0dwAoEgbGcjavGccVT+xyf897P/wAC4v8A4qj7HJ/z3s//AALi/wDiqAujor34jeL782/n6jbotul2kMdtY28EcYu4RDcYSOML86DB44OWGGJNVrnxv4ku9F/sqe8t2tzYrprstnAsslurxOkbyhA7hTbw7dzEqFwMAkHG+xyf897P/wAC4v8A4qj7HJ/z3s//AALi/wDiqA0JYdW1C30C70WG422N5NFcTw7FO94g4jOcZGBLJwDg7uc4GNPTfG3iTSvsq2t5btHbWTadHBc2cFxEbdp2uDG8ciMsg81i/wAwJBxjoMY/2OT/AJ72f/gXF/8AFUfY5P8AnvZ/+BcX/wAVQGhuz+P/ABZc+FpfD02oxNYTWsVlKotIRJLDE6PGjyhN7BDGm3LHaBtGASDjatql/rmv32tapP599fXEl1czbVXzJHYszYUADJJOAAKj+xyf897P/wAC4v8A4qj7HJ/z3s//AALi/wDiqA0K9FWPscn/AD3s/wDwLi/+Ko+xyf8APez/APAuL/4qgLleirH2OT/nvZ/+BcX/AMVR9jk/572f/gXF/wDFUBcr1JL/AMi/P/18Rf8AoMlSG12DdLd2aIOrCdXx+CEk/gKo3l0swSGEEQRkld33mJxlj6ZwOOgwOvJKk7Ie5VooorIo9A/aD/5ON8Rf9u3/AKSxUUftB/8AJxviL/t2/wDSWKipn8TCPwoP2fP+TjfDv/bz/wCkstef16B+z5/ycb4d/wC3n/0llrz+qXwi+0FKrMjh0YqynII6g0lFAzvvDnxK1bTNXguROLaYAJJNHkLOOg81c4P1x3OQcmu5TT7LxK8o8Maonh+WZjJJZ20I8tpCcg/KwITPQDIHYDpXhFaWm69qmkurWVy6bDlefun29Klwja1jtpY2pGo5yk7vdrRv5nXeLrnxP4Z02/s9cu7sTSr5KOz7lmZuNytjnCg89RwDiuN0DQNu3Ub9BkDzIYHQOGx3kUkfL04xznnA6+x6aPEXjTwrY+JJILDUZ4PNSO1iO6WHbjdKIm4aQ46qSwUDAGc1y+oXdpPEzLC80u7f5ao+5z9MZz+tYctuljtrTVeXPKo5Jbcz1/P8jLt4JrqJn82WIH7qxFlDn12noOfarOoyXtt4cvbeW/lSZ0UvZRZCIm4DMmcfMcjCgHAPJHSun0bS/EbW97dWthLpUhRRHeXcRQxQ9WcKRkYAABwAMk5HWsbxFF4P07wzdR2us3GqavPhcudwHzgliV4zgdyaqMW5K60NFKEKMpQl7zT62stV31k+i6J9dzz+iiius8EVWZTlSQfUcUrO7n5mLfU5ptFABW9Z+F7mSwW+1C5i0+GRC8KSAtNPxxsjHOD6nA96z9LmtLW8F3dxiURcpERkM3bPsOtd1onhnxz8QtSjudK8LvJDcf8AMRvAyWwQPsJ3nCttJOQu5uDwcGs5c7dondh6eHUHUry16LX73b8tL9zjWsdSuxEl3eLiFBFGs8+diAk7QOcDJJx7mtGWxS53i81C6ugkSw2+9ndo1ByAOMFeTgcAZr1U+EPhJ8KZEu/iDrA8Qa+m1/7E09d0cTfu2wY8jOMkgysquhPyEivLfHPxM1nxpPFbpa2ui6TbqY7fTNOXy4wm7K+YRjewAQdAo25Crk5coPqznp1YJ7X/AK8zUfXJ7LQRo1m89vo4kaRbaWRYkdjgb5MY8xsKASR2wABXLaprMZd/IlE0xG0OoIjiH+znkn37VzxJJyTmis+TuayxKt7i+93+7ZL7goooqzkCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD0D9oP8A5ON8Rf8Abt/6SxUUftB/8nG+Iv8At2/9JYqKmfxMI/Cg/Z8/5ON8O/8Abz/6Sy15/XoH7Pn/ACcb4d/7ef8A0llrz+qXwi+0FFFFAwooooA0tI1/WdBnM2kalcWjHr5bcN9R0NdY/wAaPiM9i1q3iKXDLtLhFD4/3gMiuBooGm0dz4U+LnjfwhrM2oWOox3Yn/19vfR+ZHJgNjphl5bPysMkDOQMV3c3xl+G/i+UH4ifC+NpyivLqGlyjzpplUJzzG4TGcAyNjCjBxkeF0VSm0S4p6nuf9k/sz3o+2f8Jl4j07z/AN79i8p2+z7ufLz5D525xnc3T7x60v8Awpn4f/8ARdfDX5Qf/JFeF0VXP3QuV9z3T/hTPw//AOi6+Gvyg/8Akik/4Rb9nKzP2O/+JOtT3cP7uaW1hYxO44ZkxbsNpIJGGYYxyeteGUUc/kHK+57rB8Vvg74Vu4rvwZ8KpbqcuJHl1WcB4GQ5RoixmIOSSSNvRevGOT8U/Hb4j+KPLT+2P7FgjwfK0YvbbmG75i+4ueGxt3beAcZGa82oqXNsOVBRRRUlBRRRQAUUUUAFa/hVbJ/HGkJqMKy2rXkSyIxAUgsB82QQV9R3GRxnNZFFCBnr+iaaLPxRqiW8F9psEWuWX+hy7CsgMz4YfuwQuOVAOMHq1VrXw5otr8VbHz7WTU7a/wDtTfaZGQ27y7XPlhCp5U/LhiDuwcDGD5TRWnP5EcnmegaP4I0zUoVkuIdVtmku3t5YzImdNVVBDz5QZyfZPrmrt9oNpqHwr0e582a7uLKznMVrasFZ189synIOUXHIAzyOg5rzKilzLsPlfc7HT/BbpBqqarY391qVhJHH/ZWnyp5pDjO/IV8qBjoD17VZtPBel3HhdNQee8UvZzXL3e9fItpEJAgcbcljj1B54BrhaKV12Cz7no0vg7wra6NNdT/2xJJbafaXsmy4jVXMxClVBjOACc5Oar33hXTtH1w6DKTMLzVlt4pXA8wQoAWwccFmkVc+qGuBqRridkiRp5CsIxGCxwgzn5fTkk8dzT5l2Dlfc9Mu9I0648GS3UulQwRCCORZ44o40jLQSSfK4XexV0SMh2bJJ6EjGfd+C9AXSJPIub+G7h0211CSaaRGi/esAy7QgIAznO6uSvfEGrahaNb3dxG6uQZHEEaySkdN7hQz/wDAiazKHJdhKLPRtY8C+HNJvLASX2pNby30dtJMI32SRsP9YkhiCAg/whnyO9LqPw90jS9IvLm61SYSWSiC4G5cJcO0Zj7cpskJPfKnkV5xRRzLsPlfc9fuPCWnWfhSfQg17ZWc+tW8Rv7x1ZJl2H95HhQApzjqe3PWsQeA9IbVdPgll1Cxa4+05sLh0NxJ5QyhQ7QBv7ZH0zXndFDkuwlF9z1jWvDVpfW+kW01pqUT2ei+bFpe9ftUreafkzs6jJJ+TOO1UrH4eaLc67qVgtzfztb+V5QUlEQsm5llmWKRVZTxyB/SvNKKOZdg5X3PQLL4fwXXgW61iUyxTQ2c12ksc/mxP5ZPykCIKuQP+ehPfGOmrbeHtP0TwJrk0UOoXEE+m20kl9vXyZtzqzJH8vBHTkn3A7+VUUcy7DcW+p6UPh94fTVbS1n1iZV1CR57Fg6/vLURhlzhSd7M20YH8LYB4FVpPBmgWuqagLl9Wa3tdKN+YCrQSBw4XbulhXcv+0EH6V59RRzLsHK+56c/hjQ7DQPE1pb6ZeajMkVldQEOhnjjdSx2kRnAU53EDBGPu4yaFx4Cs49CutWjN81omm211DPuUo8sjAOudvIGTwORxmuAoo5l2Dlfc9GbwT4al8c6poNtPqKf2dEW2yzB5Lpvl4QJCSoGTnCuTxwOa4/xLpdto3ia40+zluJIY9pU3MLwyDKg4ZXVTxnrgZ696yaKTafQEmuoUUUVJQUUUUAFFFFAHoH7Qf8Aycb4i/7dv/SWKij9oP8A5ON8Rf8Abt/6SxUVM/iYR+FHKeBPEz+DviTo3iVXlVLO6V5xEiu7Qn5ZVUNxkxs4HTr1HWt34o+Erfwf8Rbmz02SKbR7xF1DTJopA6PbS5KbW3MSFIZAxOW27uhFcDXd+DvFWiT6fB4L+IK3M/hrzvMtry2P+k6S7Eb3iJBzE/8AHHgj+NRuHzOL6MGupyFFemzfBbWdVlE/w71zR/GdiUSRpLO6jgntwygr58MjgxkneAMk/IchTxUf/Cgfi3/0Kf8A5P23/wAcq+V9ieZHm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcsuwcy7nm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcsuwcy7nm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcsuwcy7nm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcsuwcy7nm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcsuwcy7nm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcsuwcy7nm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcsuwcy7nm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcsuwcy7nm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcsuwcy7nm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcsuwcy7nm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcsuwcy7nm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcsuwcy7nm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcsuwcy7nm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcsuwcy7nm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcsuwcy7nm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcsuwcy7nm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcsuwcy7nm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcsuwcy7nm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcsuwcy7nm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcsuwcy7nm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcsuwcy7nm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcsuwcy7nm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcsuwcy7nm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcsuwcy7nm1dl8LvCVv4w+IttZ6lJFDo9mjahqc0sgREtosF9zblIDEqhYHK7t3QGtuH4LazpUpn+ImuaP4MsQjyLJeXUc89wFUlvIhjcmQg7ARkH5xgMeKwfGPirRINPn8F/D5bmDw153mXN5cn/AEnVnUnY8pAGIk/gjwB/Gw3H5V8OrHe+iMXx34mfxj8Sda8Ss8rJeXTPAJUVHWEfLErBeMiNUB69Op60Vz1FZN31LSsFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAH//Z",
	"keren": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwMDAgQDAwMEBAQFBgoGBgUFBgwICQcKDgwPDg4MDQ0PERYTDxAVEQ0NExoTFRcYGRkZDxIbHRsYHRYYGRj/2wBDAQQEBAYFBgsGBgsYEA0QGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBj/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4Poor1bTtOT4Oxab4g8QaPFeeMrpFvNN0q+jbyNNh3EC4nAILTMVYJGCPLwWbDBVHfQoOo227RW77f8HsjzMfj1hUoxXNUl8Mdm2vyS6vp5tpPnvD/wAIviT4osvtmj+Eb97cokiTXO21SVHBKtG0pUOCBnK56j1Gdj/hnv4v/wDQof8AlQtf/jtGjSeJ/jZ8VtN0PxN4quTLdeb5c8kYeO32wljshUqq7vKUHbjJ5OTXqn/DJf8A1P8A/wCUr/7dXrYbLY4mLlRpykk7X5ox/Bp/mz4zN+KamU1Y0cwxdKlOSUuX2VWpZXa+JTjfVP7MX5Hlf/DPfxf/AOhQ/wDKha//AB2j/hnv4v8A/Qof+VC1/wDjteqf8Ml/9T//AOUr/wC3Uf8ADJf/AFP/AP5Sv/t1dH9h1P8AnxL/AMDh/wDInlf8RCwv/Qxpf+E9b/5YeV/8M9/F/wD6FD/yoWv/AMdo/wCGe/i//wBCh/5ULX/47Xqn/DJf/U//APlK/wDt1H/DJf8A1P8A/wCUr/7dR/YdT/nxL/wOH/yIf8RCwv8A0MaX/hPW/wDlh5X/AMM9/F//AKFD/wAqFr/8do/4Z7+L/wD0KH/lQtf/AI7Xqn/DJf8A1P8A/wCUr/7dR/wyX/1P/wD5Sv8A7dR/YdT/AJ8S/wDA4f8AyIf8RCwv/Qxpf+E9b/5YeV/8M9/F/wD6FD/yoWv/AMdo/wCGe/i//wBCh/5ULX/47Xqn/DJf/U//APlK/wDt1H/DJf8A1P8A/wCUr/7dR/YdT/nxL/wOH/yIf8RCwv8A0MaX/hPW/wDlh5X/AMM9/F//AKFD/wAqFr/8do/4Z7+L/wD0KH/lQtf/AI7Xqn/DJf8A1P8A/wCUr/7dR/wyX/1P/wD5Sv8A7dR/YdT/AJ8S/wDA4f8AyIf8RCwv/Qxpf+E9b/5YeV/8M9/F/wD6FD/yoWv/AMdo/wCGe/i//wBCh/5ULX/47Xqn/DJf/U//APlK/wDt1H/DJf8A1P8A/wCUr/7dR/YdT/nxL/wOH/yIf8RCwv8A0MaX/hPW/wDlh5X/AMM9/F//AKFD/wAqFr/8do/4Z7+L/wD0KH/lQtf/AI7Xqn/DJf8A1P8A/wCUr/7dR/wyX/1P/wD5Sv8A7dR/YdT/AJ8S/wDA4f8AyIf8RCwv/Qxpf+E9b/5YeV/8M9/F/wD6FD/yoWv/AMdo/wCGe/i//wBCh/5ULX/47Xqn/DJf/U//APlK/wDt1H/DJf8A1P8A/wCUr/7dR/YdT/nxL/wOH/yIf8RCwv8A0MaX/hPW/wDlh5X/AMM9/F//AKFD/wAqFr/8do/4Z7+L/wD0KH/lQtf/AI7Xqn/DJf8A1P8A/wCUr/7dR/wyX/1P/wD5Sv8A7dR/YdT/AJ8S/wDA4f8AyIf8RCwv/Qxpf+E9b/5YeV/8M9/F/wD6FD/yoWv/AMdo/wCGe/i//wBCh/5ULX/47Xqn/DJf/U//APlK/wDt1H/DJf8A1P8A/wCUr/7dR/YdT/nxL/wOH/yIf8RCwv8A0MaX/hPW/wDlh5X/AMM9/F//AKFD/wAqFr/8do/4Z7+L/wD0KH/lQtf/AI7Xqn/DJf8A1P8A/wCUr/7dR/wyX/1P/wD5Sv8A7dR/YdT/AJ8S/wDA4f8AyIf8RCwv/Qxpf+E9b/5YeV/8M9/F/wD6FD/yoWv/AMdo/wCGe/i//wBCh/5ULX/47Xqn/DJf/U//APlK/wDt1H/DJf8A1P8A/wCUr/7dR/YdT/nxL/wOH/yIf8RCwv8A0MaX/hPW/wDlh5X/AMM9/F//AKFD/wAqFr/8do/4Z7+L/wD0KH/lQtf/AI7Xqn/DJf8A1P8A/wCUr/7dR/wyX/1P/wD5Sv8A7dR/YdT/AJ8S/wDA4f8AyIf8RCwv/Qxpf+E9b/5YeV/8M9/F/wD6FD/yoWv/AMdo/wCGe/i//wBCh/5ULX/47Xqn/DJf/U//APlK/wDt1H/DJf8A1P8A/wCUr/7dR/YdT/nxL/wOH/yIf8RCwv8A0MaX/hPW/wDlh5X/AMM9/F//AKFD/wAqFr/8do/4Z7+L/wD0KH/lQtf/AI7Xqn/DJf8A1P8A/wCUr/7dR/wyX/1P/wD5Sv8A7dR/YdT/AJ8S/wDA4f8AyIf8RCwv/Qxpf+E9b/5YeV/8M9/F/wD6FD/yoWv/AMdo/wCGe/i//wBCh/5ULX/47Xqn/DJf/U//APlK/wDt1H/DJf8A1P8A/wCUr/7dR/YdT/nxL/wOH/yIf8RCwv8A0MaX/hPW/wDlh5X/AMM9/F//AKFD/wAqFr/8do/4Z7+L/wD0KH/lQtf/AI7Xqn/DJf8A1P8A/wCUr/7dR/wyX/1P/wD5Sv8A7dR/YdT/AJ8S/wDA4f8AyIf8RCwv/Qxpf+E9b/5YeV/8M9/F/wD6FD/yoWv/AMdo/wCGe/i//wBCh/5ULX/47Xqn/DJf/U//APlK/wDt1H/DJf8A1P8A/wCUr/7dR/YdT/nxL/wOH/yIf8RCwv8A0MaX/hPW/wDlh5X/AMM9/F//AKFD/wAqFr/8do/4Z7+L/wD0KH/lQtf/AI7Xqn/DJf8A1P8A/wCUr/7dR/wyX/1P/wD5Sv8A7dR/YdT/AJ8S/wDA4f8AyIf8RCwv/Qxpf+E9b/5YeV/8M9/F/wD6FD/yoWv/AMdo/wCGe/i//wBCh/5ULX/47Xqn/DJf/U//APlK/wDt1H/DJf8A1P8A/wCUr/7dR/YdT/nxL/wOH/yIf8RCwv8A0MaX/hPW/wDlh5X/AMM9/F//AKFD/wAqFr/8do/4Z7+L/wD0KH/lQtf/AI7Xqn/DJf8A1P8A/wCUr/7dR/wyX/1P/wD5Sv8A7dR/YdT/AJ8S/wDA4f8AyIf8RCwv/Qxpf+E9b/5YeV/8M9/F/wD6FD/yoWv/AMdo/wCGe/i//wBCh/5ULX/47Xqn/DJf/U//APlK/wDt1H/DJf8A1P8A/wCUr/7dR/YdT/nxL/wOH/yIf8RCwv8A0MaX/hPW/wDlh5X/AMM9/F//AKFD/wAqFr/8do/4Z7+L/wD0KH/lQtf/AI7Xqn/DJf8A1P8A/wCUr/7dR/wyX/1P/wD5Sv8A7dR/YdT/AJ8S/wDA4f8AyIf8RCwv/Qxpf+E9b/5YeV/8M9/F/wD6FD/yoWv/AMdo/wCGe/i//wBCh/5ULX/47Xqn/DJf/U//APlK/wDt1H/DJf8A1P8A/wCUr/7dR/YdT/nxL/wOH/yIf8RCwv8A0MaX/hPW/wDlh4n4g+EXxJ8L2X2zWPCN+luEeR5rbbdJEiAFmkaIsEABzlsdD6HHFV7B4t03xP8AAL4hQaf4Z8Y3Ly3Nml3JJHAIo3y0sYV4mZ1fGGILZwW4wRmquo6cnxii1LxB4f0eKz8ZWqNealpVjG3kalDuANxACSVmUsoeMk+ZkMuWLKfMrYOKk6cE1NfZdn9zVrvyt6XPrcBnlV0oYrESjPDzWlSKlG13Zc0JNuK6c3M9dWorVeU0UUV5p9Udr8IvD9v4o+N3hzR7wxG3a68+VJYhKkqRK0xjZScEMIypz/e6HoaXjHxNd+MvHep+Jr5dkt7MXWPIPlIAFRMgDO1Aq5wCcZPJrpf2e/8Ak4/w5/28/wDpLLXn1d22EjbrJ3+Sjb7rv7zwKaU86quX2KVO3lzzqc338kb+iLOn6jqGk6jHqGlX9zY3cWfLuLWVopEyCDhlIIyCR9Ca3P8AhYvxB/6HrxL/AODSf/4quaorGNWcFaMmj1K2Dw9eXNVpqT80n+Z0v/CxfiD/AND14l/8Gk//AMVR/wALF+IP/Q9eJf8AwaT/APxVc1RVfWKv8z+9mX9l4P8A58x/8BX+R0v/AAsX4g/9D14l/wDBpP8A/FUf8LF+IP8A0PXiX/waT/8AxVc1RR9Yq/zP72H9l4P/AJ8x/wDAV/kdL/wsX4g/9D14l/8ABpP/APFUf8LF+IP/AEPXiX/waT//ABVc1RR9Yq/zP72H9l4P/nzH/wABX+R0v/CxfiD/AND14l/8Gk//AMVR/wALF+IP/Q9eJf8AwaT/APxVc1RR9Yq/zP72H9l4P/nzH/wFf5HS/wDCxfiD/wBD14l/8Gk//wAVR/wsX4g/9D14l/8ABpP/APFVzVFH1ir/ADP72H9l4P8A58x/8BX+R0v/AAsX4g/9D14l/wDBpP8A/FUf8LF+IP8A0PXiX/waT/8AxVc1RR9Yq/zP72H9l4P/AJ8x/wDAV/kdL/wsX4g/9D14l/8ABpP/APFUf8LF+IP/AEPXiX/waT//ABVc1RR9Yq/zP72H9l4P/nzH/wABX+R0v/CxfiD/AND14l/8Gk//AMVR/wALF+IP/Q9eJf8AwaT/APxVc1RR9Yq/zP72H9l4P/nzH/wFf5HS/wDCxfiD/wBD14l/8Gk//wAVR/wsX4g/9D14l/8ABpP/APFVzVFH1ir/ADP72H9l4P8A58x/8BX+R0v/AAsX4g/9D14l/wDBpP8A/FUf8LF+IP8A0PXiX/waT/8AxVc1RR9Yq/zP72H9l4P/AJ8x/wDAV/kdL/wsX4g/9D14l/8ABpP/APFUf8LF+IP/AEPXiX/waT//ABVc1RR9Yq/zP72H9l4P/nzH/wABX+R0v/CxfiD/AND14l/8Gk//AMVR/wALF+IP/Q9eJf8AwaT/APxVc1RR9Yq/zP72H9l4P/nzH/wFf5HS/wDCxfiD/wBD14l/8Gk//wAVR/wsX4g/9D14l/8ABpP/APFVzVFH1ir/ADP72H9l4P8A58x/8BX+R0v/AAsX4g/9D14l/wDBpP8A/FUf8LF+IP8A0PXiX/waT/8AxVc1RR9Yq/zP72H9l4P/AJ8x/wDAV/kdL/wsX4g/9D14l/8ABpP/APFUf8LF+IP/AEPXiX/waT//ABVc1RR9Yq/zP72H9l4P/nzH/wABX+R0v/CxfiD/AND14l/8Gk//AMVR/wALF+IP/Q9eJf8AwaT/APxVc1RR9Yq/zP72H9l4P/nzH/wFf5HS/wDCxfiD/wBD14l/8Gk//wAVR/wsX4g/9D14l/8ABpP/APFVzVFH1ir/ADP72H9l4P8A58x/8BX+R0v/AAsX4g/9D14l/wDBpP8A/FUf8LF+IP8A0PXiX/waT/8AxVc1RR9Yq/zP72H9l4P/AJ8x/wDAV/kdL/wsX4g/9D14l/8ABpP/APFUf8LF+IP/AEPXiX/waT//ABVc1RR9Yq/zP72H9l4P/nzH/wABX+R0v/CxfiD/AND14l/8Gk//AMVR/wALF+IP/Q9eJf8AwaT/APxVc1RR9Yq/zP72H9l4P/nzH/wFf5HS/wDCxfiD/wBD14l/8Gk//wAVR/wsX4g/9D14l/8ABpP/APFVzVFH1ir/ADP72H9l4P8A58x/8BX+R0v/AAsX4g/9D14l/wDBpP8A/FUf8LF+IP8A0PXiX/waT/8AxVc1RR9Yq/zP72H9l4P/AJ8x/wDAV/kdL/wsX4g/9D14l/8ABpP/APFUf8LF+IP/AEPXiX/waT//ABVc1RR9Yq/zP72H9l4P/nzH/wABX+R0v/CxfiD/AND14l/8Gk//AMVR/wALF+IP/Q9eJf8AwaT/APxVc1RR9Yq/zP72H9l4P/nzH/wFf5F7Vda1jXbxbvW9WvtSuEQRrNeTvM6qCSFBYk4ySce5q94O8TXfg3x3pniaxXfLZTB2jyB5qEFXTJBxuQsucEjORyKw6KiNSUZqonqtbm1TCUalCWGlFcjTTXSz0aOp+Lvh+38L/G7xHo9mYhbrdefEkUQiSJJVWYRqoOAFEgUY/u9B0BWx+0J/ycf4j/7dv/SWKirx0VDE1Ix2Un+Zw8O1p1sqwtWo7ylTg2+7cU2H7Pf/ACcf4c/7ef8A0llrz6vQf2e/+Tj/AA5/28/+kstefVpL/dYf4pflAxof8jnEf9eqP/pdcKKKK5T3AooooAKKKKACitzwz4O8T+MtRax8M6Lc6jKn+saMBY4shiN8jEKmdrY3EZIwMmvULX9nHVbCziv/AB14z8P+GLOVAFeWXzHWYjIibcUTOA+Srt93jI5HVQwNeuuanBtd9l970PFzHiLLcun7LFVkp/y7y/8AAVeX4HidFe5nwR+znY4s9S+JGuy3kIEc8ltA3lO44ZkxbsNpPIwzDBHJ607/AISD9mbGf+FdeJP+/wC//wAlV0f2a18VWC/7ev8Akmef/rUpfwcHXkv+vfL/AOluN7+V/O2h4VRXun/CQfsy/wDRO/En/f8Af/5KpP8AhHP2Zr0/bf8AhMvEum+f+9+xeUzfZt3Pl5+zvnbnGdzdPvHrR/Zt/hqwfzt+aQv9anH+Jgq8f+4fN/6RKT++x4ZRXuB/ZzOsf8iL8SPDXiDyv+PrL+X5Ofuf6oy5zh+u37vGeceaeKvh94z8FeU3ibQLmxilwEnyssRJ3YXzEJXd8rHbnOBnGKxrYDEUVzThp33X3q6O7AcS5Zj6nscPXXP/ACu8Zf8AgMkpfhtZ9Uc1RUr280dvFO8ZWOXOxj/Fg4P61FXGe801uFFFFAgooooAKs6dp93q2sWmlafD513dzJbwR7gu93YKoySAMkjknFVq6r4ef8jpL/2CdT/9IJ60owU5xi+rRzY2tKhh6lWO8Yt/crl6GPwpo8f2aPQ7fxBMOJry/mnjhdh3gjiaJlXkjMhYsArbYyStSf2n4c/6J74e/wDAi/8A/kqsevXvhv4L8Pa94Gsb3UdGtLye41t7Keaa8khkSAQB/wB0iyKHcHkAKxOTx3HpYalKvLkgl9y/ybPBzfEYbLKH1nEObV7aTa1s3tzRittlbskec/2n4c/6J74e/wDAi/8A/kqj+0/Dn/RPfD3/AIEX/wD8lV6Z4C8EeEdV0mzudU0qW6Da7eWj+ZLJE7wR2bSqhCsNp3AHse3TiqHiL4dadF4d0D/hH4/Pm1vVmjs7sux8y2dUMYZc4BXcwbgHKmuj6nV9n7RKNvRX6eXmeYs9y7619Uk6ifdzlb7V9efpyN7Xt87cF/afhz/onvh7/wACL/8A+SqP7T8Of9E98Pf+BF//APJVdp8TfCXh3S9JtNY8JxQLZxXMmnXXk3y3Yd15jlJV22F1DfKcY29BXPw+CPN+ENx46/tq1XybsWv2Aj52yQM5z15ztx0BOayqUKkJuFk7K+y2+47sLj8BiMPTxPPOKnLlSc535m7JO0na/raxl/2n4c/6J74e/wDAi/8A/kqj+0/Dn/RPfD3/AIEX/wD8lVu+FtE0mT4feIPFN7p39rXGnSQRR2JkdI1Dk5lk2EMQMYGCOetbvhfSPA2v6bqV5q+g3Gky6IP7RuLa3llYXlsV/wBV87ZQ7yuGH8LdyN1OnQnPl+FX12Xn5W6MjFY/C4f2jcaslTai2pyerSaVufmfxRV7Wu97XZwv9p+HP+ie+Hv/AAIv/wD5Ko/tPw5/0T3w9/4EX/8A8lV6tofgzwZrfhDQ5m0Wzhv9YtNRnjhjuLrz2eJ38tYiWMQVVAB8zk4HU5rmb3RfDWn/AAY8P6sbTRk1PUbe7Mkl896ZpGSUophER8oEDH38DOM55q5YSpGPM3G1r7Ly8t9UctLOsFVqexjCrzc/Jbmlv7+vx/D+7lr5etuP/tPw5/0T3w9/4EX/AP8AJVH9p+HP+ie+Hv8AwIv/AP5Kr07XPA3hq2+G8moxaLDDJH4fstQW6t7qSS4a5kID74i7BYyOd2xQOcHsKVx4Q8Ox/B3/AITJfD8o1F7BF/sz7Q+2LMhT7fjfv2HHCn5cnoVpywdWLafLor7Lb7iaWe5fUjGSVTWagvffxNJr/l5tr8uttL+ff2n4c/6J74e/8CL/AP8Akqm/2TonimePT9I0aPRtZmYRWkdtPI9rcuThYmWVndHYnAk37MhQVUFpBk0Vwc6ekkreiX6H07wKir05yUujcpNfNOVn6HN1v6JoltPY/wBrasZvsPmNBHFbuEknkUKWAYqwRVDqSSDncAB95km+Iv8AyWHxZ/2Gbz/0e9akn/Io+Gv+vCT/ANK7ivPxCdNuK6OwVMXKrh6VSOntLfK8XLf5Wv8AdZh5mgf9CdpH/f8Au/8A4/R5mgf9CdpH/f8Au/8A4/VSvYfhV8KNF8YeF59c1u7utpmaCKG2cLtwBlmJB554Ht3zXJzy7nlY7E0cDS9tWnK3+KX+Z5T5mgf9CdpH/f8Au/8A4/R5mgf9CdpH/f8Au/8A4/XV33gi00344R+CbnUSbRruKL7RwG2OFYD0DYYD61e1Tw/olx4W8SX0Whtos2jahFaw/vZG+1K7spRg5PzqAGyuBg9KOeXch4yj7lpSakk0+aW0nZfavv8Ad1OG8zQP+hO0j/v/AHf/AMfo8zQP+hO0j/v/AHf/AMfr2HxN8PPCVqfFF/pFkRbada+V5DTuTa3IZDu5bLKyPkZyMhvQVjDwh4d/4aUufCv9nf8AEoQSFbbzpOMWpcfNu3fe56/pRzy7nNSzXD1YOcXPSLl8T2STf2t/eX+Z5v5mgf8AQnaR/wB/7v8A+P0eZoH/AEJ2kf8Af+7/APj9er+FfAXhfXfDPhB2tD/ad08lxdoZnAu7dJzG4HzfKygoflxkBqybXQvDNp8O7zWLuz0gXKa5NYpJqkl4U8pYwwRRbnO7OeW9+elHPLuUszouTgudtO3xS7tfzeT/AKuefeZoH/QnaR/3/u//AI/R5mgf9CdpH/f+7/8Aj9VKKOeXc9b2X96X/gUv8y2W8PSKY38JafGrcF4Li5WRR6qWlZQ3oSrDPUHpXPa7oyacIL6yd5NPumdYTIR5kbrtLxvjGSu9PmAwwYHg7lXWqXUf+SaX/wD2E7T/ANFXNXTm72ZdOUqMotNtNpNNt7u3Vu1t/wADjKKKK6T2j0H9oT/k4/xH/wBu3/pLFRR+0J/ycf4j/wC3b/0liorozH/eqv8Ail+bPE4X/wCRNg/+vVP/ANIQfs9/8nH+HP8At5/9JZa8+r0H9nv/AJOP8Of9vP8A6Sy159VS/wB1h/il+UBUP+RziP8Ar1R/9LrhRRRXKe4FFFeg/C/4X3nj7Upr+/uP7L8M6fl9Q1SQhAoUbiiFuN23kk8IPmP8KtrRozrTVOmrtnHmGYUMvoSxOJlywj/Vl3b2SWrZyvhrwvr/AIw11dG8N6bLf3pRpPLQqoVV6szMQqjoMkjkgdSBXt0HgL4R/Cfy7n4iaz/wkuvx7X/sayXckTfu2wyZGcZJBlZVdCfkJFY/iH4tad4c8KweCPg+lzpWlxbxdarKii5vXOVLg9V3DDb8K4+UARhMHx6vRUqGE0glOfd/CvRdfV6eR808NmWee9XlLDUOkY6VJLvOX2F/djrq7yR6z4l/aB8YanAuneGYrbwtpMcP2eO1sVVpFTYFx5hUbduDtMYQqD3IBrzlG1bxT4nj+23895fXbqj3V3KZGOABlmYk4VR36AVmV6LpPhPVjd6ZoPhjTn1PxFqP7kRW53v5jE/u+wUIFJYngYJJwK4sTjK1bWpJv8vu2PocoyPL8ttHC0VBdWl7zXnJ6v1bZzXjRrNvG941gAbYFUjI4yqqFB/EKK9c+G2jR3VjF/wl37O6al4elGG1a2e7s7lVI+/G0k2yU98ADPY17B4O+Bnhj4aR2+teId/ibxfKm+K1tMeRbbRyYywzhf4p2wP7o9eglv8AXPFOpS6MdP8Ast80aO0Ud1I+2N87fNL9mCkjODgA4wRXJF6JHuV37arKqlZN3sfLHjH4QXn/AAsa+s/h7BPqWgttltJ7mREZVcZ2EsRkj1x0xnBrG1H4M/EvTLRrqfwrdyQqMlrdlmx+Ckn9K+v/AA74XutBka71PRZhY7is17Zy75LYqcHzYyCdowPu9BzgivRJdD1KO1Fxp6pq9qyhvIBRJmU8gxOMI/HQNjP96q57GTpo/MhWvtL1NJEa4sry2kDqwJjkidTkEHgqQcHNevfDn4ufFC21O1t5706xo6MEnfVFLCNS4Yt9oA378ZC7iw5wFOABrfFjxNofiD4mXDHSoo7LSXeAGe28i5ndfvGTcNyYII2kcDnAJ48zl8Sy36sk16bGyU8BAWkb12LnA4HU/nWtLGVqLvQk0zlxGQ5dmdqeZU1OHmlf5P7PqtT0ZvC/w6+JWv3elyeIoPC+rxusOmW0UKR27IWXIEeFVmZmYBVcNkk4YCvIvGngLxP4B1hNP8SWHkebuNvcRsHiuFVsFkYfgdpwwDLkDIrOvbn7XfSThBGpOFQHO1RwBnvxXpngf4wNp+hSeDfiBaSeIfCUtt9mFttUzW4GSuxiVLAHAGWBTClCu3B66CoVYKnV92X83Rv+8v1X3Hh5v/aOExdTGYF+1oNr907Jxilb93LySXuS3tpJN6+P0V6h8SPhTB4c0O08Z+CtQl1zwfeIpW8OGktmPy4lwBwWyAcDa3yMAQN3l9ctfDzoT5Ki1/PzXkehluZ4fMqCxGGldbPo01vGSeqa6phRRRWJ3hWz4V1eDQ/Fltf3iSPZssltdCIAyeRNG0MpjyQN4SRiueN2M5GRWNRVQk4SUlujKtSjWpypT2kmn8zs9R0i802OG4kUTWVzlrS+iDGC6UYyY2IGcZAKnDKflYKwIEcOq6nb2kVrBqV3FBDOLqOJJmVUlAwJFAOA+APmHNYekeIvEGged/YWu6npfn7fN+w3TweZtzjdtIzjJxnpk1pf8LF+IP8A0PXiX/waT/8AxVdSrU97tf16o4Z08V8LhGaXVtr8OWVvv1302NNPEviKN2ePX9URmme4LLdSAmV12s/X7xUkE9SDimW+v69aRWkVrreowR2bM9skVy6iBmzuKAH5ScnJHXJrP/4WL8Qf+h68S/8Ag0n/APiqP+Fi/EH/AKHrxL/4NJ//AIqr+sQ/mf3f8Ex+q1rW9hT/APAn5/8ATvzf3snS+vY9PlsI7y4W1mYPLAshCSMOhZc4JGTgmq9L/wALF+IP/Q9eJf8AwaT/APxVH/CxfiD/AND14l/8Gk//AMVUOrSfV/d/wTZLFxvanDX+8/8A5As6fqepaTd/atL1C6sZ8Y822laJsemVINPbWdXae7mbVb0yXi7LpzOxM6+jnPzDgcHPSqf/AAsX4g/9D14l/wDBpP8A/FUf8LF+IP8A0PXiX/waT/8AxVUq0Ercz+7/AIJEqOIlLndGF+/M/wD5A1IfE/iS20caTb+IdVhsApUWkd3IsWCSSNgOMEk547miDxP4lttHOkW3iHVYdPKNGbSO7kWLa2dy7AcYOTkY5yay/wDhYvxB/wCh68S/+DSf/wCKo/4WL8Qf+h68S/8Ag0n/APiqf1iP8z/r5mbwlV3vh6erv8XXv/D38y+Nd1wSeYNZ1AP9m+xbvtD58jp5XX7n+z09qDr2uG6e5Os6gZng+yvKbh9zQ4x5ZOclMcbelUP+Fi/EH/oevEv/AINJ/wD4qj/hYvxB/wCh68S/+DSf/wCKpe3h/M/u/wCCV9Xr/wDPin/4E/8A5WJWrpelpJEus6ylxb6BBKFurxBjfjBMMJIIaZgflXtnc2EVmGX/AMLF+IP/AEPXiX/waT//ABVZGq61rGu3i3et6tfalcIgjWa8neZ1UEkKCxJxkk49zU+1px1V3/XqzZwxdRcklGKfVNt/K8Y69nrbsw1rVbjXfEuoa3dpElxf3Ml1KsQIRWkcsQoJJxknGSa6bRZW13QLLS7VGl1OwDxJbRqS08BcyAoOSzqzybgP4dhAIVyOLoriqLnvc3q4SMqcacNOXby0t+R11dD4b8c+KfCMU8Wgaq9tFOdzxlFkUtjG4BgQD7j0rjP+E18Zf9Dbrv8A4Hy//FUf8Jr4y/6G3Xf/AAPl/wDiqw9i+5wVcDVrR5KkItdm2/8A202r2+vNR1KbUL65knupnMkkznLMx71Nfa1rOpxRR6lq19eJF/q1uJ3kCfQEnFc//wAJr4y/6G3Xf/A+X/4qj/hNfGX/AENuu/8AgfL/APFUexfcr6nW09yOm2r0/wDJTon13W5Gu2k1jUGa9wLotcOTcY6eZz82O2c1al8YeLpihm8U61IY2LIXvpTtJUqSMtwcMw+hI71yf/Ca+Mv+ht13/wAD5f8A4qj/AITXxl/0Nuu/+B8v/wAVR7F9yHgKj3px+/8A+1Ogg1rWLV7RrbVr6FrMMLYxzupgDZ3bMH5c5Ocdc1PZeJvEmmwvFp3iHVbOORzK6W93JGGc9WIBGScDn2rmP+E18Zf9Dbrv/gfL/wDFUf8ACa+Mv+ht13/wPl/+Ko9i+45YGrLeEfv/APtTSJJOScmis3/hNfGX/Q267/4Hy/8AxVH/AAmvjL/obdd/8D5f/iqPYvuafV8R2j97/wDkTViilnnSCCN5ZZGCJGilmYk4AAHUmovEd0lhoQ8PZBvHuVubxOvkFFZY489n/eSlxzj5BwwdRmT+LvFdzbSW1z4n1maGVSkkcl7KyupGCCC2CCO1Y1XClyu7NKWEm5KVW1lrZa6+bstu1t7a9AooorU9I9B/aE/5OP8AEf8A27f+ksVFH7Qn/Jx/iP8A7dv/AEliorozH/eqv+KX5s8Thf8A5E2D/wCvVP8A9IQfs9/8nH+HP+3n/wBJZa8+r0H9nv8A5OP8Of8Abz/6Sy159VS/3WH+KX5QFQ/5HOI/69Uf/S64UUVr+F/DWqeMPF9j4b0ZImvbxyqGV9iKApZmY+gVWJxk8cAnArnhFzkoxV2z2K1aFCnKrVdoxTbb2SWrb9Dqvhf8L7zx9qU1/f3H9l+GdPy+oapIQgUKNxRC3G7bySeEHzH+FW2/iZ8TLPWNNh8DeBrb+y/Bun4SOKMFDelTne+edu75gG5J+d/mwF0fi14h0Pw5oy/B/wAEW3kaXp0yyajeCbc97cBRkOVOGwcbtw4dFUBRGM+PV6leawsXhqW/2n38l5L8fQ+TyvCzzitHN8anyLWjB/ZXSpJXd5tbfyLbW7CiiprW0ur69js7K3luLiVgkcMSF3cnoAByTXmn2BHGcSqTjGR1r9Kf2cfgufCPw1n8datEJ/EXiV3kSQrt+yWLsXRFB5Uyja7d8FVP3Tn5j+DX7Pc6+KdP8RfFq0Gl6ZG/nW2gXRC3eolfm+eL70UA6uzAFh8qj5sj7k8YeN59N+Gt5LaSj7TctHp1rtGNs08iwhhjuN7N/wABrCq77G9GEpSUV1JLXQdNmu22RrNLeJ500pGd8auFUf7mTwOnU9zXlvwQ2+Itc+IOt3S7ryTXySzckR+VtQfQAECvQ/C3jTSW+LvirT7YxyW+m22m6ZBGT8sYXzifx3YH4CvOfA/ia38BftSa54IvbS3hsdXjMljKy4E5y0sRb1O1pEyP4kArGTaaPTwkIzo1or4kk16J6/hr8j1xbCKLV4rUR4kuFZ1I/iKBc/jgg/hVTThY6T45XwoxFvFdDdbo648qQguYwP7jqGdMd0kXsBXLfE74kS6Rquh6jpMSyS6frTtcwxqSzwGzJl2gdflYED/ZrjPjN44j1f4cxeNfDV+B4h8P3EdztV8lkVlk2+68JIh9C3qwqrnNRoOo1fRPS/n/AF+ZiftkfBuy1bwpJ8SPCsONT04KutpGuPtdso2/aPd4+Nx7p1+4K8Xs/gze337Okck2lqtxdD7Za3fAcTgfIh77HUCP03EHtX2lP4og17wDFrOm20V1Bf2S3K2snKzRyIGaI/VWK/WvNdC1DRo/Bv8AY2nXBurBi32FieZE6+S392ZcYKnG7G4ZycaU3yu5zuPRn5yMCrEEEEdjSV6l8afh9P4a8Y3PiDS4Wm8P6lM00NwgJWCRjloX/ukHOAcZHuDjy2tznasd98M/iZd+BNQmsL+3/tPw1f5TUNMkAdWDDaXRW43beCDw44P8LLa+KPwutND0+Hxz4GuP7T8GX+HjljJdrIscbHzzt3fKC3IPyP8ANgt5vXpfwl8baXpF3d+C/FtnFfeFtfdIblJ5dqWsmcCYZIVR93cwww2IwOUAPoYerGtD6tW2+y/5X/k+q+Z8lm+Aq4Gs83y5e/p7SC2qRW7tde/FaxfX4Xe55RRXX/EvwLd/D34hXegz/PbNm4sZTIHaS3ZmCFsAYb5SrDA5U44wTyFefVpSpTcJqzR9Hg8XSxlCGJoSvCSTT8mFFFFZnSFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAeg/tCf8nH+I/8At2/9JYqKP2hP+Tj/ABH/ANu3/pLFRXRmP+9Vf8UvzZ4nC/8AyJsH/wBeqf8A6Qg/Z7/5OP8ADn/bz/6Sy159XoP7Pf8Aycf4c/7ef/SWWvPqqX+6w/xS/KAqH/I5xH/Xqj/6XXCvoXwFB/wqf9nTU/iJcxeVr+vYtNK8yP5okOdjDdGcZw82CSjrHF0Jrxbwd4Zu/GXjvTPDNi2yW9mCNJgHykALO+CRnagZsZBOMDk16T+0D4li1P4kR+GdOS2i0nw9CLO3itihjVyqmTG0DbtwkezJCmLsSRXVgf3FOeKe692Pq938l+aPL4hj/aeMoZMn7kv3lX/BFq0fSc7L0TPJqKKK88+wClBIYEHB7YpKKAPpf4OLaeEvDmjS3UZuPEHiky6gxk5MGmWgdlyTyPMmiJx32Ie3PtXxJ8Sf2V4U8NkS5S1162M2fWJJHOf+BLmvm3wFrT618QdS1mJnNnpHhWPT4CRxEFiii2/iTKfqTXpHxQ1tb7wvrK26LcNp+tQamsO/aJYmbY4z2GWOT6MKwqOyuengKfPL0/zt+p1Ul1ceEtA0rxGLmaHUdZglnvraaF4pFlWUXELDcBvXAZcqT2HerXj670v4g+GLTU/Oe01PT5Unsr+BsSRIzKcj1AJBx6rmuC8SfEf4yWvgnT5/Guq6LqWg6xZrdw+GJNOeMxQ+c8bLHcKuUaEooLOcgsvD4Jr1jw98JNU174X6V4m8NXUd7aahaCVbGf8A0eXy2B4U/dVwcqR90kbgRnA4YVvZxtU/q56E8PUuq8VyrZdNtP8AgfeYnwtvfFXiP4q3Wp6nY2WsTWLSPLI0otrQO0SQI8hIJG7Y52qGJxwMdMP4peB00LVlfwn400DVLq8EkL6DY3KeZGCGdoViLM7xqCxBOCpzxg4HofjP4YeIr/8AZ+LaNY6poMunW73Gt2VvJ5V1qYhWNPLikAbajxK7EjJyMEHnPzho37Oup6r4kjQ6BZ2NjqE0i2LSTBnSFo2KSBxgyFGZMtjkr0w1ZqpzS9pe3/AO3CYSrOLqUrcsd7tLfy8z3H4d6/caZ8CPBUFwzrcRXENiUfhgBcPEQR7KaxrXTtFHxC8T2M2mWV1BcOt9Az5UgSjPO0jcm8MDnOCQa5+0v7BfH/hfwToI26bpUz3khU5+SN2k3MfXGzJ9Wrhta8X3em/E+y1C1mBME9xp0qN914mZZFB9gJePpXfSldXODF4S0owXxO7/AMvy/E7LxqurXGhXGs+BrlbeWNWhvNDmhWaCfb1RomBG7g4P8WB3Ir5V1C9OoahJdtbW1uXOfLtohFGPoo4FfQt54lms/Gml6xbOY4NSuvskqZ4L8PGfqG4+h9q8P8c29pafEvX7aw2/Zo9QnWML0Vd54H06fhXZb3bnh1VZmBRRRUmR71p0H/C3v2XJtIWLzvE3hHBtdkeXlgCnag2x5+aNWQIpyzwxljzXzzXo3wg8Wv4O+LemXzSxx2d04sbwyusaCGRgCzMwO0IwVyeM7MZAJqt8Y/CD+DPi/qlgsUUdldub+yESLGghkYkKqKTtCMHQDjOzOACK9HFf7Rh4V/tR92X/ALa/u0+R8flMf7LzWvlt/wB3VvVp+TbtUivSVpJLZS8mcFWhoVtDeeKdNs7lN8M11FHIuSNylwCMjnoaz60vDssUHjDSpppEjjS8hZ3c4VQHBJJPQV5R9gfdvxI/Y8+G2l/GqLxE8cXgv4S6No0V5rE730sr3Vz50wMSNK7uuUEQOPVQoLNx8uat4b0b4z/HtfCv7P3w6bSNPfclrbyXk0skka8tc3DzSOIxjsCAOB8zHn7M+L37S3wsl+NMPwy8VXegeL/hh4g0SFb2+0y4juxp92Z5gXLxE9FWIkA7kwrr6HyX4S3vw0/Zi/a/uZz8Q/D/AIj8Fa9pstlZa3pt/DeSWJMscirdJCWKf6vaWxtbIbjDBcot21LaR494y/Zc+IXhHwPqniu11nwl4psNHfZqy+G9T+2S6aR185CqlcdwMkDJPAJqbS/2VPH2pfDDw78QX8R+DNN8P62nmi91TU2tI7FOcG4d4wq5IwAhcknpgEj6B8T/ABGj8F/DzxrDovi39mW003V9OuIPs/hDTp2v9TBjkWOOSOKUKjnewy5YIWJ5Gc+Z/GXxh4a1P/gnv8I/C+l+KNJvNUspw97pdtexyT2+I5QDLErFk+9jkDr701Jisjzvwh+zV448X6TrGvxa94R0jwxpl7JYHxNrGqC3066kR9hMEu0l0Jxh9oByBnOQK+r/ALOHxH0L41eHvhpqqaXBeeImH9l6otw0lhdKR99ZUUnA4yNuRkHGCCfon4MfFnwNr37Gmk/DCa/+GFn4n0K7kcWXxKtTJplyjSyyCVGyAsmJiM8kEN8uGBEet/Fi2vP2h/gtpniPxv8ACibT/D2oSu8ng+Ka2sNKh8tERDPNIYyhC4AUKF2DPUUczuFkeUf8MXfFp9Y1zRbbVfB1xrGlIZf7Kj1X/S7uLAxLFEUDBCTtDSbAT04IJ+d3R45WjkRkdSVZWGCCOoIr7p+HnxD8FWv/AAVJ8eeLdQ8caBBoN1p8kUGrz6lClrN8tsFVJi2xvuEAA/wn0r4p8Tywz+N9Znt5Ekhkvp3R4yGVlMjEEEcEYpxb6iZ9Mfs2fAzwf4y+AHjH4l+I/A2seNdT0udotP8AD8N3LYRXaqisxSZBl3yzjaCcbQMEsK8O8Y6Lp3iC91HxX8Mvh94o0vwrZRoL9bkPexadMTgq1wFACn5cb8Nkn2r6y8H/ABK0jxH+z18LYfhv8YvC3w88SeCjs1LRvEt2bK11D5NsjNxiUN87AAH/AFrcqwBq/wDtJ+NfhlrX7Mniez+D/izwIt3q+sxXviezttRSG4vmRULNbxuVMo3pExKDDYcjLFqlSdx20PhLQraG88U6bZ3Kb4ZrqKORckblLgEZHPQ190/Eb4bfsx+Bf2nfCXwauPgldTjxLBbsms23iO9D2rzTyQKPJZyGAaMEtu4DHg45+GPDssUHjDSpppEjjS8hZ3c4VQHBJJPQV9yftL/tR2Xg/wCOOkXnwx0z4X+LZk0ZHTxK9smpXdnKZp1MMdxFKAgC4bZ/00J6NVSvdWBHifjX9lTxN/w1Vr/wt+Gw/tDT7CCLUDf6lMsSWdvIgYefJjGQSVGBlgM4644/4h/s8eN/h74Fi8bNqnhrxR4aef7M+seGNQ+228EucBJDtUg54zgjOATkgH2n9mb9ofS38bfElPi7r+mpqvjW3iMeq61beZYtJGksYhuEXAEO2RRtyq7VZcjIq78WviHPon7NvibwTD4n/Z5Sy1V4imi/DqyuHkuX82ImQssgjiZVjVtzK2dgXrildp2CyPL9V/ZE8faDpml6r4g8Y+ANG0rUrIXkWo6nrDWsCllDLCTJGpaUg52oGAxyRkZx/B/7MXxA8VfDa38fahq/hTwh4fuzizvfFOpixW7znGz5W64ON2M4yMjmvQP2x/GHhrxRoHwptvDfijSdZWw0No7mPTr2O4+zSlYQVcIx2N8vQ4Py+1dL4t1HwB+0X+y38N9E0/4p+FfBfiDwhaLZXml+Jbs2cUuIY4i6Ng7v9SGXaDw5BwRRd2CyPnrw/wDBzUNZ+I2teDNU8deA/C13pK5ku/EGsrb2lxyABDKqsJCQQwx25rV8f/s7eM/h74Y0vxXea54W1vwvqN0toniDQdQN5ZxOSR87BA2PlbkKfukdcA+k/s5aR8B9H8eePdJ8ca74M1zU7SBY/DWo+Iw0WkXMgV97MH427/K5bkrkqOtejfF7x94C1L9gLW/C1l4g+F0evxatCDpPglVtLZytxGWeCB28yQbc5l2gNg44GSOTuFtD5v8AFn7OXxB8IfHLw78K72XSL3VfEAhewvLGaSS0dJHK7y5jDYXaxbCnAGRnIrQ/4Zt1KDx/4i8Iav8AFv4VaJqGgzRW9wdX1x7RJ3eMORDvhBfbna3Aw3HNfWPwF8ceEPFX7M2hfF7xiPO8QfCayvrHzCQGkjMAEfXqWj2ID/fDeteQfAXWvhL4j+HnjvxR40l+HU/xWvtVkvYH+IZJ0945CjkhTwfmM/C5fO3tijmYWR4T8Vfgh41+EI0q68QvpWoaVq8Zk0/V9GuvtNpcgAEhXwD0ZTyBkHjODip8E/DmjeLv2h/B3hnxDZ/bNK1HVIbe6t/MePzI2OCNyEMPqCDX0l+1R478C+Kf2Rvh/pvhrxD4KutRtNSzPpvhjbbxWwEUqsY7UsZIoi2MbwCcgkAnFfO/wB1PTdG/ad8DarrGoWun2Ftq8Es93dyrFFEgblndiAoHqTTTbQmtT6M8beG/2VPDv7U1x8D9X+EWp6PGZ7Wzi8S2HiK5lZJLiGN0ZoJSyqoaUKTlumcdqy/BXwFufhn+3y3w6fw54c8dWT6XLf2Fv4ncQ289uyna74gnAkRldeI8EqT8ua6f4k+CPhb4q/bLuvjJr3x7+HEPhJbmyvfsWn6st5fzfZ4IVMflRggBmiPKljg9M8U7wd+0B4N8f/8ABSVPHt5rFloPhey0SbSbG+1i4S0WRFDMGYuQFLPI5Ck5xjvkVN3Yo8M0b9nPx38U9T+IXiDwjF4csodA1ie3m0s3Lx4bzGISA+UE2KBjc5jAAyQo6ehfAf4SyaH478aaFLpXwp+JzxeHFvWnbVhc21gWd1/dyC0mHnjbyoC4BX5ua1PAnjrwjp/7Pv7SNhN4w0S1vtX1C9bTbd9QiSW+RxIAYVLZkBBx8uc5rmv2K/FnhbwrrHxDfxR4l0fRFu9B8m3bUryO2Ez7j8ib2G5vYc023Zi0PlmiiitCQooooA9B/aE/5OP8R/8Abt/6SxUUftCf8nH+I/8At2/9JYqK6Mx/3qr/AIpfmzxOF/8AkTYP/r1T/wDSEH7Pf/Jx/hz/ALef/SWWvPq9B/Z7/wCTj/Dn/bz/AOkstefVUv8AdYf4pflAVD/kc4j/AK9Uf/S657Z+zjbW9hr/AIm8dX8EU9noGlPIyhQ0yu2W3RA8A7IZVJ3D7+OhOPKNRv7vVdXu9Uv5fOu7uZ7iaTaF3u7FmOAABkk8AYr17wV/of7FXjfULT/R7uXU0t5LiL5JHizbDy2YclcSSDaeMO3qa8YrqxXuYejSXZy+92/JHn5GliMzx+Me6nGmvJQim/vc2/uCiiivPPrApwR2RnVGKr94gcD602vVv2e9c07T/jJb6B4igFx4c8SwPomqxMpYCGXG2T/ZKSKj7v4dpPFTOXLFyKhHmkkb/wAJora0+Dl3eF1W41fxJa6MWP8AAvkvIoPsxLD6ir3iKw1K20P+3S3nWM1sY5IiOJIzmNoz7hVXnvtHQjNcZD4M+IFp8T9Y+C3hqCS/vDqayoqOqAtb7zFdByQqL5UjNuJxtb6V6T4W8VW3jGyTwvr8tnBe30M9mI4CPLF6kjyIF5xiaOeULjgtGAOorNuMlY78LWlRmntbT/NHvHwouLf4lfBrwrLf6femfSVaA3U1ou2Z1PlyMrMCrq+xS6nJDrng8n361/szw14ds4Zru3sLCECFDcOFLMSSADwCSdxwBk9ulfn58Kvj5qvwJ8Tar4Y1qwXUtFN0JprCSTypIWYAGaFiCOcAMpGDgHg5NfSOpftC/s+fEzwynhzxXrU+iF3gvEg1i1aPY6kOjB03oR7EjKsfWvDrUZqXke/iK10qbfup+u77f1dnv9nq+ma1aSyaLqltd+U3lyNbShjG2OjY5U+xry7xr4Z8Qab4WvI/B9hplrczxvCb9wkMenxN9+QBRuYgE4UYGeSfXCsfjB8F/BV1LH4d8Tr4o1e+VI0sPD8AuHZVyVHyAIg+YklmGPavFv2kfjH8QdS03StBgMOh6Nq3mC4tLWXfOUXGRJMMcEE5CgDjG5qxhTlKSjsaUYSptulrHTW2/wDTOD8JTLoPhLVdQM4m1LWLj+z7OXGG8oHt6DkE89cV5tqt8Lzx9cEHMT3rtGQfvhcLn8kFSQapfz3sUiSiOK2gZbUBTiIsCFfHAwMs3XLHb2Fc3BbIst3JLdzPNawNLFOMLtKkAA9cgk4x717tPZRObEVoU8ROre/z++3y+V7m3418WrNr2nW2kMDFpMhmEn8MlwWBZh6hdqqPXaT3rh5ZZJ53mmdnkdizMxyWJOSTWlo2qTWWvi4EcUqTExzQyIHSRG6qQc8d/UYyKl1fS7ZYRqGlAta/dmTdu8l89PXaeME9+D2rq5m5WZ81NJx57632/UxaKKKZiFe1fGeZ/GHwS8BfEVliNwyPp19PJGqTTzYPPyjGwPBOQMjHmDAGTjxWvaNI/wBN/YY8Tfbf9I+w6wn2Tzvn+zZe2z5efuZ82Tpj77f3jXoYL34VqT2cW/nHX/M+T4lSo18DjY/FGrGP/btRODX3tP5HhdFFSW9vPd3cVrawSTzzOI44olLM7E4CqBySScACvLPrCOiro0jVi96g0u9LWGTdgQNm2w20+Zx8mDxzjniqVABRRVm60+7s7WyuLmLZFewm4t23A70Ejxk8Hj543GDg8Z6EUAVqK6FvAnjSK6s7e58K6vaNe3Edpbtd2r26SSucIgdwFBJ9TXPUWAKKKKACiipWtrhbNLtoJRbyO0aTFTsZlCllB6EgOpI7bh6igCKiirY0rVC7oNNu90cAunHktlYSAwkPHCEMp3dMEetAFSity78GeMNPSBr/AMKa5arPKsEJnsZUEkjfdRcryx7Acmq154c8Q6dqlvpuoaDqdpe3BCwW09q8ckpJwAqkZYk8cd6dmFzMorbuPBvi+zvLe0u/CutwXFzu8iGWxlR5to3NsBXLYHJx0FZJtrlbJLxreUW7u0SzFDsZ1ALKG6EgMpI7bh60rARUUUUAereIvj94u134KW/wrsdE8L+G/Dy+SbuPQdP+yyak8aqBJctuO9yUVmIAyQCfSvKaKKSVgCiiimAUUUUAFFFFABRRRQAUUUUAeg/tCf8AJx/iP/t2/wDSWKij9oT/AJOP8R/9u3/pLFRXRmP+9Vf8UvzZ4nC//Imwf/Xqn/6Qg/Z7/wCTj/Dn/bz/AOkstefV6D+z3/ycf4c/7ef/AEllrz6ql/usP8UvygKh/wAjnEf9eqP/AKXXPdPEH/JjHgz/ALDEn/od3Xi9e0eIP+TGPBn/AGGJP/Q7uvF66sx+Kn/gj+RwcJfwsV/1/rf+lsKKKK88+rCvrf8AZOtPCfhvwHrnj+71O2HiB53sIEEzRzQQKiuxXgoxYkEq3VYyB1Ir5Ir0H4RfEfXPhr40bWdIS3u4igNxpt0MxXYUggezqNzKeuRjvXPiqcp03GO504OcIVU6i0Ps7VtM0u3+DHjv4u3VjBpniVtJu9Js7mP91sjl2jaqdBukc7MjcqkD2HwjPp7Ne3UcAcfZMD5CQcg8HPr97n6V7j8VvjvN8WbIWyaXHpOnRzrcuGky8joPlLYO0DknuTxyMYrz7QbWwbTt0swhmuwZJGu5ERRhSR85wMYB4POcAE548+hGdON5bn0cfq9eo4SaUXrf5PT77HE6hP4j+IfiGFddWK6ubGINcau+Uaa3BwvmlR87n7oIG4k856jalW11We4jeKOyuoF2wI2FKpgKqH+8MBRkemeeRWrrrWGm6E8ejKcQjdNKCCLiUnBYYHQDAHbO4jg5MGpWf223t4GODI5dnU4KiNR/7NIPyrpbscFCklJ21snfzXT8ba/M9strTwv8G/g1omvaRNbXOp+I7GO4DSTGSRtuRI8i8bFRyyBRgEjGeGI8V1rWLnXfFzid5tX1Bzj5czD/AICq4LfThRjGABUKaLdX93aRXN7cywQyJGqPIWCKXzgf3QSWOPUnuSa6jwbra+F/Der6npj+RquoI8zTLASRGWZQPN6IQ2SV/i+UDJrOjSSk23dnTiMTU+rpQXLG9l5/1p6u/lblJJtWunazi0sDDbGe7dcbun3R6HisjT0ki1W7tNUtY4A8ckVxGB8qrtJ3j/dIDD/69dRBcIySqFLESGFBnltoGST9c5NUPElheXCPcTCFTIgYEMFZimN2Rndgrz06qK3hLlmuxg8KqmGlOKbmmvS3n2OKs1b7SHUZbov+8eP06/hW5p63EayPbxiRkXZNGwyJk5Uhvyznsa1/Dfh0GU3MoDbSVUY+XPfFbHh/SWXxdqlmF+4A2PQNgj+ZqKuIV210PRwGQStTVZfG2vwb/Q831G1jtrvMBLQSDfET1x6H3ByD9Kp16B438LtpsRuI0PkTMXQAfckAyw+jKM/Va8/rqo1VUjzI+dzLAVMBiJUKi1X5BXtXwX/5I98Wf+wN/wC0LqvFa9q+C/8AyR74s/8AYG/9oXVerlf+8r0l/wCks+G41/5FE/8AFS/9OwPCa3vBFxBafE7w5dXU8cEEOqW0kksrBVRRKpLMTwAAMkmsGivLPqz1O08Y6JfaRq9tKZLa4vrBm1SWRlUXUsZjjjEXOWYr5jnPJZ24wM1NqP8Awh/9rW39rf8ACNf2f/bkX2H+y9mf7Pw+/wC0eV8+P9R/rP3n368moquYnlPUT/Yn9qaT/bH/AAin9tbL7/jz8j7D/ql+yed5X7rPmeZ17bN/GawfiDcRz/8ACNxCfSZLiDSTHcrpTRmGOX7XcMVAj+UHDAkLx82RwRXGUUXHY9o1mfT1+Oum68tr4RttP/4SaC4OrWWtLNNLH5+d8kf2lwi4+Yny1xgdBwebszoY8YaTLpdlo11o/wBmkEMN3cWsE0b7MM1wbg7GkViGAbKMBhQOQPO6KOYXKetw2VssHim50y48J392l/pqQ3d/a2cNugeC4aSNB/qARtAO07W2FhlttVta1DwMni7w5ptpbaR/wjryvJfzW8CmUr9vuNqtJgyKojEeBwxQrnPy15ktzcLZyWizyrbyOsjwhiEZlDBWI6EgO4B7bj6moqOYOU9bvZ9FbxdpBTwv4eXalyDKut6VJHICgCMyrHHCpQncolXL5IOccc747j0aLSrZbC/0u9vDqVy00tlb28BEZtrQqpWD5Nqv5ygr8pYOR1NcNRQ5AkWrjz/7Os/M+y+Vtfy/K8vzMbjnzNvzZz03846cV6N4q1TS9a8HWmkaTqdpZ3dppdjLdp5yhNS2WsQ2l88SREMPKJwecDfkN5fRSTHY9l12awHxvsNdW08I29gfEkNwdWstZWaaWPzs75I/tLhFI+Yny1xgdBwc6w1nw7NqPg5tLn/s+x03xKJrqHUr1JZV8ySI+cr7UHlbYTnCjaRkk7hXldFPmFynqFpcLofj631VbPwvoZS01IxXGkawLovIbSURl83Muw7ioX7uS2OTjGd4zvtFvvh7o95pd1arNfajdX1zp8TjfaSNFbo4K9VQvG7L22kDsa4Cijm6DsFFFFSMKKKKACiiigAooooAKKKKACiiigAooooA9B/aE/5OP8R/9u3/AKSxUUftCf8AJx/iP/t2/wDSWKiujMf96q/4pfmzxOF/+RNg/wDr1T/9IQfs9/8AJx/hz/t5/wDSWWvPq9B/Z7/5OP8ADn/bz/6Sy159VS/3WH+KX5QFQ/5HOI/69Uf/AEuue5+HP9N/YZ8Tfbf9I+w6yn2Tzvn+zZa2z5efuZ82Tpj77f3jXjFeyfs5n+2G8beBf9T/AG1o7f6Z97ydu6L7nG7/AI+c9R9zHfI8fuLe4tLyW0u4JILiFzHLDKpV42BwVYHkEEEEGurF+/Qo1fLl+ab/AEaPPyBqhmGYYN786qL0qRXTylGXrvZXV46KKK88+sCtrw2YTfTwuyiaW3kSDccZkI+UA9iecH1xWLQOtA07O51Fla2EUjC8cmVTgLKD8hH14z9RxWnfyJLaW6I5CeauGjPIGCMj6V7B4A/Zg8bfEvwbp/im/wBS0/w3FdwK0C3UTzS3KYwsuxcbFYAEbjk9QMEVS1r9mD4s6P470/wjbwaZqMd7vlg1KCfbDHGmNzyhhvjA3AdGySACScVwSq01Nx5tj0oQqKF1HRniVzdLcWsUc8ai4WVVkkUY3Lnv2rp7WeGTxAqvMEEcbADklgW+bHB7AV7Zqv7EvjtdKWfSfGGgahdL+8e0aKW3Dt/dWRsjr/eA/CvGfF3hbxV4V1S30fxTol3oWqWcWyMT8eeAxPmK2drjG1coSMKKlThV0izehVnhpOU472/NP9CW7maxjSQOieRiULIQCWI56deg4ycU2zFvL4bijmhA8q2UoRK5BZlALY3FQfU49qzLPUo5JQ+ors2KwMa4UEEHG3JA647+tQNNKumwYYS+SvKLg9fvEfjVKD7nTPMKbTioXWtr2e6S7aWt07eeieHLjdbxmbmRp5IyPQLkn8z/AErq9Wh0efSdI1KO701Gtwf7Rs7yceZO6SHJROXYPGV6AAEHpXBaHPu15wp/d5eZf+BACuu07U1E86xwRzxkrFKjKx3HPG0r8wI9RnqQQap6amWDk5pU77u3y27pfezjo9c1Lw/4llW1vLie2hmZViuNwEiZ4yp5GRg9iM11tx4ys9Fv9U1nT1juLm+jt0t45OiAR7mZsehIGO5+lcx4sgjuLmTU4xEjrN9mkijJZVAXMeCQCSFG05AOVzjnA5itJUIVbS6E0c3xmAcqKlqnpfWzs07fJ/fqek6f4+k8S2U+g+JIrcPcL/ot1GuwJKOVDDpgnjPbPPt5zMhjuHjKlSrEYPUUwEg5FOkd5JDI7FmY5JPc1dOiqbfLszkxuZVsdGLxD5pR0v1a7P0/UbXtHhb/AEP9inxxf2f+j3cupR28lxF8kjxbrYeWWHJXEkg29MO3qa8Xr2r4rwXHhT9mn4feC7uCQ3Fw8mpSvKpieBgCxhaM5OQbvBJI/wBX0549bA+7GrVeyi185aL8z4LidqtUwWCXxTqxdv7tO85evwpfO+trHhNFFFeWfWBRV6HT08pZLy4MIYZVETe5B6EjIAB+uehxg5qT7Fpv/P8AXX/gMv8A8cquViujNorS+xab/wA/11/4DL/8co+xab/z/XX/AIDL/wDHKOVhdGbRWl9i03/n+uv/AAGX/wCOUfYtN/5/rr/wGX/45RysLozaK0vsWm/8/wBdf+Ay/wDxyj7Fpv8Az/XX/gMv/wAco5WF0ZtFaX2LTf8An+uv/AZf/jlH2LTf+f66/wDAZf8A45RysLozaK0vsWm/8/11/wCAy/8Axyj7Fpv/AD/XX/gMv/xyjlYXRm0VpfYtN/5/rr/wGX/45R9i03/n+uv/AAGX/wCOUcrC6M2itL7Fpv8Az/XX/gMv/wAco+xab/z/AF1/4DL/APHKOVhdGbRWl9i03/n+uv8AwGX/AOOUfYtN/wCf66/8Bl/+OUcrC6M2itL7Fpv/AD/XX/gMv/xyj7Fpv/P9df8AgMv/AMco5WF0ZtFaX2LTf+f66/8AAZf/AI5R9i03/n+uv/AZf/jlHKwujNorS+xab/z/AF1/4DL/APHKPsWm/wDP9df+Ay//AByjlYXRm0VpfYtN/wCf66/8Bl/+OUfYtN/5/rr/AMBl/wDjlHKwujNorSNhYsMR6hKG7GaDav4lWY/oaoTQyQTNFKu116jr9CD3HfPek00CYyiiikM9B/aE/wCTj/Ef/bt/6SxUUftCf8nH+I/+3b/0liorozH/AHqr/il+bPE4X/5E2D/69U//AEhB+z3/AMnH+HP+3n/0llrz6vQf2e/+Tj/Dn/bz/wCkstefVUv91h/il+UBUP8Akc4j/r1R/wDS650vw+8Vf8IV8TNH8TND50VpN++QLuYxOpSTaMj5tjNtycZxniu3+PnhOXw38YL29itvLsNX/wBNgdd7KXP+uBZuN3mbmKgkAOnTIA8jr6F0Rf8Ahb37Lk2jiLzvEvhDb9m2R5eWAKdiDbH/ABRqyBFOWeGNmPNdWC/f0Z4br8UfVbr5r8jy89l/ZmYYfN/sP91U8oyd4S7WjPR+UjwaiiivPPsAr2/9mj4JyfFr4kfatXgkHhbSGWbUH6C4Y8pbKfV8EsR0UMepFeUeGfDGteLfF2m+G9Ds3uNQ1GYQ28eMBiepJ7KACSegAJ7V+pvwv8EaL8Lvhfp3hDR2WRbZS9zdbdpurhseZKfqQAB2VVHauPG4j2MLLdnXhMM60vJHXxWdvaRq5KxxRLwqfKiKB0wOwA4HbFcr4dvj4l1fVvE0EeYXn/s22J6+VB9785Xkz/uj0rl/jp8VdP8Ah58KNTvnlVr6aIw2kAPzSysMIoHuf0DHtXd/D3QpPCnwp8PeH7t/NvLSxjW6lPWS4Yb5mP1kZzXgcr5Wz6CT5LX3/T+vyNpJobCzik1CeKNpJFiB6Auxwqj1JPFZ3jDwV4V+IHheXQPFmjWuqWD8iOYfNE39+Nx80bD+8pBriPi9rotJPC+nw3HlXE2qCZMNg/u4pGGPXkdPaur8NeKIdZ0xZSVS5TAmjz0PqPY1KvGzRU8NKVP2j6nwv8av2dvEHwlun1zQ7f8At/wk78XDRA3NkSeEnA6jsJAME8EKcZ8fi1m1vNLuLWPELSKrwsAOJV5AyPUEj8a/Urxqlnqvw18QWF2FaGbTbhW3Hj/VsQfwIB/CvzD8T+H7O08QgiVbdbxUkRsYEMjZ+Vh2UsCD3Bx616dDEOouWQYTBSinWptaPlafVSTXy7X6No5GC7MOoyzovlvPHtwONpzk8evNdDp9yLHRDc55Zt6D1PRf5Vzd1bzrqyw3sYiulkZXHoT/APrrca3eZ44iwSCMYGOprv0aPETlRqOK0aduzJyItZW5ivJR5186vHKWwEmG7aW9mLbfbOe1cfJG8UzRSIyOpKsrDBBHUGu6TWdNt/D95pht/OCDcmzGATnOT9QDx71h61D9u8TSeYWWdo4/O8uMvul8td/A985981pRm7NNbHVm9KNSVPEQld1Fdrs9n971OfoqxLZTw26yyhV3HATcN3/fPUVX71smnseLKEo/ErHW/DTwnL4z+KGk6L9m8+0MwmvQd4UW6ENJuZOVyPkB4+ZlGRnNaPx48Vf8JT8a9S2Q+XBpX/EqiyuGbynbezckH940mCMfLtyAc13vgxf+FS/s56n8RLiLytf13FppW+P5olOdjDdGcZw82DlHWOLoTXzxXpYn/Z8NGj9qfvP0+yvzZ8blsv7Uzitj/wDl1QTpQ85OzqSXpZRv1s+wVc0uNJNUTzFDqivLtYZDFELAEdwSOfaqdXtI/wCQmf8ArhN/6KavLjufXvYezM7s7sWZjksTkk+tJRVrTNOu9Y1uz0nT4jNd3k6W8EY6u7sFUfiSK1EVaK9i8f8AwrtNL8TeG4LXTb3wtpl7dvo095rMUsSvLC4BvP3uMJKjo4GQoIcAgDjOuvhhY2qSWr6jc2MT6nptoNQ1ywFmyJcLd7nQpcyRNF/o4+Yk5IwGQK28A8uor1aD4f8AhDS5vFdv4iu/E8MVlocN/a3U2jxJIrNfQQmSONbwpKuH2A78He54MahqGv8Awst/D/gV9YuvF2lf2pHawXb6Wbq03sswQhEVbgzGQLIGIaFRhWIY8ZAuecUV3vjb4faZ4Xi1z+y/E0urS6HrI0a/WSw+zASN5xRoz5jbh/o8gbIXBxjcDmrug+ENB1z4FNcRWrL4ql1G9aznErYnitre2ke22Z27is0rqQNxMYXncKAuea0V7RefBzTtX8deJ7DSr+TRkt9Yu7DS7e4+z/Z5hFyEEk10szsMgEJFIRlSSc4HLaX8O9MvdEt3vPE8lrq1zo15rkFilgZIzDBHM4RpfMGHfyG42kBTnJPykFc4CivQtW+GI0/4YHxXDq8n2mCG2nu9MvEtopY0m2hWVI7mSXbl1wZIo8hgfatX4UfDM+MfD2o31x4b1TVVu5xo9jPZxSsljcPGz/aZSnARG8lSH+XbKx/hyAdzyiiuq8V6HaaP4U8Izx2bW97e2FxLfbmbLSpfXEIyCcKQsaLgY6euTXTan4DZvA+jWOheGYLvV3to7jUrpb1vtFlJJukQToW8pIGgMbBsDBJDOCCtAHl9Fd78LdF8Mazf+IV8VwbrO30nfHP5rp9klku7eAT/ACkbtgmZtpyDjkV0978LtKi0nwn4Vki+w+J7rXo9J1a/3NKInmVHVBHuCny1kTOMEtuBPTAK543RXoPgfwvay2Ntr975N1FeWniG3FpNAGWN7XSvOSUEk5O6dSOBtMYIOTxp+I/BXhKN9TTw1dXDy2vhjTdSli1C18lI5J/7PG+OUXJG5zdOzb12JllUH5XQGeV0V6v4R8JaDpnhfxPd+Lk8Hz3VldWEMFxqOoXV3Zosy3LMofS3Ys58pOpIG05wTyad4R8GXHhO91jXpZLKOTw4dVt30izkn8lv7aNpu2zXK7zsAQA7RsfJG9N0gK55RRXX3vgb7G2uAapvGl6HY61nyMeb9pNp+6+98u37Z97nPl9Bu4rePPDWleEPG2oeGtO1yfVptOuprS6mezFsgeNyvyfvGLdOcgYOQNw5IM5miiigAooooAKfcqJdE8xvvQTKin/ZcMSD7Arkf7zetMqSX/kX5/8Ar4i/9BkpPYDLooorIo9B/aE/5OP8R/8Abt/6SxUUftCf8nH+I/8At2/9JYqK6Mx/3qr/AIpfmzxOF/8AkTYP/r1T/wDSEH7Pf/Jx/hz/ALef/SWWvPq9B/Z7/wCTj/Dn/bz/AOkstefVUv8AdYf4pflAVD/kc4j/AK9Uf/S64V1Hw98X6r4H+INjr2k273cikxSWQdlF1G3BjO3qehGQQGVTg4xXL133wo8Z3HgzxZLdW2n2V69xGIniuYVcvHnLIrH7pPHTOcYPHFYQqSpyU4OzR62IwlPGUpYatHmjNNNd09LHS/GXwFYaRex+N/CjWjeGNWkCxxQAxm0nKbjGY25XO12xgbDuQquFz53ounx3d+sl46Q2ceXkklDbCB/DlR1JwPx7V7Z4x0+aXwhf+Mvh9c3H/CK3TbtR0mEBX0qRSG2PH08sNgq4+7xnjBrzC2tbrVJyls97fKCXKxckccnA6e5xVYnExqTc4x5b9Ol/LyFk+V1sJQjhatV1HHRNr3mlspd2tm+u7V7nTDxFd6brmk3Hh29ubBtPCzW00FwdsW05KpggDIyCD1BOd2a+uPEX7SngrS/hVF40S8ZUuAyR2jAGfzh1hCZ5YZGT90Agk4Iz8Kgvp8j2sds2HI49Tz149cHA/pXHeIrqK51FLeGX7Q8RKtOGyrk44HsOme/0xXl1sPGok30Po/r8qUnJxV38ku1l6f139y8GeJvEf7Qv7XvhH/hJw6aNFqH2xLPOYo4Yf3rDJ++zeWFJ75AAAwK/SG41NYonlmfZgFnJ7dzX5dTrY6V4cXTpLR47u1lMcYgJaNUDE5DqefmJPTPU57V6Pb/tA+P7D4WR+EFiguhDbNDHrUssjzIvLLI/UEqCAMnqq9cVhWwznZROilaDcqr5m0m2tbeXk/wPdPGOt2vivxLf67qEywaVpyNFaXLHHlFTl51J6bSoUHvtfqDUPw5+IMHiTQY9e0mbyriFzBcw4wUceq/3WGGHscdQa+Lv+Eu1a68NQaBdandmzgyUhlnd4c5zynrnn09hVrwZ421bwX4kk1TTdQMbTIY5kZPNjlHYOmRnBwQQQQfYkVUsBLla6nfTzjD+6l138j7j+K3xUtbD4R6hp7EQ6pqcf2O3QtlWyRvbrnaFzn6gZ5r428Q6rb6w169+jS3f3BK0mcne7OQ3fnaBnnk4rL8SeK9b8U376lfXkt9Ow2iY4AjX+6iL9we348mufM05hET8KOMkYrbDYeVONmcWY4rDPlVJXad276W7dvO/yHXry6gsV/cDfPCRFNzyy4xkn16H6k1H9quG/wBEspJX3HaQ/wAuz2JPf2FLFd28Ftdo3zvJGFQDpuz1PsBn8cVt+ALbQNf+Iul6V4x8QnQ9Knm2zakI1byeDjOeACcAsenWurk5Ytnm4mvHEVIyv7z39b21fnoZq2d5ZpHHIkLl5Qw2ljyvIGcd8Vft9P1W0uPtMSLKxG5zz8wPOeffmvszTfC37LvgbxCPCGtW1jc+IWCPBL4qmeWC7jfhJIZgDAFYdDgYOQeleP8Ax9+FHhPwr4bfxD4It5dNuLa4C39mkzr5QfoPLZmK84KlSUdWypOCBywxCk1FaXOtUo8r9pHm5V0dmlq+2vzPJlkt7uQJeQGKbqvY59mFO8M+E9E1L4j6dbeIdUhstMMxuLue7cqs0ancY9wxsJwQWJGAS3bFZfh228Q67a38kUPn2enwefcXcxCrb/3BvPVmIwF5J57AkWL24DxpdM4IBVEGPvHdyfcYyPxNdtPmpTjKcb/k0eNjFSxVGrQwtVrRrpzQk1o+19mvLoR/Fnx4njjxsP7NiittB0tDY6Xbwblj8lTgSBCAFLgLwFGFVFOduTwVSXAjW6lEWfLDkLn0zxUdbVq0q03UnuzzsBgaOAw8MLQVoxVl/m/N7t9WFXtI/wCQmf8ArhN/6KaqNPhlkguI54m2yRsHU4zgg5FZp2Z1su1d0jV9Q0LWYNW0q4+z3kBJil2KxQkEZAYEZwTg9QcEYIBqvGILtd8EsML/AMUMsmzb7qzcEe2c/XGS/wCxyf8APez/APAuL/4qtSS7pniTVtIsXsbOW3e1e5ivGt7q1iuY2ljDqjFJVYHAkcEYwc8g4GNS6+Iniu9CR3N1p720csMqWX9mWotVaHzvLAgEflhQbmclduGLkkE4I577HJ/z3s//AALi/wDiqPscn/Pez/8AAuL/AOKoFodCPiL4rGs/2l9qsNwtDYfZf7MtfsnkGTzPL+zeX5O3zPnxs+9z15qte+NPEGpeHE0TUJbC6t0jSFJptOtnukjQjYi3Jj85VAAAAfG35enFY/2OT/nvZ/8AgXF/8VR9jk/572f/AIFxf/FUBoX9R8Ua7qx1c6hfed/bF+up337pF864XzcPwBt/18vC4HzdOBhLHxNrumW2mwWGoPAmm3zalabFXMVwwjBcHGTxDHwcj5enJzR+xyf897P/AMC4v/iqPscn/Pez/wDAuL/4qgNDrIPix49ttRub+LWoTdXF5LftO9hbu6TS48xo2aMmMPgBlTapAwRV7RPig+ifDefw5Fp1zcXslnc6fHd3E8LRwQThg6Iog84DDudvnFNx3bc1wv2OT/nvZ/8AgXF/8VR9jk/572f/AIFxf/FUBob978QfFuoeGZdAu9ShexmhhgmC2cCSTpEV8oSSqgdyuxQCzEgDGcEisebWdTuNK0/TZLo/ZdPMjWsaKF8tnYMzZABJJA5OTgAdAKg+xyf897P/AMC4v/iqPscn/Pez/wDAuL/4qgNDR8Q+Kte8V3cVzr16t1LF5uxhDHFjzJnmfhFAOZJXb/gXpgVrW3xP8bWdhHaQarBtS3FmZHsLd5ZLcLtEEkrRl5ItoA8tyVwAMcCuY+xyf897P/wLi/8AiqPscn/Pez/8C4v/AIqgNCWx1a/0611C3sp/Ki1C3+yXS7FPmReYku3kcfPEhyMHjHQkVPZeI9b06ytLSxv3t4rS9Go2/lqoaO4AUCQNjORtXjOOKp/Y5P8AnvZ/+BcX/wAVR9jk/wCe9n/4Fxf/ABVAXR0V78RvF9+bfz9Rt0W3S7SGO2sbeCOMXcIhuMJHGF+dBg8cHLDDEmq1z438SXei/wBlT3lu1ubFdNdls4Flkt1eJ0jeUIHcKbeHbuYlQuBgEg432OT/AJ72f/gXF/8AFUfY5P8AnvZ/+BcX/wAVQGhLDq2oW+gXeiw3G2xvJorieHYp3vEHEZzjIwJZOAcHdznAxp6b428SaV9lW1vLdo7aybTo4LmzguIjbtO1wY3jkRlkHmsX+YEg4x0GMf7HJ/z3s/8AwLi/+Ko+xyf897P/AMC4v/iqA0N2fx/4sufC0vh6bUYmsJrWKylUWkIklhidHjR5Qm9ghjTbljtA2jAJBxtW1S/1zX77WtUn8++vriS6uZtqr5kjsWZsKABkknAAFR/Y5P8AnvZ/+BcX/wAVR9jk/wCe9n/4Fxf/ABVAaFeirH2OT/nvZ/8AgXF/8VR9jk/572f/AIFxf/FUBcr0VY+xyf8APez/APAuL/4qj7HJ/wA97P8A8C4v/iqAuV6kl/5F+f8A6+Iv/QZKkNrsG6W7s0QdWE6vj8EJJ/AVRvLpZgkMIIgjJK7vvMTjLH0zgcdBgdeSVJ2Q9yrRRRWRR6D+0J/ycf4j/wC3b/0lioo/aE/5OP8AEf8A27f+ksVFdGY/71V/xS/NnicL/wDImwf/AF6p/wDpCD9nv/k4/wAOf9vP/pLLXn1eg/s9/wDJx/hz/t5/9JZa8+qpf7rD/FL8oCof8jnEf9eqP/pdcKVWZHDqSrA5BHY0lFcp7h3Phz4iarpWqwXKzi2mACyTR5CzDoPMXOD9cdzkHJrtxp9p4lklHhrVE8PyTMZJLO2iHlmQnKn5SGCZ6AZA7AdK8PrQ07W9S0uVXs7l0KnK8/dPt6VLirWsddLFzjU55Seu9t2jq/FVx4m8N6df2uuXd0JpU8mNi+5ZmbjcrY5AUNzwRwDiuR0LQhHt1HUEGQvmQwPGHB/2pFJHy9OMc57Dr6/py+IvGXhSy8RyRWOo3EBkSO2jbMsIXG6RYm4aQ46qSwUDAGa5XULu2miJWB5pQd3lqj7mP0xnP61i42e1jtrTVeXO6jkltff8/wAjMghmuY2cyyxA/cWMsoc8c4PQc/561avpb2DQLyCe+kSV0UtZRZCom4DMmcfMeMKBwDye1dLo+jeJHgvLm30+XS3KKI7u7iKGGHq0gUjIwowDgAZJyOtZHiCDwjp3h66jtNYuNT1WfChnO4L84LMdvGcDvnrTUJXTa0LjOnClL2clzW11tZarvdt9F0T69OEooorrPEFDFTlSQfahnZjlmJ+pzSUUAFblp4anewF9qF1FYQuhaFJAWmm442RjnB45OBz1NUNMmtbW8F1dRiYR8rERkM3bI9BXc6F4T8cfEHUY7jSvC8kkFxz/AGjeBktgofYx3nCtg5yF3Nw2AcGlGnVqy5KUbs0niMDg6DxOPqqEfN2Xzf5LdnGtZ6jdLEl1eKRCnlxrNPu2ICTtAycDJJx7mtCWzF1vF1f3V1siWG3EjO7RqDkAcYK8nA4AzXrJ8H/CP4USLd/ELWF8Q6+hV/7E09d0cTfu2wY8jOMkgysquhPyEivLPHXxM1jxtPFAtpaaLpNspjt9M05fLjCbsrvI++wAUdAo2/Kq5OerEYL2Ef3s0pfyrV/PsfP5XxEsxrf7HQlKj/z8l7sX/gTV5etkvMvSa5Na6IujWrzwaQsjSJbSyLEjMQBukxjzGwoG4jtwAOK5nUdWiLP5EgmmYYDqCEiH+znqfesEkk5JorgactZM+ijUp01alG3X59X01ffVhRRRVGIUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAeg/tCf8AJx/iP/t2/wDSWKij9oT/AJOP8R/9u3/pLFRXRmP+9Vf8UvzZ4nC//Imwf/Xqn/6Qg/Z7/wCTj/Dn/bz/AOkstefV6D+z3/ycf4c/7ef/AEllrz6ql/usP8UvygKh/wAjnEf9eqP/AKXXCiiiuU9wKKKKANHSde1jQpzNpOoz2jHr5bcN9R0NdW/xk+Ij2DWreIZdrLtLhFD4/wB4ciuDooGm0dz4S+LnjfwdrM2oafqEd2Jzme3vo/Njk4IHTDLy2flZckDOQMV3s3xn+G3jCUN8RfhdG1wUSSXUdLlHnTzKoTnmNwmM4BkbGFGDjI8Jorto5hXpQ9mnePZpNfifP5hwzl+Or/Wpwcau3PCUoS++LV/nfp2R7p/ZH7Mt6Ptv/CZ+JNN8/wDe/YvJdvs27ny8/Z3ztzjO5un3j1p3/Cl/h9/0Xfw1+UH/AMkV4TRWv16lL+JQj8rr8mcf+r2Npf7tmNVd+ZU5+lrwuvPe/U92/wCFL/D7/ou/hr8oP/kim/8ACLfs4WZ+x3/xK1ue7h/dzy2sLGJ3XhmTFuw2kgkYZhjHJ614XRR9epR+ChH5uT/UP9X8fU0xGY1Gv7qpw++0Hc92g+K/wb8KXkV34L+FMt1cFxI8urTgPAyHKNEWMxBySSRt6L14xyfir48fEjxT5Sf2x/YsEeD5WjF7bcw3fMX3Fzw2Nu7bwDjIzXmtFRUzLETjyJ8se0UkvwNsNwlllGqq9SDq1P5qknN/+TNpdtEgooorgPpQooooAKKKKACtfwqtk/jjSE1GFZbVryJZEYgKQWA+bIIK+o7jI4zmsiihAz1/RNNFn4o1RLeC+02CLXLL/Q5dhWQGZ8MP3YIXHKgHGD1aq1r4c0W1+Ktj59rJqdtf/am+0yMht3l2ufLCFTyp+XDEHdg4GMHymitOfyI5PM9A0fwRpmpQrJcQ6rbNJdvbyxmRM6aqqCHnygzk+yfXNXb7QbTUPhXo9z5s13cWVnOYrW1YKzr57ZlOQcouOQBnkdBzXmVFLmXYfK+52On+C3SDVU1Wxv7rUrCSOP8AsrT5U80hxnfkK+VAx0B69qs2ngvS7jwumoPPeKXs5rl7vevkW0iEgQONuSxx6g88A1wtFK67BZ9z0aXwd4VtdGmup/7YkkttPtL2TZcRqrmYhSqgxnABOcnNV77wrp2j64dBlJmF5qy28UrgeYIUALYOOCzSKufVDXA1I1xOyRI08hWEYjBY4QZz8vpySeO5p8y7ByvuemXekadceDJbqXSoYIhBHIs8cUcaRloJJPlcLvYq6JGQ7Nkk9CRjPu/BegLpEnkXN/Ddw6ba6hJNNIjRfvWAZdoQEAZzndXJXviDVtQtGt7u4jdXIMjiCNZJSOm9woZ/+BE1mUOS7CUWejax4F8OaTeWAkvtSa3lvo7aSYRvskjYf6xJDEEBB/hDPkd6XUfh7pGl6ReXN1qkwkslEFwNy4S4dozH25TZISe+VPIrziijmXYfK+56/ceEtOs/Ck+hBr2ys59at4jf3jqyTLsP7yPCgBTnHU9uetYg8B6Q2q6fBLLqFi1x9pzYXDobiTyhlCh2gDf2yPpmvO6KHJdhKL7nrGteGrS+t9ItprTUons9F82LS96/apW80/JnZ1GST8mcdqpWPw80W513UrBbm/na38rygpKIhZNzLLMsUiqynjkD+leaUUcy7ByvuegWXw/guvAt1rEplimhs5rtJY5/NifyyflIEQVcgf8APQnvjHTVtvD2n6J4E1yaKHULiCfTbaSS+3r5M251Zkj+XgjpyT7gd/KqKOZdhuLfU9KHw+8Ppqtpaz6xMq6hI89iwdf3lqIwy5wpO9mbaMD+FsA8Cq0ngzQLXVNQFy+rNb2ulG/MBVoJA4cLt3SwruX/AGgg/SvPqKOZdg5X3PTn8MaHYaB4mtLfTLzUZkisrqAh0M8cbqWO0iM4CnO4gYIx93GTQuPAVnHoV1q0ZvmtE022uoZ9ylHlkYB1zt5AyeByOM1wFFHMuwcr7nozeCfDUvjnVNBtp9RT+zoi22WYPJdN8vCBISVAyc4VyeOBzXH+JdLttG8TXGn2ctxJDHtKm5heGQZUHDK6qeM9cDPXvWTRSbT6Ak11CiiipKCiiigAooooA9B/aE/5OP8AEf8A27f+ksVFH7Qn/Jx/iP8A7dv/AEliorozH/eqv+KX5s8Thf8A5E2D/wCvVP8A9IRyngPxNJ4O+JWi+JVeVUsrpXnESK7tCfllVQ3GWjZwOR16jrW78UvCVv4O+I1zZaZJFNo94i6hpc0UgdHtpclNrbmJCkMgYnLbd3QiuArvPBvivRJ9Ot/BXxCW6n8Ned5lte2x/wBJ0iRiN7xEhsxP/HHgj+NRuHzFCcZwdCemt0+z638npr5LoVj6FXD4lZhQTlaPLOK3lG9013cG3ZdVKVtbJ8fRXp03wU1nVZRP8O9c0fxpYFEkaSyuo4J7cMoK+fDI4MZJ3gDJPyHIU8VH/wAKA+Ln/Qpf+T9r/wDHK0/s/E9Kbforr71oZrijKLe/ioRfaUlGS9YytJejSPNaK9K/4UB8XP8AoUv/ACftf/jlH/CgPi5/0KX/AJP2v/xyj+z8V/z6l/4C/wDIP9aMm/6DKX/gyH+Z5rRXpX/CgPi5/wBCl/5P2v8A8co/4UB8XP8AoUv/ACftf/jlH9n4r/n1L/wF/wCQf60ZN/0GUv8AwZD/ADPNaK9K/wCFAfFz/oUv/J+1/wDjlH/CgPi5/wBCl/5P2v8A8co/s/Ff8+pf+Av/ACD/AFoyb/oMpf8AgyH+Z5rRXpX/AAoD4uf9Cl/5P2v/AMco/wCFAfFz/oUv/J+1/wDjlH9n4r/n1L/wF/5B/rRk3/QZS/8ABkP8zzWivSv+FAfFz/oUv/J+1/8AjlH/AAoD4uf9Cl/5P2v/AMco/s/Ff8+pf+Av/IP9aMm/6DKX/gyH+Z5rRXpX/CgPi5/0KX/k/a//AByj/hQHxc/6FL/yftf/AI5R/Z+K/wCfUv8AwF/5B/rRk3/QZS/8GQ/zPNaK9K/4UB8XP+hS/wDJ+1/+OUf8KA+Ln/Qpf+T9r/8AHKP7PxX/AD6l/wCAv/IP9aMm/wCgyl/4Mh/mea0V6V/woD4uf9Cl/wCT9r/8co/4UB8XP+hS/wDJ+1/+OUf2fiv+fUv/AAF/5B/rRk3/AEGUv/BkP8zzWivSv+FAfFz/AKFL/wAn7X/45R/woD4uf9Cl/wCT9r/8co/s/Ff8+pf+Av8AyD/WjJv+gyl/4Mh/mea0V6V/woD4uf8AQpf+T9r/APHKP+FAfFz/AKFL/wAn7X/45R/Z+K/59S/8Bf8AkH+tGTf9BlL/AMGQ/wAzzWivSv8AhQHxc/6FL/yftf8A45R/woD4uf8AQpf+T9r/APHKP7PxX/PqX/gL/wAg/wBaMm/6DKX/AIMh/mea0V6V/wAKA+Ln/Qpf+T9r/wDHKP8AhQHxc/6FL/yftf8A45R/Z+K/59S/8Bf+Qf60ZN/0GUv/AAZD/M81or0r/hQHxc/6FL/yftf/AI5R/wAKA+Ln/Qpf+T9r/wDHKP7PxX/PqX/gL/yD/WjJv+gyl/4Mh/mea0V6V/woD4uf9Cl/5P2v/wAco/4UB8XP+hS/8n7X/wCOUf2fiv8An1L/AMBf+Qf60ZN/0GUv/BkP8zzWivSv+FAfFz/oUv8Ayftf/jlH/CgPi5/0KX/k/a//AByj+z8V/wA+pf8AgL/yD/WjJv8AoMpf+DIf5nmtFelf8KA+Ln/Qpf8Ak/a//HKP+FAfFz/oUv8Ayftf/jlH9n4r/n1L/wABf+Qf60ZN/wBBlL/wZD/M81or0r/hQHxc/wChS/8AJ+1/+OUf8KA+Ln/Qpf8Ak/a//HKP7PxX/PqX/gL/AMg/1oyb/oMpf+DIf5nmtFelf8KA+Ln/AEKX/k/a/wDxyj/hQHxc/wChS/8AJ+1/+OUf2fiv+fUv/AX/AJB/rRk3/QZS/wDBkP8AM81or0r/AIUB8XP+hS/8n7X/AOOUf8KA+Ln/AEKX/k/a/wDxyj+z8V/z6l/4C/8AIP8AWjJv+gyl/wCDIf5nmtFelf8ACgPi5/0KX/k/a/8Axyj/AIUB8XP+hS/8n7X/AOOUf2fiv+fUv/AX/kH+tGTf9BlL/wAGQ/zPNaK9K/4UB8XP+hS/8n7X/wCOUf8ACgPi5/0KX/k/a/8Axyj+z8V/z6l/4C/8g/1oyb/oMpf+DIf5nmtFelf8KA+Ln/Qpf+T9r/8AHKP+FAfFz/oUv/J+1/8AjlH9n4r/AJ9S/wDAX/kH+tGTf9BlL/wZD/M81or0r/hQHxc/6FL/AMn7X/45R/woD4uf9Cl/5P2v/wAco/s/Ff8APqX/AIC/8g/1oyb/AKDKX/gyH+Z5rRXpX/CgPi5/0KX/AJP2v/xyj/hQHxc/6FL/AMn7X/45R/Z+K/59S/8AAX/kH+tGTf8AQZS/8GQ/zPNa7P4W+Erfxj8Rray1OSKHR7NG1DVJpZAiJbRYL7m3KQGJVCwOV3bugNbcPwU1nSpTP8RNc0fwXYBHkWS9uo557gKpLeRDG5MhB2AjIPzjAY8Vg+MvFeiQadceCvh6t1B4a87zLm9uT/pOryKTseUgLiJP4I8AfxsNx+Wo4d4dqpiFZL7L3flbdLu302Ma+axzKEsLlc+aUl/EjrCCel1L4ZSXSKbd/isrsxfHniaTxj8Sta8Ss8rJe3TPAJUVHWEfLErBeMrGqA8np1PWiudorgqTdSTnLd6nv4bDww1GFCkrRikkvJKyCiiioNgooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD/2Q==",
	"nangis": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwMDAgQDAwMEBAQFBgoGBgUFBgwICQcKDgwPDg4MDQ0PERYTDxAVEQ0NExoTFRcYGRkZDxIbHRsYHRYYGRj/2wBDAQQEBAYFBgsGBgsYEA0QGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBj/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4Poor0CxsV+HEdlrGsaclz4knVbmy0+6Q+VZR5IE0o4LSEqQqA/Jjc3zYA9HDYZ1m23aK3fb/ADb6Lr6Xa5a1ZU0kldvZd/66sxtH+HfjbXbb7Tpvh27aHarrJNtgWRWGVKGQqHGB1XPUeorS/wCFPfEb/oXf/JuD/wCLp2mvrnxO8fWWl65r05efzNkroGSHbGWO2MFVGfLAOMZ6nNd7/wAM+f8AU3f+SH/22vewWTxxkHPDUZzina/PCOvo4u2/d+p5mIzCWHko1qkYt625ZP8AFNfkjgP+FPfEb/oXf/JuD/4uj/hT3xG/6F3/AMm4P/i67/8A4Z8/6m7/AMkP/ttH/DPn/U3f+SH/ANtrs/1Zq/8AQLP/AMG0/wD5E5/7Zp/8/o/+AS/+SOA/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai67/AP4Z8/6m7/yQ/wDttH/DPn/U3f8Akh/9to/1Zq/9As//AAbT/wDkQ/tmn/z+j/4BL/5I4D/hT3xG/wChd/8AJuD/AOLo/wCFPfEb/oXf/JuD/wCLrv8A/hnz/qbv/JD/AO20f8M+f9Td/wCSH/22j/Vmr/0Cz/8ABtP/AORD+2af/P6P/gEv/kjgP+FPfEb/AKF3/wAm4P8A4uj/AIU98Rv+hd/8m4P/AIuu/wD+GfP+pu/8kP8A7bR/wz5/1N3/AJIf/baP9Wav/QLP/wAG0/8A5EP7Zp/8/o/+AS/+SOA/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai67/AP4Z8/6m7/yQ/wDttH/DPn/U3f8Akh/9to/1Zq/9As//AAbT/wDkQ/tmn/z+j/4BL/5I4D/hT3xG/wChd/8AJuD/AOLo/wCFPfEb/oXf/JuD/wCLrv8A/hnz/qbv/JD/AO20f8M+f9Td/wCSH/22j/Vmr/0Cz/8ABtP/AORD+2af/P6P/gEv/kjgP+FPfEb/AKF3/wAm4P8A4uj/AIU98Rv+hd/8m4P/AIuu/wD+GfP+pu/8kP8A7bR/wz5/1N3/AJIf/baP9Wav/QLP/wAG0/8A5EP7Zp/8/o/+AS/+SOA/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai67/AP4Z8/6m7/yQ/wDttH/DPn/U3f8Akh/9to/1Zq/9As//AAbT/wDkQ/tmn/z+j/4BL/5I4D/hT3xG/wChd/8AJuD/AOLo/wCFPfEb/oXf/JuD/wCLrv8A/hnz/qbv/JD/AO20f8M+f9Td/wCSH/22j/Vmr/0Cz/8ABtP/AORD+2af/P6P/gEv/kjgP+FPfEb/AKF3/wAm4P8A4uj/AIU98Rv+hd/8m4P/AIuu/wD+GfP+pu/8kP8A7bR/wz5/1N3/AJIf/baP9Wav/QLP/wAG0/8A5EP7Zp/8/o/+AS/+SOA/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai67/AP4Z8/6m7/yQ/wDttH/DPn/U3f8Akh/9to/1Zq/9As//AAbT/wDkQ/tmn/z+j/4BL/5I4D/hT3xG/wChd/8AJuD/AOLo/wCFPfEb/oXf/JuD/wCLrv8A/hnz/qbv/JD/AO20f8M+f9Td/wCSH/22j/Vmr/0Cz/8ABtP/AORD+2af/P6P/gEv/kjgP+FPfEb/AKF3/wAm4P8A4uj/AIU98Rv+hd/8m4P/AIuu/wD+GfP+pu/8kP8A7bR/wz5/1N3/AJIf/baP9Wav/QLP/wAG0/8A5EP7Zp/8/o/+AS/+SOA/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai67/AP4Z8/6m7/yQ/wDttH/DPn/U3f8Akh/9to/1Zq/9As//AAbT/wDkQ/tmn/z+j/4BL/5I4D/hT3xG/wChd/8AJuD/AOLo/wCFPfEb/oXf/JuD/wCLrv8A/hnz/qbv/JD/AO20f8M+f9Td/wCSH/22j/Vmr/0Cz/8ABtP/AORD+2af/P6P/gEv/kjgP+FPfEb/AKF3/wAm4P8A4uj/AIU98Rv+hd/8m4P/AIuu/wD+GfP+pu/8kP8A7bR/wz5/1N3/AJIf/baP9Wav/QLP/wAG0/8A5EP7Zp/8/o/+AS/+SOA/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai67/AP4Z8/6m7/yQ/wDttH/DPn/U3f8Akh/9to/1Zq/9As//AAbT/wDkQ/tmn/z+j/4BL/5I4D/hT3xG/wChd/8AJuD/AOLo/wCFPfEb/oXf/JuD/wCLrv8A/hnz/qbv/JD/AO20f8M+f9Td/wCSH/22j/Vmr/0Cz/8ABtP/AORD+2af/P6P/gEv/kjgP+FPfEb/AKF3/wAm4P8A4uj/AIU98Rv+hd/8m4P/AIuu/wD+GfP+pu/8kP8A7bR/wz5/1N3/AJIf/baP9Wav/QLP/wAG0/8A5EP7Zp/8/o/+AS/+SOA/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai67/AP4Z8/6m7/yQ/wDttH/DPn/U3f8Akh/9to/1Zq/9As//AAbT/wDkQ/tmn/z+j/4BL/5I4D/hT3xG/wChd/8AJuD/AOLo/wCFPfEb/oXf/JuD/wCLrv8A/hnz/qbv/JD/AO20f8M+f9Td/wCSH/22j/Vmr/0Cz/8ABtP/AORD+2af/P6P/gEv/kjgP+FPfEb/AKF3/wAm4P8A4uj/AIU98Rv+hd/8m4P/AIuu/wD+GfP+pu/8kP8A7bR/wz5/1N3/AJIf/baP9Wav/QLP/wAG0/8A5EP7Zp/8/o/+AS/+SOA/4U98Rv8AoXf/ACbg/wDi6P8AhT3xG/6F3/ybg/8Ai67/AP4Z8/6m7/yQ/wDttH/DPn/U3f8Akh/9to/1Zq/9As//AAbT/wDkQ/tmn/z+j/4BL/5I4D/hT3xG/wChd/8AJuD/AOLo/wCFPfEb/oXf/JuD/wCLrv8A/hnz/qbv/JD/AO20f8M+f9Td/wCSH/22j/Vmr/0Cz/8ABtP/AORD+2af/P6P/gEv/kjy7WPh3420K2+06l4du1h2s7SQ7Z1jVRli5jLBBg9Wx0Poa5ivSfEFlrnwk8YRWeh+JJ2ee2W4d0iEaNlpEAaMllbGCQT0zxjrVa+sV+I8d7rGj6clt4kgVrm90+1Q+Vex5AM0Q5KyAsAyE/PncvzZB8XE5dBTlSpJxqR3i2n90lZN+Vl5Ns9Gji5cqqTacH9pXX3p7Lzv62PP6KKK8Y9A6f4daPDrvxR0bTbnyzC0/myLJGJFkWNTIUKnghgm38eh6VB4k1y48SeK77XLpdr3UpYJkHYgGFXIAzhQozjnGa2fg9/yWnRf+2//AKIkrkq9NvlwEEus5X+UY2+7mf3nGtcVK/SK/Fyv+S+4ns7280+9S8sLue1uEzsmgkKOuRg4YcjgkfjWp/wmXi//AKGrW/8AwOl/+KrEorlhXqU1aEml5M3lShJ3kkzb/wCEy8X/APQ1a3/4HS//ABVH/CZeL/8Aoatb/wDA6X/4qsSir+t1/wCd/eyfYUv5V9xt/wDCZeL/APoatb/8Dpf/AIqj/hMvF/8A0NWt/wDgdL/8VWJRR9br/wA7+9h7Cl/KvuNv/hMvF/8A0NWt/wDgdL/8VR/wmXi//oatb/8AA6X/AOKrEoo+t1/5397D2FL+Vfcbf/CZeL/+hq1v/wADpf8A4qj/AITLxf8A9DVrf/gdL/8AFViUUfW6/wDO/vYewpfyr7jb/wCEy8X/APQ1a3/4HS//ABVH/CZeL/8Aoatb/wDA6X/4qsSij63X/nf3sPYUv5V9xt/8Jl4v/wChq1v/AMDpf/iqP+Ey8X/9DVrf/gdL/wDFViUUfW6/87+9h7Cl/KvuNv8A4TLxf/0NWt/+B0v/AMVR/wAJl4v/AOhq1v8A8Dpf/iqxKKPrdf8Anf3sPYUv5V9xt/8ACZeL/wDoatb/APA6X/4qj/hMvF//AENWt/8AgdL/APFViUUfW6/87+9h7Cl/KvuNv/hMvF//AENWt/8AgdL/APFUf8Jl4v8A+hq1v/wOl/8AiqxKKPrdf+d/ew9hS/lX3G3/AMJl4v8A+hq1v/wOl/8AiqP+Ey8X/wDQ1a3/AOB0v/xVYlFH1uv/ADv72HsKX8q+42/+Ey8X/wDQ1a3/AOB0v/xVH/CZeL/+hq1v/wADpf8A4qsSij63X/nf3sPYUv5V9xt/8Jl4v/6GrW//AAOl/wDiqP8AhMvF/wD0NWt/+B0v/wAVWJRR9br/AM7+9h7Cl/KvuNv/AITLxf8A9DVrf/gdL/8AFUf8Jl4v/wChq1v/AMDpf/iqxKKPrdf+d/ew9hS/lX3G3/wmXi//AKGrW/8AwOl/+Ko/4TLxf/0NWt/+B0v/AMVWJRR9br/zv72HsKX8q+42/wDhMvF//Q1a3/4HS/8AxVH/AAmXi/8A6GrW/wDwOl/+KrEoo+t1/wCd/ew9hS/lX3G3/wAJl4v/AOhq1v8A8Dpf/iqP+Ey8X/8AQ1a3/wCB0v8A8VWJRR9br/zv72HsKX8q+42/+Ey8X/8AQ1a3/wCB0v8A8VR/wmXi/wD6GrW//A6X/wCKrEoo+t1/5397D2FL+Vfcbf8AwmXi/wD6GrW//A6X/wCKo/4TLxf/ANDVrf8A4HS//FViUUfW6/8AO/vYewpfyr7jb/4TLxf/ANDVrf8A4HS//FUf8Jl4v/6GrW//AAOl/wDiqxKKPrdf+d/ew9hS/lX3G3/wmXi//oatb/8AA6X/AOKo/wCEy8X/APQ1a3/4HS//ABVYlFH1uv8Azv72HsKX8q+42/8AhMvF/wD0NWt/+B0v/wAVR/wmXi//AKGrW/8AwOl/+KrEoo+t1/5397D2FL+Vfcbf/CZeL/8Aoatb/wDA6X/4qj/hMvF//Q1a3/4HS/8AxVYlFH1uv/O/vYewpfyr7jb/AOEy8X/9DVrf/gdL/wDFUf8ACZeL/wDoatb/APA6X/4qsSij63X/AJ397D2FL+Vfcbf/AAmXi/8A6GrW/wDwOl/+Ko/4TLxf/wBDVrf/AIHS/wDxVYlFH1uv/O/vYewpfyr7i1f6nqWq3K3GqahdXsyrsElzK0jBck4BYk4yTx7mrXhvXLjw34rsdctV3Pay7imQN6EYZckHGVLDOOM5rLoqI1pxqKqn7yd7+ZTpxcXBrR6WNv4i6PDoXxR1nTbbyxCs/mxrHGI1jWRRIECjgBQ+38Og6UVpfGH/AJLTrX/bD/0RHRWuZwjTxlaEVZKUkvvZngpOWHpylu4r8g+D3/JadF/7b/8AoiSuSrrfg9/yWnRf+2//AKIkrkq1n/uNP/HP8qZEf95n/hj+cgooorgOoKKKKACiiigAorU0Pw3rniS9NroemT3jr98oAETgkbnOFXO04yRnGBXdQfBi/tLeO78VeJdI0O2kUAM8m9hIRnyzuKrnG7kMenGRzXfhssxWKjz0qbce+y+92X4nLWxtCi+WpKz7dfuWp5jRXqp8K/Bu0xbX3jPVnuYwFleGI7GYdSuIW+U9R8x4xyetL/avwRxn/hDda/7+t/8AH66f7Ha+OvTX/b1//SUzH6/f4aU38rfnY8por1X+1vgh/wBCdrX/AH9b/wCP0n9ifBG6P2n/AISTW7Lzfn+y7GPk552Z8ps46febp1PWn/Y9/hr03/29b80g+v2+KlNfK/5NnldFepH4MnUf+RW8aaLq/l/6/LbPKz937hkznDdcdO/biNe8IeJfDGw65pE9qj42y5DxknOF3qSu75Sduc4GcVzYnKsXho89Sm+XutV96ujWjjqFZ8sJa9tn9z1MSipXt5o7eKeSMrHLnYx/iwcH9airzzsaa3CiiigQUUUUAFT2dncahqVvYWcfmXFxKsMSZA3OxwBk8DkjrUFb/gz/AJGlv+vC+/8ASSWtaFNVKsYPZtIirJwg5Loi/Db6Bp0fkjTItXlHElzdSypGx/6ZIjIyryRlyScA4TJWn/aNE/6FDSP+/wBd/wDx+qVevfDfwX4e17wNY3uo6NaXk9xrb2U8015JDIkAgD/ukWRQ7g8gBWJyeO49TDRnXlyQUV/26v8AJs8TN8yo5XQ+sV+Zq9tH5N9Wl0/yPLvtGif9ChpH/f67/wDj9H2jRP8AoUNI/wC/13/8fr1fwF4I8I6rpNnc6ppUt0G128tH8yWSJ3gjs2lVCFYbTuAPY9unFUPEXw606Lw7oH/CPx+fNrerNHZ3Zdj5ls6oYwy5wCu5g3AOVNb/AFWt7P2iUbf4Vfp5eZ5i4owP1r6pLnT7vb7V9ebpyN7Xt87eb/aNE/6FDSP+/wBd/wDx+j7Ron/QoaR/3+u//j9d/wDE3wl4d0vSbTWPCcUC2cVzJp115N8t2HdeY5SVdthdQ3ynGNvQVz8PgjzfhDceOv7atV8m7Fr9gI+dskDOc9ec7cdATmsqlOrCbhyxdlf4Y7fcd2FznB4jD08TzSipy5Um3fmbsk7N2v62sYH2jRP+hQ0j/v8AXf8A8fo+0aJ/0KGkf9/rv/4/XUeFtE0mT4feIPFN7p39rXGnSQRR2JkdI1Dk5lk2EMQMYGCOetbvhfSPA2v6bqV5q+g3Gky6IP7RuLa3llYXlsV/1XztlDvK4Yfwt3I3U6dKc+X4VfX4V5/3bdGRis6oYf2jcJyVNqLad9Wk0rc3M/iir2td72uzzr7Ron/QoaR/3+u//j9H2jRP+hQ0j/v9d/8Ax+vYdD8GeDNb8IaHM2i2cN/rFpqM8cMdxdeezxO/lrESxiCqoAPmcnA6nNcze6L4a0/4MeH9WNpoyanqNvdmSS+e9M0jJKUUwiI+UCBj7+BnGc81pLDVIx5nyWtfZeX93fVHLS4lw1Wp7GNOpzc/Jbz9/X4vh/dy18vW3CfaNE/6FDSP+/13/wDH6PtGif8AQoaR/wB/rv8A+P16zrngbw1bfDeTUYtFhhkj8P2WoLdW91JJcNcyEB98RdgsZHO7YoHOD2FK48IeHY/g7/wmS+H5RqL2CL/Zn2h9sWZCn2/G/fsOOFPy5PQrRLC1YtpqOiv8K2/8BJpcUYKpGMlGes1Bar4mk19vbX5dbaX8z+0aJ/0KGkf9/rv/AOP0x9K0vXZEtNN05dN1KRglukMrtBM2eEIkLMrsTgPu28KCoBLirRXD7W+koq3ol+KR9R7O2zd/Vv8AU5ut/RNEtp7H+1tWM32HzGgjit3CSTyKFLAMVYIqh1JJBzuAA+8yR+Mv+Sj+IP8AsJXH/o1q3pP+RR8Nf9eEn/pXcV52Ki6MpQT2djHFV5ezhy6cz/Rv9LflqHmaB/0J2kf9/wC7/wDj9HmaB/0J2kf9/wC7/wDj9VK9h+FXwo0Xxh4Xn1zW7u62mZoIobZwu3AGWYkHnnge3fNcXPLueNjsTRwNL21acrf4pf5nlPmaB/0J2kf9/wC7/wDj9HmaB/0J2kf9/wC7/wDj9dXfeCLTTfjhH4JudRJtGu4ovtHAbY4VgPQNhgPrV7VPD+iXHhbxJfRaG2izaNqEVrD+9kb7UruylGDk/OoAbK4GD0o55dyHjKPuWlJqSTT5pbSdl9q+/wB3U4bzNA/6E7SP+/8Ad/8Ax+jzNA/6E7SP+/8Ad/8Ax+vYfE3w88JWp8UX+kWRFtp1r5XkNO5NrchkO7lssrI+RnIyG9BWMPCHh3/hpS58K/2d/wAShBIVtvOk4xalx827d97nr+lHPLuc1LNcPVg5xc9IuXxPZJN/a395f5nm/maB/wBCdpH/AH/u/wD4/R5mgf8AQnaR/wB/7v8A+P16v4V8BeF9d8M+EHa0P9p3TyXF2hmcC7t0nMbgfN8rKCh+XGQGrJtdC8M2nw7vNYu7PSBcprk1ikmqSXhTyljDBFFuc7s55b356Uc8u5SzOi5OC5207fFLu1/N5P8Aq5595mgf9CdpH/f+7/8Aj9HmaB/0J2kf9/7v/wCP1Uoo55dz1vZf3pf+BS/zLZbw9Ipjfwlp8atwXguLlZFHqpaVlDehKsM9Qelc9rujJpwgvrJ3k0+6Z1hMhHmRuu0vG+MZK70+YDDBgeDuVdapdR/5Jpf/APYTtP8A0Vc1dObvZl05Soyi0202k023u7dW7W3/AAOMooorpPaOt+MP/Jada/7Yf+iI6KPjD/yWnWv+2H/oiOiu3N/9+r/45fmzmwH+7Uv8K/IPg9/yWnRf+2//AKIkrkq634Pf8lp0X/tv/wCiJK5Kqn/uNP8Axz/KmKP+8z/wx/OQUUUVwHUFFFdf4F8C3Pi29ku7ub7Dolp815fOQoAAyUUnjdjkk8KOT2B3w2GqYmoqVJXkzKtWhRg5zdkjB0TQtX8RaqNN0Wye7uSpfYpChVHUliQAOgyT1IHUivUIvCXw98AbJ/GOpf23qybW/s22GUQ/IcFcjOMk/vCoZSflJrP1f4gWei6DF4Y+HSzWFjHuE9/IoE1yxypYHqMjB3cN90AIFwfOq9ZVMLgNKaVWp3fwr0X2vV6dkcXJXxWs24Q7L4n6vp6LXzPQNa+LniK9iFloccGhaekfkpBaqGcLtC43kfLjB27AuM98A1yFumo+IvEUUc93LcXd06o09zIXPTGWYnOAB+AFZ1ejaR4T1Y3emaB4Y019T8R6ifJEVud7+YxP7vsECBSWJ4GCScCvPxmYYjE+9Wm3+XyWy+R34TCUKLSjGy623+85rxq1k3ji8bTwDagqkZHGVVQoP4hRXrnw10aO6sYv+Eu/Z3TU/Dso2tq1tJd2dyoI+/G8k2yX6ADPY17B4O+Bfhj4ZrBrPiEN4m8XSpvhtbTHkW23qYywztX+KdsD+6PXoZb7XPFWpS6OdP8Ast+6JI0Ud1I+I3zt80ydmCkjODgA4wRXBF6JHfXftqsqqVk3ex8reMPhBef8LFvrT4ewT6loLbZbSe5lRGVXGdhLEZI9cdMZ5rG1H4MfEvTLU3M/hS7khAyWt2WbH4KSf0r7A8N+FrrQHN3qeiT/AGMsUmvLKXfJbEHB82MgkqMD7vQc4Ir0SbQ9SitFuNOVNXtmUN5AKpMynkGJxhG9g2M/3qrnsZOmj8xsXmnagD+/tLqBwwPMbxsDkH1BBr0jwL438etqVvbvcm/0xW2zS6gpKxqWBJMwG7d1ABLdcBTxXXfFnxNoevfE25Y6VEllpTvADcW3kXEzr94ybhuTBBG0jIHOATx5nL4llvwyT3xsbJW4CAvI3+4ucDgdT+ddGHzDEYZ82Gm4vy/y6/MIYDDYiSjileP9deh1upaF4J8a67LpaavFoV7BtgsIY41SJkLDPyYCsxZmwqsDkk4IFeYeJvCeueEtSWz1q08rzNxhmRg0cwBxlWH4HBwQCMgZFQX119svpJwgjVjhUBztUcAflXaeF/iI1ppT+G/F1u+seH5IPJEO0GSEDldpJBIzgDJyuFKkbcHuw7wuIpqlXXJP+dbN/wB5fqvmmceY1Kv1idehrBv4eyWi5X6dH955vRXdeNfAEWi6Xb+JfDN5Jqnh25VcXBwXhY8YfAHBPGcDB+UgHG7ha4sVhKmFqezqrX8GujT6pioV4Vo88H/wPJhRRRXMbBWnoGpRaV4hgu7hHa3IeGcRgF/KkRo5NmSBu2u2M8ZxnisyirpzdOSnHdakyipJxfU667sJ7SOKZgJLWfJguowTFOBjJRiBnGRkHBU8MAQRSw6rqdvaRWsGpXcUEM4uo4kmZVSUDAkUA4D4A+Yc1zun6zrGkeZ/ZWq31j5uPM+yztFvxnGdpGcZP5mr3/CZeL/+hq1v/wADpf8A4quxVqO92vlf8br8jnnSlLSST9f+GZup4l8RRuzx6/qiM0z3BZbqQEyuu1n6/eKkgnqQcUy31/XrSK0itdb1GCOzZntkiuXUQM2dxQA/KTk5I65NYv8AwmXi/wD6GrW//A6X/wCKo/4TLxf/ANDVrf8A4HS//FVXt6X88vu/+2MfqcbW9nH+r+Xm/vZopfXseny2Ed5cLazMHlgWQhJGHQsucEjJwTVeq3/CZeL/APoatb/8Dpf/AIqj/hMvF/8A0NWt/wDgdL/8VUupRf2n9y/+SNlTnG9orXz/AOAaen6nqWk3f2rS9QurGfGPNtpWibHplSDT21nV2nu5m1W9Ml4uy6czsTOvo5z8w4HBz0rJ/wCEy8X/APQ1a3/4HS//ABVH/CZeL/8Aoatb/wDA6X/4qmq1JK3NL7l/8kRLD80udwjfv/SN6HxP4kttHGk2/iHVYbAKVFpHdyLFgkkjYDjBJOeO5og8T+JbbRzpFt4h1WHTyjRm0ju5Fi2tncuwHGDk5GOcmsH/AITLxf8A9DVrf/gdL/8AFUf8Jl4v/wChq1v/AMDpf/iqf1in/PL7v/tjN4GDvelHV3+ff4d/M2RruuCTzBrOoB/s32Ld9ofPkdPK6/c/2entQde1w3T3J1nUDM8H2V5TcPuaHGPLJzkpjjb0rG/4TLxf/wBDVrf/AIHS/wDxVH/CZeL/APoatb/8Dpf/AIql7el/PL7l/wDJFfVF/wA+4/18izV2zs08oalqQmh0mKQLPcKMbsYJjjJGGlIPC/icKCRk/wDCZeL/APoatb/8Dpf/AIqs6/1PUtVuVuNU1C6vZlXYJLmVpGC5JwCxJxknj3NT7WjHVXb80kvzf9dTfkqS0dl/Xog1O/m1XWrzVLhUWa7ne4dYwQoZ2LEDJJxk+tdVosra7oFlpdqjS6nYB4kto1JaeAuZAUHJZ1Z5NwH8OwgEK5HF0Vw1L1LuW7FXwyqwUU7Nbfdb8mddXQ+G/HPinwjFPFoGqvbRTnc8ZRZFLYxuAYEA+49K4z/hNfGX/Q267/4Hy/8AxVH/AAmvjL/obdd/8D5f/iq5/YvuedVwNWtHkqQi12bb/wDbTavb681HUptQvrmSe6mcySTOcszHvU19rWs6nFFHqWrX14kX+rW4neQJ9AScVz//AAmvjL/obdd/8D5f/iqP+E18Zf8AQ267/wCB8v8A8VR7F9yvqdbT3I6bavT/AMlOifXdbka7aTWNQZr3Aui1w5Nxjp5nPzY7ZzVqXxh4umKGbxTrUhjYshe+lO0lSpIy3BwzD6EjvXJ/8Jr4y/6G3Xf/AAPl/wDiqP8AhNfGX/Q267/4Hy//ABVHsX3IeAqPenH7/wD7U6CDWtYtXtGttWvoWswwtjHO6mANndswflzk5x1zU9l4m8SabC8WneIdVs45HMrpb3ckYZz1YgEZJwOfauY/4TXxl/0Nuu/+B8v/AMVR/wAJr4y/6G3Xf/A+X/4qj2L7jlgast4R+/8A+1NIkk5JyaKzf+E18Zf9Dbrv/gfL/wDFUf8ACa+Mv+ht13/wPl/+Ko9i+5p9XxHaP3v/AORNWKKWedIII3llkYIkaKWZiTgAAdSai8R3SWGhDw9kG8e5W5vE6+QUVljjz2f95KXHOPkHDB1GZP4u8V3NtJbXPifWZoZVKSRyXsrK6kYIILYII7VjVcKXK7s0pYSbkpVbWWtlrr5uy27W3tr0CiiitT0jrfjD/wAlp1r/ALYf+iI6KPjD/wAlp1r/ALYf+iI6K7c3/wB+r/45fmzmwH+7Uv8ACvyD4Pf8lp0X/tv/AOiJK5Kut+D3/JadF/7b/wDoiSuSqp/7jT/xz/KmKP8AvM/8MfzkFFFaOhaJfeIvEVroumqhubliq+Y21VABJYn0ABPGTxwCeK44QlUkoQV29EdEpKKcpOyRveBfAtz4tvZLu7m+w6JafNeXzkKAAMlFJ43Y5JPCjk9gdbxt42ttRsovC3haH7D4btMKkaAqbkg53NnnbnkA8k/M3OAtz4gavpei6avw68MQeVY2cge8uRJua5mxyGKnDYON2f4lAAUIM+dV7WKqxwMHg6D956Tl3f8AKv7q6935Hn0KbxMliKu32V2835v8Aooqa1tLq+vI7Syt5bi4lYLHDEhd3J6AAck14x6RHGcTKeOCDzX6V/s4/Bc+EvhvceOtWiE/iPxK7yJIVx9ksXYuiKDyplG1274KqfunPzD8Gv2e508Uaf4k+LVoNL0uN/Pt9BuiFu9RK/N88X3ooB1dmALfdUfNkfcvjDxvPpvw2vJLWYC5uWj06128bZp5FhDDHcb2b/gNYVXfY3owlJqK6klroOmzXbbY1nlvE86aUjO+NXCqP9zJ4HTgnua8t+CGPEWufEHW7pd15Lr5JLckR+VtRfoACK9D8LeNNJb4ueKtPtjG9vpltpumQRk8IB5xP5tgfgK848DeJrbwD+1Lrfgi9tIIbLV4zJYylcLcHLSRFvVirSJx3QCsZNpo9PCQjOjXiviSTXomr/hr8j11bCKLVorXy9r3Cs6kfxFNuR9cEH8KqaatlpPjceFHK28NyN1ujrjypSC5jA/uOoZ0x3SRewFcr8T/AIjzaTquh6hpEIln07Wna4giUlngNmTKFA6/KwIH+zXG/GfxvHrHw5h8beGr4DxD4fuI7nYsmSyBlk2+6/ckQ+hb1YVRzUaDqNX0T0v5/wBfmYn7ZHwasdW8KSfEfwrDt1PTlVdbSNcfa7dfl+0e7x8bj3Tr9wV4tafBq9v/ANnON5dMVZ7oG8tbrADi4C4RT32OoEfpuIPavtO48U2+v+AotZ022iure/slultX5WaORAxiP1Viv1rzXQdR0aPwadH0+c3VgS32BieZE6+S392ZMYKn7xG4ZycaU3Z3Odx6M/ONgVYqQQR1B7UlepfGn4fXHhrxjc+IdLhabw9qczTQ3CAlYJGOWhf+6Qc4Bxke4OPLa3Odqx1ngnxtceFbuW0u4ft2iXeVu7FwGBBGCyg8bscEHhhwexEvjvwJb6VaR+KfC0327w1d4ZHQljaknG1s87c8AnkH5W5wW46u2+H/AImsdPnuPDPiG2S60LVmWOdZX2rA+cCTkgAdNx4I2qQflAPr4OvDEQWCxL0+zL+V/wDyLe66bnnYijKlL6xR3+0v5l/mun3HntFdF428K3Hg/wAYXGky/NAf31rIXDF4SxClsAfNwQeByDjjBPO15NejOhUlSqKzTsztp1I1IKcHdMKKKKyLCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAOt+MP/Jada/7Yf8AoiOij4w/8lp1r/th/wCiI6K7c3/36v8A45fmzmwH+7Uv8K/IPg9/yWnRf+2//oiSuSrrfg9/yWnRf+2//oiSuSqp/wC40/8AHP8AKmKP+8z/AMMfzkFew+Eov+EA+Dl94xnj2atq2Lew3p8yKc7TyhxnDSYOVYJH3NeZeG9DuPEniux0O1ba91LtL4B2IBlmwSM4UMcZ5xiu4+LmtR3vjRNDslgTT9IjFvDHBt2BiAXxgfLjCpt5xs7ZIrtyv/ZaNTHPde7D/E1q/wDt1fi0c+MXt6kMN0esvRbL5v8AJnn9FFFeOekFKCQwI69qSigD6X+Da2vhHw5ostzEbjX/ABSZdQYycm30y0DsuSeR5k0ROO+xD259r+JXiT+yfCfhpvNzHba9bedn1iSRzn/gS5r5s8A60+s/EHU9aiLtZ6T4VjsIMjiILDFFt/E+afqSa9L+J2tRX/hrWVjja5XTtbg1MQxsAZoWcI6g/wDAjz6MKwqOyuengKfPK/b/AIb9TsZRd+EvB2meMre+jmutVjkfUoUb97BcCX7RCHT7wyoZRkc9B1o8eXuk/EHwtbaoZ3tNS06Rbiyv7dsSwozKcg9wODj1XPeuV8X/ABK+Kt/4D0nxD418L+BZPD2o28s2nacY51v1gjkCGNLlVIEkQYFuABtJIJ4ruvC3wwm8R/CTSfE3hu8iktb22YPpt03kyBclSFf7ocEMD/C2Nw27to4oVlTjaoeh9XqSarw06L5afloZfwm17Vtb+LtxqfiKH+3JbV5XVNOjGyeUxJApYsQkQIViSzY9OoFQfFP4ZaroNw+r+FNV0mVrwGB/DtrdCaSFW3N5CqcNMv3iCFG35sDb09GvPhPrHi74WRaNoBvfCl/BbSnUIreby7jUZYoQkKRyKTtifaCxBzyR0yT8vQ/s9ajrXii3u9KsbPSYdSvY1ske/ae4t1bPmlpBhmaLkksoyRjA6Vl7S8vaJ2/4B2YXC1J39na0d07Le/Trs/I9v+Hev3OmfAfwTBc+YlzFcQ2LRyAqwAuHiIIPIwvasa107RD8QvE9jNpljdQTul/AXypAmGedpG5N4YHOcHB9axF1PTz8SvDfgzw/uXTNLuZL2Qlix8uOR5AWJ5JxsyT1LVwGteMLzTPihZahbTA+RPcadKjfdeJmWRQfYCXj6V6FKV1dnDi8JaUYx+KSb/y/rzOz8ajVrnQrnWfA10tvLGjQ3uhzwrNBPtySjRMCN3BwejYHcivlXUL06hqMl21ta25c58u1iEUY+ijgV9CXfiaez8Z6VrFu5ig1K6+yTJ2L8Oh/BuPofavEPHNtaWnxL1+2sNv2aPUJ1jC9FXzDwPp0/Cuu2lzxKqszAoooqTE9WtIv+FifAqTTlj8zW/D2DBtTLSRAHaown8SKVCjktGhJ5rx2u1+HfiBvDnxBsbpnRLadha3JkYIojcgbixBwFIVu33cZAJqt8SPDreGviLf2ixoltcMbu2EahFEbknaFBOApDL2+7nABFexjv9rwlPFfaj7kv/bX92j80ebh17DESofZl7y/Vffr8zk63fB2qeHNF8bWOp+LvCv/AAlGjQl/tOj/AG6Sy+0gowUedGCyYYq3A5246GsKivDPSPt628M/s13H7Gt58ev+GfNv2a9Fp/Yv/CWX53ZnSHd5+ePv5xs7Yz3ryx/2d9Y+JlvD8RPDGj+E/hP4Q1do4dH07xP4jkY3L7Qp8qSRC772DMAwHXjIwa6fT/F/hNP+CTuq+EH8UaMviF9WWRNHN7ELtl+2xNuEO7eRtBOcdATXqOj/ABa8C/EX9m3wHpel6h8FIdd8O2Een32mfFO0LRxeXEkZe1fIA3eWDgBsgqCVK4OV2i9D5d0j9mn4man+0HJ8G7yHTdH8RJbPeLJqEzi2lhUZDpJGjlge2B1BBwQRXa/Dr4B3Xgv9o3wLZePtT8D6qbrXxYXfhdb6O9u1TZIwkntiuFiYICN/PzKCoJwPYfC/xk0vV/2+/D2veNviF8PZ4NO8NT2U2saP5ljp6SM7sIfNuZT5hGQQwIB34AyDXz58OvEWj2//AAUHtPFGp67Yw6WfFdzdSapcXKLB5bSyESGUnbtOQd2cc07ti0PSPiv+yf4v8XfHzx1P8PoPB2mW1tILmy8Mx3kdtdyW4jQeZFbIuEQvkAvsBPTg5Pg/w7+Er/EK21GWT4jfD/wg9jKsTQeLNX+wSTEg8xrsbcBjB6YJFfU/w8+Ifgq1/wCCpPjzxbqHjjQINButPkig1efUoUtZvltgqpMW2N9wgAH+E+lct8DZfgfL4J+IN7q0nw2l+IX9szvpjeP23aa9qWUqVHIb/lt9zLE7e2KFJpBZHiHxB+AHjv4ca34ds9Ym0a+sPEUix6ZrOlXf2myuCxUcOFDD76n7vIORnBrovHv7Kvjj4a2+qT+L/F/gOwSyszeQCbVzHJqRCkmK1jeNXlkGAPuhcsAGJzj3T48/EL4feIPgT8IbbQ/E/gaS6sPEdvJd2Ph1ktbezRd4d1tmYvDDkAguBwQSBnA8l/bb8VaB4u/aaj1Lwz4j03XdOj0a3hS5027S6iVg8hZAyEjILZIz3oTbBpHF+Nv2ePGvgPxn4J8M6vqmgz3fjHyf7Pe0nlaOLzZERfOLRKV5kGdobgHrXMfFT4Za98IfiZd+BvEt3p11qNrFFK8unSO8JEiBxguiHODzxX2B42174U/E7xB8EPiZ/wALb8L6Ta+HDZpqWkXdxi+WRZYWCCLHygOrK0jlUVfmyRXgn7YviDQfE/7WWtax4a1vTtZ06S0tFS8065S4hYrAoIDoSCQRg804ybBpEH7KXwl8N/GH48f8I/4vi1GTR7WwkvJEswyiR1ZQsckij92p3Mc5BJUAHJp/xc8H+Hb34gz+Afhz8DvFvhrxjpt1JHc6Tb3k2sLc26gkTKpUyAn5WBGUKtnPSu4/Zm8c+DY/2eviD8Kr3xza+APFOuSrcWHiG6lNvGyqqARNMMbACrg5I4mbGSCK+jdK+JXghPBJvNa+KXwo1D416f4eudPtPEUOprHaShiNm6dwqFywQleud5UBWapbaYJaH5jyRyRStFKjI6EqyMMFSOoI7Gvsfw18CvAnhj9lLwr8Sb34PeIvi7q+vDz7m30zUp7VNOjOcYW3BdsYAOQ3zbslRgV8dXEckN5LFM6PIjlWZJBIpIPJDKSGHuCQa+tfgjqXjrwp4D0iXwB+1R8PdFsZkE934c8VXIgFnIxy8apIjd8nKFNxPvVT2Ejw7xfoug+NPjHp/hv4Q+ANd0O4vEjtT4f1CczzJd7m3AO5zs27Tl8YwxOBzXb6x+x98UtL0jVJrPVvB+uatpMH2nUPD2j6sJ9RtExnLw7BzjoAST2zXtfxJ/aE+FFj+3t4A8d6beWmr2WjWEtjres6dCWjZpUkjDJ1Mgj8zdkbuGKgkiu11D4p6V4c+IuseOvCHjv9mXTtLvmkk/tSPT55Ndmidg5WeOGVXkcsFJ5G4gHA6CeZjsj48+H37Onjr4h/Da98f2+o+HPD3hu1kMK6l4i1AWUU8gIBVGKkdSFy21c8ZyDj2746fDjRPB/wO+AcMXgnw/Y+ILmaG31Vo7aGNr2UJDuWeaNT5ilicsdwOSRnPMWjeJfA3xj/AGA7H4WXPxA8MeB/Eug6tJqDw63cG1trlGlnkGw4JYYuDwoZt0fIwQau/HTxd4Auvg9+z/ovhvx7o2ujQ57aK7kiu4/NiSOOFfMmi3boQdhOHAI6HkGndtgdTpXw/wDD0/8AwUusvDHif4W+BNM09vDTTtoWmRJe2BbDYlKvbQjf/wBs+MDk9vDfGv7LPj94vHPjXQ28LvZaPe3Vzc6BY36NfWNtvd0LwIu2P92NwQsGwMbc8V9DXXxI+Hbf8FRLLxWvj3wwdBXwubdtWGqQfZRLh/kM2/Zu5HGc1558BPHXhHTPF/7RVzrvjDRLJdZiuTYyXuoRRC/ZnuyPKLMPMJ3r93P3h60k2tR6HxnRRRWpAUUUUAFFFFABRRRQAUUUUAdb8Yf+S061/wBsP/REdFHxh/5LTrX/AGw/9ER0V25v/v1f/HL82c2A/wB2pf4V+QfB7/ktOi/9t/8A0RJXJV1vwe/5LTov/bf/ANESVyVVP/caf+Of5UxR/wB5n/hj+cj074MQQ2mr654qu4o5bbSbBnZQoaUM2WymeM7Y5BnI+9joTXB3l3cX+o3F9dyeZcXEjSyvgDczHJOBwOSeleheF/8ARv2ZvFF3b/ubiS+WF5o/ldkzCNhI5K4dxjp8zeprzeuzHfusJh6C6pyfrJtfgkY4Rc9etU81H7l/mwoooryD0AooooA91+EsVtZ/B27vC4W41fxJa6Nu/ujyXkUf8CJYfhV/xHp+p22gjXCwlsprYxvEf44zmMofcKq899o6EZrxLTvEOr2Og3OhWUzi3urmC72Lncs8W4RuuOjASOPx9hXv/hLxZbeNNNh8N669tb32oQTWnlr8qreo7yIoGePNjnlAH9+LaOoFZTWlmd+DxHspxa6fl1PcPhpqsvj/AOCnhmK8sr2R9NJLTTWSBJpUJid45GBDBwMSKf4gSQDyfZtJ8L3H9nRRK7wWyKQIw2NuSSegx1Jr4n+FH7QF58D/ABBqfhLxJpn9p6Gt3572m8RT27MAGlhY8EHA3IeMgEEc5+qNM/ai+BPiC2js9S8Rx6RJKqSfY9ctWiGDhlO4BoyOhHzV4NejO/kfT1Mc6UfZ00t3r8zvJvDVwluTY3JyCRlXzgjg1wXijwz4ys/D14nhpbSG6uY2jlv52EaWqH78mACzt3A4GeSex07r9oD4P6HawaX4f1+21y4bIttL8OobuQ5JOBt+VBkk5YgCvnj9pD4zfEK/0zStCtRDoOj6t5ont7aXfcbF25Eko4wQTkIMcY3GsqdJykkjShjMRKGqVn1OC8KTLoPhXVdQM/n6nq9x/Z9nMRhjEDjj0HIJ564rzTVr8Xvj24IbMT3rtGQfvhcLn8kFSwarfz3kcscojjtrdltQFJERYEK+OBgZZuuWO3tXNQWqJLdyS3U8ktrA0sU4wu0qQAD1yCTjHvXu09lE4MRWhTxE6t7/AD++3y+V7m5418WrNr2nW+juDFpMhmEn8MlwWBZh6hdqqPXaT3rh5ZZJ53mmdnkdizMxyWJOSTWlo2qTWWvi4EcUiTEpNDIgZJEbqpBzx39RjIqXV9MtlhGoaUC1r92ZA27yXz0552njBP0PaurmblZnzU0nHnvrfb9TFooopmIV6V8S5G8RfDHwn4yIjMpVrO6ldAsssmOvyjG3dFKQMjG8YHJx5rXpNh/pX7LOufaf332XUV+z+Z83k5aHOzP3fvv0/vN6mvXyz36WIoPZwb+cfeX6r5nn473Z0qq3UkvlLT/I8qooqS3t57u7itbWCSeeZxHHFEpZnYnAVQOSSTgAV4h6BHRV0aRqxe9QaXelrDJuwIGzbYbafM4+TB45xzxVKgAooqzdafd2drZXFzFsivYTcW7bgd6CR4yeDx88bjBweM9CKAK1FdC3gTxpFdWdvc+FdXtGvbiO0t2u7V7dJJXOEQO4Cgk+prnqLAFFFFABRRUrW1wtml20Eot5HaNJip2MyhSyg9CQHUkdtw9RQBFRRV19H1aOeGF9LvVlnt/tcSNAwaSHaW8xRjlNqsdw4wCe1AFKipzY3o0xdRNnOLNpDCtyYz5ZkABKBum4Ag464NTPo+rRzwwvpd6ss9v9riRoGDSQ7S3mKMcptVjuHGAT2oApUVow+H9euNFfWLfRNRl05M77yO2doVx1y4GB+dNtND1rUJ7eCw0i/upblDJAkFu7tMoYqWQAfMAVYEjuCO1AXKFFS3FtcWd3Ja3cEsE8bFXilUqyH0IPINRUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAdb8Yf8AktOtf9sP/REdFHxh/wCS061/2w/9ER0V25v/AL9X/wAcvzZzYD/dqX+FfkHwe/5LTov/AG3/APRElclXW/B7/ktOi/8Abf8A9ESVyVVP/caf+Of5UxR/3mf+GP5yPVdW/wCTWfDX/YRf/wBCuK82r0nVv+TWfDX/AGEX/wDQrivNq7M4+Kj/ANe4f+koxy74an+OX5hRRRXkHoBRRWholhJqWuW9pFGJXdgFjP8AGew+mcfhmk2krsqEJTkoRV2za0PTLiKMG2Q/bpVy0v8Az7Rn09HYd/4QfU8UprCR5rkwhhHa4x5RI5Ddj68E/iK9X08+GrKVNCi1WCfUd2ZFjy7yyd+g5Of4Rz2rl9GuND0i3kg8QwzO8k7P5UbJtcEnG5w42gYHA5Oeq9/PVaVSTsj7OvlWGwNCEak02781tbPZLTzf4HI3p8TfEXVI7rXlt5pNPCx3Gsyny2uI+qI5UfvJCAcEDceS3QmtSQ2urS3CSxR2V1CCsCNhSiYCrGf7wwFAYemeckVa1vV4IbZxawRWqRJtt7ePJVVbqR6kn5jjv9KLyx+2afa20jFWdiXkU4IEaDn/AL7kH5VctDxaFOzdtbLXz7L77a79T3K1s/C3wa+DWh6/pM1tdap4jsI7gNJMZJG25EjyLxsVHLIFGASMZ4YjxXWtZutf8Xv57zavqLnGFzMP+AquN36KMYwAKhj0W6vru0hub25lt4XSNUeQsEUyZwP7oJLHHqT3Oa6jwbraeF/Der6ppb+Rqt+jzNMsJJEZZgB5nRSGydv8XygZNZUaSjJtu7OrEYqp9XSguWN7Lz/rT1d/K3KST6tdM1pFpQGG2M90y43dPuj0PFZOnJJDq13aapaRwK8ckVxGB8qjaTvH+6QrD/69dPb3EbRyqBuIlMKDPLbQMkn88ms/xHY3dwslxMIQZUBUhgrMUxuyM7sFeenVRW8Jcs12MXhlUw0pxTc016Wfft5HGWYP2kOv3ui/7x4H5dfwrcsFniEj20YlZF2TRsOJk5Uhvyznsa1/Dnh0GU3UoDbcqoxhc98Vr+H9KZfF+qWeMiMBsegbBH8zUVcQk210PRwGQStTVZfG2vTRv9DzjUbVLa6zAWaCQb42brj0PuDkH6VTr0Dxv4XbTYzcRofJmYugH8EgHzD6Moz9Vrz+uqjVVSPMj53MsBUwGIlQqLVfkFel/Db/AJJx8QP+wb/7SnrzSvS/ht/yTj4gf9g3/wBpT17mRf75H0n/AOkSPBzT/d36x/8ASkeUVveCLiC0+J3hy6up44IIdUtpJJZWCqiiVSWYngAAZJNYNFeIegep2njHRL7SNXtpTJbXF9YM2qSyMqi6ljMccYi5yzFfMc55LO3GBmptR/4Q/wDta2/tb/hGv7P/ALci+w/2Xsz/AGfh9/2jyvnx/qP9Z+8+/Xk1FVzE8p6if7E/tTSf7Y/4RT+2tl9/x5+R9h/1S/ZPO8r91nzPM69tm/jNYPxBuI5/+EbiE+kyXEGkmO5XSmjMMcv2u4YqBH8oOGBIXj5sjgiuMoouOx7RrM+nr8ddN15bXwjbaf8A8JNBcHVrLWlmmlj8/O+SP7S4RcfMT5a4wOg4PN2Z0MeMNJl0uy0a60f7NIIYbu4tYJo32YZrg3B2NIrEMA2UYDCgcged0UcwuU9bhsrZYPFNzplx4Tv7tL/TUhu7+1s4bdA8Fw0kaD/UAjaAdp2tsLDLbara1qHgZPF3hzTbS20j/hHXleS/mt4FMpX7fcbVaTBkVRGI8DhihXOflrzJbm4WzktFnlW3kdZHhDEIzKGCsR0JAdwD23H1NRUcwcp63ez6K3i7SCnhfw8u1LkGVdb0qSOQFAEZlWOOFShO5RKuXyQc4453x3Ho0WlWy2F/pd7eHUrlppbK3t4CIzbWhVSsHybVfzlBX5Swcjqa4aihyBItXHn/ANnWfmfZfK2v5fleX5mNxz5m35s56b+cdOK9btdf0TUbmK2vtWsopdJ8OKbKd5lCvv0oQy2uc/fEpVgvYiQdTXjVFJOw2rnql3deE38GS+CY/EErTW+mrLGDDELM3se6d3W4875iQ8sI+QA/IM8DOja6/omo3MVtfatZRS6T4cU2U7zKFffpQhltc5++JSrBexEg6mvGqKfMLlPVHTRda1u01u619YNETS4beNLXV4rS4090gVXTyHVnkBdX4Rfm353dRVTTtTD+GdD0uzudGnE2izWt5a3t8LXI/tCWUL5m5RG/CNhmAIPQ5rzaijmCxveMINPt/FckWm6i19EIYdztcC48t/LXdGJQAJFQ5UMBjAH1rBooqSgooooAKKKKACiiigAooooAKKKKACiiigDrfjD/AMlp1r/th/6Ijoo+MP8AyWnWv+2H/oiOiu3N/wDfq/8Ajl+bObAf7tS/wr8g+D3/ACWnRf8Atv8A+iJK5Kut+D3/ACWnRf8Atv8A+iJK5Kqn/uNP/HP8qYo/7zP/AAx/OR6pon+lfsta39p/ffZdSX7P5nzeTloc7M/d++/T+83qa83r0b4Mn+0W8T+Fv9X/AGnpp/0nr5W3Mf3e/wDrs9R933488mhmt7iS3uIniljYo8cilWRgcEEHoQe1dmYfvMNhq6/lcfnFv9GjHCe5WrUvO/3pfqmMoooryD0Aq3ZX9xp5lktXMczoYxIPvIDwcehIyM+5qpRSaTVmVCcoPmi7M7PQLawtPDn2oOV1C5V2E2cNHEDs2R9gzkMGY9F6dTUst5aWMMKwWUEl5LGpCgBtpPZieuBg9a9L8G/szfEvxd8IIPFkB0+0/ctc6bYTuy3N1ETuB4G1A3JXcckHPAINcDpfw0+JPi/x2nhrS/DV5/bEcUhMMy+QkCL1dnfCgAkDryWAGc1xSnFzfvbHtU6zjh4x9nZ9+/r5+ZDJ4K8ZeJPD82u6T4VvdTtrA5uLjSrF3RADlgWVcHHfHI74qPS7+K41WBpLkKqxNsXBydzfNjj0Ar9EfBvi2x8GfDrw/wCErrRF0LU7GzFvNpwdWWOaKJZWVXXhvNQSukg6srA8jFfH37TNp4ai+KMWu+Hr0x3l0ZBPBDGEjklRvmuUxjYXVoSykcsWI4zXNTxHtZcrXobxjLDt1UtNL/en+hwtzO1lGkoZUMGJQshAJYjnp16DjnFNtBbzeG445oVBit1KsJXILMoG7G4qD6nHtWVY6nHM6vqIKhFYFFwuQQcbQSB1xUTTSJp0OGWUQjlFwTzyxGPeuhQfcJ5hTs4xhda2vZ7pLtpa3Tt56HhufNvGZhmVp5IyPQDJP5n+ldXq0OjT6VpGpx3Wmo9uCNRs7y4AkndJTkonLsHjK8AAAg9K4LQ7jdrzhTmPLzL/AMCAFddp+pJ58wSCOeIlY5UZWO4542lPmBHqM9SCDVPTUywcnNKlfd2+W3dL72cfHrmpeH/Ekq2t3cT28MxCxXG4CRM8ZU8jIwexGa6248ZWejX+qa1p6x3FzfR26W8cnRAI9zM2PQkDHc/SuX8Vwx3NxJqcYjR1m+zSRRklVAXMeCQCSFG05AOVz3wOZrWdCFS0iaOb4zAOVFS1T0vrZ2advk/v1PSLDx9J4ks7jQvEcVuHnX/RbqNNgSUcqGHTBPGe2ea86mQxXDxlSpViMHqKYCQcinSSPLIZJGLMxySe5qqdGNNvl2ZyY3Mq2OjH6w+aUdL9Wuz9P1G16Vof+jfsy+KLu3/c3El6kLzR/K7JmEbCRyVw7jHT5m9TXmtelfECKbQPgp4R8NXETmWZ3vXaRTG0TAFjGUPcG4xnI+505493KvchXrvaMGvnL3V+f4Hz2PfNKlSW7kvuWr/I8pooorxD0Aoq9Dp6eUsl5cGEMMqiJvcg9CRkAA/XPQ4wc1J9i03/AJ/rr/wGX/45VcrFdGbRWl9i03/n+uv/AAGX/wCOUfYtN/5/rr/wGX/45RysLozaK0vsWm/8/wBdf+Ay/wDxyj7Fpv8Az/XX/gMv/wAco5WF0ZtFaX2LTf8An+uv/AZf/jlH2LTf+f66/wDAZf8A45RysLozaK0vsWm/8/11/wCAy/8Axyj7Fpv/AD/XX/gMv/xyjlYXRm0VpfYtN/5/rr/wGX/45R9i03/n+uv/AAGX/wCOUcrC6M2itL7Fpv8Az/XX/gMv/wAco+xab/z/AF1/4DL/APHKOVhdGbRWl9i03/n+uv8AwGX/AOOUfYtN/wCf66/8Bl/+OUcrC6M2itL7Fpv/AD/XX/gMv/xyj7Fpv/P9df8AgMv/AMco5WF0ZtFaX2LTf+f66/8AAZf/AI5R9i03/n+uv/AZf/jlHKwujNorS+xab/z/AF1/4DL/APHKPsWm/wDP9df+Ay//AByjlYXRm0VpfYtN/wCf66/8Bl/+OUfYtN/5/rr/AMBl/wDjlHKwujNorS+xab/z/XX/AIDL/wDHKPsWm/8AP9df+Ay//HKOVhdGbRWkbCxYYj1CUN2M0G1fxKsx/Q1QmhkgmaKVdrr1HX6EHuO+e9JpoExlFFFIZ1vxh/5LTrX/AGw/9ER0UfGH/ktOtf8AbD/0RHRXbm/+/V/8cvzZzYD/AHal/hX5B8Hv+S06L/23/wDRElclXW/B7/ktOi/9t/8A0RJXJVU/9xp/45/lTFH/AHmf+GP5yNvwhr3/AAjHjfTtcMfmJby/vFAyTGwKvtGR821jjJxnGa6r4saA+i/EW5ukg2Wmof6VEw3EFj/rASf4t+WwCcBl6ZxXnVew6UP+Fh/AqTTRH5mt+HceTtTLSRYO1RhO6KyhRyWjQk8125avrWGqYL7Xxx9UveXzX5HPi37CtDEdPhl6PZ/J/meVUUUV456QV7f+zR8E5Pi18SftWrwSDwtpDLNqD8qLhjylsp9XwSxHRA3civKPDXhjWvFvi3TfDeh2T3GoajMIbePGAxJ5JPZQAST0ABJ6V+pvwv8ABGi/C74Yad4Q0crItspkubrbg3Vw2PMlP1IAA7KqjtXHjcT7GFluzrwmGdaXkjr4rS10+HzWIjihXIVBtRFUdABxgAYA7Yrz/wCHdsL6bXPEtvHlLy/e2gOfuxQk5A9B5jy5919qzfjt8VbD4efCfUr55Ve+miMVrbg8yyNwigdeT+gY9q7r4eaC3hL4T+HvDtwxlurOwjS6kPWSdhvmY/WR3NeCk+Vs+ic3TSi93+X/AA/5C6x4Y8L6mlteeKLGzluRi1inJZGDOcKqkEHOSdp6gkkYyapal8JPhzrPgqfwtqPhayu9PmO5vOy0wYZw4mP7wMuSAQ3A46cVz3xe10Wj+GNPhuBFcTaoJkAbB/dxSMPr0z+FdX4a8Uw61piysypcpgTR+h9R7GpTcbNMqdCcqXO9n0PhX41fs6a/8Jbp9c0O2/t/wm74Fw0QNzZEnhJwOo7CRRgnghSRnx+PWbW80ue1jxC0gV4WCjiReVGR2IJH41+pnjVLTVfhp4gsLsKYZtNuFbd0H7tiD+BAP4V+YHifQLO08QZ81YFvFSRGIwIZHz8rDsCwIPocetenQxDqLlmThMFKKdam1o+Vp7NSTXy7X6NrY5KC7MOoyzqvlvPHtwONpzk8V0Wn3P2HRTc5+YtvQep6L/KubuYJxqqw3kYiulkZXHoT/wDr4rca3eZ44iQkEYwMdTXfujw05UajitGn6MsYi1lbmK9lHnXzq8cpbASb5tpb2Ytt9s57Vx8kbxTNFIjI6EqysMEEdQa7lNY0230C90z7P5wQbk29ATnOW+oB475rD1qH7d4lk8wsszRx+d5cZfdL5a7+B75z75q6M3ZprY683pRqSp4iEruorvpZ7P79zAoqxJZzw26yyBV3HATcN3/fPUVX71smnseLKEo/ErHQeCdAfxJ45sNM8jzbfzBLcg7gohU5fJXkZHyg8csBkZq18V9e/t74nXu2PZFYf6AmRhm8tm3E8n+MvjpxjjOa63w2P+FffBu+8YTR7NW1XFvYbk+ZFOdp5Q4zhpMHKsETua8cr2cWvqmChh/tVPfl6bRX5v7jy6D9viZVfsx91evV/kgq5pcaSaonmKHVFeXawyGKIWAI7gkc+1U6vaR/yEz/ANcJv/RTV4kdz0XsPZmd2d2LMxyWJySfWkoq1pmnXesa3Z6Tp8Rmu7ydLeCMdXd2CqPxJFaiKtFexeP/AIV2ml+JvDcFrpt74W0y9u30ae81mKWJXlhcA3n73GElR0cDIUEOAQBxnXXwwsbVJLV9RubGJ9T020Goa5YCzZEuFu9zoUuZImi/0cfMSckYDIFbeAeXUV6tB8P/AAhpc3iu38RXfieGKy0OG/tbqbR4kkVmvoITJHGt4UlXD7Ad+Dvc8GNQ1DX/AIWW/h/wK+sXXi7Sv7UjtYLt9LN1ab2WYIQiKtwZjIFkDENCowrEMeMgXPOKK73xt8PtM8Lxa5/ZfiaXVpdD1kaNfrJYfZgJG84o0Z8xtw/0eQNkLg4xuBzV3QfCGg658CmuIrVl8VS6jetZziVsTxW1vbSPbbM7dxWaV1IG4mMLzuFAXPNaK9ovPg5p2r+OvE9hpV/JoyW+sXdhpdvcfZ/s8wi5CCSa6WZ2GQCEikIypJOcDltL+HemXuiW73nieS11a50a81yCxSwMkZhgjmcI0vmDDv5DcbSApzkn5SCucBRXoWrfDEaf8MD4rh1eT7TBDbT3emXiW0UsaTbQrKkdzJLty64MkUeQwPtWr8KPhmfGPh7Ub648N6pqq3c40exns4pWSxuHjZ/tMpTgIjeSpD/LtlY/w5AO55RRXVeK9DtNH8KeEZ47Nre9vbC4lvtzNlpUvriEZBOFIWNFwMdPXJrptT8Bs3gfRrHQvDMF3q720dxqV0t632iykk3SIJ0LeUkDQGNg2BgkhnBBWgDy+iu9+Fui+GNZv/EK+K4N1nb6Tvjn810+ySyXdvAJ/lI3bBMzbTkHHIrp734XaVFpPhPwrJF9h8T3WvR6Tq1/uaURPMqOqCPcFPlrImcYJbcCemAVzxuivQfA/he1lsbbX73ybqK8tPENuLSaAMsb2uleckoJJyd06kcDaYwQcnjT8R+CvCUb6mnhq6uHltfDGm6lLFqFr5KRyT/2eN8couSNzm6dm3rsTLKoPyugM8ror1fwj4S0HTPC/ie78XJ4PnurK6sIYLjUdQuruzRZluWZQ+luxZz5SdSQNpzgnk07wj4MuPCd7rGvSyWUcnhw6rbvpFnJP5Lf20bTdtmuV3nYAgB2jY+SN6bpAVzyiiuvvfA32NtcA1TeNL0Ox1rPkY837SbT91975dv2z73OfL6DdxW8eeGtK8IeNtQ8Nadrk+rTaddTWl1M9mLZA8blfk/eMW6c5AwcgbhyQZzNFFFABRRRQAU+5US6J5jfegmVFP8AsuGJB9gVyP8Aeb1plSS/8i/P/wBfEX/oMlJ7AZdFFFZFHW/GH/ktOtf9sP8A0RHRR8Yf+S061/2w/wDREdFdub/79X/xy/NnNgP92pf4V+QfB7/ktOi/9t//AERJXJV1vwe/5LTov/bf/wBESVyVVP8A3Gn/AI5/lTFH/eZ/4Y/nIK3vB3iHUfDPjG01TTYHuZAfLe1VmH2hW4KfL1PQjg4YKcHGKwa734UeM7jwX4slu7awsrxriMRPFcwq5ePOWRWP3SeOmc4wcjiuSlVnRmqlN2a1TOl0lWXs5K6ehe+JXhG30y7TxNoYgGiX7hVijBjNvKVyUKNyM4Y4wNvKkLgZ5PRdPju9QWS8dIbOPLySShthA/hyo6k4H49q9p8Z6ZJP4SvvGvw+uJz4WuH33+lQqFfSZRg7Hj5AjB5V1xt4zxg15jb2t1qc+y2a9vVBLlIuSOOTgdPc4rTG4uFao6sIct910v1t5eXTY1wmClBKm5czXlr8/P8AM6ceI7zTdc0m48PX1zYHTws1tNDcHbFtOSqYIAyMggjkE5zmvrnxD+0p4K0v4VReNEu2EdwGSO0IBnEw+9CEzywyMn7oBBJwRn4TBfTna1S2fDkcep5GDx684H9K5DxDdxXWoJbwy/aHiyrTq2Vdjjgew6Z7/TFeRWw8aiTfQ9j6/KlJycVd/JLtZen9d/cvBnibxH+0L+194RPiYOmjxah9sSzzmKOGH96wyfvs3lhSe+QAAMCv0in1NYopJZ32YBZye3c1+XE4stL8PLp0loyXVrKY4vJJeNUDE5DqefmYnpnqc9q9It/2gfH9h8LY/CCRQ3awWzQprUssjyovLLI/UEqCAMn+Fc5xWFbDOdlHodFK0G5VZczaTbWtvLbR/ge5+MdatvFfia/17UJxb6VpyNFaXDHHlFTl7hT22lQoPfa/UGovhz8QYfEugx67pE3lXELmG5ixgo49V/usMMPY46g18Xf8Jfq914ag0G61O7NnBkxwyzu8Oc55T1yc+nsKs+DPG+r+C/Ekuq6bqBjaZDHMjJ5sUo7b0JGcHBBBBB9iaqWAlytdeh3U84w/upbPfyPuP4rfFS10/wCEl/p7EQapqcf2O3QnKNkjex5ztC5z9QM5Ir418Q6pbawb6S+R5bsjYJHkzk73ZyG/i/hA3c8nFZfiTxVrfinUH1K/vJb6ZhtExwBGv91EX7g9vx5NYHnTmHyn4UDGTxxW2Gw8qcbM48yxWGfKqSu09XfS3bt8/kOvHlv1i1C4G64iIjm55YYxkn16H8TUf2q4b/RLKWV9x2kONuz2JP8AIUsV3bwW12rfO0kYVAOm7PU/QZ/HFbfgC10DX/iLpeleMfELaHpU822XUljVvJ4OCc8AE4BY9Oprq5OWJ5uJrxxE4yv7z39b21fmrGatne2axxyJC5eUMNpY8ryBnHfFX7fT9VtLj7REqzORljz8wPOea+zNN8K/su+BvEA8Ia3a2Nz4iYI0EviqZ5YLuN+ElhmAMAVh0OBg5B6V4/8AH34UeE/Cvhx/EPgi3l02e2uQt/aJM6+UH6Dy2ZivOCpUlGVsqSAQOWGIUpKK0udapx5X7SPNyro7NLV9tfmeTJJbXTeXeQGKbqpPBH0Yf41X0rwzpl34ztIdXvo7ayMjT3EtyxAlQHcUyMbScEEkjAOe2KoaF/berw3WI/OtbSIyy3MpCiH+783ckjAXqeewJFy8ud8aXZYFAVRBj7x3cn3GMj8TXfS5qFSFSpG6vfyaX6HmV1TqwlGjN2t5XT/K+2vYzPiD4rXxT4o/0KNIdJsVNrYQxZCeWDw4U42lgBwAMAKOdua5OpJxGLqQRZ8sMQufTPFR1ticRPEVZVqj1Z59KlGjBU4bIKvaR/yEz/1wm/8ARTVRp8MskFxHPE22SNg6nGcEHIrFOzNGXau6Rq+oaFrMGraVcfZ7yAkxS7FYoSCMgMCM4JweoOCMEA1XjEF2u+CWGF/4oZZNm33Vm4I9s5+uMl/2OT/nvZ/+BcX/AMVWpJd0zxJq2kWL2NnLbvavcxXjW91axXMbSxh1RikqsDgSOCMYOeQcDGpdfETxXehI7m6097aOWGVLL+zLUWqtD53lgQCPywoNzOSu3DFySCcEc99jk/572f8A4Fxf/FUfY5P+e9n/AOBcX/xVAtDoR8RfFY1n+0vtVhuFobD7L/Zlr9k8gyeZ5f2by/J2+Z8+Nn3uevNVr3xp4g1Lw4miahLYXVukaQpNNp1s90kaEbEW5MfnKoAAAD42/L04rH+xyf8APez/APAuL/4qj7HJ/wA97P8A8C4v/iqA0L+o+KNd1Y6udQvvO/ti/XU7790i+dcL5uH4A2/6+XhcD5unAwlj4m13TLbTYLDUHgTTb5tStNirmK4YRguDjJ4hj4OR8vTk5o/Y5P8AnvZ/+BcX/wAVR9jk/wCe9n/4Fxf/ABVAaHWQfFjx7bajc38WtQm6uLyW/ad7C3d0mlx5jRs0ZMYfADKm1SBgir2ifFB9E+G8/hyLTrm4vZLO50+O7uJ4WjggnDB0RRB5wGHc7fOKbju25rhfscn/AD3s/wDwLi/+Ko+xyf8APez/APAuL/4qgNDfvfiD4t1DwzLoF3qUL2M0MMEwWzgSSdIivlCSVUDuV2KAWYkAYzgkVjzazqdxpWn6bJdH7Lp5ka1jRQvls7BmbIAJJIHJycADoBUH2OT/AJ72f/gXF/8AFUfY5P8AnvZ/+BcX/wAVQGho+IfFWveK7uK5169W6li83Ywhjix5kzzPwigHMkrt/wAC9MCta2+J/jazsI7SDVYNqW4szI9hbvLJbhdogklaMvJFtAHluSuABjgVzH2OT/nvZ/8AgXF/8VR9jk/572f/AIFxf/FUBoS2OrX+nWuoW9lP5UWoW/2S6XYp8yLzEl28jj54kORg8Y6Eip7LxHrenWVpaWN+9vFaXo1G38tVDR3ACgSBsZyNq8ZxxVP7HJ/z3s//AALi/wDiqPscn/Pez/8AAuL/AOKoC6OivfiN4vvzb+fqNui26XaQx21jbwRxi7hENxhI4wvzoMHjg5YYYk1WufG/iS70X+yp7y3a3Niumuy2cCyyW6vE6RvKEDuFNvDt3MSoXAwCQcb7HJ/z3s//AALi/wDiqPscn/Pez/8AAuL/AOKoDQlh1bULfQLvRYbjbY3k0VxPDsU73iDiM5xkYEsnAODu5zgY09N8beJNK+yra3lu0dtZNp0cFzZwXERt2na4MbxyIyyDzWL/ADAkHGOgxj/Y5P8AnvZ/+BcX/wAVR9jk/wCe9n/4Fxf/ABVAaG7P4/8AFlz4Wl8PTajE1hNaxWUqi0hEksMTo8aPKE3sEMabcsdoG0YBIONq2qX+ua/fa1qk/n319cSXVzNtVfMkdizNhQAMkk4AAqP7HJ/z3s//AALi/wDiqPscn/Pez/8AAuL/AOKoDQr0VY+xyf8APez/APAuL/4qj7HJ/wA97P8A8C4v/iqAuV6KsfY5P+e9n/4Fxf8AxVH2OT/nvZ/+BcX/AMVQFyvUkv8AyL8//XxF/wCgyVIbXYN0t3Zog6sJ1fH4IST+AqjeXSzBIYQRBGSV3feYnGWPpnA46DA68kqTsh7lWiiisijrfjD/AMlp1r/th/6Ijoo+MP8AyWnWv+2H/oiOiu3N/wDfq/8Ajl+bObAf7tS/wr8g+D3/ACWnRf8Atv8A+iJK5Kut+D3/ACWnRf8Atv8A+iJK5Kqn/uNP/HP8qYo/7zP/AAx/OQUqsyOHRirA5BHUGkorgOo7jw58RNV0rVoLlLgWsoASSaPIWcdP3i5wfrjucg5NduNPs/Ekko8Namnh+SZjJJZ20Q8syE5U/KQwTPQDIHYDpXiFaGna1qOlyK9ncMhQ5Xn7p9vSp5Va1jrpYucanPKT13tu16nVeKp/E3hvTr611u7uhNKnkoxfcs5PG4NjkBQeeCOAcVyOhaGIyuoaggzt8yGB0Dg+8ikj5enGOc9h19f05PEXjHwrZeJJIrHUbiEyJHbRtmWELjdIsbcNIcdVJYKBgCuV1C7tZ4iVt3mlB3eWqvuY/TGc/rWLhZ7HZWmq0ud1HJLa71/P8jMghluYmkMssIP3VjLKHPHOD0HPP+TVq9lvYNAvIZ7+RJnQF7KLIVF3AZkzj5jxhQOAeSOldFpOleIRBd3MVlJpLuFSK7vIzGYourOqkZBA4GAOpOR1rM1+Dwlpvh26itNYn1PVp8LuY5A+cEsdvGcDuT1qlCV02tDRShClJwl7zT62stV31b6Lon1OEooorqPEFDFTlSQfahnZvvMT9TmkooAK3LTw1cPYC+1C5isIXQtCkgLTT8cbIxzg8cnA9zVDTZrW1vBdXUYlEfKxEZDN2yPQV1mnaT4p8ZXyXFloDSRzf8vt1uEIUNtJ3HAbB6gZbg8HFOFGtXmqdCLb8tTqpvC0qbq4maXZf5/5aXOaa01G6ESXV4pEMYjjWafdsQEnaBk4GSTj3NaEtoLkuLq/uroJEIbcOzu0ag5AHBG3k4HAGa7VvD/w98AyC58X6iNW1ZSr/wBl2QykZ+Q4KZ5xkn94VDKT8prgvFXjnU/E8scQgg0zT4QUhsrMbEC543Y+8QAo7DjgDJrtxeW/VYfv6iU/5Vq1/iadl+L8jz8Nj41Zfu4Nx/mei+Sa1NZ9TNtpS6fbiSHT1ZisUrrErE4G5+hdsAZJHsABXPajqsW9zDIJpmGA6ghIh/s56n3rCJJOTRXmSvJ3k7nc60UrQjb+umyCiiimc4UUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAdb8Yf+S061/2w/wDREdFHxh/5LTrX/bD/ANER0V25v/v1f/HL82c2A/3al/hX5B8Hv+S06L/23/8ARElclXW/B7/ktOi/9t//AERJXJVU/wDcaf8Ajn+VMUf95n/hj+cgooorgOoKKKKANHSde1jQ5zNpOoz2jHr5bcN9R0NdU/xj+Icli1q3iGXay7d4RQ+PqOlcJRQNNo63Q/iT4s0HVJL2C/F15pzLDdrvR+D9CvXPykZIGc4rqZPiX4L8ROD4y8Co0u1XkvLCT95LIAF5+4wXGeC7Ywo56jymivSw2bYnD0/ZRleH8rSkvud/wOOtgaNWftGrS7ptP8D1X7B8ELofaf8AhJdasvN+f7L5bHyc87M+U2cdPvN06nrTv+FbeEP+iraJ/wCQv/j1eUUVv/alCf8AFw0H6c0fykZfU6sfgrS+dn+aPV/+FbeEP+iraJ/5C/8Aj1J/YfwYtj9nu/G2py3EXySyQRExsw4JXELDaTnGGPHc9a8poo/tPDx/h4WPzcn/AO3B9TrS+OtL5KK/Q9Wi+IHw30C4juPDXgGS4lLB2k1CUBomU5UxljLg5J5G3oOvbn9e+K/jTXti/wBo/wBmRJg+Xpu6HcRnktkt36bscDjPNcTRWdXOsXUh7OMuWPaKUV+FvxLhl1CMudrmfdtv8woooryjtCiiigAooooAK1/Cq2T+ONITUYVltWvIlkRiApBYD5sggr6juMjjOayKKEDPX9E00WfijVEt4L7TYItcsv8AQ5dhWQGZ8MP3YIXHKgHGD1aq1r4c0W1+Ktj59rJqdtf/AGpvtMjIbd5drnywhU8qflwxB3YOBjB8porTn8iOTzPQNH8EaZqUKyXEOq2zSXb28sZkTOmqqgh58oM5Psn1zV2+0G01D4V6Pc+bNd3FlZzmK1tWCs6+e2ZTkHKLjkAZ5HQc15lRS5l2Hyvudjp/gt0g1VNVsb+61Kwkjj/srT5U80hxnfkK+VAx0B69qs2ngvS7jwumoPPeKXs5rl7vevkW0iEgQONuSxx6g88A1wtFK67BZ9z0aXwd4VtdGmup/wC2JJLbT7S9k2XEaq5mIUqoMZwATnJzVe+8K6do+uHQZSZheastvFK4HmCFAC2Djgs0irn1Q1wNSNcTskSNPIVhGIwWOEGc/L6cknjuafMuwcr7npl3pGnXHgyW6l0qGCIQRyLPHFHGkZaCST5XC72KuiRkOzZJPQkYz7vwXoC6RJ5Fzfw3cOm2uoSTTSI0X71gGXaEBAGc53VyV74g1bULRre7uI3VyDI4gjWSUjpvcKGf/gRNZlDkuwlFno2seBfDmk3lgJL7Umt5b6O2kmEb7JI2H+sSQxBAQf4Qz5Hel1H4e6RpekXlzdapMJLJRBcDcuEuHaMx9uU2SEnvlTyK84oo5l2Hyvuev3HhLTrPwpPoQa9srOfWreI3946sky7D+8jwoAU5x1PbnrWIPAekNqunwSy6hYtcfac2Fw6G4k8oZQodoA39sj6ZrzuihyXYSi+56xrXhq0vrfSLaa01KJ7PRfNi0vev2qVvNPyZ2dRkk/JnHaqVj8PNFudd1KwW5v52t/K8oKSiIWTcyyzLFIqsp45A/pXmlFHMuwcr7noFl8P4LrwLdaxKZYpobOa7SWOfzYn8sn5SBEFXIH/PQnvjHTVtvD2n6J4E1yaKHULiCfTbaSS+3r5M251Zkj+XgjpyT7gd/KqKOZdhuLfU9KHw+8Ppqtpaz6xMq6hI89iwdf3lqIwy5wpO9mbaMD+FsA8Cq0ngzQLXVNQFy+rNb2ulG/MBVoJA4cLt3SwruX/aCD9K8+oo5l2Dlfc9OfwxodhoHia0t9MvNRmSKyuoCHQzxxupY7SIzgKc7iBgjH3cZNC48BWcehXWrRm+a0TTba6hn3KUeWRgHXO3kDJ4HI4zXAUUcy7ByvuejN4J8NS+OdU0G2n1FP7OiLbZZg8l03y8IEhJUDJzhXJ44HNcf4l0u20bxNcafZy3EkMe0qbmF4ZBlQcMrqp4z1wM9e9ZNFJtPoCTXUKKKKkoKKKKACiiigDrfjD/AMlp1r/th/6Ijoo+MP8AyWnWv+2H/oiOiu3N/wDfq/8Ajl+bObAf7tS/wr8jn/CeuP4b8baZratIEtp1aXy1VmaI/LIoDcZKFh269R1rY8d+HofDnjOe2sXjk025VbuxkjcMrwPkrg7jkA5XJOTtz3rjq6zw14g0uSzh8MeMFnl0Tzd8NzAf3+nOT8zRnBzG38SYP94DcOVhqkKlJ4ao7a3i3sns0/J6a9GlfS4VoShP20ddLNd10t5rXTzfU5+iu4k+GWpag4l8G6rp3ia0Kq5e2nSKWEMoI82N2yhJ3ADJPynODxTf+FR/EP8A6F//AMm4P/i60eU437NKTXdJtfJq6fyZP1/D9aiXq7P7nqcTRXbf8Kj+If8A0L//AJNwf/F0f8Kj+If/AEL/AP5Nwf8AxdH9k47/AJ8T/wDAX/kH1/Df8/I/ejiaK7b/AIVH8Q/+hf8A/JuD/wCLo/4VH8Q/+hf/APJuD/4uj+ycd/z4n/4C/wDIPr+G/wCfkfvRxNFdt/wqP4h/9C//AOTcH/xdH/Co/iH/ANC//wCTcH/xdH9k47/nxP8A8Bf+QfX8N/z8j96OJortv+FR/EP/AKF//wAm4P8A4uj/AIVH8Q/+hf8A/JuD/wCLo/snHf8APif/AIC/8g+v4b/n5H70cTRXbf8ACo/iH/0L/wD5Nwf/ABdH/Co/iH/0L/8A5Nwf/F0f2Tjv+fE//AX/AJB9fw3/AD8j96OJortv+FR/EP8A6F//AMm4P/i6P+FR/EP/AKF//wAm4P8A4uj+ycd/z4n/AOAv/IPr+G/5+R+9HE0V23/Co/iH/wBC/wD+TcH/AMXR/wAKj+If/Qv/APk3B/8AF0f2Tjv+fE//AAF/5B9fw3/PyP3o4miu2/4VH8Q/+hf/APJuD/4uj/hUfxD/AOhf/wDJuD/4uj+ycd/z4n/4C/8AIPr+G/5+R+9HE0V23/Co/iH/ANC//wCTcH/xdH/Co/iH/wBC/wD+TcH/AMXR/ZOO/wCfE/8AwF/5B9fw3/PyP3o4miu2/wCFR/EP/oX/APybg/8Ai6P+FR/EP/oX/wDybg/+Lo/snHf8+J/+Av8AyD6/hv8An5H70cTRXbf8Kj+If/Qv/wDk3B/8XR/wqP4h/wDQv/8Ak3B/8XR/ZOO/58T/APAX/kH1/Df8/I/ejiaK7b/hUfxD/wChf/8AJuD/AOLo/wCFR/EP/oX/APybg/8Ai6P7Jx3/AD4n/wCAv/IPr+G/5+R+9HE0V23/AAqP4h/9C/8A+TcH/wAXR/wqP4h/9C//AOTcH/xdH9k47/nxP/wF/wCQfX8N/wA/I/ejiaK7b/hUfxD/AOhf/wDJuD/4uj/hUfxD/wChf/8AJuD/AOLo/snHf8+J/wDgL/yD6/hv+fkfvRxNFdt/wqP4h/8AQv8A/k3B/wDF0f8ACo/iH/0L/wD5Nwf/ABdH9k47/nxP/wABf+QfX8N/z8j96OJortv+FR/EP/oX/wDybg/+Lo/4VH8Q/wDoX/8Aybg/+Lo/snHf8+J/+Av/ACD6/hv+fkfvRxNFdt/wqP4h/wDQv/8Ak3B/8XR/wqP4h/8AQv8A/k3B/wDF0f2Tjv8AnxP/AMBf+QfX8N/z8j96OJortv8AhUfxD/6F/wD8m4P/AIuj/hUfxD/6F/8A8m4P/i6P7Jx3/Pif/gL/AMg+v4b/AJ+R+9HE0V23/Co/iH/0L/8A5Nwf/F0f8Kj+If8A0L//AJNwf/F0f2Tjv+fE/wDwF/5B9fw3/PyP3o4miu2/4VH8Q/8AoX//ACbg/wDi6P8AhUfxD/6F/wD8m4P/AIuj+ycd/wA+J/8AgL/yD6/hv+fkfvRxNFdt/wAKj+If/Qv/APk3B/8AF0f8Kj+If/Qv/wDk3B/8XR/ZOO/58T/8Bf8AkH1/Df8APyP3o4miu2/4VH8Q/wDoX/8Aybg/+Lo/4VH8Q/8AoX//ACbg/wDi6P7Jx3/Pif8A4C/8g+v4b/n5H70cTRXbf8Kj+If/AEL/AP5Nwf8AxdH/AAqP4h/9C/8A+TcH/wAXR/ZOO/58T/8AAX/kH1/Df8/I/ejiaK7b/hUfxD/6F/8A8m4P/i6P+FR/EP8A6F//AMm4P/i6P7Jx3/Pif/gL/wAg+v4b/n5H70cTXS+BPD0PiPxnBbXzxx6bbK13fSSOFVIEwWydwwCcLkHI3Z7Vpx/DLUtPcy+MtV07wzaBWcPczpLLMFUk+VGjZcg7QRkH5hjJ4rH8S+INLjs5vDHg9Z4tE83fNczn9/qLg/K0hwMRr/CmB/eI3Hi4YR4Rqti42SfwvSUvK26Xdu2m12TKuq6dOg7t9Vsvns32S67mZ4s1x/EnjbU9bZpClzOzReYqqyxD5Y1IXjIQKO/TqetFY1FeZVqSqzlUm7tu7+Z2wgoRUI7IKKKKzKCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAP/2Q==",
	"ngantuk": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwMDAgQDAwMEBAQFBgoGBgUFBgwICQcKDgwPDg4MDQ0PERYTDxAVEQ0NExoTFRcYGRkZDxIbHRsYHRYYGRj/2wBDAQQEBAYFBgsGBgsYEA0QGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBj/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4Poor0GxsU+G0dlrGsaalz4lnVbmy0+7RvKso9xAmlAILSEqQqA/Jjc3zYA9HDYZ1m23aK3fb/NvouvpdkqNzG0f4c+N9etvtOm+Hbtodqusk+2BZFYZUoZCocYHVc9R6itL/AIU58R/+hc/8nIP/AIunaY+u/E/4gWOla5r85efzNkroHSHbGWO2MFVGfLAOMZ6nNd9/wz1/1N//AJT/AP7bXu4LJ44yDnhqM5xTtfnhHX0cXbfu/U1hT51eKb+aPP8A/hTnxH/6Fz/ycg/+Lo/4U58R/wDoXP8Aycg/+Lr0D/hnr/qb/wDyn/8A22j/AIZ6/wCpv/8AKf8A/ba7P9Wav/QLP/wbD/5Er2D/AJX96PP/APhTnxH/AOhc/wDJyD/4uj/hTnxH/wChc/8AJyD/AOLr0D/hnr/qb/8Ayn//AG2j/hnr/qb/APyn/wD22j/Vmr/0Cz/8Gw/+RD2D/lf3o8//AOFOfEf/AKFz/wAnIP8A4uj/AIU58R/+hc/8nIP/AIuvQP8Ahnr/AKm//wAp/wD9to/4Z6/6m/8A8p//ANto/wBWav8A0Cz/APBsP/kQ9g/5X96PP/8AhTnxH/6Fz/ycg/8Ai6P+FOfEf/oXP/JyD/4uvQP+Gev+pv8A/Kf/APbaP+Gev+pv/wDKf/8AbaP9Wav/AECz/wDBsP8A5EPYP+V/ejz/AP4U58R/+hc/8nIP/i6P+FOfEf8A6Fz/AMnIP/i69A/4Z6/6m/8A8p//ANto/wCGev8Aqb//ACn/AP22j/Vmr/0Cz/8ABsP/AJEPYP8Alf3o8/8A+FOfEf8A6Fz/AMnIP/i6P+FOfEf/AKFz/wAnIP8A4uvQP+Gev+pv/wDKf/8AbaP+Gev+pv8A/Kf/APbaP9Wav/QLP/wbD/5EPYP+V/ejz/8A4U58R/8AoXP/ACcg/wDi6P8AhTnxH/6Fz/ycg/8Ai69A/wCGev8Aqb//ACn/AP22j/hnr/qb/wDyn/8A22j/AFZq/wDQLP8A8Gw/+RD2D/lf3o8//wCFOfEf/oXP/JyD/wCLo/4U58R/+hc/8nIP/i69A/4Z6/6m/wD8p/8A9to/4Z6/6m//AMp//wBto/1Zq/8AQLP/AMGw/wDkQ9g/5X96PP8A/hTnxH/6Fz/ycg/+Lo/4U58R/wDoXP8Aycg/+Lr0D/hnr/qb/wDyn/8A22j/AIZ6/wCpv/8AKf8A/baP9Wav/QLP/wAGw/8AkQ9g/wCV/ejz/wD4U58R/wDoXP8Aycg/+Lo/4U58R/8AoXP/ACcg/wDi69A/4Z6/6m//AMp//wBto/4Z6/6m/wD8p/8A9to/1Zq/9As//BsP/kQ9g/5X96PP/wDhTnxH/wChc/8AJyD/AOLo/wCFOfEf/oXP/JyD/wCLr0D/AIZ6/wCpv/8AKf8A/baP+Gev+pv/APKf/wDbaP8AVmr/ANAs/wDwbD/5EPYP+V/ejz//AIU58R/+hc/8nIP/AIuj/hTnxH/6Fz/ycg/+Lr0D/hnr/qb/APyn/wD22j/hnr/qb/8Ayn//AG2j/Vmr/wBAs/8AwbD/AORD2D/lf3o8/wD+FOfEf/oXP/JyD/4uj/hTnxH/AOhc/wDJyD/4uvQP+Gev+pv/APKf/wDbaP8Ahnr/AKm//wAp/wD9to/1Zq/9As//AAbD/wCRD2D/AJX96PP/APhTnxH/AOhc/wDJyD/4uj/hTnxH/wChc/8AJyD/AOLr0D/hnr/qb/8Ayn//AG2j/hnr/qb/APyn/wD22j/Vmr/0Cz/8Gw/+RD2D/lf3o8//AOFOfEf/AKFz/wAnIP8A4uj/AIU58R/+hc/8nIP/AIuvQP8Ahnr/AKm//wAp/wD9to/4Z6/6m/8A8p//ANto/wBWav8A0Cz/APBsP/kQ9g/5X96PP/8AhTnxH/6Fz/ycg/8Ai6P+FOfEf/oXP/JyD/4uvQP+Gev+pv8A/Kf/APbaP+Gev+pv/wDKf/8AbaP9Wav/AECz/wDBsP8A5EPYP+V/ejz/AP4U58R/+hc/8nIP/i6P+FOfEf8A6Fz/AMnIP/i69A/4Z6/6m/8A8p//ANto/wCGev8Aqb//ACn/AP22j/Vmr/0Cz/8ABsP/AJEPYP8Alf3o8/8A+FOfEf8A6Fz/AMnIP/i6P+FOfEf/AKFz/wAnIP8A4uvQP+Gev+pv/wDKf/8AbaP+Gev+pv8A/Kf/APbaP9Wav/QLP/wbD/5EPYP+V/ejz/8A4U58R/8AoXP/ACcg/wDi6P8AhTnxH/6Fz/ycg/8Ai69A/wCGev8Aqb//ACn/AP22j/hnr/qb/wDyn/8A22j/AFZq/wDQLP8A8Gw/+RD2D/lf3o8//wCFOfEf/oXP/JyD/wCLo/4U58R/+hc/8nIP/i69A/4Z6/6m/wD8p/8A9to/4Z6/6m//AMp//wBto/1Zq/8AQLP/AMGw/wDkQ9g/5X96PP8A/hTnxH/6Fz/ycg/+Lo/4U58R/wDoXP8Aycg/+Lr0D/hnr/qb/wDyn/8A22j/AIZ6/wCpv/8AKf8A/baP9Wav/QLP/wAGw/8AkQ9g/wCV/ejz/wD4U58R/wDoXP8Aycg/+Lo/4U58R/8AoXP/ACcg/wDi69A/4Z6/6m//AMp//wBto/4Z6/6m/wD8p/8A9to/1Zq/9As//BsP/kQ9g/5X96PP/wDhTnxH/wChc/8AJyD/AOLo/wCFOfEf/oXP/JyD/wCLr0D/AIZ6/wCpv/8AKf8A/baP+Gev+pv/APKf/wDbaP8AVmr/ANAs/wDwbD/5EPYP+V/ejz//AIU58R/+hc/8nIP/AIuj/hTnxH/6Fz/ycg/+Lr0D/hnr/qb/APyn/wD22j/hnr/qb/8Ayn//AG2j/Vmr/wBAs/8AwbD/AORD2D/lf3o8t1j4c+N9BtvtOpeHbtYdrO0kO2dY1UZYuYywQYPVsdD6GuXr0rxDY678I/GMVnofiWdnntluHdIhGjZaRAGjJZWxgkE9M8Y61WvrFPiTHe6xo+mpbeJYFa5vdPtEbyr2PcAZogSSsgLAMhPz53L82QfFxOXQU5UqScakd4tp/dJWTflZeTbMnBXst+x59RRRXjmZ1Hw50eHXviloum3PlmFp/NkWSMSLIsamQoVPBDBNv49D0qDxJrlx4l8V32uXS7XupSwTIOxAMIuQBnChRnHOMmtn4Of8lr0X/tv/AOiJK5GvTb5cBBLrOV/lGNvu5n95UvgXr/kT2d7eafepeWF3Pa3CZ2TQSFHXIwcMORwSPxrU/wCEz8Yf9DXrn/gdL/8AFViUVywr1KatCTS8mQpNbG3/AMJn4w/6GvXP/A6X/wCKo/4TPxh/0Neuf+B0v/xVYlFX9br/AM7+9j5pdzb/AOEz8Yf9DXrn/gdL/wDFUf8ACZ+MP+hr1z/wOl/+KrEoo+t1/wCd/ew5pdzb/wCEz8Yf9DXrn/gdL/8AFUf8Jn4w/wChr1z/AMDpf/iqxKKPrdf+d/ew5pdzb/4TPxh/0Neuf+B0v/xVH/CZ+MP+hr1z/wADpf8A4qsSij63X/nf3sOaXc2/+Ez8Yf8AQ165/wCB0v8A8VR/wmfjD/oa9c/8Dpf/AIqsSij63X/nf3sOaXc2/wDhM/GH/Q165/4HS/8AxVH/AAmfjD/oa9c/8Dpf/iqxKKPrdf8Anf3sOaXc2/8AhM/GH/Q165/4HS//ABVH/CZ+MP8Aoa9c/wDA6X/4qsSij63X/nf3sOaXc2/+Ez8Yf9DXrn/gdL/8VR/wmfjD/oa9c/8AA6X/AOKrEoo+t1/5397Dml3Nv/hM/GH/AENeuf8AgdL/APFUf8Jn4w/6GvXP/A6X/wCKrEoo+t1/5397Dml3Nv8A4TPxh/0Neuf+B0v/AMVR/wAJn4w/6GvXP/A6X/4qsSij63X/AJ397Dml3Nv/AITPxh/0Neuf+B0v/wAVR/wmfjD/AKGvXP8AwOl/+KrEoo+t1/5397Dml3Nv/hM/GH/Q165/4HS//FUf8Jn4w/6GvXP/AAOl/wDiqxKKPrdf+d/ew5pdzb/4TPxh/wBDXrn/AIHS/wDxVH/CZ+MP+hr1z/wOl/8AiqxKKPrdf+d/ew5pdzb/AOEz8Yf9DXrn/gdL/wDFUf8ACZ+MP+hr1z/wOl/+KrEoo+t1/wCd/ew5pdzb/wCEz8Yf9DXrn/gdL/8AFUf8Jn4w/wChr1z/AMDpf/iqxKKPrdf+d/ew5pdzb/4TPxh/0Neuf+B0v/xVH/CZ+MP+hr1z/wADpf8A4qsSij63X/nf3sOaXc2/+Ez8Yf8AQ165/wCB0v8A8VR/wmfjD/oa9c/8Dpf/AIqsSij63X/nf3sOaXc2/wDhM/GH/Q165/4HS/8AxVH/AAmfjD/oa9c/8Dpf/iqxKKPrdf8Anf3sOaXc2/8AhM/GH/Q165/4HS//ABVH/CZ+MP8Aoa9c/wDA6X/4qsSij63X/nf3sOaXc2/+Ez8Yf9DXrn/gdL/8VR/wmfjD/oa9c/8AA6X/AOKrEoo+t1/5397Dml3Nv/hM/GH/AENeuf8AgdL/APFUf8Jn4w/6GvXP/A6X/wCKrEoo+t1/5397Dml3Nv8A4TPxh/0Neuf+B0v/AMVR/wAJn4w/6GvXP/A6X/4qsSij63X/AJ397Dml3Nv/AITPxh/0Neuf+B0v/wAVR/wmfjD/AKGvXP8AwOl/+KrEoo+t1/5397Dml3Nv/hM/GH/Q165/4HS//FUf8Jn4w/6GvXP/AAOl/wDiqxKKPrdf+d/ew5pdy1f6nqWq3K3GqahdX0yrsElzK0rBck4BYk4yTx7mrfhvXLjw14rsdctV3PayhimQN6EYdckHGVLDOOM5FZVFZxrTjUVVP3k738xXd7m58RtHh0H4pa1ptt5YhWfzY1jjEaxrIokCBRwAofb+HQdKK0vjH/yWvWv+2H/oiOitszhGnjK0IqyUpJfezSorSaD4Of8AJa9F/wC2/wD6Ikrka674Of8AJa9F/wC2/wD6Ikrka0n/ALjT/wAc/wAqYpfAvV/oFFFFcJmFFFFABRRRQAUVq6H4b13xLem10PTJ7x1++UACJwSNznCrnacZIzjAru4Pgtf2ltHd+KvE2kaHbSKAGeTewkIz5Z3FVzgNyGP3eMjmu7DZZisTHnpU2132X3uyLjTlLVI8vor1Y+Ffg1aYtr7xpqz3MYCyvDEdjMOpXELfKeo+Y8Y5PWl/tX4H4z/whmtf9/W/+P11f2O18demv+3r/wDpKZXsbbtHlFFer/2t8Dv+hN1r/v63/wAfpP7E+B90ftP/AAkut2Xm/vPsuxj5OedmfJbOOn3m6dT1o/se/wANem/+3rfmkHsu0keU0V6mfgudR/5FXxromseX/r8ts8rP3f8AVmTOcN1x079uH1/wf4l8MbDrmkT2qPjbLkPGSc4XepK7vlJ25zgZxXPicqxeHjz1Kb5e61X3q6JlSlHVoxKKle3mit4p5IyscudjH+LBwf1qKvPJaa3CiiigQUUUUAFT2VncahqVvYWcfmXFxKsMSZA3OxAAyeByR1qCug8Gf8jU3/Xhff8ApJLWtCmqlWMHs2kNK7sXobfw/psfkDS4tYlHElzdSypGx/6ZJGyMq8kZcknAOEyVqT7Tof8A0J+kf9/rv/4/VGvXvhv4L8Pa94Gsb3UdGtLye41t7Keaa8khkSAQB/3SLIodweQArE5PHcephozry5IKK/7dX+TZ4+b51Syuh9YrJuN7aW7N9Wu3c8v+06H/ANCfpH/f67/+P0fadD/6E/SP+/13/wDH69W8BeCPCOq6TZ3OqaVLdBtdvLR/Mlkid4I7NpVQhWG07gD2PbpxVDxF8OtOi8O6B/wj8fnza3qzR2d2XY+ZbOqGMMucAruYNwDlTW/1Wt7P2iUbf4Vfp5eZ5i4wwf1r6pJST7tK32r636cje17fO3nH2nQ/+hP0j/v9d/8Ax+j7Tof/AEJ+kf8Af67/APj9d98TfCXh3S9JtNY8JxQLZxXMmnXXk3y3Yd15jlJV22F1DfKcY29BXPw+CPN+ENx46/tq1XybsWv2Aj52yQM5z15ztx0BOayqU6sJuHLF2V/hjt9x3YXiHDYjD08TdxU5cqTWvM3ZJ2va/raxg/adD/6E/SP+/wBd/wDx+j7Tof8A0J+kf9/rv/4/XT+FtE0mT4feIPFN7p39rXGnSQRR2JkdI1Dk5lk2EMQMYGCOetbvhfSPA2v6bqV5q+g3Gky6IP7RuLa3llYXlsV/1XztlDvK4Yfwt3I3U6dKc+X4VfX4V5/3bdGRiuIqeH9o3TlJU2otpRerSaVr8z+KKva13va7PO/tOh/9CfpH/f67/wDj9H2nQ/8AoT9I/wC/13/8fr2DQ/BngzW/CGhzNotnDf6xaajPHDHcXXns8Tv5axEsYgqqAD5nJwOpzXM3ui+GtP8Agx4f1Y2mjJqeo292ZJL570zSMkpRTCIj5QIGPv4GcZzzWksNUjHmfJa19l5f3d9UctLi2hVqexjTnzc/Jbljv7+u/wAP7uWvl624X7Tof/Qn6R/3+u//AI/R9p0P/oT9I/7/AF3/APH69Y1zwN4atvhvJqMWiwwyR+H7LUFure6kkuGuZCA++IuwWMjndsUDnB7ClceEPDsfwd/4TJfD8o1F7BF/sz7Q+2LMhT7fjfv2HHCn5cnoVolhasW01HRX+Fbf+Ak0uMMLUjGSjLWagtI/E0mvtba/LrbS/mn2nQ/+hP0j/v8AXf8A8fpj6VpeuyJaabpq6bqUjBLdIZXaCZs8IRIWZXYnAfdt4UFVBLipRXD7W+koq3ol+KR9Qqj6nN1v6JoltPY/2tqxm+w+Y0EcVu4SSeRQpYBirBFUOpJIOdwAH3mSPxn/AMlI8Qf9hK5/9GtW9J/yKPhr/rwk/wDSu4rzcTF0pSgujsc2PqSpqMIv4nb8G/0/y11DzNA/6E7SP+/93/8AH6PM0D/oTtI/7/3f/wAfqpXsPwq+FGi+MPC8+ua3d3W0zNBFDbOF24AyzEg888D275rj55dzwsdiaOBpe2rTlb/FL/M8p8zQP+hO0j/v/d//AB+jzNA/6E7SP+/93/8AH66u+8EWmm/HCPwTc6iTaNdxRfaOA2xwrAegbDAfWr2qeH9EuPC3iS+i0NtFm0bUIrWH97I32pXdlKMHJ+dQA2VwMHpRzy7kPGUfctKTUkmnzS2k7L7V9/u6nDeZoH/QnaR/3/u//j9HmaB/0J2kf9/7v/4/XsPib4eeErU+KL/SLIi20618ryGncm1uQyHdy2WVkfIzkZDegrGHhDw7/wANKXPhX+zv+JQgkK23nScYtS4+bdu+9z1/Sjnl3OalmuHqwc4uekXL4nskm/tb+8v8zzfzNA/6E7SP+/8Ad/8Ax+jzNA/6E7SP+/8Ad/8Ax+vV/CvgLwvrvhnwg7Wh/tO6eS4u0MzgXduk5jcD5vlZQUPy4yA1ZNroXhm0+Hd5rF3Z6QLlNcmsUk1SS8KeUsYYIotzndnPLe/PSjnl3KWZ0XJwXO2nb4pd2v5vJ/1c8+8zQP8AoTtI/wC/93/8fo8zQP8AoTtI/wC/93/8fqpRRzy7nrey/vS/8Cl/mWy3h6RTG/hLT41bgvBcXKyKPVS0rKG9CVYZ6g9K57XdGTThBfWTvJp90zrCZCPMjddpeN8YyV3p8wGGDA8Hcq61S6j/AMk0v/8AsJ2n/oq5q6c3ezLpylRlFptptJptvd26t2tv+BxlFFFdJ7R13xj/AOS161/2w/8AREdFHxj/AOS161/2w/8AREdFdmb/AO/V/wDHL82a1fjfqHwc/wCS16L/ANt//RElcjXXfBz/AJLXov8A23/9ESVyNVP/AHGn/jn+VMUvgXq/0CiiiuEzCiiuw8CeBLnxdeyXd3N9h0O0y15fOQoAAyUUnjdjkk8KOT2B3w2GqYmoqVJXbKjFydkYGiaDq/iPVhpui2L3dyVL7FIUKo6ksSAB0GSepA6kV6jF4R+Hfw+2T+MtT/tzV02t/ZtsNyRn5DgrkZxknMhUMpPyk1n6v8QbPRdAi8L/AA5WewsI94nv5FAnumOVLA9RkYO7hvugBAuD5zXrKphcBpTSq1O7+Fei+16vTsjS8Ybav8D0HWvi74jvohZaHHBoOnpH5KQWqhnCbQuN5Hy4wduwLjPfANchbpqPiTxHFFPdyXF5dOqNcXMhY9MZZic4Cj8AKza9K0fwjq32nTNB8Maa+peJNRPkiK3O9/MYn93zgIECksTwMEk4FedjMfiMT71abf5fJbL5Dg/aTXtHp1OY8btZHx1eHTwDaqVSMjjKqoUH8Qor1v4aaLFdWES+L/2dk1Lw7MMNq9tJd2d0ikffjaSYJL/ugDPY17H4M+BXhn4Zm31vxAH8UeMJI98Npa48i229TGWGcL/FO2B/dHr0ct/rvinUpNGOn/Zb140kMUd1I+2N87fO39mCkjODgA4wRXDHZI3rv21adVKybbsfKXjH4PXh+I99afDyCfUtBbbLaT3MqIyq4zsYtjJH06YzzWNqXwV+Jul2jXU/hS7lhUZLWzLNj8FJP6V9h+G/C13oDtdanos/2HcVlvbOXfLbEHB82MgnaMDJXoOcEV6LNoepx2q3OnCPVrVlDeQNqTMp5BicYRjjoGxn+9Vc9jF00fmBi807UAf39pdQOGHWOSNgcg+oINeleA/HHj99Strd7g6hpasFml1BSVjUsCSZgN27qACW64CnjHY/FbxLofiH4n3DvpMSWOku8AM9v5FxO6/eMm4bkwQRtI4AzgMePM5fE8l8jpPfGwslPAQF5H9di5wOB1P51vQzDEYZ82Gm4vy/y6nTg6UFUXtJWj/X3HWaroXgjxt4gl0tNXi0G9t9sGnwRxKkLIWBPyYCszMzYVWByScECvLPE3hLXfCOpLZ63aeV5m4wzIwaOYA4JVh+BwcEAjIGRUN/d/bdQkuAnlqxwqA52qOAPyxXaeF/iK1ppL+GvF9u+seHpIPJEG0GWEDldpJBIzgDJyuFKkbcHvw/1XEU1Srrkn/Otm/7y/VfNMnG4inia8ppWTenp0/A82oru/G3w/i0XSrfxL4YvJNV8OXKrtuTgvAx4xJgDgnjOBg/KQDjdwlcOKwtTC1PZ1Vr+DXRp9UzilFxdmFFFFc5IVp+H9Si0nxFBeXCO1uQ8M4jAL+VIjRybMkDdtdsZ4zjPFZlFXTm4SU47rUE7anXXdhcWkcU7ASWs+Tb3UYJinAxkoxAzjIyDgqeGAIIpYdV1O3tIrWDUruKCGcXUcSTMqpKBgSKAcB8AfMOa57TtZ1jSPM/snVr6w83HmfZZ2i34zjO0jOMn8zV3/hM/GH/AENeuf8AgdL/APFV1qtR3u18r/jdfkROjTnpL8rm6niXxFG7PHr+qIzTPcFlupATK67Wfr94qSCepBxTLfX9etIrSK11vUYI7Nme2SK5dRAzZ3FAD8pOTkjrk1i/8Jn4w/6GvXP/AAOl/wDiqP8AhM/GH/Q165/4HS//ABVX7en/ADy+7/7Yx+o4e1uVfcvP/N/ezRS+vY9PlsI7y4W1mYPLAshCSMOhZc4JGTgmq9Vv+Ez8Yf8AQ165/wCB0v8A8VR/wmfjD/oa9c/8Dpf/AIqodSi/tP7l/wDJGypQje3XyNPT9T1LSbv7VpeoXVjPjHm20rRNj0ypBp7azq7T3czaremS8XZdOZ2JnX0c5+YcDg56Vk/8Jn4w/wChr1z/AMDpf/iqP+Ez8Yf9DXrn/gdL/wDFVSrUkrc0vuX/AMkRLC0ZS52lfvZG9D4n8SW2jjSbfxDqsNgFKi0ju5FiwSSRsBxgknPHc0QeJ/Etto50i28Q6rDp5RozaR3cixbWzuXYDjBycjHOTWD/AMJn4w/6GvXP/A6X/wCKo/4TPxh/0Neuf+B0v/xVP6xT/nl93/2xm8Bhne8Fq7/Ct+/r5myNd1wSeYNZ1AP9m+xbvtD58jp5XX7n+z09qDr2uG6e5Os6gZng+yvKbh9zQ4x5ZOclMcbelY3/AAmfjD/oa9c/8Dpf/iqP+Ez8Yf8AQ165/wCB0v8A8VS9vS/nl93/ANsV9Sofyr7kWavWVkhiGpakJodJikCz3CjG7GCY4yRhpSDwvvk4UMRkf8Jn4w/6GvXP/A6X/wCKrOv9T1LVblbjVNQur6ZV2CS5laVguScAsScZJ49zU+1ox1V2/NJL83/XU3UIoNTv5tV1u81S4VFmu53uJFjBChnYsQMknGT611WiytrugWWl2qNLqdgHiS2jUlp4C5kBQclnVnk3Afw7CAQrkcXRXDUvUu5bswxND20VrZp3Xrt+p11dD4b8c+KfCMU8Wgaq9tFOdzxlFkUtjG4BgQD7j0rjP+E18Zf9Dbrv/gfL/wDFUf8ACa+Mv+ht13/wPl/+Krn9i+55tXA1a0eSpCLXZtv/ANtNq9vrzUdSm1C+uZJ7qZzJJM5yzMe9TX2tazqcUUepatfXiRf6tbid5An0BJxXP/8ACa+Mv+ht13/wPl/+Ko/4TXxl/wBDbrv/AIHy/wDxVHsX3K+p1tPcjptq9P8AyU6J9d1uRrtpNY1BmvcC6LXDk3GOnmc/NjtnNWpfGHi6YoZvFOtSGNiyF76U7SVKkjLcHDMPoSO9cn/wmvjL/obdd/8AA+X/AOKo/wCE18Zf9Dbrv/gfL/8AFUexfch4Co96cfv/APtToINa1i1e0a21a+hazDC2Mc7qYA2d2zB+XOTnHXNT2XibxJpsLxad4h1WzjkcyulvdyRhnPViARknA59q5j/hNfGX/Q267/4Hy/8AxVH/AAmvjL/obdd/8D5f/iqPYvuOWBqy3hH7/wD7U0iSTknJorN/4TXxl/0Nuu/+B8v/AMVR/wAJr4y/6G3Xf/A+X/4qj2L7mn1fEdo/e/8A5E1YopZ50ggjeWWRgiRopZmJOAAB1JqLxHdJYaEPD2Qbx7lbm8Tr5BRWWOPPZ/3kpcc4+QcMHUZk/i7xXc20ltc+J9ZmhlUpJHJeysrqRgggtggjtWNVwpcruzSlhJuSlVtZa2Wuvm7Lbtbe2vQKKKK1PSOu+Mf/ACWvWv8Ath/6Ijoo+Mf/ACWvWv8Ath/6Ijorszf/AH6v/jl+bNavxv1D4Of8lr0X/tv/AOiJK5Guu+Dn/Ja9F/7b/wDoiSuRqp/7jT/xz/KmKXwL1f6BRRWjoOiX3iPxFa6Lpqobm5YqvmNtVQAWZifQAE8ZPHAJ4rjhCVSShBXb0RCV3ZG/4E8CXPi69ku7ub7Dodplry+chQABkopPG7HJJ4UcnsDreN/G9tqNlF4V8Kw/YfDVphUjQFTckHO5s87c8gHkn5m5wFufEHV9L0XTF+HPheDyrCzkD3tyJNzXU2OQxU4bBxuz/EoAChBnzmvbxVWOBg8HQfvPScu7/lX91de78jWT5FyR+YUUVNa2t1fXsVnZW8txcSsEjhiQu7k9AAOSa8YxI4ziZSccEHnpX6Xfs4/Bk+E/hvceOtXiE/iLxIzypIV2/ZLF2Loig8qZRtdu+Cqn7pz8w/Bn9ne4TxVp/iP4uWg0rTI38+30C6IW71Er83zxfeigHV2YAsPlUfNkfc/i7xtPp3w4vJLWYC5uWj0+2xgbZp5BCGGPQuW/4DXPVd9jooQlJqK6kttoWmy3bFEWaW7TzZpCM741cKo/3MngdOp7mvLfgljxFrvxA1q6TdeSa+SS3UR+VtQfQAECvQfDHjPSX+LnirT7YxyQ6bb6bpkMZPyoB5xP47sD8BXnXgfxNB4E/aj1zwTe2kEFjq0ZeylZcC4OWkiJ9TtaRPqgFYybTR6eEpqdGvFfEkmvRPX8NfkeupYRRarHa+XiS4VnXH8RQDP44IP0FU9O+w6V43Xwq5EEV0N1ujLjypCpcxgf3HUM6e6SL2Arlfif8R5dH1XQtR0qFZJNP1p2uYYxlng+xkyhQOp2sCB/s1xvxk8bprHw3i8beGb5R4h0CeO52q+SyKyyY/2lOEkQ+hb1YVV+hz0MO6jV9E9L+f8AX5mH+2R8G7LWPCsnxH8Kwganp4VdbSNcfarZRt+0e7R8bj3Tr9wV4tafBe91D9nSN5dKQXN2Ptdpd8B1nA+RT32OoEfpvIPavtO48UW+veA4tZ022iu4L+yS5W1flZo5EDGI/VWK/WvNtB1HRYvBn9jWFz9rsW3fYWJBMidfJb+7MmMFTjdt3DOTjSm+V3OZx6M/N5gVYqQQR1B7UleqfGz4ez+GvGVz4h0qJp/D2pzNNDcIMrBIxy8L/wB0g5wDjI9wceV10HM1Z2Ot8D+OLjwpeS2l3D9u0S7yt5YuAwIIwWUHjdjgg8MOD2Il8eeA7fSrOPxV4Vm+3eGrvDJIhLG1JONrZ5254BPIPytzgtxtdv8AD7xPY6fPceGfENsl1oOrMsU6yvtWB84EnJAA6bm4I2qwPygH18JXhiILB4l6fZl/K/8A5FvddNzSElJckvl5HnlFdF438K3Hg7xjcaTL80B/fWshcMXhLEKWwB83BB4HIOOME87Xk16M6FSVKorNaMzaadmFFFFZCCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAOu+Mf8AyWvWv+2H/oiOij4x/wDJa9a/7Yf+iI6K7M3/AN+r/wCOX5s1q/G/UPg5/wAlr0X/ALb/APoiSuRrrvg5/wAlr0X/ALb/APoiSuRqp/7jT/xz/KmKXwL1f6BXsXhGH/hX3wavvGU8ezV9Wxb2G9PmjU52nlDjOGkwcqwSPua8y8N6HceJfFdjodq217qUKXwDsQDLtgkZwoY4zzjAruPi7rUd941TQ7JYI9P0eMW8McG3YGIBfGB8uMKm3nGztkiu3LP9lo1Mc917sf8AE1q/+3V+LRVP3U5/cefUUUV5BiFKCQwIOD2xSUUAfS/wce08IaHoX2pDc+IvFhm1FjIcm30uzDsuSeR5k0ROO+xD2r3D4leJP7J8J+GmEpMdtr1t5xPrEkjnP/AlzXy58O9Xl134wavrcW9rHRfCUWnwE9IgIYYtv4sZm+pNet/E3Xbe88M6xw80em65b6oYojlpIGcI4X/vo/gwrllLRs9XA0uaXp/nb9TqJ5NY8H+GtM8YfYdYi/tiF5r64msnSP7R5ouIQrHlvlDL07VZ8eX+k/EHwraaoZpLXUtPlS4sr63bEkSOykMD3AJU49VyK898SfGP4z3HhOx1HxBJ4UPhrU7VLu38OPbSCT7MZpEXEyAHdEYhufI2krwTkV6x4U+FOq+JvhRpXivw7LFPbahalzpdw3lSqpJUqr42h1IYHorYDDbkqOWFbkjaqd88PUusRH3Vsum2n5KxlfC5PFfiv4qXmp+INd02zFgXuHvzbCaOVjEsA2xMQAzBHbuBgnGK5z4i+GdE0nV2Hw4+ImjeJLi53Wr6LBcwNcgNuZohBHyyffZcDKc9jx6B48+Emo6x8AUMei6npqaUv2jXNEgm+zy615RiTiZQ2IvJV2wM/NkkHbz8+aB+zdqd14litbvTNOtBeLdPYPFOAyL5R8iUMpBIWQx5JGfzrJVG5c7lY7sLg6k4Sq0bcsd7tL8D2/4c6/caV8BvBUFyZFuYriGxKSZVgBcPEQQfQfyrGs9N0X/hYniexm0yxuoLh0v4S+VYCUZ52kbk3hgc52kg+tc5pt3bQ+N/CngbS7mW4ttLme+ubqRy7ShJHkMjkknJynXuwFcRrPjC80z4pWeo20oPkz3Gmyo33XiLLIgPsBLx9K76Urq55+LwjU4wXxSvL5a2/Bfidp43TVrnQrjWfAd0sEyK0N5oU8KTQT7RyjRMCN3BwejYHcivk7Ub06jqMl21ta25c58u1iEUY+ijgV9FXviWey8aaVrFrIY4NTufskyE9ZMCSM/UNx9D7V4Z47trOz+JviC10/b9mj1GdYwvRV8w8D2HT8K7Le7c8OsrM56iiipMT1i0h/4WL8CJdOWPzNc8O4MG1MtJEAdqjCfxIrKFHJaNCTzXjddt8OvELeG/iHY3TSIltcMLW5MjBFEbkDcWIOApCt2+7jIBNVviT4cfwz8Rr+0WNEtrhjd2wjVUURuSQoUE4CkMnb7ucAEV7GO/2vCU8V9qPuS/9tf3aeqNp+9BS6rQ5KtDQraG88U6bZ3Kb4ZrqKORckblLgEZHPQ1n1peHZYoPGGlTTSJHGl5Czu5wqgOCSSegrwzE+yv2tf2YPAHgv4cL4u+E2j/ANnyaLIn9uaet5Pct9nmO2Kf967FQHUrxwQxP8Jriv2mvgP4e8PfF74f+CvhD4TkgvvEOmq5tEupZjPOXI3FpnbYABknIUAEnpXrPxL+OvgfTf27LOI+I9F8Q/D7xP4Zh0DX3sr2O5tlV5rgB3dGKgp5gJ5yEdvUVJ8XPjN8NfDf7cXwo8Z2PinSNd0DS9Mnsry70q7jvRaiUSRBmMRbBXeGI6lQcCsU5aF6Hhtr+xL8VL3x03hO08TeA57+G38+8WHVnkNgfl2xzosRkRmDEqdm07T83TPm/gj4OS+NLnWbeb4lfDvwrLpdz9lePxPrJsWuGywLQgod6gryeOor7d+B/hbwrbft3eNfHfh74paB4qj8Q2N3e29jo05uJLeKW4hdjcsBsj2ttRV3FmznC7TXjXwMf4Iv4H+IN5rTfDh/iJ/bMz6afiC2dOa23KVIB4P/AC2+6C2dvbFVzMVjxD4g/ADx38ONb8O2esTaNfWHiKRY9M1nSrv7TZXBYqOHChh99T93kHIzg138/wCxJ8V7bx03hKfxF4Gi1Frf7RaJLqrxtf4BLrBG0QkcoB8zbAoz97g49X+PPxC+H3iD4E/CG20PxP4GkurDxHbyXdj4dZLW3s0XeHdbZmLww5AILgcEEgZwHeOviH4Kvf8Agqh4I8V23jjQLjw9aaekUmrR6lC9pB+6ucq0wbYvLjgnqw9aOZhZHF/so/s5eGPGXxF8X6X8WbLSbuTRBLp7+Hn1OWC+guY5Iw0+yFlLQjLJv3EFj06GvM9I/Zp8ReI/jLafDfwv8Qvh3r9/c6c+pfb9I1aS7s4lRtpjeRIiRJ0O3b0IOea96+EPxQ+Hvh3/AIKM/E/WdY8XaRaaLrUdzDZas10htJX86Jx++B2AFVYhiccYzkivPvgO/hf9nr9szSk8U/EPwhrOk3ulzRHW/D+ofbLO3aQsEWWQKNjZiGRyFDqScZILvUNDy/wR8AvGPj1vHg0fUtDh/wCEJjeXUftc0q+cF83Pk7Y23H9w/wB7b1Hvj23xv8JIPE/7GHwSt/AXgfTZPFuu3XlTXVlZRx3FyPLlJM0wAJQY3EscADJ6V23w4Pww+Gtr8eY5/jN4K1a98R2U89ilnqKCMxst0Y0DuQskxMmCke7bhcn5gK3PAv7Rfw8+Gv7Lfwp0fUtb02/S8gbS9Zi02/VtQ0mN1c+cUjbzEAIXPAPII5ABTk+gJI+Ifih8Nrz4VeOZPCWqeJvD2talbr/pS6JPLMlq/wDzzkZ40G/1AzjocHitH4DeAdN+J37QnhvwXrX9oLpd7O32t7BC0ixrGzdQDtBKqpYjChs9qk+Nvw/0HwF8SJofCnjzRfGOg3xa4sr/AE/UYbuZFJyY7gRsSsgz1IAbqOcqvpn7H3xD8E+DPEHjTQvFmvL4Yu/Eek/YdO8ROOLGT585b+DJdHBJAzEMkcVbfu3QluP/AGhfAXw/8MePbz4X+Dfgp4n0XxSk8f8AY95aanNqMeswk8v5LAsCQGwIycMpB6ED5w1HTdR0fVrjS9WsLqwvraQxT2t1E0UsLjgq6MAVI9CK/Sn4Z+Nfh5ovh7w5onxg+MHwv8V+LfD087eG9dt9U80RRmEqBcXBAVWwSPmPOE+86gn87vHs+q3XxR8Q3mu6jp+o6lcajPcXV5ptylzbTyO5ZnikQlWQk5GD0446UoPoNo938PfCjwBff8E0/FXxWutA8zxdY6mtvbal9qmHlobq2Qjyg/ln5ZHGSpPPqBXhngLwB4q+Jnjq08I+DtMa/wBTucsE3BEjReWd2PCqPU+wGSQD9VfCW48J+Kv+CbHiP4Wz/EnwR4a8Q6lqxkhi8RaxFZhVSe2l3MDlwCImAIU5P4ms74BzeFf2YP2gLLUfGXxK8BeIdM8R6bc6ab/wpqZ1FdNdZIJFa4wgKI+NoIB6EnAU0rtXCx5b4y/Zc+IXhHwPqniu11nwl4psNHfZqy+G9T+2S6aR185CqlcdwMkDJPAJrvvi54M8LWv7Bfwa1nTNA0LTNY1S6WK81ZLWOGWYFJOZplXcyggE5J6e1ek+J/iNH4L+HnjWHRfFv7Mtppur6dcQfZ/CGnTtf6mDHIscckcUoVHO9hlywQsTyM547xh4r+GGq/sj/AHw54g8S6Ze2lhq8B1/TrG9SS6trX5xKXjRjInyk9geeOcUrt2CyPPbb9kbxhrUF0vgv4lfCvxnqFvC050vw74iFzcuo6kKY1HcDkgciur/AGK/BGgeKvFHxD03xR4S0zWri00X/R7fU7CO4aCbeV+RXU7Xzxxg19G+EvGfwL8F/Hm0PhvWfgNo/hWexZbC+05UXV0fywXFxdFhHEhOQAxLtlRjqR4p+zd448HeG/2gfjbqep+L9C0m1vkvP7OurrUIoI7km5kZPJZmAfIII254Io5m0x2VzxTxV+zR8Q/Cnwem+JMt94a1bSbSVYNQj0bU1u5tOkLBSk20bAysyhgrNjcM8c145X1P8IvFvhbTv+CdXxZ8M6n4m0e01m+vd9pplzexx3FwNkHMcTNuf7p5APQ+lfLFWm+pLCiiiqEFFFFABRRRQAUUUUAdd8Y/+S161/2w/wDREdFHxj/5LXrX/bD/ANER0V2Zv/v1f/HL82a1fjfqHwc/5LXov/bf/wBESVyNdd8HP+S16L/23/8ARElcjVT/ANxp/wCOf5UxS+Ber/Q9Q+C0ENpq+ueKruKOW20jT2dlChpQzZbKZ4ztjkGcj72OhNcDeXdxf6jcX93J5lxcSNNK+ANzMck4HA5J6V6H4X/0b9mTxReW/wC5uJL5YXmj+V2jzCNhYclcO4x0+ZvU15tXZjv3eFw9FdU5P1k2vwSHU0jFfMKKKK8kyCiiigD3f4RQ2tp8H7y9yq3OseJLTRS/dV8l5FB9mJcfWtLxHp2pWegDXiRNYzWpjkgP/LSI5jMZ9wqrz329iAa8O03xFq9joNzoVlM4t7q5guwq53JPDuEbpjowEjj8fYV9C+D/ABfbeNNMh8N6+9tBfajBNaeWuFVb1HaRFAzx5sdxKAP78W3uBWU46WZ6ODxPs5xkun5dfwPdPg7BpfxN+D/he51HTbhLrRxJam4nsQYrn5ts2C2VdXKqzL1WQMf4ju+itE0mHR9CtNMsBtt4AcbvvHLFicAAclie2K/PT4U/H3VvgR4l1bwxq9hHqWim68+awkk8qWJmABmhcgjnADKQQcA/KcmvqrSP2rfgbrpt4NW119CusLOkGt2jRhCRlWEib06Hg7hwa8OtRmpO2x72LrS5VTv7qba103/r+me3tc28lw9lFcxm4VN7Rq3zKpOMkdq8v8f+H9ftPCd1b+CtN060uriNoXv32Qx2EJHzyAKu52AztUYGeSRjBq6l+0h8ItPkW00LxAniXUZzmPT/AA7CbqWVvcgBF9yzDHevnr9pL4x/EW/07SdBt3h0HRtYEouLS0l3z7F25Es3HBBOQgC8Y3NWMablJRHhIVY+9Fe67HCeEpl0DwdqmotcCbU9ZuBp9lNjDeUDxjrgfMCeeuOtea6nffbfHtwSw8qS9dosH74XC5/JB+tSQ6tf3F9E8cnlxW1uy2vykiIsCFfHAwMs3XLEKegrmYbVI5ryWS8mkmtIGliuFwgUqQAMc5BJxj3r3KeqUScRWhTxE610/n9/nt8r31Nvxx4vWfX9NttHYGLSZPOEn8MlwSCzD2Xaqj12k964SWWSed55nZ5HYszMcliTkk1p6Lqctn4hFwIopUmJSaGRAySI3VSDnjv6jGRU2s6VbJANR0nLWudsyBt3kvnp67Txgnvwe1dXM3KzPl5xTjzqWt9v1MOiiimYhXpnxNkbxH8MPCfjMiMzFWsrqV0CSyyY6/KMbN0UpAyMbxgcnHmdel2H+lfsra59p/ffZdRX7P5nzeTloc7M/d++/T+83qa9fLPfp4ig9nBv5x95fqvma0tVKPl+R5RRRUlvbz3d3Fa2sEk88ziOOKJSzOxOAqgckknAArxDIjq/omsX3h7xNp2v6W6JfaddRXlu8kayKskbh1JVgQwyo4Iwe9NGkasXvUGl3pawybsCBs22G2nzOPkweOcc8VSoA94u/wBrP4iL4U1HRfDPhzwP4OfUozFe6j4a0ZbO6uAQQdz7iAcE/MACM8EGvB6Ks3Wn3dna2VxcxbIr2E3Fu24HegkeMng8fPG4wcHjPQiklbYLlaiuhbwJ40iurO3ufCur2jXtxHaW7Xdq9ukkrnCIHcBQSfU1z1OwBRRRQAUUVK1tcLZpdtBKLeR2jSYqdjMoUsoPQkB1JHbcPUUARUUVdfR9WjnhhfS71ZZ7f7XEjQMGkh2lvMUY5TarHcOMAntQBSorRh8P69caK+sW+iajLpyZ33kds7QrjrlwMD86qx2N7NYT30NnPJa25VZp0jJSItnaGboCcHGeuDQBBRV19H1aOeGF9LvVlnt/tcSNAwaSHaW8xRjlNqsdw4wCe1aUPgXxtc2Md7b+DtfltpIxKk8enzMjoRkMGC4II5zTsFzAoq0+m6jFcXkElhdJLZZN1G0TBrfDhD5gx8uGZV5xyQOppZdK1SD7X5+m3cf2NxHdb4WHkMTgK+R8pyCMHHSkBUooooAKKKKACiiigAooooAKKKKACiiigDrvjH/yWvWv+2H/AKIjoo+Mf/Ja9a/7Yf8AoiOiuzN/9+r/AOOX5s1q/G/UPg5/yWvRf+2//oiSuRrrvg5/yWvRf+2//oiSuRqp/wC40/8AHP8AKmKXwL1f6Hq+rf8AJqvhr/sIv/6FcV5pXperf8mq+Gv+wi//AKFcV5pXZm/xUf8Ar3D/ANJQ6269EFFFFeSZBRRWjoVhJqWvW9nFEJXdwFjPR27A+xOM+2aTaSuyoQlOShFXbN3QNIuY0Btoz9ulTc03/PrGRxj0kYd/4VPqeKc+nSSTXTQBvKtNu3yyQQQ3bvnhj+Ir13Tn8K2DpoEWr29xqW7Mqx5d5ZT97oCC2eijntXJ6Lc6JpFrJb+IIp2klnaQxRsmHDE43OHG0DA4HJyeV7+eq8qknofbVspw2BoQhUmm3fmtrZ2so6bav8Djr4+J/iPqsdzr6W80mnKsVxrUp8triPqiyFR+8kIzggbjyW4BI1pVtNWkuEkhjsbq3GyBH+UqmAqRn+8MBQGHpnnJFXNd1i3itXFrBFapEhW3t4/uIG+8R6kn5iR3+lLeWBvbC0tpGKs7FndTggRoOR/wOQflVt2PFw9P3nbWy1v17L77a79e1vcbO18LfBn4LaHrujz211qniSwjuN8kxkdtuRI8i8BFRyyBQQCRjPysR4nrWsXGv+L3M8k2r6i/TGZh/wABRRlvpwoxjAAqKPQrq+ubSG5vrqW2hkjjVGkLBAXzgegJLHHqT6k11Pg3XU8L+F9Y1PSmEGq6ikkxmWAlhGWYACXopDZO3+L5QMnisqNJRk29WdWJxVT6tFQ92N7Lz7/dp6u7fS3JSTaveFrSLSguH8tnu2XG7p90ccHjr1rI05JIdVu7PVrSKBWjkiuI1HyqNpIcf7pAYfl3rqra5R45UC7isrQxjPLbQMkn88mqHiXTbu6R7m4EKtLGCCGCs2z72RndgrknjqoreE+Wa7GDwqq4aUopuaa9LPv28mcLYoxuQ6j5vur/ALx4H5dfwre06O5iEz20YldF2TRtys6cqQ3125z2Jrb8MeG1M32uUB9vyqMYXPfArX8OaQy+NNWswvEYDY9m2kfzNRVxCu2uh6WX8PySpqsvjbXp7ra/FHmOp2kdreZtyzW8o3xFuuPQ+4OQfpVKvRvHvhRtLjNxHGfInYyJgf6uQDLL9GUZ+q15zXVRqqpHmR83meX1MBiJYepuvy6BXpnw0/5Jv8Qf+wb/AO0p68zr0z4af8k3+IP/AGDf/aU9e5kf++R9J/8ApEjlofH9/wCR5PW94IuILT4neHLq6njggh1S2kkllYKqKJVJZieAABkk1g0V4hkep2njHRL7SNXtpTJbXF9YM2qSyMqi6ljMccYi5yzFfMc55LO3GBmptR/4Q/8Ata2/tb/hGv7P/tyL7D/ZezP9n4ff9o8r58f6j/WfvPv15NRVcxPKeon+xP7U0n+2P+EU/trZff8AHn5H2H/VL9k87yv3WfM8zr22b+M1g/EG4jn/AOEbiE+kyXEGkmO5XSmjMMcv2u4YqBH8oOGBIXj5sjgiuMoouOx7RrM+nr8ddN15bXwjbaf/AMJNBcHVrLWlmmlj8/O+SP7S4RcfMT5a4wOg4PN2Z0MeMNJl0uy0a60f7NIIYbu4tYJo32YZrg3B2NIrEMA2UYDCgcged0UcwuU9bhsrZYPFNzplx4Tv7tL/AE1Ibu/tbOG3QPBcNJGg/wBQCNoB2na2wsMttqtrWoeBk8XeHNNtLbSP+EdeV5L+a3gUylft9xtVpMGRVEYjwOGKFc5+WvMlubhbOS0WeVbeR1keEMQjMoYKxHQkB3APbcfU1FRzBynrd7PoreLtIKeF/Dy7UuQZV1vSpI5AUARmVY44VKE7lEq5fJBzjjnfHcejRaVbLYX+l3t4dSuWmlsre3gIjNtaFVKwfJtV/OUFflLByOprhqKHIEi1cef/AGdZ+Z9l8ra/l+V5fmY3HPmbfmznpv5x04r1u11/RNRuYra+1ayil0nw4psp3mUK+/ShDLa5z98SlWC9iJB1NeNUUk7DaueqOmi61rdprd1r6waImlw28aWurxWlxp7pAqunkOrPIC6vwi/Nvzu6im+HrzwlaeEbDwpf+IJoZNWgma9EUEclsss20QGWYygp5RiicjYdu5h3OPLaKfMLlPZ7fXdFvryOzv8AV7GOXSPDg+xXDTrtffpXky2obOCwlKsq+vmDqa88tbq2T4S6jaNcRC5bWLSVYC43siw3ILBepALKCe2R61zdFDkNI9O8RTafDqHj3xFHq+m3Ft4gVhp8UF0kkzeZeRXHzxg7o9qxsDvA5wBmnfFLVNL8RajqU+hanaRW1lfzGawWZdt0zyHF3E2f3pYYBHJUAY+X7vl9FHMLlCiiipKCiiigAooooAKKKKACiiigAooooA674x/8lr1r/th/6Ijoo+Mf/Ja9a/7Yf+iI6K7M3/36v/jl+bNavxv1D4Of8lr0X/tv/wCiJK5Guu+Dn/Ja9F/7b/8AoiSuRqp/7jT/AMc/ypil8C9X+h6ton+lfsr659p/ffZdSX7P5nzeTloc7M/d++/T+83qa81r0f4Ln+0W8T+Ff9V/aemn/SfveVtzH93v/rs9R933487mhmt7mS3uInimjYo8cilWRgcEEHoQe1dmP/eYbDV1/K4/OLf6NDqaxjIZRRRXkmQVcsdRuNO82S0by5pEMYlH3kB4OPQkZGfQmqdFJpNWZUJyg+aLszuvDVpp1p4b+1iQpqVyrss2cGOIEpsjzwGchgzHovTqanlu7WwhhSCxt5LyWNSqABtpPYk9QBgnn19K9G8GfszfE3xd8HbfxZB/Z9piFrnTLCd2W5uoidwPA2oG5K7jkg54BBPCaZ8NviZ4w8dx+GtL8NXv9sRRSHyZlMCQIvBdnfChQSB15LADOa4pzi5u0tj3aVflw8YqnZ9++vXz8/w7QTeCfGXiPw9Nruk+FbzU7awObmfSbF3RACCwLKuDx1xyO+KbpN/FcatbvJc4VYn2KFO4hm+bHHoBX6H+D/Flj4L+HWgeE7rRE0HUrGzEE2nB1ZY5o4llZVdOG81BIySDqysDyCK+Pv2nLTw3F8UYdf8ADl+Y7y6MgnhhQLHJKjfNcpjGwurQllI5JYjjOeWniPaS5GvQ3pqWHk6yjppf70/0OJu5nsYo3R0QwbZQshUMWK849eg4ycUyzFtL4WjjmgUGK1Uo4lcjcyhd2NxUH1OPasiw1ZZ5Ul1AbPLVgY0woIIONoJAHOP1qB7iZdNgAdZfJXlFIPXliMe9dKpvuFTMKTTjGF1ra9nukuq0tbp289F8NXBa2jabmVp5IyPQLkn8z/Suv1aLRrnSNI1JbrTo2twf7Ss7y4HmTukpyUTl2DxleAAAQa880K43a/IFbMeXnX/gQAzXZabqY+0TCOJJ48rFIjKx3HPG0p8wYHuM9SCDVS01McE3O1K+7t8np1aXpdnFRa/qnhzxRKLS8uJ7eGYqsNyWAkTPGVPKkjB9RXY3Hjez0S/1bW9NRLi6v47ZLaOTogEe5mbHoSBjufpXKeMLdJ7mTVEMSyLN9lljiJKgBf3eCQDkKNpyAcrnHOBytaTw8KtpEUc4xmX81FS1T0vrZ2cXbfo/vsz06w+IUviixuPD/iaK3ElwP9Fu4k2BJRygYdME8ZHTPPHTzWeMxXDxkFSrEYPUVGCQcg4NOkkeWUySMWdjkk9SfWrp0VTb5dmcmOzKtjoReIfNOOl+rXZ+j/MbXpehf6N+zF4pu7b9zcSXqQvNH8rtHmEbCRyVw7jHT5m9TXmlemfEGKbQPgl4Q8M3ETmaZ3vXaRTG0TAFjGUPcG4xnI+505493K/chXrvaMGvnL3V+f4HFS05peR5PRRRXiGQUVeh09PKWS8uDCGGVRE3uQehIyAAfrnocYOak+xab/z/AF1/4DL/APHKrlYrozaK0vsWm/8AP9df+Ay//HKPsWm/8/11/wCAy/8AxyjlYXRm0VpfYtN/5/rr/wABl/8AjlH2LTf+f66/8Bl/+OUcrC6M2itL7Fpv/P8AXX/gMv8A8co+xab/AM/11/4DL/8AHKOVhdGbRWl9i03/AJ/rr/wGX/45R9i03/n+uv8AwGX/AOOUcrC6M2itL7Fpv/P9df8AgMv/AMco+xab/wA/11/4DL/8co5WF0ZtFaX2LTf+f66/8Bl/+OUfYtN/5/rr/wABl/8AjlHKwujNorS+xab/AM/11/4DL/8AHKPsWm/8/wBdf+Ay/wDxyjlYXRm0VpfYtN/5/rr/AMBl/wDjlH2LTf8An+uv/AZf/jlHKwujNorS+xab/wA/11/4DL/8co+xab/z/XX/AIDL/wDHKOVhdGbRWl9i03/n+uv/AAGX/wCOUfYtN/5/rr/wGX/45RysLozaK0vsWm/8/wBdf+Ay/wDxyj7Fpv8Az/XX/gMv/wAco5WF0ZtFaX2LTf8An+uv/AZf/jlH2LTf+f66/wDAZf8A45RysLozaK0jYWLDEeoShuxmg2r+JVmP6GqE0MkEzRSrtdeo6/Qg9x3z3pNNAmMooopDOu+Mf/Ja9a/7Yf8AoiOij4x/8lr1r/th/wCiI6K7M3/36v8A45fmzWr8b9Q+Dn/Ja9F/7b/+iJK5Guu+Dn/Ja9F/7b/+iJK5Gqn/ALjT/wAc/wAqYpfAvV/obfg/X/8AhGPHGna4Y/MS3l/eKFyTGwKPtGR821jjJxnGa6v4teH30X4jXN0kGy01H/SomG4gsf8AWAk/xb8tgE4Dr0zivOa9j0of8LF+BEmmiPzNb8O48jamWkiwdqjCd0VlCjktGhJ5ruy5fWsNUwX2vjj6pe8vmvyKp+9Fw+aPKKKKK8cxCvcf2Zfgk/xb+JX2vWIJB4W0dlm1B+VFwx5S2U+r4JYjogbuRXk3hnwxrXi7xdpvhvQrJ7nUNRmENvHjAYk8knsoAJJ6AAk9K/VL4W+BtE+Fvwv07wfoxWRbdTJc3W3Bu7hseZKfqQAB2VVHauPGYj2MLLdnXhMO60vJHYRWltp8PmErHFCmQqfKqKo6ADjAA4HbFcD8PbZb2fXPEtvHlLy/e2gI/hihJyB6fvHlz7r7Vl/Hb4q6f8OvhRqV+8qvfTRmG1t8/NLK3CIB15P6Bj2rufh5oL+E/hR4e8O3LmS6s7CJbmQ9ZJ2G+Zj9ZGc14KXutn0Tm6cbPd/kv+D+Q/V/DXhnUY7e78TWNpJcjFtFNuZGBc4VVIIOcn5T1BJIxk1Q1L4SfDrWfBc/hfUvC1ld6dMdzecC0wYZ2uJifMDLkgENwOOnFYHxd10WcvhjT4rgR3E2qCZBnBPlxSMMfln8K6vw34nh1jTVlJCXCYEsfofUexpJuOqHOhUlSU+j6Hwr8av2ddf+Et0+uaFajX/CbvxcNEDc2RPRJgOo7CRRgnghSRnx+HWrW90q4s48QNIFkgYKMCVeVGR2YEr+Ir9SvG0dnqvw08QWN2FaGXTbhW3dB+7Yg/gQD+FfmL4o8PWVr4k3ecsCXqxyRPjAglcH5XHZSwIPdSQe5r0aOIdRcsx4PBSSdam9nytPZqSa+Xa/RtbbnGwXht9UmuVTy3ni27RxtOck47HnNdHp12LDRDcg8lt6j1PRf5Zrmry3uF1hYL6IQ3ayOsg/uk/054rcMDTyRwkhLeMYAHJNegrNHh3lRquK0aduz/4BZcRa4lzFeS/vr9leOUnASYBtpb2Ytt9s57VxMkbxTNFIjI6EqysMEEdQa9Bi1nTLfw5faW1t56ou5AmMKTnOW6nkA4HfNc/rluL/AMUSGRmSdo4/O8qMvum8td/A985Prmroyai01sdeb0Y1JU8RCV3UV30s72e/d6nOUVZlsbiC2WaVVUM20KWG7/vnqKrdDitk09jw5QlH4lY6DwR4ffxL460/TPI8238wS3IO4KIVOXyV5GR8oPHLAZGat/FnX/7e+J97tj2RWH+gJlcM3ls24nk/xl8dOMcZzXXeGx/wr34M33jGaPZq+q4t9P3J8yKc7TyhxnDSYOVYInc141Xs4v8A2TBQw/2qnvy9Psr839xpL3YKPV6/5BVzS40k1RPMUOqK8u1hkMUQsAR3BI59qp1e0j/kJn/rhN/6KavEjuYPYezM7s7sWZjksTkk+tJRVrTNOu9Y1uz0nT4jNd3k6W8EY6u7sFUfiSK1EVaK9i8f/Cu00vxN4bgtdNvfC2mXt2+jT3msxSxK8sLgG8/e4wkqOjgZCghwCAOM66+GFjapJavqNzYxPqem2g1DXLAWbIlwt3udClzJE0X+jj5iTkjAZArbwDy6ivVoPh/4Q0ubxXb+IrvxPDFZaHDf2t1No8SSKzX0EJkjjW8KSrh9gO/B3ueDGoahr/wst/D/AIFfWLrxdpX9qR2sF2+lm6tN7LMEIRFW4MxkCyBiGhUYViGPGQLnnFFd742+H2meF4tc/svxNLq0uh6yNGv1ksPswEjecUaM+Y24f6PIGyFwcY3A5q7oPhDQdc+BTXEVqy+KpdRvWs5xK2J4ra3tpHttmdu4rNK6kDcTGF53CgLnmtFe0Xnwc07V/HXiew0q/k0ZLfWLuw0u3uPs/wBnmEXIQSTXSzOwyAQkUhGVJJzgctpfw70y90S3e88TyWurXOjXmuQWKWBkjMMEczhGl8wYd/IbjaQFOck/KQVzgKK9C1b4YjT/AIYHxXDq8n2mCG2nu9MvEtopY0m2hWVI7mSXbl1wZIo8hgfatX4UfDM+MfD2o31x4b1TVVu5xo9jPZxSsljcPGz/AGmUpwERvJUh/l2ysf4cgHc8oorqvFeh2mj+FPCM8dm1ve3thcS325my0qX1xCMgnCkLGi4GOnrk102p+A2bwPo1joXhmC71d7aO41K6W9b7RZSSbpEE6FvKSBoDGwbAwSQzggrQB5fRXe/C3RfDGs3/AIhXxXBus7fSd8c/mun2SWS7t4BP8pG7YJmbacg45FdPe/C7SotJ8J+FZIvsPie616PSdWv9zSiJ5lR1QR7gp8tZEzjBLbgT0wCueN0V6D4H8L2stjba/e+TdRXlp4htxaTQBlje10rzklBJOTunUjgbTGCDk8afiPwV4SjfU08NXVw8tr4Y03UpYtQtfJSOSf8As8b45RckbnN07NvXYmWVQfldAZ5XRXq/hHwloOmeF/E934uTwfPdWV1YQwXGo6hdXdmizLcsyh9Ldiznyk6kgbTnBPJp3hHwZceE73WNelkso5PDh1W3fSLOSfyW/to2m7bNcrvOwBADtGx8kb03SArnlFFdfe+Bvsba4Bqm8aXodjrWfIx5v2k2n7r73y7ftn3uc+X0G7it488NaV4Q8bah4a07XJ9Wm066mtLqZ7MWyB43K/J+8Yt05yBg5A3DkgzmaKKKACiiigAp9yol0TzG+9BMqKf9lwxIPsCuR/vN60ypJf8AkX5/+viL/wBBkpPYDLooorIo674x/wDJa9a/7Yf+iI6KPjH/AMlr1r/th/6Ijorszf8A36v/AI5fmzWr8b9Q+Dn/ACWvRf8Atv8A+iJK5Guu+Dn/ACWvRf8Atv8A+iJK5Gqn/uNP/HP8qYpfAvV/oFb3g3xFqHhfxlaarpsDXMgJje1VmH2hG4KcdexHBwwU4OMVg16D8JPGc/gzxbNdW1hY3j3EQieK5hVzJHnLIrH7ucD1zjByOK5aVadGaqQdmtUxU03JW3LnxM8IW+l3aeJ9DEI0TUHASKNTGbeUrkoUbkZwxxgbTlSFwM8noemx3moLJessNlFl5ZZQ2wgfw5A6k4H49q9v8Z6Y8/hG+8a+AJ5z4Xnbff6VEu2TSJRg7Hj5Hlg8q6428Z4wa8xtbS61WbZate3yg7ysWCenJwOnucVeMxcK1R1YQ5b7rpfrby8umx1/V1Ofu/d5nSnxHdaZrWkTeHby6sDp4E9tPBcHbGVxlUwQBkZBB6gnO7OK+ufEP7S3gjSfhTF40W7YJcbkjsyAZ/OH3oQmeWGRk/dAIJOCM/Cvz6az2kdsxD44POT6H8cHA/pXFeJLyK71FLaGUXDwkq04bKyE44HsOme/0xXk1sPGok29j0Hj3Tk5cqu/KyXRWXp/Xf3LwZ4n8SftD/tgeEW8Th00eLUPtiWe7MUcMP71hk/fZtgUnvnAAGBX6Sz6mIoXlmcIBlnJ7dzX5dzJp2keGV06SzZLu1lMcXkkvGFDE5Einnkk9M9TntXo0H7QHxBsPhUng9YYLoQWrRJrUksjzInLLI/UEqpAGT/Cuc4rCth3Oyj0OimlB81WXM2k21rby20enoe6eMdbtvFXiTUNe1C5FvpOnI0VnckgeSUOZLhT22lQoPfa/ZuY/hz8QYPEugx67pMwiuYXMNzDjBRx6r/dYYYexx1Br4qTxlqtz4Zg0C71O7NnBkxwyzu8Oc55Tsc8+mewq14L8c6r4L8Tyarp2pGMzIY5kKebHKvYOhIyAcEEEEH2JFOWXy5X3O6nnGGtCKej38vU+5vit8UrWw+E1/p24QapqiGzt1Jypzje3XO0LnP+8BnJr428Qapa6w+oNqCtJdnEYlaTIY72ZyG787QN3PJxisjxJ4q1zxTfPqd7ey30zDaJzgCNf7qIvCD2wPXk1zpnuPI8puFAxk8cVvhsNKmrNnHmWKwr5VRV5J6u+lu3bzv8ia/kl1ER6jc/PcQkRT84LrjG4n15B/E1D9puGItbKWZ9x2kSDbs9iT39hSQ3tvBa3iN+8eSMKgHTdnqfYDP44rb+H0Gga/8AEfStK8ZeIToelTzbZtSEat5PBwTngAnALHp1PFdXLyRv2PNxWIjiakZ3957+t7avzViglne2SJG8cDmSUMNpY4K8gZx3q/badq1ndG6iCzMeXPPzg8559+a+zdO8Mfst+BdfHhDW4LG68QsEeCXxVM8sN1G/3JIpgDAAw6HAwcg9K8d+P/wo8IeFPDL+IfAsEumXVrchb+zjnceSr9AY2ZinOCpVijKcqTyByQxKlJR2udapxcX7WPNyro7NLVvpr8zylJba8kWO9hMUw5TOAc+zD/Gqel+F9Mu/GtpFq1/Hb2Rka4uJbpyBMgO4pkY2kgEEkjAy3bFZ+gNrmrR3X7o3FtaxeZLcSkL5H935j1JIwB1PPYGr9/cbo0vS6lQVSMf3ju5PuMZH4mvQpc1CpCpUjdXv5NL9OhxTVNxvTbcX0e9/19V0uY/xC8WL4p8Uf6FGkOk2Cm1sIYtyp5YPDhTjaWAHAAwAo525rkqknEYupBFnyw5C59M8VHWuJxE8RVlVqPVnmybk7sKvaR/yEz/1wm/9FNVGnwyyQXEc8TbZI2DqcZwQcisk7Mll2rukavqGhazBq2lXH2e8gJMUuxWKEgjIDAjOCcHqDgjBANV4xBdrvglhhf8Aihlk2bfdWbgj2zn64yX/AGOT/nvZ/wDgXF/8VWpJd0zxJq2kWL2NnLbvavcxXjW91axXMbSxh1RikqsDgSOCMYOeQcDGpdfETxXehI7m6097aOWGVLL+zLUWqtD53lgQCPywoNzOSu3DFySCcEc99jk/572f/gXF/wDFUfY5P+e9n/4Fxf8AxVAtDoR8RfFY1n+0vtVhuFobD7L/AGZa/ZPIMnmeX9m8vydvmfPjZ97nrzVa98aeINS8OJomoS2F1bpGkKTTadbPdJGhGxFuTH5yqAAAA+Nvy9OKx/scn/Pez/8AAuL/AOKo+xyf897P/wAC4v8A4qgNC/qPijXdWOrnUL7zv7Yv11O+/dIvnXC+bh+ANv8Ar5eFwPm6cDCWPibXdMttNgsNQeBNNvm1K02KuYrhhGC4OMniGPg5Hy9OTmj9jk/572f/AIFxf/FUfY5P+e9n/wCBcX/xVAaHWQfFjx7bajc38WtQm6uLyW/ad7C3d0mlx5jRs0ZMYfADKm1SBgir2ifFB9E+G8/hyLTrm4vZLO50+O7uJ4WjggnDB0RRB5wGHc7fOKbju25rhfscn/Pez/8AAuL/AOKo+xyf897P/wAC4v8A4qgNDfvfiD4t1DwzLoF3qUL2M0MMEwWzgSSdIivlCSVUDuV2KAWYkAYzgkVjzazqdxpWn6bJdH7Lp5ka1jRQvls7BmbIAJJIHJycADoBUH2OT/nvZ/8AgXF/8VR9jk/572f/AIFxf/FUBoaPiHxVr3iu7iudevVupYvN2MIY4seZM8z8IoBzJK7f8C9MCta2+J/jazsI7SDVYNqW4szI9hbvLJbhdogklaMvJFtAHluSuABjgVzH2OT/AJ72f/gXF/8AFUfY5P8AnvZ/+BcX/wAVQGhLY6tf6da6hb2U/lRahb/ZLpdinzIvMSXbyOPniQ5GDxjoSKnsvEet6dZWlpY3728VpejUbfy1UNHcAKBIGxnI2rxnHFU/scn/AD3s/wDwLi/+Ko+xyf8APez/APAuL/4qgLo6K9+I3i+/Nv5+o26LbpdpDHbWNvBHGLuEQ3GEjjC/OgweODlhhiTVa58b+JLvRf7KnvLdrc2K6a7LZwLLJbq8TpG8oQO4U28O3cxKhcDAJBxvscn/AD3s/wDwLi/+Ko+xyf8APez/APAuL/4qgNCWHVtQt9Au9FhuNtjeTRXE8OxTveIOIznGRgSycA4O7nOBjT03xt4k0r7KtreW7R21k2nRwXNnBcRG3adrgxvHIjLIPNYv8wJBxjoMY/2OT/nvZ/8AgXF/8VR9jk/572f/AIFxf/FUBobs/j/xZc+FpfD02oxNYTWsVlKotIRJLDE6PGjyhN7BDGm3LHaBtGASDjatql/rmv32tapP599fXEl1czbVXzJHYszYUADJJOAAKj+xyf8APez/APAuL/4qj7HJ/wA97P8A8C4v/iqA0K9FWPscn/Pez/8AAuL/AOKo+xyf897P/wAC4v8A4qgLleirH2OT/nvZ/wDgXF/8VR9jk/572f8A4Fxf/FUBcr1JL/yL8/8A18Rf+gyVIbXYN0t3Zog6sJ1fH4IST+AqjeXSzBIYQRBGSV3feYnGWPpnA46DA68kqTsh7lWiiisijrvjH/yWvWv+2H/oiOij4x/8lr1r/th/6Ijorszf/fq/+OX5s1q/G/UPg5/yWvRf+2//AKIkrka674Of8lr0X/tv/wCiJK5Gqn/uNP8Axz/KmKXwL1f6BSqzI4dGKspyCOoNJRXCZnfeHPiVq2mavBcicW0wASSaPIWcdB5q5wfrjucg5Ndymn2XiV5R4Y1RPD8szGSSztoR5bSE5B+VgQmegGQOwHSvCK0tN17VNJdWsrl02HK8/dPt6VLhG1rHbSxtSNRzlJ3e7WjfzOu8XXPifwzpt/Z65d3YmlXyUdn3LMzcblbHOFB56jgHFcboGgbduo36DIHmQwOgcNjvIpI+XpxjnPOB19j00eIvGnhWx8SSQWGozweakdrEd0sO3G6URNw0hx1UlgoGAM5rl9Qu7SeJmWF5pd2/y1R9zn6Yzn9aw5bdLHbWmq8ueVRyS25nr+f5GXbwTXUTP5ssQP3ViLKHPrtPQc+1WdRkvbbw5e28t/KkzopeyiyERNwGZM4+Y5GFAOAeSOldLpGneIRb3l1BZPpMjqqRXl7GYzHFnLOqkZBAAUYA6k5HWsjxFF4P07wzdR2us3GqavPhcudwHzgliV4zgdyapQldOS0NVKEKMpQl7zT62stV31k+i6J9dzz+iiius8AVWZTlSQfUcUrO7n5mLfU5ptFABW9Z+F7mSwW+1C5i0+GRC8KSAtNPxxsjHOD6nA96z9LmtLW8F3dxiURcpERkM3bPsOtdfp+meK/GmoLc2Ph4yRzf8vt0GWEKG2k7jhTg9QMtweDiiFGtXmqdCLb8tT0MLRoOPPVlr0Wv3u35aepzDWOpXYiS7vFxCgijWefOxASdoHOBkk49zWjLZJcbxeahdXQSJYbfezu0ag5AHBBXk4HAGa7RvD/w88ASLc+MNRGr6uu1/wCy7IZSM/IcFM84yT+8KhlJ+U1wPirx3qnieVIVhg0zToQUhsbIbEC5yN+PvEAKOw44Aya7sXlv1WH7+olP+Vatf4mnZfi/IzXJSvzas3DqrWWkjT7XzYdNDEiKV1iRycDdJ03tgDJI+gFc3qmsxl38iUTTEbQ6giOIf7OeSfftXPEknJOaK8yV5O8ncJ4q691fe729NkvuCiiimcYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAdd8Y/wDktetf9sP/AERHRR8Y/wDktetf9sP/AERHRXZm/wDv1f8Axy/NmtX436h8HP8Aktei/wDbf/0RJXI113wc/wCS16L/ANt//RElcjVT/wBxp/45/lTFL4F6v9AooorhMwooooA0tI1/WdBnM2kalcWjHr5bcN9R0NdY/wAaPiM9i1q3iKXDLtLhFD4/3gMiuBooGm0ddofxL8XaFqkl7DqAuvNOZYbtfMR+D9CvJz8pGSBnOK6qT4meCvEbg+M/AiNLtV5Lywk/eyyABefuMExngu2MKOeo8nor0cNmuJoQ9lGV4fytJr7n+hcaskrdD1f7B8Drofaf+Em1qy83959l8tj5OedmfJbOOn3m6dT1pf8AhWng/wD6Kvof/kL/AOPV5PRXR/adCf8AFw0H6c0fyY/aRe8Uesf8K08H/wDRV9D/APIX/wAepP7C+C1sfs13431OW4i+SWSCImNmHBK4hYbSc4wx47nrXlFFH9p4eP8ADw0fm5P/ANuD2kVtFfiesRfEH4baBcR3HhnwBJcTFg7SahKA0TKcqYyxlwck8jb0HXtz2v8AxZ8a69sX+0v7MiTB8vTd0O4jPJbJbv03Y4HGea4iisquc4ucfZxlyx7RSivwt+InWk1bZBRRRXlmYUUUUAFFFFABWv4VWyfxxpCajCstq15EsiMQFILAfNkEFfUdxkcZzWRRQgZ6/ommiz8UaolvBfabBFrll/ocuwrIDM+GH7sELjlQDjB6tVa18OaLa/FWx8+1k1O2v/tTfaZGQ27y7XPlhCp5U/LhiDuwcDGD5TRWnP5EcnmegaP4I0zUoVkuIdVtmku3t5YzImdNVVBDz5QZyfZPrmrt9oNpqHwr0e582a7uLKznMVrasFZ189synIOUXHIAzyOg5rzKilzLsPlfc7HT/BbpBqqarY391qVhJHH/AGVp8qeaQ4zvyFfKgY6A9e1WbTwXpdx4XTUHnvFL2c1y93vXyLaRCQIHG3JY49QeeAa4Wilddgs+56NL4O8K2ujTXU/9sSSW2n2l7JsuI1VzMQpVQYzgAnOTmq994V07R9cOgykzC81ZbeKVwPMEKAFsHHBZpFXPqhrgaka4nZIkaeQrCMRgscIM5+X05JPHc0+Zdg5X3PTLvSNOuPBkt1LpUMEQgjkWeOKONIy0EknyuF3sVdEjIdmySehIxn3fgvQF0iTyLm/hu4dNtdQkmmkRov3rAMu0ICAM5zurkr3xBq2oWjW93cRurkGRxBGskpHTe4UM/wDwImsyhyXYSiz0bWPAvhzSbywEl9qTW8t9HbSTCN9kkbD/AFiSGIICD/CGfI70uo/D3SNL0i8ubrVJhJZKILgblwlw7RmPtymyQk98qeRXnFFHMuw+V9z1+48JadZ+FJ9CDXtlZz61bxG/vHVkmXYf3keFACnOOp7c9axB4D0htV0+CWXULFrj7TmwuHQ3EnlDKFDtAG/tkfTNed0UOS7CUX3PWNa8NWl9b6RbTWmpRPZ6L5sWl71+1St5p+TOzqMkn5M47VSsfh5otzrupWC3N/O1v5XlBSURCybmWWZYpFVlPHIH9K80oo5l2Dlfc9Asvh/BdeBbrWJTLFNDZzXaSxz+bE/lk/KQIgq5A/56E98Y6att4e0/RPAmuTRQ6hcQT6bbSSX29fJm3OrMkfy8EdOSfcDv5VRRzLsNxb6npQ+H3h9NVtLWfWJlXUJHnsWDr+8tRGGXOFJ3szbRgfwtgHgVWk8GaBa6pqAuX1Zre10o35gKtBIHDhdu6WFdy/7QQfpXn1FHMuwcr7npz+GNDsNA8TWlvpl5qMyRWV1AQ6GeON1LHaRGcBTncQMEY+7jJoXHgKzj0K61aM3zWiabbXUM+5SjyyMA6528gZPA5HGa4CijmXYOV9z0ZvBPhqXxzqmg20+op/Z0RbbLMHkum+XhAkJKgZOcK5PHA5rj/Eul22jeJrjT7OW4khj2lTcwvDIMqDhldVPGeuBnr3rJopNp9ASa6hRRRUlBRRRQAUUUUAdd8Y/+S161/wBsP/REdFHxj/5LXrX/AGw/9ER0V2Zv/v1f/HL82a1fjfqc94S11/DXjfTNcVpAltOrS+WqszRH5ZFAbjJQsO3XqOtbPjzw9D4b8aT21i8cmm3KreWEkbh1eB8lcHccgEFck5O3PeuNrrfDPiHS5bOHwx4xWeXQ/N3wXMB/f6c5PzNGSDmNv40wf7wG4cmGqQqUnhqjtreLeyezT8npr0aV9LgrNcrOeoruZPhjqWoOJfBmq6b4mtCquXtp0ilhDKCPNjdgUJO4AZJ+U5weKb/wqH4if9C9/wCTcH/xdaPKcb0pSa7pNr5NXT+TF7KfY4iiu3/4VD8RP+he/wDJuD/4uj/hUPxE/wChe/8AJuD/AOLo/snHf8+J/wDgL/yF7Kf8rOIort/+FQ/ET/oXv/JuD/4uj/hUPxE/6F7/AMm4P/i6P7Jx3/Pif/gL/wAg9lP+VnEUV2//AAqH4if9C9/5Nwf/ABdH/CofiJ/0L3/k3B/8XR/ZOO/58T/8Bf8AkHsp/wArOIort/8AhUPxE/6F7/ybg/8Ai6P+FQ/ET/oXv/JuD/4uj+ycd/z4n/4C/wDIPZT/AJWcRRXb/wDCofiJ/wBC9/5Nwf8AxdH/AAqH4if9C9/5Nwf/ABdH9k47/nxP/wABf+Qeyn/KziKK7f8A4VD8RP8AoXv/ACbg/wDi6P8AhUPxE/6F7/ybg/8Ai6P7Jx3/AD4n/wCAv/IPZT/lZxFFdv8A8Kh+In/Qvf8Ak3B/8XR/wqH4if8AQvf+TcH/AMXR/ZOO/wCfE/8AwF/5B7Kf8rOIort/+FQ/ET/oXv8Aybg/+Lo/4VD8RP8AoXv/ACbg/wDi6P7Jx3/Pif8A4C/8g9lP+VnEUV2//CofiJ/0L3/k3B/8XR/wqH4if9C9/wCTcH/xdH9k47/nxP8A8Bf+Qeyn/KziKK7f/hUPxE/6F7/ybg/+Lo/4VD8RP+he/wDJuD/4uj+ycd/z4n/4C/8AIPZT/lZxFFdv/wAKh+In/Qvf+TcH/wAXR/wqH4if9C9/5Nwf/F0f2Tjv+fE//AX/AJB7Kf8AKziKK7f/AIVD8RP+he/8m4P/AIuj/hUPxE/6F7/ybg/+Lo/snHf8+J/+Av8AyD2U/wCVnEUV2/8AwqH4if8AQvf+TcH/AMXR/wAKh+In/Qvf+TcH/wAXR/ZOO/58T/8AAX/kHsp/ys4iiu3/AOFQ/ET/AKF7/wAm4P8A4uj/AIVD8RP+he/8m4P/AIuj+ycd/wA+J/8AgL/yD2U/5WcRRXb/APCofiJ/0L3/AJNwf/F0f8Kh+In/AEL3/k3B/wDF0f2Tjv8AnxP/AMBf+Qeyn/KziKK7f/hUPxE/6F7/AMm4P/i6P+FQ/ET/AKF7/wAm4P8A4uj+ycd/z4n/AOAv/IPZT/lZxFFdv/wqH4if9C9/5Nwf/F0f8Kh+In/Qvf8Ak3B/8XR/ZOO/58T/APAX/kHsp/ys4iiu3/4VD8RP+he/8m4P/i6P+FQ/ET/oXv8Aybg/+Lo/snHf8+J/+Av/ACD2U/5WcRRXb/8ACofiJ/0L3/k3B/8AF0f8Kh+In/Qvf+TcH/xdH9k47/nxP/wF/wCQeyn/ACs4iiu3/wCFQ/ET/oXv/JuD/wCLo/4VD8RP+he/8m4P/i6P7Jx3/Pif/gL/AMg9lP8AlZxFFdv/AMKh+In/AEL3/k3B/wDF0f8ACofiJ/0L3/k3B/8AF0f2Tjv+fE//AAF/5B7Kf8rOIort/wDhUPxE/wChe/8AJuD/AOLo/wCFQ/ET/oXv/JuD/wCLo/snHf8APif/AIC/8g9lP+VnEUV2/wDwqH4if9C9/wCTcH/xdH/CofiJ/wBC9/5Nwf8AxdH9k47/AJ8T/wDAX/kHsp/ys4iiu3/4VD8RP+he/wDJuD/4uj/hUPxE/wChe/8AJuD/AOLo/snHf8+J/wDgL/yD2U/5WcRXTeA/D0PiTxpBbXzxx6bbK15fySOEVIEwWydwwCSFyDkbs9q04/hjqWnuZfGeq6b4ZtArOHuZ0llmCqSfKjRiXIO0EZB+YYyeKx/E3iHS4rObwx4OWeLQ/N3z3M5/f6i4PytIQBiNf4EwP7xG48XDCPCtVsXGyX2Xo5eVt0u7fTa7KUOXWRl+LddfxL431PXGaQpczs0XmKqssQ+WNSF4yECjv06nrRWNRXmVakqs5VJvVu7+ZLd3dhRRRWYgooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD/9k=",
	"panik": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwMDAgQDAwMEBAQFBgoGBgUFBgwICQcKDgwPDg4MDQ0PERYTDxAVEQ0NExoTFRcYGRkZDxIbHRsYHRYYGRj/2wBDAQQEBAYFBgsGBgsYEA0QGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBj/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4Poorv7KyX4dR2Wr6vpyXPiOdVuLKwukPlWceSBLKOMyEghUB+TG4/NgDSpU5dFq3sjfCYR125SfLCPxS7f5t9F18km1jaR8PPGmu232jTvD100O1XWSbbArqwyChkKhhgdVz29RWj/wqD4if9C9/5Nwf/F0/TX1z4mePbLS9b12cvPv2Sum5ItsZY7YwVUZ2AHGM9Tmu7/4UB/1Nv/kh/wDbK4a+LdCSjVqKL3tyt/jdfkfTZdkMMxpurg8NUqRTtze0pw10fwuLto11fqcD/wAKg+In/Qvf+TcH/wAXR/wqD4if9C9/5Nwf/F133/CgP+pt/wDJD/7ZR/woD/qbf/JD/wC2Vj/aVP8A5+r/AMAl/meh/qdiP+gGp/4Ppf8AyBwP/CoPiJ/0L3/k3B/8XR/wqD4if9C9/wCTcH/xdd9/woD/AKm3/wAkP/tlH/CgP+pt/wDJD/7ZR/aVP/n6v/AJf5h/qdiP+gGp/wCD6X/yBwP/AAqD4if9C9/5Nwf/ABdH/CoPiJ/0L3/k3B/8XXff8KA/6m3/AMkP/tlH/CgP+pt/8kP/ALZR/aVP/n6v/AJf5h/qdiP+gGp/4Ppf/IHA/wDCoPiJ/wBC9/5Nwf8AxdH/AAqD4if9C9/5Nwf/ABdd9/woD/qbf/JD/wC2Uf8ACgP+pt/8kP8A7ZR/aVP/AJ+r/wAAl/mH+p2I/wCgGp/4Ppf/ACBwP/CoPiJ/0L3/AJNwf/F0f8Kg+In/AEL3/k3B/wDF133/AAoD/qbf/JD/AO2Uf8KA/wCpt/8AJD/7ZR/aVP8A5+r/AMAl/mH+p2I/6Aan/g+l/wDIHA/8Kg+In/Qvf+TcH/xdH/CoPiJ/0L3/AJNwf/F133/CgP8Aqbf/ACQ/+2Uf8KA/6m3/AMkP/tlH9pU/+fq/8Al/mH+p2I/6Aan/AIPpf/IHA/8ACoPiJ/0L3/k3B/8AF0f8Kg+In/Qvf+TcH/xdd9/woD/qbf8AyQ/+2Uf8KA/6m3/yQ/8AtlH9pU/+fq/8Al/mH+p2I/6Aan/g+l/8gcD/AMKg+In/AEL3/k3B/wDF0f8ACoPiJ/0L3/k3B/8AF133/CgP+pt/8kP/ALZR/wAKA/6m3/yQ/wDtlH9pU/8An6v/AACX+Yf6nYj/AKAan/g+l/8AIHA/8Kg+In/Qvf8Ak3B/8XR/wqD4if8AQvf+TcH/AMXXff8ACgP+pt/8kP8A7ZR/woD/AKm3/wAkP/tlH9pU/wDn6v8AwCX+Yf6nYj/oBqf+D6X/AMgcD/wqD4if9C9/5Nwf/F0f8Kg+In/Qvf8Ak3B/8XXff8KA/wCpt/8AJD/7ZR/woD/qbf8AyQ/+2Uf2lT/5+r/wCX+Yf6nYj/oBqf8Ag+l/8gcD/wAKg+In/Qvf+TcH/wAXR/wqD4if9C9/5Nwf/F133/CgP+pt/wDJD/7ZR/woD/qbf/JD/wC2Uf2lT/5+r/wCX+Yf6nYj/oBqf+D6X/yBwP8AwqD4if8AQvf+TcH/AMXR/wAKg+In/Qvf+TcH/wAXXff8KA/6m3/yQ/8AtlH/AAoD/qbf/JD/AO2Uf2lT/wCfq/8AAJf5h/qdiP8AoBqf+D6X/wAgcD/wqD4if9C9/wCTcH/xdH/CoPiJ/wBC9/5Nwf8Axdd9/wAKA/6m3/yQ/wDtlH/CgP8Aqbf/ACQ/+2Uf2lT/AOfq/wDAJf5h/qdiP+gGp/4Ppf8AyBwP/CoPiJ/0L3/k3B/8XR/wqD4if9C9/wCTcH/xdd9/woD/AKm3/wAkP/tlH/CgP+pt/wDJD/7ZR/aVP/n6v/AJf5h/qdiP+gGp/wCD6X/yBwP/AAqD4if9C9/5Nwf/ABdH/CoPiJ/0L3/k3B/8XXff8KA/6m3/AMkP/tlH/CgP+pt/8kP/ALZR/aVP/n6v/AJf5h/qdiP+gGp/4Ppf/IHA/wDCoPiJ/wBC9/5Nwf8AxdH/AAqD4if9C9/5Nwf/ABdd9/woD/qbf/JD/wC2Uf8ACgP+pt/8kP8A7ZR/aVP/AJ+r/wAAl/mH+p2I/wCgGp/4Ppf/ACBwP/CoPiJ/0L3/AJNwf/F0f8Kg+In/AEL3/k3B/wDF133/AAoD/qbf/JD/AO2Uf8KA/wCpt/8AJD/7ZR/aVP8A5+r/AMAl/mH+p2I/6Aan/g+l/wDIHA/8Kg+In/Qvf+TcH/xdH/CoPiJ/0L3/AJNwf/F133/CgP8Aqbf/ACQ/+2Uf8KA/6m3/AMkP/tlH9pU/+fq/8Al/mH+p2I/6Aan/AIPpf/IHA/8ACoPiJ/0L3/k3B/8AF0f8Kg+In/Qvf+TcH/xdd9/woD/qbf8AyQ/+2Uf8KA/6m3/yQ/8AtlH9pU/+fq/8Al/mH+p2I/6Aan/g+l/8gcD/AMKg+In/AEL3/k3B/wDF0f8ACoPiJ/0L3/k3B/8AF133/CgP+pt/8kP/ALZR/wAKA/6m3/yQ/wDtlH9pU/8An6v/AACX+Yf6nYj/AKAan/g+l/8AIHA/8Kg+In/Qvf8Ak3B/8XR/wqD4if8AQvf+TcH/AMXXff8ACgP+pt/8kP8A7ZR/woD/AKm3/wAkP/tlH9pU/wDn6v8AwCX+Yf6nYj/oBqf+D6X/AMgcD/wqD4if9C9/5Nwf/F0f8Kg+In/Qvf8Ak3B/8XXff8KA/wCpt/8AJD/7ZR/woD/qbf8AyQ/+2Uf2lT/5+r/wCX+Yf6nYj/oBqf8Ag+l/8gcD/wAKg+In/Qvf+TcH/wAXR/wqD4if9C9/5Nwf/F133/CgP+pt/wDJD/7ZR/woD/qbf/JD/wC2Uf2lT/5+r/wCX+Yf6nYj/oBqf+D6X/yBwP8AwqD4if8AQvf+TcH/AMXR/wAKg+In/Qvf+TcH/wAXXff8KA/6m3/yQ/8AtlH/AAoD/qbf/JD/AO2Uf2lT/wCfq/8AAJf5h/qdiP8AoBqf+D6X/wAgeYav8PPGmhW32jUfD10sO1naSHbOqKoyS5jLBRg9Wx39DXM16P4gstc+E/i6K00TxHOzzWy3DukXlo2WdAGjJZWxgkE9M8Y61XvbJfiLHe6vpGnJbeI4Fa4vbC1Q+VeR5AMsQ5xICQGQn587h82Qe2nXlyqcmnF9Vdfen+dz53F5XT9pLD0VKNaO8JNSv/hlGyb625V5NvQ4Ciiius8A6b4eaRDrvxO0bTrjZ5LT+bIskYkV1jUyFCp4IYJt/HoelQ+I9buPEfim+1u6Xa9zJuCZB2KOFXIAzhQBnHOM1r/CD/ks+jf9t/8A0RJXKVhDWvK/RL8W7/kj1qrccrppfaqTv58sYcv3c0vvJ7S8u9PvEu7C6ntbhM7JoHKOuRg4I5HBI/GtP/hMfF3/AENOtf8AgdL/APFVi0V0SpxlrJXPOpYqtSXLTm0vJtG1/wAJj4u/6GnWv/A6X/4qj/hMfF3/AENOtf8AgdL/APFVi0UvY0/5V9xp9fxX/P2X3v8AzNr/AITHxd/0NOtf+B0v/wAVR/wmPi7/AKGnWv8AwOl/+KrFoo9jT/lX3B9fxX/P2X3v/M2v+Ex8Xf8AQ061/wCB0v8A8VR/wmPi7/oada/8Dpf/AIqsWij2NP8AlX3B9fxX/P2X3v8AzNr/AITHxd/0NOtf+B0v/wAVR/wmPi7/AKGnWv8AwOl/+KrFoo9jT/lX3B9fxX/P2X3v/M2v+Ex8Xf8AQ061/wCB0v8A8VR/wmPi7/oada/8Dpf/AIqsWij2NP8AlX3B9fxX/P2X3v8AzNr/AITHxd/0NOtf+B0v/wAVR/wmPi7/AKGnWv8AwOl/+KrFoo9jT/lX3B9fxX/P2X3v/M2v+Ex8Xf8AQ061/wCB0v8A8VR/wmPi7/oada/8Dpf/AIqsWij2NP8AlX3B9fxX/P2X3v8AzNr/AITHxd/0NOtf+B0v/wAVR/wmPi7/AKGnWv8AwOl/+KrFoo9jT/lX3B9fxX/P2X3v/M2v+Ex8Xf8AQ061/wCB0v8A8VR/wmPi7/oada/8Dpf/AIqsWij2NP8AlX3B9fxX/P2X3v8AzNr/AITHxd/0NOtf+B0v/wAVR/wmPi7/AKGnWv8AwOl/+KrFoo9jT/lX3B9fxX/P2X3v/M2v+Ex8Xf8AQ061/wCB0v8A8VR/wmPi7/oada/8Dpf/AIqsWij2NP8AlX3B9fxX/P2X3v8AzNr/AITHxd/0NOtf+B0v/wAVR/wmPi7/AKGnWv8AwOl/+KrFoo9jT/lX3B9fxX/P2X3v/M2v+Ex8Xf8AQ061/wCB0v8A8VR/wmPi7/oada/8Dpf/AIqsWij2NP8AlX3B9fxX/P2X3v8AzNr/AITHxd/0NOtf+B0v/wAVR/wmPi7/AKGnWv8AwOl/+KrFoo9jT/lX3B9fxX/P2X3v/M2v+Ex8Xf8AQ061/wCB0v8A8VR/wmPi7/oada/8Dpf/AIqsWij2NP8AlX3B9fxX/P2X3v8AzNr/AITHxd/0NOtf+B0v/wAVR/wmPi7/AKGnWv8AwOl/+KrFoo9jT/lX3B9fxX/P2X3v/M2v+Ex8Xf8AQ061/wCB0v8A8VR/wmPi7/oada/8Dpf/AIqsWij2NP8AlX3B9fxX/P2X3v8AzNr/AITHxd/0NOtf+B0v/wAVR/wmPi7/AKGnWv8AwOl/+KrFoo9jT/lX3B9fxX/P2X3v/M2v+Ex8Xf8AQ061/wCB0v8A8VR/wmPi7/oada/8Dpf/AIqsWij2NP8AlX3B9fxX/P2X3v8AzNr/AITHxd/0NOtf+B0v/wAVR/wmPi7/AKGnWv8AwOl/+KrFoo9jT/lX3B9fxX/P2X3v/M2v+Ex8Xf8AQ061/wCB0v8A8VR/wmPi7/oada/8Dpf/AIqsWij2NP8AlX3B9fxX/P2X3v8AzNr/AITHxd/0NOtf+B0v/wAVR/wmPi7/AKGnWv8AwOl/+KrFoo9jT/lX3B9fxX/P2X3v/M2v+Ex8Xf8AQ061/wCB0v8A8VR/wmPi7/oada/8Dpf/AIqsWij2NP8AlX3B9fxX/P2X3v8AzNr/AITHxd/0NOtf+B0v/wAVR/wmPi7/AKGnWv8AwOl/+KrFoo9jT/lX3B9fxX/P2X3v/MtX+pajqlytxqd/dXsyrsElzK0jBck4yxPGSePerXhzW7jw54psdbtV3PbSbimQN6nhlyQcZUkZxxnNZdFU4RceRrQyhiKsKqrxk+dNNPrdbM2viHpEOhfE7WdOt9nkrP5saxxiNUWRRIECjgBQ+38Og6UVo/F//ks+s/8AbD/0RHRXNhZOVGDe9l+R3ZzTjSzDEU4KyU5Jeikw+EH/ACWfRv8Atv8A+iJK5Sur+EH/ACWfRv8Atv8A+iJK5SnT/jz9I/nIuv8A8iyj/wBfKn/pNIKKKK6jyAooooAKKKKACitTRPDmueI7w2uiabPeOv3ygwicEjc5wq52nGSM4wK7iD4N39rbx3XijxJpOiW0igBnfewkIz5ZyVXON3Rj04yOa56uKpUnyzlr26/duepgslx2Nj7ShSbj32j/AOBOy/E8zor1M+Fvg9af6Ne+MdVe5jG2V4YjsZh1K4hb5T1HJ47nrS/2p8FMZ/4Q/Wf+/rf/AB+svrl/hpyfyt+djt/1ecdKuJpRf+O//pKlb5/I8ror1P8AtX4J/wDQn6z/AN/W/wDj9J/YvwUuT9p/4SPWrPzfn+zbGPk552Z8ps46fePTqetP641vTkvlf8mw/wBX1L4MVRf/AG/b/wBKUfwPLaK9PPwcOof8iv4y0XV9n+vy2zys/d+4ZOuG646d+3Fa74R8SeGdh1vSZ7VHxtlyHjJOcLvUld3yk7c5wM4q6WLo1Xyxlr22f3M5MZkWPwcPaVqT5e6tKP3xuvxMWipXt5o7eKeSMrHLnYx/iwcHH41FXSeU01uFFFFAgooooAKns7S41DUbewtI/MuLiRYYkyBuZjgDJ4HJHWoK3/Bv/I0N/wBeF7/6SS1M3yxbRvhqSq1oU5bNpfey9Db6Bp0fkjTItXlHElxdSypGT/0yRCjKvJGXJJwDhMlak8/RP+hR0n/v9d//AB+qVevfDfwX4e17wNY3uo6NaXk9xrb2U8015JDIkAgD/ukWRQ7g8gBWJyeO47sNl6ry5IvX1f6HlZvxJHKqH1irFct7WUYPo39r06tt+bPLvP0T/oUdJ/7/AF3/APH6PP0T/oUdJ/7/AF3/APH69X8BeCPCOq6TZ3OqaVLdBtdvLR/Mlkid4I7NpVQhWG07gD2PbpxVDxF8OtOi8O6B/wAI/H582t6s0dndl2PmWzqhjDLnAK7mDcA5U1v/AGPL2ftFt6u/T/M8xcd4f619UlGz7uELfavr5cje17fO3m/n6J/0KOk/9/rv/wCP0efon/Qo6T/3+u//AI/Xf/E3wl4d0vSbTWPCcUC2cVzJp115N8t2HdeY5SVdthdQ3ynGNvQVz8PgjzfhDceOv7atV8m7Fr9gI+dskDOc9ec7cdATmsqmWOE3Deyvu9vvO7C8WUcRh6eJ0ipy5UnCN+ZuyTsna/raxgefon/Qo6T/AN/rv/4/R5+if9CjpP8A3+u//j9dR4W0TSZPh94g8U3unf2tcadJBFHYmR0jUOTmWTYQxAxgYI561u+F9I8Da/pupXmr6DcaTLog/tG4treWVheWxX/VfO2UO8rhh/C3cjdVU8sU+XW19d35/LoyMVxasP7RunzKm1FtQpvVpNK3xP4oq9rXe9rs868/RP8AoUdJ/wC/13/8fo8/RP8AoUdJ/wC/13/8fr2HQ/BngzW/CGhzNotnDf6xaajPHDHcXXns8Tv5axEsYgqqAD5nJwOpzXM3ui+GtP8Agx4f1Y2mjJqeo292ZJL570zSMkpRTCIj5QIGPv4GcZzzVyyjljzOSta+78vx1Ry0uOIVansY0nzc/Jb2dPf39f8AD+7lr5etuE8/RP8AoUdJ/wC/13/8fo8/RP8AoUdJ/wC/13/8fr1nXPA3hq2+G8moxaLDDJH4fstQW6t7qSS4a5kID74i7BYyOd2xQOcHsKVx4Q8Ox/B3/hMl8PyjUXsEX+zPtD7YsyFPt+N+/YccKflyehWnLJ3FtN7K+8tiaXHdCpGMlDeagvcp/E0mvlr8uttL+Z+fon/Qo6T/AN/rv/4/Ub6VpmuSJa6bpy6dqMhCQJDK7QTNnhCJCzKzE4D7tvCgqAS4rUVwPDxtpe/q/wDM+pWOk3acU1192K/FK6Obrf0TRLaex/tbVjN9h8xoI4rdwkk8ihSwDFWCKodSSQc7gAPvMkXjH/kouv8A/YSuP/RrVvyf8ij4a/68JP8A0ruK5HUbgpLqcGaqWHn7GL+0439E/uvb/LXUPM0D/oTtI/7/AN3/APH6PM0D/oTtI/7/AN3/APH6qV7D8KvhRovjDwvPrmt3d1tMzQRQ2zhduAMsxIPPPA9u+ax55dz57HYmjgaXtq05W/xS/wAzynzNA/6E7SP+/wDd/wDx+jzNA/6E7SP+/wDd/wDx+urvvBFppvxwj8E3Ook2jXcUX2jgNscKwHoGwwH1q9qnh/RLjwt4kvotDbRZtG1CK1h/eyN9qV3ZSjByfnUANlcDB6Uc8u5DxlH3LSk1JJp80tpOy+1ff7upw3maB/0J2kf9/wC7/wDj9HmaB/0J2kf9/wC7/wDj9ew+Jvh54StT4ov9IsiLbTrXyvIadybW5DId3LZZWR8jORkN6CsYeEPDv/DSlz4V/s7/AIlCCQrbedJxi1Lj5t2773PX9KOeXc5qWa4erBzi56RcvieySb+1v7y/zPN/M0D/AKE7SP8Av/d//H6PM0D/AKE7SP8Av/d//H69X8K+AvC+u+GfCDtaH+07p5Li7QzOBd26TmNwPm+VlBQ/LjIDVk2uheGbT4d3msXdnpAuU1yaxSTVJLwp5Sxhgii3Od2c8t789KOeXcpZnRcnBc7advil3a/m8n/Vzz7zNA/6E7SP+/8Ad/8Ax+jzNA/6E7SP+/8Ad/8Ax+qlFHPLuet7L+9L/wACl/mWy3h6RTG/hLT41bgvBcXKyKPVS0rKG9CVYZ6g9K57XdGTThBfWTvJp90zrCZCPMjddpeN8YyV3p8wGGDA8Hcq61S6j/yTS/8A+wnaf+irmrpzd7MunKVGUWm2m0mm293bq3a2/wCBxlFFFdJ7R1fxf/5LPrP/AGw/9ER0UfF//ks+s/8AbD/0RHRXHhP4FP0X5HsZ9/yM8T/18n/6Uw+EH/JZ9G/7b/8AoiSuUrq/hB/yWfRv+2//AKIkrlKqn/Hn6R/OQq//ACLKP/Xyp/6TSCiiiuo8gKKK67wN4GuPFl7JdXU32HRLT5ru+chQABkqpPG7HJJ4UcnsDnVqxpRc5uyR1YPB1sZWjQoRvJ/1d9kur6GDouhat4i1Uado1k93clS+xSFCqOpLEgAdBknqQOpFenReE/h/4B2T+MNS/trVk2t/Z1sMoh+Q4K5GcZJ/eFQyn7pNUNW8fWejaFF4Z+HizWFjHuE99IoE1yxypYHqMjB3cN90AIFwfPK5vZ1sTrNuEey3fq+novvPcVfA5V7tGKr1v5nrCP8AhX2n/eemmiO+1n4s+Ib2IWeiRw6HYJH5SQWqgsF2gY3kfLjBxsC4z3wDXJW6aj4i8QxRTXUtxd3LhGnuJC56YyzHnAA/ACs6vRdJ8J6sbzTNB8Mac+p+I9R/dCK3be/mMT8nYIECksTwMEk4FdMKFKhH93FL+u55mJzLFZhUUsXUcl26L0Wy+SRzXjR7N/G941hhrUFUjI43KqhQfxCivXPhto0d1Yxf8Jd+zumpeHpRtbVraS7s7lQR9+NpJtkvrgAZ7EV7B4O+Bfhj4aRW+teIN/ifxfKm+K0tMeRbbepjLDO1f4p2wP7o9ehkv9c8ValLpH9nG1v2jR2jju5HxE+dvmmTswUkZwcAHGCKqL0SMK79rVlVSsm72Plfxj8ILwfEa+s/h9BPqWhNtltZ7iREZVYZ2EsRkj1x0xnBrH1H4MfEvTLQ3U/hW7khAyWt2WbH4KSf0r6+8N+F7nw+zXuqaLOLDcVlvLOXfLbkHB82MgnaMD7vQc4Ir0WXQ9Tjthc6eE1e1ZQwtwUSVlPOYnGEc46BsZ/vVXPYydNH5jEXmnX4JE9rdQOGHWN42ByD6gg16N4G8a+O21K3ge4N9pisFml1BSVjUtkkzAbt2MgAluuAp4rsPiz4m0PX/idcMdLiSz0l3gBuLbyLiZ1+8ZNw3JggjaRkDnAJ48ym8Sy6grJNemxsVbhUBd29di5wOB1P51hXp060eWUUz08pxdbBVlOnVcF5O1/Xp951mp6H4K8aa9LpiavHod5AFgsIUjVImUsM/JgKzMzNhVYHJJwQK8x8S+FNc8J6itprNp5XmbjDMjbo5gDjKkfgcHBAIyBmob66+2X8k4QRqThUBztUcAfliuy8M/EI2ulP4c8W276voEkPkiHaDJCByu0kjIzjGTlcKVI24OLpVqHvQfMu3X5P9H9531cXl+aVHCvH2U9eWavyvspx6duaO3VNI85oruPGfgKLRtLt/Enhq7fVPD1wq4uDgvCx4w+AOCeM4GD8pAON3D10Uq0aseaB4WOwNbA1XRrqz3XVNPZp7NPowooorU4wrS0DUYtK8QQXdwjtbkPDOIxl/KkQxvtyQN212xnjOM8Vm0UpLmTTLpVHTmpx3Tv9x1t1Yz2scUzASW02TBdRgmKcDqUJAzjIyOCp4IBBFOh1XU7e0itYNSu4oIZxdRxJMyqkoGBIoBwHwB8w5rndP1jV9J8z+ytVvbHzceZ9lnaLfjOM7SM4yfzNXf8AhMfF3/Q061/4HS//ABVWq9WOyX32/RlzoYSrrNteXKpW+bkvy8tdzeTxL4ijdnj1/VEZpnuCy3UgJlddrP1+8VJBPUg4plvr+vWkVpFa63qMEdmzPbJFcuogZs7igB+UnJyR1yaxP+Ex8Xf9DTrX/gdL/wDFUf8ACY+Lv+hp1r/wOl/+Kqvrdbt+L/yMf7Oy+1tf/AI+f97zf3s0kvr2PT5bCO8uFtZmDywLIQkjDoWXOCRk4JqvVX/hMfF3/Q061/4HS/8AxVH/AAmPi7/oada/8Dpf/iql16j+yvv/AOAbLD4SN7Tlr/dX/wAmamn6nqWk3f2rS9QurGfGPNtpWibHplSDT21nV2nu5m1W9Ml4uy6czsTOvo5z8w4HBz0rI/4THxd/0NOtf+B0v/xVH/CY+Lv+hp1r/wADpf8A4qmsTVStb8X/AJESwWBlLnbd+/Iv/kjfh8T+JLbRxpNv4h1WGwClRaR3cixYJJI2A4wSTnjuaIPE/iW20c6RbeIdVh08o0ZtI7uRYtrZ3LsBxg5ORjnJrA/4THxd/wBDTrX/AIHS/wDxVH/CY+Lv+hp1r/wOl/8Aiqr63X7fi/8AIzeW5c736u/wR37/ABb+ZtDXdcEnmDWdQD/ZvsW77Q+fI6eV1+5/s9Pag69rhunuTrOoGZ4Psrym4fc0OMeWTnJTHG3pWL/wmPi7/oada/8AA6X/AOKo/wCEx8Xf9DTrX/gdL/8AFUvrVbt+L/yK+oYDu/8AwCP/AMkWqu2dmnlDUtSEsOlRSBZrhRjdjBMcZIw0hB4X8ThQSMj/AITHxd/0NOtf+B0v/wAVWff6lqOqXK3Gp391ezKuwSXMrSMFyTjLE8ZJ496h1aklayXzv+iOhRw1N8ybk10aSXz956eXXug1K/m1TWrzU7hUWa6ned1jBChmYsQMk8ZNdVosra7oFlpdqjS6nYB4kto1JaeAuZAUHJZ1Z5NwH8OwgEK5HF0Vm4Jx5TgxlJ4n3pP3r3v56/5s66uh8N+OfFPhGKeLQNVe2inO54yiyKWxjcAwIB9x6Vxn/Ca+Mv8Aobdd/wDA+X/4qj/hNfGX/Q267/4Hy/8AxVZexfc8urgataPJUhFrs23/AO2m1e315qOpTahfXMk91M5kkmc5ZmPepr7WtZ1OKKPUtWvrxIv9WtxO8gT6Ak4rn/8AhNfGX/Q267/4Hy//ABVH/Ca+Mv8Aobdd/wDA+X/4qj2L7lfU62nuR021en/kp0T67rcjXbSaxqDNe4F0WuHJuMdPM5+bHbOatS+MPF0xQzeKdakMbFkL30p2kqVJGW4OGYfQkd65P/hNfGX/AENuu/8AgfL/APFUf8Jr4y/6G3Xf/A+X/wCKo9i+5DwFR704/f8A/anQQa1rFq9o1tq19C1mGFsY53UwBs7tmD8ucnOOuansvE3iTTYXi07xDqtnHI5ldLe7kjDOerEAjJOBz7VzH/Ca+Mv+ht13/wAD5f8A4qj/AITXxl/0Nuu/+B8v/wAVR7F9xywNWW8I/f8A/amkSSck5NFZv/Ca+Mv+ht13/wAD5f8A4qj/AITXxl/0Nuu/+B8v/wAVR7F9zT6viO0fvf8A8iasUUs86QQRvLLIwRI0UszEnAAA6k1F4juksNCHh7IN49ytzeJ18gorLHHns/7yUuOcfIOGDqMyfxd4rubaS2ufE+szQyqUkjkvZWV1IwQQWwQR2rGq4UuV3ZpSwk3JSq2stbLXXzdlt2tvbXoFFFFanpHV/F//AJLPrP8A2w/9ER0UfF//AJLPrP8A2w/9ER0Vx4T+BT9F+R7Gff8AIzxP/Xyf/pTD4Qf8ln0b/tv/AOiJK5Sur+EH/JZ9G/7b/wDoiSuUqqf8efpH85Cr/wDIso/9fKn/AKTSCiitDQtFvvEXiG10bTlQ3NwxVfMbaqgAksT6AAnjJ44BPFdMpKKcnsjy6VKdWap01eTdku7eyN7wN4GuPFl7JdXU32HRLT5ru+chQABkqpPG7HJJ4UcnsDq+NPGlvqFlF4X8Lw/YfDlphUjQFTckHO5s87c8gHkn5m5wFuePtW0vRtNX4eeGYPKsbOQPeXAky1zNjkMVODg4zn+JQAFCDPnlcdCm68lXqbfZXbzfn+R9Fj8RDLKUsuwr956VJrq+sFtaK6/zPyCiiprW0ur68jtLK3luLiVgkcMSF3cnoAByTXonzRHGcTKeOCDz0r9Kv2cfgufCPw1n8c6tEJ/EXiR3kSQrt+yWLsXRFB5Uyja7d8FVP3Tn5j+DX7Pc6eKdP8R/Fu0Gl6ZG/nW+gXRC3eolcN88X3ooB1dmALD5VHzZH3J4w8bzab8NbyS0mH2i5aPTrXaMbZp5BCGGPTezf8BrCq77G9GEpNRXUfa6Bpst0zIizS3iedNL13xqwVR/uZPA6dT3NeXfBDb4j1z4g65cJm7l18kluSI/K2oPoACK9C8LeM9Kb4u+KtPtzFJa6bbabpdvGTwgXzifx3bR+ArznwL4mt/AX7UuueCb2zt4bLVoy9jKVIWc5aSIn1O1pEyP4kxWMm00enhIRnRrRXxJJr0TV/w1+R68thDFq8VrsxJcKzoR/EUC5H1wQfoKxLjV9F8F6ve6bqTPBYR273axpEXeJlUyNGiDqroGdMcZSReMcYfxP+JEuk6roWoaRAss+n607XEKAlmgNmTLtH+64OP9muI+NvjODX/h5a+JtCv1XWNMuEE/l3ARzE2CoEhBATcY5AxGNpbkZNEpWTZlhMN7acYy0Tdr/wBX/pnl/wC1Dpvhf4g3EnivwRZm3vLOwtrq+mkkSM6pC+1CRF97z4SwDDksqt12DPIWnwavL79nOKWXTV8+7Bu7S6GA4nx8invsdQI/TcQe1dZfeIvDU/w60Ww0/R2j1iGQC61C5kKxvFLmRCu042ZZtu4EhRkE78j1Pwjc2Vn8OIPDiX8eooiFYLiJdqTY6xYP3JVxgoTkkblzk4jCVpN+9/XkehnGXUcKoum3q2rPsvtad9+m+1tT87mBViCCCOxpK9R+NHw/m8NeMbnX9Kie48PajM0sNyikrDIxy0L/AN0g5wDjI9wceXV6B821Y6vwV41n8LXclpdw/btFu8rd2TgMCCMFlB43Y4IPDDg9iJfHPgaDS7SPxR4Xl+2+G7vDI6EsbYk42tnnbngE8g/K3OC3H12ngHxLY6fPceGvEFsl1oeqsscyyvtWB84EnJAA6ZPBG1SD8uDwYijKnL29Lfqu6/zXT7j6HLsZTxdJZbjX7uvJJ/Yk/v8Ack/iXTdWPP6K6Hxr4WuPCPi640qX5oD++tZC4YvCWIUnAHzcEHgcg44wTz1dFOcakVOOzPExOGqYarKhVVpRdmgoooqzAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA6v4v/8AJZ9Z/wC2H/oiOij4v/8AJZ9Z/wC2H/oiOiuPCfwKfovyPYz7/kZ4n/r5P/0ph8IP+Sz6N/23/wDRElcpXV/CD/ks+jf9t/8A0RJXKVVP+PP0j+chV/8AkWUf+vlT/wBJpBXr3hOL/hAfg9e+MJ49mrariCw3J8yKc7TyhxnDSYOVYInc15r4c0S48R+KbHRLVtr3Mm0vgHYo5ZsEjOFBOM84xXbfFnWY73xkmiWawpYaRGLeGODbsDEAvjA+XGFTbzjZ2yRWeJXtqkcP03founzZ3ZK/qOGrZo/iXuU/8ck7v/t2Ovq0cDRRRXpHzQUoJDAg4PbFJRQB9LfB1bXwl4c0WW5Q3Gv+KWl1BzJybfTLQOy5J5HmTRE477EPava/iX4l/snwp4acS5jttetjMPeKORz+q5r5t8A60+s/ELU9ai3tZaT4VjsIcjiMLDFDt+pPmn6kmvSfidrH9oeHNVithFM1lrlvqKRSPtWSJ3EbAkchcsckdAwNYVHZXPTwFNTl6f52/U7Iwap4W8F6d42gn8x9WSRtRRR89vciQXEKyDqpKhlAPUdM5pPHt5pfxB8L2up+dJaalp8iXFlqFu2JIkdlOQe4GQceq571w3jX4nfFKPwtpkvjbw94cZJ7GKa3Omedb3v2YySJsm3KYpVieIKwbaVcqV5JNd/4B+HHiXxn8KbTxNo6WM1lcxSRrbNP5ckgBKnAIxG4IIKE4JGQRuxXHCryRtUO+dCd1XiuXoum2n5K33ml8ELLxD4y+MF5qfilra8h08STyyRLiOV2jSBDtP3S2xzj244rnfih8OtVsJb7xF8MoptW8O4e3leNd0KqSd0Sn/lqisTh14UkqCeQt/xdZ/E3w18M47Cx0CPQ9Mlmjj1Yi2mK7FEcAnunRi8kRyoEUWM5bdwCT5lp/h347+MNUi/4Szxj4l0uG1guJ7OztplsoY3hTFssduq4KtL5SLweGHI61ipSlPnTOqhQrcrnCN4R32/q/kd58PItHsvhJ4X1S50yGTVLiS0064a5BcusVy0aDY2QCuFOQM5Aplnp+jHx/wCJ9Pm0yyubadlvoWfKnEozztI3JvDA5zg4Nc1pOqXD+MPCng6XUpb+XT5W1DUb133+ayO0rOT6ZK/99CuL1rxfd6Z8TrK/tpgfInuNPlRvuyRFlkUH2Al/Su+i9LnNjcNJzjG95NN/LovuR2fjQarPoFxrHgW5W3eNWhvNDngWaG429UeJgRu4OD/FgdyK+VdQvTqGoyXbW1tblzny7aIRRr9FHAr6Du/Es1l4y0rWLdzHBqN19lmjJ4L8Oh+obj6H2rxHxxb2lp8StftrHb9mj1CdYwvRRvPA+nT8K7LaHhVVYwKKKKkxPVLWL/hYXwNk09Y/M1rw/gwbUy0kQB2qMJ3QFQo5LRoSea8frtPh7r7eHfH9ldM6JbzsLW4LsEURuQNxYjgKQrdvu4yATVb4jeHm8N/EO+tVjRLa4Y3dsI1CKI3JO0KCcBSGXt93OACK82ivYV5Uej95fqv1+Z9LmL/tDL6WO+3D93Pz09yXzV4t915o5StDQraG88U6bZ3Kb4ZrqKORckblLgEZHPQ1n1peHZYoPGGlTTSJHGl5Czu5wqgOCSSegruPmj7n+I3w2/Zj8C/tO+Evg1cfBK6nHiWC3ZNZtvEd6HtXmnkgUeSzkMA0YJbdwGPBxz4V8Qf2bbDQ/wBprxJ8OdJ+I3hLw/pthbxX1reeMdUFiJI5VUiIOEIaRSx7DIGeOle5ftL/ALUdl4P+OOkXnwx0z4X+LZk0ZHTxK9smpXdnKZp1MMdxFKAgC4bZ/wBNCejV5r+z54s+HHj/AOI3j7xd8dtR8Mah41vrdJdFn8XkJpjSBXUq44QKCIBjGQgO3vWSulct22PKviT+z541+Gvgqx8Z3GqeG/Enhm8m+zx614a1D7ZbCTnCltqnnawzgjIxnOBXZN+xn8To73w9DdeJPA9pFr9ss9lcXeqPAjyOAUtwHiDPMwbO2NW6ckZGfY/i94+8Bal+wFrfhay8QfC6PX4tWhB0nwSq2ls5W4jLPBA7eZINucy7QGwccDJw/j7478Iax8S/2eZtH8ZaJf2ukLaNfyWmoRSpYsJbYsZSrERkBDndj7p9Kak2KyOE+Bfwp8R+Fv20Z/hz4r8B+F/EeqWNnOZNL8QXGLGVTGrrKr+RPn5WDL+7787Tmuw+HfgnwzqX7OX7ROoal4K8Pyaxpl/dR2DpZxztYMA+EtpDGGVQeBtC9BwOld7F8RPh8P8AgqnN4t/4Tnw0NAOgeT/a/wDacH2QyeQBs87ds3Z4xnNZHwK+MPhL4c+Cvjl4hk1/w5PqH9vzahpmmXeoRRtqaqzsPJG7Lg8YZQeSDzSbbGfMfxB+Bfiv4XeBNF8QeNdW0HTr/V0Etv4cM8ramkZ/jkjEexB06vnJxjIIHHeCNATxX8S/D/hqU3Yh1LUYLSVrSEzSpG8gV2RACWIUk4x2r3f9p2y8B/EBrf47eAfiBYXx1pI/7T8M6lqcf9padKAE+SFn3mMEYKqCF+8uUPy89+yR8Q/B3wz/AGk7TxB43ZYNOmsprKO+aMuLKV9uJSACQMKyEgcBznjNXd2uTbU9F/aT+GPwj+Et8vgfTfg/4lhvL6zVtF8V2+syXAvbngGN7dgU4YgMFw3zAgYIz8r654f17wxrUmj+JNE1HRtRjCs9nqNs9vMgYZBKOAQCCCOOa/RPwD4m+HuiWNz4W+NPxx+HPj3Qf7cj1Tw1dNqRuL21m84yKbggYiUMQcltoBdWOw4Hxd+0bqt/r37TfivW77W9D1kXl15lteaJfR3ls1uFCQhXQkZEaqCDggg8c1MH0G0dr+zxP8EfF3irwp8MfGPwS/tjWdRunt5/En/CSXdvuDM7qfs0eFG1dqcMM4z1Ndl8UfAHw2v/AI3+IP2fvhF+z4w8WQmJbXxF/wAJPdulupSKZ5XglygUKxT5mPUEckCvF/2cNW0vQ/2qfBOra3qVnpun22oB57u8mWGKJdjDLOxAUc9Sa+ktA+N/w98Ef8FOfHHirU9dsbnw1rlnHp0Wt2MguYIm8q2YNvj3ApuiKEjODjOADRK6egLY8I8ZfsufELwj4H1TxXa6z4S8U2Gjvs1ZfDep/bJdNI6+chVSuO4GSBkngE1Npf7Knj7Uvhh4d+IL+I/Bmm+H9bTzRe6pqbWkdinODcO8YVckYAQuST0wCR9A+J/iNH4L+HnjWHRfFv7Mtppur6dcQfZ/CGnTtf6mDHIscckcUoVHO9hlywQsTyM58z+MvjDw1qf/AAT3+EfhfS/FGk3mqWU4e90u2vY5J7fEcoBliViyfexyB196FJhZHTeHvgzpGv8A/BPbU4NM03wbceJbfxLLaN4rcwRxJBFcKry/bXAIg2gkHPIIwMkCvDPH/wCzr4/+HWueGbTVp9E1Cw8SyxwaZrWlXRuLKV3KgDftDDhg2dvIyVzg17X4D1XwHrv/AATRu/htq3xK8OeHNbv9azFDf3i7kP2iN1M0S5kWI7eXCkLwx4Bo+L/xD8B+CP2fvhH8JNG8X6Z4z1Lw1q9vrOo6ho0wnt41jMhMaSDgkmYgDOQIxkLkChN3CyPHdT/Zq8daV+0rpnwQuNW8PN4h1GHz4rqOeY2ir5byYZjEHBxG3RDyRUnhP9mTx/4z+KvjL4f6PqXh8ar4T3/bWlmmEU5ViuISsRZiSONyrX1Zq2sfCHWP27fB/wAck+NXg0aO9ibeOxN4FuEmFvMoM27CwR7XzmQqdwCBSTXMfCH4heCNI/a5+PWu3njfw/Y2Wox3B02+m1KGOK7bzWK+S5YBz0I2k0uZ2CyPAtF/Zc8Za/8AEXSvA2m+MvAU+u31pcXc1rb6ubk6d5JQNFc+TG/lyEycAbgdrc8Vh+CPgF4x8et48Gj6locP/CExvLqP2uaVfOC+bnydsbbj+4f723qPfHR/sh+PfDXw8/ag07WfFuox6dplzaT2T3s3EcLuoKlz2UlQM9BnJwMmvoD4cH4YfDW1+PMc/wAZvBWrXviOynnsUs9RQRmNlujGgdyFkmJkwUj3bcLk/MBTbaBJHwRRRRWhIUUUUAFFFFABRRRQAUUUUAdX8X/+Sz6z/wBsP/REdFHxf/5LPrP/AGw/9ER0Vx4T+BT9F+R7Gff8jPE/9fJ/+lMPhB/yWfRv+2//AKIkrlK6v4Qf8ln0b/tv/wCiJK5Sqp/x5+kfzkKv/wAiyj/18qf+k0j0z4NwRWura34ouoklttJsGcqFDSBmy2UzxnbHIM5H3sdCa4W7u7i/1Ce+u5PMnnkaWR8AbmY5JwOBye1egeGP9H/Zr8T3dv8AuriS9WF5o/ldkzCNhI5K4dxjp8zeprzmlhVzVqtTzS+5f8E682bo4HB4ZbOLm/Nyk1+CikFFFFd586FFFFAHunwmjtrP4O3l4XAn1fxJa6MW/ujyXkUf8CJYfhV7xPpmp23h3+3C/nWlxbNFJH/ejOYyp9wqrz32joRmvFNO8Q6xY6Fc6FZTuLe6uoLvYudyzxbhG646MBI4/H2FfQPhDxdZ+M7CDw5r0ltbX2oQTWvlr8qrepI0iIBnjzY55QB/fi2jqBWU1dWZ34PEeynGS6fl1Po7wBaHx34E8ManrujatayQWUZH2llCTl413zIQDuSUBXK5+9yQDyfbNM0+DRtNs7K1MNtYwrsUSyfMWJz1PUkkknqSa+Nvg/8AtNWXwzgf4cfEfT7iSx0p/Ks9RtFDTW8JOQjxnG+NSThlO5RwQRjH0zpnxe+D3jVIYrHxl4dupgA6W966QzKGHaOcA8j0HSvArU5qTvse/XrycVTWyv6ep3OqQw6poc9sBHc21wjRSIfmSReVZSO46g15H408M+IbTw5cHwnpWlw6hJG0P9oyosYsYipDyDALMwUnAGBnknsep1b4s/CzwNpUVne+LtFtI4h5cNlbTieXGeESKPcx64AAr59+Pv7RmvJpVn4b8MaFNpdrrEche+v8C48pcBv3Q/1eQeNxJ9gazpwlKSSNMG6kFZLRnkPhKUaF4S1S/abzdT1e4/s+zlIw3lA9vQcgn3xXm2q3wvfHlwQ2YXvXaMg/fC4XP5KKsR6tf3V9HMkwiS2gZbUBSREWBCvjgYGWbrljtPSuXgtkWS7kluZnltYWlinGF2lSAAeuQScY9692nqlEwxNaFPETq3v8/v8Aw+V7m5418WrNr2nW2juDFpMhmEn8MlwSCzD1C7VUeu0nvXDyyyTzvNM7PI7FmZjksSckmtLR9Tms9eE4SKRJiY5oZEDJIjdVKkHjv6jGRUusaXbLCNQ0nL2v3ZkDbvJfPTnnaeME/Q9q6nJuVmfNTScee+t9v1MWiiimYhXpHxJkbxD8M/CvjAhDKVazupXQLLLJ6/KMbd0UpAyMbxgcnHm9ej2P+k/sva39p/ffZdRX7P5nzeTloc7M/d++/T+83qa4MauWVOot1K336H0WRN1aOLwr+GVNy+cLST/Br5nllFFSW9vPd3cVrawSTzzOI44olLM7E4CqBySScACus+dI6KujSNWL3qDS70tYZN2BA2bbDbT5nHyYPHOOeKpUAFFFWbrT7uztbK4uYtkV7Cbi3bcDvQSPGTwePnjcYODxnoRQBWoroW8CeNIrqzt7nwrq9o17cR2lu13avbpJK5wiB3AUEn1Nc9RYAooooAKKKla2uFs0u2glFvI7RpMVOxmUKWUHoSA6kjtuHqKAIqKK07rw54hsdHh1a90HU7bT5wrRXc1q6RSBhlSrkYORyMHmgDMoq4+k6ol9bWT6beLc3So1vA0LB5g/3Ci4ywbIxjr2pU0fVpbmS3j0u9eaO4W0eNYGLLMxIWMjGQ5KsAvU7T6UAUqKuR6Rqs01vDDpl5JJcqzwIkLEyqpYMVGPmAKsCR02n0NU6ACiiigAooooAKKKKACiiigAooooAKKKKACiiigDq/i//wAln1n/ALYf+iI6KPi//wAln1n/ALYf+iI6K48J/Ap+i/I9jPv+Rnif+vk//SmHwg/5LPo3/bf/ANESVyldX8IP+Sz6N/23/wDRElcpVU/48/SP5yFX/wCRZR/6+VP/AEmkep6r/wAmu+G/+wi//oVxXnFej6r/AMmu+G/+wi//AKFcV5xRgPhn/il+Z1cR/wATD/8AXml/6SgoooruPngoorQ0Sxk1LXLe0ijEju4Cxn+I9h9Cf0zSbSV2VCEpyUIq7ZtaJpdxEg+zIRfSruaX/n2jI7ejsO/8IPqeKUthI81z5IYR2uMeWSOQ3bvngn8q9WsP+EasZF0KPVbefUMkyqmXaWT+LoME+3aua0SfRNLgkg163uHlknaTy0ZQr5JxufeMAADgcnJ5Xv56ryqSdkfZ1sqw2CoQjUmm3fmtrZ2ty6eb/A4+9bxN8RNTiudeFvI+nqsM+sy/u2nj6qsm0fvJCM4IG48luATWrcJZ601wlzDDa3EHEEUmPlXAVIyO4wAAR6Z5yRVvXdYhitXS1gjtkhTZb28eSqBuuPUk/MT3P0pLuxa7sLW3dirOxLOpwQI0HPv88g/Krk7I8WhTV3bWy18+y++3n1PXNN0Pwx8IPhfpHi22W1vta120We2nn8tmjxlZGUDlEVjswcEsuM9ceWavrFzrni10meXVdQkPOwGYH6KvLfThR7VBHo11f3dpFdXtzLbwyJGqNIWVAXzgf3QSWP1J9c10/g7Wl8MeGtX1LTJBb6rqCPMZlhO4RlmAAl6KQ2Tt/i+UDJrOlSSk3J3Z14jFVPq6UFyxvb17/p6/dblJJtVu3a0i0sDD7Ge7ZcFun3R6HisnT1ki1W7tNUtY4FeOSK4jA+VRtJ3j/dIDD/69dPBOjpIoG4iQwoM8ttAySfzyaz/Een3lwr3E/koZEBBDBWbZjdkZ3YK5PTqoraEuWa7GDwqqYaUopuaa9LPv2OMs1b7SHX7w4X/ePA/Lr+FbmnrcRLI1tGJGRdk0bDImTlSG+uM59TWv4c8OqZftUoD7flUY+XPfFa+gaUy+LtUswM7AGx6BsEfzNRVxCTbXQ9HAZBJKmqy+Ntfg3+aPONStUtrvMBLQSDfGT1x6H3ByD9Kp16B428LtpsXnxp+5mYumB9yQDLD6Moz9Vrz+uqjVVSPMj53MsBUwGIlQqbr8ugV6T8OP+SdePv8AsG/+0p682r0n4cf8k68ff9g3/wBpT1zZj/AfrH/0pHp8Lf8AIyh/hqf+m5HlVb3gi4gtPid4curqeOCCHVLaSSWVgqoolUlmJ4AAGSTWDRXUfPHqdp4x0S+0jV7aUyW1xfWDNqksjKoupYzHHGIucsxXzHOeSztxgZqbUf8AhD/7Wtv7W/4Rr+z/AO3IvsP9l7M/2fh9/wBo8r58f6j/AFn7z79eTUVXMTynqJ/sT+1NJ/tj/hFP7a2X3/Hn5H2H/VL9k87yv3WfM8zr22b+M1g/EG4jn/4RuIT6TJcQaSY7ldKaMwxy/a7hioEfyg4YEhePmyOCK4yii47HtGsz6evx103XltfCNtp//CTQXB1ay1pZppY/Pzvkj+0uEXHzE+WuMDoODzdmdDHjDSZdLstGutH+zSCGG7uLWCaN9mGa4NwdjSKxDANlGAwoHIHndFHMLlPW4bK2WDxTc6ZceE7+7S/01Ibu/tbOG3QPBcNJGg/1AI2gHadrbCwy22q2tah4GTxd4c020ttI/wCEdeV5L+a3gUylft9xtVpMGRVEYjwOGKFc5+WvMlubhbOS0WeVbeR1keEMQjMoYKxHQkB3APbcfU1FRzBynrd7PoreLtIKeF/Dy7UuQZV1vSpI5AUARmVY44VKE7lEq5fJBzjjnfHcejRaVbLYX+l3t4dSuWmlsre3gIjNtaFVKwfJtV/OUFflLByOprhqKHIEi1cef/Z1n5n2Xytr+X5Xl+Zjcc+Zt+bOem/nHTivS5dc8N3Go2WhIRGup6PpllqepyagjQRQxRQSSBIgg2yjytvzOxzkAAnjyqiknYbR6/Jr/hnXfGHhjxDBrkgl07xBCJV1GCOz8q0km81FQCZ8xxFZAWyMCReMc1Nomv6Jewabr93q1lb6jN4j0oahFNMqM32dps3XJ+4yPHub+8HJ6ivGqKfMLlPVZtW0m/8Ahvpnhqy1W0sNWltJ914ZlCyJ9suG+ySuT+5DAq4OQGyA3BBHlRGCRRRSbuNKwUUUUhhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAHV/F//AJLPrP8A2w/9ER0UfF//AJLPrP8A2w/9ER0Vx4T+BT9F+R7Gff8AIzxP/Xyf/pTD4Qf8ln0b/tv/AOiJK5Sur+EH/JZ9G/7b/wDoiSuUqqf8efpH85Cr/wDIso/9fKn/AKTSPUtF/wBJ/Zf1r7T+++y6iv2fzPm8nLQ52Z+799+n95vU15zXofwcP9oN4m8L/wCr/tLTj/pHXysZj+73/wBdnqPu+/Hn80MtvcSQTxPFLGxR43UqysDggg9CD2pYR8tWrT87/ev80decJ1sHg8StuRwfrCT/AEa/K7toyiiiu8+dCrdlfz6f5slqxSZ0MYkH3kB649CRkZ9zVSik0mrMqE3B80Xqdp4fg0+08Mm5U41G4Vz5xOGSIErsj7AthtzHkLwOpqxNd21okVvBYQSXcqKQu0MEJGTuJ6gV6T4M/Zn+Jfiz4QQeK4Dp1p+6a502xndlubqI/MDwNqBuSu45IOeAQa89tPh78R/EfjE6HpnhXVJ9XihdmtliMZjRerFmwoAOBnPJIAzmuGU4ubtLY9qnWlHDxiqdn37/APBOi8MfBD4m/FO0F94X8PW09tbyBHvmdbS3JBGUDNw5HfaDjvjpVrxl8PvFXw08bWWjeNIYLeSS1ea2ntJfOhnUviQRvt5ZcAMCAR9CCfs7wp8R9B8PfDqw8LalomoeDJbC3gtP7OuYh9oWN4sCWFYy2/a/LYyepNfM37SnxL/4S200zTVtWsZ4b43q288DLPFJ5PlzOrdER3CsEySfvEKMZ5IV5VJcttDpjTlh26ttNL366p/oeWXM72USSBkQwYlCyEAliOcY69uOcUlmIJfDUaSwqDFbKUIlcjcygbgNxUH1OPasux1JJnWTUV2BFYFFwuQQcbckDrioWmlTT4fmWTyl5RcHryxFdSg+5M8wptOMYXWtr2e6S7aWt07eeieHbjdbxmbmVp5I8egGSfzP9K6zV4dHuNL0jU0utNja3U/2jZ3lwPMuHSU5KJy7B4ivQAAg9K4LRJ92vOFP7vLzL/wIAV12nain2iYLCk8RKxyoysdxzxtKfMCD3GepBBq3pqZYOTmlTvu7fLbq0vvZx0eual4f8SSra3k89tDMQsVxuAkTPGVPKkjB9RmuuuPGVnot9qmtaesdxc30dulvHJ0QCPczMB6EgY7n6Vy/iyGO4uJNTjEUbLN9mkiiJKqAuY8EgEkKNpyAcrnHOBzFaSoQq2kTRzfGYDmoqWqel9bOzWnyf36npGn+PZPEllPoPiSO3D3A/wBFuo12BJRyoYdME8ZHTPPt51MhjuHjKlSrEYPUUwEg5FOkkeWRpJGLMxySe59aunRVNvl2ZyY3Mq2OjF4h80o6X6tdn6fqNr0fRP8ARv2afE93b/ubiS8SF5Y/ldkzCNhI5K4dxjp8zeprzivSPH8Uug/Bfwl4bnicyzO967OpjaJgCxjKHuDPjOR9zpzxzY58zp0+rkvuWrPRyBOnDFYp7QpyXznaC/Nv5dNzyuiiius+dCir0Onp5SyXlwYQwyqIm9yD0JGQAD9c9DjBzUn2LTf+f66/8Bl/+OVXKxXRm0VpfYtN/wCf66/8Bl/+OUfYtN/5/rr/AMBl/wDjlHKwujNorS+xab/z/XX/AIDL/wDHKPsWm/8AP9df+Ay//HKOVhdGbRWl9i03/n+uv/AZf/jlH2LTf+f66/8AAZf/AI5RysLozaK0vsWm/wDP9df+Ay//AByj7Fpv/P8AXX/gMv8A8co5WF0ZtFaX2LTf+f66/wDAZf8A45R9i03/AJ/rr/wGX/45RysLozaK0vsWm/8AP9df+Ay//HKPsWm/8/11/wCAy/8AxyjlYXRm0VpfYtN/5/rr/wABl/8AjlH2LTf+f66/8Bl/+OUcrC6M2itL7Fpv/P8AXX/gMv8A8co+xab/AM/11/4DL/8AHKOVhdGbRWl9i03/AJ/rr/wGX/45R9i03/n+uv8AwGX/AOOUcrC6M2itL7Fpv/P9df8AgMv/AMco+xab/wA/11/4DL/8co5WF0ZtFaX2LTf+f66/8Bl/+OUfYtN/5/rr/wABl/8AjlHKwujNorS+xab/AM/11/4DL/8AHKPsWm/8/wBdf+Ay/wDxyjlYXRm0VpGwsWGI9QlDdjNBtX8SrMf0NUJoZIJmilXa69R1+hB7jvnvSaaBMZRRRSGdX8X/APks+s/9sP8A0RHRR8X/APks+s/9sP8A0RHRXHhP4FP0X5HsZ9/yM8T/ANfJ/wDpTD4Qf8ln0b/tv/6IkrlK6v4Qf8ln0b/tv/6IkrlKqn/Hn6R/OQq//Iso/wDXyp/6TSNrwjrv/CM+NtO1sx+YlvJ+8UDJKMCr4GR821jjnGcZrqvitoL6N8Q7m5SDZaah/pMTDcQWP+sBJ/i3ZbAJwGXpnFed16/pY/4WD8DZNOCeZrXh7Hk7Uy0kWDtUYTuisoUclo1JPNZ4h+xqxr9Phfo9n8n+Z3ZRH69g62W/bX7yHm4r3o/OOv8A26eWUUUV6R80Fe3/ALM/wTk+LXxJ+16vbyf8Ito7LNqD8qLhjylsp9WwSxHRA3civKPDXhjWvFvi3TfDeh2T3OoajMIbePGAxPUk9lABJPQAEnpX6m/C/wAD6J8Lvhfp3hDRysi2ymS5usYN1cNjzJT9SAAOyqo7Vx43E+xhZbs68Jh3Wl5I6+G0tdPi81iI4oVyFT5URVHQAcYAGAO2K8++Hdqt9LrviS3jzHeX720Bz92KEnIHp+8eXPuvtWd8dvipYfDz4UalevKr300RhtbcH5pZG4RAOvJ/QMe1d18PNAbwl8J/D3h24Yy3VlYRpcyHrJOw3zMfrI7mvAtaLZ9C5umkur/L/h/yNSSDTYLe3uNYjszMXWGN3QH5nOAi555PFU/Fvgbwl488KS+HvFGh2mo2D8iN12tE3Z43HzIw/vKQfqOK4r4va4LR/C9hFciK4m1QTIN2CfLikYY9emfwrq/DXimHWdMWUsqXKYE0Y7H1HsaSvGzRU8PKVL2j2Phj41fs7eIPhPdPrmiQHX/CbPgXDxA3FkSeEmA6jsJFGCeCFOM+Oxa1a3ml3FpHiBpArwsAOJF5UZHYgkfjX6l+NUs9W+GviCwvArQy6bcK2eg/dsQfwIB/CvzD8T6BZWniHPmrAt4qSI/QQytn5WHZSwIPcHHrXpUMQ6i5ZiwmBkk61NrR8rT2akmvl2v3a2ORguzBqUs6L5bzx7cDjac5PHrzXQ2Fz9h0U3HctvQep6L/ACrm7q3nGqrDeRiK6WRlcf3Sf/11uNA88kcRISCMYGOprv3R4icqNRxWjT9GWCItZS5ivJMz3rq8cu7ASYbtpb2Ytt9uvauOkjeKZopEZHUlWVhggjqDXdJrOm2/h+9037P5wRdybeik5zk9+QDx3zWFrMH27xLJ5m5ZjHH53loXzL5a7+B75z75rSjN2aa2OrN6UakqeIhK7qK7XZ7Pfu9TAoqxJZzw26yyBV3HaE3Dd/3z1FV+hxWyaex4souO6N/wXoL+I/G9hpvkebB5gkuQdwAhU5fJXkZHyg8csBkZqz8Vdd/t34mXu2PZFYf6AmRhm2M24nk/xl8dOMcZzXWeHR/wgHwdvvF8ybNW1TFvYbk5RTnaeUOOjSYOVYInc14/XnU37fESqdI+6vXq/wBD6PHR/s/LaeE+3VtUl5R2gvzl5XQVc0uNJNUTzFDqivLtYZDFELAEdwSOfaqdXtI/5CZ/64Tf+imrvjufMvYezM7s7sWZjksTkk+tJRVrTNOu9Y1uz0nT4jNd3k6W8EY6u7sFUfiSK1EVaK9i8f8AwrtNL8TeG4LXTb3wtpl7dvo095rMUsSvLC4BvP3uMJKjo4GQoIcAgDjOuvhhY2qSWr6jc2MT6nptoNQ1ywFmyJcLd7nQpcyRNF/o4+Yk5IwGQK28A8uor1aD4f8AhDS5vFdv4iu/E8MVlocN/a3U2jxJIrNfQQmSONbwpKuH2A78He54MahqGv8Awst/D/gV9YuvF2lf2pHawXb6Wbq03sswQhEVbgzGQLIGIaFRhWIY8ZAuecUV3vjb4faZ4Xi1z+y/E0urS6HrI0a/WSw+zASN5xRoz5jbh/o8gbIXBxjcDmrug+ENB1z4FNcRWrL4ql1G9aznErYnitre2ke22Z27is0rqQNxMYXncKAuea0V7RefBzTtX8deJ7DSr+TRkt9Yu7DS7e4+z/Z5hFyEEk10szsMgEJFIRlSSc4HLaX8O9MvdEt3vPE8lrq1zo15rkFilgZIzDBHM4RpfMGHfyG42kBTnJPykFc4CivQtW+GI0/4YHxXDq8n2mCG2nu9MvEtopY0m2hWVI7mSXbl1wZIo8hgfatX4UfDM+MfD2o31x4b1TVVu5xo9jPZxSsljcPGz/aZSnARG8lSH+XbKx/hyAdzyiiuq8V6HaaP4U8Izx2bW97e2FxLfbmbLSpfXEIyCcKQsaLgY6euTXTan4DZvA+jWOheGYLvV3to7jUrpb1vtFlJJukQToW8pIGgMbBsDBJDOCCtAHl9Fd78LdF8Mazf+IV8VwbrO30nfHP5rp9klku7eAT/ACkbtgmZtpyDjkV0978LtKi0nwn4Vki+w+J7rXo9J1a/3NKInmVHVBHuCny1kTOMEtuBPTAK543RXoPgfwvay2Ntr975N1FeWniG3FpNAGWN7XSvOSUEk5O6dSOBtMYIOTxp+I/BXhKN9TTw1dXDy2vhjTdSli1C18lI5J/7PG+OUXJG5zdOzb12JllUH5XQGeV0V6v4R8JaDpnhfxPd+Lk8Hz3VldWEMFxqOoXV3Zosy3LMofS3Ys58pOpIG05wTyad4R8GXHhO91jXpZLKOTw4dVt30izkn8lv7aNpu2zXK7zsAQA7RsfJG9N0gK55RRXX3vgb7G2uAapvGl6HY61nyMeb9pNp+6+98u37Z97nPl9Bu4rePPDWleEPG2oeGtO1yfVptOuprS6mezFsgeNyvyfvGLdOcgYOQNw5IM5miiigAooooAKfcqJdE8xvvQTKin/ZcMSD7Arkf7zetMqSX/kX5/8Ar4i/9BkpPYDLooorIo6v4v8A/JZ9Z/7Yf+iI6KPi/wD8ln1n/th/6Ijorjwn8Cn6L8j2M+/5GeJ/6+T/APSmHwg/5LPo3/bf/wBESVyldX8IP+Sz6N/23/8ARElcpVU/48/SP5yFX/5FlH/r5U/9JpBW74P1/UPDXjC01PTYHuZAfLa1UsPPVuCnHU9CODhgpwcYrCrvvhR4yuPBviua6tbCyvHuIxE8VzCrl485ZFY/dzx064weOK6JwjOLjLZnn4WtUo1oVKLtJNNPz6Fz4keErfTLtfEuiCEaLfuAsSAxm3lK5KFG5GcMcYG3lSFwM8pounx3eoLJeOkVnFl5ZJQ2wgfw5UdScD8e1e1eMtNkm8J33jP4fTzN4XuH36hpcKhX0mUYO14+cRg8q69OM8YNeZW9pc6rMRate3oUl2WLk9OTgdPc4rKi5UoKEne3XyPRxzpYvEurRhyc2ritr9bdl1t02OnHiO70zW9JuPD99c2LaeFntp4Jztj2nJVMEAZGQQeoJzuzX1v4i/aU8F6X8KovGiXbKlyGSO0YAz+cOsITPLDIyfugEEnBGfhUF9PZ7VLZ/wB4Rgep6YPHrg4H9K4/xFdx3WoR20UgneHKtOrZVyT0HsOme/0xXPWw8aiTfQ0+vypScnFXfyS7WXp/Xf3HwX4l8R/tC/tfeET4mDro8eofbEs85ijhh/euMn77N5YUnvkAADAr9IZ9UWGKSWd9mAWcnjHc1+XU62OleHV0+S0eO7tZTFH5JLRqgYnIkU8/MSemepz2r0a2/aB8fWHwri8IJFBdCC2aFNallkeVF5KyP1BKggDJ/hX0rCthnOyj0OilaDcqsuZtJtrW3l6/ge6+MdbtfFfiW/17UJxBpWno0VpcMceSVOXnBPTBUKD32v1BqH4dfECHxJoMeu6RP5VzC5huYsYKOPVf7rDDD2OOoNfFw8X6vc+GoNButTuzZwZMcMs7tDnOeU9c8+nsKs+DfG2reC/EkmqabqBjeZDHMhTzY5R2DpkZwcEEEEH2JqpYCXLbqd1POMP7qT0e/kfcfxW+KlpYfCPUNPbEGqanH9it0LZRskb2652hc5+oGeRXxv4g1S31c3rX6tLd8IJGkzuO92fDd/4QM88nFZfiTxXrfim/fU768lvp2G0TEACNf7qIvCD2/Hk1z5mnMPlPwoGMnitsNh5Uo2b3OPMsVhnyqkrtPV30t27ed/kOvZJL8R39wN1xERHNzyw24yT69D9SaZ9puDi0spJZNx2kP8uz2JPf2pIru3gtrtW+d5IwqAdN2ep+gz+OK6n4VeG4/iB8WtF8J3+rLpsV7cYa8IXKAKzEAHgs3AGfyPSulx5It9EediKyxNSMvtS39b2/HQwfsl1YwxrIsD75QwwxzleQM474q9bWGq2tz9piVZmIyx5+cHnPP519/wCi+A/gV4QvtQ8IxeDLdtStLNriXUdZtUuGuNoJAEsoYHdjgKAMZHBGK+W/2m/Dvw78N63pdx8PLC30WWTcLq1tbh/nyNwcIT8oX7vGB09K5KWJVSXJHS51ypKEOavFySWlnay+7Xc83ElvdSCO7hMU3VT0IPswqtpfhnTLrxlaQ6rfJb2Zkae4luWIEqA7imRjaTggkkYBz2xVHQf7b1eO62x+fbWkRlluJSFEP935u5JGAOp57AkXLy53Il0zKVBVEGPvHdyfcYyPxNbu7bgnZ+RhFQpOFZR5qb1tLrZ7efa6810ZleP/ABUvifxN/oSJDpViptbGGLITywfvhTjaWGOABgBRzjNcpUlwIxdSiLPlhyFz6Z4qOtaVONKChHZHn4zF1MXXlXrO8pO7/rstkFXtI/5CZ/64Tf8Aopqo0+GWSC4jnibbJGwdTjOCDkVqnZnMy7V3SNX1DQtZg1bSrj7PeQEmKXYrFCQRkBgRnBOD1BwRggGq8Ygu13wSwwv/ABQyybNvurNwR7Zz9cZL/scn/Pez/wDAuL/4qtSS7pniTVtIsXsbOW3e1e5ivGt7q1iuY2ljDqjFJVYHAkcEYwc8g4GNS6+Iniu9CR3N1p720csMqWX9mWotVaHzvLAgEflhQbmclduGLkkE4I577HJ/z3s//AuL/wCKo+xyf897P/wLi/8AiqBaHQj4i+KxrP8AaX2qw3C0Nh9l/sy1+yeQZPM8v7N5fk7fM+fGz73PXmq17408Qal4cTRNQlsLq3SNIUmm062e6SNCNiLcmPzlUAAAB8bfl6cVj/Y5P+e9n/4Fxf8AxVH2OT/nvZ/+BcX/AMVQGhf1HxRrurHVzqF9539sX66nffukXzrhfNw/AG3/AF8vC4HzdOBhLHxNrumW2mwWGoPAmm3zalabFXMVwwjBcHGTxDHwcj5enJzR+xyf897P/wAC4v8A4qj7HJ/z3s//AALi/wDiqA0Osg+LHj221G5v4tahN1cXkt+072Fu7pNLjzGjZoyYw+AGVNqkDBFXtE+KD6J8N5/DkWnXNxeyWdzp8d3cTwtHBBOGDoiiDzgMO52+cU3HdtzXC/Y5P+e9n/4Fxf8AxVH2OT/nvZ/+BcX/AMVQGhv3vxB8W6h4Zl0C71KF7GaGGCYLZwJJOkRXyhJKqB3K7FALMSAMZwSKx5tZ1O40rT9Nkuj9l08yNaxooXy2dgzNkAEkkDk5OAB0AqD7HJ/z3s//AALi/wDiqPscn/Pez/8AAuL/AOKoDQ0fEPirXvFd3Fc69erdSxebsYQxxY8yZ5n4RQDmSV2/4F6YFa1t8T/G1nYR2kGqwbUtxZmR7C3eWS3C7RBJK0ZeSLaAPLclcADHArmPscn/AD3s/wDwLi/+Ko+xyf8APez/APAuL/4qgNCWx1a/0611C3sp/Ki1C3+yXS7FPmReYku3kcfPEhyMHjHQkVPZeI9b06ytLSxv3t4rS9Go2/lqoaO4AUCQNjORtXjOOKp/Y5P+e9n/AOBcX/xVH2OT/nvZ/wDgXF/8VQF0dFe/Ebxffm38/UbdFt0u0hjtrG3gjjF3CIbjCRxhfnQYPHBywwxJqtc+N/El3ov9lT3lu1ubFdNdls4Flkt1eJ0jeUIHcKbeHbuYlQuBgEg432OT/nvZ/wDgXF/8VR9jk/572f8A4Fxf/FUBoSw6tqFvoF3osNxtsbyaK4nh2Kd7xBxGc4yMCWTgHB3c5wMaem+NvEmlfZVtby3aO2sm06OC5s4LiI27TtcGN45EZZB5rF/mBIOMdBjH+xyf897P/wAC4v8A4qj7HJ/z3s//AALi/wDiqA0N2fx/4sufC0vh6bUYmsJrWKylUWkIklhidHjR5Qm9ghjTbljtA2jAJBxtW1S/1zX77WtUn8++vriS6uZtqr5kjsWZsKABkknAAFR/Y5P+e9n/AOBcX/xVH2OT/nvZ/wDgXF/8VQGhXoqx9jk/572f/gXF/wDFUfY5P+e9n/4Fxf8AxVAXK9FWPscn/Pez/wDAuL/4qj7HJ/z3s/8AwLi/+KoC5XqSX/kX5/8Ar4i/9BkqQ2uwbpbuzRB1YTq+PwQkn8BVG8ulmCQwgiCMkru+8xOMsfTOBx0GB15JUnZD3KtFFFZFHV/F/wD5LPrP/bD/ANER0UfF/wD5LPrP/bD/ANER0Vx4T+BT9F+R7Gff8jPE/wDXyf8A6Uw+EH/JZ9G/7b/+iJK5Sur+EH/JZ9G/7b/+iJK5Sqp/x5+kfzkKv/yLKP8A18qf+k0gpVZkcOjFWU5BHUGkorqPIO68OfEXVdK1aG5ScW0wAWSaMELOOn7xc4P1x3OQcmu1GnWfiWSX/hGtUTw+8zGSSztoh5ZkJyD8pDBM9AMgdgOleIVoafrWo6ZIj2ly6bDlRk/Kfb0qeVWtY66WLnGpzyk9d7aN/M6rxVc+JvDmm31rrd3dCWVPJjYvuWctxuVscgKDzwRwDiuS0LQhFs1DUEGdvmQwOgcH/akUkfL7Y5z2HX1/Tl8Q+MfCtl4kkhsdRuITIkdrG2ZYQuN0ixNw0hx1UlgoGAM5rldQu7aaMsLdppQd/lqj7mP0xnP61i42ex2VpKtLndRyS2vv+f5GZBFLcxNIZJYgfuiIsokPrg9Bzz0/rVq+lvINAvIJr+VJXRS1nFkIi7gMyZx8xyMKBwDye1dDpWleIRb3dzFZSaSzBViu7yMxmKLqzqpGQQBgYA6k5HWszxBD4R07w7dR2msXGp6rPhQXOQvzgljt4zgdyetEYty1Nly06LnB6tPrZW276vy6J9ThKKKK7DwhVZlOVJB9RSs7N95ifqc02igArdsvDl19jTUb27j0+MrvgVsmaXuCkY5xnGGOB71n6ZNa2t4Lq6jEoj5WIjIZu2R6Cur0/S/FPjK/W4stBMiTf8vt0GEIUNtJ3HAOD1Ay3B4OKwrVeRXbsu7PUy/BLEOyTlJ7RSbfq7L/AC9UJJ4x+It3ZQ2V14y1FYoYngUSXx3eWxBZCQdxHA4J4rMuLIXt3dXV9f3N5PKMrLKzySE8cscHd6da7NtA+H3gKQXHi7UF1bVl2t/ZlmMpGfkOCmecZJ/eFQyk/Ka4LxT431LxNNHEIINNsIQUhsrMbEC543EfeIAUdhxwBk1y0a/tZfuo+732+7qz0MblywNNrG1v3vSCfM1/ie0fTV+RstqbWulrYW/mQaepYiKRxErMcDc/Te2AMkj8AK57UdXiLP5MnnTMMB1BCRj/AGc9T71gkknJNFdMaaR5FXGOp6+bvb02S+4KKKK0OIKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAOr+L/APyWfWf+2H/oiOij4v8A/JZ9Z/7Yf+iI6K48J/Ap+i/I9jPv+Rnif+vk/wD0ph8IP+Sz6N/23/8ARElcpXV/CD/ks+jf9t//AERJXKVVP+PP0j+chV/+RZR/6+VP/SaQUUUV1HkBRRRQBo6Tr2saHcGbSdRntGPXy24P1B4NdW/xj+Ib2LWreIJdrLtLhFDY+org6KB3aOs0P4j+K9C1KS8gvxciU5lhu13o/B+hXrn5SM4Gc4rqJPiT4N8QuD4w8DoZdqtJeWMn7yWQALz9xguM8F2xhRz1HldFc1XCUqkudq0u6dn+B6+Dz7GYWl9XjJSp/wAskpR+5p2+Vj1P7D8E7kfaf+Ek1mz835/s3lsfJzzsz5TZx0+8enU9ad/wrjwj/wBFT0X/AMhf/Hq8qoqPq1WPwVX87P8AQ6f7awtT+Pgqb/wucfvtLX9D1X/hXHhH/oqei/8AkL/49Tf7E+Ddsfs93401KW4j+SV4IiY2YcEriJhtJ6YY8dz1ryyij6tVfxVX8rL9A/tnBw1o4KCf95zl+ctD1SLx/wDDrQbiOfw34DknlLB2kv5QGiZTlTGWMmDknkbeg69uf134q+Mtd2L/AGj/AGbEmD5em7odxGeS2S3fpnHA4zzXF0U4YGjF8zV33bv+ZlX4jx9Wn7GE1CH8sEoL/wAlSb+bYUUUV1nhhRRRQAUUUUAFa/hVbJ/HGkJqMKy2rXkSyIxAUgsB82QQV9R3GRxnNZFFCBnr+iaaLPxRqiW8F9psEWuWX+hy7CsgMz4YfuwQuOVAOMHq1VrXw5otr8VbHz7WTU7a/wDtTfaZGQ27y7XPlhCp5U/LhiDuwcDGD5TRWnP5EcnmegaP4I0zUoVkuIdVtmku3t5YzImdNVVBDz5QZyfZPrmrt9oNpqHwr0e582a7uLKznMVrasFZ189synIOUXHIAzyOg5rzKilzLsPlfc7HT/BbpBqqarY391qVhJHH/ZWnyp5pDjO/IV8qBjoD17VZtPBel3HhdNQee8UvZzXL3e9fItpEJAgcbcljj1B54BrhaKV12Cz7no0vg7wra6NNdT/2xJJbafaXsmy4jVXMxClVBjOACc5Oar33hXTtH1w6DKTMLzVlt4pXA8wQoAWwccFmkVc+qGuBqRridkiRp5CsIxGCxwgzn5fTkk8dzT5l2Dlfc9Mu9I0648GS3UulQwRCCORZ44o40jLQSSfK4XexV0SMh2bJJ6EjGfd+C9AXSJPIub+G7h0211CSaaRGi/esAy7QgIAznO6uSvfEGrahaNb3dxG6uQZHEEaySkdN7hQz/wDAiazKHJdhKLPRtY8C+HNJvLASX2pNby30dtJMI32SRsP9YkhiCAg/whnyO9LqPw90jS9IvLm61SYSWSiC4G5cJcO0Zj7cpskJPfKnkV5xRRzLsPlfc9fuPCWnWfhSfQg17ZWc+tW8Rv7x1ZJl2H95HhQApzjqe3PWsQeA9IbVdPgll1Cxa4+05sLh0NxJ5QyhQ7QBv7ZH0zXndFDkuwlF9z1jWvDVpfW+kW01pqUT2ei+bFpe9ftUreafkzs6jJJ+TOO1UrH4eaLc67qVgtzfztb+V5QUlEQsm5llmWKRVZTxyB/SvNKKOZdg5X3PQLL4fwXXgW61iUyxTQ2c12ksc/mxP5ZPykCIKuQP+ehPfGOmrbeHtP0TwJrk0UOoXEE+m20kl9vXyZtzqzJH8vBHTkn3A7+VUUcy7DcW+p6UPh94fTVbS1n1iZV1CR57Fg6/vLURhlzhSd7M20YH8LYB4FVpPBmgWuqagLl9Wa3tdKN+YCrQSBw4XbulhXcv+0EH6V59RRzLsHK+56c/hjQ7DQPE1pb6ZeajMkVldQEOhnjjdSx2kRnAU53EDBGPu4yaFx4Cs49CutWjN81omm211DPuUo8sjAOudvIGTwORxmuAoo5l2Dlfc9GbwT4al8c6poNtPqKf2dEW2yzB5Lpvl4QJCSoGTnCuTxwOa4/xLpdto3ia40+zluJIY9pU3MLwyDKg4ZXVTxnrgZ696yaKTafQEmuoUUUVJQUUUUAFFFFAHV/F/wD5LPrP/bD/ANER0UfF/wD5LPrP/bD/ANER0Vx4T+BT9F+R7Gff8jPE/wDXyf8A6UzA8Ka2/hzxrputqzhbadWl8tVZmjPyyKA3GShYduvUda2PHPh+Hw74ymtrJ0k065UXdjJG4ZWgfJXB3HIByuScnbnvXH11fhvX9Mks4vDXi8Ty6J5u+G5hP7/T3J+Zozg5Rv4kwf7wG4cuacJ+1jrpZr+u36snC1Kdag8FVdtbxk9k7WafZSVrvo4q+l2sCiu3k+Gmo37iXwdqmneJbUqrl7adIpYQwBHmxu2UJO4AZJ+U5weKZ/wqX4g/9C//AOTcH/xdV9codZpers/uY3kGZX93Dyku8U5J+jjdP5M4uiu0/wCFS/EH/oX/APybg/8Ai6P+FS/EH/oX/wDybg/+Lo+uYf8A5+L70L+wMz/6Bqn/AIBL/I4uiu0/4VL8Qf8AoX//ACbg/wDi6P8AhUvxB/6F/wD8m4P/AIuj65h/+fi+9B/YGZ/9A1T/AMAl/kcXRXaf8Kl+IP8A0L//AJNwf/F0f8Kl+IP/AEL/AP5Nwf8AxdH1zD/8/F96D+wMz/6Bqn/gEv8AI4uiu0/4VL8Qf+hf/wDJuD/4uj/hUvxB/wChf/8AJuD/AOLo+uYf/n4vvQf2Bmf/AEDVP/AJf5HF0V2n/CpfiD/0L/8A5Nwf/F0f8Kl+IP8A0L//AJNwf/F0fXMP/wA/F96D+wMz/wCgap/4BL/I4uiu0/4VL8Qf+hf/APJuD/4uj/hUvxB/6F//AMm4P/i6PrmH/wCfi+9B/YGZ/wDQNU/8Al/kcXRXaf8ACpfiD/0L/wD5Nwf/ABdH/CpfiD/0L/8A5Nwf/F0fXMP/AM/F96D+wMz/AOgap/4BL/I4uiu0/wCFS/EH/oX/APybg/8Ai6P+FS/EH/oX/wDybg/+Lo+uYf8A5+L70H9gZn/0DVP/AACX+RxdFdp/wqX4g/8AQv8A/k3B/wDF0f8ACpfiD/0L/wD5Nwf/ABdH1zD/APPxfeg/sDM/+gap/wCAS/yOLortP+FS/EH/AKF//wAm4P8A4uj/AIVL8Qf+hf8A/JuD/wCLo+uYf/n4vvQf2Bmf/QNU/wDAJf5HF0V2n/CpfiD/ANC//wCTcH/xdH/CpfiD/wBC/wD+TcH/AMXR9cw//Pxfeg/sDM/+gap/4BL/ACOLortP+FS/EH/oX/8Aybg/+Lo/4VL8Qf8AoX//ACbg/wDi6PrmH/5+L70H9gZn/wBA1T/wCX+RxdFdp/wqX4g/9C//AOTcH/xdH/CpfiD/ANC//wCTcH/xdH1zD/8APxfeg/sDM/8AoGqf+AS/yOLortP+FS/EH/oX/wDybg/+Lo/4VL8Qf+hf/wDJuD/4uj65h/8An4vvQf2Bmf8A0DVP/AJf5HF0V2n/AAqX4g/9C/8A+TcH/wAXR/wqX4g/9C//AOTcH/xdH1zD/wDPxfeg/sDM/wDoGqf+AS/yOLortP8AhUvxB/6F/wD8m4P/AIuj/hUvxB/6F/8A8m4P/i6PrmH/AOfi+9B/YGZ/9A1T/wAAl/kcXRXaf8Kl+IP/AEL/AP5Nwf8AxdH/AAqX4g/9C/8A+TcH/wAXR9cw/wDz8X3oP7AzP/oGqf8AgEv8ji6K7T/hUvxB/wChf/8AJuD/AOLo/wCFS/EH/oX/APybg/8Ai6PrmH/5+L70H9gZn/0DVP8AwCX+RxdFdp/wqX4g/wDQv/8Ak3B/8XR/wqX4g/8AQv8A/k3B/wDF0fXMP/z8X3oP7AzP/oGqf+AS/wAji6K7T/hUvxB/6F//AMm4P/i6P+FS/EH/AKF//wAm4P8A4uj65h/+fi+9B/YGZ/8AQNU/8Al/kcXRXaf8Kl+IP/Qv/wDk3B/8XR/wqX4g/wDQv/8Ak3B/8XR9cw//AD8X3oP7AzP/AKBqn/gEv8ji6K7T/hUvxB/6F/8A8m4P/i6P+FS/EH/oX/8Aybg/+Lo+uYf/AJ+L70H9gZn/ANA1T/wCX+RxdFdp/wAKl+IP/Qv/APk3B/8AF0f8Kl+IP/Qv/wDk3B/8XR9cw/8Az8X3oP7AzP8A6Bqn/gEv8ji6K7T/AIVL8Qf+hf8A/JuD/wCLo/4VL8Qf+hf/APJuD/4uj65h/wDn4vvQf2Bmf/QNU/8AAJf5HF10ngbw/D4i8ZQ2166R6dbKbu+kkcKqwJgtk7hgE4XIORuz2rTj+Gmo2DmXxjqmneGrUKzh7mdJZZgoJPlRo2XIO0EZB+YYyeKx/Emv6ZHZy+GvCAni0Tzd81zMf3+oOD8rSHAwi/wpgf3iNx4iddVU4UXdvr0Xz7+X3m1HLpYKSxGYQsk/gekpPty7qL6tpabXdkZnivW38R+NdT1tmcrczs0XmKqssY+WNSF4yECjv06nrRWPRW0IqEVFbI8qvWnXqSq1HeUm2/V6sKKKKoyCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAP/9k=",
	"bangga": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwMDAgQDAwMEBAQFBgoGBgUFBgwICQcKDgwPDg4MDQ0PERYTDxAVEQ0NExoTFRcYGRkZDxIbHRsYHRYYGRj/2wBDAQQEBAYFBgsGBgsYEA0QGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBj/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4Poor2XTNMj+BcOleJvE2hw3/AI7vI0vtK0bUYm+z6VBuIFzcAEFp2KMEiBHl4LthwqjPF4tUEoxXNOXwx6t/ol1fTzbSdUaPtLtu0Vu+3/B7I5nwz8Efit4vsDfaF4J1GS1MccqT3Wy0SZHBKtG0zIJAQM5TOMjPUZ3P+GY/jj/0JH/lSs//AI7TdBl8X/tAfGbSfD3i3xjdtNd+d5dxLEJIrbZAXPlwKURdwhUHbtyeTk9fZP8Ahin/AKqX/wCUb/7or5jM+IJ5bUVLG4mnTm1fl9nUnpqviUo31T+yvQ9PDZesTFyo0pSSdr80V+DT/Nnjv/DMfxx/6Ej/AMqVn/8AHaP+GY/jj/0JH/lSs/8A47XsX/DFP/VS/wDyjf8A3RR/wxT/ANVL/wDKN/8AdFed/rphv+g+n/4Iq/8AyZ0f2NU/58S/8Dj/APInjv8AwzH8cf8AoSP/ACpWf/x2j/hmP44/9CR/5UrP/wCO17F/wxT/ANVL/wDKN/8AdFH/AAxT/wBVL/8AKN/90Uf66Yb/AKD6f/gir/8AJh/Y1T/nxL/wOP8A8ieO/wDDMfxx/wChI/8AKlZ//HaP+GY/jj/0JH/lSs//AI7XsX/DFP8A1Uv/AMo3/wB0Uf8ADFP/AFUv/wAo3/3RR/rphv8AoPp/+CKv/wAmH9jVP+fEv/A4/wDyJ47/AMMx/HH/AKEj/wAqVn/8do/4Zj+OP/Qkf+VKz/8Ajtexf8MU/wDVS/8Ayjf/AHRR/wAMU/8AVS//ACjf/dFH+umG/wCg+n/4Iq//ACYf2NU/58S/8Dj/APInjv8AwzH8cf8AoSP/ACpWf/x2j/hmP44/9CR/5UrP/wCO17F/wxT/ANVL/wDKN/8AdFH/AAxT/wBVL/8AKN/90Uf66Yb/AKD6f/gir/8AJh/Y1T/nxL/wOP8A8ieO/wDDMfxx/wChI/8AKlZ//HaP+GY/jj/0JH/lSs//AI7XsX/DFP8A1Uv/AMo3/wB0Uf8ADFP/AFUv/wAo3/3RR/rphv8AoPp/+CKv/wAmH9jVP+fEv/A4/wDyJ47/AMMx/HH/AKEj/wAqVn/8do/4Zj+OP/Qkf+VKz/8Ajtexf8MU/wDVS/8Ayjf/AHRR/wAMU/8AVS//ACjf/dFH+umG/wCg+n/4Iq//ACYf2NU/58S/8Dj/APInjv8AwzH8cf8AoSP/ACpWf/x2j/hmP44/9CR/5UrP/wCO17F/wxT/ANVL/wDKN/8AdFH/AAxT/wBVL/8AKN/90Uf66Yb/AKD6f/gir/8AJh/Y1T/nxL/wOP8A8ieO/wDDMfxx/wChI/8AKlZ//HaP+GY/jj/0JH/lSs//AI7XsX/DFP8A1Uv/AMo3/wB0Uf8ADFP/AFUv/wAo3/3RR/rphv8AoPp/+CKv/wAmH9jVP+fEv/A4/wDyJ47/AMMx/HH/AKEj/wAqVn/8do/4Zj+OP/Qkf+VKz/8Ajtexf8MU/wDVS/8Ayjf/AHRR/wAMU/8AVS//ACjf/dFH+umG/wCg+n/4Iq//ACYf2NU/58S/8Dj/APInjv8AwzH8cf8AoSP/ACpWf/x2j/hmP44/9CR/5UrP/wCO17F/wxT/ANVL/wDKN/8AdFH/AAxT/wBVL/8AKN/90Uf66Yb/AKD6f/gir/8AJh/Y1T/nxL/wOP8A8ieO/wDDMfxx/wChI/8AKlZ//HaP+GY/jj/0JH/lSs//AI7XsX/DFP8A1Uv/AMo3/wB0Uf8ADFP/AFUv/wAo3/3RR/rphv8AoPp/+CKv/wAmH9jVP+fEv/A4/wDyJ47/AMMx/HH/AKEj/wAqVn/8do/4Zj+OP/Qkf+VKz/8Ajtexf8MU/wDVS/8Ayjf/AHRR/wAMU/8AVS//ACjf/dFH+umG/wCg+n/4Iq//ACYf2NU/58S/8Dj/APInjv8AwzH8cf8AoSP/ACpWf/x2j/hmP44/9CR/5UrP/wCO17F/wxT/ANVL/wDKN/8AdFH/AAxT/wBVL/8AKN/90Uf66Yb/AKD6f/gir/8AJh/Y1T/nxL/wOP8A8ieO/wDDMfxx/wChI/8AKlZ//HaP+GY/jj/0JH/lSs//AI7XsX/DFP8A1Uv/AMo3/wB0Uf8ADFP/AFUv/wAo3/3RR/rphv8AoPp/+CKv/wAmH9jVP+fEv/A4/wDyJ47/AMMx/HH/AKEj/wAqVn/8do/4Zj+OP/Qkf+VKz/8Ajtexf8MU/wDVS/8Ayjf/AHRR/wAMU/8AVS//ACjf/dFH+umG/wCg+n/4Iq//ACYf2NU/58S/8Dj/APInjv8AwzH8cf8AoSP/ACpWf/x2j/hmP44/9CR/5UrP/wCO17F/wxT/ANVL/wDKN/8AdFH/AAxT/wBVL/8AKN/90Uf66Yb/AKD6f/gir/8AJh/Y1T/nxL/wOP8A8ieO/wDDMfxx/wChI/8AKlZ//HaP+GY/jj/0JH/lSs//AI7XsX/DFP8A1Uv/AMo3/wB0Uf8ADFP/AFUv/wAo3/3RR/rphv8AoPp/+CKv/wAmH9jVP+fEv/A4/wDyJ47/AMMx/HH/AKEj/wAqVn/8do/4Zj+OP/Qkf+VKz/8Ajtexf8MU/wDVS/8Ayjf/AHRR/wAMU/8AVS//ACjf/dFH+umG/wCg+n/4Iq//ACYf2NU/58S/8Dj/APInjv8AwzH8cf8AoSP/ACpWf/x2j/hmP44/9CR/5UrP/wCO17F/wxT/ANVL/wDKN/8AdFH/AAxT/wBVL/8AKN/90Uf66Yb/AKD6f/gir/8AJh/Y1T/nxL/wOP8A8ieO/wDDMfxx/wChI/8AKlZ//HaP+GY/jj/0JH/lSs//AI7XsX/DFP8A1Uv/AMo3/wB0Uf8ADFP/AFUv/wAo3/3RR/rphv8AoPp/+CKv/wAmH9jVP+fEv/A4/wDyJ47/AMMx/HH/AKEj/wAqVn/8do/4Zj+OP/Qkf+VKz/8Ajtexf8MU/wDVS/8Ayjf/AHRR/wAMU/8AVS//ACjf/dFH+umG/wCg+n/4Iq//ACYf2NU/58S/8Dj/APInjv8AwzH8cf8AoSP/ACpWf/x2j/hmP44/9CR/5UrP/wCO17F/wxT/ANVL/wDKN/8AdFH/AAxT/wBVL/8AKN/90Uf66Yb/AKD6f/gir/8AJh/Y1T/nxL/wOP8A8ieO/wDDMfxx/wChI/8AKlZ//HaP+GY/jj/0JH/lSs//AI7XsX/DFP8A1Uv/AMo3/wB0Uf8ADFP/AFUv/wAo3/3RR/rphv8AoPp/+CKv/wAmH9jVP+fEv/A4/wDyJ4D4m+CPxW8IWAvtd8E6jHaiOSV57XZdpCiAFmkaFnEYAOcvjODjoccBXuHjXSfF/wCzV8TrbTPCXju7kmu7BL2SWK3EMUmXmiCyQszpJtAYgtnBbgAjNVNT0yP46Q6r4m8M6HDYeO7ON77VdG06Jvs+qwbgDc24JJWdS6h4iT5mQ65csp+kwma1PZQxFZxlRltUinG1/wCaMrtLpfmfmktV51XCx5nTgmpr7Ls/ua3flb0ueNUUUV9Aeed/8EfDNr4v/aB8LaFfGE2r3f2maOaETJMkKNO0TITghxGUOc43ZwehzfHXi6+8d/EbV/FuoJ5c2oTmRYsg+TGAFjjyFXdtRVXdgE7cnkmuu/Zj/wCTqfC3/b3/AOkc1eYV5NFKWa1XL7NOFvLmlU5vv5Y/cjrm7YWNusnf5KNvuu/vLemapqei6pFqejajd6dew58u6tJmhlTIKnaykEZBIOOxNdD/AMLS+Jv/AEUXxZ/4N7j/AOLrk6K9OrhaNV81SCb80mc0as4K0ZNHWf8AC0vib/0UXxZ/4N7j/wCLo/4Wl8Tf+ii+LP8Awb3H/wAXXJ0Vl/Z+F/59R/8AAV/kV9Yq/wAz+9nWf8LS+Jv/AEUXxZ/4N7j/AOLo/wCFpfE3/ooviz/wb3H/AMXXJ0Uf2fhf+fUf/AV/kH1ir/M/vZ1n/C0vib/0UXxZ/wCDe4/+Lo/4Wl8Tf+ii+LP/AAb3H/xdcnRR/Z+F/wCfUf8AwFf5B9Yq/wAz+9nWf8LS+Jv/AEUXxZ/4N7j/AOLo/wCFpfE3/ooviz/wb3H/AMXXJ0Uf2fhf+fUf/AV/kH1ir/M/vZ1n/C0vib/0UXxZ/wCDe4/+Lo/4Wl8Tf+ii+LP/AAb3H/xdcnRR/Z+F/wCfUf8AwFf5B9Yq/wAz+9nWf8LS+Jv/AEUXxZ/4N7j/AOLo/wCFpfE3/ooviz/wb3H/AMXXJ0Uf2fhf+fUf/AV/kH1ir/M/vZ1n/C0vib/0UXxZ/wCDe4/+Lo/4Wl8Tf+ii+LP/AAb3H/xdcnRR/Z+F/wCfUf8AwFf5B9Yq/wAz+9nWf8LS+Jv/AEUXxZ/4N7j/AOLo/wCFpfE3/ooviz/wb3H/AMXXJ0Uf2fhf+fUf/AV/kH1ir/M/vZ1n/C0vib/0UXxZ/wCDe4/+Lo/4Wl8Tf+ii+LP/AAb3H/xdcnRR/Z+F/wCfUf8AwFf5B9Yq/wAz+9nWf8LS+Jv/AEUXxZ/4N7j/AOLo/wCFpfE3/ooviz/wb3H/AMXXJ0Uf2fhf+fUf/AV/kH1ir/M/vZ1n/C0vib/0UXxZ/wCDe4/+Lo/4Wl8Tf+ii+LP/AAb3H/xdcnRR/Z+F/wCfUf8AwFf5B9Yq/wAz+9nWf8LS+Jv/AEUXxZ/4N7j/AOLo/wCFpfE3/ooviz/wb3H/AMXXJ0Uf2fhf+fUf/AV/kH1ir/M/vZ1n/C0vib/0UXxZ/wCDe4/+Lo/4Wl8Tf+ii+LP/AAb3H/xdcnRR/Z+F/wCfUf8AwFf5B9Yq/wAz+9nWf8LS+Jv/AEUXxZ/4N7j/AOLo/wCFpfE3/ooviz/wb3H/AMXXJ0Uf2fhf+fUf/AV/kH1ir/M/vZ1n/C0vib/0UXxZ/wCDe4/+Lo/4Wl8Tf+ii+LP/AAb3H/xdcnRR/Z+F/wCfUf8AwFf5B9Yq/wAz+9nWf8LS+Jv/AEUXxZ/4N7j/AOLo/wCFpfE3/ooviz/wb3H/AMXXJ0Uf2fhf+fUf/AV/kH1ir/M/vZ1n/C0vib/0UXxZ/wCDe4/+Lo/4Wl8Tf+ii+LP/AAb3H/xdcnRR/Z+F/wCfUf8AwFf5B9Yq/wAz+9nWf8LS+Jv/AEUXxZ/4N7j/AOLo/wCFpfE3/ooviz/wb3H/AMXXJ0Uf2fhf+fUf/AV/kH1ir/M/vZ1n/C0vib/0UXxZ/wCDe4/+Lo/4Wl8Tf+ii+LP/AAb3H/xdcnRR/Z+F/wCfUf8AwFf5B9Yq/wAz+9nWf8LS+Jv/AEUXxZ/4N7j/AOLo/wCFpfE3/ooviz/wb3H/AMXXJ0Uf2fhf+fUf/AV/kH1ir/M/vZ1n/C0vib/0UXxZ/wCDe4/+Lo/4Wl8Tf+ii+LP/AAb3H/xdcnRR/Z+F/wCfUf8AwFf5B9Yq/wAz+9nWf8LS+Jv/AEUXxZ/4N7j/AOLo/wCFpfE3/ooviz/wb3H/AMXXJ0Uf2fhf+fUf/AV/kH1ir/M/vZ1n/C0vib/0UXxZ/wCDe4/+Lo/4Wl8Tf+ii+LP/AAb3H/xdcnRR/Z+F/wCfUf8AwFf5B9Yq/wAz+9nWf8LS+Jv/AEUXxZ/4N7j/AOLo/wCFpfE3/ooviz/wb3H/AMXXJ0Uf2fhf+fUf/AV/kH1ir/M/vZo6zr+u+Ir5L3xBrWo6tcpGIlnv7l53VASQoZySBlice59a0PAvi6+8CfEbSPFunp5k2nziRosgedGQVkjyVbbuRmXdgkbsjkCueorWeGpTpOhKK5GmmulnuiI1JRmqieq1udn8bvDNr4Q/aB8U6FYmEWqXf2mGOGEQpCkyLOsSoDgBBIEGMZ25wOgK3P2nP+TqfFP/AG6f+kcNFefklWVXLsPUm7twg36uKOjGxUMRUjHZSf5h+zH/AMnU+Fv+3v8A9I5q8wr0/wDZj/5Op8Lf9vf/AKRzV5hU4f8A5Glf/r3S/wDSqo6n+6w/xS/KAUUUV7JxhRRRQAUUUUAFFdD4R8C+L/HeqNp/hLQLvVJkx5jRALFDkMR5kjEImQjY3EZIwMnivX7T9lfWNNsYdS+Ivj3wz4RsJo1CvNN5rrOw3CFt5jjyAHyVkb7vGRyPKx2eYDAz9niKqUv5d5f+Aq7/AAOqhga9dc1ODa77L73ofP8ARX0Qfh/+yxp+LHVfit4jmvoAI7iW0t28mSQcM0eLZxsJyRh2GCPmbqXf8JP+yRjP/CrfFf8A4ESf/JlcP+sXNrSwtaS/wW/9Kcb/AC+Zv/ZzXx1YL/t6/wCSZ860V9E/8JR+yP8A9Eu8V/8AgRJ/8mUn/CL/ALJGoH7f/wAJ54s0r7R++/s/yXb7Lu58rP2Z87c7c736febqT/WFx/iYSsv+3L/+kuX4h/Z1/hqwfzt+aR870V9Cn9lk65/yTr4q+E/E/k/8fmX8v7Pn7n+pabO7D9dv3eM848m8Y/DLx54A8pvF3hq706GbAS4ys0JY7sJ5sZZN+EY7M7sDOMc12YPP8vxk/ZUaq5/5XeMv/AZWf4fmZVsBiKMeacNO+6+9XRydFSvbzR28U7xlY5c7GP8AFg4P61FXrnI01uFFFFAgooooAKt6Xpl9rWu2WjaZB597ezpbW8W4LvkdgqrliAMkgZJAqpXY/DH/AJHyf/sCav8A+m25rDFVXSozqR3Sb+5F0oqc1F9WXoR4N0KP7JD4etvE04+We/1K4uY4HYd7eKF4nROSMyszMFVtsRLJUn9teF/+iYeF/wDwJ1L/AOTKwK9e+G/gvw9r3gaxvdR0a0vJ7jW3sp5prySGRIBAH/dIsih3B5ACsTk8dx2YbJoYiXIpSv8A4pL8E7fckvQ8nN8+hlVD6xWjeN7aKPZvrbt3ucB/bXhf/omHhf8A8CdS/wDkyj+2vC//AETDwv8A+BOpf/Jlei+AvBHhHVdJs7nVNKlug2u3lo/mSyRO8Edm0qoQrDadwB7Ht04qh4i+HWnReHdA/wCEfj8+bW9WaOzuy7HzLZ1QxhlzgFdzBuAcqa3/ANXl7P2ibt/jnfp5+Z5i41wv1r6pJNPu4xt9q+vlyN7Xt87cT/bXhf8A6Jh4X/8AAnUv/kyj+2vC/wD0TDwv/wCBOpf/ACZXW/E3wl4d0vSbTWPCcUC2cVzJp115N8t2HdeY5SVdthdQ3ynGNvQVz8PgjzfhDceOv7atV8m7Fr9gI+dskDOc9ec7cdATmsqmRxhNw952V/jnt953YXibD4jD08TflU5cqTir8zdknZO1/W1il/bXhf8A6Jh4X/8AAnUv/kyj+2vC/wD0TDwv/wCBOpf/ACZWt4W0TSZPh94g8U3unf2tcadJBFHYmR0jUOTmWTYQxAxgYI561u+F9I8Da/pupXmr6DcaTLog/tG4treWVheWxX/VfO2UO8rhh/C3cjdTp5HTny+81fX45+fnboyMVxPDD+0bpuSptRbUYPVpNK1+Z/FFXta73tdnGf214X/6Jh4X/wDAnUv/AJMo/trwv/0TDwv/AOBOpf8AyZXp+h+DPBmt+ENDmbRbOG/1i01GeOGO4uvPZ4nfy1iJYxBVUAHzOTgdTmuZvdF8Naf8GPD+rG00ZNT1G3uzJJfPemaRklKKYREfKBAx9/AzjOea0lw/CMeZydrX+Ofl576o5aXGVKrU9jGlLm5+S3LHf39d/h/dy18vW3Lf214X/wCiYeF//AnUv/kyj+2vC/8A0TDwv/4E6l/8mV6Prngbw1bfDeTUYtFhhkj8P2WoLdW91JJcNcyEB98RdgsZHO7YoHOD2FK48IeHY/g7/wAJkvh+Uai9gi/2Z9ofbFmQp9vxv37DjhT8uT0K05cPRi2m3or/ABz2+8mlxrhqkYyUHrNQXuw+JpNddtfl1tpfhf7a8L/9Ew8L/wDgTqX/AMmUg0jw/wCMrmLS9F0GPQdendYbKO0uZZLO6cnCwsszO8cjlsCTzNmQisigtKuDRXnyy+CX7uUk+j5pP8G7M+oWIlf3kmvRL9Dm639E0S2nsf7W1YzfYfMaCOK3cJJPIoUsAxVgiqHUkkHO4AD7zJd+KX/JdPGn/Yevv/Sh6uyf8ij4a/68JP8A0ruKxp13UoxqpW5kn96ucmZSlRapxe8rX+Tf6f5a6h5mgf8AQnaR/wB/7v8A+P0eZoH/AEJ2kf8Af+7/APj9VK9h+FXwo0Xxh4Xn1zW7u62mZoIobZwu3AGWYkHnnge3fNRzy7ngY7E0cDS9tWnK3+KX+Z5T5mgf9CdpH/f+7/8Aj9HmaB/0J2kf9/7v/wCP11d94ItNN+OEfgm51Em0a7ii+0cBtjhWA9A2GA+tXtU8P6JceFvEl9FobaLNo2oRWsP72RvtSu7KUYOT86gBsrgYPSjnl3IeMo+5aUmpJNPmltJ2X2r7/d1OG8zQP+hO0j/v/d//AB+jzNA/6E7SP+/93/8AH69h8TfDzwlanxRf6RZEW2nWvleQ07k2tyGQ7uWyysj5GcjIb0FYw8IeHf8AhpS58K/2d/xKEEhW286TjFqXHzbt33uev6Uc8u5zUs1w9WDnFz0i5fE9kk39rf3l/meb+ZoH/QnaR/3/ALv/AOP0eZoH/QnaR/3/ALv/AOP16v4V8BeF9d8M+EHa0P8Aad08lxdoZnAu7dJzG4HzfKygoflxkBqybXQvDNp8O7zWLuz0gXKa5NYpJqkl4U8pYwwRRbnO7OeW9+elHPLuUszouTgudtO3xS7tfzeT/q5595mgf9CdpH/f+7/+P0eZoH/QnaR/3/u//j9VKKOeXc9b2X96X/gUv8y2W8PSKY38JafGrcF4Li5WRR6qWlZQ3oSrDPUHpXPa7oyacIL6yd5NPumdYTIR5kbrtLxvjGSu9PmAwwYHg7lXWqXUf+SaX/8A2E7T/wBFXNXTm72ZdOUqMotNtNpNNt7u3Vu1t/wOMooorpPaPT/2nP8Ak6nxT/26f+kcNFH7Tn/J1Pin/t0/9I4aK8Th/wD5FeF/69w/9JR25h/vVX/E/wA2H7Mf/J1Phb/t7/8ASOavMK9P/Zj/AOTqfC3/AG9/+kc1eYVWH/5Glf8A690v/Sqoqn+6w/xS/KAUUUV7JxhRRXp3wg+EF98StVn1LUrr+yPCWmZk1PV5SEVVUbmjjZvl37eSx+VFO5s5VW5cbjaOCoyxGIlaK/qy7t9F1NaNGdaap01ds43wn4P8S+OfEa6F4U0mbUr9o2lMSMqBEXqzOxCqOQMsRkkDqQD9A2/w3+CPwW8q7+KOvf8ACW+JY9j/ANg6eu+OFv3TYaPI3Y3EgzMiyIT+7JFYXij42aX4W8HW/wAPvgZHd6No8PmC81maNRd6g5BQyKcZXcAG34Vx8gURhMHwuvC+rY/N/erSdCj0itKkv8UvsL+7HXV3Z3+0oYTSCU5938K9F19Xp5Htfiz9prx1q9suleEYbTwdosUH2aK005FeRY9irt80qNm3B2GNYyoPcgGvKfN1nxb4qR9Q1G5v9RvHVHu72ZpXOAFy7sSSFUdzwBWVXoukeE9WN5pmgeGdObUvEeonyRFbne/mMT8nYKECksTwMEk4FexgsqweXQthaSj521fq9382znniamJmnXk2v62WyOb8avZN44vGsAGtQVSMjjKqoUfoor1v4baPFdWEX/CXfs7pqXh6UYbVrZ7uzuVUj78bSTbJfoAM9jXr/g/4F+GPholvrPiDf4m8XypvitbTHkW+3qY2YZwv8U7YH90evRS6hrnirUpdHOn/AGa+ZEdoo7qRtsb52+aX7MFJGcHABxgiu2OyQV37arKqlZN3sfK/jD4QXn/Cxb60+H1vcaloLFZbSe5kRGVXGQhLEZI9cdMZwaxtR+DHxL0y0N1P4Uu5IQMlrdlmx+Ckn9K+v/Dnhe60F2u9T0WcWW4rLeWUu+S2IOD5sZBJUYH3eg5wRXos2hanFai405U1e1ZQ3kAokzKeQYnGEfjoGxn+9Vc9jJ00fmRG+oaTqsc0T3NjfWsiyI6lopYZFOQwPBVgQCD1Fe2/DD45/Fyw1W0tbrUTruiRtsnOsKW8tWkDM32kDzN+NyruLjnAU4AE3xY8S6Jr/wATLlv7KiSy0l3gBuLbyLid1+8ZAw3JggjaRwOcAnjzSXxLLfhkmvTYWSngIC8jf7i5wOB1P515+YYDC5hT9niKSn6rb0e6+R25fJ0aqk5uK8na/r0+89Wt/B/wv+LOvX2k3Pii28Ia8kyxaTawwJHbPGzrlRFhUZy7MFRHVssThgK8Y8ffDbxf8NddTTPFem/Z/O3m2uonEkNyqttLIw/A7WwwDLlRkVj3tz9svpJwgRWOFQHO1RwB+Veu/Dz45vpnhyXwH8TLGXxR4JmtPsotNitPahclPLYlSwBwACwKbUKMuzafNrYfMMvk62Gftael6bspL/BL/wBtlv0abNsTicNjasudcj6NbW6Jr06r7jw6ivX/AIrfBm28LeHbHx74A1SbxF4Gvo0KXzYaW0c/Libaq8FsgHau1sowDAb/ACCvWwGPo46kq1B3Wz6NNbprdNdUzy6+HnQnyTWv5ruvIKKKK7DEK3fBut23h7xna6jfRyyWLJLaXghAMv2eeJ4JjHkgeYI5HK543Bc5GRWFRUVaaqwlTls1b7yoycZKS6Hbarod/pMdvcyoJtPu9zWWowBjb3ijGWicgZxkBlIDIfldVYFRBDqup29pFawaldxQQzi6jiSZlVJQMCRQDgPgD5hzWNoninxP4a8//hHPEeraP9o2+d/Z95Jb+btzt3bCM43NjPTJ9a1v+FpfE3/ooviz/wAG9x/8XUrEYuGijF+fM43+XK/z89NhToUKnxfdZP8AVFxPEviKN2ePX9URmme4LLdSAmV12s/X7xUkE9SDimW+v69aRWkVrreowR2bM9skVy6iBmzuKAH5ScnJHXJqt/wtL4m/9FF8Wf8Ag3uP/i6P+FpfE3/ooviz/wAG9x/8XVfXcb/Iv/A3/wDIGP1DB2tb/wAlXn5+b+9gl9ex6fLYR3lwtrMweWBZCEkYdCy5wSMnBNV6sf8AC0vib/0UXxZ/4N7j/wCLo/4Wl8Tf+ii+LP8Awb3H/wAXUvFYt/8ALuP/AIG//kDZUKMb2b18l/mO0/U9S0m7+1aXqF1Yz4x5ttK0TY9MqQae2s6u093M2q3pkvF2XTmdiZ19HOfmHA4OelRf8LS+Jv8A0UXxZ/4N7j/4uj/haXxN/wCii+LP/Bvcf/F01i8Ylbkj/wCBv/5AiWEw0pc7378q/wAy7D4n8SW2jjSbfxDqsNgFKi0ju5FiwSSRsBxgknPHc0QeJ/Etto50i28Q6rDp5RozaR3cixbWzuXYDjBycjHOTVL/AIWl8Tf+ii+LP/Bvcf8AxdH/AAtL4m/9FF8Wf+De4/8Ai6f13G/yL/wN/wDyBm8uwTveK1d/hW/fffzLA13XBJ5g1nUA/wBm+xbvtD58jp5XX7n+z09qDr2uG6e5Os6gZng+yvKbh9zQ4x5ZOclMcbelV/8AhaXxN/6KL4s/8G9x/wDF0f8AC0vib/0UXxZ/4N7j/wCLo+uYz+SP/gb/APkCvqOE7f8Akq/zK9bWi6Kk0Sa7rqXVr4Zt5wl5fRrt34wTBAxBD3DKflTnGdzbUV2XN/4Wl8Tf+ii+LP8Awb3H/wAXWJrOv674ivkvfEGtajq1ykYiWe/uXndUBJChnJIGWJx7n1rOVXFVFytKN+qbb+XurXs+nZm6jSjrdv5W/Vhr+s3XiLxXqniC9jhjudRu5byZIQQivI5dgoJJAyxxkn610eiytrugWWl2qNLqdgHiS2jUlp4C5kBQclnVnk3Afw7CAQrkcXRVqlFQUI6JbHLiqLxCu3qndPz1/wAzrq6Hw3458U+EYp4tA1V7aKc7njKLIpbGNwDAgH3HpXGf8Jr4y/6G3Xf/AAPl/wDiqP8AhNfGX/Q267/4Hy//ABVZ+xfc8yrgataPJUhFrs23/wC2m1e315qOpTahfXMk91M5kkmc5ZmPepr7WtZ1OKKPUtWvrxIv9WtxO8gT6Ak4rn/+E18Zf9Dbrv8A4Hy//FUf8Jr4y/6G3Xf/AAPl/wDiqPYvuV9Trae5HTbV6f8Akp0T67rcjXbSaxqDNe4F0WuHJuMdPM5+bHbOatS+MPF0xQzeKdakMbFkL30p2kqVJGW4OGYfQkd65P8A4TXxl/0Nuu/+B8v/AMVR/wAJr4y/6G3Xf/A+X/4qj2L7kPAVHvTj9/8A9qdBBrWsWr2jW2rX0LWYYWxjndTAGzu2YPy5yc465qey8TeJNNheLTvEOq2ccjmV0t7uSMM56sQCMk4HPtXMf8Jr4y/6G3Xf/A+X/wCKo/4TXxl/0Nuu/wDgfL/8VR7F9xywNWW8I/f/APamkSSck5NFZv8AwmvjL/obdd/8D5f/AIqj/hNfGX/Q267/AOB8v/xVHsX3NPq+I7R+9/8AyJqxRSzzpBBG8ssjBEjRSzMScAADqTUXiO6Sw0IeHsg3j3K3N4nXyCissceez/vJS45x8g4YOozJ/F3iu5tpLa58T6zNDKpSSOS9lZXUjBBBbBBHasarhS5XdmlLCTclKray1stdfN2W3a29tegUUUVqeken/tOf8nU+Kf8At0/9I4aKP2nP+TqfFP8A26f+kcNFeJw//wAivC/9e4f+ko7cw/3qr/if5sP2Y/8Ak6nwt/29/wDpHNXmFen/ALMf/J1Phb/t7/8ASOavMKrD/wDI0r/9e6X/AKVVFU/3WH+KX5QCiitzwf4T1fxz430/wpoSQtf30hSMzPsRAFLM7H0VVZjgEnGACcA+rVqwpQlUqO0UrtvoluzlhFzkoxV2zsvhB8IL74larPqWpXX9keEtMzJqerykIqqo3NHGzfLv28lj8qKdzZyqtvfFv4t2Ou6Vb/Dv4d2v9keA9MxHFDECjX7Kc+ZJn5tm75grfMzHe+WICanxs8UeHvC2gp8DPh9afZ9H0udZdVvhOHk1C6CjKyFDh9pxv3Dh0VQqCIZ8Lr57LcNPNKsczxa91a0oPouk5b3k+n8q8z0cRUWFi8NS3+0+/kvJfj6BRRU1raXV9eR2llby3FxKwSOGJC7uT0AA5Jr6k8wjjIEqk4xkda/Sr9nH4Lnwl8NZ/HWrxCfxH4ld5EkK4+yWLsXRFB5Uyja7d8FVP3Tn5j+DX7PU6eKbDxF8W7QaXpkT+db6BdELd6iVw37yL70UA6uzAFh8qj5sj7j8YeN59N+Gt5JaTAXNy0en2uBjbNPIsIYe43s3/Aawqu+xvRhKUlFdR9roOmy3TbYxPLeJ500pGd8auFUf7mTwOnBPc15d8ENviPXPiDrd0u68k18ks3JEflbUH0ABFeh+FvGmkt8XvFenWxje30y203TIIyeEA84n8d20fgK858DeJbbwF+1Lrngi9s4ILLV4zJYysuFuDlpYi3qdrSJkfxJisZNpo9PCQjOjWiviSTXomr/hr8j11LCKLVorXZtkuFZ1x/EUAz+OCD9BVTTRYaT44HhN2EEV0N1ujrjypCC5jA/uOod0x3SRewFcr8TfiNPpWr6Hf6Nb+dPp+tO9xBEpZng+xky7QOvysCB/s1xvxo8bJq/w5h8beGb4L4h0CeO5Cq+S0assm33XhJFPoW9WFVfoc1Gg6jV9E9L+f9fmYn7ZHwbstW8KyfEjwpDjU9OCrrSRrj7Xbr8v2j3aPjce6dfuCvFbT4M319+ztHJLparPdA3drdcBxcAfIp77HUCP03EHtX2nceKYNe8AxazpttFdQX9kt0tq/KzRyIGaI/VWK/WvNdC1HRo/Bp0bT7g3Vixb7CxPMidfJb+7MmMFTjdjcM5ONKbs7nO49GfnIwKsQQQR2NJXqXxp+H8/hrxlc+INLiabw/qUzTQ3CAlYJGOWhf8AukHOAcZHuDjy2tznasel/CT4t3vw51OfTdStf7X8J6lmPU9IlUOrKw2tJGrfLv28FT8rr8rdFZbvxg+D9l4e0yD4ifDu5/tfwFqWJIpoiXbT2Y48uTPzbN3yhm+ZW+R/mAL+T1618E/iBpGh3t74B8bWEOo+D/ErxwXaXE2xLOQnas4ywVRyu9hhhsRg2YwD81mmCqYSq8zwK97TngvtxXXp78VrF9fhd7no4atGtFYau9Psv+V/5PqvmeM0V2/xZ+Hd98Mfide+HLk77Rs3OnzGUSNLas7CNmwBhxtKsMD5lOMqQTxFe1hcTTxVGNei7xkrpnDVpSpTcJqzQUUUVuZhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAHp/7Tn/J1Pin/ALdP/SOGij9pz/k6nxT/ANun/pHDRXicP/8AIrwv/XuH/pKO3MP96q/4n+bD9mP/AJOp8Lf9vf8A6RzV5hXp/wCzH/ydT4W/7e//AEjmrzCqw/8AyNK//Xul/wClVRVP91h/il+UAr6d+G9v/wAKW/Za1f4o3cPleJfEmLLRvMi+eGM7vLYbojjO2ScgkpIscPIJrwPwL4RvvHfxG0jwlp7+XNqE4jaXAPkxgFpJMFl3bUVm25BO3A5Ir1b9prxZDq/xXi8I6UlpDovhiBbG1htChiWQqpk2hVGzbhItmSFMJ6EkVw51H+0MVRypfC/fqf4ItWX/AG9LT0TN8E/YUp4rqvdj6vd/JfmjxSiiivqzzApQSGBHXtSUUAfS/wAHVtfCfhzRpbmM3HiDxSZdQYycmDTLQOy5J5HmTRE477EPavafiX4lGk+EfDbeaxjtdetjMOpzEkjn8crmvm7wHrLa18QdT1iJnaz0nwrHp8BI4jCwxRbfxPmn6kmvTPiPrVpqGiaokkmYdP1231JtgLFoGcJJgDk/ePTsw9a56jsrnp4Cnzy9P87fqdhPpXjbwZ4J03x/PZ2scOsB5LsJI7zJIZftELP8u0H5SgAJ64JyaPHt9pXxC8L2up+c9rqWnyJcWV/bnEsSOynIPcDIOPVc1wF/f/F3xlp2iXc/j3Uob7XrZtQ07wmLZJLFdODyfKZGADNGIh9/5iXUKQVzXqfg74Ua54l+C2ieKtJure6N9aEzabJmBxyyMEY8KwYMMHg8HIJIrjhXUFy1Gr/5ndKhPTER01svlp+lvkznfAs9prHxC1LxN8W7yyk0bSle4uZXkMdq7lEgRiuQFLbHJBPOMDriuM8Y6j8MLzxFIfgr4zs9Qa+Y239gBZhIQ2cxIrriSP7xXBymT1B49n8b/DWJPgDaa+/gaC41XQLmKW60TWVZrW9bMcDXEmxwWRYgCOflzJ7mvK7L4AxXWtX9mLVntZNCeeBrtUgu4dQ2R+QY2DEqgnyFI6BnByMVkqt58zf+Wnc7aGFm6Tr0rcsdHfr/AFdf0jtvh1r9xpvwG8E287OtxFPDZFH4YAXDxEEH0U/pWNa6dov/AAsLxPYzaZZXUE7rfws+VIEozztI3JvDA5zgkGub0vUZz438LeDhqlxqTafM2oahfTyF2mKO0jOSexyn4t61xWteL7vTPifZ6hazAmCe406VG+68TMsig+wEv6V6FKV1c4sXhLTjGPxO7/y/D8zsvGq6rc6Hcaz4GuUt5Y1aG80OaFZoZ9vJRomBG7g4P8WB3Ir5W1C9OoajJdtbW1uXOfLtohFGPoo4FfQd34lmsvGml6xbuYoNSuvskqZ4L8Oh/BuPofavEfHFtaWfxL1+1sNv2aPUJ1jC9FXeeB9On4V1W0PEqqzMCiiikYn0npVv/wALw/Y9n0NIfP8AFvgja1psizJNbhTsjG2In5o0aMRqcs8EbMea+YK9R+BvjaTwL8bdI1F5oorG9kGnX7TSLGgglZQXZ2B2hGCSE8Z2YyATVb47eB5PAXxx1jTUhhisL2Q6lYLDGsaLBKzEIqKTtCMHjA4z5ecAEV8pl0f7OzGrgPsVL1IeV378V6O0kuz8meniX9Yw8K/2o+7L/wBtf3afI83rQ0K2hvPFOm2dym+Ga6ijkXJG5S4BGRz0NZ9aXh2WKDxhpU00iRxpeQs7ucKoDgkknoK+nPMP0M8Tfs6/BfS/j7oXw6039m3XtQ0TVLMXFx4us9Z1H7PpzlpRscMzR5AjU8uD+8HynjPyB4u+Efh1P2rPEPwx8KePPDunaPZzutvrPiTUVt7VAsYdonmVSN6sWj6cle1fa3xF8Vwa5+074S8c+E/2o/AuieCtLgt11bRk8WKTelJ5HlAtkJjffGyJuY7hjp8orxay8T/s0+N/+CifiLX/ABR/ZTeEZ7ICzub5DDYXOoKIg8sgOBtIEvL/ACsw3HkisYtlux4z4y/Zo8a+FPhpd+P9N8SeDPGXh6ykEd5e+FNV+3LakkDL5ReMsucZxkE4HNXdK/ZU+IOq/Dbwz48/4SDwdYaHr+DHdalqTWq2YOQvns8YUFiNoVC7EngYyR9NX3j74d2n7L3xb8KS+IPgrp2rS2Eq2tl4FC2kN3uibywC7A3MwxyY1wuQMkkgeNfGXxh4Z1P/AIJ7/CPwxpfijSbzVbKcPe6ZbXsck9viOUAyxKxZPvY5A6+9UpNisjyfxj+z/wDEvwV8atN+Ft/pMN7r2qBG0/7BL5kN0rkgMrsFwAVbO4Lt2knjmvQrX9iX4qXvjpvCdp4m8Bz38Nv594sOrPIbA/LtjnRYjIjMGJU7Np2n5umfafiZ8avh3oH7Zvwe8cReJtJ1rR9O0aSz1G60u6jvPshlSSLc/lliCvmbiOuAcCus+B/hbwrbft3eNfHfh74paB4qj8Q2N3e29jo05uJLeKW4hdjcsBsj2ttRV3FmznC7TScnYLI+L/hx+z149+Jtx4hk0efRdN0rw+7x6hrWsXZtrOJ1zkb9pJ4BJO3AGCxGRnQ8V/sy+PPBnwmtfiJrWs+Fv7GutQSwhe2v2m373ZUnDqhjMJC7gwcnBGQDkD1/4UeMfAvij9mz4r/AzWfG2j+ENW1bWZ9SsNS1acQWtwpeIhTIeBzbgHuVcYDYIrttb0nwR4c/4J2fDrQ/EviKPXPC0Xi6CLUdRsRIsVxD9suGuPIyA7RgeYAwALBSwHIpuTuFjwS2/ZG8Ya1BdL4L+JXwr8Z6hbwtOdL8O+Ihc3LqOpCmNR3A5IHIrwGaGW3uJIJ43iljYo6OMMrA4II7Gv028JeM/gX4L+PNofDes/AbR/Cs9iy2F9pyouro/lguLi6LCOJCcgBiXbKjHUj87PiNc2l58Y/Ft3p88NxaTazeSQTQOHjkQzuVZWHBUgggjjFOMm9waPb/ANkb4JeFPi1qPi7UfF2i6lrMWiWaSWWmQTPaw3szb/3b3C42H5UAG4ffJ5CmvPfH3h/SPE3iW6j+F3wf8XeHLjR4pTr+jtJLqiWBRsby+zeijDbvM4GOvWvdvg3488O6x+xnbfDXw38VNJ+GXjvSNa/tUXmrXP2O31DEhdd8uMFcFFKnJ/cqCpU16z8SfiH8PNX+Anjqbwl47+GX/C09W0S30/Xbu11NbeK/RVYSLbPKVErFGlVccjKBjwlJtphbQ/N2vt74leCv2bvg94G+Ft7rvwTn8QSeLbFZLu7t/EN7byW7LHbl3WPeVkJM5IXKD5cd+PiGvvT41/tE+H/B3wv+ETeC7H4Y+OdUttMxO2pxR6pPo8scNrt2eXKDA7HdnPJMQ/umnK90JHBfFf8AY8aH9qSw+HPws1a0t7bVtIfV4I9cuHxbCNyjx70R2YfdKkjPJBPGT454I+AXjHx63jwaPqWhw/8ACExvLqP2uaVfOC+bnydsbbj+4f723qPfHqXwN/aLu9X/AG2rL4ifGHxDDBFdWE2lrdFPKtrFSN0agD7ibgRk55fLHqa9R+HB+GHw1tfjzHP8ZvBWrXviOynnsUs9RQRmNlujGgdyFkmJkwUj3bcLk/MBSu1oOyZ8tfD/AOCb/EDwqNaj+K3ww8OO07QLp3iPXfsd2SuPmEflt8pzwc84NTa3+zl8UtC+OOk/Cq40m2n1zWE83T5ba4DW1zFhmaVZDjCqEcnIBAXpyM+3/B24+Bth+yfZ6hZD4Rn4gxXUjawPiRC1wvkh3x5EQBdzs8raIxgndnmup+O/xL8K6n8cfgt4g8BfFTwros2n2F1v1a0VLq305miTZFNBEzmJH5j2n7oY9dpo5ncLI+cvHP7OHirwN4a1XWZPGfgHXhpBA1Ky0PW1uLqzO8RkSRMqsCGYAgZIrxyvuX4oap8J9Y/Z+8X6j8TNT+CmqeN50L6He/Dssbyac5Ia5/iyWwW3fLjd3xXw1VRd9xNBRRRVCCiiigAooooAKKKKACiiigD0/wDac/5Op8U/9un/AKRw0UftOf8AJ1Pin/t0/wDSOGivE4f/AORXhf8Ar3D/ANJR25h/vVX/ABP82H7Mf/J1Phb/ALe//SOavMK9P/Zj/wCTqfC3/b3/AOkc1eYVWH/5Glf/AK90v/Sqoqn+6w/xS/KB9Afsr2ltpviTxd8RdStobiw8NaNJK6BA9wrvl90IPAPlwTKTuX74HQnHi2qale6zrl7rGpTefe3s73NxLtC75HYszYUADJJOAAK9x8A/6D+wF8QtTsf9GvZtWjtZbqH5JZId1ovlsw5KYllG08Ykf+8c+B1zZMlXx+NxT3UlTXkoxT/FybNsZ7lCjSXZy+92/JBRRRX0x5oUUUUAe6fCeK2svg1eXxZVn1bxJa6MX7ovkvIo+jEsPwrQ8RafqdpoK+ICxktJrco0XQvGcxlfYhVXB77R0IBrxLTvEGr2WhXGh2Uzi3urmC72Lncs8W4RuuOjASOPx9hXv/hLxba+M9Mi8N+IJIIL/UIJrRY1AVUvEkaREAzx5sc8oA/vxbe4FZTStZnfhMR7KcZLp+XU94+Gklp8QvhN4Tu7vQbiC406NgLmayXy7olyJSjElWR3UuV4KSbuMHn2a68R+EPh54d0qz17XItLhl3R2sUys8lwwO5goVSSRuyQB0x2FfFXwj/aEufglrWoeCfFelnU9DjujMIlcRz2RfG54i3DISMlDjB5BGTn6TvvjZ+z78S9ItNP1HxpZaTdwyJe2qaxEbWWB9pww3jYwKsQQGIIP0NeFWpTUn1R9HVxEXy0Zu0E+mu76HoNh8R/DHivXIfD2i/brlruCYieW0aKEhFBKnfgncpPbBwwrkfGfhLxNaeHbxPCdtp1tdXCNE9/NiJbKLBzIAq5YgE7RwAeSexoRfEj4N+CtXjvf+FgWmv6q8ZitNP0c/bJWLYzsji3fMQAMsQAM+prxn9on4/+OphYeFNGsh4f03VoGkllEokuzGGwyuw+WPjk7Sev3qxp05SaWxvBqlNrDO8HbVo858JzLoPhTVb5pxNqWr3P9n2c2MMYgcDHoOQT74rzXVr77b48uDkGJ712jIP3wuFz+SCp4dTvp7qKVJfLjtoGS1G04iLAhXxwMDLMOcsdvauZhtY0a7kluppJrWFpIrgYXaVIAHfIJOMe9e7T2UThxFaFPETq3v8AP+unyubXjXxas2vadb6Q4MWkyGYSdVkuCwZmHqF2qo9dpPeuHllknneaZ2eR2LMzHJYk5JNaWjapNZ6+LgRwypMSk0MiBo5EbqpBzx39RjipdX0y2WEahpQLWv3ZUDbvJfPTnnaeME9+D2rq5m5WZ8zNJx5k9b7fqYtFFFMyCvoD48zyeOf2ffhv8UmWE3LI+l6jcSxLHcXE+CM4QY8sPb3LAZGPMGFG5gPn+vfdD/4mH/BOzxd9v/0r+ztdj+xef8/2XMlrnys/cz5sv3cf6x/7xz8zxAlSrYPFr4o1FH5VLxa+9p/I9LAPmhWpPZxb+cdV+v3nztRRUlvbz3d3Fa2sEk88ziOOKJSzOxOAqgckknAAr6I80joq6NI1YveoNLvS1hk3YEDZtsNtPmcfJg8c454qlQAUUVZutPu7O1sri5i2RXsJuLdtwO9BI8ZPB4+eNxg4PGehFAE2iaxfeHvE2na/pbol9p11FeW7yRrIqyRuHUlWBDDKjgjB717Td/tZ/ERfCmo6L4Z8OeB/Bz6lGYr3UfDWjLZ3VwCCDufcQDgn5gARngg15Q3gTxpFdWdvc+FdXtGvbiO0t2u7V7dJJXOEQO4Cgk+prnqHHuCfY7v4b/FXV/hodShs/DvhbxBYal5RutO8SaYl9A7Rb9jAEgqR5j9CM55zgY0fin8dvHfxcs9N0zxC2mafoul/8eWi6Nai1s7c425CZJJA4GScAnGMnPmdFKyvcLhRRUrW1wtml20Eot5HaNJip2MyhSyg9CQHUkdtw9RTAioorVuPDPiSz0WPWLvw/qsGnSKrpeS2kiwurfdIcjaQcjHPOaAMqipzY3o0xdRNnOLNpDCtyYz5ZkABKBum4Ag464NTXGj6taXd1a3el3sE9ogkuYpYGV4FJUBnBGVGXUZP94eooApUVoy+H9eg0VNYn0TUYtOfGy8e2dYWz0w5GD+dEPh/XrjRX1i30TUZdOTO+8jtnaFcdcuBgfnRYLmdRU5sb0aYuomznFm0hhW5MZ8syAAlA3TcAQcdcGoKACiiigAooooAKKKKACiiigAooooAKKKKAPT/ANpz/k6nxT/26f8ApHDRR+05/wAnU+Kf+3T/ANI4aK8Th/8A5FeF/wCvcP8A0lHbmH+9Vf8AE/zYfsx/8nU+Fv8At7/9I5q8wr0/9mP/AJOp8Lf9vf8A6RzV5hVYf/kaV/8Ar3S/9Kqiqf7rD/FL8oH0T4o/5R2eAv8AsOy/+jL6vAq998Uf8o7PAX/Ydl/9GX1eBVz8M/wsR/1+q/8ApbNcy+Kn/gj+QUUUV9KecFFFaGiWL6jrlvaRxiR3cBUP8R7D6E4/DNJtJXZUIOclGKu2dF4W0C8u9QtLCw8tNTvpI4lnlcIlqsjBVyx4Vm3Dk/dU56nju/id8N9D8AeFdK0eWzv5vF3lm6vL+21NJLJEWVgFhREy5K7TvL5zu4BGB1nwtuPCWj/FDSNKn8Q6VHfI8rM9zZi+WWcxOApjOFLFjhcnghe+K+gpvD/hLTtBn1X4waTaWem2qvqcCy2otY1dcAMiqxI3HkRk/wAWNuMCvHrYqTknbQ+vWV0cNF0pNSdtbO+vb5HwV41sPHur+PbTw9450do/EFtBHJNc3IEM72zKHVrgjPOxgdxAf5gDkmr8q2mrPcwtHFaT24KQK/ykJwqIw/iGAoyOeM+orf8AF3iZ9X1HVPFkl295qOrSG6vJmPDMx+RF7hUAUYP8Qb2xm6hYm7tre3lJV5GLO6nBURqOR/wKQflXTd213Z5NGmlJ21snfzXT8ba/5HtltY+E/g78HdC1/RzZ3Or+ILBLhJJH8yTIG2V3BxsVXymwEAlcdmNeL6xq91r3i1xK02rai56JmbP0VQNxHvhRjAAFRLo1ze3NpHc31xLBFIkaozlggL5wB2BJY49SfU16X8DrrQbXW7i1urDUry/8QvhG0y4W0aGMtJudp2RgAoyxG5R8vO7pWUIKDcpas7KuIqzoxhT91N2Xn/Wnz36W8xkl1e7drSPTkQBtjSXbg5boflXjg8VkWKPb6peWeq2scSskkc6KPlUbSQ4+hAI/+vXpPivwy/gzxMdFk1jSdYWWFJ7W60ufzopIjkZLYHzAqQ3HXGM5Fcf4q0+SSN7qW4RnICsigjBXGQxA7jnGT90VtTqLmTWxhLC8+HlKz5016W7a/h8ziLNW+0BlGW6L/vHgfl1/CtywS4iEj28YkdF2zRsMiZOVIb8s57Gtjw54eXzPtUgD4+VBj5c98D+ta3h/SmHi7VLMLxGA2PQNgj+Zoq4hXduh34DIJWp+1Xxtr8G/0PONRtUtrrMBZoJBviZuuPQ+4OQfpVOvQfG/hd9Ni+0Rp+4mYumP4JAPmH0ZRn6rXn1dVGqqkVJHz2ZYCpgMRKhUWq/IK9/+AX/JC/jV/wBgEf8ApPd14BXv/wAAv+SF/Gr/ALAI/wDSe7rwOLf+RZP/ABU//TkC8p/3lekv/SWfOlb3gi4gtPid4curqeOCCHVLaSSWVgqoolUlmJ4AAGSTWDRX0B5x6naeMdEvtI1e2lMltcX1gzapLIyqLqWMxxxiLnLMV8xznks7cYGam1H/AIQ/+1rb+1v+Ea/s/wDtyL7D/ZezP9n4ff8AaPK+fH+o/wBZ+8+/Xk1FVzE8p6if7E/tTSf7Y/4RT+2tl9/x5+R9h/1S/ZPO8r91nzPM69tm/jNYPxBuI5/+EbiE+kyXEGkmO5XSmjMMcv2u4YqBH8oOGBIXj5sjgiuMoouOx7RrM+nr8ddN15bXwjbaf/wk0FwdWstaWaaWPz875I/tLhFx8xPlrjA6Dg83ZnQx4w0mXS7LRrrR/s0ghhu7i1gmjfZhmuDcHY0isQwDZRgMKByB53RRzC5T1uGytlg8U3OmXHhO/u0v9NSG7v7Wzht0DwXDSRoP9QCNoB2na2wsMttqtrWoeBk8XeHNNtLbSP8AhHXleS/mt4FMpX7fcbVaTBkVRGI8DhihXOflrzJbm4WzktFnlW3kdZHhDEIzKGCsR0JAdwD23H1NRUcwcp63ez6K3i7SCnhfw8u1LkGVdb0qSOQFAEZlWOOFShO5RKuXyQc4453x3Ho0WlWy2F/pd7eHUrlppbK3t4CIzbWhVSsHybVfzlBX5Swcjqa4aihyBItXHn/2dZ+Z9l8ra/l+V5fmY3HPmbfmznpv5x04r1fU7/Tf+ERuZC/h+COfwzZ2ov7bUllvZpUhh/cNb+a20b02k+WhAXO718eopJ2G1c9Uu7rwm/gyXwTH4glaa301ZYwYYhZm9j3Tu63HnfMSHlhHyAH5BngZ1tf8ReH9YvfHOp3OpWUt3b+ZZRL5y/8AExtmvopY/LOfnKKkinGfkMeOFNeK0U+YXKeoeIIdKv8AVPFPiK88RrPb3qyzaZLZ6tEjFScx28tptMuMFVx8qrtPUYqR00XWtbtNbutfWDRE0uG3jS11eK0uNPdIFV08h1Z5AXV+EX5t+d3UV5XRRzBY9Uu7rwm/gyXwTH4glaa301ZYwYYhZm9j3Tu63HnfMSHlhHyAH5BngZ8roopN3GlYKKKKQwooooAKKKKACiiigAooooAKKKKAPT/2nP8Ak6nxT/26f+kcNFH7Tn/J1Pin/t0/9I4aK8Th/wD5FeF/69w/9JR25h/vVX/E/wA2H7Mf/J1Phb/t7/8ASOavMK9P/Zj/AOTqfC3/AG9/+kc1eYVWH/5Glf8A690v/Sqoqn+6w/xS/KB9EeF/+Jh/wTt8W/b/APSv7O11PsXn/P8AZcva58rP3M+bL93H+sf+8c+B17z+yyf7cb4gfDr/AI9/7f0Jv9O+/wDZ9u6H/V8bs/at33h9zHfI8LurW5sb6ayvbeW2uYJGilgmQo8bqcMrKeQQQQQelc2SNUcbjcK9+dTXpOK6eTi/zsr67Y336NGr5cvzTf6NEVFFFfTHmhVuyv59P817VtkzoYxIOqA8HHoSMjPuaqUUmk1ZlQm4Pmjudd4ft7KPwbeXyQpPqks/2eEMf9SgQMxA9XztB9Fb1zW/r/xb+IfizwtF4Z1fX7+/skRYzDKo+dQejtjJAIB5PbnNel/CP9lrxn41+H6a1qesWXhuy1Ax3dl5sDz3EqAMFcoCoRDnIJOSOcYIJm8RfstfFDTfGlh4Y0+80PVF1EO4voZGgEMSY3STIwLKoyBld2SQo5NcFSpSc7N3a/A9OHtfZrlVlbp1PnVLhkMVs7blQxn6/Nz/ACFdraXCy+IFV5seXE20AHPzN82OPQCvbNU/Ye8aRad9q0fxpoOpXygM1rJby2ytj+FJCWH4sAPpXi3irwz4w8H69baP4k0W60PU7KLYiXB2mcbifMjb7rrghcoSMKKXPCr8LNMNUnhpXlHe35p/oWLqZ7FUZGVXh2ygPtzuxnj1GQOORXvXw28ZfDXxnFd3PjTS9G8PeN5LTGn32n/6Pb3TFAGMdvnyln7EgZIbjGOPnO31GJ5Ve8HlhVZTEuBwQfu5I4zjvWHqxZtPscOjyQklSG4Bxk4x055z2xUzoc63OmWPpqV4xdk7r8P8j6f/AGiJr2y8FeHLHXJ51162uJZobRktfJjtGhGVTyfmCBljA3YySTivJGnh1Lw9peIr1dS0+MyQC1tQftEYk3q77mXBUsVJ+bIIPY44Earr2qXpW+ubieWYASXN05eQKB1DEkngkc8c1t6rqb399ollIyRm1YiKZTt2Akcn3H6jNKEJUklua0HQxTk3Jxell0d9Gr9NNjn5db1Tw/4rka3eRbfeJUtJJN6eWw3Kp9OCBkV1E/jKz0W91TWtPWO4ub6O3S2jk6IBHuZmx6EgY7n6VxfiGX7W8N9MP9KmaTzTuLbgCADk8nncMnsBWJXXLDwqWk0clHOMVgXKlTnezunvZ2aur+T++zPSdP8AH0niWyn0HxJFbh51/wBFuo12BJRyoYdME8Z9+fbzmZDHcPGVKlWIweopgJByKdJI8shkdizMcknufWrp0Y02+XZnJjcyrY6MXiHzSjpfq12fp+o2vffBv+gfsAfELUrH/Rr2bVYrWW5h+SSSEtaqY2YclMSyjaeMSOP4jnwKvoD4z21z4M/ZM+GXgG9tpTc3UkuqyyTIYXt3ALtA0Zycg3pUkkf6vp82B4HETVWeEwi3nVi7eULzf5JfPrsPL/djVqvZRa+ctF+Z850UUV9CeaFFXodPTylkvLgwhhlURN7kHoSMgAH656HGDmpPsWm/8/11/wCAy/8Axyq5WK6M2itL7Fpv/P8AXX/gMv8A8co+xab/AM/11/4DL/8AHKOVhdGbRWl9i03/AJ/rr/wGX/45R9i03/n+uv8AwGX/AOOUcrC6M2itL7Fpv/P9df8AgMv/AMco+xab/wA/11/4DL/8co5WF0ZtFaX2LTf+f66/8Bl/+OUfYtN/5/rr/wABl/8AjlHKwujNorS+xab/AM/11/4DL/8AHKPsWm/8/wBdf+Ay/wDxyjlYXRm0VpfYtN/5/rr/AMBl/wDjlH2LTf8An+uv/AZf/jlHKwujNorS+xab/wA/11/4DL/8co+xab/z/XX/AIDL/wDHKOVhdGbRWl9i03/n+uv/AAGX/wCOUfYtN/5/rr/wGX/45RysLozaK0vsWm/8/wBdf+Ay/wDxyj7Fpv8Az/XX/gMv/wAco5WF0ZtFaX2LTf8An+uv/AZf/jlH2LTf+f66/wDAZf8A45RysLozaK0vsWm/8/11/wCAy/8Axyj7Fpv/AD/XX/gMv/xyjlYXRm0VpfYtN/5/rr/wGX/45R9i03/n+uv/AAGX/wCOUcrC6M2itI2FiwxHqEobsZoNq/iVZj+hqhNDJBM0Uq7XXqOv0IPcd896TTQJjKKKKQz0/wDac/5Op8U/9un/AKRw0UftOf8AJ1Pin/t0/wDSOGivE4f/AORXhf8Ar3D/ANJR25h/vVX/ABP82H7Mf/J1Phb/ALe//SOavMK9P/Zj/wCTqfC3/b3/AOkc1eYVWH/5Glf/AK90v/Sqoqn+6w/xS/KB1nwy8Y/8IB8WtD8XNB58NlOfPjC7mMLqY5No3L8+x225IG7GeM16B+0p4Ll8KfHO/wBQhtPK03XP+JhbupdlaRseeCzDG/zNzlQSAsidMgDxOvp7QE/4Xh+x7PoSw+f4t8D7TabIsyTW4U7Ixtiz80aPGEUks8EbMea4c3l/Z+OoZn9h/u5+Sk/dl/27LR/4jfBr6xQnhuvxR9VuvmvyPm2iiivqzzAr2/8AZo+Ccnxa+JH2vV4JB4W0dlm1B+V+0MeUtlPq2CWI6IG7kV5R4Z8Ma14t8Xab4b0Oye41DUZhDbx4wGJ6sT2UAEk9AASelfqb8L/A+ifC74Yad4Q0crItspkuboLtN3cNjzJT9SAAOyqo7Vx43E+xhZbs68JhnWl5I6+CytrKIH5Y44l4RflRFA4GBwAAOB2ArlvDtxJrutaz4kSP5Jbkafbn0htxg4+sskpP09q5n44/FbTvhz8LdR1GWVXvZIzFa24PMsrcIgHuf0DHtXc+AdFl8MfC3QNCvZTPe2tjGLuZuslww3zOfcyO5rwEnytn0EnyWvv+n9fkbMc0VhZxPfzxRmSRYlPQM7HCqPUk8Vn+LvBnhbx74Xl0DxXo1tqlhJyI5h80bf343HzI3+0pBrh/i9ri2j+GNPiuPKuJtUEyAHBPlxSMMevIz+FdX4a8Uw6zpiylglwgAmjz0PqPY0leNmip4aUqftO58M/Gr9nbXvhNdvr2hW/9veE3fAuGiBuLIk8JMB1HYSAYJ4IBxnxr+0bPU9Lms1RY2cB4cAcSDoAR6gkfjX6m+NY7TVfhp4gsLsK0M2m3Ctu6f6tiD+BAP4V+Y3iXQbKz8RZ81bcXipJG+MCGRs/K47KWBB7g49a9KhiHUVpbk4bANRdWDWjs0+qkmvl29WjloLy9jPlI7fLwF6/oa0BPczspjs5WuNuCxXCr756Ae5qnOhM09vfReVqCSHcD0J9P8DSTWyJaWUpkkkilDmaMSEAsr42nrjgqfxr0oWkrnhVYunNwfR21/Uo6tJA16IbeXzY4VCeb2c9WYe2Sce2KoV0sehi+1DzxaqlsFGIIZAp6f3mz169zTbjwzcteSSC2e2tiAUCfvj06HB71p7RGTw7eqknrb/g69PU5yirEtlPDAssqqu5toQsN3/fPUVX71aaexhKLj8SO1+EvguXx78X9F0D7J9psjOtxfhi6oLVCGk3Mgyu4fIDx8zqMjOa1/wBo/wAY/wDCYftAar5cHlW+jf8AEmi3Ltd/Jd97N8xBzI0mCMfLtyAc16P4BT/hSn7LOr/FG6h8rxL4jxZaN5kXzwo27y2G6I4ztknIJKSLFDyCa+YK+WwUv7RzSrjP+XdFOnHzlo5v8o+dn2PRrr6vhY0ftT95+n2V+bCrmlxpJqieYodUV5drDIYohYAjuCRz7VTq9pH/ACEz/wBcJv8A0U1fTx3PLew9mZ3Z3YszHJYnJJ9aSirWmadd6xrdnpOnxGa7vJ0t4Ix1d3YKo/EkVqIq0V7F4/8AhXaaX4m8NwWum3vhbTL27fRp7zWYpYleWFwDefvcYSVHRwMhQQ4BAHGddfDCxtUktX1G5sYn1PTbQahrlgLNkS4W73OhS5kiaL/Rx8xJyRgMgVt4B5dRXq0Hw/8ACGlzeK7fxFd+J4YrLQ4b+1uptHiSRWa+ghMkca3hSVcPsB34O9zwY1DUNf8AhZb+H/Ar6xdeLtK/tSO1gu30s3VpvZZghCIq3BmMgWQMQ0KjCsQx4yBc84orvfG3w+0zwvFrn9l+JpdWl0PWRo1+slh9mAkbzijRnzG3D/R5A2QuDjG4HNXdB8IaDrnwKa4itWXxVLqN61nOJWxPFbW9tI9tszt3FZpXUgbiYwvO4UBc81or2i8+Dmnav468T2GlX8mjJb6xd2Gl29x9n+zzCLkIJJrpZnYZAISKQjKkk5wOW0v4d6Ze6JbveeJ5LXVrnRrzXILFLAyRmGCOZwjS+YMO/kNxtICnOSflIK5wFFehat8MRp/wwPiuHV5PtMENtPd6ZeJbRSxpNtCsqR3Mku3LrgyRR5DA+1avwo+GZ8Y+HtRvrjw3qmqrdzjR7GezilZLG4eNn+0ylOAiN5KkP8u2Vj/DkA7nlFFdV4r0O00fwp4Rnjs2t729sLiW+3M2WlS+uIRkE4UhY0XAx09cmum1PwGzeB9GsdC8MwXervbR3GpXS3rfaLKSTdIgnQt5SQNAY2DYGCSGcEFaAPL6K734W6L4Y1m/8Qr4rg3WdvpO+OfzXT7JLJd28An+UjdsEzNtOQcciunvfhdpUWk+E/CskX2HxPda9HpOrX+5pRE8yo6oI9wU+WsiZxgltwJ6YBXPG6K9B8D+F7WWxttfvfJuory08Q24tJoAyxva6V5ySgknJ3TqRwNpjBByeNPxH4K8JRvqaeGrq4eW18MabqUsWoWvkpHJP/Z43xyi5I3Obp2beuxMsqg/K6AzyuivV/CPhLQdM8L+J7vxcng+e6srqwhguNR1C6u7NFmW5ZlD6W7FnPlJ1JA2nOCeTTvCPgy48J3usa9LJZRyeHDqtu+kWck/kt/bRtN22a5XedgCAHaNj5I3pukBXPKKK6+98DfY21wDVN40vQ7HWs+RjzftJtP3X3vl2/bPvc58voN3Fbx54a0rwh421Dw1p2uT6tNp11NaXUz2YtkDxuV+T94xbpzkDByBuHJBnM0UUUAFFFFABT7lRLonmN96CZUU/wCy4YkH2BXI/wB5vWmVJL/yL8//AF8Rf+gyUnsBl0UUVkUen/tOf8nU+Kf+3T/0jhoo/ac/5Op8U/8Abp/6Rw0V4nD/APyK8L/17h/6SjtzD/eqv+J/mw/Zj/5Op8Lf9vf/AKRzV5hXp/7Mf/J1Phb/ALe//SOavMKrD/8AI0r/APXul/6VVFU/3WH+KX5QCuv+GPjnWPh58TNP8S6NbPeSITDNYh3UXcTjDRnb1PRlyCAyqcHGK5Cu++FHjO48GeLJrq1sLK8e4jETxXMKuXjzlkVj90njpnOMHjivTxFCniKUqNVXjJWa8mc9GUo1Iyg9U9Dtfjv8ONL0a/i+Ifgp7F/CGtSqscNsDGbK4KFmiMbHKhtrsFwNh3IVTau7yzRNPju9QWS8dIbOIGSWSUNsIH8OVHUnA/HtXtvi+wnfwhqPjH4eXdyfCl227UtJgG19LkUhtkkXTyw2Crj7vGeADXl1raXWqTbLZ729UHeVi5I45OB09zXLl1KrhMPGhVnz8uik92ul+7WzfXfc7q1OFarzQVr9PPrbyOmHiK60zXNKufDt9cWBsAs1tNDcHbHt6qmDgZGQQeoJyGzX1z4g/aT8FaX8KYvGqXjKlwGSO0YAz+cOsITPLDIyfugEEnBGfhTc+nu9qlqwDkcep5HPHrzgf0rj/EV3FdahHbQyi4eLKvOrZV2OOB7Dpnv9MU62HjUSb6HV9flSk5cqu/kl2svT+u/uPgzxN4j/AGhv2vvCP/CTh00eLUPtiWecxRww/vWGT99m8sKT3yAABgV+kM+prFG8sz7MAs5PGO5r8upksdL8OJYPaNHd2spijEJLRqgYnIkU88knpnqc9q9It/2gPH9h8LU8IJFDdCC2aFNallkeVF5ZZH6glQQBk/wr6VhWwznZR6HRStBuVV8zaTbWtvL1/A9z8Y63a+KvEt9ruoTCDStPRorS4Y48oqcvOD22lQoPfa/UGovh18QIPEmgx67pE/lXMLmG5ixgo49V/usMMPY46g18XDxfq114ag0C71O7NnBkxwyzu0Oc55T1yc+nsKs+DPG+reC/EkmqabqBjaZDHMjJ5sco7B0yM4OCCCCD7EiqlgJcrXXod1POMP7qWz38j7j+KvxTtbD4Sahp7EQapqcf2O3QtlWyRvbrnaFzn6gZ5FfG2v6rb6w189+rS3eBGJHkyD87s5Dd+doGeeTisvxH4q1zxTfvqV/ey30zDaJjgCNf7qIv3B7fjya58zT+T5T8KBjnjitsNh5Uo2Zx5lisM+VUldp6u+lu3bzuWr24kv4EvZ8/aY8QzNxk4AAY+/T8zVi3tJbvS4hHhAjs0hfqXwB8o9AAPqT7CsyG8t7e2u1Pzu6KqAdN2ep+gz+OKh/tnU/J8pb2VE9IztznrnHWupU5JWicVTF4erUVWunJta2792/Q6iDSNRAAiuGUdsIcVYVNatiwCRyjHzfKVJH5VwrXE7/fmkb6sTSx3NxE26KeRD6q5Bo9lPuQ8XgnoqLX/bz/AMjvfNtrlxHdweVP1VuhH0I/xqfwb4P8Pav8VdKsvE+r2+n6QZzcXtxeuypPGvzGLcCuwsAVLFhgEtnIwcjwtp/iTxJa6lPBCJrDTLY3N1ezsES3H8ALnqzsNqpyTz2BIfe3G6NLosCoKogx947uT7jGR+Jrkq/vVOhCfLK1rreN1o/Vbq/kKSpxtUhdwetpev4+q6XJ/jV8R4/iF8QANJhitfDekRnT9HtbfckQgViBKIyAELgLwFXCqinOzJ83qS4EYupBFnYHIXPpnio62wWDpYOhDD0VaMVZf13e78zz61WVabqT3YVe0j/kJn/rhN/6KaqNPhlkguI54m2yRsHU4zgg5FdSdmZMu1d0jV9Q0LWYNW0q4+z3kBJil2KxQkEZAYEZwTg9QcEYIBqvGILtd8EsML/xQyybNvurNwR7Zz9cZL/scn/Pez/8C4v/AIqtSS7pniTVtIsXsbOW3e1e5ivGt7q1iuY2ljDqjFJVYHAkcEYwc8g4GNS6+Iniu9CR3N1p720csMqWX9mWotVaHzvLAgEflhQbmclduGLkkE4I577HJ/z3s/8AwLi/+Ko+xyf897P/AMC4v/iqBaHQj4i+KxrP9pfarDcLQ2H2X+zLX7J5Bk8zy/s3l+Tt8z58bPvc9earXvjTxBqXhxNE1CWwurdI0hSabTrZ7pI0I2ItyY/OVQAAAHxt+XpxWP8AY5P+e9n/AOBcX/xVH2OT/nvZ/wDgXF/8VQGhf1HxRrurHVzqF9539sX66nffukXzrhfNw/AG3/Xy8LgfN04GEsfE2u6ZbabBYag8CabfNqVpsVcxXDCMFwcZPEMfByPl6cnNH7HJ/wA97P8A8C4v/iqPscn/AD3s/wDwLi/+KoDQ6yD4sePbbUbm/i1qE3VxeS37TvYW7uk0uPMaNmjJjD4AZU2qQMEVe0T4oPonw3n8ORadc3F7JZ3Onx3dxPC0cEE4YOiKIPOAw7nb5xTcd23NcL9jk/572f8A4Fxf/FUfY5P+e9n/AOBcX/xVAaG/e/EHxbqHhmXQLvUoXsZoYYJgtnAkk6RFfKEkqoHcrsUAsxIAxnBIrHm1nU7jStP02S6P2XTzI1rGihfLZ2DM2QASSQOTk4AHQCoPscn/AD3s/wDwLi/+Ko+xyf8APez/APAuL/4qgNDR8Q+Kte8V3cVzr16t1LF5uxhDHFjzJnmfhFAOZJXb/gXpgVrW3xP8bWdhHaQarBtS3FmZHsLd5ZLcLtEEkrRl5ItoA8tyVwAMcCuY+xyf897P/wAC4v8A4qj7HJ/z3s//AALi/wDiqA0JbHVr/TrXULeyn8qLULf7JdLsU+ZF5iS7eRx88SHIweMdCRU9l4j1vTrK0tLG/e3itL0ajb+Wqho7gBQJA2M5G1eM44qn9jk/572f/gXF/wDFUfY5P+e9n/4Fxf8AxVAXR0V78RvF9+bfz9Rt0W3S7SGO2sbeCOMXcIhuMJHGF+dBg8cHLDDEmq1z438SXei/2VPeW7W5sV012WzgWWS3V4nSN5Qgdwpt4du5iVC4GASDjfY5P+e9n/4Fxf8AxVH2OT/nvZ/+BcX/AMVQGhLDq2oW+gXeiw3G2xvJorieHYp3vEHEZzjIwJZOAcHdznAxp6b428SaV9lW1vLdo7aybTo4LmzguIjbtO1wY3jkRlkHmsX+YEg4x0GMf7HJ/wA97P8A8C4v/iqPscn/AD3s/wDwLi/+KoDQ3Z/H/iy58LS+HptRiawmtYrKVRaQiSWGJ0eNHlCb2CGNNuWO0DaMAkHG1bVL/XNfvta1Sfz76+uJLq5m2qvmSOxZmwoAGSScAAVH9jk/572f/gXF/wDFUfY5P+e9n/4Fxf8AxVAaFeirH2OT/nvZ/wDgXF/8VR9jk/572f8A4Fxf/FUBcr0VY+xyf897P/wLi/8AiqPscn/Pez/8C4v/AIqgLlepJf8AkX5/+viL/wBBkqQ2uwbpbuzRB1YTq+PwQkn8BVG8ulmCQwgiCMkru+8xOMsfTOBx0GB15JUnZD3KtFFFZFHp/wC05/ydT4p/7dP/AEjhoo/ac/5Op8U/9un/AKRw0V4nD/8AyK8L/wBe4f8ApKO3MP8Aeqv+J/mw/Zj/AOTqfC3/AG9/+kc1eYV6f+zH/wAnU+Fv+3v/ANI5q8wqsP8A8jSv/wBe6X/pVUVT/dYf4pflAKVWZHDoxVlOQR1BpKK9k4zufDnxF1XStXguVnFtKAEkljBCzjoPMXOD9cdzkHJrtxp1n4lkm/4RrVE8PSTMZJLO2iHlmQnIPykEJnoBkDsB0rw+tDTtb1LS5UezuXQocrz90+3pU8qtax10sXONTnlJ6720bOq8VXHibw1pt9aa3dXQmlTyUYvuWctxuDY5woPPBHAOK5HQtCEZTUNQQZ2+ZDA6BwfeRSR8vTjHOew6+wacPEXjHwrZ+JJIbHUriEyJHbRtulh243SLG3DSHHVSWCgYAzXK393bTwki3eaUHd5ao+5j9MZz+tYuNntY7K0lWlzuo5JbX3/P8jMhimuUZ/MliBHyiMsokPHOD0HPPT+tWr6W9t9AvIJr+RJXQF7KLIVF3AZkzj5jxhQDgHk9q6bRdE8TSw3txa6bPpb7F2Xd1CUaCDq8gXGRtUYBwAAScjrWR4gg8Jab4cuY7XWJ9U1afChmOQvzglm28ZwO5PWiKvKzNU406LlCXvNPray1XfVvt0T6nB0UUV2HhiqzKcqSD6ihnZjlmJ+pzSUUAFblp4ZuJLAXuoXMVhE6F4UkBaafjjZGOcHjk4HPU1Q0ya1tbwXV1GJRHysRGQzds+wr0Lw14G+InxM1KG40XwlNLbXPP9qXytHahA4Rm8w4VtpJyq7m+VsA4NceMxdPDQdSrNRiuraS/E9HB4anUV5ay6RV/vdvy09Tz+PSbljh3giPo8gz+QrQTR7MeeGld8jEQCncp9eBg17v/wAIJ8EfgtIl78T9dHijxKmyT/hH9MXdHC37psNHuGcbiQZmRZEJ/dkivHPiL8Wdb+IF1BbrYWOgaLaK0VrpOlp5UapuyvmEY8xgFQZwFG3KquTnysFnUsxqr6rSbpfzv3U/8KavL10XmXUwlPCxftpe92Wr+fRfiyzNr9xb+H00K0knttESZ5UtJZViRnYAb5MBfMfaoG4joMAAcVy2pavHvfyZBNMw2h1BCRD/AGc9T71gEknJOaK9enQhDSK/rzOapiubZa+bvb02S+4KKKK2OQKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAPT/2nP+TqfFP/AG6f+kcNFH7Tn/J1Pin/ALdP/SOGivE4f/5FeF/69w/9JR25h/vVX/E/zYfsx/8AJ1Phb/t7/wDSOavMK9P/AGY/+TqfC3/b3/6RzV5hVYf/AJGlf/r3S/8ASqoqn+6w/wAUvygFFFFeycYUUUUAaOk69rGhzmbSdRntGPXy24b6joa6t/jJ8RJLFrVvEMu0rt3hFD4+o5FcHRQO7R6F4H+NXj7wDrs+paTqMN2tz/x8WuoRebHLgMByMOuC2fkZckLnIGK9Kn+PPwo8czK3xS+D8T3JjSSfVNHmAuLidVCDPMTiPbuwrSvjagw2Aw+c6K8bG5BgsXV+sSi41P5otxl98Wr/ADudlHMK9KHs07x7NJr8T6J/sP8AZI1Afb/+E98V6V9o/ff2f5MjfZd3PlZ+zPnbnbne/T7zdS7/AIUF8Mv+jjvCf5W//wAlV86UVzf2LjKf8DHVF/iUJ/deOn6mn12lL+JQj8rr8mfRf/Cgvhl/0cd4T/K3/wDkqm/8Ib+yrYH7DqXxZ8QXF7b/ALq4ms7djDJIvDNGVtnGwkEjDsMY+Zup+dqKP7GxtTStjqjX91Qj+UXcPrtGPwUI/Nyf6n0ZbfGf4EeDL6C98A/Bia8uTIsrz61cAPbvGcxtCzmcqcliSuz7q9eMcX4x/aP+KvjDyo/7d/sC3jwfJ0Eva72G75mk3GQ5DYK7tvyqduRmvJ6K0ocNYClU9tODqT/mm3N/+TNpfJImpmWIlHki+WPaKSX4BRRRXvHAFFFFABRRRQAVr+FVsn8caQmowrLateRLIjEBSCwHzZBBX1HcZHGc1kUUIGev6Jpos/FGqJbwX2mwRa5Zf6HLsKyAzPhh+7BC45UA4werVWtfDmi2vxVsfPtZNTtr/wC1N9pkZDbvLtc+WEKnlT8uGIO7BwMYPlNFac/kRyeZ6Bo/gjTNShWS4h1W2aS7e3ljMiZ01VUEPPlBnJ9k+uau32g2mofCvR7nzZru4srOcxWtqwVnXz2zKcg5RccgDPI6DmvMqKXMuw+V9zsdP8FukGqpqtjf3WpWEkcf9lafKnmkOM78hXyoGOgPXtVm08F6XceF01B57xS9nNcvd718i2kQkCBxtyWOPUHngGuFopXXYLPuejS+DvCtro011P8A2xJJbafaXsmy4jVXMxClVBjOACc5Oar33hXTtH1w6DKTMLzVlt4pXA8wQoAWwccFmkVc+qGuBqRridkiRp5CsIxGCxwgzn5fTkk8dzT5l2Dlfc9Mu9I0648GS3UulQwRCCORZ44o40jLQSSfK4XexV0SMh2bJJ6EjGfd+C9AXSJPIub+G7h0211CSaaRGi/esAy7QgIAznO6uSvfEGrahaNb3dxG6uQZHEEaySkdN7hQz/8AAiazKHJdhKLPRtY8C+HNJvLASX2pNby30dtJMI32SRsP9YkhiCAg/wAIZ8jvS6j8PdI0vSLy5utUmElkoguBuXCXDtGY+3KbJCT3yp5FecUUcy7D5X3PX7jwlp1n4Un0INe2VnPrVvEb+8dWSZdh/eR4UAKc46ntz1rEHgPSG1XT4JZdQsWuPtObC4dDcSeUMoUO0Ab+2R9M153RQ5LsJRfc9Y1rw1aX1vpFtNaalE9novmxaXvX7VK3mn5M7OoySfkzjtVKx+Hmi3Ou6lYLc387W/leUFJRELJuZZZlikVWU8cgf0rzSijmXYOV9z0Cy+H8F14FutYlMsU0NnNdpLHP5sT+WT8pAiCrkD/noT3xjpq23h7T9E8Ca5NFDqFxBPpttJJfb18mbc6syR/LwR05J9wO/lVFHMuw3FvqelD4feH01W0tZ9YmVdQkeexYOv7y1EYZc4UnezNtGB/C2AeBVaTwZoFrqmoC5fVmt7XSjfmAq0EgcOF27pYV3L/tBB+lefUUcy7ByvuenP4Y0Ow0DxNaW+mXmozJFZXUBDoZ443UsdpEZwFOdxAwRj7uMmhceArOPQrrVozfNaJpttdQz7lKPLIwDrnbyBk8DkcZrgKKOZdg5X3PRm8E+GpfHOqaDbT6in9nRFtssweS6b5eECQkqBk5wrk8cDmuP8S6XbaN4muNPs5biSGPaVNzC8MgyoOGV1U8Z64Gevesmik2n0BJrqFFFFSUFFFFABRRRQB6f+05/wAnU+Kf+3T/ANI4aKP2nP8Ak6nxT/26f+kcNFeJw/8A8ivC/wDXuH/pKO3MP96q/wCJ/mzjPhx4tk8C/FfQfFiPMsdhdo9wIY1d3gb5JkUPxlo2dRyMZyCDyOh+MPgm18C/FS7sNJlhn0K+jXU9InhkEiSWkuSm1t7FgpDIGJy2zd0YV5tXo3gXxl4eudLtvAPxOS7uPCf2jzbS/tCPteiSMQXeElWzC/8Ay0iwQfvqN4+asXTqUK6xtJc2nLKK3avdNd3F3suqk7a2TVKUZ0/YS01un2fW/k9NfJdDhaK9dn+AGvazMtx8LvEOh+PdOaNJGlsLyK3uLYOoKi4glcGIsd4C5J+RtwU8VF/wzR8bf+hK/wDKlaf/AB2muIcst72IhF9pSUWvWMrNfNA8vxPSm36K6+9aHk9Fesf8M0fG3/oSv/Klaf8Ax2j/AIZo+Nv/AEJX/lStP/jtH+sOV/8AQVT/APA4/wCYf2fiv+fUv/AX/keT0V6x/wAM0fG3/oSv/Klaf/HaP+GaPjb/ANCV/wCVK0/+O0f6w5X/ANBVP/wOP+Yf2fiv+fUv/AX/AJHk9Fesf8M0fG3/AKEr/wAqVp/8do/4Zo+Nv/Qlf+VK0/8AjtH+sOV/9BVP/wADj/mH9n4r/n1L/wABf+R5PRXrH/DNHxt/6Er/AMqVp/8AHaP+GaPjb/0JX/lStP8A47R/rDlf/QVT/wDA4/5h/Z+K/wCfUv8AwF/5Hk9Fesf8M0fG3/oSv/Klaf8Ax2j/AIZo+Nv/AEJX/lStP/jtH+sOV/8AQVT/APA4/wCYf2fiv+fUv/AX/keT0V6x/wAM0fG3/oSv/Klaf/HaP+GaPjb/ANCV/wCVK0/+O0f6w5X/ANBVP/wOP+Yf2fiv+fUv/AX/AJHk9Fesf8M0fG3/AKEr/wAqVp/8do/4Zo+Nv/Qlf+VK0/8AjtH+sOV/9BVP/wADj/mH9n4r/n1L/wABf+R5PRXrH/DNHxt/6Er/AMqVp/8AHaP+GaPjb/0JX/lStP8A47R/rDlf/QVT/wDA4/5h/Z+K/wCfUv8AwF/5Hk9Fesf8M0fG3/oSv/Klaf8Ax2j/AIZo+Nv/AEJX/lStP/jtH+sOV/8AQVT/APA4/wCYf2fiv+fUv/AX/keT0V6x/wAM0fG3/oSv/Klaf/HaP+GaPjb/ANCV/wCVK0/+O0f6w5X/ANBVP/wOP+Yf2fiv+fUv/AX/AJHk9Fesf8M0fG3/AKEr/wAqVp/8do/4Zo+Nv/Qlf+VK0/8AjtH+sOV/9BVP/wADj/mH9n4r/n1L/wABf+R5PRXrH/DNHxt/6Er/AMqVp/8AHaP+GaPjb/0JX/lStP8A47R/rDlf/QVT/wDA4/5h/Z+K/wCfUv8AwF/5Hk9Fesf8M0fG3/oSv/Klaf8Ax2j/AIZo+Nv/AEJX/lStP/jtH+sOV/8AQVT/APA4/wCYf2fiv+fUv/AX/keT0V6x/wAM0fG3/oSv/Klaf/HaP+GaPjb/ANCV/wCVK0/+O0f6w5X/ANBVP/wOP+Yf2fiv+fUv/AX/AJHk9Fesf8M0fG3/AKEr/wAqVp/8do/4Zo+Nv/Qlf+VK0/8AjtH+sOV/9BVP/wADj/mH9n4r/n1L/wABf+R5PRXrH/DNHxt/6Er/AMqVp/8AHaP+GaPjb/0JX/lStP8A47R/rDlf/QVT/wDA4/5h/Z+K/wCfUv8AwF/5Hk9Fesf8M0fG3/oSv/Klaf8Ax2j/AIZo+Nv/AEJX/lStP/jtH+sOV/8AQVT/APA4/wCYf2fiv+fUv/AX/keT0V6x/wAM0fG3/oSv/Klaf/HaP+GaPjb/ANCV/wCVK0/+O0f6w5X/ANBVP/wOP+Yf2fiv+fUv/AX/AJHk9Fesf8M0fG3/AKEr/wAqVp/8do/4Zo+Nv/Qlf+VK0/8AjtH+sOV/9BVP/wADj/mH9n4r/n1L/wABf+R5PRXrH/DNHxt/6Er/AMqVp/8AHaP+GaPjb/0JX/lStP8A47R/rDlf/QVT/wDA4/5h/Z+K/wCfUv8AwF/5Hk9Fesf8M0fG3/oSv/Klaf8Ax2j/AIZo+Nv/AEJX/lStP/jtH+sOV/8AQVT/APA4/wCYf2fiv+fUv/AX/keT0V6x/wAM0fG3/oSv/Klaf/HaP+GaPjb/ANCV/wCVK0/+O0f6w5X/ANBVP/wOP+Yf2fiv+fUv/AX/AJHk9Fesf8M0fG3/AKEr/wAqVp/8do/4Zo+Nv/Qlf+VK0/8AjtH+sOV/9BVP/wADj/mH9n4r/n1L/wABf+R5PRXrH/DNHxt/6Er/AMqVp/8AHaP+GaPjb/0JX/lStP8A47R/rDlf/QVT/wDA4/5h/Z+K/wCfUv8AwF/5Hk9d78HvBNr46+KlpYatLDBoVjG2p6vPNII0jtIsF9zb1KhiVQsDld+7oproIPgBr2jTNcfFHxDofgLTljeRZb+8iuLi5CKSwt4InJlKnYCuQfnXaGPFc5468ZeHrbS7nwD8MUu7fwn9o827v7sj7XrciklHmIVcQp/yziwAPvsN5+XGvmUcdGWHy6d3JfGtYxXfm2cl0Sbd97K7LhhnQaqYhWS+y935W3S7t9NjB+I/i2Tx18V9e8WO8zR392724mjVHSBfkhRgnGVjVFPJzjJJPJK5eivVoUYUKcaVNWjFJL0WiOSc3OTnLd6hRRRWpIUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB//2Q==",
	"gugup": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwMDAgQDAwMEBAQFBgoGBgUFBgwICQcKDgwPDg4MDQ0PERYTDxAVEQ0NExoTFRcYGRkZDxIbHRsYHRYYGRj/2wBDAQQEBAYFBgsGBgsYEA0QGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBj/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4Poor1XTtOT4PRab4g8QaRFeeMbpFvNO0q+jbydOh3ECecAgtMSrBIwR5eCzYYKo6UrmmHw7qttu0Vu+3+bfRfpdnP+H/AIR/EjxPZfbNH8JXz25RJEmudtskqOCVaNpSocEDOVz1HqM6/wDwz58Xv+hR/wDJ+1/+O0aNJ4n+NXxV03Q/E3im5Mtz5vlzyRh47fbCWOyFSqru8pQduMnk5Nep/wDDJv8A1P3/AJSv/t1aqmnse1g8qjjIOeGoznFO1+eEfwcXbfu/U8s/4Z8+L3/Qo/8Ak/a//HaP+GfPi9/0KP8A5P2v/wAdr1P/AIZN/wCp+/8AKV/9uo/4ZN/6n7/ylf8A26n7LyOv/Vyt/wBAs/8AwbD/AORPLP8Ahnz4vf8AQo/+T9r/APHaP+GfPi9/0KP/AJP2v/x2vU/+GTf+p+/8pX/26j/hk3/qfv8Aylf/AG6j2XkH+rlb/oFn/wCDYf8AyJ5Z/wAM+fF7/oUf/J+1/wDjtH/DPnxe/wChR/8AJ+1/+O16n/wyb/1P3/lK/wDt1H/DJv8A1P3/AJSv/t1HsvIP9XK3/QLP/wAGw/8AkTyz/hnz4vf9Cj/5P2v/AMdo/wCGfPi9/wBCj/5P2v8A8dr1P/hk3/qfv/KV/wDbqP8Ahk3/AKn7/wApX/26j2XkH+rlb/oFn/4Nh/8AInln/DPnxe/6FH/yftf/AI7R/wAM+fF7/oUf/J+1/wDjtep/8Mm/9T9/5Sv/ALdR/wAMm/8AU/f+Ur/7dR7LyD/Vyt/0Cz/8Gw/+RPLP+GfPi9/0KP8A5P2v/wAdo/4Z8+L3/Qo/+T9r/wDHa9T/AOGTf+p+/wDKV/8AbqP+GTf+p+/8pX/26j2XkH+rlb/oFn/4Nh/8ieWf8M+fF7/oUf8Ayftf/jtH/DPnxe/6FH/yftf/AI7Xqf8Awyb/ANT9/wCUr/7dR/wyb/1P3/lK/wDt1HsvIP8AVyt/0Cz/APBsP/kTyz/hnz4vf9Cj/wCT9r/8do/4Z8+L3/Qo/wDk/a//AB2vU/8Ahk3/AKn7/wApX/26j/hk3/qfv/KV/wDbqPZeQf6uVv8AoFn/AODYf/Inln/DPnxe/wChR/8AJ+1/+O0f8M+fF7/oUf8Ayftf/jtep/8ADJv/AFP3/lK/+3Uf8Mm/9T9/5Sv/ALdR7LyD/Vyt/wBAs/8AwbD/AORPLP8Ahnz4vf8AQo/+T9r/APHaP+GfPi9/0KP/AJP2v/x2vU/+GTf+p+/8pX/26j/hk3/qfv8Aylf/AG6j2XkH+rlb/oFn/wCDYf8AyJ5Z/wAM+fF7/oUf/J+1/wDjtH/DPnxe/wChR/8AJ+1/+O16n/wyb/1P3/lK/wDt1H/DJv8A1P3/AJSv/t1HsvIP9XK3/QLP/wAGw/8AkTyz/hnz4vf9Cj/5P2v/AMdo/wCGfPi9/wBCj/5P2v8A8dr1P/hk3/qfv/KV/wDbqP8Ahk3/AKn7/wApX/26j2XkH+rlb/oFn/4Nh/8AInln/DPnxe/6FH/yftf/AI7R/wAM+fF7/oUf/J+1/wDjtep/8Mm/9T9/5Sv/ALdR/wAMm/8AU/f+Ur/7dR7LyD/Vyt/0Cz/8Gw/+RPLP+GfPi9/0KP8A5P2v/wAdo/4Z8+L3/Qo/+T9r/wDHa9T/AOGTf+p+/wDKV/8AbqP+GTf+p+/8pX/26j2XkH+rlb/oFn/4Nh/8ieWf8M+fF7/oUf8Ayftf/jtH/DPnxe/6FH/yftf/AI7Xqf8Awyb/ANT9/wCUr/7dR/wyb/1P3/lK/wDt1HsvIP8AVyt/0Cz/APBsP/kTyz/hnz4vf9Cj/wCT9r/8do/4Z8+L3/Qo/wDk/a//AB2vU/8Ahk3/AKn7/wApX/26j/hk3/qfv/KV/wDbqPZeQf6uVv8AoFn/AODYf/Inln/DPnxe/wChR/8AJ+1/+O0f8M+fF7/oUf8Ayftf/jtep/8ADJv/AFP3/lK/+3Uf8Mm/9T9/5Sv/ALdR7LyD/Vyt/wBAs/8AwbD/AORPLP8Ahnz4vf8AQo/+T9r/APHaP+GfPi9/0KP/AJP2v/x2vU/+GTf+p+/8pX/26j/hk3/qfv8Aylf/AG6j2XkH+rlb/oFn/wCDYf8AyJ5Z/wAM+fF7/oUf/J+1/wDjtH/DPnxe/wChR/8AJ+1/+O16n/wyb/1P3/lK/wDt1H/DJv8A1P3/AJSv/t1HsvIP9XK3/QLP/wAGw/8AkTyz/hnz4vf9Cj/5P2v/AMdo/wCGfPi9/wBCj/5P2v8A8dr1P/hk3/qfv/KV/wDbqP8Ahk3/AKn7/wApX/26j2XkH+rlb/oFn/4Nh/8AInln/DPnxe/6FH/yftf/AI7R/wAM+fF7/oUf/J+1/wDjtep/8Mm/9T9/5Sv/ALdR/wAMm/8AU/f+Ur/7dR7LyD/Vyt/0Cz/8Gw/+RPLP+GfPi9/0KP8A5P2v/wAdo/4Z8+L3/Qo/+T9r/wDHa9T/AOGTf+p+/wDKV/8AbqP+GTf+p+/8pX/26j2XkH+rlb/oFn/4Nh/8ieWf8M+fF7/oUf8Ayftf/jtH/DPnxe/6FH/yftf/AI7Xqf8Awyb/ANT9/wCUr/7dR/wyb/1P3/lK/wDt1HsvIP8AVyt/0Cz/APBsP/kTyz/hnz4vf9Cj/wCT9r/8do/4Z8+L3/Qo/wDk/a//AB2vU/8Ahk3/AKn7/wApX/26j/hk3/qfv/KV/wDbqPZeQf6uVv8AoFn/AODYf/IniviD4R/EjwxZfbNY8JXyW4R5HmtttykSIAWaRoiwQAHOWx0PoccVXr/izTfE/wAA/iDBp/hnxjcvLc2aXckkcAijfLSxhXiZnV8YYgtnBbjBGaq6jpyfGGLUvEHh/SIrPxjao15qOlWMbeTqMO4AzwAklZgWUPGSfMyGXLFlMOHY8evgYc8qNNONSO8W0/ukrJvysvJtnlVFFFZnlHa/CPw/b+J/jZ4d0e8MRt2uvPlSWISpKkStKY2UnBDCMqc/3uh6Gl4w8TXfjHx1qfia9XZLezF1jyD5SABUTIAztQKucAnGTya6T9nz/k43w7/28/8ApLLXn9aL4TvqPlwMEus5X+Sjb7uZ/eWdP1HUNJ1GPUNKvrmxu4s+XcW0rRSJkEHDKQRkEj6E1uf8LE+IH/Q9eJf/AAZz/wDxVc1RRc44V6lNWhJpeTOl/wCFifED/oevEv8A4M5//iqP+FifED/oevEv/gzn/wDiq5qindl/W6/87+9nS/8ACxPiB/0PXiX/AMGc/wD8VR/wsT4gf9D14l/8Gc//AMVXNUUXYfW6/wDO/vZ0v/CxPiB/0PXiX/wZz/8AxVH/AAsT4gf9D14l/wDBnP8A/FVzVFF2H1uv/O/vZ0v/AAsT4gf9D14l/wDBnP8A/FUf8LE+IH/Q9eJf/BnP/wDFVzVFF2H1uv8Azv72dL/wsT4gf9D14l/8Gc//AMVR/wALE+IH/Q9eJf8AwZz/APxVc1RRdh9br/zv72dL/wALE+IH/Q9eJf8AwZz/APxVH/CxPiB/0PXiX/wZz/8AxVc1RRdh9br/AM7+9nS/8LE+IH/Q9eJf/BnP/wDFUf8ACxPiB/0PXiX/AMGc/wD8VXNUUXYfW6/87+9nS/8ACxPiB/0PXiX/AMGc/wD8VR/wsT4gf9D14l/8Gc//AMVXNUUXYfW6/wDO/vZ0v/CxPiB/0PXiX/wZz/8AxVH/AAsT4gf9D14l/wDBnP8A/FVzVFF2H1uv/O/vZ0v/AAsT4gf9D14l/wDBnP8A/FUf8LE+IH/Q9eJf/BnP/wDFVzVFF2H1uv8Azv72dL/wsT4gf9D14l/8Gc//AMVR/wALE+IH/Q9eJf8AwZz/APxVc1RRdh9br/zv72dL/wALE+IH/Q9eJf8AwZz/APxVH/CxPiB/0PXiX/wZz/8AxVc1RRdh9br/AM7+9nS/8LE+IH/Q9eJf/BnP/wDFUf8ACxPiB/0PXiX/AMGc/wD8VXNUUXYfW6/87+9nS/8ACxPiB/0PXiX/AMGc/wD8VR/wsT4gf9D14l/8Gc//AMVXNUUXYfW6/wDO/vZ0v/CxPiB/0PXiX/wZz/8AxVH/AAsT4gf9D14l/wDBnP8A/FVzVFF2H1uv/O/vZ0v/AAsT4gf9D14l/wDBnP8A/FUf8LE+IH/Q9eJf/BnP/wDFVzVFF2H1uv8Azv72dL/wsT4gf9D14l/8Gc//AMVR/wALE+IH/Q9eJf8AwZz/APxVc1RRdh9br/zv72dL/wALE+IH/Q9eJf8AwZz/APxVH/CxPiB/0PXiX/wZz/8AxVc1RRdh9br/AM7+9nS/8LE+IH/Q9eJf/BnP/wDFUf8ACxPiB/0PXiX/AMGc/wD8VXNUUXYfW6/87+9nS/8ACxPiB/0PXiX/AMGc/wD8VR/wsT4gf9D14l/8Gc//AMVXNUUXYfW6/wDO/vZ0v/CxPiB/0PXiX/wZz/8AxVH/AAsT4gf9D14l/wDBnP8A/FVzVFF2H1uv/O/vZ0v/AAsT4gf9D14l/wDBnP8A/FUf8LE+IH/Q9eJf/BnP/wDFVzVFF2H1uv8Azv72dL/wsT4gf9D14l/8Gc//AMVR/wALE+IH/Q9eJf8AwZz/APxVc1RRdh9br/zv72dL/wALE+IH/Q9eJf8AwZz/APxVH/CxPiB/0PXiX/wZz/8AxVc1RRdh9br/AM7+9l7Vda1jXLxbvW9WvtSuFQRrNeTtM6qCSFBYk4ySce5q94P8TXfg7x1pniayXfLZTB2jyB5qEFXTJBxuQsucEjORyKw6KVzONacaiqp+8ne/mdT8XPD9v4Y+NniLR7MxC3W68+JIohEkSSqsojVQcAKJAox/d6DoCtf9oP8A5ON8Rf8Abt/6SxUVMt2deZQjDF1oRWilJfiw/Z8/5ON8O/8Abz/6Sy15/XoH7Pn/ACcb4d/7ef8A0llrz+qXwjq/7lT/AMc/yphRRRQeeFFFFABRRRQAUVueGfB/ifxjqLWXhnRrnUJU/wBY0YCxxZDEb5GIVM7WxuIyRgZNenW37OeqWFnFf+OfGXh/wzZyoAryy+Y6zEZETbiiZwHyVdvu8ZHIai3sd2Gy3FYmPPSg2u+y+92R4rRXuR8E/s62OLPUviPrst5CBHNJbQt5TuOCyYt2G0nkYZuCOT1pf7f/AGaMZ/4V34k/7/v/APJVVyHT/ZDj/Er01/29f/0lM8Mor3P/AISD9mf/AKJ54j/7/v8A/JVN/wCEd/ZovT9s/wCEy8S6d5/737F5TN9n3c+Xn7O+ducZ3N0+8etHIH9kX+GvTf8A29b80jw6ivbz+zqdX/5Eb4j+G/EHlf8AH1l/L8nP3P8AVGXOcP12/d4zzjzXxT8P/GXgry28TaBc2MUuAk+VliJO7C+YhK7vlY7c5wM4xScWjDEZXi8PHnqU3y91qvvV0c1RUr280dvFPJGVjlzsY/xYOD+tRVJwNNbhRRRQIKKKKACrOnafd6trFppWnw+dd3cyW8Ee4Lvd2CqMkgDJI5JxVaup+Hv/ACOkv/YJ1P8A9IJ6aV3Y1oQU6kYPZtIvQx+FdHj+zR6Jb+IJhxNeX008cTMO8EcTRsq8kZkLFgFO2MkrUn9peHf+ifeH/wDwIv8A/wCSayK9e+G/gvw9r3gaxvdR0a0vJ7jW3sp5prySGRIBAH/dIsih3B5ACsTk8dx6GGwjry5IWueTm/EMMqofWK0fdvbSMezf2rdu9/U84/tLw7/0T7w//wCBF/8A/JNH9peHf+ifeH//AAIv/wD5Jr03wF4I8I6rpNnc6ppUt0G128tH8yWSJ3gjs2lVCFYbTuAPY9unFUPEXw606Lw7oH/CPx+fNrerNHZ3Zdj5ls6oYwy5wCu5g3AOVNdH9mz9n7RWt+PT/M8xcb4X619Ukmn3cIW+1fXy5G9r2+duB/tLw7/0T7w//wCBF/8A/JNH9peHf+ifeH//AAIv/wD5Jrtfib4S8O6XpNprHhOKBbOK5k0668m+W7DuvMcpKu2wuob5TjG3oK5+HwR5vwhuPHX9tWq+Tdi1+wEfO2SBnOevOduOgJzWVTBThNwsnZX+R3YXimhiMPTxPwqcuVJxjfmbsk7J2v62sZX9peHf+ifeH/8AwIv/AP5Jo/tLw7/0T7w//wCBF/8A/JNb3hbRNJk+H3iDxTe6d/a1xp0kEUdiZHSNQ5OZZNhDEDGBgjnrW74X0jwNr+m6leavoNxpMuiD+0bi2t5ZWF5bFf8AVfO2UO8rhh/C3cjdTp4Jz5dUr6/n5W6MjFcUxw/tG6bkqbUW1GD1aTSt8T+KKva13va7OE/tLw7/ANE+8P8A/gRf/wDyTR/aXh3/AKJ94f8A/Ai//wDkmvV9D8GeDNb8IaHM2i2cN/rFpqM8cMdxdeezxO/lrESxiCqoAPmcnA6nNcze6L4a0/4MeH9WNpoyanqNvdmSS+e9M0jJKUUwiI+UCBj7+BnGc81csulGPM2rWv8Al5b6o5aXGlKrU9jGlLm5+S3JDf39d/h/dy18vW3Hf2l4d/6J94f/APAi/wD/AJJo/tLw7/0T7w//AOBF/wD/ACTXp+ueBvDVt8N5NRi0WGGSPw/Zagt1b3Uklw1zIQH3xF2Cxkc7tigc4PYUrjwh4dj+Dv8AwmS+H5RqL2CL/Zn2h9sWZCn2/G/fsOOFPy5PQrTlls4tp20V+u33E0uN8PUjGSg9ZqC92HxNJrrtr8uttL+e/wBpeHf+ifeH/wDwIv8A/wCSaadJ0TxTPHp+k6MmjazMwitI7aeR7W4cnCxMsrO6OxOBJv2ZCgqoLSDKorgcE+h9SsVK/vJNeiX4pHN1v6JoltPY/wBrasZvsPmNBHFbuEknkUKWAYqwRVDqSSDncAB95km+In/JYPFf/YZvP/R71qSf8ij4a/68JP8A0ruK4qrcVocWZuVCSpRe8mr+ib+W3+WuoeZoH/QnaR/3/u//AI/R5mgf9CdpH/f+7/8Aj9VK9h+FXwo0Xxh4Xn1zW7u62mZoIobZwu3AGWYkHnnge3fNc3PLufP47E0cDS9tWnK3+KX+Z5T5mgf9CdpH/f8Au/8A4/R5mgf9CdpH/f8Au/8A4/XV33gi00344R+CbnUSbRruKL7RwG2OFYD0DYYD61e1Tw/olx4W8SX0Whtos2jahFaw/vZG+1K7spRg5PzqAGyuBg9KOeXch4yj7lpSakk0+aW0nZfavv8Ad1OG8zQP+hO0j/v/AHf/AMfo8zQP+hO0j/v/AHf/AMfr2HxN8PPCVqfFF/pFkRbada+V5DTuTa3IZDu5bLKyPkZyMhvQVjDwh4d/4aUufCv9nf8AEoQSFbbzpOMWpcfNu3fe56/pRzy7nNSzXD1YOcXPSLl8T2STf2t/eX+Z5v5mgf8AQnaR/wB/7v8A+P0eZoH/AEJ2kf8Af+7/APj9er+FfAXhfXfDPhB2tD/ad08lxdoZnAu7dJzG4HzfKygoflxkBqybXQvDNp8O7zWLuz0gXKa5NYpJqkl4U8pYwwRRbnO7OeW9+elHPLuUszouTgudtO3xS7tfzeT/AKuefeZoH/QnaR/3/u//AI/R5mgf9CdpH/f+7/8Aj9VKKOeXc9b2X96X/gUv8y2W8PSKY38JafGrcF4Li5WRR6qWlZQ3oSrDPUHpXPa7oyacIL6yd5NPumdYTIR5kbrtLxvjGSu9PmAwwYHg7lXWqXUf+SaX/wD2E7T/ANFXNXTm72ZdOUqMotNtNpNNt7u3Vu1t/wADjKKKK6T2j0D9oP8A5ON8Rf8Abt/6SxUUftB/8nG+Iv8At2/9JYqKmfxM9HNf99r/AOOX5sP2fP8Ak43w7/28/wDpLLXn9egfs+f8nG+Hf+3n/wBJZa8/ql8Iqv8AuVP/ABz/ACphRRRQeeFFFegfDD4YXnj3UZr+/uP7M8M2GX1DU5CECgDcUQtxuxySeEHzH+FWaV9Eb4bDVMTUVKkrtnLeG/C+v+L9dXR/Dmmy394UaTy0KqFVerMzEKo6DJI5IHUgV7ZB4D+Enwo8u5+Ies/8JLr8e1/7Gsl3JE37tsMmRnGSQZWVXQn5CRWR4g+LOn+HPC0Hgn4QJc6VpcW8XWqyooub1zlS4PVcjDb8K4+UARhMHx+rSSPUVXC4DSmlVqd38K9F9r1enZHrHiT4/wDjDU4F07wzFbeF9Jjh+zx2tiqtIqbAuPMKjbtwdpjCFQe+Aa86RtV8UeJo/tt/PeX126o91dymRjgAZZmOcKo79AKzK9G0jwnqxu9M0Dwxpr6n4j1E+SIrc738xif3fYIECksTwMEk4FKcmkcdXG1sXNPEzcl/Wy2XyOa8atZN44vG08A2oKpGRxlVUKD+IUV658NdGjurGL/hLv2d01Pw7KNratbSXdncqCPvxvJNsl+gAz2NeweDvgX4Y+Gawaz4hDeJvF0qb4bW0x5Ftt6mMsM7V/inbA/uj16GW+1zxVqUujnT/st+6JI0Ud1I+I3zt80ydmCkjODgA4wRWUXokRXftqsqqVk3ex8reMPhBef8LFvrT4ewT6loLbZbSe5lRGVXGdhLEZI9cdMZ5rG1H4MfEvTLU3M/hS7khAyWt2WbH4KSf0r7A8N+FrrQHN3qeiT/AGMsUmvLKXfJbEHB82MgkqMD7vQc4Ir0SbQ9SitFuNOVNXtmUN5AKpMynkGJxhG9g2M/3qrnsZOmj8x1N9peppIhuLK8t5A6sCY5InU5BHQqQcHNeu/Dn4s/E+31O1tp706vpCNsnfVFLCNS4Zm+0Ab9+MhdxbrgKcADY+LPibQ9e+Jtyx0qJLLSneAG4tvIuJnX7xk3DcmCCNpGQOcAnjzOXxLLfhknvjY2StwEBeRv9xc4HA6n86Tqu3u7noZZVlh6ykqjivJ2v69PvPRH8MfDr4la9daVJ4gg8L6vE6w6ZbRQpHbvGWXIEeFVmLMwCq4bJJwwFeR+M/AfifwDrCaf4ksPI83cbe4jYPFcKrYLIw/A7ThgGXIGRWdfXX2y+knCCNWOFQHO1RwB+Vel+CPi81hoUng7x/aSeIfCctt9nFttUzW4GSuxiVLAHAGWBTClCu3BuEEopPc6a+KweYVZKpH2cuklt5KS9NLrbqmeQUV6f8R/hVB4d0O08ZeC9Ql1zwheIpW7OGktmPy4lwBwWyAcDa3yMAQN3mFJq254+KwtTC1PZ1Vr+DXRp9UwooopHOFbPhXV4ND8V219dpI9oyyW10IgDJ5E0bRSmPJA3hJGK543YzkZFY1FCdioTcJKS3R2Wo6ReadHDcSKJrK5ybW+iDGC6UYyY2IGcZAKnDKflYKwIDIdV1O3tIrWDUruKCGcXUcSTMqpKBgSKAcB8AfMOawtJ8ReINA87+wtd1LS/O2+b9iung8zbnG7aRnGTjPqa0/+FifED/oevEv/AIM5/wD4qt1WsOdDDVPiv6WT/G6/I008S+Io3Z49f1RGaZ7gst1ICZXXaz9fvFSQT1IOKZb6/r1pFaRWut6jBHZsz2yRXLqIGbO4oAflJyckdcms/wD4WJ8QP+h68S/+DOf/AOKo/wCFifED/oevEv8A4M5//iqv6zLuzH+z8Da1v/JF5/3vN/eydL69j0+WwjvLhbWZg8sCyEJIw6FlzgkZOCar0v8AwsT4gf8AQ9eJf/BnP/8AFUf8LE+IH/Q9eJf/AAZz/wDxVQ61zZUMPG9pPX+6v/kizp+p6lpN39q0vULqxnxjzbaVomx6ZUg09tZ1dp7uZtVvTJeLsunM7Ezr6Oc/MOBwc9Kp/wDCxPiB/wBD14l/8Gc//wAVR/wsT4gf9D14l/8ABnP/APFVSxDSsRLB4SUud79+Vf8AyRqQ+J/Elto40m38Q6rDYBSotI7uRYsEkkbAcYJJzx3NEHifxLbaOdItvEOqw6eUaM2kd3IsW1s7l2A4wcnIxzk1l/8ACxPiB/0PXiX/AMGc/wD8VR/wsT4gf9D14l/8Gc//AMVT+tS7szeXYF3ut3f4Fv3338y+Nd1wSeYNZ1AP9m+xbvtD58jp5XX7n+z09qDr2uG6e5Os6gZng+yvKbh9zQ4x5ZOclMcbelUP+FifED/oevEv/gzn/wDiqP8AhYnxA/6HrxL/AODOf/4ql9ZfdlfUcF/UF/8AJCVq6XpaPEusawlxb6BBKFurxBjfjBMMRIIaZgflXtnc2EDMMv8A4WJ8QP8AoevEv/gzn/8AiqyNV1rWNcvFu9b1a+1K4VBGs15O0zqoJIUFiTjJJx7modXsbqNGD5k2/JpJfm/66hrWq3GueJNQ1u7SJLi+uZLqVYgQis7FiFBJOMk4yTXTaLK2u6BZaXao0up2AeJLaNSWngLmQFByWdWeTcB/DsIBCuRxdFc8o8yszjxdJ4hXb9697+ev+bOurofDfjnxT4Rini0DVXtopzueMosilsY3AMCAfcelcZ/wmvjL/obdd/8AA+X/AOKo/wCE18Zf9Dbrv/gfL/8AFVj7F9zzKuBq1o8lSEWuzbf/ALabV7fXmo6lNqF9cyT3UzmSSZzlmY96mvta1nU4oo9S1a+vEi/1a3E7yBPoCTiuf/4TXxl/0Nuu/wDgfL/8VR/wmvjL/obdd/8AA+X/AOKo9i+5X1Otp7kdNtXp/wCSnRPrutyNdtJrGoM17gXRa4cm4x08zn5sds5q1L4w8XTFDN4p1qQxsWQvfSnaSpUkZbg4Zh9CR3rk/wDhNfGX/Q267/4Hy/8AxVH/AAmvjL/obdd/8D5f/iqPYvuQ8BUe9OP3/wD2p0EGtaxavaNbatfQtZhhbGOd1MAbO7Zg/LnJzjrmp7LxN4k02F4tO8Q6rZxyOZXS3u5IwznqxAIyTgc+1cx/wmvjL/obdd/8D5f/AIqj/hNfGX/Q267/AOB8v/xVHsX3HLA1Zbwj9/8A9qaRJJyTk0Vm/wDCa+Mv+ht13/wPl/8AiqP+E18Zf9Dbrv8A4Hy//FUexfc0+r4jtH73/wDImrFFLPOkEEbyyyMESNFLMxJwAAOpNReI7pLDQh4eyDePcrc3idfIKKyxx57P+8lLjnHyDhg6jMn8XeK7m2ktrnxPrM0MqlJI5L2VldSMEEFsEEdqxquFLld2aUsJNyUqtrLWy1183Zbdrb216BRRRWp6R6B+0H/ycb4i/wC3b/0lioo/aD/5ON8Rf9u3/pLFRUz+Jno5r/vtf/HL82H7Pn/Jxvh3/t5/9JZa8/r0D9nz/k43w7/28/8ApLLXn9UvhFV/3Kn/AI5/lTCiitfwv4b1Pxf4usfDmjpE15eOVQyvsRQFLMzH0CqxOMnjgE4FBwwhKpJQgrt6I6n4YfDC88e6jNf39x/Znhmwy+oanIQgUAbiiFuN2OSTwg+Y/wAKtt/Ev4l2esadD4H8D2/9meDrDCRxRgobwg53vnnbu+YBuSfnf5sBdH4s+INE8OaMvwg8E23kaXp0yyajeCbc97cBRkOVOGwcbtw4dFUBRGM+P1rtoexi6scFB4Og/eek5d3/ACr+6uvd+QUUVNa2l1fXkdpZW8txcSsFjhiQu7k9AAOSaR4pHGcTKeOCDzX6V/s4/Bc+EvhvceOtWiE/iPxK7yJIVx9ksXYuiKDyplG1274KqfunPzD8Gv2e508Uaf4k+LVoNL0uN/Pt9BuiFu9RK/N88X3ooB1dmALfdUfNkfcvjDxvPpvw2vJLWYC5uWj06128bZp5FhDDHcb2b/gNYVXfY3owlJqK6klroOmzXbbY1nlvE86aUjO+NXCqP9zJ4HTgnua8t+CGPEWufEHW7pd15Lr5JLckR+VtRfoACK9D8LeNNJb4ueKtPtjG9vpltpumQRk8IB5xP5tgfgK848DeJrbwD+1Lrfgi9tIIbLV4zJYylcLcHLSRFvVirSJx3QCsZNpo9PCQjOjXiviSTXomr/hr8j11bCKLVorXy9r3Cs6kfxFNuR9cEH8KqaatlpPjceFHK28NyN1ujrjypSC5jA/uOoZ0x3SRewFcr8T/AIjzaTquh6hpEIln07Wna4giUlngNmTKFA6/KwIH+zXG/GfxvHrHw5h8beGr4DxD4fuI7nYsmSyBlk2+6/ckQ+hb1YVRzUaDqNX0T0v5/wBfmYn7ZHwasdW8KSfEfwrDt1PTlVdbSNcfa7dfl+0e7x8bj3Tr9wV4tafBq9v/ANnON5dMVZ7oG8tbrADi4C4RT32OoEfpuIPavtO48U2+v+AotZ022iure/slultX5WaORAxiP1Viv1rzXQdR0aPwadH0+c3VgS32BieZE6+S392ZMYKn7xG4ZycaU3Z3Odx6M/ONgVYqQQR1B7UlepfGn4fXHhrxjc+IdLhabw9qczTQ3CAlYJGOWhf+6Qc4Bxke4OPLa3Odqx3vw0+Jd34F1Cawv7f+0/DV/lNQ0yQB1YMNpdA3G7HBB4ccH+FltfFD4X2mh6fD448D3H9p+Db/AA8csZLtZFjjY+edu75QW5B+R/mwW84r0r4TeNdM0i6u/Bfi2zivvC+vOkNyk8u1LWTOBMMkKo+7uYYYbFYHKAF76M9fB4iGIgsFiXp9mX8r/wDkW9103PKaK674leBrv4ffEG60Kf5rZs3FjKZA7SW7MwQtgDDfKVYYHKnHGCeRrJqx5lajOhUlSqKzWjCiiigyCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAPQP2g/8Ak43xF/27f+ksVFH7Qf8Aycb4i/7dv/SWKipn8TPRzX/fa/8Ajl+bD9nz/k43w7/28/8ApLLXn9egfs+f8nG+Hf8At5/9JZa8/ql8Iqv+5U/8c/yphX0H4Dg/4VR+ztqfxDuYvK1/XsWmlb4/miQ52MN0ZxnDzYJKOscXQmvGPB/hm78Y+OtM8M2TbJb2YI0mAfKQAs74JGdqBmxkE4wOTXpHx/8AEkWp/EePwzpyW0Wk+H4RaW8VsUMauVUyY2gbduEj2ZIUxdskVcNNTqy1/VaNTHPde7H/ABNav/t1fi0eT0UUUzxQpQSGBHXtSUUAfS/wbW18I+HNFluYjca/4pMuoMZOTb6ZaB2XJPI8yaInHfYh7c+1/ErxJ/ZPhPw03m5jttetvOz6xJI5z/wJc182eAdafWfiDqetRF2s9J8Kx2EGRxEFhii2/ifNP1JNel/E7Wor/wANayscbXK6drcGpiGNgDNCzhHUH/gR59GFYVHZXPTwFPnlft/w36nYyi78JeDtM8ZW99HNdarHI+pQo372C4Ev2iEOn3hlQyjI56DrR48vdJ+IPha21Qzvaalp0i3Flf27YlhRmU5B7gcHHque9cr4v+JXxVv/AAHpPiHxr4X8CyeHtRt5ZtO04xzrfrBHIEMaXKqQJIgwLcADaSQTxXdeFvhhN4j+Emk+JvDd5FJa3tswfTbpvJkC5KkK/wB0OCGB/hbG4bd20cUKypxtUPQ+r1JNV4adF8tPy0Mv4Ta9q2t/F241PxFD/bktq8rqmnRjZPKYkgUsWISIEKxJZsenUCoPin8MtV0G4fV/Cmq6TK14DA/h21uhNJCrbm8hVOGmX7xBCjb82Bt6ejXnwn1jxd8LItG0A3vhS/gtpTqEVvN5dxqMsUISFI5FJ2xPtBYg55I6ZJ+Xof2etR1rxRb3elWNnpMOpXsa2SPftPcW6tnzS0gwzNFySWUZIxgdKy9peXtE7f8AAOzC4WpO/s7WjunZb36ddn5Ht/w71+50z4D+CYLnzEuYriGxaOQFWAFw8RBB5GF7VjWunaIfiF4nsZtMsbqCd0v4C+VIEwzztI3JvDA5zg4PrWIup6efiV4b8GeH9y6ZpdzJeyEsWPlxyPICxPJONmSepauA1rxheaZ8ULLULaYHyJ7jTpUb7rxMyyKD7AS8fSvQpSurs4cXhLSjGPxSTf8Al/Xmdn41GrXOhXOs+BrpbeWNGhvdDnhWaCfbklGiYEbuDg9GwO5FfKuoXp1DUZLtra1ty5z5drEIox9FHAr6Eu/E09n4z0rWLdzFBqV19kmTsX4dD+DcfQ+1eIeOba0tPiXr9tYbfs0eoTrGF6KvmHgfTp+FddtLniVVZmBRRRUmJ7xp0H/C3f2XptIWLzvEvhHBtdkeXlgCnag2x5+aNWQIpyzwxljzXz3Xovwh8Wv4P+LWmXzSxx2d04sbwyusaCGRgCzMwO0KwVyeM7MZAJqt8YvCL+Dfi9qlgsUUdndub+yESLGghkYkKqKTtCMHQDjOzOACKJaq57WMf1vCU8V9qPuS/wDbX92j80cHWl4e0O/8T+LtL8N6Uivf6neRWNsrHAMkrhFBPplhWbW14P8AEdz4P+IeheLbOJZbjSNQg1CONjgO0UiuFPsduKzPFPp34n+Dv2b/ANnK/wBO8D+I/AmsfErxVJaJdahdSazLpkFvvyAEEWeTgkKQcAjLHNeNz+G/CHxb+OWgeFfgzolz4XTV4lga0129a4ihusyMxWVVZzHsCYyuc7uMYr6S8fal4Q+K3xe0L4/fB347eDfBPiaCzWG5sfF06Wsts4RkLKsiOrnY5QjaV4yG54d8Zfjh8OJ/21fhL4ssPFtnrOm6Agh1a/sVZ4oS7kM4IGGADbjszwPXis02VY+fPDn7NXjrxP8AtEa78GrDVvD0evaLC89xczzzC1dUMYIRhEXJ/er1QdD+ND4a/s+eO/ii+vz6NPoumaToLMmoa1rF0baziZckrv2kngEk4wBgkjIz9i+BL74S+F/27fFvxRu/jb4HuLPxFpshsYYdSQCEFoC/nysRGjZTCoGLMCTgbTXk3wf8ZeBPFP7MHxR+BuseN9G8Jatq2rS6lp+p6rOILS4UtCQpl6dbcA9ysgwGwRRzMLHluufssfETw98O9M8Z3+reF307U9Vi0m1+y3z3BkaWQpHMrJGY2hbG4Mrk4I4zkCpqf7NXjrSv2ldM+CFxq3h5vEOow+fFdRzzG0VfLeTDMYg4OI26IeSK+kPFS6T8P/8Agm14BEGvw+ILTS/FcMv2+zVhDdMl5cSSCDeAWQFXVWIG7buAAIroNW1j4Q6x+3b4P+OSfGrwaNHexNvHYm8C3CTC3mUGbdhYI9r5zIVO4BApJpc7Cx8p+E/2ZPH/AIz+KvjL4f6RqWgDVfCe/wC2tLNMIpyrFcQlYizEkcblWm+JP2ZPiL4c+Edx8REvvDOt6XYt5epQ6Hqa3k2mtwGWcKNoKlgGCs23OTxk19R/s9arpOqftk/H7WdP1OK70yeKaeO90+VZVkjMzHfG6nDccgg4rz/wdqvw6+Bn7HfxK09/in4a8Yap40tWs9N03RpWeSNXheJXmiYBoWAlLMGAxsABYkU+Z3CyPjavsvUfgv8ACj4a/sj+EfiP4l+E/iTxlNq9vHLrN+uqTafLpBkUEFYQu0puO0FlwflJb5hXyZ4S1PT9E8f6HrOrWX26wsdQt7q5tMA+fEkis6YPHzAEc+tfoq/xP8Iaj8cLv4iQfHjwLf8Awx1/SktNX8Ja7eMtzCFjK4htSpOSSSwIGd7gg/KQ5tgj87/EHhrVdLhi1z/hHdc0/wAO6lLI2k3mpWrRrdRBuNsmAkjAFc7SRmvQf2afhZonxh/aC0/wh4jvZrbSxby3k627BJJxGAfLViDjJIycZ2hsYPI9I/bI1zwzrH/CA2Pw48SeFtQ8CaTpX2bTbHSNRSa4tJG2l/Pi3eYmUSIAsM5Vt2GJFeJ/CGzF18UrR4/iRb/D+8t43ns9cuC6pHMBgIXQ5QMCwJ5GMgg5p3uhbM9l+Lei/CfwfY+IdEv/ANmLxn4NuYlmt9J8QyatczwzTDIikZZP3ZQnBOxm46ZrzL4f/BN/iB4VGtR/Fb4YeHHadoF07xHrv2O7JXHzCPy2+U54OecGvsWz+MA8N/Arxpp3x0+N/wAN/iLFeac9tpdj4dlS5up2ZHXZKsaIBklMErxgktXl/wAHbj4G2H7J9nqFkPhGfiDFdSNrA+JELXC+SHfHkRAF3OzytojGCd2eahN2HY8J8R/B/wAWfCj46eHfCfjvT7R/td1bTQywOJ7a8gaUKSpxyOCCGAPqMEZ9f/af+Ffhy9/bPg8FeF7jwP4AsJdEhuPO1B49K09HHmE7mRMB2wAOOTit79q7x14F8U/EL4L6j4Y8T+Hb+2s0U3f9mXEXl2S+bbsFdFdvJAAbCseACM8Gut8YeIv2fPF//BRMan4+8QeG9b8Nf8I1FHZXZvI7jT/tokPyzOjFOEL8OduSM84p3ejCx81eMv2aPGvhT4aXfj/TfEngzxl4espBHeXvhTVfty2pJAy+UXjLLnGcZBOBzXtniX4Jab4x/Yi+Ed34Z0vwd4e1S6cPqniPUjBp6lSsir59xt3OWbaAvzEnoODju77x98O7T9l74t+FJfEHwV07VpbCVbWy8ChbSG73RN5YBdgbmYY5Ma4XIGSSQPGvjL4w8M6n/wAE9/hH4Y0vxRpN5qtlOHvdMtr2OSe3xHKAZYlYsn3scgdfeldsLI8R+K/wk8YfBnx0PCvjKC1FzJAt1BcWcplhuIiSu5GIB6qwIIB46cjPQfB3xB8JLee08MeP/g3/AMJhqOpapHFFqv8AwkNzp/2aKQogTyohh8NubJIJ3Y7CvTf23PFnhbxb4y8DXHhfxNo+uJb6EIbiTTb2O5ET7ydrlGO1vY8186+CriC0+Jnh26upo4IItTtpJJZWCqiiVSWJPAAHJJq1qtRbM+pP2mNF/Z6+C3jSfwDpXwG+2X95owu7bWf+Eovo/ssshlRG8li4fYUDYLYbocVnfG/4Vap4i8ZfB/wbovgjwJ4Ov/EGm+XBPpNyzR3bFYz5t0VtIirfQSfePPriftxeJ/DXi39pOy1Pwr4h0rXLFdCt4WutMu47qIOJpyVLoSNwDA4znketev8Ajz4g+Arz9o39nPU7Txv4cuLLSbMLqN1FqULx2R2RjEzBsRng/ex0qFdWKPFf+GLvi0+sa5ottqvg641jSkMv9lR6r/pd3FgYliiKBghJ2hpNgJ6cEE8L8K/gH47+LVrrOoaK+k6RpOjA/b9W125NrawMASULbWOQASeMKMZIyM/Tfw8+Ifgq1/4Kk+PPFuoeONAg0G60+SKDV59ShS1m+W2CqkxbY33CAAf4T6Vzfwp8ZeAvFX7N3xY+B2q+ONF8Japq2sz6lp2qapcCG0uULxMFMvTrbgHuVkBUNginzMVkeNeNf2bPHngL4MR/E3WtT8NzaNLeCzhWwvWuZJtzMElRlTy2jYLuDB84IyAcge6/Hn4BzeNPE3wj8K/CjwXoum3uo6AbnULm0tEtIVAEOZ7l405A3HkgsScAEnBsfFHSdO8N/wDBKLw1olj4it9dhh13yk1G2DLBcP8AaLln8neAzRg7wGIG4KWAwRXqfiL4+/CaTQfCfwo1nxdpx0PxP4aGn32vaHqiGXSJwiKqzPGx8tTuYHdwCDuBUthcz3HZHw/p3wVGo/E/WfBX/C2vhlZSaVHul1XUNYktrCd9wVooZXhBkdSecLjg4JqX4k/s+eNfhr4KsfGdxqnhvxJ4ZvJvs8eteGtQ+2Wwk5wpbap52sM4IyMZzgV7J8EvBXwP8DfFDx34f8f+Kfh14m1GG0STwpquqX8Vxo1wCJMmYqzIj7hCGRvmA3bcjk9j8XvH3gLUv2Atb8LWXiD4XR6/Fq0IOk+CVW0tnK3EZZ4IHbzJBtzmXaA2DjgZL5ncVtCP45/s4xeMx8LrT4f6d4H8Ifa9FVbi7u3h0xL66dYikY2JvnmPzHAViO5GRn478feBPEfw1+IWo+C/Fdoltqlg4WRY33o6soZXRu6srAj68gHIr6s+PvjvwhrHxL/Z5m0fxlol/a6Qto1/JaahFKliwltixlKsRGQEOd2Pun0ry79srxD4f8UftWalq/hnXNN1nT3sbVFvNNuUuImYRgEB0JBI6HmiDezBnAftB/8AJxviL/t2/wDSWKij9oP/AJON8Rf9u3/pLFRVT+Jnfmv++1/8cvzYfs+f8nG+Hf8At5/9JZa8/r0D9nz/AJON8O/9vP8A6Sy15/VL4RVf9yp/45/lTPav2c7a3sNe8TeOb+CKez0DSnkZQoaZXbLbogeAdkMq5yPv46E48q1C/u9V1e61S/l867u5nuJpNoXe7sWY4AAGSTwBivXPBf8Aof7FvjbULT/R7uXU0t5LiL5JHizbDyyw5K4kkGOmHb1NeNVr0R0Zg/Z4XD0F1Tk/WTa/BIKKKKR44UUUUAe6/CWK2s/g7d3hcLcav4ktdG3f3R5LyKP+BEsPwq/4j0/U7bQRrhYS2U1sY3iP8cZzGUPuFVee+0dCM14lp3iHV7HQbnQrKZxb3VzBd7FzuWeLcI3XHRgJHH4+wr3/AMJeLLbxppsPhvXXtre+1CCa08tflVb1HeRFAzx5sc8oA/vxbR1ArKa0szvweI9lOLXT8up7h8NNVl8f/BTwzFeWV7I+mklpprJAk0qExO8cjAhg4GJFP8QJIB5Ps2k+F7j+zoold4LZFIEYbG3JJPQY6k18T/Cj9oC8+B/iDU/CXiTTP7T0Nbvz3tN4int2YANLCx4IOBuQ8ZAII5z9UaZ+1F8CfEFtHZ6l4jj0iSVUk+x65atEMHDKdwDRkdCPmrwa9Gd/I+nqY50o+zppbvX5neTeGrhLcmxuTkEjKvnBHBrgvFHhnxlZ+HrxPDS2kN1cxtHLfzsI0tUP35MAFnbuBwM8k9jp3X7QHwf0O1g0vw/r9trlw2RbaX4dQ3chyScDb8qDJJyxAFfPH7SHxm+IV/pmlaFaiHQdH1bzRPb20u+42LtyJJRxggnIQY4xuNZU6TlJJGlDGYiUNUrPqcF4UmXQfCuq6gZ/P1PV7j+z7OYjDGIHHHoOQTz1xXmmrX4vfHtwQ2YnvXaMg/fC4XP5IKlg1W/nvI5Y5RHHbW7LagKSIiwIV8cDAyzdcsdvauagtUSW7klup5JbWBpYpxhdpUgAHrkEnGPevdp7KJwYitCniJ1b3+f32+Xyvc3PGvi1Zte0630dwYtJkMwk/hkuCwLMPULtVR67Se9cPLLJPO80zs8jsWZmOSxJySa0tG1Say18XAjikSYlJoZEDJIjdVIOeO/qMZFS6vplssI1DSgWtfuzIG3eS+enPO08YJ+h7V1czcrM+amk4899b7fqYtFFFMxCvafjLM/i/wCCngP4iMsRuGR9Ovp5I1SaabB5+UY2B4ZyBkY8wYAyceLV7PpP+m/sN+Jvtn+kfYdYT7J53z/Z8vb58vP3M+bJ0x99v7xp9Gj2MrfPTxFB7ODfzj7y/VfM8MooqS3t57u7itbWCSeeZxHHFEpZnYnAVQOSSTgAVkeOR0VdGkasXvUGl3pawybsCBs22G2nzOPkweOcc8VSoAK7v4b/ABV1f4aHUobPw74W8QWGpeUbrTvEmmJfQO0W/YwBIKkeY/QjOec4GOEqzdafd2drZXFzFsivYTcW7bgd6CR4yeDx88bjBweM9CKLXA9D+Kfx28d/Fyz03TPELaZp+i6X/wAeWi6Nai1s7c425CZJJA4GScAnGMnPmddC3gTxpFdWdvc+FdXtGvbiO0t2u7V7dJJXOEQO4Cgk+prnqLWC9z0f4SfGrxT8GrrXbjwvYaPdtrVl9huBqUUkgRMk5TZImG575HtXnFFFFgCiipWtrhbNLtoJRbyO0aTFTsZlCllB6EgOpI7bh6igCKiitGHw/r1xor6xb6JqMunJnfeR2ztCuOuXAwPzoAzqKtJpuoyz2cMdhdPJe4+yosTE3GXKDyxj58spXjPII6irFh4e1/VbWa50vQ9SvYYOJZba2eRY/wDeKggfjQBm0VaTTdRkns4I7C6eW9x9lRYmLXGXKDyxj5vnUrxnkEdRVkeG/ETaD/bi6DqZ0vn/AE4Wr+Rwdp/eY28EEdeooAzKKKKACiiigAooooAK7v4b/FXV/hodShs/DvhbxBYal5RutO8SaYl9A7Rb9jAEgqR5j9CM55zgY4Sii1wPTPin8dvHfxcs9N0zxC2mafoul/8AHloujWotbO3ONuQmSSQOBknAJxjJz5nRRQlYAooooAKKKKAPQP2g/wDk43xF/wBu3/pLFRR+0H/ycb4i/wC3b/0lioqZ/Ez0c1/32v8A45fmw/Z8/wCTjfDv/bz/AOkstef16B+z5/ycb4d/7ef/AEllrz+qXwiq/wC5U/8AHP8AKme5+IP+TG/Bv/YYk/8AQ7uvGK9n8Qf8mN+Df+wxJ/6Hd14xWr6G+cfHS/69w/8ASUFFFFI8gKKK0NEsJNS1y3tIoxK7sAsZ/jPYfTOPwzSbSV2VCEpyUIq7ZtaHplxFGDbIft0q5aX/AJ9oz6ejsO/8IPqeKU1hI81yYQwjtcY8okchux9eCfxFer6efDVlKmhRarBPqO7Mix5d5ZO/QcnP8I57Vy+jXGh6RbyQeIYZneSdn8qNk2uCTjc4cbQMDgcnPVe/nqtKpJ2R9nXyrDYGhCNSabd+a2tnslp5v8Dkb0+JviLqkd1ry280mnhY7jWZT5bXEfVEcqP3khAOCBuPJboTWpIbXVpbhJYo7K6hBWBGwpRMBVjP94YCgMPTPOSKta3q8ENs4tYIrVIk229vHkqqt1I9ST8xx3+lF5Y/bNPtbaRirOxLyKcECNBz/wB9yD8quWh4tCnZu2tlr59l99td+p7la2fhb4NfBrQ9f0ma2utU8R2EdwGkmMkjbciR5F42KjlkCjAJGM8MR4rrWs3Wv+L3895tX1FzjC5mH/AVXG79FGMYAFQx6LdX13aQ3N7cy28LpGqPIWCKZM4H90Eljj1J7nNdR4N1tPC/hvV9U0t/I1W/R5mmWEkiMswA8zopDZO3+L5QMmsqNJRk23dnViMVU+rpQXLG9l5/1p6u/lblJJ9Wuma0i0oDDbGe6Zcbun3R6HisnTkkh1a7tNUtI4FeOSK4jA+VRtJ3j/dIVh/9eunt7iNo5VA3ESmFBnltoGST+eTWf4jsbu4WS4mEIMqAqQwVmKY3ZGd2CvPTqoreEuWa7GLwyqYaU4puaa9LPv28jjLMH7SHX73Rf948D8uv4VuWCzxCR7aMSsi7Jo2HEycqQ35Zz2Na/hzw6DKbqUBtuVUYwue+K1/D+lMvi/VLPGRGA2PQNgj+ZqKuISba6Ho4DIJWpqsvjbXpo3+h5xqNqltdZgLNBIN8bN1x6H3ByD9Kp16B438LtpsZuI0PkzMXQD+CQD5h9GUZ+q15/XVRqqpHmR87mWAqYDESoVFqvyCvaPgz/wAkf+LH/YG/9oXNeL17R8Gf+SP/ABY/7A3/ALQua2judORf75H0n/6RI8Lre8EXEFp8TvDl1dTxwQQ6pbSSSysFVFEqksxPAAAySawaKyPIPU7Txjol9pGr20pktri+sGbVJZGVRdSxmOOMRc5ZivmOc8lnbjAzU2o/8If/AGtbf2t/wjX9n/25F9h/svZn+z8Pv+0eV8+P9R/rP3n368moquYnlPUT/Yn9qaT/AGx/win9tbL7/jz8j7D/AKpfsnneV+6z5nmde2zfxmsH4g3Ec/8AwjcQn0mS4g0kx3K6U0Zhjl+13DFQI/lBwwJC8fNkcEVxlFFx2PaNZn09fjrpuvLa+EbbT/8AhJoLg6tZa0s00sfn53yR/aXCLj5ifLXGB0HB5uzOhjxhpMul2WjXWj/ZpBDDd3FrBNG+zDNcG4OxpFYhgGyjAYUDkDzuijmFynrcNlbLB4pudMuPCd/dpf6akN3f2tnDboHguGkjQf6gEbQDtO1thYZbbVbWtQ8DJ4u8OabaW2kf8I68ryX81vAplK/b7jarSYMiqIxHgcMUK5z8teZLc3C2clos8q28jrI8IYhGZQwViOhIDuAe24+pqKjmDlPW72fRW8XaQU8L+Hl2pcgyrrelSRyAoAjMqxxwqUJ3KJVy+SDnHHO+O49Gi0q2Wwv9Lvbw6lctNLZW9vARGba0KqVg+Tar+coK/KWDkdTXDUUOQJFq48/+zrPzPsvlbX8vyvL8zG458zb82c9N/OOnFelOmi61rdprd1r6waImlw28aWurxWlxp7pAqunkOrPIC6vwi/Nvzu6ivK6KSY2j03w7Lp8954B1+TWNNt7bw9j+0I7i6SOZPLvZbj5IyQ0m5ZFA2A85BxTbP+zte07wu51aGDT9OgeG9sl1aLT54JjNI5nQygh8q6HKqzHbt4wDXmlFPmCx6xYyaNN4o8Ha9beILH+zvD1wwu2vLpEuGSO/muFYRthpC6SLjap+bIOKzH8V6RpPgvQHtrSS71g6Re2bOt6oit1muLhSskIQszbZNwy4HKnae/nVFHMLlCiiipKCiiigAooooAKKKKACiiigAooooAKKKKAPQP2g/wDk43xF/wBu3/pLFRR+0H/ycb4i/wC3b/0lioqZ/Ez0c1/32v8A45fmw/Z8/wCTjfDv/bz/AOkstef16B+z5/ycb4d/7ef/AEllrz+qXwiq/wC5U/8AHP8AKme4+Hf9N/Yd8S/bP9I+w6wn2Tzvn+z5a3z5efuZ82Tpj77f3jXjVex/s6n+128a+Bv9T/bOjt/pn3vJ27ovucbv+PjPUfcx3yPILi3uLS8ltLuCSC4hcxyxSqVdGBwVYHkEEYINa9EdGYr2mGw1dfyuPzi3+jRHRRRSPHCrdlf3GnmWS1cxzOhjEg+8gPBx6EjIz7mqlFJpNWZUJyg+aLszs9AtrC08Ofag5XULlXYTZw0cQOzZH2DOQwZj0Xp1NSy3lpYwwrBZQSXksakKAG2k9mJ64GD1r0vwb+zN8S/F3wgg8WQHT7T9y1zpthO7Lc3URO4HgbUDcldxyQc8Ag1wOl/DT4k+L/HaeGtL8NXn9sRxSEwzL5CQIvV2d8KACQOvJYAZzXFKcXN+9se1TrOOHjH2dn37+vn5kMngrxl4k8Pza7pPhW91O2sDm4uNKsXdEAOWBZVwcd8cjvio9Lv4rjVYGkuQqrE2xcHJ3N82OPQCv0R8G+LbHwZ8OvD/AISutEXQtTsbMW82nB1ZY5oollZVdeG81BK6SDqysDyMV8fftM2nhqL4oxa74evTHeXRkE8EMYSOSVG+a5TGNhdWhLKRyxYjjNc1PEe1lytehvGMsO3VS00v96f6HC3M7WUaShlQwYlCyEAliOenXoOOcU20FvN4bjjmhUGK3UqwlcgsygbsbioPqce1ZVjqcczq+ogqEVgUXC5BBxtBIHXFRNNImnQ4ZZRCOUXBPPLEY966FB9wnmFOzjGF1ra9nuku2lrdO3noeG5828ZmGZWnkjI9AMk/mf6V1erQ6NPpWkanHdaaj24I1GzvLgCSd0lOSicuweMrwAACD0rgtDuN2vOFOY8vMv8AwIAV12n6knnzBII54iVjlRlY7jnjaU+YEeoz1IINU9NTLByc0qV93b5bd0vvZx8eual4f8SSra3dxPbwzELFcbgJEzxlTyMjB7EZrrbjxlZ6Nf6prWnrHcXN9HbpbxydEAj3MzY9CQMdz9K5fxXDHc3EmpxiNHWb7NJFGSVUBcx4JAJIUbTkA5XPfA5mtZ0IVLSJo5vjMA5UVLVPS+tnZp2+T+/U9IsPH0niSzuNC8RxW4edf9Fuo02BJRyoYdME8Z7Z5rzqZDFcPGVKlWIweopgJByKdJI8shkkYszHJJ7mqp0Y02+XZnJjcyrY6MfrD5pR0v1a7P0/UbXs/hb/AEP9izxvf2f+j3cupR28lxF8kjxbrYeWWHJXEkgx0w7eprxivafitBceFf2a/h/4Mu4JDcXDyalK8qmJ4GALGFozk5BusEkj/V9OeN1s2b5SuSNeu9owa+cvdX5/geFUUUVkeOFFXodPTylkvLgwhhlURN7kHoSMgAH656HGDmpPsWm/8/11/wCAy/8Axyq5WK6M2itL7Fpv/P8AXX/gMv8A8co+xab/AM/11/4DL/8AHKOVhdGbRWl9i03/AJ/rr/wGX/45R9i03/n+uv8AwGX/AOOUcrC6M2itL7Fpv/P9df8AgMv/AMco+xab/wA/11/4DL/8co5WF0ZtFaX2LTf+f66/8Bl/+OUfYtN/5/rr/wABl/8AjlHKwujNorS+xab/AM/11/4DL/8AHKPsWm/8/wBdf+Ay/wDxyjlYXRm0VpfYtN/5/rr/AMBl/wDjlH2LTf8An+uv/AZf/jlHKwujNorS+xab/wA/11/4DL/8co+xab/z/XX/AIDL/wDHKOVhdGbRWl9i03/n+uv/AAGX/wCOUfYtN/5/rr/wGX/45RysLozaK0vsWm/8/wBdf+Ay/wDxyj7Fpv8Az/XX/gMv/wAco5WF0ZtFaX2LTf8An+uv/AZf/jlH2LTf+f66/wDAZf8A45RysLozaK0vsWm/8/11/wCAy/8Axyj7Fpv/AD/XX/gMv/xyjlYXRm0VpfYtN/5/rr/wGX/45R9i03/n+uv/AAGX/wCOUcrC6M2itI2FiwxHqEobsZoNq/iVZj+hqhNDJBM0Uq7XXqOv0IPcd896TTQJjKKKKQz0D9oP/k43xF/27f8ApLFRR+0H/wAnG+Iv+3b/ANJYqKmfxM9HNf8Afa/+OX5sP2fP+TjfDv8A28/+kstef16B+z5/ycb4d/7ef/SWWvP6pfCKr/uVP/HP8qZ0vw/8U/8ACFfEvSPEzQ+dFaTfvkC7mMTqUk2jI+bYzbcnGcZ4rtvj14Ul8OfF+8vYrby7DV/9Ngdd7KXP+uBZuN3mbmKgkAOnTIA8kr6E0Rf+FufsvS6OIvO8S+Edv2bZHl5YAp2INsf8UasgRTlnhjZjzWkNdDqy9fWsNUwX2vjj6pe8vmvyPB6KKKDxQr2/9mj4JyfFr4k/atXgkHhbSGWbUH5UXDHlLZT6vgliOiBu5FeUeGvDGteLfFum+G9DsnuNQ1GYQ28eMBiTySeygAknoACT0r9Tfhf4I0X4XfDDTvCGjlZFtlMlzdbcG6uGx5kp+pAAHZVUdq48bifYwst2deEwzrS8kdfFaWunw+axEcUK5CoNqIqjoAOMADAHbFef/Du2F9NrniW3jyl5fvbQHP3YoScgeg8x5c+6+1Zvx2+Kth8PPhPqV88qvfTRGK1tweZZG4RQOvJ/QMe1d18PNBbwl8J/D3h24Yy3VnYRpdSHrJOw3zMfrI7mvBSfK2fRObppRe7/AC/4f8hdY8MeF9TS2vPFFjZy3IxaxTksjBnOFVSCDnJO09QSSMZNUtS+Enw51nwVP4W1HwtZXenzHc3nZaYMM4cTH94GXJAIbgcdOK574va6LR/DGnw3AiuJtUEyANg/u4pGH16Z/Cur8NeKYda0xZWZUuUwJo/Q+o9jUpuNmmVOhOVLnez6Hwr8av2dNf8AhLdPrmh239v+E3fAuGiBubIk8JOB1HYSKME8EKSM+Px6za3mlz2seIWkCvCwUcSLyoyOxBI/Gv1M8apaar8NPEFhdhTDNptwrbug/dsQfwIB/CvzA8T6BZ2niDPmrAt4qSIxGBDI+flYdgWBB9Dj1r06GIdRcsycJgpRTrU2tHytPZqSa+Xa/RtbHJQXZh1GWdV8t549uBxtOcniui0+5+w6KbnPzFt6D1PRf5VzdzBONVWG8jEV0sjK49Cf/wBfFbjW7zPHESEgjGBjqa790eGnKjUcVo0/RljEWsrcxXso86+dXjlLYCTfNtLezFtvtnPauPkjeKZopEZHQlWVhggjqDXcprGm2+gXumfZ/OCDcm3oCc5y31APHfNYetQ/bvEsnmFlmaOPzvLjL7pfLXfwPfOffNXRm7NNbHXm9KNSVPEQld1Fd9LPZ/fuYFFWJLOeG3WWQKu44Cbhu/756iq/etk09jxZQlH4lY6z4a+FJfGXxP0rRfs3n2hmE16DvCi3QgybmXlcj5QePmZRkZzWj8dvFP8AwlHxq1LZD5cGl/8AEqjyuGbynbeW5IP7xpMEY+XbkA5rvPBq/wDCp/2ddT+IdxF5Wv67i00rfH80SnOxhujOM4ebByjrHF0Jr56py0Vj2MUvqmChh/tVPfl6fZX5sKuaXGkmqJ5ih1RXl2sMhiiFgCO4JHPtVOr2kf8AITP/AFwm/wDRTVEdzxHsPZmd2d2LMxyWJySfWkoq1pmnXesa3Z6Tp8Rmu7ydLeCMdXd2CqPxJFaiKtFexeP/AIV2ml+JvDcFrpt74W0y9u30ae81mKWJXlhcA3n73GElR0cDIUEOAQBxnXXwwsbVJLV9RubGJ9T020Goa5YCzZEuFu9zoUuZImi/0cfMSckYDIFbeAeXUV6tB8P/AAhpc3iu38RXfieGKy0OG/tbqbR4kkVmvoITJHGt4UlXD7Ad+Dvc8GNQ1DX/AIWW/h/wK+sXXi7Sv7UjtYLt9LN1ab2WYIQiKtwZjIFkDENCowrEMeMgXPOKK73xt8PtM8Lxa5/ZfiaXVpdD1kaNfrJYfZgJG84o0Z8xtw/0eQNkLg4xuBzV3QfCGg658CmuIrVl8VS6jetZziVsTxW1vbSPbbM7dxWaV1IG4mMLzuFAXPNaK9ovPg5p2r+OvE9hpV/JoyW+sXdhpdvcfZ/s8wi5CCSa6WZ2GQCEikIypJOcDltL+HemXuiW73nieS11a50a81yCxSwMkZhgjmcI0vmDDv5DcbSApzkn5SCucBRXoWrfDEaf8MD4rh1eT7TBDbT3emXiW0UsaTbQrKkdzJLty64MkUeQwPtWr8KPhmfGPh7Ub648N6pqq3c40exns4pWSxuHjZ/tMpTgIjeSpD/LtlY/w5AO55RRXVeK9DtNH8KeEZ47Nre9vbC4lvtzNlpUvriEZBOFIWNFwMdPXJrptT8Bs3gfRrHQvDMF3q720dxqV0t632iykk3SIJ0LeUkDQGNg2BgkhnBBWgDy+iu9+Fui+GNZv/EK+K4N1nb6Tvjn810+ySyXdvAJ/lI3bBMzbTkHHIrp734XaVFpPhPwrJF9h8T3WvR6Tq1/uaURPMqOqCPcFPlrImcYJbcCemAVzxuivQfA/he1lsbbX73ybqK8tPENuLSaAMsb2uleckoJJyd06kcDaYwQcnjT8R+CvCUb6mnhq6uHltfDGm6lLFqFr5KRyT/2eN8couSNzm6dm3rsTLKoPyugM8ror1fwj4S0HTPC/ie78XJ4PnurK6sIYLjUdQuruzRZluWZQ+luxZz5SdSQNpzgnk07wj4MuPCd7rGvSyWUcnhw6rbvpFnJP5Lf20bTdtmuV3nYAgB2jY+SN6bpAVzyiiuvvfA32NtcA1TeNL0Ox1rPkY837SbT91975dv2z73OfL6DdxW8eeGtK8IeNtQ8Nadrk+rTaddTWl1M9mLZA8blfk/eMW6c5AwcgbhyQZzNFFFABRRRQAU+5US6J5jfegmVFP8AsuGJB9gVyP8Aeb1plSS/8i/P/wBfEX/oMlJ7AZdFFFZFHoH7Qf8Aycb4i/7dv/SWKij9oP8A5ON8Rf8Abt/6SxUVM/iZ6Oa/77X/AMcvzYfs+f8AJxvh3/t5/wDSWWvP69A/Z8/5ON8O/wDbz/6Sy15/VL4RVf8Acqf+Of5UwrqPh94u1XwR8QLHXtJt3u5FJiks1dlF1G3BjO3qehGQQGVTg4xXL13vwo8Z3HgvxZLd21hZXjXEYieK5hVy8ecsisfuk8dM5xg5HFF7anJQnOnUjOm7ST09TpfjJ4DsNJvY/G3hU2h8M6rIFjigBjNpOU3NGY25XO12xgbDuQquFz55ounx3eoLJeOkNnHl5JJQ2wgfw5UdScD8e1e1+MdOml8Iah4z+Ht1cHwpcvu1HSYRtfSpAQ2x4unlg4KuPu8Z4ANeX29rdanPstmvb1QS5SLkjjk4HT3OKUqvkd+JjDEV3OnHlvvHz628vLpsdOPEd5puuaTceHr65sDp4Wa2mhuDti2nJVMEAZGQQRyCc5zX1z4h/aU8FaX8KovGiXbCO4DJHaEAziYfehCZ5YZGT90Agk4Iz8JgvpztapbPhyOPU8jB49ecD+lch4hu4rrUEt4ZftDxZVp1bKuxxwPYdM9/piuGth41Em+h0fX5UpOTirv5JdrL0/rv7l4M8TeI/wBoX9r7wifEwdNHi1D7YlnnMUcMP71hk/fZvLCk98gAAYFfpFPqaxRSSzvswCzk9u5r8uJxZaX4eXTpLRkurWUxxeSS8aoGJyHU8/MxPTPU57V6Rb/tA+P7D4Wx+EEihu1gtmhTWpZZHlReWWR+oJUEAZP8K5zisK2Gc7KPQ6KVoNyqy5m0m2tbeW2j/A9z8Y61beK/E1/r2oTi30rTkaK0uGOPKKnL3CnttKhQe+1+oNRfDn4gw+JdBj13SJvKuIXMNzFjBRx6r/dYYYexx1Br4u/4S/V7rw1BoN1qd2bODJjhlnd4c5zynrk59PYVZ8GeN9X8F+JJdV03UDG0yGOZGTzYpR23oSM4OCCCCD7E1UsBLla69Dup5xh/dS2e/kfcfxW+Klrp/wAJL/T2Ig1TU4/sduhOUbJG9jznaFzn6gZyRXxr4h1S21g30l8jy3ZGwSPJnJ3uzkN/F/CBu55OKy/EnirW/FOoPqV/eS30zDaJjgCNf7qIv3B7fjyawPOnMPlPwoGMnjitsNh5U42Zx5lisM+VUldp6u+lu3b5/IdePLfrFqFwN1xERHNzywxjJPr0P4mo/tVw3+iWUsr7jtIcbdnsSf5Cliu7eC2u1b52kjCoB03Z6n6DP44rb8AWuga/8RdL0rxj4hbQ9Knm2y6ksat5PBwTngAnALHp1NdXJyxPNxNeOInGV/ee/re2r81YzVs72zWOORIXLyhhtLHleQM474q/b6fqtpcfaIlWZyMsefmB5zzX2ZpvhX9l3wN4gHhDW7WxufETBGgl8VTPLBdxvwksMwBgCsOhwMHIPSvH/j78KPCfhXw4/iHwRby6bPbXIW/tEmdfKD9B5bMxXnBUqSjK2VJAIHLDEKUlFaXOtU48r9pHm5V0dmlq+2vzPJkktrpvLvIDFN1Ungj6MP8AGneGfCmial8RtOtfEOpw2WmmZri7mu3KrNGp3GPcMbCcEFiRgEt2xWZ4ctvEGu21/JHEJrLT4DPcXcxCLB/cG89WYjaF5J57AkTXlzvjS7LKUBVE4zuO7k+4xkfia6o3jJXOe0IctWKvDe0vJ/j2uul0M+LHjtPG/jYf2bFHbaDpiGy0u3g3LH5KnAkCEAKWAXgKMKqKc7cng6knEYupBFnywxC59M8VHWrd3c87E154irKrU3YVe0j/AJCZ/wCuE3/opqo0+GWSC4jnibbJGwdTjOCDkUJ2Ziy7V3SNX1DQtZg1bSrj7PeQEmKXYrFCQRkBgRnBOD1BwRggGq8Ygu13wSwwv/FDLJs2+6s3BHtnP1xkv+xyf897P/wLi/8Aiq1JLumeJNW0ixexs5bd7V7mK8a3urWK5jaWMOqMUlVgcCRwRjBzyDgY1Lr4ieK70JHc3WnvbRywypZf2Zai1VofO8sCAR+WFBuZyV24YuSQTgjnvscn/Pez/wDAuL/4qj7HJ/z3s/8AwLi/+KoFodCPiL4rGs/2l9qsNwtDYfZf7MtfsnkGTzPL+zeX5O3zPnxs+9z15qte+NPEGpeHE0TUJbC6t0jSFJptOtnukjQjYi3Jj85VAAAAfG35enFY/wBjk/572f8A4Fxf/FUfY5P+e9n/AOBcX/xVAaF/UfFGu6sdXOoX3nf2xfrqd9+6RfOuF83D8Abf9fLwuB83TgYSx8Ta7pltpsFhqDwJpt82pWmxVzFcMIwXBxk8Qx8HI+Xpyc0fscn/AD3s/wDwLi/+Ko+xyf8APez/APAuL/4qgNDrIPix49ttRub+LWoTdXF5LftO9hbu6TS48xo2aMmMPgBlTapAwRV7RPig+ifDefw5Fp1zcXslnc6fHd3E8LRwQThg6Iog84DDudvnFNx3bc1wv2OT/nvZ/wDgXF/8VR9jk/572f8A4Fxf/FUBob978QfFuoeGZdAu9ShexmhhgmC2cCSTpEV8oSSqgdyuxQCzEgDGcEisebWdTuNK0/TZLo/ZdPMjWsaKF8tnYMzZABJJA5OTgAdAKg+xyf8APez/APAuL/4qj7HJ/wA97P8A8C4v/iqA0NHxD4q17xXdxXOvXq3UsXm7GEMcWPMmeZ+EUA5kldv+BemBWtbfE/xtZ2EdpBqsG1LcWZkewt3lktwu0QSStGXki2gDy3JXAAxwK5j7HJ/z3s//AALi/wDiqPscn/Pez/8AAuL/AOKoDQlsdWv9OtdQt7KfyotQt/sl0uxT5kXmJLt5HHzxIcjB4x0JFT2XiPW9OsrS0sb97eK0vRqNv5aqGjuAFAkDYzkbV4zjiqf2OT/nvZ/+BcX/AMVR9jk/572f/gXF/wDFUBdHRXvxG8X35t/P1G3RbdLtIY7axt4I4xdwiG4wkcYX50GDxwcsMMSarXPjfxJd6L/ZU95btbmxXTXZbOBZZLdXidI3lCB3Cm3h27mJULgYBION9jk/572f/gXF/wDFUfY5P+e9n/4Fxf8AxVAaEsOrahb6Bd6LDcbbG8miuJ4dine8QcRnOMjAlk4Bwd3OcDGnpvjbxJpX2VbW8t2jtrJtOjgubOC4iNu07XBjeORGWQeaxf5gSDjHQYx/scn/AD3s/wDwLi/+Ko+xyf8APez/APAuL/4qgNDdn8f+LLnwtL4em1GJrCa1ispVFpCJJYYnR40eUJvYIY025Y7QNowCQcbVtUv9c1++1rVJ/Pvr64kurmbaq+ZI7FmbCgAZJJwABUf2OT/nvZ/+BcX/AMVR9jk/572f/gXF/wDFUBoV6KsfY5P+e9n/AOBcX/xVH2OT/nvZ/wDgXF/8VQFyvRVj7HJ/z3s//AuL/wCKo+xyf897P/wLi/8AiqAuV6kl/wCRfn/6+Iv/AEGSpDa7Bulu7NEHVhOr4/BCSfwFUby6WYJDCCIIySu77zE4yx9M4HHQYHXklSdkPcq0UUVkUegftB/8nG+Iv+3b/wBJYqKP2g/+TjfEX/bt/wCksVFTP4mejmv++1/8cvzYfs+f8nG+Hf8At5/9JZa8/r0D9nz/AJON8O/9vP8A6Sy15/VL4RVf9yp/45/lTClVmRw6MVYHII6g0lFB553Hhz4iarpWrQXKXAtZQAkk0eQs46fvFzg/XHc5Bya7cafZ+JJJR4a1NPD8kzGSSztoh5ZkJyp+UhgmegGQOwHSvEK0NO1rUdLkV7O4ZChyvP3T7elTyq1rHXSxc41OeUnrvbdr1Oq8VT+JvDenX1rrd3dCaVPJRi+5ZyeNwbHICg88EcA4rkdC0MRldQ1BBnb5kMDoHB95FJHy9OMc57Dr6/pyeIvGPhWy8SSRWOo3EJkSO2jbMsIXG6RY24aQ46qSwUDAFcrqF3azxErbvNKDu8tVfcx+mM5/WsXCz2OytNVpc7qOSW13r+f5GZBDLcxNIZZYQfurGWUOeOcHoOef8mrV7LewaBeQz38iTOgL2UWQqLuAzJnHzHjCgcA8kdK6PR9H8SNBeXNvp8uluUUR3d1EUMMPVpApGRgcA4AAJOR1rL1+Dwlpvh26itNYn1PVp8LuY5A+cEsdvGcDuT1pqLbV1oa3jTouUH7zT62stV31fl0T6nCUUUV1nhihipypIPtQzs33mJ+pzSUUAFblp4auHsBfahcxWELoWhSQFpp+ONkY5weOTge5qhps1ra3gurqMSiPlYiMhm7ZHoK7jQvCnjj4gahFcaV4YkkguOf7RvAyW4QPsJ3nCtg5yF3NweDg1nLmbtE9LA4SFbf3pPaKu/m7f8D1OOa01G6ESXV4pEMYjjWafdsQEnaBk4GSTj3NaEtoLkuLu/uroJEIbcSM7tGoOQBxjbycDgDNernwh8JPhTIt38QdYHiDX0Kv/Yunrujib922CmRnGSQZWVXQn5CRXlvjn4l6x41nigW0tNG0m2Ux2+m6cvlxhN2V3kY3sAFHQKNvCrk5covub18DDBxf1ia5/wCVav8A7e6L8WXZdblt9DXR7VpoNJSR3S2ldYkZjgbpMAeY2FALEdBgADiua1HVYt7mGQTTMMB1BCRD/Zz1PvWESScmis+TucVTFuWy183e3psl9wUUUVZxhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB6B+0H/AMnG+Iv+3b/0lioo/aD/AOTjfEX/AG7f+ksVFTP4mejmv++1/wDHL82H7Pn/ACcb4d/7ef8A0llrz+vQP2fP+TjfDv8A28/+kstef1S+EVX/AHKn/jn+VMKKKKDzwooooA0dJ17WNDnM2k6jPaMevltw31HQ11T/ABj+Icli1q3iGXay7d4RQ+PqOlcJRQNNo7jwn8W/G3g/WZtQsNQjuhOcz297H5kcmAQOmGXls/KwyQM5AxXeTfGX4b+L5QfiJ8L42nKK8uoaXKPOmmVQnPMbhMZwDI2MKMHGR4XRVKTR6GHzXE0IeyUrw/laTX3O/wCB7n/ZP7M96Ptn/CZeI9O8/wDe/YvKdvs+7ny8+Q+ducZ3N0+8etL/AMKZ+H//AEXXw1+UH/yRXhdFPn8jb+0qE/4uGg/Tmj+TPdP+FM/D/wD6Lr4a/KD/AOSKT/hFv2crM/Y7/wCJOtT3cP7uaW1hYxO44ZkxbsNpIJGGYYxyeteGUUc/kH9o4eP8PDR+bk//AG491g+K3wd8K3cV34M+FUt1OXEjy6rOA8DIco0RYzEHJJJG3ovXjHJ+Kfjt8R/FHlp/bH9iwR4PlaMXttzDd8xfcXPDY27tvAOMjNebUUnNsirnGKnH2cZcse0Uor8LfiFFFFSeWFFFFABRRRQAVr+FVsn8caQmowrLateRLIjEBSCwHzZBBX1HcZHGc1kUUIGev6Jpos/FGqJbwX2mwRa5Zf6HLsKyAzPhh+7BC45UA4werVWtfDmi2vxVsfPtZNTtr/7U32mRkNu8u1z5YQqeVPy4Yg7sHAxg+U0Vpz+RHJ5noGj+CNM1KFZLiHVbZpLt7eWMyJnTVVQQ8+UGcn2T65q7faDaah8K9HufNmu7iys5zFa2rBWdfPbMpyDlFxyAM8joOa8yopcy7D5X3Ox0/wAFukGqpqtjf3WpWEkcf9lafKnmkOM78hXyoGOgPXtVm08F6XceF01B57xS9nNcvd718i2kQkCBxtyWOPUHngGuFopXXYLPuejS+DvCtro011P/AGxJJbafaXsmy4jVXMxClVBjOACc5Oar33hXTtH1w6DKTMLzVlt4pXA8wQoAWwccFmkVc+qGuBqRridkiRp5CsIxGCxwgzn5fTkk8dzT5l2Dlfc9Mu9I0648GS3UulQwRCCORZ44o40jLQSSfK4XexV0SMh2bJJ6EjGfd+C9AXSJPIub+G7h0211CSaaRGi/esAy7QgIAznO6uSvfEGrahaNb3dxG6uQZHEEaySkdN7hQz/8CJrMocl2Eos9G1jwL4c0m8sBJfak1vLfR20kwjfZJGw/1iSGIICD/CGfI70uo/D3SNL0i8ubrVJhJZKILgblwlw7RmPtymyQk98qeRXnFFHMuw+V9z1+48JadZ+FJ9CDXtlZz61bxG/vHVkmXYf3keFACnOOp7c9axB4D0htV0+CWXULFrj7TmwuHQ3EnlDKFDtAG/tkfTNed0UOS7CUX3PWNa8NWl9b6RbTWmpRPZ6L5sWl71+1St5p+TOzqMkn5M47VSsfh5otzrupWC3N/O1v5XlBSURCybmWWZYpFVlPHIH9K80oo5l2Dlfc9Asvh/BdeBbrWJTLFNDZzXaSxz+bE/lk/KQIgq5A/wCehPfGOmrbeHtP0TwJrk0UOoXEE+m20kl9vXyZtzqzJH8vBHTkn3A7+VUUcy7DcW+p6UPh94fTVbS1n1iZV1CR57Fg6/vLURhlzhSd7M20YH8LYB4FVpPBmgWuqagLl9Wa3tdKN+YCrQSBw4XbulhXcv8AtBB+lefUUcy7ByvuenP4Y0Ow0DxNaW+mXmozJFZXUBDoZ443UsdpEZwFOdxAwRj7uMmhceArOPQrrVozfNaJpttdQz7lKPLIwDrnbyBk8DkcZrgKKOZdg5X3PRm8E+GpfHOqaDbT6in9nRFtssweS6b5eECQkqBk5wrk8cDmuP8AEul22jeJrjT7OW4khj2lTcwvDIMqDhldVPGeuBnr3rJopNp9ASa6hRRRUlBRRRQAUUUUAegftB/8nG+Iv+3b/wBJYqKP2g/+TjfEX/bt/wCksVFTP4mejmv++1/8cvzZyngTxM/g74k6N4lV5VSzulecRIru0J+WVVDcZMbOB069R1rd+KPhK38H/EW5s9Nkim0e8RdQ0yaKQOj20uSm1tzEhSGQMTltu7oRXA13fg7xVok+nweC/iCtzP4a87zLa8tj/pOkuxG94iQcxP8Axx4I/jUbh8zi+jFQnCrSeGm7a3i3sns0/J6a9GlfS5yFFemzfBbWdVlE/wAO9c0fxnYlEkaSzuo4J7cMoK+fDI4MZJ3gDJPyHIU8VH/woH4t/wDQp/8Ak/bf/HKrlYPKcZ0pSfmk2vk1dP5M82or0n/hQPxb/wChT/8AJ+2/+OUf8KB+Lf8A0Kf/AJP23/xynyvsH9k47/nxP/wF/wCR5tRXpP8AwoH4t/8AQp/+T9t/8co/4UD8W/8AoU//ACftv/jlHK+wf2Tjv+fE/wDwF/5Hm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcr7B/ZOO/wCfE/8AwF/5Hm1Fek/8KB+Lf/Qp/wDk/bf/AByj/hQPxb/6FP8A8n7b/wCOUcr7B/ZOO/58T/8AAX/kebUV6T/woH4t/wDQp/8Ak/bf/HKP+FA/Fv8A6FP/AMn7b/45RyvsH9k47/nxP/wF/wCR5tRXpP8AwoH4t/8AQp/+T9t/8co/4UD8W/8AoU//ACftv/jlHK+wf2Tjv+fE/wDwF/5Hm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcr7B/ZOO/wCfE/8AwF/5Hm1Fek/8KB+Lf/Qp/wDk/bf/AByj/hQPxb/6FP8A8n7b/wCOUcr7B/ZOO/58T/8AAX/kebUV6T/woH4t/wDQp/8Ak/bf/HKP+FA/Fv8A6FP/AMn7b/45RyvsH9k47/nxP/wF/wCR5tRXpP8AwoH4t/8AQp/+T9t/8co/4UD8W/8AoU//ACftv/jlHK+wf2Tjv+fE/wDwF/5Hm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcr7B/ZOO/wCfE/8AwF/5Hm1Fek/8KB+Lf/Qp/wDk/bf/AByj/hQPxb/6FP8A8n7b/wCOUcr7B/ZOO/58T/8AAX/kebUV6T/woH4t/wDQp/8Ak/bf/HKP+FA/Fv8A6FP/AMn7b/45RyvsH9k47/nxP/wF/wCR5tRXpP8AwoH4t/8AQp/+T9t/8co/4UD8W/8AoU//ACftv/jlHK+wf2Tjv+fE/wDwF/5Hm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcr7B/ZOO/wCfE/8AwF/5Hm1Fek/8KB+Lf/Qp/wDk/bf/AByj/hQPxb/6FP8A8n7b/wCOUcr7B/ZOO/58T/8AAX/kebUV6T/woH4t/wDQp/8Ak/bf/HKP+FA/Fv8A6FP/AMn7b/45RyvsH9k47/nxP/wF/wCR5tRXpP8AwoH4t/8AQp/+T9t/8co/4UD8W/8AoU//ACftv/jlHK+wf2Tjv+fE/wDwF/5Hm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcr7B/ZOO/wCfE/8AwF/5Hm1Fek/8KB+Lf/Qp/wDk/bf/AByj/hQPxb/6FP8A8n7b/wCOUcr7B/ZOO/58T/8AAX/kebUV6T/woH4t/wDQp/8Ak/bf/HKP+FA/Fv8A6FP/AMn7b/45RyvsH9k47/nxP/wF/wCR5tRXpP8AwoH4t/8AQp/+T9t/8co/4UD8W/8AoU//ACftv/jlHK+wf2Tjv+fE/wDwF/5Hm1Fek/8ACgfi3/0Kf/k/bf8Axyj/AIUD8W/+hT/8n7b/AOOUcr7B/ZOO/wCfE/8AwF/5Hm1Fek/8KB+Lf/Qp/wDk/bf/AByj/hQPxb/6FP8A8n7b/wCOUcr7B/ZOO/58T/8AAX/kebV2Xwu8JW/jD4i21nqUkUOj2aNqGpzSyBES2iwX3NuUgMSqFgcru3dAa24fgtrOlSmf4ia5o/gyxCPIsl5dRzz3AVSW8iGNyZCDsBGQfnGAx4rB8Y+KtEg0+fwX8PluYPDXneZc3lyf9J1Z1J2PKQBiJP4I8AfxsNx+Vbas0p4N4aSq4uNkvsvRvytul3b6bXZi+O/Ez+MfiTrXiVnlZLy6Z4BKio6wj5YlYLxkRqgPXp1PWiueorJu5wVakqs3Unu3d/MKKKKCAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD//Z",
	"semangat": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwMDAgQDAwMEBAQFBgoGBgUFBgwICQcKDgwPDg4MDQ0PERYTDxAVEQ0NExoTFRcYGRkZDxIbHRsYHRYYGRj/2wBDAQQEBAYFBgsGBgsYEA0QGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBj/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4Poors7S0XwQlrqep2ST65KontbO4U+XapniSQcZc4O1c/L1POANpStotzrwOBeKblJ8tOPxS3ST8urfRdfJJtZemeCvFWrwefY6LcNFtV1eXESuGGQVLkbh9M9vUVd/4Vn43/wCgJ/5Mw/8AxdSWLat488YWun6rq8peXftkZdyx4Qk7UBAGdgzjHrXX/wDCm/8AqY//ACT/APtlc1Wt7N2nJJ+jf6n2OUcL082pSrZfhKtWEW483taVO7ST+FwlbRr7Ul5nGf8ACs/G/wD0BP8AyZh/+Lo/4Vn43/6An/kzD/8AF12f/Cm/+pj/APJP/wC2Uf8ACm/+pj/8k/8A7ZWf1uH/AD8X/gL/AMz1f+IfYv8A6FtX/wAKaP8A8rOM/wCFZ+N/+gJ/5Mw//F0f8Kz8b/8AQE/8mYf/AIuuz/4U3/1Mf/kn/wDbKP8AhTf/AFMf/kn/APbKPrcP+fi/8Bf+Yf8AEPsX/wBC2r/4U0f/AJWcZ/wrPxv/ANAT/wAmYf8A4uj/AIVn43/6An/kzD/8XXZ/8Kb/AOpj/wDJP/7ZR/wpv/qY/wDyT/8AtlH1uH/Pxf8AgL/zD/iH2L/6FtX/AMKaP/ys4z/hWfjf/oCf+TMP/wAXR/wrPxv/ANAT/wAmYf8A4uuz/wCFN/8AUx/+Sf8A9so/4U3/ANTH/wCSf/2yj63D/n4v/AX/AJh/xD7F/wDQtq/+FNH/AOVnGf8ACs/G/wD0BP8AyZh/+Lo/4Vn43/6An/kzD/8AF12f/Cm/+pj/APJP/wC2Uf8ACm/+pj/8k/8A7ZR9bh/z8X/gL/zD/iH2L/6FtX/wpo//ACs4z/hWfjf/AKAn/kzD/wDF0f8ACs/G/wD0BP8AyZh/+Lrs/wDhTf8A1Mf/AJJ//bKP+FN/9TH/AOSf/wBso+tw/wCfi/8AAX/mH/EPsX/0Lav/AIU0f/lZxn/Cs/G//QE/8mYf/i6P+FZ+N/8AoCf+TMP/AMXXZ/8ACm/+pj/8k/8A7ZR/wpv/AKmP/wAk/wD7ZR9bh/z8X/gL/wAw/wCIfYv/AKFtX/wpo/8Ays4z/hWfjf8A6An/AJMw/wDxdH/Cs/G//QE/8mYf/i67P/hTf/Ux/wDkn/8AbKP+FN/9TH/5J/8A2yj63D/n4v8AwF/5h/xD7F/9C2r/AOFNH/5WcZ/wrPxv/wBAT/yZh/8Ai6P+FZ+N/wDoCf8AkzD/APF12f8Awpv/AKmP/wAk/wD7ZR/wpv8A6mP/AMk//tlH1uH/AD8X/gL/AMw/4h9i/wDoW1f/AApo/wDys4z/AIVn43/6An/kzD/8XR/wrPxv/wBAT/yZh/8Ai67P/hTf/Ux/+Sf/ANso/wCFN/8AUx/+Sf8A9so+tw/5+L/wF/5h/wAQ+xf/AELav/hTR/8AlZxn/Cs/G/8A0BP/ACZh/wDi6P8AhWfjf/oCf+TMP/xddn/wpv8A6mP/AMk//tlH/Cm/+pj/APJP/wC2UfW4f8/F/wCAv/MP+IfYv/oW1f8Awpo//KzjP+FZ+N/+gJ/5Mw//ABdH/Cs/G/8A0BP/ACZh/wDi67P/AIU3/wBTH/5J/wD2yj/hTf8A1Mf/AJJ//bKPrcP+fi/8Bf8AmH/EPsX/ANC2r/4U0f8A5WcZ/wAKz8b/APQE/wDJmH/4uj/hWfjf/oCf+TMP/wAXXZ/8Kb/6mP8A8k//ALZR/wAKb/6mP/yT/wDtlH1uH/Pxf+Av/MP+IfYv/oW1f/Cmj/8AKzjP+FZ+N/8AoCf+TMP/AMXR/wAKz8b/APQE/wDJmH/4uuz/AOFN/wDUx/8Akn/9so/4U3/1Mf8A5J//AGyj63D/AJ+L/wABf+Yf8Q+xf/Qtq/8AhTR/+VnGf8Kz8b/9AT/yZh/+Lo/4Vn43/wCgJ/5Mw/8Axddn/wAKb/6mP/yT/wDtlH/Cm/8AqY//ACT/APtlH1uH/Pxf+Av/ADD/AIh9i/8AoW1f/Cmj/wDKzjP+FZ+N/wDoCf8AkzD/APF0f8Kz8b/9AT/yZh/+Lrs/+FN/9TH/AOSf/wBso/4U3/1Mf/kn/wDbKPrcP+fi/wDAX/mH/EPsX/0Lav8A4U0f/lZxn/Cs/G//AEBP/JmH/wCLo/4Vn43/AOgJ/wCTMP8A8XXZ/wDCm/8AqY//ACT/APtlH/Cm/wDqY/8AyT/+2UfW4f8APxf+Av8AzD/iH2L/AOhbV/8ACmj/APKzjP8AhWfjf/oCf+TMP/xdH/Cs/G//AEBP/JmH/wCLrs/+FN/9TH/5J/8A2yj/AIU3/wBTH/5J/wD2yj63D/n4v/AX/mH/ABD7F/8AQtq/+FNH/wCVnGf8Kz8b/wDQE/8AJmH/AOLo/wCFZ+N/+gJ/5Mw//F12f/Cm/wDqY/8AyT/+2Uf8Kb/6mP8A8k//ALZR9bh/z8X/AIC/8w/4h9i/+hbV/wDCmj/8rOM/4Vn43/6An/kzD/8AF0f8Kz8b/wDQE/8AJmH/AOLrs/8AhTf/AFMf/kn/APbKP+FN/wDUx/8Akn/9so+tw/5+L/wF/wCYf8Q+xf8A0Lav/hTR/wDlZxn/AArPxv8A9AT/AMmYf/i6P+FZ+N/+gJ/5Mw//ABddn/wpv/qY/wDyT/8AtlH/AApv/qY//JP/AO2UfW4f8/F/4C/8w/4h9i/+hbV/8KaP/wArOM/4Vn43/wCgJ/5Mw/8AxdH/AArPxv8A9AT/AMmYf/i67P8A4U3/ANTH/wCSf/2yj/hTf/Ux/wDkn/8AbKPrcP8An4v/AAF/5h/xD7F/9C2r/wCFNH/5WcZ/wrPxv/0BP/JmH/4uj/hWfjf/AKAn/kzD/wDF12f/AApv/qY//JP/AO2Uf8Kb/wCpj/8AJP8A+2UfW4f8/F/4C/8AMP8AiH2L/wChbV/8KaP/AMrOM/4Vn43/AOgJ/wCTMP8A8XR/wrPxv/0BP/JmH/4uuz/4U3/1Mf8A5J//AGyj/hTf/Ux/+Sf/ANso+tw/5+L/AMBf+Yf8Q+xf/Qtq/wDhTR/+Vnn+p+CvFWkQeffaLcLFtZ2eLEqoFGSWKE7R9cd/Q1gV3es2urfDnxLHbaVrkrPLAszMsexWyXUBkJYNjBxnpmq93aL43S61PTLJINciUz3VnbqfLukzzJGOcOMjcufm6jnIPRGo7KT1i+v/AAD5LHZJSVaeFw8ZQxEHrTk4zvZXfLOKSlLry8q00Tk9HxlFFFbny5v+CtMi1fx/pdjPs8ozeY6ugdXCAuVIPUHbj8e9M1vVZtc8Q3eq3A2vO+4LwdijhVyAM4AAzjnFaHwz/wCSpaX/ANtf/RL1z9RDWq/Rfjf/ACPcrNwyWko/bq1L+fJCny/dzyt6sltrq5s7pbmzuJbeZM7ZYnKMuRg4I56E1of8JN4k/wChh1X/AMC5P8ayqK1cYvdHlUcZiKEeWlUlFeTa/I1f+Em8Sf8AQw6r/wCBcn+NH/CTeJP+hh1X/wAC5P8AGsqil7OHY1/tTG/8/pf+BP8AzNX/AISbxJ/0MOq/+Bcn+NH/AAk3iT/oYdV/8C5P8ayqKPZw7B/amN/5/S/8Cf8Amav/AAk3iT/oYdV/8C5P8aP+Em8Sf9DDqv8A4Fyf41lUUezh2D+1Mb/z+l/4E/8AM1f+Em8Sf9DDqv8A4Fyf40f8JN4k/wChh1X/AMC5P8ayqKPZw7B/amN/5/S/8Cf+Zq/8JN4k/wChh1X/AMC5P8aP+Em8Sf8AQw6r/wCBcn+NZVFHs4dg/tTG/wDP6X/gT/zNX/hJvEn/AEMOq/8AgXJ/jR/wk3iT/oYdV/8AAuT/ABrKoo9nDsH9qY3/AJ/S/wDAn/mav/CTeJP+hh1X/wAC5P8AGj/hJvEn/Qw6r/4Fyf41lUUezh2D+1Mb/wA/pf8AgT/zNX/hJvEn/Qw6r/4Fyf40f8JN4k/6GHVf/AuT/Gsqij2cOwf2pjf+f0v/AAJ/5mr/AMJN4k/6GHVf/AuT/Gj/AISbxJ/0MOq/+Bcn+NZVFHs4dg/tTG/8/pf+BP8AzNX/AISbxJ/0MOq/+Bcn+NH/AAk3iT/oYdV/8C5P8ayqKPZw7B/amN/5/S/8Cf8Amav/AAk3iT/oYdV/8C5P8aP+Em8Sf9DDqv8A4Fyf41lUUezh2D+1Mb/z+l/4E/8AM1f+Em8Sf9DDqv8A4Fyf40f8JN4k/wChh1X/AMC5P8ayqKPZw7B/amN/5/S/8Cf+Zq/8JN4k/wChh1X/AMC5P8aP+Em8Sf8AQw6r/wCBcn+NZVFHs4dg/tTG/wDP6X/gT/zNX/hJvEn/AEMOq/8AgXJ/jR/wk3iT/oYdV/8AAuT/ABrKoo9nDsH9qY3/AJ/S/wDAn/mav/CTeJP+hh1X/wAC5P8AGj/hJvEn/Qw6r/4Fyf41lUUezh2D+1Mb/wA/pf8AgT/zNX/hJvEn/Qw6r/4Fyf40f8JN4k/6GHVf/AuT/Gsqij2cOwf2pjf+f0v/AAJ/5mr/AMJN4k/6GHVf/AuT/Gj/AISbxJ/0MOq/+Bcn+NZVFHs4dg/tTG/8/pf+BP8AzNX/AISbxJ/0MOq/+Bcn+NH/AAk3iT/oYdV/8C5P8ayqKPZw7B/amN/5/S/8Cf8Amav/AAk3iT/oYdV/8C5P8aP+Em8Sf9DDqv8A4Fyf41lUUezh2D+1Mb/z+l/4E/8AM1f+Em8Sf9DDqv8A4Fyf40f8JN4k/wChh1X/AMC5P8ayqKPZw7B/amN/5/S/8Cf+Zq/8JN4k/wChh1X/AMC5P8aP+Em8Sf8AQw6r/wCBcn+NZVFHs4dg/tTG/wDP6X/gT/zNX/hJvEn/AEMOq/8AgXJ/jR/wk3iT/oYdV/8AAuT/ABrKoo9nDsH9qY3/AJ/S/wDAn/mav/CTeJP+hh1X/wAC5P8AGj/hJvEn/Qw6r/4Fyf41lUUezh2D+1Mb/wA/pf8AgT/zNX/hJvEn/Qw6r/4Fyf40f8JN4k/6GHVf/AuT/Gsqij2cOwf2pjf+f0v/AAJ/5li8vr7UJxNf3lxdSBdoeeQuwHXGSenJ/OrGiarNofiG01W3G54H3FeBvU8MuSDjIJGccZrPopuKa5baGNPF1qdeOJjN86aafW61TNPxrpkWkeP9UsYNnlCbzEVECKgcBwoA6Absfh2oq78TP+Spap/2y/8ARKUVjRbdOLfZHpcQ0YUc1xVKmrRjUmkuyUmkHwz/AOSpaX/21/8ARL1z9dB8M/8AkqWl/wDbX/0S9c/Th/Fl6L9TTE/8ibD/APX2t/6RQCiiitzwQooooAKKKKACitDStE1bXLo2+lWMty4+8VGFTgkbmPC5wcZPNdZD8L7y3hS48Qa5pulQOowWfcwc87DnaucZ6MenfrWU69ODtJ6ntZdw7mWYw9rhaLcP5to/+BStH8Tg6K9CPh34aWx8i78Tai06ALI0cZ2s3cr+7PB6jk8dzS/bvhXjP/CM6p/38b/47UfWL7Qb+X+Z6P8Aqo4aVsZQg+3tOb1+BStbzt5X1PPKK9D+3/Cr/oWtT/7+N/8AHqb/AGT8K5z5/wDbeq2vmfP5G0nys87c+WenTqenU9aPrD6wf3f5B/qqpfwsbQl/3E5f/S4xX3XPPqK78/DA3v8AyL/ifS9S2f67J2+Xn7v3C/XB646d+3K6v4b1zQdh1XTpbdHxtk4dCTnjcpIzweM5qoV6c3ZPU4cfwzmmAp+2xFB8n8ytKP8A4FFuP473XRmVRUr280dvFO8ZWOXOxj/Fg4P61FWx4bTW4UUUUCCiiigAqW1tpry+hs7ZN80zrHGuQNzE4AyeOpqKtnwt/wAjF/26XX/pPJSk7Js6cHRjXxFOlLaTS+92L0Npo9lH5RsY9Sk6PNPJIqE/9M1QqQPdiScA4XkVJu0j/oXNP/7+3H/x2oK9e+G/gvw9r3gaxvdR0a0vJ7jW3sp5prySGRIBAH/dIsih3B5ACsTk8dx34bAe3lyR39X+h5mb8ULKqH1irBct7WUIPo3vLfbq235s8o3aR/0Lmn/9/bj/AOO0btI/6FzT/wDv7cf/AB2vXfAXgjwjquk2dzqmlS3QbXby0fzJZIneCOzaVUIVhtO4A9j26cVQ8RfDrTovDugf8I/H582t6s0dndl2PmWzqhjDLnAK7mDcA5U1v/ZMvZ+0W3q79P8AM8xcf0PrTwkopPu6dO32r626cre17fO3mO7SP+hc0/8A7+3H/wAdo3aR/wBC5p//AH9uP/jtei/E3wl4d0vSbTWPCcUC2cVzJp115N8t2HdeY5SVdthdQ3ynGNvQVz8PgjzfhDceOv7atV8m7Fr9gI+dskDOc9ec7cdATmsqmXOE3C17K+72O3C8YUsRh6eJ92KnLlSdOF+ZuyTtF2v62sc1u0j/AKFzT/8Av7cf/HaN2kf9C5p//f24/wDjtdd4W0TSZPh94g8U3unf2tcadJBFHYmR0jUOTmWTYQxAxgYI561u+F9I8Da/pupXmr6DcaTLog/tG4treWVheWxX/VfO2UO8rhh/C3cjdTp5cp8utr67vz+XRkYrjH6v7RulzKm1FtU6b1aTSt8T+KKva13vbU803aR/0Lmn/wDf24/+O0btI/6FzT/+/tx/8dr2fQ/BngzW/CGhzNotnDf6xaajPHDHcXXns8Tv5axEsYgqqAD5nJwOpzXM3ui+GtP+DHh/VjaaMmp6jb3ZkkvnvTNIySlFMIiPlAgY+/gZxnPNaSyrljzNq1r7vy/HVHLS48jVqexjRfNz8lvZ09/f10+z+7lr5etvPt2kf9C5p/8A39uP/jtG7SP+hc0//v7cf/Ha9f1zwN4atvhvJqMWiwwyR+H7LUFure6kkuGuZCA++IuwWMjndsUDnB7ClceEPDsfwd/4TJfD8o1F7BF/sz7Q+2LMhT7fjfv2HHCn5cnoVollEotpvZX3exNLj+lUjGShvNQX7ul8TSa+Wvy620v5bu0j/oXNP/7+3H/x2o5NLsNVZYLCyFlfOQsKRyM0Up7KQ5LKxJwG3begIGSwZRXA6EbafqfVRzGbdqkYuPVKMU/k1G69Tm639E0S2nsf7W1YzfYfMaCOK3cJJPIoUsAxVgiqHUkkHO4AD7zJV8Tf8jtrH/X9P/6Maukk/wCRR8Nf9eEn/pXcVySm+RSXU87OIywtR4eL+04322v917f5a6h5mgf9CdpH/f8Au/8A4/R5mgf9CdpH/f8Au/8A4/VSvYfhV8KNF8YeF59c1u7utpmaCKG2cLtwBlmJB554Ht3zWHPLufOY7E0cDS9tWnK3+KX+Z5T5mgf9CdpH/f8Au/8A4/R5mgf9CdpH/f8Au/8A4/XV33gi00344R+CbnUSbRruKL7RwG2OFYD0DYYD61e1Tw/olx4W8SX0Whtos2jahFaw/vZG+1K7spRg5PzqAGyuBg9KOeXch4yj7lpSakk0+aW0nZfavv8Ad1OG8zQP+hO0j/v/AHf/AMfo8zQP+hO0j/v/AHf/AMfr2HxN8PPCVqfFF/pFkRbada+V5DTuTa3IZDu5bLKyPkZyMhvQVjDwh4d/4aUufCv9nf8AEoQSFbbzpOMWpcfNu3fe56/pRzy7nNSzXD1YOcXPSLl8T2STf2t/eX+Z5v5mgf8AQnaR/wB/7v8A+P0eZoH/AEJ2kf8Af+7/APj9er+FfAXhfXfDPhB2tD/ad08lxdoZnAu7dJzG4HzfKygoflxkBqybXQvDNp8O7zWLuz0gXKa5NYpJqkl4U8pYwwRRbnO7OeW9+elHPLuUszouTgudtO3xS7tfzeT/AKuefeZoH/QnaR/3/u//AI/R5mgf9CdpH/f+7/8Aj9VKKOeXc9b2X96X/gUv8y2W8PSKY38JafGrcF4Li5WRR6qWlZQ3oSrDPUHpXPa7oyacIL6yd5NPumdYTIR5kbrtLxvjGSu9PmAwwYHg7lXWqXUf+SaX/wD2E7T/ANFXNXTm72ZdOUqMotNtNpNNt7u3Vu1t/wADjKKKK6T2joPiZ/yVLVP+2X/olKKPiZ/yVLVP+2X/AKJSiuah/Cj6I9/ij/kc4z/r7U/9LYfDP/kqWl/9tf8A0S9c/XQfDP8A5Klpf/bX/wBEvXP1UP4svRfqLE/8ibD/APX2t/6RQCiiitzwQoorpPCXhKfxHdPcXEn2TSrb5rm7YgAADJVSeM45J6KOT2Bic4wjzS2O3L8vxGYYiOGw0eacv6u+yW7b0SMjS9I1HW9QFjpdq9xOVLbVIAAHUknAA+vcgd676Lw34N8H7ZfE19/auorhvsMAyqH5TyuecZJ+cgMD92qmo+MLXS9Ij0HwWstpaJu827dQJZ2PBYHqMjB3cHoAFAxXF1koVK2snyx7dfn2PpFicsyP3aEI4mv1lLWlF9oR+21/NLTRWizsNU+IutXUYtdKSLSbNU8tYrcAsF2gY3Y4xg42hcZ9s1z1rDf6/r8MD3DzXVy4QzTuWPplmPYAfgBVCvRdI8J6sbzTNA8M6c2peI9RPkiK3O9/MYn5OwUIFJYngYJJwK2VOFKPuKx42NznG5pUUsdWlNXva+i9Ir3V8kkc341eybxxeNYANagqkZHGVVQo/RRXrfw20eK6sIv+Eu/Z3TUvD0ow2rWz3dncqpH342km2S/QAZ7GvX/B/wAC/DHw0S31nxBv8TeL5U3xWtpjyLfb1MbMM4X+KdsD+6PXopdQ1zxVqUujnT/s18yI7RR3UjbY3zt80v2YKSM4OADjBFEdkjjrv21WVVKybvY+V/GHwgvP+Fi31p8Pre41LQWKy2k9zIiMquMhCWIyR646Yzg1jaj8GPiXplobqfwpdyQgZLW7LNj8FJP6V9f+HPC91oLtd6nos4stxWW8spd8lsQcHzYyCSowPu9BzgivRZtC1OK1Fxpypq9qyhvIBRJmU8gxOMI/HQNjP96q57GTpo/MVlurC+wyzW1zCwOCCjxsOR7giu78GeIvGVxqMEBmN1pysFmnvVJSNS2STKBu3dQASeuADxXd/FjxLomv/Ey5b+yokstJd4Abi28i4ndfvGQMNyYII2kcDnAJ480l8Sy34ZJr02Fkp4CAvI3+4ucDgdT+dZVVGqrNXPXyXMMTl1dVKFeVP/C7X9elvW5v65pPhPxRrjaZDqKaRPbKsFlEqKsbLuBPy8AsWZuFYHJPUCvONd8O6t4cvlttUtvL35McqnckgBxlT+XBwRkZAzSXtz9svpJwgRWOFQHO1RwB+VdLoPjM2+ntoniOFtS0Z4vK8rALxgcjaeMjp1ORgEEYwc1TqUleLuu3+X+R6s8blWcTdLFR9hU15aiu4vsqkei6c0dV1i0jhqK63xT4Pj0uwh1zQrl9Q0WdRiY8tEemHwBwTxnAwflIBxnkq2p1IzV4nzeZZZiMtrvD4mNno1bVNPaUWtGn0aCiiirOAKv6NfR6drUN1MrNDhopQgy3lupR9vbdtY4zxnGaoUUmrqxpRqyo1I1Ybxaa+R1U9rLBHHNxJby5MNwgOyUDupP15HUHggHipYdV1O3tIrWDUruKCGcXUcSTMqpKBgSKAcB8AfMOa5qy1PUtO3/2fqF1aeZjf9nlaPdjOM4PPU/nVv8A4SbxJ/0MOq/+Bcn+NaqvOOy/GxrOhgaus3JeXKpJfNyj+Wm2u76NPEviKN2ePX9URmme4LLdSAmV12s/X7xUkE9SDimW+v69aRWkVrreowR2bM9skVy6iBmzuKAH5ScnJHXJrn/+Em8Sf9DDqv8A4Fyf40f8JN4k/wChh1X/AMC5P8ar61V/pv8AyMv7Oyy1rv8A8Fx8/wC/5v72a6X17Hp8thHeXC2szB5YFkISRh0LLnBIycE1Xqh/wk3iT/oYdV/8C5P8aP8AhJvEn/Qw6r/4Fyf41LrzfT8f+AbLDYGN7VJa/wBxf/Jmzp+p6lpN39q0vULqxnxjzbaVomx6ZUg09tZ1dp7uZtVvTJeLsunM7Ezr6Oc/MOBwc9Kw/wDhJvEn/Qw6r/4Fyf40f8JN4k/6GHVf/AuT/GmsTUStb8f+AZywOXSlzuUr9/Zx/wDkzpIfE/iS20caTb+IdVhsApUWkd3IsWCSSNgOMEk547miDxP4lttHOkW3iHVYdPKNGbSO7kWLa2dy7AcYOTkY5ya5v/hJvEn/AEMOq/8AgXJ/jR/wk3iT/oYdV/8AAuT/ABp/W6v9N/5EPLMrd7t6u/8ADjv3+PfzN8a7rgk8wazqAf7N9i3faHz5HTyuv3P9np7UHXtcN09ydZ1AzPB9leU3D7mhxjyyc5KY429KwP8AhJvEn/Qw6r/4Fyf40f8ACTeJP+hh1X/wLk/xo+tVf6f/AACv7Py3+Z/+C4//ACZfqzBAixC+vhJFp8b4lmUY3d9iE8FyOg/E4AJGP/wk3iT/AKGHVf8AwLk/xqleX19qE4mv7y4upAu0PPIXYDrjJPTk/nWbqzata39eh0RjhKT505Ta6OKS+b5pad1pfugvryXUNUub+ZUWS4laZwgwoLEk4z25rrNFlbXdAstLtUaXU7APEltGpLTwFzICg5LOrPJuA/h2EAhXI4uis3BNWPNxlOWKfNJ+9e9/PX/NnXV0Phvxz4p8IxTxaBqr20U53PGUWRS2MbgGBAPuPSuM/wCE18Zf9Dbrv/gfL/8AFUf8Jr4y/wCht13/AMD5f/iqx9i+55VXA1a0eSpCLXZtv/202r2+vNR1KbUL65knupnMkkznLMx71Nfa1rOpxRR6lq19eJF/q1uJ3kCfQEnFc/8A8Jr4y/6G3Xf/AAPl/wDiqP8AhNfGX/Q267/4Hy//ABVHsX3K+p1tPcjptq9P/JTon13W5Gu2k1jUGa9wLotcOTcY6eZz82O2c1al8YeLpihm8U61IY2LIXvpTtJUqSMtwcMw+hI71yf/AAmvjL/obdd/8D5f/iqP+E18Zf8AQ267/wCB8v8A8VR7F9yHgKj3px+//wC1Ogg1rWLV7RrbVr6FrMMLYxzupgDZ3bMH5c5Ocdc1PZeJvEmmwvFp3iHVbOORzK6W93JGGc9WIBGScDn2rmP+E18Zf9Dbrv8A4Hy//FUf8Jr4y/6G3Xf/AAPl/wDiqPYvuOWBqy3hH7//ALU0iSTknJorN/4TXxl/0Nuu/wDgfL/8VR/wmvjL/obdd/8AA+X/AOKo9i+5p9XxHaP3v/5E1YopZ50ggjeWWRgiRopZmJOAAB1JqLxHdJYaEPD2Qbx7lbm8Tr5BRWWOPPZ/3kpcc4+QcMHUZk/i7xXc20ltc+J9ZmhlUpJHJeysrqRgggtggjtWNVwpcruzSlhJuSlVtZa2Wuvm7Lbtbe2vQKKKK1PSOg+Jn/JUtU/7Zf8AolKKPiZ/yVLVP+2X/olKK5qH8KPoj3+KP+RzjP8Ar7U/9LYfDP8A5Klpf/bX/wBEvXP10Hwz/wCSpaX/ANtf/RL1z9VD+LL0X6ixP/Imw/8A19rf+kUAooq7pGl3et61b6XYhDPO2F3ttUAAkkn0ABPrxxmtm0ldni0aM69SNKkryk0klu29El6mv4S8JT+I7p7i4k+yaVbfNc3bEAAAZKqTxnHJPRRyewOn4o8UQXlrHoGgRfZNEtvlVFBBnIOdzZ5xnnB5J5PPSz4w1Gw0uxHgvQYvLtLZw1zPvy08mOQxHBwcZz3UAABRXF1jSg6rVWe3Rfr6/kfW5pioZPRllGCa53pWmvtPrTi7K0Ivf+d76WQUUVNa2l1fXkdpZW8txcSsEjhiQu7k9AAOSa6z44jjIEqk4xkda/Sr9nH4Lnwl8NZ/HWrxCfxH4ld5EkK4+yWLsXRFB5Uyja7d8FVP3Tn5j+DX7PU6eKbDxF8W7QaXpkT+db6BdELd6iVw37yL70UA6uzAFh8qj5sj7j8YeN59N+Gt5JaTAXNy0en2uBjbNPIsIYe43s3/AAGsKrvsb0YSlJRXUfa6Dpst022MTy3iedNKRnfGrhVH+5k8DpwT3NeXfBDb4j1z4g63dLuvJNfJLNyRH5W1B9AARXofhbxppLfF7xXp1sY3t9MttN0yCMnhAPOJ/HdtH4CvOfA3iW28BftS654IvbOCCy1eMyWMrLhbg5aWIt6na0iZH8SYrGTaaPTwkIzo1or4kk16Jq/4a/I9dSwii1aK12bZLhWdcfxFAM/jgg/QVU00WGk+OB4TdhBFdDdbo648qQguYwP7jqHdMd0kXsBXK/E34jT6Vq+h3+jW/nT6frTvcQRKWZ4PsZMu0Dr8rAgf7Ncb8aPGyav8OYfG3hm+C+IdAnjuQqvktGrLJt914SRT6FvVhVX6HNRoOo1fRPS/n/X5mJ+2R8G7LVvCsnxI8KQ41PTgq60ka4+126/L9o92j43HunX7grxW0+DN9ffs7RyS6Wqz3QN3a3XAcXAHyKe+x1Aj9NxB7V9p3HimDXvAMWs6bbRXUF/ZLdLavys0ciBmiP1Viv1rzXQtR0aPwadG0+4N1YsW+wsTzInXyW/uzJjBU43Y3DOTjSm7O5zuPRn5yMCrEEEEdjSV6l8afh/P4a8ZXPiDS4mm8P6lM00NwgJWCRjloX/ukHOAcZHuDjy2tznasdD4W8UzaBcPb3EX2vS7j5bm1YBgQRgsoPGccEdCOD2Id4u8Iw6fbpr+gSfa9DuPmV1JYwEnG1s84zwCeQflPOCecrqPB+uWlnLNoWswJcaTqJVJVkfAiboH5OAOmTwRgEH5cHlrU3B+1p79V3/4J9XlGPpY6isozF+5r7Ob3pyeyvZ+5J6SXT4lZo4uitrxV4fm8NeJZtOk5iP7y3fcGLxEkKTgDngg8DkHtisWtIyUkpLY+cxmEq4OvPDV42nFtNeaCiiiqOYKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA6D4mf8lS1T/tl/wCiUoo+Jn/JUtU/7Zf+iUormofwo+iPf4o/5HOM/wCvtT/0th8M/wDkqWl/9tf/AES9c/XQfDP/AJKlpf8A21/9EvXP1UP4svRfqLE/8ibD/wDX2t/6RQCvS/DcX/CH/DO68TSps1HUcQ2m5eUU52nleM4Z/RgqVwmiaVNrniG00q3O1532luDsUcs2CRnABOM84rrPiLqiXXiddKtViSz01BDGkW3aGIBbGBxjAXb22duamsvaTjS6bv0X+bPT4el/ZmDxGdNe/H93S/xyTvL1hC79Wjj6KKK7T44KUEhgR17UlFAH0v8AB1bXwn4c0aW5jNx4g8UmXUGMnJg0y0DsuSeR5k0ROO+xD2r2n4l+JRpPhHw23msY7XXrYzDqcxJI5/HK5r5u8B6y2tfEHU9YiZ2s9J8Kx6fASOIwsMUW38T5p+pJr0z4j61aahomqJJJmHT9dt9SbYCxaBnCSYA5P3j07MPWueo7K56eAp88vT/O36nYT6V428GeCdN8fz2drHDrAeS7CSO8ySGX7RCz/LtB+UoACeuCcmjx7faV8QvC9rqfnPa6lp8iXFlf25xLEjspyD3AyDj1XNcBf3/xd8Zadol3P491KG+162bUNO8Ji2SSxXTg8nymRgAzRiIff+Yl1CkFc16n4O+FGueJfgtonirSbq3ujfWhM2myZgccsjBGPCsGDDB4PByCSK44V1BctRq/+Z3SoT0xEdNbL5afpb5M53wLPaax8QtS8TfFu8spNG0pXuLmV5DHau5RIEYrkBS2xyQTzjA64rjPGOo/DC88RSH4K+M7PUGvmNt/YAWYSENnMSK64kj+8Vwcpk9QePZ/G/w1iT4A2mvv4GguNV0C5ilutE1lWa1vWzHA1xJscFkWIAjn5cye5ryuy+AMV1rV/Zi1Z7WTQnnga7VILuHUNkfkGNgxKoJ8hSOgZwcjFZKrefM3/lp3O2hhZuk69K3LHR36/wBXX9I7b4da/cab8BvBNvOzrcRTw2RR+GAFw8RBB9FP6VjWunaL/wALC8T2M2mWV1BO638LPlSBKM87SNybwwOc4JBrm9L1Gc+N/C3g4apcak2nzNqGoX08hdpijtIzknscp+LetcVrXi+70z4n2eoWswJgnuNOlRvuvEzLIoPsBL+lehSldXOLF4S04xj8Tu/8vw/M7Lxquq3Oh3Gs+BrlLeWNWhvNDmhWaGfbyUaJgRu4OD/FgdyK+VtQvTqGoyXbW1tblzny7aIRRj6KOBX0Hd+JZrLxppesW7mKDUrr7JKmeC/Dofwbj6H2rxHxxbWln8S9ftbDb9mj1CdYwvRV3ngfTp+FdVtDxKqszAooopGJ6BBF/wAJp8Jnsgm/VdGwYtq5Z48cKML3UFQo5LIpJ5rzOur8Gaw2i+MbW4LqsEzfZ5y7BQEYjkkjgA4b/gOM81W8b6K2h+Nbu3CIsEzG4gCKFUIxPAAPAByvb7ucc1xQXs6rp9Hqv1Psc3l/amVUMzt+8pWpVPNJXpyfrG8W3u4+aOdrQ0HTBrfirTNGNylsL67itfPk+7FvcLuPsM5/Cs+rWmW9td61Z2l7erY2006Ry3TIXECFgGcqOTgEnHfFdJ8cfavxT+EXwi+DGqW+hXH7NvjTxnpEdqklz4xt9YuUG453fJEpiBGOjbPpjmvmfwR8J/EHxk+J2r6R8L9KZNMhkluRNqcwjjsbQufLM8nPzbcDAySQSMgE19kfCTx94r8DeIbF/Ff7WXwy8T+ArZGEtvd3ofU2QIQm1WQS7s7eGdsY6GuP+DHx3+E2n/Hv4y2Ekuk6LoXjOYvpN5q9mWsHZRKpW5jGMRyGUvtJUY3KSpIrJNpF2R89fEP9njxv8PfAsXjZtU8NeKPDTz/Zn1jwxqH223glzgJIdqkHPGcEZwCckA9kP2L/AIoC/wBAtpvEnge2Gu2oubGS61R4RK5UMIFVogzylTnaisAAckZGfRPi18Q59E/Zt8TeCYfE/wCzyllqrxFNF+HVlcPJcv5sRMhZZBHEyrGrbmVs7AvXFa/xY+IPgrUfj1+zde6f420C7sdHNsdRnt9ShkisTvt93nMGxHwhzux90+lPmYrI8X0/9jr4xagNWtP+Kcttb05JJv8AhH59UT+0LmFGKedFEoP7tmGFZyobIxwRXB/Dr4Tt8Q7TUJm+I/w/8ItZSrEYfFesfYJJiwJzGuxtwGMHpgkV9feE/iP4Dg/4KqeOvFd3488OReHp9Ait7bVpdUhW0lbyLLKJMW2MdyycA9Vb0NeefAZ/gg/w+8eXmrv8N5PiH/a0r6a3j9t2mta5QqVHRv8Alt9zLZ29sUczCyPFPiD8APHfw41vw7Z6xNo19YeIpFj0zWdKu/tNlcFio4cKGH31P3eQcjODXfz/ALEnxXtvHTeEp/EXgaLUWt/tFokuqvG1/gEusEbRCRygHzNsCjP3uDj1f48/EL4feIPgT8IbbQ/E/gaS6sPEdvJd2Ph1ktbezRd4d1tmYvDDkAguBwQSBnAd46+Ifgq9/wCCqHgjxXbeONAuPD1pp6RSatHqUL2kH7q5yrTBti8uOCerD1o5mFkfMfgP4AfEn4hfFTWPAOk6Zb2epaI8iarNqE3l29iUYod7qGzlgQNoYnBI4BI6LV/2V/H+kfCzxH8Qz4h8HahoOhthrrTdSa6W9GVBaBkjKkBm2kOyMCpyOmfe/AvxU+HCftD/ALQHg7V/GWl6VYeODJFpviQTo1oD5c0efOB24xPuU5A+UjOSKf4d8LaZ4G/4JnfFnRbTxnpPicLqDGa/0h2ksllb7KojikYDzDjYSwGMttBO0mhyYWPnbwT+zrf+O/Del6lpfxb+FNpeakP3Oiah4gMWoK5YqI2hEZw5I4GT1Fdz8Bv2bEvf2r7z4ffGG20eOPSIme50S41J4J9RDwu0b2hiIMqrhXbDDC9e4r07wbq3wA8O/BDwDrHhFvg0L+JIW8TN4ztWvNWWbCbzbRZDb/M8zBJWMDaQQATVrxf8VfhxYf8ABUjwr41HjHRLnw6uifZJ9WsruO4t4pXiuEAeSMkDlkBz0BBOBzScm7oLI+ZPj78J9N+GPxE1FNG8W+DtT0651W9itdJ0TVWvLrS4o5fkiulYbo3CsF5ZjlGyTjJ7n9jT4W/D/wCKfxH8S6d8Q9BOr2NhpQuoYxdTQbH81QWzE6k8E8E4ri/2jfCWn6L8Y9Y8UaT4/wDBviqx8Tatf6jbr4e1MXklojTeYq3AUYjYiXAwTnY3pXpH7DXi3wr4S+I/jC58V+JtH0KC40Mwwy6pex2qyv5qnapkYAnHOBzVO/KC3Ndf2YvCaftiSpKh/wCFPx6OfF/2vz5PLOnFMiLzc7/v8Z3b/LG7OeaxP2qvgX4c8K/tAeEPAfwd8IzQTa3pyulhFczXDTTtNIud0zttG1RnkKACTjk1yD/tP+Jn/ZBX4GHShkYtjrv2r94bISeYLby9nr8u7f8Ac+Xb3r6G+MHxt+Hfh79vf4Z/EC18R6Vr2g6fo8lpfXej3Ud6LUymePcfLLcqJAxXqVzgcil7yYaHgWsfsffFLS9I1Saz1bwfrmraTB9p1Dw9o+rCfUbRMZy8Owc46AEk9s1h+Df2avHfjj4Mp8TtL1fwxa6Gbw2kp1K+a2a3CsFaWVmTy0jGckl89gCSAfrzUPinpXhz4i6x468IeO/2ZdO0u+aST+1I9Pnk12aJ2DlZ44ZVeRywUnkbiAcDoPDv+E38NT/8EttV8NHxJosHiC68QG4OiR3ka3Hlm6R8iDdv2DGc46ChSYWRy837GnxXtPGdtoV/qvg6ztr1IzYazc6tssr+STOyGBinmSSnaTtCdMHoRnoP2a/hIdB/bom+GvxR8L6VqMtjY3Jnsb+CO8t3Plq8cihwVYFWDA4zz2PFdh8XfHvg/Uk/ZXTTfGeh3a6M1q2ri31GKT7AV/s/JuMN+6xsl+/jG1vQ109t8Qvh+v8AwVYvPFx8ceGh4fbQxENXOpwfZC/2dF2+du2bsjGM5yKTbaHZHh3i/wDZV+IN5N418VeG28LXEOl31zcTeG9O1BH1Cyt/Mdk3W6Ltj/djIjLBsDAXPFcL8P8A4Jv8QPCo1qP4rfDDw47TtAuneI9d+x3ZK4+YR+W3ynPBzzg19QfC7xD8Lfg58Q/il8abz4v+GtftNZa6Gn6FZ3Be/nd7gy7ZIiOu4BQ67kIYtuArlfg9c/A2x/ZQtNRsh8Ij8QY7uRtYHxHha4UQh3x9nhALudnlbVjGD82eafMxWPENX/Z0+IugfHjRPhPrCaZa6rrZU6ffG4Z7OdGzhxIqltuVII25Hpgirfjz9m/xX8Nra/bxb4w8C2V1a3MUEennV8Xd2kjqnnxQlA/lKWJLMF4RiARgn6f+KfxI+HGr/tSfs/69pPjPwrJpunrIb6ezvIY4LBSse1ZAHIgA5AVjxgjJxXzp8Ztb8EeJP2/NU1jW9Xh1bwbca3afbL3T7gTpJZhYlk2PGTkBQw+U5445pqTYNIs237I3jDWoLpfBfxK+FfjPULeFpzpfh3xELm5dR1IUxqO4HJA5FeAzQy29xJBPG8UsbFHRxhlYHBBHY1+m3hLxn8C/Bfx5tD4b1n4DaP4VnsWWwvtOVF1dH8sFxcXRYRxITkAMS7ZUY6kfnZ8Rrm0vPjH4tu9PnhuLSbWbySCaBw8ciGdyrKw4KkEEEcYojJvcGjmaKKKskKKKKAOg+Jn/ACVLVP8Atl/6JSij4mf8lS1T/tl/6JSiuah/Cj6I9/ij/kc4z/r7U/8AS2Hwz/5Klpf/AG1/9EvXP10Hwz/5Klpf/bX/ANEvXP1UP4svRfqLE/8AImw//X2t/wCkUDvPhhDHb6lqviC4jSSDTrNmIxmQE5OUzxnajjqPvY7muUubia7vZru4ffNM7SO2AMsTknA46muw8P8A7j4F69cw/u5nu1iaROGZMxDaSOSMM3H+0fWuKooLmqTn52+5f8E7s9bw+WZfg1s4SqPzc5NL7lBL7+4UUUV1nyYUUUUAe6fCeK2svg1eXxZVn1bxJa6MX7ovkvIo+jEsPwrQ8RafqdpoK+ICxktJrco0XQvGcxlfYhVXB77R0IBrxLTvEGr2WhXGh2Uzi3urmC72Lncs8W4RuuOjASOPx9hXv/hLxba+M9Mi8N+IJIIL/UIJrRY1AVUvEkaREAzx5sc8oA/vxbe4FZTStZnfhMR7KcZLp+XU94+Gklp8QvhN4Tu7vQbiC406NgLmayXy7olyJSjElWR3UuV4KSbuMHn2a68R+EPh54d0qz17XItLhl3R2sUys8lwwO5goVSSRuyQB0x2FfFXwj/aEufglrWoeCfFelnU9DjujMIlcRz2RfG54i3DISMlDjB5BGTn6TvvjZ+z78S9ItNP1HxpZaTdwyJe2qaxEbWWB9pww3jYwKsQQGIIP0NeFWpTUn1R9HVxEXy0Zu0E+mu76HoNh8R/DHivXIfD2i/brlruCYieW0aKEhFBKnfgncpPbBwwrkfGfhLxNaeHbxPCdtp1tdXCNE9/NiJbKLBzIAq5YgE7RwAeSexoRfEj4N+CtXjvf+FgWmv6q8ZitNP0c/bJWLYzsji3fMQAMsQAM+prxn9on4/+OphYeFNGsh4f03VoGkllEokuzGGwyuw+WPjk7Sev3qxp05SaWxvBqlNrDO8HbVo858JzLoPhTVb5pxNqWr3P9n2c2MMYgcDHoOQT74rzXVr77b48uDkGJ712jIP3wuFz+SCp4dTvp7qKVJfLjtoGS1G04iLAhXxwMDLMOcsdvauZhtY0a7kluppJrWFpIrgYXaVIAHfIJOMe9e7T2UThxFaFPETq3v8AP+unyubXjXxas2vadb6Q4MWkyGYSdVkuCwZmHqF2qo9dpPeuHllknneaZ2eR2LMzHJYk5JNaWjapNZ6+LgRwypMSk0MiBo5EbqpBzx39RjipdX0y2WEahpQLWv3ZUDbvJfPTnnaeME9+D2rq5m5WZ8zNJx5k9b7fqYtFFFMyCu38dO2teBPD3iYhPMIa2uJGULJI/rxxt3RyEem7pyccRXb2v7/4Aar5/wC9+z3q+Tv+bystFnbnp99un94+prlxKs4T7P8APQ+s4ZbrUMdgpfDKlKX/AG9Tamn9ya+Z55RRUlvbz3d3Fa2sEk88ziOOKJSzOxOAqgckknAArY+TI6KujSNWL3qDS70tYZN2BA2bbDbT5nHyYPHOOeKpUAFFFWbrT7uztbK4uYtkV7Cbi3bcDvQSPGTwePnjcYODxnoRQBWoroW8CeNIrqzt7nwrq9o17cR2lu13avbpJK5wiB3AUEn1Nc9RYAooooA6z4e/EHV/hv4nn1nSdN0XUxc2rWVzY61YpeW1xEzo5V42/wBqNDkEHjrya6/4i/tFePPiL4Ft/BEtj4e8NeF4ZBL/AGJ4asBZWzuDkFl3MSAecZxnBxkAjySpWtrhbNLtoJRbyO0aTFTsZlCllB6EgOpI7bh6ilZbhciooq/Noms2+jxavcaRfxafKcR3j27rE59FcjB/A0wKFFbl34M8YaekDX/hTXLVZ5VghM9jKgkkb7qLleWPYDk1QGkasXvUGl3pawybsCBs22G2nzOPkweOcc8UWC5Soqeaxvba0t7q4s54oLkM0EskZVJgp2koTwwBBBx3qa40fVrS7urW70u9gntEElzFLAyvApKgM4Iyoy6jJ/vD1FAFKitGXw/r0GiprE+iajFpz42Xj2zrC2emHIwfzosNA13VVhbTNF1G9E8jQxG2tnk8x1XeyLtBywX5iByBz0osBnUVrar4X8TaFbJca34d1bTYZG2JJe2kkKs2M4BYAE4B4rJoAKKKKACiiigAooooAKKKKACiiigDoPiZ/wAlS1T/ALZf+iUoo+Jn/JUtU/7Zf+iUormofwo+iPf4o/5HOM/6+1P/AEth8M/+SpaX/wBtf/RL1z9dB8M/+SpaX/21/wDRL1z9VD+LL0X6ixP/ACJsP/19rf8ApFA9Dv8A/kgGh/8AX63/AKFNXEV29/8A8kA0P/r9b/0KauIp4T4Zf4n+Z28W/wAXC/8AXij/AOkIKKKK6j5QKKK0NEsX1HXLe0jjEju4Cof4j2H0Jx+GaTaSuyoQc5KMVds6LwtoF5d6haWFh5aanfSRxLPK4RLVZGCrljwrNuHJ+6pz1PHd/E74b6H4A8K6Vo8tnfzeLvLN1eX9tqaSWSIsrALCiJlyV2neXzndwCMDrPhbceEtH+KGkaVP4h0qO+R5WZ7mzF8ss5icBTGcKWLHC5PBC98V9BTeH/CWnaDPqvxg0m0s9NtVfU4FltRaxq64AZFViRuPIjJ/ixtxgV49bFSck7aH16yujhoulJqTtrZ317fI+CvGth491fx7aeHvHOjtH4gtoI5Jrm5Ahne2ZQ6tcEZ52MDuID/MAck1flW01Z7mFo4rSe3BSBX+UhOFRGH8QwFGRzxn1Fb/AIu8TPq+o6p4sku3vNR1aQ3V5Mx4ZmPyIvcKgCjB/iDe2M3ULE3dtb28pKvIxZ3U4KiNRyP+BSD8q6bu2u7PJo00pO2tk7+a6fjbX/I9strHwn8Hfg7oWv6ObO51fxBYJcJJI/mSZA2yu4ONiq+U2AgErjsxrxfWNXute8WuJWm1bUXPRMzZ+iqBuI98KMYAAqJdGub25tI7m+uJYIpEjVGcsEBfOAOwJLHHqT6mvS/gddaDa63cWt1YaleX/iF8I2mXC2jQxlpNztOyMAFGWI3KPl53dKyhBQblLVnZVxFWdGMKfupuy8/60+e/S3mMkur3btaR6ciANsaS7cHLdD8q8cHisixR7fVLyz1W1jiVkkjnRR8qjaSHH0IBH/169J8V+GX8GeJjosmsaTrCywpPa3Wlz+dFJEcjJbA+YFSG464xnIrj/FWnySRvdS3CM5AVkUEYK4yGIHcc4yfuitqdRcya2MJYXnw8pWfOmvS3bX8PmcRZq32gMoy3Rf8AePA/Lr+FblglxEJHt4xI6LtmjYZEycqQ35Zz2NbHhzw8vmfapAHx8qDHy574H9a1vD+lMPF2qWYXiMBsegbBH8zRVxCu7dDvwGQStT9qvjbX4N/oecajapbXWYCzQSDfEzdceh9wcg/Sqdeg+N/C76bF9ojT9xMxdMfwSAfMPoyjP1WvPq6qNVVIqSPnsywFTAYiVCotV+QV3Hgj/kSfGP8A14/+05a4eu48Ef8AIk+Mf+vH/wBpy1njP4T9V+aPd4J/5G8P8NX/ANNTPO63vBFxBafE7w5dXU8cEEOqW0kksrBVRRKpLMTwAAMkmsGitT5Q9TtPGOiX2kavbSmS2uL6wZtUlkZVF1LGY44xFzlmK+Y5zyWduMDNTaj/AMIf/a1t/a3/AAjX9n/25F9h/svZn+z8Pv8AtHlfPj/Uf6z959+vJqKrmJ5T1E/2J/amk/2x/wAIp/bWy+/48/I+w/6pfsnneV+6z5nmde2zfxmsH4g3Ec//AAjcQn0mS4g0kx3K6U0Zhjl+13DFQI/lBwwJC8fNkcEVxlFFx2PaNZn09fjrpuvLa+EbbT/+EmguDq1lrSzTSx+fnfJH9pcIuPmJ8tcYHQcHm7M6GPGGky6XZaNdaP8AZpBDDd3FrBNG+zDNcG4OxpFYhgGyjAYUDkDzuijmFynrcNlbLB4pudMuPCd/dpf6akN3f2tnDboHguGkjQf6gEbQDtO1thYZbbVbWtQ8DJ4u8OabaW2kf8I68ryX81vAplK/b7jarSYMiqIxHgcMUK5z8teZLc3C2clos8q28jrI8IYhGZQwViOhIDuAe24+pqKjmDlPW72fRW8XaQU8L+Hl2pcgyrrelSRyAoAjMqxxwqUJ3KJVy+SDnHHO+O49Gi0q2Wwv9Lvbw6lctNLZW9vARGba0KqVg+Tar+coK/KWDkdTXDUUOQJFq48/+zrPzPsvlbX8vyvL8zG458zb82c9N/OOnFdzqbQan4MutS1fUtOhul0+3gtpNP1MM155ZjRYpbUksuEXJOEUFM4Oa88opJjsey67NYD432GuraeEbewPiSG4OrWWsrNNLH52d8kf2lwikfMT5a4wOg4OdZeKtL1jS9W02KZLK/1KxYahcXkqRxXE6GOKIqxP93zHYnHzO3YZryuinzC5T0/xdqPhLWPCt/pOka5czNozxPp8d3bRwRmJVWCVYnErGRnIjl+6p+VjjnA29f8AEXh/WL3xzqdzqVlLd2/mWUS+cv8AxMbZr6KWPyzn5yipIpxn5DHjhTXitFHMHKeoeIIdKv8AVPFPiK88RrPb3qyzaZLZ6tEjFScx28tptMuMFVx8qrtPUYqS7uvCb+DJfBMfiCVprfTVljBhiFmb2PdO7rced8xIeWEfIAfkGeBnyuijmDlOj8c3Ntd+MBNaXEU8f2CxTfE4Zdy2cKsMjuGBBHYgiucooqWUgooooAKKKKACiiigAooooAKKKKAOg+Jn/JUtU/7Zf+iUoo+Jn/JUtU/7Zf8AolKK5qH8KPoj3+KP+RzjP+vtT/0th8M/+SpaX/21/wDRL1z9dB8M/wDkqWl/9tf/AES9c/VQ/iy9F+osT/yJsP8A9fa3/pFA9B0n9/8AAHVfP/e/Z74eTv8Am8rJiztz0++3T+8fU1xVdn8MD9tbXvD/ANz7dZH9/wBfLxlPu9/9bnqOnvxx0kckMzwzRtHIjFWRxgqRwQR2NPDu05w87/ejuz9Ovl+X4xbcjpv1pyfXzjKPptd2dm0UUV1HyYVbsr+fT/Ne1bZM6GMSDqgPBx6EjIz7mqlFJpNWZUJuD5o7nXeH7eyj8G3l8kKT6pLP9nhDH/UoEDMQPV87QfRW9c1v6/8AFv4h+LPC0XhnV9fv7+yRFjMMqj51B6O2MkAgHk9uc16X8I/2WvGfjX4fprWp6xZeG7LUDHd2XmwPPcSoAwVygKhEOcgk5I5xggmbxF+y18UNN8aWHhjT7zQ9UXUQ7i+hkaAQxJjdJMjAsqjIGV3ZJCjk1wVKlJzs3dr8D04e19muVWVunU+dUuGQxWztuVDGfr83P8hXa2lwsviBVebHlxNtABz8zfNjj0Ar2zVP2HvGkWnfatH8aaDqV8oDNayW8tsrY/hSQlh+LAD6V4t4q8M+MPB+vW2j+JNFutD1Oyi2IlwdpnG4nzI2+664IXKEjCilzwq/CzTDVJ4aV5R3t+af6Fi6mexVGRlV4dsoD7c7sZ49RkDjkV718NvGXw18ZxXdz400vRvD3jeS0xp99p/+j290xQBjHb58pZ+xIGSG4xjj5zt9RieVXvB5YVWUxLgcEH7uSOM471h6sWbT7HDo8kJJUhuAcZOMdOec9sVM6HOtzplj6aleMXZO6/D/ACPp/wDaImvbLwV4csdcnnXXra4lmhtGS18mO0aEZVPJ+YIGWMDdjJJOK8kaeHUvD2l4ivV1LT4zJALW1B+0RiTervuZcFSxUn5sgg9jjgRquvapelb65uJ5ZgBJc3Tl5AoHUMSSeCRzxzW3qupvf32iWUjJGbViIplO3YCRyfcfqM0oQlSSW5rQdDFOTcnF6WXR30av002Ofl1vVPD/AIrka3eRbfeJUtJJN6eWw3Kp9OCBkV1E/jKz0W91TWtPWO4ub6O3S2jk6IBHuZmx6EgY7n6VxfiGX7W8N9MP9KmaTzTuLbgCADk8nncMnsBWJXXLDwqWk0clHOMVgXKlTnezunvZ2aur+T++zPSdP8fSeJbKfQfEkVuHnX/RbqNdgSUcqGHTBPGffn285mQx3DxlSpViMHqKYCQcinSSPLIZHYszHJJ7n1q6dGNNvl2ZyY3Mq2OjF4h80o6X6tdn6fqNrt9L/cfAnX7iH93M90sTSJwzJmIbSRyRhmGP9o+tcRXb+Mo5NI+FvhzQpo2MkrNdMzjYYzgkoV9f32M/7PTnjPFO/JDu/wAtT2+F06NPG41/DCjJX/vVLQj6fE38raXueeUUUVsfJhRV6HT08pZLy4MIYZVETe5B6EjIAB+uehxg5qT7Fpv/AD/XX/gMv/xyq5WK6M2itL7Fpv8Az/XX/gMv/wAco+xab/z/AF1/4DL/APHKOVhdGbRWl9i03/n+uv8AwGX/AOOUfYtN/wCf66/8Bl/+OUcrC6M2itL7Fpv/AD/XX/gMv/xyj7Fpv/P9df8AgMv/AMco5WF0ZtFaX2LTf+f66/8AAZf/AI5R9i03/n+uv/AZf/jlHKwujNorS+xab/z/AF1/4DL/APHKPsWm/wDP9df+Ay//AByjlYXRm0VpfYtN/wCf66/8Bl/+OUfYtN/5/rr/AMBl/wDjlHKwujNorS+xab/z/XX/AIDL/wDHKPsWm/8AP9df+Ay//HKOVhdGbRWl9i03/n+uv/AZf/jlH2LTf+f66/8AAZf/AI5RysLozaK0vsWm/wDP9df+Ay//AByj7Fpv/P8AXX/gMv8A8co5WF0ZtFaX2LTf+f66/wDAZf8A45R9i03/AJ/rr/wGX/45RysLozaK0vsWm/8AP9df+Ay//HKPsWm/8/11/wCAy/8AxyjlYXRm0VpfYtN/5/rr/wABl/8AjlH2LTf+f66/8Bl/+OUcrC6M2itI2FiwxHqEobsZoNq/iVZj+hqhNDJBM0Uq7XXqOv0IPcd896TTQJjKKKKQzoPiZ/yVLVP+2X/olKKPiZ/yVLVP+2X/AKJSiuah/Cj6I9/ij/kc4z/r7U/9LYfDP/kqWl/9tf8A0S9c/XQfDP8A5Klpf/bX/wBEvXP1UP4svRfqLE/8ibD/APX2t/6RQNXw3q/9g+KrLVSm9IX+dcZJQgq2ORzgnHPXFdF8Q9IbTPGk86Rbbe8/fxsMkFj98ZPfdk4HQMPpXEV6Zp3/ABWfwmexCb9U0XHlYXLPHj5VGF7qCu0ckopJ5qar9nUjV6bP9PxPTyGP9p5fiMo+2v3tPzlFWnHveUNUu8Tz+iiiu0+OCvb/ANmj4JyfFr4kfa9XgkHhbR2WbUH5X7Qx5S2U+rYJYjogbuRXlHhnwxrXi3xdpvhvQ7J7jUNRmENvHjAYnqxPZQAST0ABJ6V+pvwv8D6J8Lvhhp3hDRysi2ymS5ugu03dw2PMlP1IAA7KqjtXHjcT7GFluzrwmGdaXkjr4LK2sogfljjiXhF+VEUDgYHAAA4HYCuW8O3Emu61rPiRI/kluRp9ufSG3GDj6yySk/T2rmfjj8VtO+HPwt1HUZZVe9kjMVrbg8yytwiAe5/QMe1dz4B0WXwx8LdA0K9lM97a2MYu5m6yXDDfM59zI7mvASfK2fQSfJa+/wCn9fkbMc0VhZxPfzxRmSRYlPQM7HCqPUk8Vn+LvBnhbx74Xl0DxXo1tqlhJyI5h80bf343HzI3+0pBrh/i9ri2j+GNPiuPKuJtUEyAHBPlxSMMevIz+FdX4a8Uw6zpiylglwgAmjz0PqPY0leNmip4aUqftO58M/Gr9nbXvhNdvr2hW/8Ab3hN3wLhogbiyJPCTAdR2EgGCeCAcZ8a/tGz1PS5rNUWNnAeHAHEg6AEeoJH41+pvjWO01X4aeILC7CtDNptwrbun+rYg/gQD+FfmN4l0Gys/EWfNW3F4qSRvjAhkbPyuOylgQe4OPWvSoYh1FaW5OGwDUXVg1o7NPqpJr5dvVo5aC8vYz5SO3y8Bev6GtAT3M7KY7OVrjbgsVwq++egHuapzoTNPb30Xlagkh3A9CfT/A0k1siWllKZJJIpQ5mjEhALK+Np644Kn8a9KFpK54VWLpzcH0dtf1KOrSQNeiG3l82OFQnm9nPVmHtknHtiqFdLHoYvtQ88WqpbBRiCGQKen95s9evc0248M3LXkkgtntrYgFAn749Ohwe9ae0Rk8O3qpJ62/4OvT1OcoqxLZTwwLLKqrubaELDd/3z1FV+9WmnsYSi4/EjY8LaQ2ueK7Ox8rzId4ecHIAjU5bJHIyOAfUjkVL8Q9X/ALX8eXW1Nsdn/oaZGCdhO4nk/wARbHtjjNdJov8AxR3wyu/EsibNR1DENnuXlAc7Typx0Z+eGCpXmVckX7Sq59Fov1Pr8yj/AGXk9HAf8va7VWflFXVOL9buVul13CrmlxpJqieYodUV5drDIYohYAjuCRz7VTq9pH/ITP8A1wm/9FNXTHc+New9mZ3Z3YszHJYnJJ9aSirWmadd6xrdnpOnxGa7vJ0t4Ix1d3YKo/EkVqIq0V7F4/8AhXaaX4m8NwWum3vhbTL27fRp7zWYpYleWFwDefvcYSVHRwMhQQ4BAHGddfDCxtUktX1G5sYn1PTbQahrlgLNkS4W73OhS5kiaL/Rx8xJyRgMgVt4B5dRXq0Hw/8ACGlzeK7fxFd+J4YrLQ4b+1uptHiSRWa+ghMkca3hSVcPsB34O9zwY1DUNf8AhZb+H/Ar6xdeLtK/tSO1gu30s3VpvZZghCIq3BmMgWQMQ0KjCsQx4yBc84orvfG3w+0zwvFrn9l+JpdWl0PWRo1+slh9mAkbzijRnzG3D/R5A2QuDjG4HNXdB8IaDrnwKa4itWXxVLqN61nOJWxPFbW9tI9tszt3FZpXUgbiYwvO4UBc81or2i8+Dmnav468T2GlX8mjJb6xd2Gl29x9n+zzCLkIJJrpZnYZAISKQjKkk5wOW0v4d6Ze6JbveeJ5LXVrnRrzXILFLAyRmGCOZwjS+YMO/kNxtICnOSflIK5wFFehat8MRp/wwPiuHV5PtMENtPd6ZeJbRSxpNtCsqR3Mku3LrgyRR5DA+1avwo+GZ8Y+HtRvrjw3qmqrdzjR7GezilZLG4eNn+0ylOAiN5KkP8u2Vj/DkA7nlFFdV4r0O00fwp4Rnjs2t729sLiW+3M2WlS+uIRkE4UhY0XAx09cmum1PwGzeB9GsdC8MwXervbR3GpXS3rfaLKSTdIgnQt5SQNAY2DYGCSGcEFaAPL6K734W6L4Y1m/8Qr4rg3WdvpO+OfzXT7JLJd28An+UjdsEzNtOQcciunvfhdpUWk+E/CskX2HxPda9HpOrX+5pRE8yo6oI9wU+WsiZxgltwJ6YBXPG6K9B8D+F7WWxttfvfJuory08Q24tJoAyxva6V5ySgknJ3TqRwNpjBByeNPxH4K8JRvqaeGrq4eW18MabqUsWoWvkpHJP/Z43xyi5I3Obp2beuxMsqg/K6AzyuivV/CPhLQdM8L+J7vxcng+e6srqwhguNR1C6u7NFmW5ZlD6W7FnPlJ1JA2nOCeTTvCPgy48J3usa9LJZRyeHDqtu+kWck/kt/bRtN22a5XedgCAHaNj5I3pukBXPKKK6+98DfY21wDVN40vQ7HWs+RjzftJtP3X3vl2/bPvc58voN3Fbx54a0rwh421Dw1p2uT6tNp11NaXUz2YtkDxuV+T94xbpzkDByBuHJBnM0UUUAFFFFABT7lRLonmN96CZUU/wCy4YkH2BXI/wB5vWmVJL/yL8//AF8Rf+gyUnsBl0UUVkUdB8TP+Spap/2y/wDRKUUfEz/kqWqf9sv/AESlFc1D+FH0R7/FH/I5xn/X2p/6Ww+Gf/JUtL/7a/8Aol65+ug+Gf8AyVLS/wDtr/6JeufqofxZei/UWJ/5E2H/AOvtb/0igFa/hjWL7Q/E9tfWEL3EmfLNupP75W4KcdT0I68gHBxWRXffCjxnceDPFk11a2FlePcRiJ4rmFXLx5yyKx+6Tx0znGDxxWsoqSaex5WDxFXD14VqErTi0010a2E8c+Go9OuV1zTFjXTLtwFjVShhkxkqVPIzgnGBjkEDAzhaJp8d3qCyXjpDZxAySyShthA/hyo6k4H49q9q8ZaWZ/Ct741+H80z+F5333+mRKBJpEowdjx9oweVdcbeM8YNeY2tpdapNstnvb1Qd5WLkjjk4HT3NZ05OEeWTv5np5nOjjsXKvQp8nNq4rVKXXl7JvVLW22yOmHiK60zXNKufDt9cWBsAs1tNDcHbHt6qmDgZGQQeoJyGzX1z4g/aT8FaX8KYvGqXjKlwGSO0YAz+cOsITPLDIyfugEEnBGfhTc+nu9qlqwDkcep5HPHrzgf0rj/ABFdxXWoR20MouHiyrzq2Vdjjgew6Z7/AExXNWw8aiTfQPr8qUnLlV38ku1l6f139x8GeJvEf7Q37X3hH/hJw6aPFqH2xLPOYo4Yf3rDJ++zeWFJ75AAAwK/SGfU1ijeWZ9mAWcnjHc1+XUyWOl+HEsHtGju7WUxRiElo1QMTkSKeeST0z1Oe1ekW/7QHj+w+FqeEEihuhBbNCmtSyyPKi8ssj9QSoIAyf4V9KwrYZzso9DopWg3Kq+ZtJtrW3l6/ge5+MdbtfFXiW+13UJhBpWno0VpcMceUVOXnB7bSoUHvtfqDUXw6+IEHiTQY9d0ifyrmFzDcxYwUceq/wB1hhh7HHUGvi4eL9WuvDUGgXep3Zs4MmOGWd2hznPKeuTn09hVnwZ431bwX4kk1TTdQMbTIY5kZPNjlHYOmRnBwQQQQfYkVUsBLla69Dup5xh/dS2e/kfcfxV+KdrYfCTUNPYiDVNTj+x26Fsq2SN7dc7Quc/UDPIr421/VbfWGvnv1aW7wIxI8mQfndnIbvztAzzycVl+I/FWueKb99Sv72W+mYbRMcARr/dRF+4Pb8eTXPmafyfKfhQMc8cVthsPKlGzOPMsVhnyqkrtPV30t27edy1e3El/Al7Pn7THiGZuMnAADH36fmasW9pLd6XEI8IEdmkL9S+APlHoAB9SfYVmQ3lvb212p+d3RVQDpuz1P0GfxxUP9s6n5PlLeyonpGduc9c4611KnJK0TiqYvD1aiq105NrW3fu36HUQaRqIAEVwyjthDirCprVsWASOUY+b5SpI/KuFa4nf780jfViaWO5uIm3RTyIfVXINHsp9yHi8E9FRa/7ef+R3vm21y4ju4PKn6q3Qj6Ef41nW3h2wn8UW8d/drDbb2mnlnYgSoDkrkY2ng5JI457YqnosusamJ1KGeC3j8x55OPK/u/N3JIxjvz6GtC9uN8aXRYFQVRBj7x3cn3GMj8TWet3G+vkbQUKEqeI5Oam3fll1s9V5p2s2vNdGYHjLxCuv6/8A6KixadaL5FpFHkLsB+9tOME8cYGAFHbNc7UlwIxdSCLOwOQufTPFR1tCChFRWx5+YY6tj8RPFV3ecnd/5Lslsl0QVe0j/kJn/rhN/wCimqjT4ZZILiOeJtskbB1OM4IORVp2Zxsu1d0jV9Q0LWYNW0q4+z3kBJil2KxQkEZAYEZwTg9QcEYIBqvGILtd8EsML/xQyybNvurNwR7Zz9cZL/scn/Pez/8AAuL/AOKrUku6Z4k1bSLF7Gzlt3tXuYrxre6tYrmNpYw6oxSVWBwJHBGMHPIOBjUuviJ4rvQkdzdae9tHLDKll/ZlqLVWh87ywIBH5YUG5nJXbhi5JBOCOe+xyf8APez/APAuL/4qj7HJ/wA97P8A8C4v/iqBaHQj4i+KxrP9pfarDcLQ2H2X+zLX7J5Bk8zy/s3l+Tt8z58bPvc9earXvjTxBqXhxNE1CWwurdI0hSabTrZ7pI0I2ItyY/OVQAAAHxt+XpxWP9jk/wCe9n/4Fxf/ABVH2OT/AJ72f/gXF/8AFUBoX9R8Ua7qx1c6hfed/bF+up337pF864XzcPwBt/18vC4HzdOBhLHxNrumW2mwWGoPAmm3zalabFXMVwwjBcHGTxDHwcj5enJzR+xyf897P/wLi/8AiqPscn/Pez/8C4v/AIqgNDrIPix49ttRub+LWoTdXF5LftO9hbu6TS48xo2aMmMPgBlTapAwRV7RPig+ifDefw5Fp1zcXslnc6fHd3E8LRwQThg6Iog84DDudvnFNx3bc1wv2OT/AJ72f/gXF/8AFUfY5P8AnvZ/+BcX/wAVQGhv3vxB8W6h4Zl0C71KF7GaGGCYLZwJJOkRXyhJKqB3K7FALMSAMZwSKx5tZ1O40rT9Nkuj9l08yNaxooXy2dgzNkAEkkDk5OAB0AqD7HJ/z3s//AuL/wCKo+xyf897P/wLi/8AiqA0NHxD4q17xXdxXOvXq3UsXm7GEMcWPMmeZ+EUA5kldv8AgXpgVrW3xP8AG1nYR2kGqwbUtxZmR7C3eWS3C7RBJK0ZeSLaAPLclcADHArmPscn/Pez/wDAuL/4qj7HJ/z3s/8AwLi/+KoDQlsdWv8ATrXULeyn8qLULf7JdLsU+ZF5iS7eRx88SHIweMdCRU9l4j1vTrK0tLG/e3itL0ajb+Wqho7gBQJA2M5G1eM44qn9jk/572f/AIFxf/FUfY5P+e9n/wCBcX/xVAXR0V78RvF9+bfz9Rt0W3S7SGO2sbeCOMXcIhuMJHGF+dBg8cHLDDEmq1z438SXei/2VPeW7W5sV012WzgWWS3V4nSN5Qgdwpt4du5iVC4GASDjfY5P+e9n/wCBcX/xVH2OT/nvZ/8AgXF/8VQGhLDq2oW+gXeiw3G2xvJorieHYp3vEHEZzjIwJZOAcHdznAxp6b428SaV9lW1vLdo7aybTo4LmzguIjbtO1wY3jkRlkHmsX+YEg4x0GMf7HJ/z3s//AuL/wCKo+xyf897P/wLi/8AiqA0N2fx/wCLLnwtL4em1GJrCa1ispVFpCJJYYnR40eUJvYIY025Y7QNowCQcbVtUv8AXNfvta1Sfz76+uJLq5m2qvmSOxZmwoAGSScAAVH9jk/572f/AIFxf/FUfY5P+e9n/wCBcX/xVAaFeirH2OT/AJ72f/gXF/8AFUfY5P8AnvZ/+BcX/wAVQFyvRVj7HJ/z3s//AALi/wDiqPscn/Pez/8AAuL/AOKoC5XqSX/kX5/+viL/ANBkqQ2uwbpbuzRB1YTq+PwQkn8BVG8ulmCQwgiCMkru+8xOMsfTOBx0GB15JUnZD3KtFFFZFHQfEz/kqWqf9sv/AESlFHxM/wCSpap/2y/9EpRXNQ/hR9Ee/wAUf8jnGf8AX2p/6Ww+Gf8AyVLS/wDtr/6JeufroPhn/wAlS0v/ALa/+iXrn6qH8WXov1Fif+RNh/8Ar7W/9IoBSqzI4dGKspyCOoNJRW54J3Phz4i6rpWrwXKzi2lACSSxghZx0HmLnB+uO5yDk12406z8SyTf8I1qieHpJmMklnbRDyzITkH5SCEz0AyB2A6V4fWhp2t6lpcqPZ3LoUOV5+6fb0qeVWtY66WLnGpzyk9d7aNnVeKrjxN4a02+tNburoTSp5KMX3LOW43Bsc4UHngjgHFcjoWhCMpqGoIM7fMhgdA4PvIpI+XpxjnPYdfYNOHiLxj4Vs/EkkNjqVxCZEjto23Sw7cbpFjbhpDjqpLBQMAZrlb+7tp4SRbvNKDu8tUfcx+mM5/WsXGz2sdlaSrS53Ucktr7/n+RmQxTXKM/mSxAj5RGWUSHjnB6Dnnp/WrV9Le2+gXkE1/IkroC9lFkKi7gMyZx8x4woBwDye1dFpema+kF1cpZto7OESG7vYzGYoycs6qRnIAwMAdScjrWZ4gg8Jab4cuY7XWJ9U1afChmOQvzglm28ZwO5PWnGLbV9jb3adFzg9Wn1srarvq/Lon1ODooorrPCFVmU5UkH1FDOzHLMT9TmkooAK3LTwzcSWAvdQuYrCJ0LwpIC00/HGyMc4PHJwOepqhpk1ra3gurqMSiPlYiMhm7Z9hXS21v4h8VXwuLfRfMWX/l6udwi2g7ScnAOPQZPB64rGrNx8l3PWyzL3i5ckIuc3tGKbfq7J6fd6o5yPSbljh3giPo8gz+Qq+mj2Y88GV33DEQCncp9eBg10zaT4M8ISCfxHeLqOojDfYLUZVD8pwVz75+cgMD92uO8QeLdQ16VIxFFY2cQKxWtsNqhc8bv7xAAHYccAZNYxrSqv3Fp32+7uenj8hp5VSf12slW6U42k1/je0fTV+SN43wtLBLWBXhs1JwkriJWJwNz9C5wBk4/CsHUtXj3v5MgmmYbQ6ghIh/s56n3rAJJOSc0VoqaR4dbGyqWet1oru9l2WyS+WnQKKKK0OIKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAOg+Jn/JUtU/7Zf+iUoo+Jn/ACVLVP8Atl/6JSiuah/Cj6I9/ij/AJHOM/6+1P8A0th8M/8AkqWl/wDbX/0S9c/XQfDP/kqWl/8AbX/0S9c/VQ/iy9F+osT/AMibD/8AX2t/6RQCiiitzwQooooA0dJ17WNDnM2k6jPaMevltw31HQ11b/GT4iSWLWreIZdpXbvCKHx9RyK4Oigd2jpdN8e+J9N1B7pb83XmHMkVyN6McH6Edc8EZwM5refx34Y1pwfE3hNTJtDPc2j/ADyOAB/snbjPBY4wOvUeeUVjOhCb5nv3Wh72A4nzDBUfqsJqVLfknGM4/dJO3yt17s9D+y/Cqcef/bmp2vmfP5Gxj5WedufLPTp1PTqetL/whHhv/ooOlf8AkP8A+O153RU+xmvhqP8AB/odn+sOCq/7zl1J9uV1Iet7Ts/La3Q9E/4Qjw3/ANFB0r/yH/8AHaT+y/hhAfJuPFN9JNH8sjwxkozDglcRkYz05P1NeeUUeyqP4qj/AAX6B/rBgKWuHy6mn/edSf3JzVj0OPxl4J0iZJtC8IPNIWDM95IAYyvKlCS+DyemOg69sXV/iH4o1fYv237DGuDsscxZPPJbJbv0zjgcZrlqKccNTT5mrvz1McTxbmdak6FOapU/5acVBf8AkqTffVsKKKK3PmgooooAKKKKACtfwqtk/jjSE1GFZbVryJZEYgKQWA+bIIK+o7jI4zmsiihAz1/RNNFn4o1RLeC+02CLXLL/AEOXYVkBmfDD92CFxyoBxg9Wqta+HNFtfirY+fayanbX/wBqb7TIyG3eXa58sIVPKn5cMQd2DgYwfKaK05/Ijk8z0DR/BGmalCslxDqts0l29vLGZEzpqqoIefKDOT7J9c1dvtBtNQ+Fej3PmzXdxZWc5itbVgrOvntmU5Byi45AGeR0HNeZUUuZdh8r7nY6f4LdINVTVbG/utSsJI4/7K0+VPNIcZ35CvlQMdAevarNp4L0u48LpqDz3il7Oa5e73r5FtIhIEDjbksceoPPANcLRSuuwWfc9Gl8HeFbXRprqf8AtiSS20+0vZNlxGquZiFKqDGcAE5yc1XvvCunaPrh0GUmYXmrLbxSuB5ghQAtg44LNIq59UNcDUjXE7JEjTyFYRiMFjhBnPy+nJJ47mnzLsHK+56Zd6Rp1x4MlupdKhgiEEcizxxRxpGWgkk+Vwu9irokZDs2ST0JGM+78F6AukSeRc38N3DptrqEk00iNF+9YBl2hAQBnOd1cle+INW1C0a3u7iN1cgyOII1klI6b3Chn/4ETWZQ5LsJRZ6NrHgXw5pN5YCS+1JreW+jtpJhG+ySNh/rEkMQQEH+EM+R3pdR+HukaXpF5c3WqTCSyUQXA3LhLh2jMfblNkhJ75U8ivOKKOZdh8r7nr9x4S06z8KT6EGvbKzn1q3iN/eOrJMuw/vI8KAFOcdT2561iDwHpDarp8EsuoWLXH2nNhcOhuJPKGUKHaAN/bI+ma87oocl2Eovuesa14atL630i2mtNSiez0XzYtL3r9qlbzT8mdnUZJPyZx2qlY/DzRbnXdSsFub+drfyvKCkoiFk3MssyxSKrKeOQP6V5pRRzLsHK+56BZfD+C68C3WsSmWKaGzmu0ljn82J/LJ+UgRBVyB/z0J74x01bbw9p+ieBNcmih1C4gn022kkvt6+TNudWZI/l4I6ck+4HfyqijmXYbi31PSh8PvD6araWs+sTKuoSPPYsHX95aiMMucKTvZm2jA/hbAPAqtJ4M0C11TUBcvqzW9rpRvzAVaCQOHC7d0sK7l/2gg/SvPqKOZdg5X3PTn8MaHYaB4mtLfTLzUZkisrqAh0M8cbqWO0iM4CnO4gYIx93GTQuPAVnHoV1q0ZvmtE022uoZ9ylHlkYB1zt5AyeByOM1wFFHMuwcr7nozeCfDUvjnVNBtp9RT+zoi22WYPJdN8vCBISVAyc4VyeOBzXH+JdLttG8TXGn2ctxJDHtKm5heGQZUHDK6qeM9cDPXvWTRSbT6Ak11CiiipKCiiigAooooA6D4mf8lS1T/tl/6JSij4mf8AJUtU/wC2X/olKK5qH8KPoj3+KP8Akc4z/r7U/wDS2Y3h3Vm0PxVYaqGcLBMDJsUMxjPDgA8ZKlh+PatXxbo0WieJ5YLR0exnUXNo6MGVon5XBycgcjJPOM965euj0LWrB7aPQfEolk0rzN0U8X+tsmJ5ZODlD/EuD/eAyOXK8Zc6+f8AXkRga1LEYZ5fWai3LmhJ7RlazT7Rmkrvo4xvpdrIorq38CXt4wk8MahY67blVYtBMkckYIBHmIzfKT82Bkn5TnHSm/8ACuPGf/QG/wDJiL/4qq+sUv5kU+F83v7mFnJd4xcov0lG8X6ps5aiup/4Vx4z/wCgN/5MRf8AxVH/AArjxn/0Bv8AyYi/+Ko+sUv5l96F/qvnP/QHV/8ABc/8jlqK6n/hXHjP/oDf+TEX/wAVR/wrjxn/ANAb/wAmIv8A4qj6xS/mX3oP9V85/wCgOr/4Ln/kctRXU/8ACuPGf/QG/wDJiL/4qj/hXHjP/oDf+TEX/wAVR9YpfzL70H+q+c/9AdX/AMFz/wAjlqK6n/hXHjP/AKA3/kxF/wDFUf8ACuPGf/QG/wDJiL/4qj6xS/mX3oP9V85/6A6v/guf+Ry1FdT/AMK48Z/9Ab/yYi/+Ko/4Vx4z/wCgN/5MRf8AxVH1il/MvvQf6r5z/wBAdX/wXP8AyOWorqf+FceM/wDoDf8AkxF/8VR/wrjxn/0Bv/JiL/4qj6xS/mX3oP8AVfOf+gOr/wCC5/5HLUV1P/CuPGf/AEBv/JiL/wCKo/4Vx4z/AOgN/wCTEX/xVH1il/MvvQf6r5z/ANAdX/wXP/I5aiup/wCFceM/+gN/5MRf/FUf8K48Z/8AQG/8mIv/AIqj6xS/mX3oP9V85/6A6v8A4Ln/AJHLUV1P/CuPGf8A0Bv/ACYi/wDiqP8AhXHjP/oDf+TEX/xVH1il/MvvQf6r5z/0B1f/AAXP/I5aiup/4Vx4z/6A3/kxF/8AFUf8K48Z/wDQG/8AJiL/AOKo+sUv5l96D/VfOf8AoDq/+C5/5HLUV1P/AArjxn/0Bv8AyYi/+Ko/4Vx4z/6A3/kxF/8AFUfWKX8y+9B/qvnP/QHV/wDBc/8AI5aiup/4Vx4z/wCgN/5MRf8AxVH/AArjxn/0Bv8AyYi/+Ko+sUv5l96D/VfOf+gOr/4Ln/kctRXU/wDCuPGf/QG/8mIv/iqP+FceM/8AoDf+TEX/AMVR9YpfzL70H+q+c/8AQHV/8Fz/AMjlqK6n/hXHjP8A6A3/AJMRf/FUf8K48Z/9Ab/yYi/+Ko+sUv5l96D/AFXzn/oDq/8Aguf+Ry1FdT/wrjxn/wBAb/yYi/8AiqP+FceM/wDoDf8AkxF/8VR9YpfzL70H+q+c/wDQHV/8Fz/yOWorqf8AhXHjP/oDf+TEX/xVH/CuPGf/AEBv/JiL/wCKo+sUv5l96D/VfOf+gOr/AOC5/wCRy1FdT/wrjxn/ANAb/wAmIv8A4qj/AIVx4z/6A3/kxF/8VR9YpfzL70H+q+c/9AdX/wAFz/yOWorqf+FceM/+gN/5MRf/ABVH/CuPGf8A0Bv/ACYi/wDiqPrFL+Zfeg/1Xzn/AKA6v/guf+Ry1FdT/wAK48Z/9Ab/AMmIv/iqP+FceM/+gN/5MRf/ABVH1il/MvvQf6r5z/0B1f8AwXP/ACOWorqf+FceM/8AoDf+TEX/AMVR/wAK48Z/9Ab/AMmIv/iqPrFL+Zfeg/1Xzn/oDq/+C5/5HLUV1P8Awrjxn/0Bv/JiL/4qj/hXHjP/AKA3/kxF/wDFUfWKX8y+9B/qvnP/AEB1f/Bc/wDI5aiup/4Vx4z/AOgN/wCTEX/xVH/CuPGf/QG/8mIv/iqPrFL+Zfeg/wBV85/6A6v/AILn/kctRXU/8K48Z/8AQG/8mIv/AIqj/hXHjP8A6A3/AJMRf/FUfWKX8y+9B/qvnP8A0B1f/Bc/8jlqK6n/AIVx4z/6A3/kxF/8VR/wrjxn/wBAb/yYi/8AiqPrFL+Zfeg/1Xzn/oDq/wDguf8AkctW54S0aLW/E8UF26JYwKbm7d2CqsSctk5GAeBkHjOe1X08CXtmxk8T6hY6FbhWYNPMkkkgAJPlorfMR8uRkH5hjPSsvXdasEtpNB8NCWPSvM3Szy/629YHhn4GEH8K4H94jJ4mVVTXLTfz6I3w+Uyy2ccVmkOWMX/DlpObWtnH4oxfWTSVvhu7Iz/EWrNrniq/1Us5WeYmPeoVhGOEBA4yFCj8O9FZlFXFKKSR4eJxE8TVnXqu8pNtvzbuwooopmIUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB//9k=",
	"ngambek": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwMDAgQDAwMEBAQFBgoGBgUFBgwICQcKDgwPDg4MDQ0PERYTDxAVEQ0NExoTFRcYGRkZDxIbHRsYHRYYGRj/2wBDAQQEBAYFBgsGBgsYEA0QGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBj/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4Poor0awsE+GEdjrWtaZHdeKLhFurHTrxG8qxi3ECaYAgtKSpCoD8mNzfMABtKVtFudGEwjrtyk+WEfil2/zb6Lr5JNrE0X4Z+O/EFr9q0vw1ePBsSRZZ9tusisMqyGQqHBAzlc9R6itT/hSfxO/6Fn/ydt//AI5S6W/iD4r/ABFsNI1/xFcGS48zZM6B0h2xFjsiBVRnywDjGepya9E/4Zu/6nP/AMp3/wBtrCpV9m7Tkk/Rs+my3IIZjTdXB4apUinbm9pThro/hcZW0a+0/U86/wCFJ/E7/oWf/J23/wDjlH/Ck/id/wBCz/5O2/8A8cr0X/hm7/qc/wDynf8A22j/AIZu/wCpz/8AKd/9trP61H+dfc/8z0P9TcR/0A1P/B9L/wCQPOv+FJ/E7/oWf/J23/8AjlH/AApP4nf9Cz/5O2//AMcr0X/hm7/qc/8Aynf/AG2j/hm7/qc//Kd/9to+tR/nX3P/ADD/AFNxH/QDU/8AB9L/AOQPOv8AhSfxO/6Fn/ydt/8A45R/wpP4nf8AQs/+Ttv/APHK9F/4Zu/6nP8A8p3/ANto/wCGbv8Aqc//ACnf/baPrUf519z/AMw/1NxH/QDU/wDB9L/5A86/4Un8Tv8AoWf/ACdt/wD45R/wpP4nf9Cz/wCTtv8A/HK9F/4Zu/6nP/ynf/baP+Gbv+pz/wDKd/8AbaPrUf519z/zD/U3Ef8AQDU/8H0v/kDzr/hSfxO/6Fn/AMnbf/45R/wpP4nf9Cz/AOTtv/8AHK9F/wCGbv8Aqc//ACnf/baP+Gbv+pz/APKd/wDbaPrUf519z/zD/U3Ef9ANT/wfS/8AkDzr/hSfxO/6Fn/ydt//AI5R/wAKT+J3/Qs/+Ttv/wDHK9F/4Zu/6nP/AMp3/wBto/4Zu/6nP/ynf/baPrUf519z/wAw/wBTcR/0A1P/AAfS/wDkDzr/AIUn8Tv+hZ/8nbf/AOOUf8KT+J3/AELP/k7b/wDxyvRf+Gbv+pz/APKd/wDbaP8Ahm7/AKnP/wAp3/22j61H+dfc/wDMP9TcR/0A1P8AwfS/+QPOv+FJ/E7/AKFn/wAnbf8A+OUf8KT+J3/Qs/8Ak7b/APxyvRf+Gbv+pz/8p3/22j/hm7/qc/8Aynf/AG2j61H+dfc/8w/1NxH/AEA1P/B9L/5A86/4Un8Tv+hZ/wDJ23/+OUf8KT+J3/Qs/wDk7b//AByvRf8Ahm7/AKnP/wAp3/22j/hm7/qc/wDynf8A22j61H+dfc/8w/1NxH/QDU/8H0v/AJA86/4Un8Tv+hZ/8nbf/wCOUf8ACk/id/0LP/k7b/8AxyvRf+Gbv+pz/wDKd/8AbaP+Gbv+pz/8p3/22j61H+dfc/8AMP8AU3Ef9ANT/wAH0v8A5A86/wCFJ/E7/oWf/J23/wDjlH/Ck/id/wBCz/5O2/8A8cr0X/hm7/qc/wDynf8A22j/AIZu/wCpz/8AKd/9to+tR/nX3P8AzD/U3Ef9ANT/AMH0v/kDzr/hSfxO/wChZ/8AJ23/APjlH/Ck/id/0LP/AJO2/wD8cr0X/hm7/qc//Kd/9to/4Zu/6nP/AMp3/wBto+tR/nX3P/MP9TcR/wBANT/wfS/+QPOv+FJ/E7/oWf8Aydt//jlH/Ck/id/0LP8A5O2//wAcr0X/AIZu/wCpz/8AKd/9to/4Zu/6nP8A8p3/ANto+tR/nX3P/MP9TcR/0A1P/B9L/wCQPOv+FJ/E7/oWf/J23/8AjlH/AApP4nf9Cz/5O2//AMcr0X/hm7/qc/8Aynf/AG2j/hm7/qc//Kd/9to+tR/nX3P/ADD/AFNxH/QDU/8AB9L/AOQPOv8AhSfxO/6Fn/ydt/8A45R/wpP4nf8AQs/+Ttv/APHK9F/4Zu/6nP8A8p3/ANto/wCGbv8Aqc//ACnf/baPrUf519z/AMw/1NxH/QDU/wDB9L/5A86/4Un8Tv8AoWf/ACdt/wD45R/wpP4nf9Cz/wCTtv8A/HK9F/4Zu/6nP/ynf/baP+Gbv+pz/wDKd/8AbaPrUf519z/zD/U3Ef8AQDU/8H0v/kDzr/hSfxO/6Fn/AMnbf/45R/wpP4nf9Cz/AOTtv/8AHK9F/wCGbv8Aqc//ACnf/baP+Gbv+pz/APKd/wDbaPrUf519z/zD/U3Ef9ANT/wfS/8AkDzr/hSfxO/6Fn/ydt//AI5R/wAKT+J3/Qs/+Ttv/wDHK9F/4Zu/6nP/AMp3/wBto/4Zu/6nP/ynf/baPrUf519z/wAw/wBTcR/0A1P/AAfS/wDkDzr/AIUn8Tv+hZ/8nbf/AOOUf8KT+J3/AELP/k7b/wDxyvRf+Gbv+pz/APKd/wDbaP8Ahm7/AKnP/wAp3/22j61H+dfc/wDMP9TcR/0A1P8AwfS/+QPOv+FJ/E7/AKFn/wAnbf8A+OUf8KT+J3/Qs/8Ak7b/APxyvRf+Gbv+pz/8p3/22j/hm7/qc/8Aynf/AG2j61H+dfc/8w/1NxH/AEA1P/B9L/5A86/4Un8Tv+hZ/wDJ23/+OUf8KT+J3/Qs/wDk7b//AByvRf8Ahm7/AKnP/wAp3/22j/hm7/qc/wDynf8A22j61H+dfc/8w/1NxH/QDU/8H0v/AJA86/4Un8Tv+hZ/8nbf/wCOUf8ACk/id/0LP/k7b/8AxyvRf+Gbv+pz/wDKd/8AbaP+Gbv+pz/8p3/22j61H+dfc/8AMP8AU3Ef9ANT/wAH0v8A5A86/wCFJ/E7/oWf/J23/wDjlH/Ck/id/wBCz/5O2/8A8cr0X/hm7/qc/wDynf8A22j/AIZu/wCpz/8AKd/9to+tR/nX3P8AzD/U3Ef9ANT/AMH0v/kDzr/hSfxO/wChZ/8AJ23/APjlH/Ck/id/0LP/AJO2/wD8cr0X/hm7/qc//Kd/9to/4Zu/6nP/AMp3/wBto+tR/nX3P/MP9TcR/wBANT/wfS/+QPJta+Gfjvw/a/atU8NXiQbHkaWDbcLGqjLM5jLBAAc5bHQ+hrlK9P8AElh4g+DXjWGy0DxRcPJParcu6RCNGy0iBXjJZXxgkE9N3GDzVa/sE+J8d9rWi6ZHa+KLdGur7TrNG8q+i3AGaEEkrKCwDIT8+dy/MSD0Rm7KT1Xf/gHzmLyumqksPRUo1o7wk1K/+GUbJvrblXk29DzmiiitTwDq/hnosHiH4s6Hpd0YzA1x50iSRiRZFjUyFCp4IYJt/HoelVvFGv3PijxfqGv3a7JLuUuI8g+WgGETIAztUKM45xk81u/BP/kumh/9vH/pPJXGVEP4j9F+v+R61VuOV00vtVJ38+WMOX7uaX3k9lfXum3yXunXlxaXMedk9vIY3XIIOGHIyCR+Na//AAnHjT/ob9e/8GEv/wAVWDRWrinujzqWKrUly05tLybRvf8ACceNP+hv17/wYS//ABVH/CceNP8Aob9e/wDBhL/8VWDRRyR7Gn1/Ff8AP2X3v/M3v+E48af9Dfr3/gwl/wDiqP8AhOPGn/Q369/4MJf/AIqsGijkj2D6/iv+fsvvf+Zvf8Jx40/6G/Xv/BhL/wDFUf8ACceNP+hv17/wYS//ABVYNFHJHsH1/Ff8/Zfe/wDM3v8AhOPGn/Q369/4MJf/AIqj/hOPGn/Q369/4MJf/iqwaKOSPYPr+K/5+y+9/wCZvf8ACceNP+hv17/wYS//ABVH/CceNP8Aob9e/wDBhL/8VWDRRyR7B9fxX/P2X3v/ADN7/hOPGn/Q369/4MJf/iqP+E48af8AQ369/wCDCX/4qsGijkj2D6/iv+fsvvf+Zvf8Jx40/wChv17/AMGEv/xVH/CceNP+hv17/wAGEv8A8VWDRRyR7B9fxX/P2X3v/M3v+E48af8AQ369/wCDCX/4qj/hOPGn/Q369/4MJf8A4qsGijkj2D6/iv8An7L73/mb3/CceNP+hv17/wAGEv8A8VR/wnHjT/ob9e/8GEv/AMVWDRRyR7B9fxX/AD9l97/zN7/hOPGn/Q369/4MJf8A4qj/AITjxp/0N+vf+DCX/wCKrBoo5I9g+v4r/n7L73/mb3/CceNP+hv17/wYS/8AxVH/AAnHjT/ob9e/8GEv/wAVWDRRyR7B9fxX/P2X3v8AzN7/AITjxp/0N+vf+DCX/wCKo/4Tjxp/0N+vf+DCX/4qsGijkj2D6/iv+fsvvf8Amb3/AAnHjT/ob9e/8GEv/wAVR/wnHjT/AKG/Xv8AwYS//FVg0UckewfX8V/z9l97/wAze/4Tjxp/0N+vf+DCX/4qj/hOPGn/AEN+vf8Agwl/+KrBoo5I9g+v4r/n7L73/mb3/CceNP8Aob9e/wDBhL/8VR/wnHjT/ob9e/8ABhL/APFVg0UckewfX8V/z9l97/zN7/hOPGn/AEN+vf8Agwl/+Ko/4Tjxp/0N+vf+DCX/AOKrBoo5I9g+v4r/AJ+y+9/5m9/wnHjT/ob9e/8ABhL/APFUf8Jx40/6G/Xv/BhL/wDFVg0UckewfX8V/wA/Zfe/8ze/4Tjxp/0N+vf+DCX/AOKo/wCE48af9Dfr3/gwl/8AiqwaKOSPYPr+K/5+y+9/5m9/wnHjT/ob9e/8GEv/AMVR/wAJx40/6G/Xv/BhL/8AFVg0UckewfX8V/z9l97/AMze/wCE48af9Dfr3/gwl/8AiqP+E48af9Dfr3/gwl/+KrBoo5I9g+v4r/n7L73/AJm9/wAJx40/6G/Xv/BhL/8AFUf8Jx40/wChv17/AMGEv/xVYNFHJHsH1/Ff8/Zfe/8AM3v+E48af9Dfr3/gwl/+Ko/4Tjxp/wBDfr3/AIMJf/iqwaKOSPYPr+K/5+y+9/5m9/wnHjT/AKG/Xv8AwYS//FUf8Jx40/6G/Xv/AAYS/wDxVYNFHJHsH1/Ff8/Zfe/8ze/4Tjxp/wBDfr3/AIMJf/iqP+E48af9Dfr3/gwl/wDiqwaKOSPYPr+K/wCfsvvf+Zb1HVdU1e6W51bUru/mVNiy3UzSsFyTgFiTjJJx7mrfhfX7nwv4v0/X7Rd8lpKHMeQPMQjDpkg43KWGccZyOayaKbimuXoZQxFWFVV4yfOmmn1utmb/AMTNFg8PfFnXNLtTGIFuPOjSOMRrGsiiQIFHACh9v4dB0orU+Nn/ACXTXP8At3/9J46KwpO8It9kd+dU40swxFOCslOSXopMPgn/AMl00P8A7eP/AEnkrjK7P4J/8l00P/t4/wDSeSuMqofxJei/Uqv/AMiyj/18qf8ApNIKKKK2PICiiigAooooAKK1tA8L+IPFF8bTQNKuL2RfvsgASPIJG9zhVztOMkZxgc16Db/A3UbO2jvPF3inRdAtZEAVpJN7LKRnyzuKLnAbkMfu8ZHNZzrQg7SZ6mCyTHY2PtMPSbj32j/4E7L8TyiivXj4S+CFn/ot/wCOdYkuohsleCI+W7DqUxCw2k8j5m4xyetL/bHwExn/AIQjXf8Av8//AMkVHt77Rb+X+Z3f6vOOlXE0ov8Ax3/9JUrfP5HkFFevf2z8A/8AoSNd/wC/z/8AyRSf2F8BLs/av+Eo16x83959k8tj5GedmfJbO3p95unU9aPbPrB/d/kL/V5S/h4qi/8At+3/AKUo/geRUV62fgcdT/5FHx1oWteX/wAfGW2eVn7v+rMmc4brjp37cF4i8F+KfCnlnX9GuLSOTAWbKyRknOF3oSu75Sduc4GcYqoVoTdk9TkxmRY/Bw9pWpPl7q0o/wDgUbr8TBoqV7eaO3inkjKxy52Mf4sHBx+NRVqeU01uFFFFAgooooAKnsbK51LVLbTrKLzbm5lWGKPcF3OxAUZPAySOtQV0Xgj/AJGx/wDsHX//AKRzUpOybN8NTVWtCnLZtL72X4YPDmmR+Qukw61MOJbq7lmSNiP+eSRtGyryRlyxYAHCZK0/7XoP/QlaL/3/ALz/AOSKz69e+G/gvw9r3gaxvdR0a0vJ7jW3sp5prySGRIBAH/dIsih3B5ACsTk8dx34bA+3lyR39X+h5eb8SRyqh9YqxXLe1lGD6N/a9OrbfmzzH7XoP/QlaL/3/vP/AJIo+16D/wBCVov/AH/vP/kivVPAXgjwjquk2dzqmlS3QbXby0fzJZIneCOzaVUIVhtO4A9j26cVQ8RfDrTovDugf8I/H582t6s0dndl2PmWzqhjDLnAK7mDcA5U1v8A2TL2ftFt6u/T/M8tcd4f608JKNn3cIW+1fXy5W9r2+dvOvteg/8AQlaL/wB/7z/5Io+16D/0JWi/9/7z/wCSK7z4m+EvDul6Taax4TigWziuZNOuvJvluw7rzHKSrtsLqG+U4xt6Cufh8Eeb8Ibjx1/bVqvk3YtfsBHztkgZznrznbjoCc1lUy5wm4WvZX3ex3YXiyjiMPTxOkVOXKk4RvzN2Sdk7X9bWMP7XoP/AEJWi/8Af+8/+SKPteg/9CVov/f+8/8Akiul8LaJpMnw+8QeKb3Tv7WuNOkgijsTI6RqHJzLJsIYgYwMEc9a3fC+keBtf03UrzV9BuNJl0Qf2jcW1vLKwvLYr/qvnbKHeVww/hbuRuqqeXc/LqlfXd+fy6MjFcWrD+0bp8yptRbUKb1aTSt8T+KKva13vbU89+16D/0JWi/9/wC8/wDkij7XoP8A0JWi/wDf+8/+SK9e0PwZ4M1vwhoczaLZw3+sWmozxwx3F157PE7+WsRLGIKqgA+ZycDqc1zN7ovhrT/gx4f1Y2mjJqeo292ZJL570zSMkpRTCIj5QIGPv4GcZzzVyypxjzNq1r7vy/HVHLS44hVqexjSfNz8lvZ09/f10+z+7lr5etuH+16D/wBCVov/AH/vP/kij7XoP/QlaL/3/vP/AJIr1bXPA3hq2+G8moxaLDDJH4fstQW6t7qSS4a5kID74i7BYyOd2xQOcHsKVx4Q8Ox/B3/hMl8PyjUXsEX+zPtD7YsyFPt+N+/YccKflyehWnLKZRbTeyvu9iaXHdCpGMlDeagvcp/E0mvlr8uttL+bfa9B/wChK0X/AL/3n/yRTG0rSfEEqWemaWml6pIwjtkgmd7edieI2EhZldicB9+3IUFVBZxSorgdGNtD6lY6TdpxTXX3Yr8Uro5ut/RNEtp7H+1tWM32HzGgjit3CSTyKFLAMVYIqh1JJBzuAA+8yJ44/wCSneI/+wpc/wDo1q25P+RR8Nf9eEn/AKV3FccpvlujgzVSw8/Yxf2nG/on917f5a6h5mgf9CdpH/f+7/8Aj9HmaB/0J2kf9/7v/wCP1Ur2H4VfCjRfGHhefXNbu7raZmgihtnC7cAZZiQeeeB7d81hzy7nz2OxNHA0vbVpyt/il/meU+ZoH/QnaR/3/u//AI/R5mgf9CdpH/f+7/8Aj9dXfeCLTTfjhH4JudRJtGu4ovtHAbY4VgPQNhgPrV7VPD+iXHhbxJfRaG2izaNqEVrD+9kb7UruylGDk/OoAbK4GD0o55dyHjKPuWlJqSTT5pbSdl9q+/3dThvM0D/oTtI/7/3f/wAfo8zQP+hO0j/v/d//AB+vYfE3w88JWp8UX+kWRFtp1r5XkNO5NrchkO7lssrI+RnIyG9BWMPCHh3/AIaUufCv9nf8ShBIVtvOk4xalx827d97nr+lHPLuc1LNcPVg5xc9IuXxPZJN/a395f5nm/maB/0J2kf9/wC7/wDj9HmaB/0J2kf9/wC7/wDj9er+FfAXhfXfDPhB2tD/AGndPJcXaGZwLu3ScxuB83ysoKH5cZAasm10LwzafDu81i7s9IFymuTWKSapJeFPKWMMEUW5zuznlvfnpRzy7lLM6Lk4LnbTt8Uu7X83k/6uefeZoH/QnaR/3/u//j9HmaB/0J2kf9/7v/4/VSijnl3PW9l/el/4FL/MtlvD0imN/CWnxq3BeC4uVkUeqlpWUN6Eqwz1B6Vz2u6MmnCC+sneTT7pnWEyEeZG67S8b4xkrvT5gMMGB4O5V1ql1H/kml//ANhO0/8ARVzV05u9mXTlKjKLTbTaTTbe7t1btbf8DjKKKK6T2js/jZ/yXTXP+3f/ANJ46KPjZ/yXTXP+3f8A9J46K56P8OPoj2M//wCRnif+vk//AEph8E/+S6aH/wBvH/pPJXGV2fwT/wCS6aH/ANvH/pPJXGVUP4kvRfqKv/yLKP8A18qf+k0gooorY8gKKK7X4ffD668ZX0t5eTf2foFllr3UHIUAAbiiE8bscknhRyewaZzUFzSOrB4OtjK0aFCN5P8Aq77JdX0Od0Hw9rPibWF0vQrCS8uihfYpChVHUszEBR0GSRyQOpFesQ+Dfhr8ONlx431T+3tZTa39l2o3JG37tsFMjOMk5kKq6k/ITWbrXxIsdD8PQ+E/hkk+nafHvFxqMigT3bHKlweq5GDu4b7oAQLg+ZVkoTq6y91fj/wD3FXwOU+7Riq9b+Z604/4V9p/3nporI9H134zeJr+FbHQI4PD2mpF5KW9ooZwm0LjeQNuMHbsC4z3wDXFQjUvEniONLi8lury6dUa4uZC7dMZZic4Cj8AKza9F0nwnqxvNM0Hwxpz6n4j1H90Irdt7+YxPydggQKSxPAwSTgVqqcKS9xWPMxOZ4rMKiljKjku3Rei2XySOa8aPZv43vGsMNagqkZHG5VUKD+IUV658NtGjurGL/hLv2d01Lw9KNratbSXdncqCPvxtJNsl9cADPYivYPB3wL8MfDSK31rxBv8T+L5U3xWlpjyLbb1MZYZ2r/FO2B/dHr0Ml/rnirUpdI/s42t+0aO0cd3I+Inzt80ydmCkjODgA4wRRF6JGFd+1qyqpWTd7Hyv4x+EF4PiNfWfw+gn1LQm2y2s9xIiMqsM7CWIyR646Yzg1j6j8GPiXplobqfwrdyQgZLW7LNj8FJP6V9feG/C9z4fZr3VNFnFhuKy3lnLvltyDg+bGQTtGB93oOcEV6LLoepx2wudPCavasoYW4KJKynnMTjCOcdA2M/3qrnsZOmj8xv9N03UVYefaXcDhlPMckTg5B7EEGvT/APxC+IQ1K2t5bo6jpatsml1FSVjUsCSZgN27GQuS3XAU4GOn+LPibQ9f8AidcMdLiSz0l3gBuLbyLiZ1+8ZNw3JggjaRkDnAJ48ym8Sy6grJNemxsVbhUBd29di5wOB1P51nVUais1c9TKcXWwVZTp1XBeTtf16fedre+H/AvjvXp9MGtxeH9QhKwafBHEiQshYZ+TCqzMzNhVYHJJwQK8s8VeDvEHg3VFstds/K8zcYZ0YPHMqnBKsPwODhgCMgZFVb66+2X8k4QRqThUBztUcAfliu78J/ExrPR38L+M7Z9b8NyQeQINqmWADJXaSQSM4AycrhSpG3BzVOpSV46rt/kd9XF5fmlRwrx9lPXlmr8r7Kcenbmjt1TSPMKK9A8d/DqHQ9JtvFPhW9k1fwzdKpW5ODJAx4xJgDgnjOBg/KwBxu8/rWE1NXR4OOwFbA1XRrqz3XVNPZp7NPowoooqzjCtTw5qcOkeJLe8uUd7Yh4LgRgF/JlRo5CmSBv2O23PGcZyKy6KTV1YulUdOaqR3Tv9x195p1zZRxTsBLaT5NvdxgmK4UYyUYgZxkZBwVPDAEEAh1XU7e0itYNSu4oIZxdRxJMyqkoGBIoBwHwB8w5rn9N1zWtG83+x9Yv9P83HmfZLh4t+M4ztIzjJ/M1f/wCE48af9Dfr3/gwl/8Aiq1Vecdl+Jc6GDq6zbXlyqVvm5L8vLXc2k8S+Io3Z49f1RGaZ7gst1ICZXXaz9fvFSQT1IOKZb6/r1pFaRWut6jBHZsz2yRXLqIGbO4oAflJyckdcmsj/hOPGn/Q369/4MJf/iqP+E48af8AQ369/wCDCX/4qq+tVf6f/AMf7Oy+1tf/AACPn/e8397LyX17Hp8thHeXC2szB5YFkISRh0LLnBIycE1XqH/hOPGn/Q369/4MJf8A4qj/AITjxp/0N+vf+DCX/wCKqXXm+n4/8A3WHwkb2nLX+4v/AJM0NP1PUtJu/tWl6hdWM+MebbStE2PTKkGntrOrtPdzNqt6ZLxdl05nYmdfRzn5hwODnpWZ/wAJx40/6G/Xv/BhL/8AFUf8Jx40/wChv17/AMGEv/xVNYmola34/wDAM5YLAylztu/fkX/yRtw+J/Elto40m38Q6rDYBSotI7uRYsEkkbAcYJJzx3NEHifxLbaOdItvEOqw6eUaM2kd3IsW1s7l2A4wcnIxzk1if8Jx40/6G/Xv/BhL/wDFUf8ACceNP+hv17/wYS//ABVV9bq/03/kZvLcud79Xf4I79/i38zWGu64JPMGs6gH+zfYt32h8+R08rr9z/Z6e1B17XDdPcnWdQMzwfZXlNw+5ocY8snOSmONvSsn/hOPGn/Q369/4MJf/iqP+E48af8AQ369/wCDCX/4ql9aqf0/+AV9Qy/u/wDwCP8A8kTVoWFghiGqaos0GjRSBbi5UY3YwTFGSMNKQeF99xwoZhk/8Jx40/6G/Xv/AAYS/wDxVZmo6rqmr3S3Orald38ypsWW6maVguScAsScZJOPc1DqyelrHQo4am+ZNya6NJL5+89PLr3QarqM+r67e6tcrGk15cSXEixghQzsWIGSTjJ9a6nRZW13QLLS7VGl1OwDxJbRqS08BcyAoOSzqzybgP4dhAIVyOLorKUE1Y4MZSeJ96T9697+ev8Amzrq6Hw3458U+EYp4tA1V7aKc7njKLIpbGNwDAgH3HpXGf8ACa+Mv+ht13/wPl/+Ko/4TXxl/wBDbrv/AIHy/wDxVY+xfc8urgataPJUhFrs23/7abV7fXmo6lNqF9cyT3UzmSSZzlmY96mvta1nU4oo9S1a+vEi/wBWtxO8gT6Ak4rn/wDhNfGX/Q267/4Hy/8AxVH/AAmvjL/obdd/8D5f/iqPYvuV9Trae5HTbV6f+SnRPrutyNdtJrGoM17gXRa4cm4x08zn5sds5q1L4w8XTFDN4p1qQxsWQvfSnaSpUkZbg4Zh9CR3rk/+E18Zf9Dbrv8A4Hy//FUf8Jr4y/6G3Xf/AAPl/wDiqPYvuQ8BUe9OP3//AGp0EGtaxavaNbatfQtZhhbGOd1MAbO7Zg/LnJzjrmp7LxN4k02F4tO8Q6rZxyOZXS3u5IwznqxAIyTgc+1cx/wmvjL/AKG3Xf8AwPl/+Ko/4TXxl/0Nuu/+B8v/AMVR7F9xywNWW8I/f/8AamkSSck5NFZv/Ca+Mv8Aobdd/wDA+X/4qj/hNfGX/Q267/4Hy/8AxVHsX3NPq+I7R+9//ImrFFLPOkEEbyyyMESNFLMxJwAAOpNReI7pLDQh4eyDePcrc3idfIKKyxx57P8AvJS45x8g4YOozJ/F3iu5tpLa58T6zNDKpSSOS9lZXUjBBBbBBHasarhS5XdmlLCTclKray1stdfN2W3a29tegUUUVqekdn8bP+S6a5/27/8ApPHRR8bP+S6a5/27/wDpPHRXPR/hx9Eexn//ACM8T/18n/6Uw+Cf/JdND/7eP/SeSuMrs/gn/wAl00P/ALeP/SeSuMqofxJei/UVf/kWUf8Ar5U/9JpBRRWn4e0HUPE3ia00LS1jN1dOVTzG2qoALMxPoFBPGTxwCeK1bSV2eXSpTqzVOmrybsl3b2R0Xw++H114yvpby8m/s/QLLLXuoOQoAA3FEJ43Y5JPCjk9g2v488eWup2MXhHwjB/Z/heywkcaAqbog53tnnbnkA8k/M3zYC3fiRrWk6Hpa/DLwnB5Wn2UokvroS7nu5wOQxU4bBxuz/EoAChBnzKsqUHUftJ/Jfr6n0eYYiGWUpZbhX7z0qTXV9YLa0V1/mfkFFFTWtpdX15HaWVvLcXErBI4YkLu5PQADkmuo+ZI4ziZTxwQeelfpV+zj8Fz4R+Gs/jnVohP4i8SO8iSFdv2Sxdi6IoPKmUbXbvgqp+6c/Mfwa/Z7nTxTp/iP4t2g0vTI38630C6IW71Erhvni+9FAOrswBYfKo+bI+5PGHjebTfhreSWkw+0XLR6da7RjbNPIIQwx6b2b/gNYVXfY3owlJqK6j7XQNNlumZEWaW8Tzppeu+NWCqP9zJ4HTqe5ry74IbfEeufEHXLhM3cuvkktyRH5W1B9AARXoXhbxnpTfF3xVp9uYpLXTbbTdLt4yeEC+cT+O7aPwFec+BfE1v4C/al1zwTe2dvDZatGXsZSpCznLSRE+p2tImR/EmKxk2mj08JCM6NaK+JJNeiav+GvyPXlsIYtXitdmJLhWdCP4igXI+uCD9BWJcavovgvV73TdSZ4LCO3e7WNIi7xMqmRo0QdVdAzpjjKSLxjjD+J/xIl0nVdC1DSIFln0/Wna4hQEs0BsyZdo/3XBx/s1xHxt8Zwa/8PLXxNoV+q6xplwgn8u4COYmwVAkIICbjHIGIxtLcjJolKybMsJhvbTjGWibtf8Aq/8ATPL/ANqHTfC/xBuJPFfgizNveWdhbXV9NJIkZ1SF9qEiL73nwlgGHJZVbrsGeQtPg1eX37OcUsumr592Dd2l0MBxPj5FPfY6gR+m4g9q6y+8ReGp/h1othp+jtHrEMgF1qFzIVjeKXMiFdpxsyzbdwJCjIJ35HqfhG5srP4cQeHEv49RREKwXES7Umx1iwfuSrjBQnJI3LnJxGErSb97+vI9DOMuo4VRdNvVtWfZfa0779N9ran53MCrEEEEdjSV6j8aPh/N4a8Y3Ov6VE9x4e1GZpYblFJWGRjloX/ukHOAcZHuDjy6vQPm2rHZeAvHtx4QvZbO8g/tDQbzKXtg4DBgRtLqDxuxwQeGHB7FZviD8PrfSLKLxd4Rm+3+FrzDpIhLG0JONjZ5254BPIPyt82C3D13nw38Vafptxc+FfElrHd+H9ZZIp1mk2rbvnAl5ICjpubgjarA/KAearTcX7SG/Vd/+CfQ5bjKeLpLLca/d15JP7En9/uSfxLpurHm9FdL488I3Pgrxrc6PN81u3760kLhjJAWIUtgDDfKQeByDjjBPNVcZKSUkeJicNUw1WVCsrSi7NBRRRVGAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB2fxs/5Lprn/AG7/APpPHRR8bP8Akumuf9u//pPHRXPR/hx9Eexn/wDyM8T/ANfJ/wDpTD4J/wDJdND/AO3j/wBJ5K4yuz+Cf/JdND/7eP8A0nkrjKqH8SXov1FX/wCRZR/6+VP/AEmkFe1+DYf+FcfBC/8AG9xH5es6xi207enzRoc7GG5DjOGlwcq6pH3NeVeF9AufFHi/T9AtG2SXcoQyYB8tAMu+CRnaoY4zzjA5rvfjNrsd/wCOk0CxWCPTdFiFtDHblSgchS+NoG3GFTbk48vtkipqr2k1S6bv0/4J35K/qOGrZo/iXuU/8ck7v/t2Ovq0ecUUUV2HzIUoJDAg4PbFJRQB9LfB1bXwl4c0WW5Q3Gv+KWl1BzJybfTLQOy5J5HmTRE477EPava/iX4l/snwp4acS5jttetjMPeKORz+q5r5t8A60+s/ELU9ai3tZaT4VjsIcjiMLDFDt+pPmn6kmvSfidrH9oeHNVithFM1lrlvqKRSPtWSJ3EbAkchcsckdAwNYVHZXPTwFNTl6f52/U7Iwap4W8F6d42gn8x9WSRtRRR89vciQXEKyDqpKhlAPUdM5pPHt5pfxB8L2up+dJaalp8iXFlqFu2JIkdlOQe4GQceq571w3jX4nfFKPwtpkvjbw94cZJ7GKa3Omedb3v2YySJsm3KYpVieIKwbaVcqV5JNd/4B+HHiXxn8KbTxNo6WM1lcxSRrbNP5ckgBKnAIxG4IIKE4JGQRuxXHCryRtUO+dCd1XiuXoum2n5K33ml8ELLxD4y+MF5qfilra8h08STyyRLiOV2jSBDtP3S2xzj244rnfih8OtVsJb7xF8MoptW8O4e3leNd0KqSd0Sn/lqisTh14UkqCeQt/xdZ/E3w18M47Cx0CPQ9Mlmjj1Yi2mK7FEcAnunRi8kRyoEUWM5bdwCT5lp/h347+MNUi/4Szxj4l0uG1guJ7OztplsoY3hTFssduq4KtL5SLweGHI61ipSlPnTOqhQrcrnCN4R32/q/kd58PItHsvhJ4X1S50yGTVLiS0064a5BcusVy0aDY2QCuFOQM5Aplnp+jHx/wCJ9Pm0yyubadlvoWfKnEozztI3JvDA5zg4Nc1pOqXD+MPCng6XUpb+XT5W1DUb133+ayO0rOT6ZK/99CuL1rxfd6Z8TrK/tpgfInuNPlRvuyRFlkUH2Al/Su+i9LnNjcNJzjG95NN/LovuR2fjQarPoFxrHgW5W3eNWhvNDngWaG429UeJgRu4OD/FgdyK+VdQvTqGoyXbW1tblzny7aIRRr9FHAr6Du/Es1l4y0rWLdzHBqN19lmjJ4L8Oh+obj6H2rxHxxb2lp8StftrHb9mj1CdYwvRRvPA+nT8K7LaHhVVYwKKKKkxPYbKH/hZn7PkumLH5uveGsG32pl5Igp2oMJn5kVlCjktEhY814lXdfDPxI/hj4k6fdtJGlrcMLS6MjKiiJyAWLEHAUhX7fdxkAmq3xQ8Mv4W+JuoWaxxpa3Lm8tRGiooickhQoJ2hWDJ2+7nABFckF7Oo4dHqv1Ppsxf9oZfSx326f7ufnZe5L5q8W+680cdWhoVtDeeKdNs7lN8M11FHIuSNylwCMjnoaz60vDssUHjDSpppEjjS8hZ3c4VQHBJJPQVufMn2V+1r+zB4A8F/DhfF3wm0f8As+TRZE/tzT1vJ7lvs8x2xT/vXYqA6leOCGJ/hNcV+018B/D3h74vfD/wV8IfCckF94h01XNol1LMZ5y5G4tM7bAAMk5CgAk9K9Z+Jfx18D6b+3ZZxHxHoviH4feJ/DMOga+9lex3NsqvNcAO7oxUFPMBPOQjt6ipPi58Zvhr4b/bi+FHjOx8U6RrugaXpk9leXelXcd6LUSiSIMxiLYK7wxHUqDgVinLQvQ8Ntf2Jfipe+Om8J2nibwHPfw2/n3iw6s8hsD8u2OdFiMiMwYlTs2nafm6Z838EfByXxpc6zbzfEr4d+FZdLufsrx+J9ZNi1w2WBaEFDvUFeTx1FfbvwP8LeFbb9u7xr478PfFLQPFUfiGxu723sdGnNxJbxS3ELsblgNke1tqKu4s2c4Xaa8a+Bj/AARfwP8AEG81pvhw/wARP7ZmfTT8QWzpzW25SpAPB/5bfdBbO3tiq5mKx4h8QP2f/Hfw51zw5Z6xNo19YeI5Fj0vWdLu/tFlcFio4cKGA+dT93kHIzg139z+xH8WrbxjceF217wQ2qJa/a7a2Oqskl+ozuEEbxh228AsVVASBu649X+O/wAQvh94g+BfwgttD8T+BnutP8R28t3Y+HWS1t7NF3h3W2Zi8MOQCC4HBBIGcDY1z4keA5/+CqnhrxWnjzw5J4et9Ae3fVl1SE2kbGC4+QzbtgO5xxnqw9aXNKwWR82XP7KnxTtfhnrHi920B5dEg+06roEWorJqVhHtL7poVBCHYC+0tuwDxnivVPBHwp0jxt/wTWlvtM8P+GoPEr66UbxBqEcFs1rAsy72ku3AKRquc8+wBJAO38KvHvguy+Iv7Ul1qvjTQbaHWpL0aXLc6jEi6gpkvdnkFmxKCHTG3PDL6isjwHqvgPXf+CaN38NtW+JXhzw5rd/rWYob+8Xch+0RupmiXMixHby4UheGPANDbBJHhfxO/Z/+IHwsm0JtVTTdasdewumaloE5u7e6c4wiNtUliGBHGGz8pODjtV/Yy+LJhSzfVvBcfiR7X7YnhR9ZUao0eOoj27fbO/HvXqHxA+Kvw/8Ahh8Jvgn8ONL8UaX45vvCOvWuvaneaNKLiBUiaRjHHJ0JJmIXnIEYLBcgV6h4l+K/hnUviVF8TPh740/Zwht3hR11TxNZTL4ggPleW6nY6yN8uVA+U7TtwepOaQWR4N8EPAmh3n7GvxuuvEHg/TrnxFpIaG2mvrBJLuylWIgrGzKXjYMOgwc15B8QfgX4r+F3gTRfEHjXVtB06/1dBLb+HDPK2ppGf45IxHsQdOr5ycYyCB9R/BX47+G/C3hL45eN9R8QeFLrWLjXJNTsLBphYrq23cd0EErmUB+oHzFSwzkivIv2nbLwH8QGt/jt4B+IFhfHWkj/ALT8M6lqcf8AaWnSgBPkhZ95jBGCqghfvLlD8rTdwex4R4I0BPFfxL8P+GpTdiHUtRgtJWtITNKkbyBXZEAJYhSTjHavpv8AaT+GPwj+Et8vgfTfg/4lhvL6zVtF8V2+syXAvbngGN7dgU4YgMFw3zAgYIz51+yR8Q/B3wz/AGk7TxB43ZYNOmsprKO+aMuLKV9uJSACQMKyEgcBznjNfWHgHxN8PdEsbnwt8afjj8OfHug/25Hqnhq6bUjcXtrN5xkU3BAxEoYg5LbQC6sdhwCTaYJH52a54f17wxrUmj+JNE1HRtRjCs9nqNs9vMgYZBKOAQCCCOOa+iP2e/hR4A8cfsyfGHxZ4p0D7frHh7TJrjS7n7VNF9ndbSaQHajqr/MinDAjj0rzn9o3Vb/Xv2m/Fet32t6HrIvLrzLa80S+jvLZrcKEhCuhIyI1UEHBBB45r3n9lEFP2LP2gJGGEOj3ADHoT9huOP1H505P3bglqfPZ+Cniofs2D42/2ho//CPm8+w/ZfNk+179+zO3y9m3P+3nHaugb9nHxNpdl8ONY1/xR4Q0/SvHCiazuLy+lgjtk8pZcXDtEAhKsFG0t8xAz3r1H4ea14H8e/8ABPLUfhFffEPw34T8RWOrm9UeILk28c0fmCTKkAlsguMKGbKjjBBp/wC0x4r8Az/s8fBHRfB/jLSvEX9hW6xzraXCGdAkEChpYQxaIsVPyuAR0PINHM72CwftV/s1eEfBXimK++GuqeE9EtU023x4Tn1mabV7+4e4ePzLeCTe0ikFAMMB+7fjIOeKX9jL4smFLN9W8Fx+JHtftieFH1lRqjR46iPbt9s78e9ew/tDeIvA+t/HXwV+0d4Y+JHgnWtI8Oxaabjw9Hqa/wBrT+XfNI3lW2M5CzAkMVK7GJHFd/4l+K/hnUviVF8TPh740/Zwht3hR11TxNZTL4ggPleW6nY6yN8uVA+U7TtweplSdh2R4N8EPAmh3n7GvxuuvEHg/TrnxFpIaG2mvrBJLuylWIgrGzKXjYMOgwc15B8QfgX4r+F3gTRfEHjXVtB06/1dBLb+HDPK2ppGf45IxHsQdOr5ycYyCB9R/BX47+G/C3hL45eN9R8QeFLrWLjXJNTsLBphYrq23cd0EErmUB+oHzFSwzkivIv2nbLwH8QGt/jt4B+IFhfHWkj/ALT8M6lqcf8AaWnSgBPkhZ95jBGCqghfvLlD8rTdxPY+aqKKK0JCiiigAooooAKKKKAOz+Nn/JdNc/7d/wD0njoo+Nn/ACXTXP8At3/9J46K56P8OPoj2M//AORnif8Ar5P/ANKYfBP/AJLpof8A28f+k8lcZXZ/BP8A5Lpof/bx/wCk8lcZVQ/iS9F+oq//ACLKP/Xyp/6TSPV/gbbw2es6/wCLryGOW10bTmdlChpVZstujzxnZHIucj72OhNed3t5c6jqdxqF5J5lzcytNK+ANzsSScDgck9K9K8J/wCi/sq+LL22/c3Ml+kDzR/K7x5gGwsOSuHcY6fO3qa8up0NZzl8vuOvNm6OBweGWzi5vzcpNfgopBRRRXSfOhRRRQB7p8Jo7az+Dt5eFwJ9X8SWujFv7o8l5FH/AAIlh+FXvE+manbeHf7cL+daXFs0Ukf96M5jKn3CqvPfaOhGa8U07xDrFjoVzoVlO4t7q6gu9i53LPFuEbrjowEjj8fYV9A+EPF1n4zsIPDmvSW1tfahBNa+Wvyqt6kjSIgGePNjnlAH9+LaOoFZTV1Znfg8R7KcZLp+XU+jvAFofHfgTwxqeu6Nq1rJBZRkfaWUJOXjXfMhAO5JQFcrn73JAPJ9s0zT4NG02zsrUw21jCuxRLJ8xYnPU9SSSSepJr42+D/7TVl8M4H+HHxH0+4ksdKfyrPUbRQ01vCTkI8ZxvjUk4ZTuUcEEYx9M6Z8Xvg941SGKx8ZeHbqYAOlveukMyhh2jnAPI9B0rwK1Oak77Hv168nFU1sr+nqdzqkMOqaHPbAR3NtcI0UiH5kkXlWUjuOoNeR+NPDPiG08OXB8J6VpcOoSRtD/aMqLGLGIqQ8gwCzMFJwBgZ5J7HqdW+LPws8DaVFZ3vi7RbSOIeXDZW04nlxnhEij3MeuAAK+ffj7+0ZryaVZ+G/DGhTaXa6xHIXvr/AuPKXAb90P9XkHjcSfYGs6cJSkkjTBupBWS0Z5D4SlGheEtUv2m83U9XuP7Ps5SMN5QPb0HIJ98V5tqt8L3x5cENmF712jIP3wuFz+SirEerX91fRzJMIktoGW1AUkRFgQr44GBlm65Y7T0rl4LZFku5JbmZ5bWFpYpxhdpUgAHrkEnGPevdp6pRMMTWhTxE6t7/P7/w+V7m5418WrNr2nW2juDFpMhmEn8MlwSCzD1C7VUeu0nvXDyyyTzvNM7PI7FmZjksSckmtLR9Tms9eE4SKRJiY5oZEDJIjdVKkHjv6jGRUusaXbLCNQ0nL2v3ZkDbvJfPTnnaeME/Q9q6nJuVmfNTScee+t9v1MWiiimYhXqfxTkfxN8KPB3jcrGZirWN3K6KkssuOvyjGzdFMQMjG8YAyceWV6lp3+l/sja/9q/f/AGTU0+zeb83kZaDOzP3f9Y/T++3qa5sRo4S7P89D6LIm6tHF4V/DKm5fOFpJ/g18zyGiipLe3nu7uK1tYJJ55nEccUSlmdicBVA5JJOABWp86R1f0TWL7w94m07X9LdEvtOuory3eSNZFWSNw6kqwIYZUcEYPemjSNWL3qDS70tYZN2BA2bbDbT5nHyYPHOOeKpUAe8Xf7WfxEXwpqOi+GfDngfwc+pRmK91Hw1oy2d1cAgg7n3EA4J+YAEZ4INeD0VZutPu7O1sri5i2RXsJuLdtwO9BI8ZPB4+eNxg4PGehFJK2wXK1FdC3gTxpFdWdvc+FdXtGvbiO0t2u7V7dJJXOEQO4Cgk+prnqdgCiiigAooqVra4WzS7aCUW8jtGkxU7GZQpZQehIDqSO24eooAiooq6+j6tHPDC+l3qyz2/2uJGgYNJDtLeYoxym1WO4cYBPagClRWjD4f1640V9Yt9E1GXTkzvvI7Z2hXHXLgYH51Vjsb2awnvobOeS1tyqzTpGSkRbO0M3QE4OM9cGgCCvXdR/aN8d3PwMh+E2kad4c8OeHvs0dtef2JYfZ59RCIql7hyx3O+wF2UKWOc8EivMf7D1o31nZDSL/7TexrLawfZ333CN91o1xlgcHBGc4qey8K+J9StJ7rTvDmrXkFu5jmlt7OSRYnAyVYgEAgEZB9aLXC5k0Vr23hTxTeaKdYtPDWr3GnBWc3kVnI8IVc7jvC7cDByc8YNUxpWqF3Qabd7o4BdOPJbKwkBhIeOEIZTu6YI9aAKlFFFABRRRQAUUUUAFFFFABRRRQAUUUUAdn8bP+S6a5/27/8ApPHRR8bP+S6a5/27/wDpPHRXPR/hx9Eexn//ACM8T/18n/6Uw+Cf/JdND/7eP/SeSuMrs/gn/wAl00P/ALeP/SeSuMqofxJei/UVf/kWUf8Ar5U/9JpHr2s/8mjeFv8AsJyf+h3NeW16lrP/ACaN4W/7Ccn/AKHc15bTw20vV/mdXEf8TD/9eaX/AKSgooorpPngoorQ0Sxk1LXLe0ijEju4Cxn+I9h9Cf0zSbSV2VCEpyUIq7ZtaJpdxEg+zIRfSruaX/n2jI7ejsO/8IPqeKUthI81z5IYR2uMeWSOQ3bvngn8q9WsP+EasZF0KPVbefUMkyqmXaWT+LoME+3aua0SfRNLgkg163uHlknaTy0ZQr5JxufeMAADgcnJ5Xv56ryqSdkfZ1sqw2CoQjUmm3fmtrZ2ty6eb/A4+9bxN8RNTiudeFvI+nqsM+sy/u2nj6qsm0fvJCM4IG48luATWrcJZ601wlzDDa3EHEEUmPlXAVIyO4wAAR6Z5yRVvXdYhitXS1gjtkhTZb28eSqBuuPUk/MT3P0pLuxa7sLW3dirOxLOpwQI0HPv88g/Krk7I8WhTV3bWy18+y++3n1PXNN0Pwx8IPhfpHi22W1vta120We2nn8tmjxlZGUDlEVjswcEsuM9ceWavrFzrni10meXVdQkPOwGYH6KvLfThR7VBHo11f3dpFdXtzLbwyJGqNIWVAXzgf3QSWP1J9c10/g7Wl8MeGtX1LTJBb6rqCPMZlhO4RlmAAl6KQ2Tt/i+UDJrOlSSk3J3Z14jFVPq6UFyxvb17/p6/dblJJtVu3a0i0sDD7Ge7ZcFun3R6HisnT1ki1W7tNUtY4FeOSK4jA+VRtJ3j/dIDD/69dPBOjpIoG4iQwoM8ttAySfzyaz/ABHp95cK9xP5KGRAQQwVm2Y3ZGd2CuT06qK2hLlmuxg8KqmGlKKbmmvSz79jjLNW+0h1+8OF/wB48D8uv4VuaetxEsjW0YkZF2TRsMiZOVIb64zn1Na/hzw6pl+1SgPt+VRj5c98Vr6BpTL4u1SzAzsAbHoGwR/M1FXEJNtdD0cBkEkqarL421+Df5o841K1S2u8wEtBIN8ZPXHofcHIP0qnXoHjbwu2mxefGn7mZi6YH3JAMsPoyjP1WvP66qNVVI8yPncywFTAYiVCpuvy6BXqnwt/5Jj8SP8AsF/+0rivK69U+Fv/ACTH4kf9gv8A9pXFRi/4T+X5o9ThX/kZQ/w1P/Tcjx+t7wRcQWnxO8OXV1PHBBDqltJJLKwVUUSqSzE8AADJJrBorQ+dPU7Txjol9pGr20pktri+sGbVJZGVRdSxmOOMRc5ZivmOc8lnbjAzU2o/8If/AGtbf2t/wjX9n/25F9h/svZn+z8Pv+0eV8+P9R/rP3n368moquYnlPUT/Yn9qaT/AGx/win9tbL7/jz8j7D/AKpfsnneV+6z5nmde2zfxmsH4g3Ec/8AwjcQn0mS4g0kx3K6U0Zhjl+13DFQI/lBwwJC8fNkcEVxlFFx2PaNZn09fjrpuvLa+EbbT/8AhJoLg6tZa0s00sfn53yR/aXCLj5ifLXGB0HB5uzOhjxhpMul2WjXWj/ZpBDDd3FrBNG+zDNcG4OxpFYhgGyjAYUDkDzuijmFynrcNlbLB4pudMuPCd/dpf6akN3f2tnDboHguGkjQf6gEbQDtO1thYZbbVbWtQ8DJ4u8OabaW2kf8I68ryX81vAplK/b7jarSYMiqIxHgcMUK5z8teZLc3C2clos8q28jrI8IYhGZQwViOhIDuAe24+pqKjmDlPW72fRW8XaQU8L+Hl2pcgyrrelSRyAoAjMqxxwqUJ3KJVy+SDnHHO+O49Gi0q2Wwv9Lvbw6lctNLZW9vARGba0KqVg+Tar+coK/KWDkdTXDUUOQJFq48/+zrPzPsvlbX8vyvL8zG458zb82c9N/OOnFet2uv6JqNzFbX2rWUUuk+HFNlO8yhX36UIZbXOfviUqwXsRIOprxqiknYbVz1R00XWtbtNbutfWDRE0uG3jS11eK0uNPdIFV08h1Z5AXV+EX5t+d3UU3w9eeErTwjYeFL/xBNDJq0EzXoigjktllm2iAyzGUFPKMUTkbDt3MO5x5bRT5hcp7DF400az8Q6FFNKst9ZWunW1pfRSo0NuklvbpcrI+7jaEkAA6GRycY5d4a1GxXTredE8NXT2vie6u2l1HVFtpLaMrBtmiXzk352t/DIPl6dj45RRzBynqet/YNQ8C6cNNtvDGrrb214hvdQ1Zba8hzd3DqVg+0R5YqyuAY2yWxyOKZ4q1TS9a8HWmkaTqdpZ3dppdjLdp5yhNS2WsQ2l88SREMPKJwecDfkN5fRRzByhRRRUlBRRRQAUUUUAFFFFABRRRQAUUUUAdn8bP+S6a5/27/8ApPHRR8bP+S6a5/27/wDpPHRXPR/hx9Eexn//ACM8T/18n/6Uw+Cf/JdND/7eP/SeSuMrs/gn/wAl00P/ALeP/SeSuMqofxJei/UVf/kWUf8Ar5U/9JpHruhf6X+yPr32r9/9k1Rfs3m/N5GWgzsz93/WP0/vt6mvLq9P+Bx/tNvFfhH/AFX9q6Wf9K+95W3Mf3ON3+vz1H3cd+PNJ4Jra5ktrmGSGaJikkcilWRgcEEHkEHtToaTnHzv9515wnWweDxS25HB+sJP81Jfld20jooorpPnQq3ZX8+n+bJasUmdDGJB95AeuPQkZGfc1UopNJqzKhNwfNF6naeH4NPtPDJuVONRuFc+cThkiBK7I+wLYbcx5C8DqasTXdtaJFbwWEEl3KikLtDBCRk7ieoFek+DP2Z/iX4s+EEHiuA6dafumudNsZ3Zbm6iPzA8DagbkruOSDngEGvPbT4e/EfxH4xOh6Z4V1SfV4oXZrZYjGY0XqxZsKADgZzySAM5rhlOLm7S2Pap1pRw8YqnZ9+//BOi8MfBD4m/FO0F94X8PW09tbyBHvmdbS3JBGUDNw5HfaDjvjpVrxl8PvFXw08bWWjeNIYLeSS1ea2ntJfOhnUviQRvt5ZcAMCAR9CCfs7wp8R9B8PfDqw8LalomoeDJbC3gtP7OuYh9oWN4sCWFYy2/a/LYyepNfM37SnxL/4S200zTVtWsZ4b43q288DLPFJ5PlzOrdER3CsEySfvEKMZ5IV5VJcttDpjTlh26ttNL366p/oeWXM72USSBkQwYlCyEAliOcY69uOcUlmIJfDUaSwqDFbKUIlcjcygbgNxUH1OPasux1JJnWTUV2BFYFFwuQQcbckDrioWmlTT4fmWTyl5RcHryxFdSg+5M8wptOMYXWtr2e6S7aWt07eeieHbjdbxmbmVp5I8egGSfzP9K6zV4dHuNL0jU0utNja3U/2jZ3lwPMuHSU5KJy7B4ivQAAg9K4LRJ92vOFP7vLzL/wACAFddp2op9omCwpPESscqMrHcc8bSnzAg9xnqQQat6amWDk5pU77u3y26tL72cdHrmpeH/Ekq2t5PPbQzELFcbgJEzxlTypIwfUZrrrjxlZ6LfaprWnrHcXN9HbpbxydEAj3MzAehIGO5+lcv4shjuLiTU4xFGyzfZpIoiSqgLmPBIBJCjacgHK5xzgcxWkqEKtpE0c3xmA5qKlqnpfWzs1p8n9+p6Rp/j2TxJZT6D4kjtw9wP9Fuo12BJRyoYdME8ZHTPPt51MhjuHjKlSrEYPUUwEg5FOkkeWRpJGLMxySe59aunRVNvl2ZyY3Mq2OjF4h80o6X6tdn6fqNr1Pw/wD6L+yn4tvLb9zcyXyQPNH8rvHugGwsOSuHcY6fM3qa8sr1T4jwzeHfgP4L8K3MMhmnd76R5FMbQsAWMRQ85BucZyPudOeIxLvyx7v8tT0cgTpwxWKe0KclfznaC/Nv5dNzx+iiitT50KKvQ6enlLJeXBhDDKoib3IPQkZAAP1z0OMHNSfYtN/5/rr/AMBl/wDjlVysV0ZtFaX2LTf+f66/8Bl/+OUfYtN/5/rr/wABl/8AjlHKwujNorS+xab/AM/11/4DL/8AHKPsWm/8/wBdf+Ay/wDxyjlYXRm0VpfYtN/5/rr/AMBl/wDjlH2LTf8An+uv/AZf/jlHKwujNorS+xab/wA/11/4DL/8co+xab/z/XX/AIDL/wDHKOVhdGbRWl9i03/n+uv/AAGX/wCOUfYtN/5/rr/wGX/45RysLozaK0vsWm/8/wBdf+Ay/wDxyj7Fpv8Az/XX/gMv/wAco5WF0ZtFaX2LTf8An+uv/AZf/jlH2LTf+f66/wDAZf8A45RysLozaK0vsWm/8/11/wCAy/8Axyj7Fpv/AD/XX/gMv/xyjlYXRm0VpfYtN/5/rr/wGX/45R9i03/n+uv/AAGX/wCOUcrC6M2itL7Fpv8Az/XX/gMv/wAco+xab/z/AF1/4DL/APHKOVhdGbRWl9i03/n+uv8AwGX/AOOUfYtN/wCf66/8Bl/+OUcrC6M2itL7Fpv/AD/XX/gMv/xyj7Fpv/P9df8AgMv/AMco5WF0ZtFaRsLFhiPUJQ3YzQbV/EqzH9DVCaGSCZopV2uvUdfoQe47570mmgTGUUUUhnZ/Gz/kumuf9u//AKTx0UfGz/kumuf9u/8A6Tx0Vz0f4cfRHsZ//wAjPE/9fJ/+lMPgn/yXTQ/+3j/0nkrjK7P4J/8AJdND/wC3j/0nkrjKqH8SXov1FX/5FlH/AK+VP/SaRveC/EX/AAinj3TNfMXmx20v71Au4mNlKPtGR821mxk4zjPFdd8Y/DkmhfE26u47fy7PUv8AS4WG4guf9aCT/Fvy2ATgOvTOK8zr2zSB/wALL/Z8k0sR+br3hnHkbUy0kIU7VGE/iRWQKDktEhY80qj9nNVOmz/Q78oj9fwVbLftr95DzcV70fnHVf4Tx+iiius+ZCvb/wBmf4JyfFr4k/a9Xt5P+EW0dlm1B+VFwx5S2U+rYJYjogbuRXlHhrwxrXi3xbpvhvQ7J7nUNRmENvHjAYnqSeygAknoACT0r9Tfhf4H0T4XfC/TvCGjlZFtlMlzdYwbq4bHmSn6kAAdlVR2rjxuJ9jCy3Z14TDutLyR18Npa6fF5rERxQrkKnyoiqOgA4wAMAdsV598O7Vb6XXfElvHmO8v3toDn7sUJOQPT948ufdfas747fFSw+Hnwo1K9eVXvpojDa24PzSyNwiAdeT+gY9q7r4eaA3hL4T+HvDtwxlurKwjS5kPWSdhvmY/WR3NeBa0Wz6FzdNJdX+X/D/kakkGmwW9vcaxHZmYusMbugPzOcBFzzyeKp+LfA3hLx54Ul8PeKNDtNRsH5EbrtaJuzxuPmRh/eUg/UcVxXxe1wWj+F7CK5EVxNqgmQbsE+XFIwx69M/hXV+GvFMOs6YspZUuUwJox2PqPY0leNmip4eUqXtHsfDHxq/Z28QfCe6fXNEgOv8AhNnwLh4gbiyJPCTAdR2EijBPBCnGfHYtatbzS7i0jxA0gV4WAHEi8qMjsQSPxr9S/GqWerfDXxBYXgVoZdNuFbPQfu2IP4EA/hX5h+J9AsrTxDnzVgW8VJEfoIZWz8rDspYEHuDj1r0qGIdRcsxYTAySdam1o+Vp7NSTXy7X7tbHIwXZg1KWdF8t549uBxtOcnj15robC5+w6KbjuW3oPU9F/lXN3VvONVWG8jEV0sjK4/uk/wD663GgeeSOIkJBGMDHU137o8ROVGo4rRp+jLBEWspcxXkmZ711eOXdgJMN20t7MW2+3XtXHSRvFM0UiMjqSrKwwQR1Bruk1nTbfw/e6b9n84Iu5NvRSc5ye/IB475rC1mD7d4lk8zcsxjj87y0L5l8td/A985981pRm7NNbHVm9KNSVPEQld1Fdrs9nv3epgUVYks54bdZZAq7jtCbhu/756iq/Q4rZNPY8WUXHdHSeA/Dknin4gadpX2fzrbzRLdA7gohU5fLLyuR8oPHLKMjNXPjD4i/4SH4r3+yLy4tO/4l0eVwzeWzbieTn52fB4+XbxnNdj4XH/Ct/gfqHjaePy9Z1fFtp29PmjU52sMocZw0uDlXCR9zXiVcsX7Sq5dFov1PpMcv7PyylhP+XlW1SXlHaC/OXldBVzS40k1RPMUOqK8u1hkMUQsAR3BI59qp1e0j/kJn/rhN/wCimrojufMPYezM7s7sWZjksTkk+tJRVrTNOu9Y1uz0nT4jNd3k6W8EY6u7sFUfiSK1EVaK9i8f/Cu00vxN4bgtdNvfC2mXt2+jT3msxSxK8sLgG8/e4wkqOjgZCghwCAOM66+GFjapJavqNzYxPqem2g1DXLAWbIlwt3udClzJE0X+jj5iTkjAZArbwDy6ivVoPh/4Q0ubxXb+IrvxPDFZaHDf2t1No8SSKzX0EJkjjW8KSrh9gO/B3ueDGoahr/wst/D/AIFfWLrxdpX9qR2sF2+lm6tN7LMEIRFW4MxkCyBiGhUYViGPGQLnnFFd742+H2meF4tc/svxNLq0uh6yNGv1ksPswEjecUaM+Y24f6PIGyFwcY3A5q7oPhDQdc+BTXEVqy+KpdRvWs5xK2J4ra3tpHttmdu4rNK6kDcTGF53CgLnmtFe0Xnwc07V/HXiew0q/k0ZLfWLuw0u3uPs/wBnmEXIQSTXSzOwyAQkUhGVJJzgctpfw70y90S3e88TyWurXOjXmuQWKWBkjMMEczhGl8wYd/IbjaQFOck/KQVzgKK9C1b4YjT/AIYHxXDq8n2mCG2nu9MvEtopY0m2hWVI7mSXbl1wZIo8hgfatX4UfDM+MfD2o31x4b1TVVu5xo9jPZxSsljcPGz/AGmUpwERvJUh/l2ysf4cgHc8oorqvFeh2mj+FPCM8dm1ve3thcS325my0qX1xCMgnCkLGi4GOnrk102p+A2bwPo1joXhmC71d7aO41K6W9b7RZSSbpEE6FvKSBoDGwbAwSQzggrQB5fRXe/C3RfDGs3/AIhXxXBus7fSd8c/mun2SWS7t4BP8pG7YJmbacg45FdPe/C7SotJ8J+FZIvsPie616PSdWv9zSiJ5lR1QR7gp8tZEzjBLbgT0wCueN0V6D4H8L2stjba/e+TdRXlp4htxaTQBlje10rzklBJOTunUjgbTGCDk8afiPwV4SjfU08NXVw8tr4Y03UpYtQtfJSOSf8As8b45RckbnN07NvXYmWVQfldAZ5XRXq/hHwloOmeF/E934uTwfPdWV1YQwXGo6hdXdmizLcsyh9Ldiznyk6kgbTnBPJp3hHwZceE73WNelkso5PDh1W3fSLOSfyW/to2m7bNcrvOwBADtGx8kb03SArnlFFdfe+Bvsba4Bqm8aXodjrWfIx5v2k2n7r73y7ftn3uc+X0G7it488NaV4Q8bah4a07XJ9Wm066mtLqZ7MWyB43K/J+8Yt05yBg5A3DkgzmaKKKACiiigAp9yol0TzG+9BMqKf9lwxIPsCuR/vN60ypJf8AkX5/+viL/wBBkpPYDLooorIo7P42f8l01z/t3/8ASeOij42f8l01z/t3/wDSeOiuej/Dj6I9jP8A/kZ4n/r5P/0ph8E/+S6aH/28f+k8lcZXZ/BP/kumh/8Abx/6TyVxlVD+JL0X6ir/APIso/8AXyp/6TSCuh8E+JdS8KeNrPV9Mge6kBMT2isw+0I3BT5ep6EcHDBTg4xXPV33wo8ZXHg3xXNdWthZXj3EYieK5hVy8ecsisfu546dcYPHFaSSaaex5+FrVKNaFWi7STTT8+hqfFLwba6XeJ4r8P8A2f8AsHUZAqRRAxm2mK5MZRuRnDHGBtOVIXAzxmi6fHd6gsl46RWcWXlklDbCB/DlR1JwPx7V7X4y06Wbwlf+Mvh7cTN4XuG36hpcI2vpUowdrx8jyweVdfu8Z4wa8xt7S51WYi1a9vQpLssXJ6cnA6e5xUQm4R5XqejjnSxeJdWjDk5tXFbX627LrbpsdOPEd3pmt6TceH765sW08LPbTwTnbHtOSqYIAyMgg9QTndmvrfxF+0p4L0v4VReNEu2VLkMkdowBn84dYQmeWGRk/dAIJOCM/CoL6ez2qWz/ALwjA9T0wePXBwP6Vx/iK7jutQjtopBO8OVadWyrknoPYdM9/piuWth41Em+hp9flSk5OKu/kl2svT+u/uPgvxL4j/aF/a+8InxMHXR49Q+2JZ5zFHDD+9cZP32bywpPfIAAGBX6Qz6osMUks77MAs5PGO5r8up1sdK8Orp8lo8d3aymKPySWjVAxORIp5+Yk9M9TntXo1t+0D4+sPhXF4QSKC6EFs0Ka1LLI8qLyVkfqCVBAGT/AAr6VhWwznZR6HRStBuVWXM2k21rby9fwPdfGOt2vivxLf69qE4g0rT0aK0uGOPJKnLzgnpgqFB77X6g1D8OviBD4k0GPXdIn8q5hcw3MWMFHHqv91hhh7HHUGvi4eL9XufDUGg3Wp3Zs4MmOGWd2hznPKeuefT2FWfBvjbVvBfiSTVNN1AxvMhjmQp5sco7B0yM4OCCCCD7E1UsBLlt1O6nnGH91J6PfyPuP4rfFS0sPhHqGntiDVNTj+xW6Fso2SN7dc7Quc/UDPIr438Qapb6ub1r9Wlu+EEjSZ3He7Phu/8ACBnnk4rL8SeK9b8U376nfXkt9Ow2iYgARr/dRF4Qe348mufM05h8p+FAxk8VthsPKlGze5x5lisM+VUldp6u+lu3bzv8h17JJfiO/uBuuIiI5ueWG3GSfXofqTTPtNwcWllJLJuO0h/l2exJ7+1JFd28Ftdq3zvJGFQDpuz1P0GfxxXU/Crw3H8QPi1ovhO/1ZdNivbjDXhC5QBWYgA8Fm4Az+R6V0uPJFvojzsRWWJqRl9qW/re346GD9kurGGNZFgffKGGGOcryBnHfFXraw1W1uftMSrMxGWPPzg855/Ovv8A0XwH8CvCF9qHhGLwZbtqVpZtcS6jrNqlw1xtBIAllDA7scBQBjI4IxXy3+034d+HfhvW9LuPh5YW+iyybhdWtrcP8+RuDhCflC/d4wOnpXJSxKqS5I6XOuVJQhzV4uSS0s7WX3a7nm4kt7qQR3cJim6qehB9mFRaL4X0m98c2UGs6hHa2Bkae5munIWVAdxTIxtJwQSSMA57YrP8Px67rMV2Uj8+1s4TNNcykKIP7vzdyxGAvU89gSLV5c7kS6ZlKgqiDH3ju5PuMZH4munW/LfUwioUXCuo81N62l1s9vPtdea6MofEjxgvi3xZ/oMccGj6eptNPgh3KnlKeHCnAUsAOABgBQc7c1x1SXAjF1KIs+WHIXPpnio61hFQSijz8Zi6uLryr1neUnd/12WyCr2kf8hM/wDXCb/0U1UafDLJBcRzxNtkjYOpxnBByKtOzOZl2rukavqGhazBq2lXH2e8gJMUuxWKEgjIDAjOCcHqDgjBANV4xBdrvglhhf8Aihlk2bfdWbgj2zn64yX/AGOT/nvZ/wDgXF/8VWpJd0zxJq2kWL2NnLbvavcxXjW91axXMbSxh1RikqsDgSOCMYOeQcDGpdfETxXehI7m6097aOWGVLL+zLUWqtD53lgQCPywoNzOSu3DFySCcEc99jk/572f/gXF/wDFUfY5P+e9n/4Fxf8AxVAtDoR8RfFY1n+0vtVhuFobD7L/AGZa/ZPIMnmeX9m8vydvmfPjZ97nrzVa98aeINS8OJomoS2F1bpGkKTTadbPdJGhGxFuTH5yqAAAA+Nvy9OKx/scn/Pez/8AAuL/AOKo+xyf897P/wAC4v8A4qgNC/qPijXdWOrnUL7zv7Yv11O+/dIvnXC+bh+ANv8Ar5eFwPm6cDCWPibXdMttNgsNQeBNNvm1K02KuYrhhGC4OMniGPg5Hy9OTmj9jk/572f/AIFxf/FUfY5P+e9n/wCBcX/xVAaHWQfFjx7bajc38WtQm6uLyW/ad7C3d0mlx5jRs0ZMYfADKm1SBgir2ifFB9E+G8/hyLTrm4vZLO50+O7uJ4WjggnDB0RRB5wGHc7fOKbju25rhfscn/Pez/8AAuL/AOKo+xyf897P/wAC4v8A4qgNDfvfiD4t1DwzLoF3qUL2M0MMEwWzgSSdIivlCSVUDuV2KAWYkAYzgkVjzazqdxpWn6bJdH7Lp5ka1jRQvls7BmbIAJJIHJycADoBUH2OT/nvZ/8AgXF/8VR9jk/572f/AIFxf/FUBoaPiHxVr3iu7iudevVupYvN2MIY4seZM8z8IoBzJK7f8C9MCta2+J/jazsI7SDVYNqW4szI9hbvLJbhdogklaMvJFtAHluSuABjgVzH2OT/AJ72f/gXF/8AFUfY5P8AnvZ/+BcX/wAVQGhLY6tf6da6hb2U/lRahb/ZLpdinzIvMSXbyOPniQ5GDxjoSKnsvEet6dZWlpY3728VpejUbfy1UNHcAKBIGxnI2rxnHFU/scn/AD3s/wDwLi/+Ko+xyf8APez/APAuL/4qgLo6K9+I3i+/Nv5+o26LbpdpDHbWNvBHGLuEQ3GEjjC/OgweODlhhiTVa58b+JLvRf7KnvLdrc2K6a7LZwLLJbq8TpG8oQO4U28O3cxKhcDAJBxvscn/AD3s/wDwLi/+Ko+xyf8APez/APAuL/4qgNCWHVtQt9Au9FhuNtjeTRXE8OxTveIOIznGRgSycA4O7nOBjT03xt4k0r7KtreW7R21k2nRwXNnBcRG3adrgxvHIjLIPNYv8wJBxjoMY/2OT/nvZ/8AgXF/8VR9jk/572f/AIFxf/FUBobs/j/xZc+FpfD02oxNYTWsVlKotIRJLDE6PGjyhN7BDGm3LHaBtGASDjatql/rmv32tapP599fXEl1czbVXzJHYszYUADJJOAAKj+xyf8APez/APAuL/4qj7HJ/wA97P8A8C4v/iqA0K9FWPscn/Pez/8AAuL/AOKo+xyf897P/wAC4v8A4qgLleirH2OT/nvZ/wDgXF/8VR9jk/572f8A4Fxf/FUBcr1JL/yL8/8A18Rf+gyVIbXYN0t3Zog6sJ1fH4IST+AqjeXSzBIYQRBGSV3feYnGWPpnA46DA68kqTsh7lWiiisijs/jZ/yXTXP+3f8A9J46KPjZ/wAl01z/ALd//SeOiuej/Dj6I9jP/wDkZ4n/AK+T/wDSmHwT/wCS6aH/ANvH/pPJXGV2fwT/AOS6aH/28f8ApPJXGVUP4kvRfqKv/wAiyj/18qf+k0gpVZkcOjFWU5BHUGkorY8g7rw58RdV0rVoblJxbTABZJowQs46fvFzg/XHc5Bya7UadZ+JZJf+Ea1RPD7zMZJLO2iHlmQnIPykMEz0AyB2A6V4hWhp+tajpkiPaXLpsOVGT8p9vSp5Va1jrpYucanPKT13to38zqvFVz4m8OabfWut3d0JZU8mNi+5Zy3G5WxyAoPPBHAOK5LQtCEWzUNQQZ2+ZDA6Bwf9qRSR8vtjnPYdfX9OXxD4x8K2XiSSGx1G4hMiR2sbZlhC43SLE3DSHHVSWCgYAzmuV1C7tpoywt2mlB3+WqPuY/TGc/rWLjZ7HZWkq0ud1HJLa+/5/kZkEUtzE0hkliB+6IiyiQ+uD0HPPT+tWr6W8g0C8gmv5UldFLWcWQiLuAzJnHzHIwoHAPJ7V0Wk6T4i+z3dzDYSaUzKqxXd3GYzFF1ZwpGRgDAwBjJOR1rL8QQ+EdO8O3UdprFxqeqz4UFzkL84JY7eM4HcnrTjFtq5suWnRc4PVp9bK23fV+XRPqcJRRRXWeEKrMpypIPqKVnZvvMT9Tmm0UAFbtl4cuvsaaje3cenxld8CtkzS9wUjHOM4wxwPes/TJrW1vBdXUYlEfKxEZDN2yPQV2Gl6H4u8b6glxYeHmkjn/5frsMsAUNtJ3HCtg9Qu5uDwcVjVm4+S7nqZfgliHZJym9opNv1dl/l6ohk8Y/EW7sobK68ZaisUMTwKJL47vLYgshIO4jgcE8VmXFkL27urm+v7m8nlGVllZ5JCeOWODu9OtegN4a+Gvw5kW58a6mutayu1/7JsVykbfu2wUzzjJI8xlDKT8pIrzrxf4+1TxZPHELa20rTYFKQWFiuxAueN5H3yAFHQAbeFGTnCE+Z/u1p32PQx2WrA02sbWXtekE+Zr/E9o+mr8jWfVpLXSF0y2MsGmqzMsEkixIzHA3P03tgAZI+gArnNR1eIs/kyedMwwHUEJGP9nPU+9YJJJyTRWqppHkVcY6lu/m729NkvuCiiitDiCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigDs/jZ/yXTXP+3f/wBJ46KPjZ/yXTXP+3f/ANJ46K56P8OPoj2M/wD+Rnif+vk//SmHwT/5Lpof/bx/6TyVxldn8E/+S6aH/wBvH/pPJXGVUP4kvRfqKv8A8iyj/wBfKn/pNIKKKK2PICiiigDR0nXtY0O4M2k6jPaMevltwfqDwa6t/jH8Q3sWtW8QS7WXaXCKGx9RXB0UDu0dh4d+J3i/w3qkt7a363QmOZYLxPMR+Dj0ZeTn5SMkDOcYrr5Pin4F8TSA+N/h8jTFFeS90+QebLKqhefuMExngu2MKOcZHkFFZTowk+Z79z18Hn2NwtL6vGSlT/lklKP3STt8rHr39nfAS7H2r/hKddsfN/efZPKY+RnnZnyWzt6febp1PWnf8Kt8F/8ARX9B/wDIX/x+vH6Kn2U18M3+D/Q6f7awtT+Pgqb/AMLnH77S1/Q9g/4Vb4L/AOiv6D/5C/8Aj9J/wj/wMtT9mvPHmqy3MX7uWS3iYxu44YpiFhtJzjDNx3PWvIKKPZze83+H+Qf2zg6etHAwT/vOcvzloewQ/Ef4X+HbmO58K/DqS4mLB2k1GUBoWU5QxljKQck5I29B17c34i+MPjrxD5af2n/ZUSYPl6Xug3MM8l9xc8N03beAcZGa4OimsPBO7V356mdfiPH1afsYTVOH8sEoL/yVJv5thRRRWx4QUUUUAFFFFABWv4VWyfxxpCajCstq15EsiMQFILAfNkEFfUdxkcZzWRRQgZ6/ommiz8UaolvBfabBFrll/ocuwrIDM+GH7sELjlQDjB6tVa18OaLa/FWx8+1k1O2v/tTfaZGQ27y7XPlhCp5U/LhiDuwcDGD5TRWnP5EcnmegaP4I0zUoVkuIdVtmku3t5YzImdNVVBDz5QZyfZPrmrt9oNpqHwr0e582a7uLKznMVrasFZ189synIOUXHIAzyOg5rzKilzLsPlfc7HT/AAW6Qaqmq2N/dalYSRx/2Vp8qeaQ4zvyFfKgY6A9e1WbTwXpdx4XTUHnvFL2c1y93vXyLaRCQIHG3JY49QeeAa4Wilddgs+56NL4O8K2ujTXU/8AbEkltp9peybLiNVczEKVUGM4AJzk5qvfeFdO0fXDoMpMwvNWW3ilcDzBCgBbBxwWaRVz6oa4GpGuJ2SJGnkKwjEYLHCDOfl9OSTx3NPmXYOV9z0y70jTrjwZLdS6VDBEII5FnjijjSMtBJJ8rhd7FXRIyHZsknoSMZ934L0BdIk8i5v4buHTbXUJJppEaL96wDLtCAgDOc7q5K98QatqFo1vd3Ebq5BkcQRrJKR03uFDP/wImsyhyXYSiz0bWPAvhzSbywEl9qTW8t9HbSTCN9kkbD/WJIYggIP8IZ8jvS6j8PdI0vSLy5utUmElkoguBuXCXDtGY+3KbJCT3yp5FecUUcy7D5X3PX7jwlp1n4Un0INe2VnPrVvEb+8dWSZdh/eR4UAKc46ntz1rEHgPSG1XT4JZdQsWuPtObC4dDcSeUMoUO0Ab+2R9M153RQ5LsJRfc9Y1rw1aX1vpFtNaalE9novmxaXvX7VK3mn5M7OoySfkzjtVKx+Hmi3Ou6lYLc387W/leUFJRELJuZZZlikVWU8cgf0rzSijmXYOV9z0Cy+H8F14FutYlMsU0NnNdpLHP5sT+WT8pAiCrkD/AJ6E98Y6att4e0/RPAmuTRQ6hcQT6bbSSX29fJm3OrMkfy8EdOSfcDv5VRRzLsNxb6npQ+H3h9NVtLWfWJlXUJHnsWDr+8tRGGXOFJ3szbRgfwtgHgVWk8GaBa6pqAuX1Zre10o35gKtBIHDhdu6WFdy/wC0EH6V59RRzLsHK+56c/hjQ7DQPE1pb6ZeajMkVldQEOhnjjdSx2kRnAU53EDBGPu4yaFx4Cs49CutWjN81omm211DPuUo8sjAOudvIGTwORxmuAoo5l2Dlfc9GbwT4al8c6poNtPqKf2dEW2yzB5Lpvl4QJCSoGTnCuTxwOa4/wAS6XbaN4muNPs5biSGPaVNzC8MgyoOGV1U8Z64Gevesmik2n0BJrqFFFFSUFFFFABRRRQB2fxs/wCS6a5/27/+k8dFHxs/5Lprn/bv/wCk8dFc9H+HH0R7Gf8A/IzxP/Xyf/pTOc8Ha+/hfx5pWvK0ipa3CtL5aqzNEflkUBuMlCw7deo61s/ELw3B4Y8cz2thJHLpd0i3unyxuHV7eTJXB3MSAQVyTk7c9xXFV2PhbxHpMtlD4U8bLcTaD5u+C6gP+kaa7H5mjJBzG38aYP8AeA3Dlu8Zc6JwlSnWoPBVXbW8ZPZO1mn2Ula76OKvpdrmqK7+X4U6pqMgm8EavpniqzKK5e1uI4ZYQygjzYnYFCTuAGSflOcHimf8KY+JX/Qt/wDk5b//AByq9vT/AJkN5BmV/dw8pLvFOSfo43T+TODorvP+FMfEr/oW/wDyct//AI5R/wAKY+JX/Qt/+Tlv/wDHKPb0/wCZfeL+wMz/AOgWp/4BL/I4Oiu8/wCFMfEr/oW//Jy3/wDjlH/CmPiV/wBC3/5OW/8A8co9vT/mX3h/YGZ/9AtT/wAAl/kcHRXef8KY+JX/AELf/k5b/wDxyj/hTHxK/wChb/8AJy3/APjlHt6f8y+8P7AzP/oFqf8AgEv8jg6K7z/hTHxK/wChb/8AJy3/APjlH/CmPiV/0Lf/AJOW/wD8co9vT/mX3h/YGZ/9AtT/AMAl/kcHRXef8KY+JX/Qt/8Ak5b/APxyj/hTHxK/6Fv/AMnLf/45R7en/MvvD+wMz/6Ban/gEv8AI4Oiu8/4Ux8Sv+hb/wDJy3/+OUf8KY+JX/Qt/wDk5b//AByj29P+ZfeH9gZn/wBAtT/wCX+RwdFd5/wpj4lf9C3/AOTlv/8AHKP+FMfEr/oW/wDyct//AI5R7en/ADL7w/sDM/8AoFqf+AS/yODorvP+FMfEr/oW/wDyct//AI5R/wAKY+JX/Qt/+Tlv/wDHKPb0/wCZfeH9gZn/ANAtT/wCX+RwdFd5/wAKY+JX/Qt/+Tlv/wDHKP8AhTHxK/6Fv/yct/8A45R7en/MvvD+wMz/AOgWp/4BL/I4Oiu8/wCFMfEr/oW//Jy3/wDjlH/CmPiV/wBC3/5OW/8A8co9vT/mX3h/YGZ/9AtT/wAAl/kcHRXef8KY+JX/AELf/k5b/wDxyj/hTHxK/wChb/8AJy3/APjlHt6f8y+8P7AzP/oFqf8AgEv8jg6K7z/hTHxK/wChb/8AJy3/APjlH/CmPiV/0Lf/AJOW/wD8co9vT/mX3h/YGZ/9AtT/AMAl/kcHRXef8KY+JX/Qt/8Ak5b/APxyj/hTHxK/6Fv/AMnLf/45R7en/MvvD+wMz/6Ban/gEv8AI4Oiu8/4Ux8Sv+hb/wDJy3/+OUf8KY+JX/Qt/wDk5b//AByj29P+ZfeH9gZn/wBAtT/wCX+RwdFd5/wpj4lf9C3/AOTlv/8AHKP+FMfEr/oW/wDyct//AI5R7en/ADL7w/sDM/8AoFqf+AS/yODorvP+FMfEr/oW/wDyct//AI5R/wAKY+JX/Qt/+Tlv/wDHKPb0/wCZfeH9gZn/ANAtT/wCX+RwdFd5/wAKY+JX/Qt/+Tlv/wDHKP8AhTHxK/6Fv/yct/8A45R7en/MvvD+wMz/AOgWp/4BL/I4Oiu8/wCFMfEr/oW//Jy3/wDjlH/CmPiV/wBC3/5OW/8A8co9vT/mX3h/YGZ/9AtT/wAAl/kcHRXef8KY+JX/AELf/k5b/wDxyj/hTHxK/wChb/8AJy3/APjlHt6f8y+8P7AzP/oFqf8AgEv8jg6K7z/hTHxK/wChb/8AJy3/APjlH/CmPiV/0Lf/AJOW/wD8co9vT/mX3h/YGZ/9AtT/AMAl/kcHRXef8KY+JX/Qt/8Ak5b/APxyj/hTHxK/6Fv/AMnLf/45R7en/MvvD+wMz/6Ban/gEv8AI4Oiu8/4Ux8Sv+hb/wDJy3/+OUf8KY+JX/Qt/wDk5b//AByj29P+ZfeH9gZn/wBAtT/wCX+RwdFd5/wpj4lf9C3/AOTlv/8AHKP+FMfEr/oW/wDyct//AI5R7en/ADL7w/sDM/8AoFqf+AS/yODorvP+FMfEr/oW/wDyct//AI5R/wAKY+JX/Qt/+Tlv/wDHKPb0/wCZfeH9gZn/ANAtT/wCX+RwddT8PfDcHifxzBa38kcWl2qNe6hLI4RUt48FsncpAJIXIORuz2Na0Xwp1TTpDN431fTPCtmEZw91cRzSzBVJPlRIxLkHaCMg/MMZPFYvinxHpMVlN4U8ErcQ6D5u+e6nP+kak6n5WkIAxGv8CYH94jceJlVU1ywfzNqOXSwMliMwhZJ/A9JSfbl3UX1bS02u7IyvGOvv4o8earrzNIyXVwzReYqqyxD5Y1IXjIQKO/TqetFYdFUkkrI8qvWnXqSq1HeUm2/V6sKKKKZkFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAf//Z",
	"suka": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwMDAgQDAwMEBAQFBgoGBgUFBgwICQcKDgwPDg4MDQ0PERYTDxAVEQ0NExoTFRcYGRkZDxIbHRsYHRYYGRj/2wBDAQQEBAYFBgsGBgsYEA0QGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBj/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4Poor1PT9PT4Qxadr+v6RHeeMLlFu9O0u+jbydOh3ECecAgtMSrBIwR5eCzYYKo2lK2i3NcNhnWbbdord9v8ANvouvpdrn9A+EvxG8TWf2vSPCd89uUSRJrjbbJKrglWjMpUOCBnK56j1Gdf/AIUB8XP+hS/8n7X/AOOUujyeJvjP8U9N0TxJ4ouTJc+b5c8kYeODbCWOyFSqru8pQduMnk5Neof8Mpf9T7/5S/8A7dWNSr7N2nJJ+jZ72ByeONg6mFoTnFO1+eEdd9nF237v1PLv+FAfFz/oUv8Ayftf/jlH/CgPi5/0KX/k/a//AByvUf8AhlL/AKn3/wApf/26j/hlL/qff/KX/wDbqz+sx/nX3P8AzOz/AFYr/wDQJP8A8G0//kDy7/hQHxc/6FL/AMn7X/45R/woD4uf9Cl/5P2v/wAcr1H/AIZS/wCp9/8AKX/9uo/4ZS/6n3/yl/8A26j6zH+dfc/8w/1Yr/8AQJP/AMG0/wD5A8u/4UB8XP8AoUv/ACftf/jlH/CgPi5/0KX/AJP2v/xyvUf+GUv+p9/8pf8A9uo/4ZS/6n3/AMpf/wBuo+sx/nX3P/MP9WK//QJP/wAG0/8A5A8u/wCFAfFz/oUv/J+1/wDjlH/CgPi5/wBCl/5P2v8A8cr1H/hlL/qff/KX/wDbqP8AhlL/AKn3/wApf/26j6zH+dfc/wDMP9WK/wD0CT/8G0//AJA8u/4UB8XP+hS/8n7X/wCOUf8ACgPi5/0KX/k/a/8AxyvUf+GUv+p9/wDKX/8AbqP+GUv+p9/8pf8A9uo+sx/nX3P/ADD/AFYr/wDQJP8A8G0//kDy7/hQHxc/6FL/AMn7X/45R/woD4uf9Cl/5P2v/wAcr1H/AIZS/wCp9/8AKX/9uo/4ZS/6n3/yl/8A26j6zH+dfc/8w/1Yr/8AQJP/AMG0/wD5A8u/4UB8XP8AoUv/ACftf/jlH/CgPi5/0KX/AJP2v/xyvUf+GUv+p9/8pf8A9uo/4ZS/6n3/AMpf/wBuo+sx/nX3P/MP9WK//QJP/wAG0/8A5A8u/wCFAfFz/oUv/J+1/wDjlH/CgPi5/wBCl/5P2v8A8cr1H/hlL/qff/KX/wDbqP8AhlL/AKn3/wApf/26j6zH+dfc/wDMP9WK/wD0CT/8G0//AJA8u/4UB8XP+hS/8n7X/wCOUf8ACgPi5/0KX/k/a/8AxyvUf+GUv+p9/wDKX/8AbqP+GUv+p9/8pf8A9uo+sx/nX3P/ADD/AFYr/wDQJP8A8G0//kDy7/hQHxc/6FL/AMn7X/45R/woD4uf9Cl/5P2v/wAcr1H/AIZS/wCp9/8AKX/9uo/4ZS/6n3/yl/8A26j6zH+dfc/8w/1Yr/8AQJP/AMG0/wD5A8u/4UB8XP8AoUv/ACftf/jlH/CgPi5/0KX/AJP2v/xyvUf+GUv+p9/8pf8A9uo/4ZS/6n3/AMpf/wBuo+sx/nX3P/MP9WK//QJP/wAG0/8A5A8u/wCFAfFz/oUv/J+1/wDjlH/CgPi5/wBCl/5P2v8A8cr1H/hlL/qff/KX/wDbqP8AhlL/AKn3/wApf/26j6zH+dfc/wDMP9WK/wD0CT/8G0//AJA8u/4UB8XP+hS/8n7X/wCOUf8ACgPi5/0KX/k/a/8AxyvUf+GUv+p9/wDKX/8AbqP+GUv+p9/8pf8A9uo+sx/nX3P/ADD/AFYr/wDQJP8A8G0//kDy7/hQHxc/6FL/AMn7X/45R/woD4uf9Cl/5P2v/wAcr1H/AIZS/wCp9/8AKX/9uo/4ZS/6n3/yl/8A26j6zH+dfc/8w/1Yr/8AQJP/AMG0/wD5A8u/4UB8XP8AoUv/ACftf/jlH/CgPi5/0KX/AJP2v/xyvUf+GUv+p9/8pf8A9uo/4ZS/6n3/AMpf/wBuo+sx/nX3P/MP9WK//QJP/wAG0/8A5A8u/wCFAfFz/oUv/J+1/wDjlH/CgPi5/wBCl/5P2v8A8cr1H/hlL/qff/KX/wDbqP8AhlL/AKn3/wApf/26j6zH+dfc/wDMP9WK/wD0CT/8G0//AJA8u/4UB8XP+hS/8n7X/wCOUf8ACgPi5/0KX/k/a/8AxyvUf+GUv+p9/wDKX/8AbqP+GUv+p9/8pf8A9uo+sx/nX3P/ADD/AFYr/wDQJP8A8G0//kDy7/hQHxc/6FL/AMn7X/45R/woD4uf9Cl/5P2v/wAcr1H/AIZS/wCp9/8AKX/9uo/4ZS/6n3/yl/8A26j6zH+dfc/8w/1Yr/8AQJP/AMG0/wD5A8u/4UB8XP8AoUv/ACftf/jlH/CgPi5/0KX/AJP2v/xyvUf+GUv+p9/8pf8A9uo/4ZS/6n3/AMpf/wBuo+sx/nX3P/MP9WK//QJP/wAG0/8A5A8u/wCFAfFz/oUv/J+1/wDjlH/CgPi5/wBCl/5P2v8A8cr1H/hlL/qff/KX/wDbqP8AhlL/AKn3/wApf/26j6zH+dfc/wDMP9WK/wD0CT/8G0//AJA8u/4UB8XP+hS/8n7X/wCOUf8ACgPi5/0KX/k/a/8AxyvUf+GUv+p9/wDKX/8AbqP+GUv+p9/8pf8A9uo+sx/nX3P/ADD/AFYr/wDQJP8A8G0//kDy7/hQHxc/6FL/AMn7X/45R/woD4uf9Cl/5P2v/wAcr1H/AIZS/wCp9/8AKX/9uo/4ZS/6n3/yl/8A26j6zH+dfc/8w/1Yr/8AQJP/AMG0/wD5A8u/4UB8XP8AoUv/ACftf/jlH/CgPi5/0KX/AJP2v/xyvUf+GUv+p9/8pf8A9uo/4ZS/6n3/AMpf/wBuo+sx/nX3P/MP9WK//QJP/wAG0/8A5A8u/wCFAfFz/oUv/J+1/wDjlH/CgPi5/wBCl/5P2v8A8cr1H/hlL/qff/KX/wDbqP8AhlL/AKn3/wApf/26j6zH+dfc/wDMP9WK/wD0CT/8G0//AJA8X1/4S/EbwzZ/a9X8J3yW4R5Hmt9tykSoAWaQxFggAOctjofQ44yvXPFem+JvgP4/gsPDfjC5eS5s0u5JI4BFG+WljCvEzOr4wxBbOC3GCM1W1DT0+L0Wo6/oGkR2fjC2RrvUdLsY28nUYdwBngBJKzAsoeMk+ZkMuWLKd4zdlJ6rueJiMvhzyo0k41Y7wbUr+klZN+Vl5NvQ8sooorU8c7P4S6Bb+JvjT4e0i7MRt2ufPlSWISpKsStKY2U8EMIypz/e6Hoafi/xLd+MPHGp+Jb1dkl7MXWPIPloAFRMgDO1Aq5wCcZPJro/gB/ycV4d/wC3n/0llrgamH8R+i/U9Go3HL4JfanK/nyxhb7uZ/eWbDUdQ0rUY7/S765sruPPl3FtK0UiZBBwykEZBI+hNbf/AAsLx9/0PHiT/wAGc3/xVc3RWrinujhp4irTVoSaXkzpP+FhePv+h48Sf+DOb/4qj/hYXj7/AKHjxJ/4M5v/AIqubopckexp9cxH/Px/ezpP+FhePv8AoePEn/gzm/8AiqP+FhePv+h48Sf+DOb/AOKrm6KOSPYPrmI/5+P72dJ/wsLx9/0PHiT/AMGc3/xVH/CwvH3/AEPHiT/wZzf/ABVc3RRyR7B9cxH/AD8f3s6T/hYXj7/oePEn/gzm/wDiqP8AhYXj7/oePEn/AIM5v/iq5uijkj2D65iP+fj+9nSf8LC8ff8AQ8eJP/BnN/8AFUf8LC8ff9Dx4k/8Gc3/AMVXN0UckewfXMR/z8f3s6T/AIWF4+/6HjxJ/wCDOb/4qj/hYXj7/oePEn/gzm/+Krm6KOSPYPrmI/5+P72dJ/wsLx9/0PHiT/wZzf8AxVH/AAsLx9/0PHiT/wAGc3/xVc3RRyR7B9cxH/Px/ezpP+FhePv+h48Sf+DOb/4qj/hYXj7/AKHjxJ/4M5v/AIquboo5I9g+uYj/AJ+P72dJ/wALC8ff9Dx4k/8ABnN/8VR/wsLx9/0PHiT/AMGc3/xVc3RRyR7B9cxH/Px/ezpP+FhePv8AoePEn/gzm/8AiqP+FhePv+h48Sf+DOb/AOKrm6KOSPYPrmI/5+P72dJ/wsLx9/0PHiT/AMGc3/xVH/CwvH3/AEPHiT/wZzf/ABVc3RRyR7B9cxH/AD8f3s6T/hYXj7/oePEn/gzm/wDiqP8AhYXj7/oePEn/AIM5v/iq5uijkj2D65iP+fj+9nSf8LC8ff8AQ8eJP/BnN/8AFUf8LC8ff9Dx4k/8Gc3/AMVXN0UckewfXMR/z8f3s6T/AIWF4+/6HjxJ/wCDOb/4qj/hYXj7/oePEn/gzm/+Krm6KOSPYPrmI/5+P72dJ/wsLx9/0PHiT/wZzf8AxVH/AAsLx9/0PHiT/wAGc3/xVc3RRyR7B9cxH/Px/ezpP+FhePv+h48Sf+DOb/4qj/hYXj7/AKHjxJ/4M5v/AIquboo5I9g+uYj/AJ+P72dJ/wALC8ff9Dx4k/8ABnN/8VR/wsLx9/0PHiT/AMGc3/xVc3RRyR7B9cxH/Px/ezpP+FhePv8AoePEn/gzm/8AiqP+FhePv+h48Sf+DOb/AOKrm6KOSPYPrmI/5+P72dJ/wsLx9/0PHiT/AMGc3/xVH/CwvH3/AEPHiT/wZzf/ABVc3RRyR7B9cxH/AD8f3s6T/hYXj7/oePEn/gzm/wDiqP8AhYXj7/oePEn/AIM5v/iq5uijkj2D65iP+fj+9nSf8LC8ff8AQ8eJP/BnN/8AFUf8LC8ff9Dx4k/8Gc3/AMVXN0UckewfXMR/z8f3s6T/AIWF4+/6HjxJ/wCDOb/4qj/hYXj7/oePEn/gzm/+Krm6KOSPYPrmI/5+P72dJ/wsLx9/0PHiT/wZzf8AxVH/AAsLx9/0PHiT/wAGc3/xVc3RRyR7B9cxH/Px/ezpP+FhePv+h48Sf+DOb/4qj/hYXj7/AKHjxJ/4M5v/AIquboo5I9g+uYj/AJ+P72XdU1nV9cvFu9a1W91K4VBGs15O0zhQSQoLEnGSTj3NXvCHiW78H+ONM8S2S75LKYO0eQPMQgq6ZIONyFlzgkZyORWJRTcU1boZxr1I1FVUveTvfrdHT/FrQLfwz8afEOkWhiFutz58SRRCJIllVZRGqjgBRIFGP7vQdAVr/H//AJOK8Rf9u3/pLFRWFJ3hFvsdmaU408bWhBWSlJL72HwA/wCTivDv/bz/AOkstcDXffAD/k4rw7/28/8ApLLXA1UP4j9F+o63+4Uv8c//AEmmFFFFbHmhRRRQAUUUUAFFbfhrwh4m8Yai1l4b0a51CRP9Y0YCxx5BI3yNhUztbG4jJGBk16Zbfs76pYWkV9438Y6B4as5UAVpJfMdZiMiJtxRM4D5Ku33eMjkZzrQg7SZ6GFyrF4qPPRptx77L73ZfieMUV7efBX7PNliz1H4i65LeQgJNJbwt5TuOrJi3YbSeRhm4I5PWl/t79mzGf8AhXviP/v+/wD8lVHtr7Rf3f5nV/Yrj/Er04v/ABX/APSU/wATw+ivcP7f/Zr/AOifeIv+/wC//wAlU3/hHv2bL0/bP+Ew8Sad53737F5bN9n3c+XnyHztzjO5un3j1p+2fWL+4P7Fv8GIpv8A7et/6UkeI0V7Yf2eDq//ACJHxF8Oa/5X/H1l9nk5+5/qjLnOH67fu8Z5x5v4o8A+MfBnlt4l0G5so5MBJ8rLESd2F8xCV3fKx25zgZxinGtCTsnqc+JyjGYaPPVpvl7rVferr8Tm6Kle3mjt4p5IyscudjH+LBwf1qKtTzmmtwooooEFFFFABVnTrC71XV7TS7CLzru7mS3hj3Bd7uwVRkkAZJHJOKrV1Hw//wCRzl/7BWpf+kE9Juyua0KaqVYwezaRehj8LaRH9mj0WDX5hxNeX008cTEd4Y4mjZV5IzIWLAKdsZJWpP7R8O/9CBoH/gRf/wDyTWTXr3w38F+Hte8DWN7qOjWl5Pca29lPNNeSQyJAIA/7pFkUO4PIAVicnjuO/DYH28uSO/q/0PKzfiKGVUPrFaPu3tZRj2b+1bt1d/U83/tHw7/0IGgf+BF//wDJNH9o+Hf+hA0D/wACL/8A+Sa9O8BeCPCOq6TZ3OqaVLdBtdvLR/Mlkid4I7NpVQhWG07gD2PbpxVDxF8OtOi8O6B/wj8fnza3qzR2d2XY+ZbOqGMMucAruYNwDlTW/wDZMvZ+0W3q79P8zzFxxhvrX1SUbPu4Qt9q+vlyN7Xt87cB/aPh3/oQNA/8CL//AOSaP7R8O/8AQgaB/wCBF/8A/JNdt8TfCXh3S9JtNY8JxQLZxXMmnXXk3y3Yd15jlJV22F1DfKcY29BXPw+CPN+ENx46/tq1XybsWv2Aj52yQM5z15ztx0BOayqZc4TcLXsr7vY7sLxVQxGHp4nSKnLlScI35m7JOydr+trGT/aPh3/oQNA/8CL/AP8Akmj+0fDv/QgaB/4EX/8A8k1v+FtE0mT4feIPFN7p39rXGnSQRR2JkdI1Dk5lk2EMQMYGCOetbvhfSPA2v6bqV5q+g3Gky6IP7RuLa3llYXlsV/1XztlDvK4Yfwt3I3VVPLufl1Svru/P5dGRiuKo4f2jdNyVNqLahB6tJpW+J/FFXta73tdnB/2j4d/6EDQP/Ai//wDkmj+0fDv/AEIGgf8AgRf/APyTXrGh+DPBmt+ENDmbRbOG/wBYtNRnjhjuLrz2eJ38tYiWMQVVAB8zk4HU5rmb3RfDWn/Bjw/qxtNGTU9Rt7sySXz3pmkZJSimERHygQMffwM4znmrllTjHmbVrX3fl+OqOWlxrTq1PYxpS5ufktyQ39/X/D+7lr5etuN/tHw7/wBCBoH/AIEX/wD8k0f2j4d/6EDQP/Ai/wD/AJJr1DXPA3hq2+G8moxaLDDJH4fstQW6t7qSS4a5kID74i7BYyOd2xQOcHsKVx4Q8Ox/B3/hMl8PyjUXsEX+zPtD7YsyFPt+N+/YccKflyehWnLKZRbTeyvu9iaXHGHqRjJQes1Be7T+JpNddtfl1tpfzz+0fDv/AEIGgf8AgRf/APyTTTpOi+KJ49P0nR00fWJmEdrHbTyPbXDE4WNllLujsTgSb9mQoKqC0gy6K4HRj0PqVi5N++k16Jfiloc3W/omiW09j/a2rGb7D5jQRxW7hJJ5FClgGKsEVQ6kkg53AAfeZJfiF/yV3xV/2GLv/wBHPWrJ/wAij4a/68JP/Su4rjlN8t0cOac1CXsoveTjf0Tfyvb/AC11DzNA/wChO0j/AL/3f/x+jzNA/wChO0j/AL/3f/x+qlew/Cr4UaL4w8Lz65rd3dbTM0EUNs4XbgDLMSDzzwPbvmsOeXc+fx2Jo4Gl7atOVv8AFL/M8p8zQP8AoTtI/wC/93/8fo8zQP8AoTtI/wC/93/8frq77wRaab8cI/BNzqJNo13FF9o4DbHCsB6BsMB9avap4f0S48LeJL6LQ20WbRtQitYf3sjfald2Uowcn51ADZXAwelHPLuQ8ZR9y0pNSSafNLaTsvtX3+7qcN5mgf8AQnaR/wB/7v8A+P0eZoH/AEJ2kf8Af+7/APj9ew+Jvh54StT4ov8ASLIi20618ryGncm1uQyHdy2WVkfIzkZDegrGHhDw7/w0pc+Ff7O/4lCCQrbedJxi1Lj5t2773PX9KOeXc5qWa4erBzi56RcvieySb+1v7y/zPN/M0D/oTtI/7/3f/wAfo8zQP+hO0j/v/d//AB+vV/CvgLwvrvhnwg7Wh/tO6eS4u0MzgXduk5jcD5vlZQUPy4yA1ZNroXhm0+Hd5rF3Z6QLlNcmsUk1SS8KeUsYYIotzndnPLe/PSjnl3KWZ0XJwXO2nb4pd2v5vJ/1c8+8zQP+hO0j/v8A3f8A8fo8zQP+hO0j/v8A3f8A8fqpRRzy7nrey/vS/wDApf5lst4ekUxv4S0+NW4LwXFysij1UtKyhvQlWGeoPSue13Rk04QX1k7yafdM6wmQjzI3XaXjfGMld6fMBhgwPB3KutUuo/8AJNL/AP7Cdp/6KuaunN3sy6cpUZRababSabb3durdrb/gcZRRRXSe0d98f/8Ak4rxF/27f+ksVFHx/wD+TivEX/bt/wCksVFc9H+HH0R6ecf7/X/xy/8ASmHwA/5OK8O/9vP/AKSy1wNd98AP+TivDv8A28/+kstcDVQ/iP0X6irf7hS/xz/9JphRRRWx5oUUV3/wy+GV3481Ga+vrj+zPDVhl9Q1OQhAoA3FELcbscknhByf4VaZzUFzSOjC4Wriqqo0VeT/AK+7uzlvDnhjXvF2uLo/h3TZL68KNJ5aEKFUdWZmIVR0GSRyQOpAr2mHwJ8JvhV5dz8QtY/4STXo9r/2PZruSJv3bYZMjOMkgysquhPyEisnX/itp/h3wvB4L+EaXOl6ZFvF1qkqKLm9c5UuD1XIw2/CuPlAEYTB8irNQnV1lovx/wCAesq2Ey7SnFVav8z+Bf4V9r1enZHqviP49+LtSgXTvDUVt4Y0qOHyI7ayVWdU2BceYVG3bg7TGEKg98A157GdV8T+JoxeX893fXbqj3N3KZGOABlmY5wqj8AKzK9G0jwnqxu9M0Dwxpr6n4j1E+SIrc738xif3fYIECksTwMEk4FaKEKS91WOGtjq+NmniZuS/D5LZfJHNeNWsm8cXjaeAbUFUjI4yqqFB/EKK9c+GujR3VjF/wAJd+zump+HZRtbVraS7s7lQR9+N5Jtkv0AGexr2Dwd8C/DHwzWDWfEIbxN4ulTfDa2mPIttvUxlhnav8U7YH90evQy32ueKtSl0c6f9lv3RJGijupHxG+dvmmTswUkZwcAHGCKIvRIzrv21WVVKybvY+VvGHwgvP8AhYt9afD2CfUtBbbLaT3MqIyq4zsJYjJHrjpjPNY2o/Bj4l6Zam5n8KXckIGS1uyzY/BST+lfYHhvwtdaA5u9T0Sf7GWKTXllLvktiDg+bGQSVGB93oOcEV6JNoepRWi3GnKmr2zKG8gFUmZTyDE4wjewbGf71Vz2MnTR+Y6m+0vU0kU3FneW8gdWGY5InU5BHQqQcHNet/Dv4rfE2DU7W2mvTq2kI2yd9UUsI1LhmbzwN+/GQuS3XAU4GNr4s+JtD174m3LHSokstKd4Abi28i4mdfvGTcNyYII2kZA5wCePM5fEst+GSe+NjZK3AQF5G/3FzgcDqfzrOry1Fa1z0crrzwtZTjVcV5O1/Xp956FL4Z+HnxH1660p9fg8MatE6w6bbxRIkDoWXI8vCqzFmYBVcNkk4YCvJPGXgTxN4D1dLDxHYeT5u429xGweK4VWwWRh+B2nDAMuQMis++uvtl9JOEEascKgOdqjgD8q9J8FfFxrDQ5PB/j20k8QeFJbb7OLbapmtwMldjEqWAOAMsCuFKFduDCp1KavHVdv8jrr4rBZjUcasfZy6SW3kpL00utuqZ5FRXpvxG+FsHh7RLTxj4N1CXW/CN4ilbs4aS2Y/LiXAHBbIzgYb5GAON3mVawmpq6PFxeEq4Sp7Kqtd/Jp7NPqn3CiiiqOYK2PC2rQaJ4qtr67SR7RlktroRAGTyJo2ilKZIG8I7Fc8bsZyMiseik1dWLpzdOSnHdanZahpN3p0cNxIolsrnJtb6IEwXKjGTGxAzjIBU4ZT8rBWBAZDqup29pFawaldxQQzi6jiSZlVJQMCRQDgPgD5hzWFpPiHX9B87+w9c1LTPO2+b9iuXh8zbnG7aRnGTjPqa0v+FhePv8AoePEn/gzm/8Aiq1Vecdl+I50MLU+K68rJ/jdfkaieJfEUbs8ev6ojNM9wWW6kBMrrtZ+v3ipIJ6kHFMt9f160itIrXW9Rgjs2Z7ZIrl1EDNncUAPyk5OSOuTWd/wsLx9/wBDx4k/8Gc3/wAVR/wsLx9/0PHiT/wZzf8AxVV9aq/0/wDgGP8AZ+Btb/2xef8Ae8397LCX17Hp8thHeXC2szB5YFkISRh0LLnBIycE1Xo/4WF4+/6HjxJ/4M5v/iqP+FhePv8AoePEn/gzm/8Aiql15vp+P/ANlQw0b2k9f7q/+SLWn6nqWk3f2rS9QurGfGPNtpWibHplSDT21nV2nu5m1W9Ml4uy6czsTOvo5z8w4HBz0ql/wsLx9/0PHiT/AMGc3/xVH/CwvH3/AEPHiT/wZzf/ABVNYmola34/8AiWDwcpc7bv35V/8kasPifxJbaONJt/EOqw2AUqLSO7kWLBJJGwHGCSc8dzRB4n8S22jnSLbxDqsOnlGjNpHdyLFtbO5dgOMHJyMc5NZX/CwvH3/Q8eJP8AwZzf/FUf8LC8ff8AQ8eJP/BnN/8AFVX1ur/Tf+Rm8uwDvdbu/wAEd+/xb+ZoDXdcEnmDWdQD/ZvsW77Q+fI6eV1+5/s9Pag69rhunuTrOoGZ4Psrym4fc0OMeWTnJTHG3pWf/wALC8ff9Dx4k/8ABnN/8VR/wsLx9/0PHiT/AMGc3/xVL6zU/p/8Ar6hgf6gv/kgrU0zTEeJdY1hbi30GGULc3aDG/GCYYiRhpmB+Ve2dzYQMwy/+FhePv8AoePEn/gzm/8AiqyNU1nV9cvFu9a1W91K4VBGs15O0zhQSQoLEnGSTj3NQ6snpax0KNCD5k3LyaSXz1f3fig1nVLjXPEeoa1dpGlxfXMl1KsQIQM7FiFBJOMk4yTXT6LK2u6BZaXao0up2AeJLaNSWngLmQFByWdWeTcB/DsIBCuRxdFZSgmrHFi6TxGrfvXvfz1/zZ11dD4b8c+KfCMU8Wgaq9tFOdzxlFkUtjG4BgQD7j0rjP8AhNfGX/Q267/4Hy//ABVH/Ca+Mv8Aobdd/wDA+X/4qsfYvueXVwNWtHkqQi12bb/9tNq9vrzUdSm1C+uZJ7qZzJJM5yzMe9TX2tazqcUUepatfXiRf6tbid5An0BJxXP/APCa+Mv+ht13/wAD5f8A4qj/AITXxl/0Nuu/+B8v/wAVR7F9yvqdbT3I6bavT/yU6J9d1uRrtpNY1BmvcC6LXDk3GOnmc/NjtnNWpfGHi6YoZvFOtSGNiyF76U7SVKkjLcHDMPoSO9cn/wAJr4y/6G3Xf/A+X/4qj/hNfGX/AENuu/8AgfL/APFUexfch4Co96cfv/8AtToINa1i1e0a21a+hazDC2Mc7qYA2d2zB+XOTnHXNT2XibxJpsLxad4h1WzjkcyulvdyRhnPViARknA59q5j/hNfGX/Q267/AOB8v/xVH/Ca+Mv+ht13/wAD5f8A4qj2L7jlgast4R+//wC1NIkk5JyaKzf+E18Zf9Dbrv8A4Hy//FUf8Jr4y/6G3Xf/AAPl/wDiqPYvuafV8R2j97/+RNWKKWedIII3llkYIkaKWZiTgAAdSai8R3SWGhDw9kG8e5W5vE6+QUVljjz2f95KXHOPkHDB1GZP4u8V3NtJbXPifWZoZVKSRyXsrK6kYIILYII7VjVcKXK7s0pYSbkpVbWWtlrr5uy27W3tr0CiiitT0jvvj/8A8nFeIv8At2/9JYqKPj//AMnFeIv+3b/0liorno/w4+iPTzj/AH+v/jl/6Uw+AH/JxXh3/t5/9JZa4Gu++AH/ACcV4d/7ef8A0llrgaqH8R+i/UVb/cKX+Of/AKTTCiitbwx4c1Pxd4tsvDujrG15eOVQyvsRQAWZmPoFVicZPHAJwK1bSV2cFOnKpJQgrt6JeZ1Pwy+GV3481Ga+vrj+zPDVhl9Q1OQhAoA3FELcbscknhByf4VbZ+JPxJtNX06HwR4It/7M8H2GEjijBQ3hBzvfPO3PzANyT87fNgLo/FbX9E8O6Ovwj8F23k6Zp8yyajeCXc97cBeQ5U4bBxu3Dh0CgKIxnyKsqUPaP2kvkv19T28ZWjgKbwOHfvPScl1f8q/urr/M/IKKKmtbS6vryO0sreW4uJWCxwxIXdyegAHJNdR4JHGcTKeOCDzX6V/s4/Bc+EvhvceOtWiE/iPxK7yJIVx9ksXYuiKDyplG1274KqfunPzD8Gv2e508Uaf4k+LVoNL0uN/Pt9BuiFu9RK/N88X3ooB1dmALfdUfNkfcvjDxvPpvw2vJLWYC5uWj06128bZp5FhDDHcb2b/gNYVXfY3owlJqK6klroOmzXbbY1nlvE86aUjO+NXCqP8AcyeB04J7mvLfghjxFrnxB1u6XdeS6+SS3JEflbUX6AAivQ/C3jTSW+LnirT7Yxvb6ZbabpkEZPCAecT+bYH4CvOPA3ia28A/tS634IvbSCGy1eMyWMpXC3By0kRb1Yq0icd0ArGTaaPTwkIzo14r4kk16Jq/4a/I9dWwii1aK18va9wrOpH8RTbkfXBB/CqmmrZaT43HhRytvDcjdbo648qUguYwP7jqGdMd0kXsBXK/E/4jzaTquh6hpEIln07Wna4giUlngNmTKFA6/KwIH+zXG/GfxvHrHw5h8beGr4DxD4fuI7nYsmSyBlk2+6/ckQ+hb1YVRzUaDqNX0T0v5/1+ZiftkfBqx1bwpJ8R/CsO3U9OVV1tI1x9rt1+X7R7vHxuPdOv3BXi1p8Gr2//AGc43l0xVnugby1usAOLgLhFPfY6gR+m4g9q+07jxTb6/wCAotZ022iure/slultX5WaORAxiP1Viv1rzXQdR0aPwadH0+c3VgS32BieZE6+S392ZMYKn7xG4ZycaU3Z3Odx6M/ONgVYqQQR1B7UlepfGn4fXHhrxjc+IdLhabw9qczTQ3CAlYJGOWhf+6Qc4Bxke4OPLa3Odqx3nw2+JN14Hv5rG+t/7T8N3+Uv9NkAdWDDaXQNxuxwQeHHB/hK2fid8MbXRLCHxv4IuP7T8HX+HjljJdrIscbHzztz8oLcg/I3zYLedV6R8KPGemaTdXXg3xZZx3vhjXXSG5SeXaltJnAmGSFUfd3Nww2KwOUAPNVg4v2kN+q7/wDBPawOJhiaawOKfu/Yl/I//kW9103PK6K634keCLvwB4/utCn+a2bNxZSmQO0luzMELYAw3ykEYHKnHGCeSrSMlJXR5NehOhUlSqK0k7MKKKKZkFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAd98f/8Ak4rxF/27f+ksVFHx/wD+TivEX/bt/wCksVFc9H+HH0R6ecf7/X/xy/8ASmHwA/5OK8O/9vP/AKSy1wNd98AP+TivDv8A28/+kstcDVQ/iP0X6irf7hS/xz/9JphXv/gSD/hVX7PWpfEK5i8vXtdxa6Xvj+aJDnYw3RnGcPLgko6xxdCa8b8IeGrvxh440zw1ZNskvZgjSYB8tACzvgkZ2oGbGQTjA5NejfHvxHFqXxFj8NacttFpWgQi0t4rYoY1cqpkxtA27cJHsyQpi7ZIpVF7SSp/N+n/AATsyt/VKFXMH8S92H+JrV/9ux19Wjyqiiius8EKUEhgR17UlFAH0v8ABtbXwj4c0WW5iNxr/iky6gxk5NvploHZck8jzJoicd9iHtz7X8SvEn9k+E/DTebmO216287PrEkjnP8AwJc182eAdafWfiDqetRF2s9J8Kx2EGRxEFhii2/ifNP1JNel/E7Wor/w1rKxxtcrp2twamIY2AM0LOEdQf8AgR59GFYVHZXPTwFPnlft/wAN+p2Mou/CXg7TPGVvfRzXWqxyPqUKN+9guBL9ohDp94ZUMoyOeg60ePL3SfiD4WttUM72mpadItxZX9u2JYUZlOQe4HBx6rnvXK+L/iV8Vb/wHpPiHxr4X8CyeHtRt5ZtO04xzrfrBHIEMaXKqQJIgwLcADaSQTxXdeFvhhN4j+Emk+JvDd5FJa3tswfTbpvJkC5KkK/3Q4IYH+Fsbht3bRxQrKnG1Q9D6vUk1Xhp0Xy0/LQy/hNr2ra38XbjU/EUP9uS2ryuqadGNk8piSBSxYhIgQrElmx6dQKg+Kfwy1XQbh9X8KarpMrXgMD+HbW6E0kKtubyFU4aZfvEEKNvzYG3p6NefCfWPF3wsi0bQDe+FL+C2lOoRW83l3GoyxQhIUjkUnbE+0FiDnkjpkn5eh/Z61HWvFFvd6VY2ekw6lexrZI9+09xbq2fNLSDDM0XJJZRkjGB0rL2l5e0Tt/wDswuFqTv7O1o7p2W9+nXZ+R7f8O9fudM+A/gmC58xLmK4hsWjkBVgBcPEQQeRhe1Y1rp2iH4heJ7GbTLG6gndL+AvlSBMM87SNybwwOc4OD61iLqenn4leG/Bnh/cumaXcyXshLFj5ccjyAsTyTjZknqWrgNa8YXmmfFCy1C2mB8ie406VG+68TMsig+wEvH0r0KUrq7OHF4S0oxj8Uk3/l/Xmdn41GrXOhXOs+BrpbeWNGhvdDnhWaCfbklGiYEbuDg9GwO5FfKuoXp1DUZLtra1ty5z5drEIox9FHAr6Eu/E09n4z0rWLdzFBqV19kmTsX4dD+DcfQ+1eIeOba0tPiXr9tYbfs0eoTrGF6KvmHgfTp+FddtLniVVZmBRRRUmJ7rp8H/C2v2Y5tJWLzvEnhLBttkeXlhCnag2x5+aNWQIpyzwxljzXz9Xonwk8Vv4Q+LGmXzSxx2d04sbwyuqKIpGALMzA7QrBXPTOzGQCaq/F/wk/g74t6nYrFHHZ3Tm+sxEixoIZGJCqqk7QjBkA4zszgAiuSK9nUcOj1X6nvY5/XMFTxf24e5L/21/do33RwtaGg6YNb8VaZoxuUthfXcVr58n3Yt7hdx9hnP4Vn1a0y3trvWrO0vb1bG2mnSOW6ZC4gQsAzlRycAk474rc8E+1fin8IvhF8GNUt9CuP2bfGnjPSI7VJLnxjb6xcoNxzu+SJTECMdG2fTHNfO3gH4Map8Z/EnjKb4d3On6bpWiJJqCRa1NIsv2Us5jTMaOGkCqAckDPevrn4SePvFfgbxDYv4r/ay+GXifwFbIwlt7u9D6myBCE2qyCXdnbwztjHQ1wnwS+LfwpH7VvxeZ9YsvDPh3xfBNFpl9eAW8G7ccls4Ee/ezgNj0ODgVkm0itD5y8N/BXxT4o+APiT4vWF/o8eieH7j7NdW88sguXbEZzGojKkfvl6sOh/H3rxv8JIPE/7GHwSt/AXgfTZPFuu3XlTXVlZRx3FyPLlJM0wAJQY3EscADJ6VoaU3w8+Hv8AwT7+KHw7i+K3hHX/ABDc3/neVp18u2Yk2wC24fa84Cpkuq7c7gCdpNeheBf2i/h58Nf2W/hTo+pa3pt+l5A2l6zFpt+rahpMbq584pG3mIAQueAeQRyACNvoCSPkXV/gReaF8a1+GOqfE34dWupJE8l1fz6pLDY2TqM+TLM8KgSH+6AeeDg8Vd8Zfs0eNfCnw0u/H+m+JPBnjLw9ZSCO8vfCmq/bltSSBl8ovGWXOM4yCcDmvU/Afw8+APgX9r+a38eePPCnjHwVfWU1zo2oSanDcxJcGRCI74IxCuEMnL4Rjg9flX1S+8ffDu0/Ze+LfhSXxB8FdO1aWwlW1svAoW0hu90TeWAXYG5mGOTGuFyBkkkBuT6BY/PKvsvUfgv8KPhr+yP4R+I/iX4T+JPGU2r28cus366pNp8ukGRQQVhC7Sm47QWXB+UlvmFfJnhLU9P0Tx/oes6tZfbrCx1C3urm0wD58SSKzpg8fMARz61+ir/E/wAIaj8cLv4iQfHjwLf/AAx1/SktNX8Ja7eMtzCFjK4htSpOSSSwIGd7gg/KQ5tgj87/ABB4a1XS4Ytc/wCEd1zT/DupSyNpN5qVq0a3UQbjbJgJIwBXO0kZre+G/ir4beGZNSPxD+FX/CdrcCP7Iv8Abtxpf2Qru3n9yD5m7Kdemzjqa9r/AGyNc8M6x/wgNj8OPEnhbUPAmk6V9m02x0jUUmuLSRtpfz4t3mJlEiALDOVbdhiRXyzTWqE9D7j+NvhD9nP4Q23gY2f7OkniS48V2zTxW0XirUIGhcCLEagFzISZgBwOnTnjyaT9jT4quxtl1LwXb+IZLc3sXhF9bU6p5XXiPbtOOmd+PevT/wBon4q+CrXxz+z94p0XXtH8SReGgl1qFtpd7FcvF5bWrFGCMdjnY2A2OV9jXp3iX4r+GdS+JUXxM+HvjT9nCG3eFHXVPE1lMviCA+V5bqdjrI3y5UD5TtO3B6mE2kVZHxr8O/2b/iL8TPCvibWtA/su3k8O3H2S807UZnguTLg5VRsKDGCCXZQMHOAM1oaP+zD4y8Q+L9S0XQvGHgLUrLSdPj1DVNetNaEmm2CuZAI5ZgnEg8pyQAQAMk17L4O+J/hq8+A37SNxqXjLw5Bq/iC9upbKKGYWR1EOjrvt7eVzJh8525YjdgnNeV/sw+KdW8Oaj4mt9K+Ivgfw21/BDDNpXjaB207Vo/3mQ8i/cKZxg/eEp9DVXeorI5bX/g9rfw98Y+FJrzV/B/irTdU1FIba50TVUvbSdldN0chC5UEOucoeCeD0r1v4w/A7xD8Qf2zofhz4Y8L+BPA+oS6Il4tlply5sNq7yXLpaRne3p5XYfN6XPjrdfBSGT4bXWgTfD6LxzHq8Umuy+BWxpSQBwS277o52EE/N9/PGK9m0vxL4c8V/wDBVyx1Xwvr+l63Yf8ACKNF9r0y7juYt4D5XehIyMjjPepcnuFj5Vuv2SPilB4R17WbO98Lapd6CXOoaJp2pibUIEXJ3tCF+XKqWCMQ5H8OeK48/BTxUP2bB8bf7Q0f/hHzefYfsvmyfa9+/Znb5ezbn/bzjtX1f8N9Y+G3wQ+KHxY+LusfFfw/q66lLeQ2nhyCVv7SeU3LSNHNAwBDB12BhuQgltwFcF8Pdb8D+Pv+CempfCO++IXhvwl4istXN8q6/cm3imj8wSZQgEtwXGFDNlRxgg0+ZhZHhnjz4K+Kfh78L/B3jzWr/R59N8WW4ubGKzlkaaJTGkmJQ0aqDiQfdZuc15xX1p+1L4k8B6j+zL8GvDngzxppPiFtHsjbzC1uEM6BbeFQ0sIYtEWKn5XAI6HkGvkuqi7rUTCiiiqEFFFFABRRRQAUUUUAFFFFAHffH/8A5OK8Rf8Abt/6SxUUfH//AJOK8Rf9u3/pLFRXPR/hx9EennH+/wBf/HL/ANKYfAD/AJOK8O/9vP8A6Sy1wNd98AP+TivDv/bz/wCkstcDVQ/iP0X6irf7hS/xz/8ASaZ7P+zvbQWGveJfHF9BFNZ6DpbyMoUNMrNlt0QPAOyKVc5H38dCceW6hf3eqatdanfy+bdXUzzzSbQu92YsxwAAMkngcV6z4M/0P9jPxrf2n7i7l1JLeS4i+WR4s242FhyVxJIMdMO3qa8dp0Vec5fL7jpzJ+ywmGoLrFzfrJtfgohRRRXSeIFFFFAHuvwlitrP4O3d4XC3Gr+JLXRt390eS8ij/gRLD8Kv+I9P1O20Ea4WEtlNbGN4j/HGcxlD7hVXnvtHQjNeJad4h1ex0G50KymcW91cwXexc7lni3CN1x0YCRx+PsK9/wDCXiy28aabD4b117a3vtQgmtPLX5VW9R3kRQM8ebHPKAP78W0dQKymtLM78HiPZTi10/Lqe4fDTVZfH/wU8MxXlleyPppJaaayQJNKhMTvHIwIYOBiRT/ECSAeT7NpPhe4/s6KJXeC2RSBGGxtyST0GOpNfE/wo/aAvPgf4g1Pwl4k0z+09DW7897TeIp7dmADSwseCDgbkPGQCCOc/VGmftRfAnxBbR2epeI49IklVJPseuWrRDBwyncA0ZHQj5q8GvRnfyPp6mOdKPs6aW71+Z3k3hq4S3Jsbk5BIyr5wRwa4LxR4Z8ZWfh68Tw0tpDdXMbRy387CNLVD9+TABZ27gcDPJPY6d1+0B8H9DtYNL8P6/ba5cNkW2l+HUN3IcknA2/KgyScsQBXzx+0h8ZviFf6ZpWhWoh0HR9W80T29tLvuNi7ciSUcYIJyEGOMbjWVOk5SSRpQxmIlDVKz6nBeFJl0HwrquoGfz9T1e4/s+zmIwxiBxx6DkE89cV5pq1+L3x7cENmJ712jIP3wuFz+SCpYNVv57yOWOURx21uy2oCkiIsCFfHAwMs3XLHb2rmoLVElu5JbqeSW1gaWKcYXaVIAB65BJxj3r3aeyicGIrQp4idW9/n99vl8r3Nzxr4tWbXtOt9HcGLSZDMJP4ZLgsCzD1C7VUeu0nvXDyyyTzvNM7PI7FmZjksSckmtLRtUmstfFwI4pEmJSaGRAySI3VSDnjv6jGRUur6ZbLCNQ0oFrX7syBt3kvnpzztPGCfoe1dXM3KzPmppOPPfW+36mLRRRTMQr2X4xzP4u+C/gX4hMsRnZH0+9mkjVJppcHn5RjYHhnIGRjeMAZOPGq9k0n/AE39iLxL9s/0j7Fq6fZPO+f7Pl7fPl5+5nzJOmPvt6mubEKzjLz/ADPbyhupSxOHe0oN/OHvL9V8zw+iipLe3nu7uK1tYJJ55nEccUSlmdicBVA5JJOABWp4hHRV0aRqxe9QaXelrDJuwIGzbYbafM4+TB45xzxVKgAooqzdafd2drZXFzFsivYTcW7bgd6CR4yeDx88bjBweM9CKAK1FdC3gTxpFdWdvc+FdXtGvbiO0t2u7V7dJJXOEQO4Cgk+prnqLAFFFFABRRUrW1wtml20Eot5HaNJip2MyhSyg9CQHUkdtw9RQBFRRV+XRNag0eLVp9Iv4tPmOIrt7d1ic+iuRg/gaAKFFWn03UYri8gksLpJbLJuo2iYNb4cIfMGPlwzKvOOSB1NLLpWqQfa/P027j+xuI7rfCw8hicBXyPlOQRg46UAVK7j4TfFTxD8HPiRF418MWemXeoRQSW6xalG8kW1xgkhHQ59Oa466sb2xeNL6zntmljWaMTRlC8bDKuM9VI5B6GoKGgL+uatc6/4n1LXbxIkuNQupbuVIQQivI5chQSSBknGSaoUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAd98f/APk4rxF/27f+ksVFHx//AOTivEX/AG7f+ksVFc9H+HH0R6ecf7/X/wAcv/SmHwA/5OK8O/8Abz/6Sy1wNd98AP8Ak4rw7/28/wDpLLXA1UP4j9F+oq3+4Uv8c/8A0mme4a//AMmQ+Dv+wvJ/6Hd143Xsmv8A/JkPg7/sLyf+h3deN1WG2l6v8zozv46P/Xun/wCkoKKKK6DxQoorQ0Swk1LXLe0ijEruwCxn+M9h9M4/DNJtJXZUISnJQirtm1oemXEUYNsh+3Srlpf+faM+no7Dv/CD6nilNYSPNcmEMI7XGPKJHIbsfXgn8RXq+nnw1ZSpoUWqwT6juzIseXeWTv0HJz/COe1cvo1xoekW8kHiGGZ3knZ/KjZNrgk43OHG0DA4HJz1Xv56rSqSdkfZ18qw2BoQjUmm3fmtrZ7Jaeb/AAORvT4m+IuqR3WvLbzSaeFjuNZlPltcR9URyo/eSEA4IG48luhNakhtdWluElijsrqEFYEbClEwFWM/3hgKAw9M85Iq1rerwQ2zi1gitUiTbb28eSqq3Uj1JPzHHf6UXlj9s0+1tpGKs7EvIpwQI0HP/fcg/KrloeLQp2btrZa+fZffbXfqe5Wtn4W+DXwa0PX9JmtrrVPEdhHcBpJjJI23IkeReNio5ZAowCRjPDEeK61rN1r/AIvfz3m1fUXOMLmYf8BVcbv0UYxgAVDHot1fXdpDc3tzLbwukao8hYIpkzgf3QSWOPUnuc11Hg3W08L+G9X1TS38jVb9HmaZYSSIyzADzOikNk7f4vlAyayo0lGTbd2dWIxVT6ulBcsb2Xn/AFp6u/lblJJ9Wuma0i0oDDbGe6Zcbun3R6HisnTkkh1a7tNUtI4FeOSK4jA+VRtJ3j/dIVh/9eunt7iNo5VA3ESmFBnltoGST+eTWf4jsbu4WS4mEIMqAqQwVmKY3ZGd2CvPTqoreEuWa7GLwyqYaU4puaa9LPv28jjLMH7SHX73Rf8AePA/Lr+Fblgs8Qke2jErIuyaNhxMnKkN+Wc9jWv4c8Ogym6lAbblVGMLnvitfw/pTL4v1SzxkRgNj0DYI/mairiEm2uh6OAyCVqarL4216aN/oecajapbXWYCzQSDfGzdceh9wcg/SqdegeN/C7abGbiND5MzF0A/gkA+YfRlGfqtef11UaqqR5kfO5lgKmAxEqFRar8gr2X4Of8ki+K3/YH/wDaNzXjVey/Bz/kkXxW/wCwP/7RuajFfw38vzR2cPf79H0n/wCkSPDq3vBFxBafE7w5dXU8cEEOqW0kksrBVRRKpLMTwAAMkmsGitDxT1O08Y6JfaRq9tKZLa4vrBm1SWRlUXUsZjjjEXOWYr5jnPJZ24wM1NqP/CH/ANrW39rf8I1/Z/8AbkX2H+y9mf7Pw+/7R5Xz4/1H+s/effryaiq5ieU9RP8AYn9qaT/bH/CKf21svv8Ajz8j7D/ql+yed5X7rPmeZ17bN/GawfiDcRz/APCNxCfSZLiDSTHcrpTRmGOX7XcMVAj+UHDAkLx82RwRXGUUXHY9o1mfT1+Oum68tr4RttP/AOEmguDq1lrSzTSx+fnfJH9pcIuPmJ8tcYHQcHm7M6GPGGky6XZaNdaP9mkEMN3cWsE0b7MM1wbg7GkViGAbKMBhQOQPO6KOYXKetw2VssHim50y48J392l/pqQ3d/a2cNugeC4aSNB/qARtAO07W2FhlttVta1DwMni7w5ptpbaR/wjryvJfzW8CmUr9vuNqtJgyKojEeBwxQrnPy15ktzcLZyWizyrbyOsjwhiEZlDBWI6EgO4B7bj6moqOYOU9bvZ9FbxdpBTwv4eXalyDKut6VJHICgCMyrHHCpQncolXL5IOccc747j0aLSrZbC/wBLvbw6lctNLZW9vARGba0KqVg+Tar+coK/KWDkdTXDUUOQJFq48/8As6z8z7L5W1/L8ry/MxuOfM2/NnPTfzjpxXdai8GpeDrnVNX1LTobpLC2htpNP1MM155ZjRYpbUksuEXJbCKCmcHNed0Ukx2PTvEU2nw6h498RR6vptxbeIFYafFBdJJM3mXkVx88YO6PasbA7wOcAZrU8ZXHh7xn44kitNfsNP0m11WQ39ubhFSdWkJa8ifP75mXjbksOAvyn5fHaKfMLlPQfHer6B4o0GPVtN1W5mvLS8kiMF7bR2rrbSlpI0jVZZNyRsJBnIx5ijFefUUUm7jSsFFFFIYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB33x//AOTivEX/AG7f+ksVFHx//wCTivEX/bt/6SxUVz0f4cfRHp5x/v8AX/xy/wDSmHwA/wCTivDv/bz/AOkstcDXffAD/k4rw7/28/8ApLLXA1UP4j9F+oq3+4Uv8c//AEmme3eHv9N/Yj8SfbP9I+xawn2Tzvn+z5a3z5efuZ8yTpj77eprx2vYP2eD/a7eNPBH+p/tnSG/0z73k7d0X3ON3/HxnqPuY75Hkdxbz2l3La3UEkE8LmOSKVSrIwOCrA8ggjBBp0HaU4+d/vOnM17TC4XELblcfnGT/RojooorpPECrdlf3GnmWS1cxzOhjEg+8gPBx6EjIz7mqlFJpNWZUJyg+aLszs9AtrC08Ofag5XULlXYTZw0cQOzZH2DOQwZj0Xp1NSy3lpYwwrBZQSXksakKAG2k9mJ64GD1r0vwb+zN8S/F3wgg8WQHT7T9y1zpthO7Lc3URO4HgbUDcldxyQc8Ag1wOl/DT4k+L/HaeGtL8NXn9sRxSEwzL5CQIvV2d8KACQOvJYAZzXFKcXN+9se1TrOOHjH2dn37+vn5kMngrxl4k8Pza7pPhW91O2sDm4uNKsXdEAOWBZVwcd8cjvio9Lv4rjVYGkuQqrE2xcHJ3N82OPQCv0R8G+LbHwZ8OvD/hK60RdC1OxsxbzacHVljmiiWVlV14bzUErpIOrKwPIxXx9+0zaeGovijFrvh69Md5dGQTwQxhI5JUb5rlMY2F1aEspHLFiOM1zU8R7WXK16G8Yyw7dVLTS/3p/ocLcztZRpKGVDBiULIQCWI56deg45xTbQW83huOOaFQYrdSrCVyCzKBuxuKg+px7VlWOpxzOr6iCoRWBRcLkEHG0EgdcVE00iadDhllEI5RcE88sRj3roUH3CeYU7OMYXWtr2e6S7aWt07eeh4bnzbxmYZlaeSMj0AyT+Z/pXV6tDo0+laRqcd1pqPbgjUbO8uAJJ3SU5KJy7B4yvAAAIPSuC0O43a84U5jy8y/8AAgBXXafqSefMEgjniJWOVGVjuOeNpT5gR6jPUgg1T01MsHJzSpX3dvlt3S+9nHx65qXh/wASSra3dxPbwzELFcbgJEzxlTyMjB7EZrrbjxlZ6Nf6prWnrHcXN9HbpbxydEAj3MzY9CQMdz9K5fxXDHc3EmpxiNHWb7NJFGSVUBcx4JAJIUbTkA5XPfA5mtZ0IVLSJo5vjMA5UVLVPS+tnZp2+T+/U9IsPH0niSzuNC8RxW4edf8ARbqNNgSUcqGHTBPGe2ea86mQxXDxlSpViMHqKYCQcinSSPLIZJGLMxySe5qqdGNNvl2ZyY3Mq2OjH6w+aUdL9Wuz9P1G17J4Y/0P9jHxrf2n+j3Uuox28lxF8kjxbrcbCw5K4kkGOmHb1NeN17N8VIJ/C37N/gHwbdQSGe4eTUZHlUxNAwBYxMhycg3WCSR/q+nPEYh35Y93+Wp1ZOnTjiMQ9owa+cvdX5/geG0UUVqeIFFXodPTylkvLgwhhlURN7kHoSMgAH656HGDmpPsWm/8/wBdf+Ay/wDxyq5WK6M2itL7Fpv/AD/XX/gMv/xyj7Fpv/P9df8AgMv/AMco5WF0ZtFaX2LTf+f66/8AAZf/AI5R9i03/n+uv/AZf/jlHKwujNorS+xab/z/AF1/4DL/APHKPsWm/wDP9df+Ay//AByjlYXRm0VpfYtN/wCf66/8Bl/+OUfYtN/5/rr/AMBl/wDjlHKwujNorS+xab/z/XX/AIDL/wDHKPsWm/8AP9df+Ay//HKOVhdGbRWl9i03/n+uv/AZf/jlH2LTf+f66/8AAZf/AI5RysLozaK0vsWm/wDP9df+Ay//AByj7Fpv/P8AXX/gMv8A8co5WF0ZtFaX2LTf+f66/wDAZf8A45R9i03/AJ/rr/wGX/45RysLozaK0vsWm/8AP9df+Ay//HKPsWm/8/11/wCAy/8AxyjlYXRm0VpfYtN/5/rr/wABl/8AjlH2LTf+f66/8Bl/+OUcrC6M2itL7Fpv/P8AXX/gMv8A8co+xab/AM/11/4DL/8AHKOVhdGbRWl9i03/AJ/rr/wGX/45R9i03/n+uv8AwGX/AOOUcrC6M2itI2FiwxHqEobsZoNq/iVZj+hqhNDJBM0Uq7XXqOv0IPcd896TTQJjKKKKQzvvj/8A8nFeIv8At2/9JYqKPj//AMnFeIv+3b/0liorno/w4+iPTzj/AH+v/jl/6Uw+AH/JxXh3/t5/9JZa4Gu++AH/ACcV4d/7ef8A0llrgaqH8R+i/UVb/cKX+Of/AKTTOk8A+KP+EM+JOkeJWh86O0m/fIF3MYnUpJtGR82xmxk4zjPFdr8d/Csnh34uXl7FbeXYat/psDrvYFz/AK0Fm43b9zFQSAHXpkAeTV9AaKv/AAtr9mOXSBF53iTwlt+zbY8vLAFOxBtj/ijVkCKcs8KFjzSqP2c1U6bM7MtX1vC1cD9r44eqXvL5x1+R4XRRRXWeCFe3/s0fBOT4tfEn7Vq8Eg8LaQyzag/Ki4Y8pbKfV8EsR0QN3Iryjw14Y1rxb4t03w3odk9xqGozCG3jxgMSeST2UAEk9AASelfqb8L/AARovwu+GGneENHKyLbKZLm624N1cNjzJT9SAAOyqo7Vx43E+xhZbs68JhnWl5I6+K0tdPh81iI4oVyFQbURVHQAcYAGAO2K8/8Ah3bC+m1zxLbx5S8v3toDn7sUJOQPQeY8ufdfas347fFWw+Hnwn1K+eVXvpojFa24PMsjcIoHXk/oGPau6+Hmgt4S+E/h7w7cMZbqzsI0upD1knYb5mP1kdzXgpPlbPonN00ovd/l/wAP+QuseGPC+ppbXniixs5bkYtYpyWRgznCqpBBzknaeoJJGMmqWpfCT4c6z4Kn8Laj4WsrvT5jubzstMGGcOJj+8DLkgENwOOnFc98XtdFo/hjT4bgRXE2qCZAGwf3cUjD69M/hXV+GvFMOtaYsrMqXKYE0fofUexqU3GzTKnQnKlzvZ9D4V+NX7Omv/CW6fXNDtv7f8Ju+BcNEDc2RJ4ScDqOwkUYJ4IUkZ8fj1m1vNLntY8QtIFeFgo4kXlRkdiCR+NfqZ41S01X4aeILC7CmGbTbhW3dB+7Yg/gQD+FfmB4n0CztPEGfNWBbxUkRiMCGR8/Kw7AsCD6HHrXp0MQ6i5Zk4TBSinWptaPlaezUk18u1+ja2OSguzDqMs6r5bzx7cDjac5PFdFp9z9h0U3OfmLb0Hqei/yrm7mCcaqsN5GIrpZGVx6E/8A6+K3Gt3meOIkJBGMDHU137o8NOVGo4rRp+jLGItZW5ivZR5186vHKWwEm+baW9mLbfbOe1cfJG8UzRSIyOhKsrDBBHUGu5TWNNt9AvdM+z+cEG5NvQE5zlvqAeO+aw9ah+3eJZPMLLM0cfneXGX3S+Wu/ge+c++aujN2aa2OvN6UakqeIhK7qK76Wez+/cwKKsSWc8NussgVdxwE3Dd/3z1FV+9bJp7HiyhKPxKx1fw38KyeMfiZpWjfZvPtTMJrwHeFFuhBkyy8rkfKDx8zKMjOa0Pjn4o/4Sf4z6jsh8uHS/8AiVx5XDN5TtvLckH940mCMfLtyAc13fg5f+FU/s86n8QbiLy9e1zFppe+P5o1OdjDdGcZw8uDlHWOLoTXz7XLF+0qOXRaf5nuYtfU8BTw326nvy8ltFfm/mgq5pcaSaonmKHVFeXawyGKIWAI7gkc+1U6vaR/yEz/ANcJv/RTV0R3PAew9mZ3Z3YszHJYnJJ9aSirWmadd6xrdnpOnxGa7vJ0t4Ix1d3YKo/EkVqIq0V7F4/+Fdppfibw3Ba6be+FtMvbt9GnvNZiliV5YXAN5+9xhJUdHAyFBDgEAcZ118MLG1SS1fUbmxifU9NtBqGuWAs2RLhbvc6FLmSJov8ARx8xJyRgMgVt4B5dRXq0Hw/8IaXN4rt/EV34nhistDhv7W6m0eJJFZr6CEyRxreFJVw+wHfg73PBjUNQ1/4WW/h/wK+sXXi7Sv7UjtYLt9LN1ab2WYIQiKtwZjIFkDENCowrEMeMgXPOKK73xt8PtM8Lxa5/ZfiaXVpdD1kaNfrJYfZgJG84o0Z8xtw/0eQNkLg4xuBzV3QfCGg658CmuIrVl8VS6jetZziVsTxW1vbSPbbM7dxWaV1IG4mMLzuFAXPNaK9ovPg5p2r+OvE9hpV/JoyW+sXdhpdvcfZ/s8wi5CCSa6WZ2GQCEikIypJOcDltL+HemXuiW73nieS11a50a81yCxSwMkZhgjmcI0vmDDv5DcbSApzkn5SCucBRXoWrfDEaf8MD4rh1eT7TBDbT3emXiW0UsaTbQrKkdzJLty64MkUeQwPtWr8KPhmfGPh7Ub648N6pqq3c40exns4pWSxuHjZ/tMpTgIjeSpD/AC7ZWP8ADkA7nlFFdV4r0O00fwp4Rnjs2t729sLiW+3M2WlS+uIRkE4UhY0XAx09cmum1PwGzeB9GsdC8MwXervbR3GpXS3rfaLKSTdIgnQt5SQNAY2DYGCSGcEFaAPL6K734W6L4Y1m/wDEK+K4N1nb6Tvjn810+ySyXdvAJ/lI3bBMzbTkHHIrp734XaVFpPhPwrJF9h8T3WvR6Tq1/uaURPMqOqCPcFPlrImcYJbcCemAVzxuivQfA/he1lsbbX73ybqK8tPENuLSaAMsb2uleckoJJyd06kcDaYwQcnjT8R+CvCUb6mnhq6uHltfDGm6lLFqFr5KRyT/ANnjfHKLkjc5unZt67EyyqD8roDPK6K9X8I+EtB0zwv4nu/FyeD57qyurCGC41HULq7s0WZblmUPpbsWc+UnUkDac4J5NO8I+DLjwne6xr0sllHJ4cOq276RZyT+S39tG03bZrld52AIAdo2Pkjem6QFc8oorr73wN9jbXANU3jS9Dsdaz5GPN+0m0/dfe+Xb9s+9zny+g3cVvHnhrSvCHjbUPDWna5Pq02nXU1pdTPZi2QPG5X5P3jFunOQMHIG4ckGczRRRQAUUUUAFPuVEuieY33oJlRT/suGJB9gVyP95vWmVJL/AMi/P/18Rf8AoMlJ7AZdFFFZFHffH/8A5OK8Rf8Abt/6SxUUfH//AJOK8Rf9u3/pLFRXPR/hx9EennH+/wBf/HL/ANKYfAD/AJOK8O/9vP8A6Sy1wNd98AP+TivDv/bz/wCkstcDVQ/iP0X6irf7hS/xz/8ASaYV0/w/8W6p4K8f2Ou6TbvdyKTFJZqzKLmNuDGdvU9CMggMqnBxiuYrvfhR4zuPBfiyW7trCyvGuIxE8VzCrl485ZFY/dJ46ZzjByOK1kk00zjw9SdOrGdJ2kndep0Xxh8C2Ok3sfjXwsbU+GtVkCpFCDGbScruMZjblc7WbGBtOVKrhc+f6Lp8d3qCyXjpDZx5eSSUNsIH8OVHUnA/HtXtfjHTppfCF/4z+HtzcHwrcvu1HSYRtfSpAQdjxdPLBwVcfd4zwAa8vt7W61OfZbNe3qglykXJHHJwOnucVnCbhGz1O/FKnia7qUo8t94rv1t5eXTY6ceI7zTdc0m48PX1zYHTws1tNDcHbFtOSqYIAyMggjkE5zmvrnxD+0p4K0v4VReNEu2EdwGSO0IBnEw+9CEzywyMn7oBBJwRn4TBfTna1S2fDkcep5GDx684H9K5DxDdxXWoJbwy/aHiyrTq2Vdjjgew6Z7/AExXLWw8aiTfQ3+vypScnFXfyS7WXp/Xf3LwZ4m8R/tC/tfeET4mDpo8WofbEs85ijhh/esMn77N5YUnvkAADAr9Ip9TWKKSWd9mAWcnt3NflxOLLS/Dy6dJaMl1aymOLySXjVAxOQ6nn5mJ6Z6nPavSLf8AaB8f2Hwtj8IJFDdrBbNCmtSyyPKi8ssj9QSoIAyf4VznFYVsM52Ueh0UrQblVlzNpNta28ttH+B7n4x1q28V+Jr/AF7UJxb6VpyNFaXDHHlFTl7hT22lQoPfa/UGovhz8QYfEugx67pE3lXELmG5ixgo49V/usMMPY46g18Xf8Jfq914ag0G61O7NnBkxwyzu8Oc55T1yc+nsKs+DPG+r+C/Ekuq6bqBjaZDHMjJ5sUo7b0JGcHBBBBB9iaqWAlytdeh3U84w/upbPfyPuP4rfFS10/4SX+nsRBqmpx/Y7dCco2SN7HnO0LnP1AzkivjXxDqltrBvpL5HluyNgkeTOTvdnIb+L+EDdzycVl+JPFWt+KdQfUr+8lvpmG0THAEa/3URfuD2/Hk1gedOYfKfhQMZPHFbYbDypxszjzLFYZ8qpK7T1d9Ldu3z+Q68eW/WLULgbriIiObnlhjGSfXofxNR/arhv8ARLKWV9x2kONuz2JP8hSxXdvBbXat87SRhUA6bs9T9Bn8cVt+ALXQNf8AiLpeleMfELaHpU822XUljVvJ4OCc8AE4BY9Oprq5OWJ5uJrxxE4yv7z39b21fmrGatne2axxyJC5eUMNpY8ryBnHfFX7fT9VtLj7REqzORljz8wPOea+zNN8K/su+BvEA8Ia3a2Nz4iYI0EviqZ5YLuN+ElhmAMAVh0OBg5B6V4/8ffhR4T8K+HH8Q+CLeXTZ7a5C39okzr5QfoPLZmK84KlSUZWypIBA5YYhSkorS51qnHlftI83Kujs0tX21+Z5MkltdN5d5AYpuqk8EfRh/jS+G/Cmi6j8RNPtvEGpw2WmmVri7mu3KrNGp3GPcMbCcEFiRgEt2xWZ4dt9f122vnjiE1nYQGe4u5iFWD+4N56sxGAvJPPYEie8ud8aXZZSgKonGdx3cn3GMj8TW+t+W+pz2hTcasVzQ3tLrZ/j2uul0RfFXxynjXxp/xLoo7fQtMQ2WmW8G5Y/JU4EgQgBSwC8BRhVRTnbk8LUk4jF1IIs+WGIXPpnio61hFQSijz8ViKmJqyrVX7zCr2kf8AITP/AFwm/wDRTVRp8MskFxHPE22SNg6nGcEHIq07MwZdq7pGr6hoWswatpVx9nvICTFLsVihIIyAwIzgnB6g4IwQDVeMQXa74JYYX/ihlk2bfdWbgj2zn64yX/Y5P+e9n/4Fxf8AxVakl3TPEmraRYvY2ctu9q9zFeNb3VrFcxtLGHVGKSqwOBI4Ixg55BwMal18RPFd6EjubrT3to5YZUsv7MtRaq0PneWBAI/LCg3M5K7cMXJIJwRz32OT/nvZ/wDgXF/8VR9jk/572f8A4Fxf/FUC0OhHxF8VjWf7S+1WG4WhsPsv9mWv2TyDJ5nl/ZvL8nb5nz42fe5681WvfGniDUvDiaJqEthdW6RpCk02nWz3SRoRsRbkx+cqgAAAPjb8vTisf7HJ/wA97P8A8C4v/iqPscn/AD3s/wDwLi/+KoDQv6j4o13Vjq51C+87+2L9dTvv3SL51wvm4fgDb/r5eFwPm6cDCWPibXdMttNgsNQeBNNvm1K02KuYrhhGC4OMniGPg5Hy9OTmj9jk/wCe9n/4Fxf/ABVH2OT/AJ72f/gXF/8AFUBodZB8WPHttqNzfxa1Cbq4vJb9p3sLd3SaXHmNGzRkxh8AMqbVIGCKvaJ8UH0T4bz+HItOubi9ks7nT47u4nhaOCCcMHRFEHnAYdzt84puO7bmuF+xyf8APez/APAuL/4qj7HJ/wA97P8A8C4v/iqA0N+9+IPi3UPDMugXepQvYzQwwTBbOBJJ0iK+UJJVQO5XYoBZiQBjOCRWPNrOp3Glafpsl0fsunmRrWNFC+WzsGZsgAkkgcnJwAOgFQfY5P8AnvZ/+BcX/wAVR9jk/wCe9n/4Fxf/ABVAaGj4h8Va94ru4rnXr1bqWLzdjCGOLHmTPM/CKAcySu3/AAL0wK1rb4n+NrOwjtINVg2pbizMj2Fu8sluF2iCSVoy8kW0AeW5K4AGOBXMfY5P+e9n/wCBcX/xVH2OT/nvZ/8AgXF/8VQGhLY6tf6da6hb2U/lRahb/ZLpdinzIvMSXbyOPniQ5GDxjoSKnsvEet6dZWlpY3728VpejUbfy1UNHcAKBIGxnI2rxnHFU/scn/Pez/8AAuL/AOKo+xyf897P/wAC4v8A4qgLo6K9+I3i+/Nv5+o26LbpdpDHbWNvBHGLuEQ3GEjjC/OgweODlhhiTVa58b+JLvRf7KnvLdrc2K6a7LZwLLJbq8TpG8oQO4U28O3cxKhcDAJBxvscn/Pez/8AAuL/AOKo+xyf897P/wAC4v8A4qgNCWHVtQt9Au9FhuNtjeTRXE8OxTveIOIznGRgSycA4O7nOBjT03xt4k0r7KtreW7R21k2nRwXNnBcRG3adrgxvHIjLIPNYv8AMCQcY6DGP9jk/wCe9n/4Fxf/ABVH2OT/AJ72f/gXF/8AFUBobs/j/wAWXPhaXw9NqMTWE1rFZSqLSESSwxOjxo8oTewQxptyx2gbRgEg42rapf65r99rWqT+ffX1xJdXM21V8yR2LM2FAAySTgACo/scn/Pez/8AAuL/AOKo+xyf897P/wAC4v8A4qgNCvRVj7HJ/wA97P8A8C4v/iqPscn/AD3s/wDwLi/+KoC5Xoqx9jk/572f/gXF/wDFUfY5P+e9n/4Fxf8AxVAXK9SS/wDIvz/9fEX/AKDJUhtdg3S3dmiDqwnV8fghJP4CqN5dLMEhhBEEZJXd95icZY+mcDjoMDrySpOyHuVaKKKyKO++P/8AycV4i/7dv/SWKij4/wD/ACcV4i/7dv8A0liorno/w4+iPTzj/f6/+OX/AKUw+AH/ACcV4d/7ef8A0llrga774Af8nFeHf+3n/wBJZa4Gqh/Efov1FW/3Cl/jn/6TTClVmRw6MVYHII6g0lFbHmnceHPiJqulatBcpcC1lACSTR5Czjp+8XOD9cdzkHJrtxp9n4kklHhrU08PyTMZJLO2iHlmQnKn5SGCZ6AZA7AdK8QrQ07WtR0uRXs7hkKHK8/dPt6VPKrWsddLFzjU55Seu9t2vU6rxVP4m8N6dfWut3d0JpU8lGL7lnJ43BscgKDzwRwDiuR0LQxGV1DUEGdvmQwOgcH3kUkfL04xznsOvr+nJ4i8Y+FbLxJJFY6jcQmRI7aNsywhcbpFjbhpDjqpLBQMAVyuoXdrPEStu80oO7y1V9zH6Yzn9axcLPY7K01Wlzuo5JbXev5/kZkEMtzE0hllhB+6sZZQ545weg55/wAmrV7LewaBeQz38iTOgL2UWQqLuAzJnHzHjCgcA8kdK6PR9H8SNBeXMGny6W5VRHd3cRQww9WkCkZGBwCAAAScjrWXr8HhLTfDt1FaaxPqerT4XcxyB84JY7eM4HcnrTUW2ro292nRcoP3mn1sktu+r8uifU4Siiius8IUMVOVJB9qGdm+8xP1OaSigArctPDVw9gL7ULmKwhdC0KSAtNPxxsjHODxycD3NUNNmtbW8F1dRiUR8rERkM3bI9BXbaJ4W8beP9QjuNL8MySQz/8AMRvAyW4QPsJ3nCtg5yF3NweDg1jVm4+S7np4DCRrb3lJ7RSb+bt/wPU5BrTUboRJdXikQxiONZp92xASdoGTgZJOPc1oS2guS4ur+6ugkSw24kZ3aNQcgDjG3k4HAGa9UPhH4TfCuRbvx/q41/XlKv8A2Lp67kib922CmRnGSQZWVXQn5CRXl/jj4k6v4znigW0tNG0q3Ux2+m6evlxhM5XeR99gAo6BRt4VcnOUarqP3Vp3/wAjpxGXwwMH9ZmvafyrV/8Ab3Remr8i9LrUlvoi6RbNNBpSSM6W8rrEjMcDdJgDzGwoBYjoMAAcVzWo6rFvcwyCaZhgOoISIf7Oep96wiSTk0VappHn1cW57LXzd7emyX3BRRRWhxhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB33x//wCTivEX/bt/6SxUUfH/AP5OK8Rf9u3/AKSxUVz0f4cfRHp5x/v9f/HL/wBKYfAD/k4rw7/28/8ApLLXA133wA/5OK8O/wDbz/6Sy1wNVD+I/RfqKt/uFL/HP/0mmFFFFbHmhRRRQBo6Tr2saHOZtJ1Ge0Y9fLbhvqOhrqn+MfxDksWtW8Qy7WXbvCKHx9R0rhKKBptHb+Ffiz418I6zNf2OoR3QnOZ7e9j8yOTggdMMvLZ+VhkgZyBiu6l+MXw58XSA/EL4ZRtOUV5dQ0yUedNMqheeY2CYzwZGxhRzjI8OorKdGMnzde56WGzjFYen7GMrw/lklJfc07fI9w/sn9mu9H2z/hMfEWned+9+xeU7fZ93Pl58h87c4zubp949aX/hTngH/ouXhv8AKH/5Irw6il7Oa+Gb/Bm/9qYef8XCwfo5R/KX/DHuP/CnPAP/AEXLw3+UP/yRSf8ACMfs7WZ+yX/xH1qa6h/dzS2sLGJ3HDMmIGG0kEjDMMY5PWvD6KPZze83+H+Qf2phofwsJD5ucv8A249yg+Knwf8AC13FdeDfhZLdTlxI8uqzANAyHKNEWMxBySSRt6L17cp4o+OfxF8T+Wn9r/2NCmD5Wjl7fcw3fMX3Fzw2Nu7bwDjIzXnFFCoQTu9X56mdbPMZUh7OMuSPaKUV+FvxCiiitjyQooooAKKKKACtfwqtk/jjSE1GFZbVryJZEYgKQWA+bIIK+o7jI4zmsiihAz1/RNNFn4o1RLeC+02CLXLL/Q5dhWQGZ8MP3YIXHKgHGD1aq1r4c0W1+Ktj59rJqdtf/am+0yMht3l2ufLCFTyp+XDEHdg4GMHymitOfyI5PM9A0fwRpmpQrJcQ6rbNJdvbyxmRM6aqqCHnygzk+yfXNXb7QbTUPhXo9z5s13cWVnOYrW1YKzr57ZlOQcouOQBnkdBzXmVFLmXYfK+52On+C3SDVU1Wxv7rUrCSOP8AsrT5U80hxnfkK+VAx0B69qs2ngvS7jwumoPPeKXs5rl7vevkW0iEgQONuSxx6g88A1wtFK67BZ9z0aXwd4VtdGmup/7YkkttPtL2TZcRqrmYhSqgxnABOcnNV77wrp2j64dBlJmF5qy28UrgeYIUALYOOCzSKufVDXA1I1xOyRI08hWEYjBY4QZz8vpySeO5p8y7ByvuemXekadceDJbqXSoYIhBHIs8cUcaRloJJPlcLvYq6JGQ7Nkk9CRjPu/BegLpEnkXN/Ddw6ba6hJNNIjRfvWAZdoQEAZzndXJXviDVtQtGt7u4jdXIMjiCNZJSOm9woZ/+BE1mUOS7CUWejax4F8OaTeWAkvtSa3lvo7aSYRvskjYf6xJDEEBB/hDPkd6XUfh7pGl6ReXN1qkwkslEFwNy4S4dozH25TZISe+VPIrziijmXYfK+56/ceEtOs/Ck+hBr2ys59at4jf3jqyTLsP7yPCgBTnHU9uetYg8B6Q2q6fBLLqFi1x9pzYXDobiTyhlCh2gDf2yPpmvO6KHJdhKL7nrGteGrS+t9ItprTUons9F82LS96/apW80/JnZ1GST8mcdqpWPw80W513UrBbm/na38rygpKIhZNzLLMsUiqynjkD+leaUUcy7ByvuegWXw/guvAt1rEplimhs5rtJY5/NifyyflIEQVcgf8APQnvjHTVtvD2n6J4E1yaKHULiCfTbaSS+3r5M251Zkj+XgjpyT7gd/KqKOZdhuLfU9KHw+8Ppqtpaz6xMq6hI89iwdf3lqIwy5wpO9mbaMD+FsA8Cq0ngzQLXVNQFy+rNb2ulG/MBVoJA4cLt3SwruX/AGgg/SvPqKOZdg5X3PTn8MaHYaB4mtLfTLzUZkisrqAh0M8cbqWO0iM4CnO4gYIx93GTQuPAVnHoV1q0ZvmtE022uoZ9ylHlkYB1zt5AyeByOM1wFFHMuwcr7nozeCfDUvjnVNBtp9RT+zoi22WYPJdN8vCBISVAyc4VyeOBzXH+JdLttG8TXGn2ctxJDHtKm5heGQZUHDK6qeM9cDPXvWTRSbT6Ak11CiiipKCiiigAooooA774/wD/ACcV4i/7dv8A0lioo+P/APycV4i/7dv/AEliorno/wAOPoj084/3+v8A45f+lM5bwL4lfwf8R9G8SK8qpZ3KtMIkV3aE/LKqhuMlGcDp16jrW58TvCdv4Q+IlzZ6bJFNpF4i3+mTROHR7aTJTadzEgEMgYnLbd3QiuCruvB/inRZ9Pg8GfEBbmfw353mW15bH/SdJdiNzxEg5ib+OPBH8ajcPmbvGXMhYecKtF4Wo7a3i3sns0/KWmvRpX0vbkaK9Lm+DOsapIJ/h7rekeMrEokjSWdzHBNbhlBXz4ZHBjJO8AZJ+Q5Cnio/+FC/Fj/oVP8Ayetv/jlV7en/ADIHk+Ov7tGTXdJtfJq6fyZ5xRXo/wDwoX4sf9Cp/wCT1t/8co/4UL8WP+hU/wDJ62/+OUe3p/zL7w/sfH/8+J/+Ay/yPOKK9H/4UL8WP+hU/wDJ62/+OUf8KF+LH/Qqf+T1t/8AHKPb0/5l94f2Pj/+fE//AAGX+R5xRXo//Chfix/0Kn/k9bf/AByj/hQvxY/6FT/yetv/AI5R7en/ADL7w/sfH/8APif/AIDL/I84or0f/hQvxY/6FT/yetv/AI5R/wAKF+LH/Qqf+T1t/wDHKPb0/wCZfeH9j4//AJ8T/wDAZf5HnFFej/8AChfix/0Kn/k9bf8Axyj/AIUL8WP+hU/8nrb/AOOUe3p/zL7w/sfH/wDPif8A4DL/ACPOKK9H/wCFC/Fj/oVP/J62/wDjlH/Chfix/wBCp/5PW3/xyj29P+ZfeH9j4/8A58T/APAZf5HnFFej/wDChfix/wBCp/5PW3/xyj/hQvxY/wChU/8AJ62/+OUe3p/zL7w/sfH/APPif/gMv8jziivR/wDhQvxY/wChU/8AJ62/+OUf8KF+LH/Qqf8Ak9bf/HKPb0/5l94f2Pj/APnxP/wGX+R5xRXo/wDwoX4sf9Cp/wCT1t/8co/4UL8WP+hU/wDJ62/+OUe3p/zL7w/sfH/8+J/+Ay/yPOKK9H/4UL8WP+hU/wDJ62/+OUf8KF+LH/Qqf+T1t/8AHKPb0/5l94f2Pj/+fE//AAGX+R5xRXo//Chfix/0Kn/k9bf/AByj/hQvxY/6FT/yetv/AI5R7en/ADL7w/sfH/8APif/AIDL/I84or0f/hQvxY/6FT/yetv/AI5R/wAKF+LH/Qqf+T1t/wDHKPb0/wCZfeH9j4//AJ8T/wDAZf5HnFFej/8AChfix/0Kn/k9bf8Axyj/AIUL8WP+hU/8nrb/AOOUe3p/zL7w/sfH/wDPif8A4DL/ACPOKK9H/wCFC/Fj/oVP/J62/wDjlH/Chfix/wBCp/5PW3/xyj29P+ZfeH9j4/8A58T/APAZf5HnFFej/wDChfix/wBCp/5PW3/xyj/hQvxY/wChU/8AJ62/+OUe3p/zL7w/sfH/APPif/gMv8jziivR/wDhQvxY/wChU/8AJ62/+OUf8KF+LH/Qqf8Ak9bf/HKPb0/5l94f2Pj/APnxP/wGX+R5xRXo/wDwoX4sf9Cp/wCT1t/8co/4UL8WP+hU/wDJ62/+OUe3p/zL7w/sfH/8+J/+Ay/yPOKK9H/4UL8WP+hU/wDJ62/+OUf8KF+LH/Qqf+T1t/8AHKPb0/5l94f2Pj/+fE//AAGX+R5xRXo//Chfix/0Kn/k9bf/AByj/hQvxY/6FT/yetv/AI5R7en/ADL7w/sfH/8APif/AIDL/I84or0f/hQvxY/6FT/yetv/AI5R/wAKF+LH/Qqf+T1t/wDHKPb0/wCZfeH9j4//AJ8T/wDAZf5HnFFej/8AChfix/0Kn/k9bf8Axyj/AIUL8WP+hU/8nrb/AOOUe3p/zL7w/sfH/wDPif8A4DL/ACPOKK9H/wCFC/Fj/oVP/J62/wDjlH/Chfix/wBCp/5PW3/xyj29P+ZfeH9j4/8A58T/APAZf5HnFFej/wDChfix/wBCp/5PW3/xyj/hQvxY/wChU/8AJ62/+OUe3p/zL7w/sfH/APPif/gMv8jziivR/wDhQvxY/wChU/8AJ62/+OUf8KF+LH/Qqf8Ak9bf/HKPb0/5l94f2Pj/APnxP/wGX+R5xXY/DHwnb+L/AIiW1nqUkUOkWaNf6nNK4REto8F9x3KQCSqFgcru3dAa2ofgzrGlyGf4ha3pHg2xCPIsl5cxzzXAVSW8mGNyZCDsBGQfnGAx4rC8YeKdFg0+fwZ8P1uYPDfneZc3lyf9J1Z1J2vKQBiJf4I8AfxsNx+WZVFJcsH8zSlgXhJKtjI2SfwvSUvK26XdtLTa7Mbx14lfxh8R9Z8SM8rJeXLNCJUVHWEfLErBeMhFQHr06nrRXPUVSSSsjz6tWVWcqk3dt3fqwooopmYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB//9k=",
	"syok": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwMDAgQDAwMEBAQFBgoGBgUFBgwICQcKDgwPDg4MDQ0PERYTDxAVEQ0NExoTFRcYGRkZDxIbHRsYHRYYGRj/2wBDAQQEBAYFBgsGBgsYEA0QGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBj/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4Poor1jTtOT4NRab4h8Q6PFe+M7pEvNN0m/jbyNNh3EC4nAILTMVYJGCPLwWbDBVGeLxaoJRiuacvhj1b/RLq+nm2k7oUHVbbdord9v8ANvov0uznvD3wf+Jfimy+2aN4Qv3tyiSpNc7bVJUcEq0bSlRICBnK56j1Gdj/AIZ3+MX/AEJ//lQtf/jtGiyeKPjf8WNM0LxP4rujLdeb5c8kYkjt9sJc7IVKqu7ylB24yeTk16t/wyN/1UH/AMpP/wBur5jM+IJ5bUVLG4mnTm1fl9nUnpqviUo31T+yvQ9nCZXHFwc8PRlOKdr88Y/g07b92eU/8M7/ABi/6E//AMqFr/8AHaP+Gd/jF/0J/wD5ULX/AOO16t/wyN/1UH/yk/8A26j/AIZG/wCqg/8AlJ/+3V53+umG/wCg+n/4Iq//ACZ1f6v1f+gaX/gyH/yJ5T/wzv8AGL/oT/8AyoWv/wAdo/4Z3+MX/Qn/APlQtf8A47Xq3/DI3/VQf/KT/wDbqP8Ahkb/AKqD/wCUn/7dR/rphv8AoPp/+CKv/wAmH+r9X/oGl/4Mh/8AInlP/DO/xi/6E/8A8qFr/wDHaP8Ahnf4xf8AQn/+VC1/+O16t/wyN/1UH/yk/wD26j/hkb/qoP8A5Sf/ALdR/rphv+g+n/4Iq/8AyYf6v1f+gaX/AIMh/wDInlP/AAzv8Yv+hP8A/Kha/wDx2j/hnf4xf9Cf/wCVC1/+O16t/wAMjf8AVQf/ACk//bqP+GRv+qg/+Un/AO3Uf66Yb/oPp/8Agir/APJh/q/V/wCgaX/gyH/yJ5T/AMM7/GL/AKE//wAqFr/8do/4Z3+MX/Qn/wDlQtf/AI7Xq3/DI3/VQf8Ayk//AG6j/hkb/qoP/lJ/+3Uf66Yb/oPp/wDgir/8mH+r9X/oGl/4Mh/8ieU/8M7/ABi/6E//AMqFr/8AHaP+Gd/jF/0J/wD5ULX/AOO16t/wyN/1UH/yk/8A26j/AIZG/wCqg/8AlJ/+3Uf66Yb/AKD6f/gir/8AJh/q/V/6Bpf+DIf/ACJ5T/wzv8Yv+hP/APKha/8Ax2j/AIZ3+MX/AEJ//lQtf/jterf8Mjf9VB/8pP8A9uo/4ZG/6qD/AOUn/wC3Uf66Yb/oPp/+CKv/AMmH+r9X/oGl/wCDIf8AyJ5T/wAM7/GL/oT/APyoWv8A8do/4Z3+MX/Qn/8AlQtf/jterf8ADI3/AFUH/wApP/26j/hkb/qoP/lJ/wDt1H+umG/6D6f/AIIq/wDyYf6v1f8AoGl/4Mh/8ieU/wDDO/xi/wChP/8AKha//HaP+Gd/jF/0J/8A5ULX/wCO16t/wyN/1UH/AMpP/wBuo/4ZG/6qD/5Sf/t1H+umG/6D6f8A4Iq//Jh/q/V/6Bpf+DIf/InlP/DO/wAYv+hP/wDKha//AB2j/hnf4xf9Cf8A+VC1/wDjterf8Mjf9VB/8pP/ANuo/wCGRv8AqoP/AJSf/t1H+umG/wCg+n/4Iq//ACYf6v1f+gaX/gyH/wAieU/8M7/GL/oT/wDyoWv/AMdo/wCGd/jF/wBCf/5ULX/47Xq3/DI3/VQf/KT/APbqP+GRv+qg/wDlJ/8At1H+umG/6D6f/gir/wDJh/q/V/6Bpf8AgyH/AMieU/8ADO/xi/6E/wD8qFr/APHaP+Gd/jF/0J//AJULX/47Xq3/AAyN/wBVB/8AKT/9uo/4ZG/6qD/5Sf8A7dR/rphv+g+n/wCCKv8A8mH+r9X/AKBpf+DIf/InlP8Awzv8Yv8AoT//ACoWv/x2j/hnf4xf9Cf/AOVC1/8Ajterf8Mjf9VB/wDKT/8AbqP+GRv+qg/+Un/7dR/rphv+g+n/AOCKv/yYf6v1f+gaX/gyH/yJ5T/wzv8AGL/oT/8AyoWv/wAdo/4Z3+MX/Qn/APlQtf8A47Xq3/DI3/VQf/KT/wDbqP8Ahkb/AKqD/wCUn/7dR/rphv8AoPp/+CKv/wAmH+r9X/oGl/4Mh/8AInlP/DO/xi/6E/8A8qFr/wDHaP8Ahnf4xf8AQn/+VC1/+O16t/wyN/1UH/yk/wD26j/hkb/qoP8A5Sf/ALdR/rphv+g+n/4Iq/8AyYf6v1f+gaX/AIMh/wDInlP/AAzv8Yv+hP8A/Kha/wDx2j/hnf4xf9Cf/wCVC1/+O16t/wAMjf8AVQf/ACk//bqP+GRv+qg/+Un/AO3Uf66Yb/oPp/8Agir/APJh/q/V/wCgaX/gyH/yJ5T/AMM7/GL/AKE//wAqFr/8do/4Z3+MX/Qn/wDlQtf/AI7Xq3/DI3/VQf8Ayk//AG6j/hkb/qoP/lJ/+3Uf66Yb/oPp/wDgir/8mH+r9X/oGl/4Mh/8ieU/8M7/ABi/6E//AMqFr/8AHaP+Gd/jF/0J/wD5ULX/AOO16t/wyN/1UH/yk/8A26j/AIZG/wCqg/8AlJ/+3Uf66Yb/AKD6f/gir/8AJh/q/V/6Bpf+DIf/ACJ5T/wzv8Yv+hP/APKha/8Ax2j/AIZ3+MX/AEJ//lQtf/jterf8Mjf9VB/8pP8A9uo/4ZG/6qD/AOUn/wC3Uf66Yb/oPp/+CKv/AMmH+r9X/oGl/wCDIf8AyJ5T/wAM7/GL/oT/APyoWv8A8do/4Z3+MX/Qn/8AlQtf/jterf8ADI3/AFUH/wApP/26j/hkb/qoP/lJ/wDt1H+umG/6D6f/AIIq/wDyYf6v1f8AoGl/4Mh/8ieU/wDDO/xi/wChP/8AKha//HaP+Gd/jF/0J/8A5ULX/wCO16t/wyN/1UH/AMpP/wBuo/4ZG/6qD/5Sf/t1H+umG/6D6f8A4Iq//Jh/q/V/6Bpf+DIf/InlP/DO/wAYv+hP/wDKha//AB2j/hnf4xf9Cf8A+VC1/wDjterf8Mjf9VB/8pP/ANuo/wCGRv8AqoP/AJSf/t1H+umG/wCg+n/4Iq//ACYf6v1f+gaX/gyH/wAieU/8M7/GL/oT/wDyoWv/AMdo/wCGd/jF/wBCf/5ULX/47Xq3/DI3/VQf/KT/APbqP+GRv+qg/wDlJ/8At1H+umG/6D6f/gir/wDJh/q/V/6Bpf8AgyH/AMieU/8ADO/xi/6E/wD8qFr/APHaP+Gd/jF/0J//AJULX/47Xq3/AAyN/wBVB/8AKT/9uo/4ZG/6qD/5Sf8A7dR/rphv+g+n/wCCKv8A8mH+r9X/AKBpf+DIf/IniPiH4P8AxL8LWX2zWfCF+luEeV5rbbdJEiAFmkaIsIwAc5bHQ+hxxFexeLtM8Ufs/fES30/wx4zunlubJLySSOARRvlpYwrxMzq+MMQWzgtwARmquo6cnxli1LxD4e0eKy8Z2qPealpNhG3kalDuANxACSVmUsoeMk+ZkMuWLKfpMJmtT2UMRWcZUZbVIpxtf+aMrtLpfmfmktV5NfBQ55UqaaqL7Ls/ukrXflZeTbPJ6KKK+gPLO3+EHh628U/HDw5o14YjbvdefKk0QlSVIVaYxspOCHEZU5/vZweho+MvE954z8eap4nvl2S30xdYsg+VGAFjTIAztQKucAnGTya6b9nf/k5Pw3/29f8ApLLXnleTRSlmtVy+zThby5pVOb7+WP3I7pu2Cgl1lK/yUbfdd/eWtP1LUdI1KPUNKv7qxvIs+XcWsrRSJkEHDKQRkEj6E1uf8LH+If8A0Pnib/waT/8AxVczRXp1cLRqvmqQTfmkzkhWqQVoSa9GdN/wsf4h/wDQ+eJv/BpP/wDFUf8ACx/iH/0Pnib/AMGk/wD8VXM0Vl/Z+F/59R/8BX+RX1qt/O/vZ03/AAsf4h/9D54m/wDBpP8A/FUf8LH+If8A0Pnib/waT/8AxVczRR/Z+F/59R/8BX+QfWq387+9nTf8LH+If/Q+eJv/AAaT/wDxVH/Cx/iH/wBD54m/8Gk//wAVXM0Uf2fhf+fUf/AV/kH1qt/O/vZ03/Cx/iH/AND54m/8Gk//AMVR/wALH+If/Q+eJv8AwaT/APxVczRR/Z+F/wCfUf8AwFf5B9arfzv72dN/wsf4h/8AQ+eJv/BpP/8AFUf8LH+If/Q+eJv/AAaT/wDxVczRR/Z+F/59R/8AAV/kH1qt/O/vZ03/AAsf4h/9D54m/wDBpP8A/FUf8LH+If8A0Pnib/waT/8AxVczRR/Z+F/59R/8BX+QfWq387+9nTf8LH+If/Q+eJv/AAaT/wDxVH/Cx/iH/wBD54m/8Gk//wAVXM0Uf2fhf+fUf/AV/kH1qt/O/vZ03/Cx/iH/AND54m/8Gk//AMVR/wALH+If/Q+eJv8AwaT/APxVczRR/Z+F/wCfUf8AwFf5B9arfzv72dN/wsf4h/8AQ+eJv/BpP/8AFUf8LH+If/Q+eJv/AAaT/wDxVczRR/Z+F/59R/8AAV/kH1qt/O/vZ03/AAsf4h/9D54m/wDBpP8A/FUf8LH+If8A0Pnib/waT/8AxVczRR/Z+F/59R/8BX+QfWq387+9nTf8LH+If/Q+eJv/AAaT/wDxVH/Cx/iH/wBD54m/8Gk//wAVXM0Uf2fhf+fUf/AV/kH1qt/O/vZ03/Cx/iH/AND54m/8Gk//AMVR/wALH+If/Q+eJv8AwaT/APxVczRR/Z+F/wCfUf8AwFf5B9arfzv72dN/wsf4h/8AQ+eJv/BpP/8AFUf8LH+If/Q+eJv/AAaT/wDxVczRR/Z+F/59R/8AAV/kH1qt/O/vZ03/AAsf4h/9D54m/wDBpP8A/FUf8LH+If8A0Pnib/waT/8AxVczRR/Z+F/59R/8BX+QfWq387+9nTf8LH+If/Q+eJv/AAaT/wDxVH/Cx/iH/wBD54m/8Gk//wAVXM0Uf2fhf+fUf/AV/kH1qt/O/vZ03/Cx/iH/AND54m/8Gk//AMVR/wALH+If/Q+eJv8AwaT/APxVczRR/Z+F/wCfUf8AwFf5B9arfzv72dN/wsf4h/8AQ+eJv/BpP/8AFUf8LH+If/Q+eJv/AAaT/wDxVczRR/Z+F/59R/8AAV/kH1qt/O/vZ03/AAsf4h/9D54m/wDBpP8A/FUf8LH+If8A0Pnib/waT/8AxVczRR/Z+F/59R/8BX+QfWq387+9nTf8LH+If/Q+eJv/AAaT/wDxVH/Cx/iH/wBD54m/8Gk//wAVXM0Uf2fhf+fUf/AV/kH1qt/O/vZ03/Cx/iH/AND54m/8Gk//AMVR/wALH+If/Q+eJv8AwaT/APxVczRR/Z+F/wCfUf8AwFf5B9arfzv72dN/wsf4h/8AQ+eJv/BpP/8AFUf8LH+If/Q+eJv/AAaT/wDxVczRR/Z+F/59R/8AAV/kH1qt/O/vZ03/AAsf4h/9D54m/wDBpP8A/FUf8LH+If8A0Pnib/waT/8AxVczRR/Z+F/59R/8BX+QfWq387+9nTf8LH+If/Q+eJv/AAaT/wDxVH/Cx/iH/wBD54m/8Gk//wAVXM0Uf2fhf+fUf/AV/kH1qt/O/vZ03/Cx/iH/AND54m/8Gk//AMVR/wALH+If/Q+eJv8AwaT/APxVczRR/Z+F/wCfUf8AwFf5B9arfzv72XtV1vWdevVvNc1e+1O4RBGs17cPM6oCSFDMScZJOPc1f8G+J7zwZ480vxPYrvlsZg7RZA82MgrImSDjchZc4JGcjkVhUVrPDUp0nQlFcjTTXSz3REa04zVRP3k738zq/jB4etvC3xw8R6NZmIW6XXnxJDEIkiSZVmEaqDgBBIFGP7ucDoCtj9oj/k5PxJ/26/8ApLFRXn5JVlVy7D1Ju7cIN+rijqzGEYYqrCOylL82H7O//Jyfhv8A7ev/AEllrzyvQ/2d/wDk5Pw3/wBvX/pLLXnlTh/+RpX/AOvdL/0qqOr/ALnT/wAU/wAoBRRRXsnAFFFFABRRRQAUVu+GPBvijxnqTWPhjRbrUZU/1jRgLHFkMRvkYhUztbG4jJGBk16la/s26rp9nDf+O/Gvh7wvZTIAryy+Y6zEZETbiiZwHyVdvu8ZHI8rHZ5gMDP2eIqpS/l3l/4Crv8AA7cPl2JxMealBtd9l970PEKK92Pgf9m+xxZ6l8StelvIQI55LaBvKdxwzJi3YbSeRhmGCOT1p3/CQ/sw4z/wrnxL/wB/3/8AkquH/WLm1pYWtJf4Lf8ApTjf5fM6f7JcfjrQX/b1/wAkzweivd/+Eh/Zh/6Jz4l/7/v/APJVJ/wjn7MV8ftv/CaeJtN8/wDe/YfKdvs27ny8/Z3ztzjO9un3j1J/rC4/xMJWX/bl/wD0ly/EP7Kv8Nem/wDt635pHhNFe5n9m86x/wAiJ8SvDPiHyv8Aj6y/l+Rn7n+qMuc4frt+7xnnHmXiv4eeNPBHlN4n8P3VjFLgJPlZYSTuwvmISu75GO3OcDOMV2YPP8vxk/ZUaq5/5XeMv/AZWf4fmYYjLMVh489SD5e61X3q6OZoqV7eaO3inkjKxy52Mf4sHBx+NRV65wtNbhRRRQIKKKKACrWm6feavrNppWnw+deXkyW8EW4LvkdgqjJIAySOScVVrq/h3/yOsv8A2CNU/wDTfcVhiqrpUZ1I7pN/cjSjBTqRg+rRehTwno0f2WPQ7fxDOOJr2/nnjhdh3gjiaJlXkjMhYsArbYySlSf2p4c/6J34d/8AAjUP/kqsavXvhv4L8Pa94Gsb3UdGtLye41t7Keaa8khkSAQB/wB0iyKHcHkAKxOTx3HZhsmhiJcilK/+KS/BO33JL0PKzfiCGVUPrFaPu3tpGPZv7Vu3e551/anhz/onfh3/AMCNQ/8Akqj+1PDn/RO/Dv8A4Eah/wDJVel+AvBHhHVdJs7nVNKlug2u3lo/mSyRO8Edm0qoQrDadwB7Ht04qh4i+HWnReHdA/4R+Pz5tb1Zo7O7LsfMtnVDGGXOAV3MG4Byprf/AFeXs/aJu3+Od+nn5nmLjbC/Wvqkk0+7jG32r6+XI3te3ztwf9qeHP8Aonfh3/wI1D/5Ko/tTw5/0Tvw7/4Eah/8lV2fxN8JeHdL0m01jwnFAtnFcyaddeTfLdh3XmOUlXbYXUN8pxjb0Fc/D4I834Q3Hjr+2rVfJuxa/YCPnbJAznPXnO3HQE5rKpkcYTcPedlf457feduF4ooYjD08T8KnLlScY35m7JOydr+trGZ/anhz/onfh3/wI1D/AOSqP7U8Of8ARO/Dv/gRqH/yVW54W0TSZPh94g8U3unf2tcadJBFHYmR0jUOTmWTYQxAxgYI561u+F9I8Da/pupXmr6DcaTLog/tG4treWVheWxX/VfO2UO8rhh/C3cjdTp5HTny+81fX45+fnboyMVxRHD+0bpuSptRbUYPVpNK1+Z/FFXta73tdnDf2p4c/wCid+Hf/AjUP/kqj+1PDn/RO/Dv/gRqH/yVXquh+DPBmt+ENDmbRbOG/wBYtNRnjhjuLrz2eJ38tYiWMQVVAB8zk4HU5rmb3RfDWn/Bjw/qxtNGTU9Rt7sySXz3pmkZJSimERHygQMffwM4znmtJcPwjHmcna1/jn5ee+qOWlxnSq1PYxpS5ufktyQ39/Xf4f3ctfL1tyH9qeHP+id+Hf8AwI1D/wCSqP7U8Of9E78O/wDgRqH/AMlV6brngbw1bfDeTUYtFhhkj8P2WoLdW91JJcNcyEB98RdgsZHO7YoHOD2FK48IeHY/g7/wmS+H5RqL2CL/AGZ9ofbFmQp9vxv37DjhT8uT0K05cPRi2m3or/HPb7yaXG+HqRjJQes1Be7D4mk1121+XW2l/P8A+1PDn/RO/Dv/AIEah/8AJVN/snQ/FdxHp2kaLHoutTMIrSO2uJHtblycLEyys7pIxOBJv2ZCAqoLSDIorz5ZfBL93KSfR80n+DdmfUrFSv7yTXol+KRzdb+iaJbT2P8Aa2rGb7D5jQRxW7hJJ5FClgGKsEVQ6kkg53AAfeZJ/iP/AMlk8W/9hq8/9HvWnJ/yKPhr/rwk/wDSu4rGnXdSjGqlbmSf3q5xZm5UWqUXvK1/RN/Lb/LXUPM0D/oTtI/7/wB3/wDH6PM0D/oTtI/7/wB3/wDH6qV7D8KvhRovjDwvPrmt3d1tMzQRQ2zhduAMsxIPPPA9u+ajnl3PAx2Jo4Gl7atOVv8AFL/M8p8zQP8AoTtI/wC/93/8fo8zQP8AoTtI/wC/93/8frq77wRaab8cI/BNzqJNo13FF9o4DbHCsB6BsMB9avap4f0S48LeJL6LQ20WbRtQitYf3sjfald2Uowcn51ADZXAwelHPLuQ8ZR9y0pNSSafNLaTsvtX3+7qcN5mgf8AQnaR/wB/7v8A+P0eZoH/AEJ2kf8Af+7/APj9ew+Jvh54StT4ov8ASLIi20618ryGncm1uQyHdy2WVkfIzkZDegrGHhDw7/w0pc+Ff7O/4lCCQrbedJxi1Lj5t2773PX9KOeXc5qWa4erBzi56RcvieySb+1v7y/zPN/M0D/oTtI/7/3f/wAfo8zQP+hO0j/v/d//AB+vV/CvgLwvrvhnwg7Wh/tO6eS4u0MzgXduk5jcD5vlZQUPy4yA1ZNroXhm0+Hd5rF3Z6QLlNcmsUk1SS8KeUsYYIotzndnPLe/PSjnl3KWZ0XJwXO2nb4pd2v5vJ/1c8+8zQP+hO0j/v8A3f8A8fo8zQP+hO0j/v8A3f8A8fqpRRzy7nrey/vS/wDApf5lst4ekUxv4S0+NW4LwXFysij1UtKyhvQlWGeoPSue13Rk04QX1k7yafdM6wmQjzI3XaXjfGMld6fMBhgwPB3KutUuo/8AJNL/AP7Cdp/6KuaunN3sy6cpUZRababSabb3durdrb/gcZRRRXSe0eh/tEf8nJ+JP+3X/wBJYqKP2iP+Tk/En/br/wCksVFeJw//AMivC/8AXuH/AKSj0M0/3yt/il+bD9nf/k5Pw3/29f8ApLLXnleh/s7/APJyfhv/ALev/SWWvPKrD/8AI0r/APXul/6VVFV/3On/AIp/lAKKKK9k4Aoor0P4WfCy8+IGpTX9/cf2X4Y0/L6jqkhCKoUbjGjNxu28knhB8x6qrcuNxtHBUZYjEStFf1Zd2+i6m2Hw9TEVFSpK7Zynhnwr4g8Y68ujeGtMlv70o0nloVUKi9WZmIVR0GSRyQOpAr3CDwD8IPhJ5d18Rta/4SbxBHtf+xbJd0cTfumwyZGcZJBlZVdCfkJFY/iL4u6d4b8KQeB/g4lzpOlQ+YLrVZUUXN85BQuD1XcMNvwrj5QojCYPjdeF9Wx+b+9Wk6FHpFaVJf4pfYX92Ouruz0/a4bA6U0qlTu/hXovter07I9c8TftCeMtUt103wxFbeFdIjh+zx2tiqtIqbFXHmFRt24O0xqhUHuQDXm6tq3inxOhvb+4vb+7dUe6u5WkY4AGWdiThVHfoBWXXouk+E9WN5pmg+GNOfU/Eeo/uhFbtvfzGJ+TsECBSWJ4GCScCvYwWVYPLocuFpKPnbV+r3fzbOSpjK2LmniJtr+tlsjmvGj2b+N7xrDDWoKpGRxuVVCg/iFFeufDbRo7qxi/4S79ndNS8PSja2rW0l3Z3Kgj78bSTbJfXAAz2Ir2Dwd8C/DHw0it9a8Qb/E/i+VN8VpaY8i229TGWGdq/wAU7YH90evQyX+ueKtSl0j+zja37Ro7Rx3cj4ifO3zTJ2YKSM4OADjBFdsXokTXftasqqVk3ex8r+MfhBeD4jX1n8PoJ9S0JtstrPcSIjKrDOwliMkeuOmM4NY+o/Bj4l6ZaG6n8K3ckIGS1uyzY/BST+lfX3hvwvc+H2a91TRZxYbist5Zy75bcg4PmxkE7Rgfd6DnBFeiy6HqcdsLnTwmr2rKGFuCiSsp5zE4wjnHQNjP96q57GTpo/MdWvtL1NJEa4sr22kDowJjkidTkEHgqQcHNewfDj4v/FG11S0tri+OsaOjbJ31VSwjUuGZvtAG/fjIXcWHOApwANX4s+JtD1/4nXDHS4ks9Jd4Abi28i4mdfvGTcNyYII2kZA5wCePMpvEsuoKyTXpsbFW4VAXdvXYucDgdT+dcGYZfhcwp+zxNJT9Ve3o918jvy2rLD1VJVHFeTtf16feekHwr8OPiZr95pcviODwtrEbrDpdrFCkdu0ZdcgR4VWdmZgFVw2SThgK8h8a+APFHw/1lNP8S6f5Hm7zb3EbB4bhVbBZGH4HacMAy5AyKzb66+2X8k4QRqThUBztUcAflivT/A3xifT9Bk8GfEKzk8ReEZbb7MLbapmtwMldjEqWAOAAWBTahQrtwfMrYfMMvk62Fftael6bspJf3Jdf8Mt+jTZ0YjFYTH1ZKpH2b6SW3kpL06rbqmeOUV6l8SvhPb+G9Cs/GngnUZdd8HXiKVvDhpLZz8uJcAcFsgHA2t8jAMBu8tr1sBj6OOpKtQd1s+jTW6a3TXVM8nE4aphp+zqLX8GujT6oKKKK7DnCtrwprEGheLba/vEkezZZLa6EQBk8iaNoZTHkgbwkjlc8bsZyMisWioq01VhKnLZq33lQm4SUlujs9R0e802OC4kUTWNzlrS/hDGC6UYy0bEDOMgFThlPysFYECOHVdTt7SK1g1K7ighnF1HEkzKqSgYEigHAfAHzDmsPSPEfiHw/539g69qel+ft837DdPB5m3O3dsIzjJxnpk1p/wDCx/iH/wBD54m/8Gk//wAVUrEYuGijF+fM43+XK/z89NgnQw9T4r+lk/1X5GkniXxFG7PHr+qIzTPcFlupATK67Wfr94qSCepBxTLfX9etIrSK11vUYI7Nme2SK5dRAzZ3FAD8pOTkjrk1Q/4WP8Q/+h88Tf8Ag0n/APiqP+Fj/EP/AKHzxN/4NJ//AIqq+u43+Rf+Bv8A+QMfqGCta3/ki8/Pzf3smS+vY9PlsI7y4W1mYPLAshCSMOhZc4JGTgmq9O/4WP8AEP8A6HzxN/4NJ/8A4qj/AIWP8Q/+h88Tf+DSf/4qpeKxb/5dx/8AA3/8gbqhh43tJ6/3V/8AJFjT9T1LSbv7VpeoXVjPjHm20rRNj0ypBp7azq7T3czaremS8XZdOZ2JnX0c5+YcDg56VU/4WP8AEP8A6HzxN/4NJ/8A4qj/AIWP8Q/+h88Tf+DSf/4qmsXjErckf/A3/wDIGcsHhJS53v35V/8AJGnD4n8SW2jjSbfxDqsNgFKi0ju5FiwSSRsBxgknPHc0QeJ/Etto50i28Q6rDp5RozaR3cixbWzuXYDjBycjHOTWZ/wsf4h/9D54m/8ABpP/APFUf8LH+If/AEPnib/waT//ABVP67jf5F/4G/8A5AzeXYF3ut3f4Fv3338y8Nd1wSeYNZ1AP9m+xbvtD58jp5XX7n+z09qDr2uG6e5Os6gZng+yvKbh9zQ4x5ZOclMcbelUf+Fj/EP/AKHzxN/4NJ//AIqj/hY/xD/6HzxN/wCDSf8A+Ko+uYz+SP8A4G//AJAr6jg/6iv8xta2laUkkS6zrKXFt4fgmCXV4gxvxgmGEkENOwPyr2zubCKzDL/4WP8AEP8A6HzxN/4NJ/8A4qsfVdb1nXr1bzXNXvtTuEQRrNe3DzOqAkhQzEnGSTj3NZyq4qouVpRv1Tbfy91a9n07M6FGjF3Tb8mrfq/66hreq3GveJtR1y8SJLi/upbuVYgQivI5YhQSTjJOMk102iytrugWWl2qNLqdgHiS2jUlp4C5kBQclnVnk3Afw7CAQrkcXRVqlFQUI6JbHHi6LxCu3717389f82ddXQ+G/HPinwjFPFoGqvbRTnc8ZRZFLYxuAYEA+49K4z/hNfGX/Q267/4Hy/8AxVH/AAmvjL/obdd/8D5f/iqz9i+55lXA1a0eSpCLXZtv/wBtNq9vrzUdSm1C+uZJ7qZzJJM5yzMe9TX2tazqcUUepatfXiRf6tbid5An0BJxXP8A/Ca+Mv8Aobdd/wDA+X/4qj/hNfGX/Q267/4Hy/8AxVHsX3K+p1tPcjptq9P/ACU6J9d1uRrtpNY1BmvcC6LXDk3GOnmc/NjtnNWpfGHi6YoZvFOtSGNiyF76U7SVKkjLcHDMPoSO9cn/AMJr4y/6G3Xf/A+X/wCKo/4TXxl/0Nuu/wDgfL/8VR7F9yHgKj3px+//AO1Ogg1rWLV7RrbVr6FrMMLYxzupgDZ3bMH5c5Ocdc1PZeJvEmmwvFp3iHVbOORzK6W93JGGc9WIBGScDn2rmP8AhNfGX/Q267/4Hy//ABVH/Ca+Mv8Aobdd/wDA+X/4qj2L7jlgast4R+//AO1NIkk5JyaKzf8AhNfGX/Q267/4Hy//ABVH/Ca+Mv8Aobdd/wDA+X/4qj2L7mn1fEdo/e//AJE1YopZ50ggjeWWRgiRopZmJOAAB1JqLxHdJYaEPD2Qbx7lbm8Tr5BRWWOPPZ/3kpcc4+QcMHUZk/i7xXc20ltc+J9ZmhlUpJHJeysrqRgggtggjtWNVwpcruzSlhJuSlVtZa2Wuvm7Lbtbe2vQKKKK1PSPQ/2iP+Tk/En/AG6/+ksVFH7RH/JyfiT/ALdf/SWKivE4f/5FeF/69w/9JR6Gaf75W/xS/Nh+zv8A8nJ+G/8At6/9JZa88r0P9nf/AJOT8N/9vX/pLLXnlVh/+RpX/wCvdL/0qqKr/udP/FP8oBRRWx4V8M6p4x8YWPhrRkia9vHKIZX2IoClmZj6BVYnGTxwCcCvVq1YUoSqVHaKV230S3ZxQhKclCKu3ojq/hZ8LLz4galNf39x/ZfhjT8vqOqSEIqhRuMaM3G7bySeEHzHqqtt/E74nWes6bB4F8C239l+DNPwkcUYKNelTne+edu75gG5J+d/mIC6Xxd8RaH4b0Vfg54HtfI0rTpll1K8EwZ764CjIcqcNg43bhw6KoVBGM+N189luGnmlWOZ4te6taUH0XSct7yfT+VeZ62KqxwcHhKD977cu7/lX91de78gooqa1tLq+vI7Syt5bi4lYJHDEhd3J6AAck19SeORxnEynjgg89K/Sr9nH4Lnwj8NZ/HOrRCfxF4kd5EkK7fsli7F0RQeVMo2u3fBVT905+Y/g1+z3OninT/EfxbtBpemRv51voF0Qt3qJXDfPF96KAdXZgCw+VR82R9yeMPG82m/DW8ktJh9ouWj0612jG2aeQQhhj03s3/Aawqu+xvRhKTUV1H2ugabLdMyIs0t4nnTS9d8asFUf7mTwOnU9zXl3wQ2+I9c+IOuXCZu5dfJJbkiPytqD6AAivQvC3jPSm+LvirT7cxSWum22m6Xbxk8IF84n8d20fgK858C+JrfwF+1Lrngm9s7eGy1aMvYylSFnOWkiJ9TtaRMj+JMVjJtNHp4SEZ0a0V8SSa9E1f8NfkevLYQxavFa7MSXCs6EfxFAuR9cEH6CsS41fRfBer3um6kzwWEdu92saRF3iZVMjRog6q6BnTHGUkXjHGH8T/iRLpOq6FqGkQLLPp+tO1xCgJZoDZky7R/uuDj/ZriPjb4zg1/4eWvibQr9V1jTLhBP5dwEcxNgqBIQQE3GOQMRjaW5GTRKVk2ZYTDe2nGMtE3a/8AV/6Z5f8AtQ6b4X+INxJ4r8EWZt7yzsLa6vppJEjOqQvtQkRfe8+EsAw5LKrddgzyFp8Gry+/Zzill01fPuwbu0uhgOJ8fIp77HUCP03EHtXWX3iLw1P8OtFsNP0do9YhkAutQuZCsbxS5kQrtONmWbbuBIUZBO/I9T8I3NlZ/DiDw4l/HqKIhWC4iXak2OsWD9yVcYKE5JG5c5OIwlaTfvf15HoZxl1HCqLpt6tqz7L7WnffpvtbU/O5gVYgggjsaSvUfjR8P5vDXjG51/SonuPD2ozNLDcopKwyMctC/wDdIOcA4yPcHHl1egfNtWPQPhh8T7vwHqM1hf239qeGdQymoaXIA6srDaXRW43beCDw4+U/wstv4p/Cy00LT4fHfgS4/tTwXqGHjljJdrFmONj5527vlDNyD8j/ADYLeaV6d8IvG+l6Pd3fgnxfZRX3hXxA6Q3KTy7UtZM4WYZYKo+7uYYYbEYHKAH5rNMFUwlV5ngV72nPBfbiuvT34rWL6/C73PVweIhXgsHiHp9mX8r/APkW9103PJaK7D4m+BLz4d/ES70C4+e1bNxYymQO0tszMELYAw3ylWGBypxxgnj69rC4mniqMa9F3jJXTPNrUZ0ZunUVmtGFFFFbmYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB6H+0R/ycn4k/7df/SWKij9oj/k5PxJ/wBuv/pLFRXicP8A/Irwv/XuH/pKPQzT/fK3+KX5sP2d/wDk5Pw3/wBvX/pLLXnleh/s7/8AJyfhv/t6/wDSWWvPKrD/API0r/8AXul/6VVFV/3On/in+UAr6I8Awf8ACpP2cdU+I11D5XiDX8WmleZH80SHOxhujOM4eYgko6xxdCa8U8G+GLzxn480vwxYtslvpgjS4B8qMAtI+CRnagZsZBOMDk16X+0J4mi1T4lR+GNNS2i0jw7CLO3itShjVyqmTG0DbtwkezJCmI9CSK4c6j/aGKo5Uvhfv1P8EWrL/t6WnomdOXP6tRqY17r3Y/4mtX8l+LR5HRRRX1Z44UoJDAg4PbFJRQB9LfB1bXwl4c0WW5Q3Gv8AilpdQcycm30y0DsuSeR5k0ROO+xD2r2v4l+Jf7J8KeGnEuY7bXrYzD3ijkc/qua+bfAOtPrPxC1PWot7WWk+FY7CHI4jCwxQ7fqT5p+pJr0n4nax/aHhzVYrYRTNZa5b6ikUj7VkidxGwJHIXLHJHQMDWFR2Vz08BTU5en+dv1OyMGqeFvBeneNoJ/MfVkkbUUUfPb3IkFxCsg6qSoZQD1HTOaTx7eaX8QfC9rqfnSWmpafIlxZahbtiSJHZTkHuBkHHque9cN41+J3xSj8LaZL428PeHGSeximtzpnnW979mMkibJtymKVYniCsG2lXKleSTXf+Afhx4l8Z/Cm08TaOljNZXMUka2zT+XJIASpwCMRuCCChOCRkEbsVxwq8kbVDvnQndV4rl6Lptp+St95pfBCy8Q+MvjBean4pa2vIdPEk8skS4jldo0gQ7T90tsc49uOK534ofDrVbCW+8RfDKKbVvDuHt5XjXdCqkndEp/5aorE4deFJKgnkLf8AF1n8TfDXwzjsLHQI9D0yWaOPViLaYrsURwCe6dGLyRHKgRRYzlt3AJPmWn+Hfjv4w1SL/hLPGPiXS4bWC4ns7O2mWyhjeFMWyx26rgq0vlIvB4YcjrWKlKU+dM6qFCtyucI3hHfb+r+R3nw8i0ey+EnhfVLnTIZNUuJLTTrhrkFy6xXLRoNjZAK4U5AzkCmWen6MfH/ifT5tMsrm2nZb6FnypxKM87SNybwwOc4ODXNaTqlw/jDwp4Ol1KW/l0+VtQ1G9d9/msjtKzk+mSv/AH0K4vWvF93pnxOsr+2mB8ie40+VG+7JEWWRQfYCX9K76L0uc2Nw0nOMb3k038ui+5HZ+NBqs+gXGseBblbd41aG80OeBZobjb1R4mBG7g4P8WB3Ir5V1C9OoajJdtbW1uXOfLtohFGv0UcCvoO78SzWXjLStYt3McGo3X2WaMngvw6H6huPofavEfHFvaWnxK1+2sdv2aPUJ1jC9FG88D6dPwrstoeFVVjAoooqTE9+02D/AIXD+yxNo6w+d4n8H7Ta7I8vNAFOxBtjz80asgRTlnhjZjzXzrXpHwd8XP4N+L2l37SxR2d24sL0yusaCGRgCzOwO0IwRyeM7MZAJqr8ZvB7+C/jFqtgsUUdldub+yESLGghkYkKqKTtCMHQDjOzOACK+Uy6P9nZjVwH2Kl6kPK79+K9HaSXZ+TPYxb+tYWGJ+1H3Jf+2v7tPkcDWhoOmDW/FWmaMblLYX13Fa+fJ92Le4XcfYZz+FZ9WtMt7a71qztL29Wxtpp0jlumQuIELAM5UcnAJOO+K+nPHPtX4p/CL4RfBjVLfQrj9m3xp4z0iO1SS58Y2+sXKDcc7vkiUxAjHRtn0xzXzp4a+Dep/E/Q/H3jD4eXOnx6R4ZMl6dIv5pBqBtDveMqqoyOwRCD845X3Gfrv4SePvFfgbxDYv4r/ay+GXifwFbIwlt7u9D6myBCE2qyCXdnbwztjHQ14r8M/jP4Z0L/AIKJap4m8PRLb+C/FOpS6ZNEY9iPDOwCylCPlHmhZCCMhSw4yayTZTseP2HwY8UXv7Oeo/GmTUNHsvD9neiwSC6lkW6u5CUX9ygjKsMueSw+4/pz3WhfsffFHV9B0i+1DV/B/hy91mPzNM0bXNV+z316MAjy4gjZOCDtJBGeQK9E/bK1DQvhz4f8DfADwaMaTogk1q6hc7t0ksj+Ur+4DTE57SLXbePdV+F3x2+Mfw3+NWnfGfwp4ZstCjtn1PRtavPs19AYZzOVijP33JYoSOPlBBbpT5nuFkcN+yx8J7bT/iZ8UvCHxR8EaZdapoui7ha6tZxXX2eTJIkjLBhypBDL1BBBrxDVfgP4u8O/Ayz+KPirU9D0Cw1BsabpeozSrqGoDgh4oVjYbSDnLMvGCcBlz9geA/j78N9d/a9+KXjaLxHo2maQ2gQWOnXGsXCWi6i8OclVkKlsnIC9SoHAzgeP/H/VvAv7Qfwy0740eH/Gum6R4q0+1Fnqvg3V9VjjkATktZpIw3dc4QYcdg4Ksk3cLKx8oxRSzzpDDG8krsFREGWYngAAdTX2d8bfg78Ffgh8PvDyah8KvFOtWuq2e2TxhFq0lvPa3ZXIR7Vl8sE/e2sF4BHJU184/Anxf4e8BftF+E/F3iq3M2kafe+ZcbY/MMYKMqyhep2Myvgc/LxzX3BaeMvh+vjHx3J8Qvjp4A8YfCjxYxu4tFur95tQsZW27USFQWRFAAGCCCiMApBzU27gj88db8M+JPDMlrH4j8P6ro73cIubZdQtJLczxHpIm8Dcp/vDivoD9jT4W/D/AOKfxH8S6d8Q9BOr2NhpQuoYxdTQbH81QWzE6k8E8E4rO/bJ16PxJ+0WdT03xH4Z1rQE0+G10h9A1CK7SCBMkxyCNjsfeznBxwRjOK6X9hrxb4V8JfEfxhc+K/E2j6FBcaGYYZdUvY7VZX81TtUyMATjnA5obbjcS3Ndf2YvCaftiSpKh/4U/Ho58X/a/Pk8s6cUyIvNzv8Av8Z3b/LG7OeaxP2qvgX4c8K/tAeEPAfwd8IzQTa3pyulhFczXDTTtNIud0zttG1RnkKACTjk1yD/ALT/AImf9kFfgYdKGRi2Ou/av3hshJ5gtvL2evy7t/3Pl296+hvjB8bfh34e/b3+GfxAtfEela9oOn6PJaX13o91Hei1Mpnj3Hyy3KiQMV6lc4HIpe8mPQ8C1j9j74paXpGqTWereD9c1bSYPtOoeHtH1YT6jaJjOXh2DnHQAkntmuntfCfhZv8AglVe+LW8NaOfEC68IV1c2cf2sJ56DYJtu/bgkYzjFe86h8U9K8OfEXWPHXhDx3+zLp2l3zSSf2pHp88muzROwcrPHDKryOWCk8jcQDgdB4YfGnhe5/4Jc6n4ck8Q6HF4huPERuhoqXca3IQ3CtuWAtv2AZ5x0FK7e4WR5/4L/Zd+IXjDwDYeM7vV/CnhPR9TkEWmzeJtS+xm+Y5CiJQrE7sHAON3UZHNQ6d+zB8ULz9oH/hT19Dpmka+1o99FNfzv9lngX+NJI0csDggfL1BBwQRXtPii9+Hv7Rv7Nnwu0W0+K3hTwRq/hG1Wx1LT/Ed19kUqIoomkizxIf3IZQOzkEqRXosXx3+F/iH9v3wxd2Pi3TItA8P+HLrT5fEGo3KW0FxO3O1ZJCAwGBg9yWxkYJfMwsj5g1D9kz4oWHgbxF4kjvfC9/J4d8x9T0ix1MTX1tGmTveILhMopcKxDkD7ueKxvh7+zp47+Ifw3vvH1vqHhzw94btZDCNS8Rah9ihnkBAKoxUjqQuW2rk4zkHHuHwE8deEdM8X/tFXOu+MNEsl1mK5NjJe6hFEL9me7I8osw8wnev3c/eHrVHw3r3gX4r/wDBPXS/hDP8RPDngvxJ4b1Jrxk1+5NtBeR+ZM4KsAS2ROeFDNuj6AEGjmYWR438R/2dPiF8L/C3hbWfEJ0u4fxJJ5Nnp+nSyT3CSYU7HGwKSdwA2MwJ6EjBrsI/2Lvi06R2Umr+CoPEctr9sTwtLrKjUmj9RHt2Y7Z34z3r2747+INI+Hvwp/Zk1wXEusafoc9reLI0ZjkvIIIrc71RuV3KAQG5G5c1curv4Tan+2fY/tMR/HfwfF4citFmfSpLtl1JZFtDb+WttjftP3jxnJI285pczsFkfAupabf6PrN3pGq2ktpfWcz29xbzLteKRCVZWHYggiqtdt8YPGNh8QPjv4q8ZaVbvBY6nqMk9ukg2t5ecKzDsxABI9Sa4mtUSFFFFABRRRQAUUUUAFFFFAHof7RH/JyfiT/t1/8ASWKij9oj/k5PxJ/26/8ApLFRXicP/wDIrwv/AF7h/wCko9DNP98rf4pfmw/Z3/5OT8N/9vX/AKSy155Xof7O/wDycn4b/wC3r/0llrzyqw//ACNK/wD17pf+lVRVf9zp/wCKf5QPb/2bbW30/wAQeJ/Hd/BFPZeH9JeRlChp1dstuiB4B2QyqTuH3wOhOPJdR1C71bWLvVdQm867u5nuJ5NoXe7sWY4AAGSTwBivYfBP+h/sS+OdQs/9Hu5tTjtpLiL5JHizbDy2YclcSSDaeMO3qa8VrmyZKvj8binupKmvJRin+Lk2b49+zw2Hors5fNtr8Egooor6Y8kKKKKAPdPhNHbWfwdvLwuBPq/iS10Yt/dHkvIo/wCBEsPwq94n0zU7bw7/AG4X860uLZopI/70ZzGVPuFVee+0dCM14pp3iHWLHQrnQrKdxb3V1Bd7FzuWeLcI3XHRgJHH4+wr6B8IeLrPxnYQeHNektra+1CCa18tflVb1JGkRAM8ebHPKAP78W0dQKymrqzO/B4j2U4yXT8up9HeALQ+O/AnhjU9d0bVrWSCyjI+0soScvGu+ZCAdySgK5XP3uSAeT7ZpmnwaNptnZWphtrGFdiiWT5ixOep6kkkk9STXxt8H/2mrL4ZwP8ADj4j6fcSWOlP5VnqNooaa3hJyEeM43xqScMp3KOCCMY+mdM+L3we8apDFY+MvDt1MAHS3vXSGZQw7RzgHkeg6V4FanNSd9j369eTiqa2V/T1O51SGHVNDntgI7m2uEaKRD8ySLyrKR3HUGvI/GnhnxDaeHLg+E9K0uHUJI2h/tGVFjFjEVIeQYBZmCk4AwM8k9j1OrfFn4WeBtKis73xdotpHEPLhsracTy4zwiRR7mPXAAFfPvx9/aM15NKs/DfhjQptLtdYjkL31/gXHlLgN+6H+ryDxuJPsDWdOEpSSRpg3UgrJaM8h8JSjQvCWqX7Tebqer3H9n2cpGG8oHt6DkE++K821W+F748uCGzC967RkH74XC5/JRViPVr+6vo5kmESW0DLagKSIiwIV8cDAyzdcsdp6Vy8FsiyXcktzM8trC0sU4wu0qQAD1yCTjHvXu09UomGJrQp4idW9/n9/4fK9zc8a+LVm17TrbR3Bi0mQzCT+GS4JBZh6hdqqPXaT3rh5ZZJ53mmdnkdizMxyWJOSTWlo+pzWevCcJFIkxMc0MiBkkRuqlSDx39RjIqXWNLtlhGoaTl7X7syBt3kvnpzztPGCfoe1dTk3KzPmppOPPfW+36mLRRRTMQr2340zP4x+B/gH4jssRuGR9Nvp5I1jnnmweflGPLDwXBAyMeYMAZOPEq9r0f/Tv2EvE/23/SfsOsp9k875/s2Xts+Xn7mfNk6Y++3945+Z4gSpVsHi18Uaij8ql4tfe0/ketlj56dei9nBv5x1X6r5nhFFFSW9vPd3cVrawSTzzOI44olLM7E4CqBySScACvojySOu3+F/xMvfhX4vfxJpvhfwvrt55QSAeILE3aWrh1cTQgMpSUFeGB4BNcqNI1YveoNLvS1hk3YEDZtsNtPmcfJg8c454qlQ0Bv+NfGfiH4hePdS8Y+Kb37Xquoy+ZNIFCqMAKqqB0VVAUD0ArAoqzdafd2drZXFzFsivYTcW7bgd6CR4yeDx88bjBweM9CKAK1FdC3gTxpFdWdvc+FdXtGvbiO0t2u7V7dJJXOEQO4Cgk+prnqLAFFFFABRRUrW1wtml20Eot5HaNJip2MyhSyg9CQHUkdtw9RQBFRRWl/wAI9r/9n21//YepfZLpxHb3H2Z/LmYnAVGxhiT2FAGbRVqPTNSlaURafdOYpFhkCxMdjsSFVuOGJBAB5ODVi78O+INP1O306/0PUrW8uSFgtp7V0klJOAFUjLZJwMUAZtFTtZXiWP21rSdbbzDD55jITzAM7N3TdjnHWoKACvTPhz8bNb+HPh2bQYvCHgnxNpz3bXyW/ibR0vfImZEQvG2VZciNOM4+Xp1z5nRQ1cDu/in8X/HHxi8TW+s+NL+GX7JEYbOztYhDb2qE5KxoOmcDJJJOAM4AxwlFFCVgCiiigAooooAKKKKACiiigAooooA9D/aI/wCTk/En/br/AOksVFH7RH/JyfiT/t1/9JYqK8Th/wD5FeF/69w/9JR6Gaf75W/xS/Nh+zv/AMnJ+G/+3r/0llrzyvQ/2d/+Tk/Df/b1/wCksteeVWH/AORpX/690v8A0qqKr/udP/FP8oHu/iH/AJMS8F/9hmT/ANDvK8Ur2vxD/wAmJeC/+wzJ/wCh3leKVz8M/wALEf8AX6r/AOls3zf46X/XuH/pIUUUV9KeSFFFaGiWMmpa5b2kUYkd3AWM/wAR7D6E/pmk2krsqEJTkoRV2za0TS7iJB9mQi+lXc0v/PtGR29HYd/4QfU8UpbCR5rnyQwjtcY8skchu3fPBP5V6tYf8I1YyLoUeq28+oZJlVMu0sn8XQYJ9u1c1ok+iaXBJBr1vcPLJO0nloyhXyTjc+8YAAHA5OTyvfz1XlUk7I+zrZVhsFQhGpNNu/NbWztbl083+Bx963ib4ianFc68LeR9PVYZ9Zl/dtPH1VZNo/eSEZwQNx5LcAmtW4Sz1prhLmGG1uIOIIpMfKuAqRkdxgAAj0zzkireu6xDFaulrBHbJCmy3t48lUDdcepJ+YnufpSXdi13YWtu7FWdiWdTggRoOff55B+VXJ2R4tCmru2tlr59l99vPqeuabofhj4QfC/SPFtstrfa1rtos9tPP5bNHjKyMoHKIrHZg4JZcZ648s1fWLnXPFrpM8uq6hIedgMwP0VeW+nCj2qCPRrq/u7SK6vbmW3hkSNUaQsqAvnA/ugksfqT65rp/B2tL4Y8NavqWmSC31XUEeYzLCdwjLMABL0Uhsnb/F8oGTWdKklJuTuzrxGKqfV0oLlje3r3/T1+63KSTardu1pFpYGH2M92y4LdPuj0PFZOnrJFqt3aapaxwK8ckVxGB8qjaTvH+6QGH/166eCdHSRQNxEhhQZ5baBkk/nk1n+I9PvLhXuJ/JQyICCGCs2zG7IzuwVyenVRW0Jcs12MHhVUw0pRTc016WffscZZq32kOv3hwv8AvHgfl1/CtzT1uIlka2jEjIuyaNhkTJypDfXGc+prX8OeHVMv2qUB9vyqMfLnvitfQNKZfF2qWYGdgDY9A2CP5moq4hJtroejgMgklTVZfG2vwb/NHnGpWqW13mAloJBvjJ649D7g5B+lU69A8beF202Lz40/czMXTA+5IBlh9GUZ+q15/XVRqqpHmR87mWAqYDESoVN1+XQK9t+Cn/JG/i5/2Bf/AGhdV4lXtvwU/wCSN/Fz/sC/+0LqvA4t/wCRZP8AxU//AE5A6Mk/3yPpL/0iR4NW94IuILT4neHLq6njggh1S2kkllYKqKJVJZieAABkk1g0V9AeSep2njHRL7SNXtpTJbXF9YM2qSyMqi6ljMccYi5yzFfMc55LO3GBmptR/wCEP/ta2/tb/hGv7P8A7ci+w/2Xsz/Z+H3/AGjyvnx/qP8AWfvPv15NRVcxPKeon+xP7U0n+2P+EU/trZff8efkfYf9Uv2TzvK/dZ8zzOvbZv4zWD8QbiOf/hG4hPpMlxBpJjuV0pozDHL9ruGKgR/KDhgSF4+bI4IrjKKLjse0azPp6/HXTdeW18I22n/8JNBcHVrLWlmmlj8/O+SP7S4RcfMT5a4wOg4PN2Z0MeMNJl0uy0a60f7NIIYbu4tYJo32YZrg3B2NIrEMA2UYDCgcged0UcwuU9bhsrZYPFNzplx4Tv7tL/TUhu7+1s4bdA8Fw0kaD/UAjaAdp2tsLDLbara1qHgZPF3hzTbS20j/AIR15Xkv5reBTKV+33G1WkwZFURiPA4YoVzn5a8yW5uFs5LRZ5Vt5HWR4QxCMyhgrEdCQHcA9tx9TUVHMHKet3s+it4u0gp4X8PLtS5BlXW9KkjkBQBGZVjjhUoTuUSrl8kHOOOd8dx6NFpVsthf6Xe3h1K5aaWyt7eAiM21oVUrB8m1X85QV+UsHI6muGoocgSLVx5/9nWfmfZfK2v5fleX5mNxz5m35s56b+cdOK7rUng1Lwbdanq2p6dBdpp9vDbSadqYZrsxmNFiltSSy4RclsIoZM4Oa87opJjsesW/i+2k1XQTNqVnZzXuk3Mt1exn/V6jIs1uk8xGSHCrEc/w+Yz4yxJi0Ce38PL4b0vW9c024uB4ntL9DBfR3EdnApIldpUYou8mMkZz+7yccV5ZRT5hcp2Xje8s9bitdX0m9gisIv8ARl0fzFDWLdTsXrIjnLeZycnDc4J42iik3caVgooopDCiiigAooooAKKKKACiiigAooooAKKKKAPQ/wBoj/k5PxJ/26/+ksVFH7RH/JyfiT/t1/8ASWKivE4f/wCRXhf+vcP/AElHoZp/vlb/ABS/Nh+zv/ycn4b/AO3r/wBJZa88r0P9nf8A5OT8N/8Ab1/6Sy155VYf/kaV/wDr3S/9Kqiq/wC50/8AFP8AKB7t4c/079hPxP8Abf8ASfsOsp9k875/s2Xts+Xn7mfNk6Y++39458Vr2f8AZvP9sN438Cf6n+29Gb/TPveRt3Rfc43f8fOfvD7mO+R47c21xZ3ktpdwS29xC5jlhlUo8bA4KsDyCCCCDXNkjVHG43CvfnU16Tiunk4v87K+u+YL2mHw9ZfyuPzi3+jRFRRRX0x5IVbsr+fT/NktWKTOhjEg+8gPXHoSMjPuaqUUmk1ZlQm4Pmi9TtPD8Gn2nhk3KnGo3CufOJwyRAldkfYFsNuY8heB1NWJru2tEit4LCCS7lRSF2hghIydxPUCvSfBn7M/xL8WfCCDxXAdOtP3TXOm2M7stzdRH5geBtQNyV3HJBzwCDXntp8PfiP4j8YnQ9M8K6pPq8ULs1ssRjMaL1Ys2FABwM55JAGc1wynFzdpbHtU60o4eMVTs+/f/gnReGPgh8TfinaC+8L+Hrae2t5Aj3zOtpbkgjKBm4cjvtBx3x0q14y+H3ir4aeNrLRvGkMFvJJavNbT2kvnQzqXxII328suAGBAI+hBP2d4U+I+g+Hvh1YeFtS0TUPBkthbwWn9nXMQ+0LG8WBLCsZbftflsZPUmvmb9pT4l/8ACW2mmaatq1jPDfG9W3ngZZ4pPJ8uZ1boiO4VgmST94hRjPJCvKpLltodMacsO3Vtppe/XVP9Dyy5neyiSQMiGDEoWQgEsRzjHXtxziksxBL4ajSWFQYrZShErkbmUDcBuKg+px7Vl2OpJM6yaiuwIrAouFyCDjbkgdcVC00qafD8yyeUvKLg9eWIrqUH3JnmFNpxjC61tez3SXbS1unbz0Tw7cbreMzcytPJHj0AyT+Z/pXWavDo9xpekaml1psbW6n+0bO8uB5lw6SnJROXYPEV6AAEHpXBaJPu15wp/d5eZf8AgQArrtO1FPtEwWFJ4iVjlRlY7jnjaU+YEHuM9SCDVvTUywcnNKnfd2+W3Vpfezjo9c1Lw/4klW1vJ57aGYhYrjcBImeMqeVJGD6jNddceMrPRb7VNa09Y7i5vo7dLeOTogEe5mYD0JAx3P0rl/FkMdxcSanGIo2Wb7NJFESVUBcx4JAJIUbTkA5XOOcDmK0lQhVtImjm+MwHNRUtU9L62dmtPk/v1PSNP8eyeJLKfQfEkduHuB/ot1GuwJKOVDDpgnjI6Z59vOpkMdw8ZUqVYjB6imAkHIp0kjyyNJIxZmOST3PrV06Kpt8uzOTG5lWx0YvEPmlHS/Vrs/T9Rte1+FP9C/Yj8c6hZ/6Pdy6lHbSXEPySPFuth5bMOSuJJBtPGHb1NeKV7d8Wre48J/sy/D3wVd28puLmSTUpXlUxPAwBcwtGcnIN2VJJH+r6c4HgcRNVZ4TCLedWLt5QvN/kl8+uxrla5I1672jBr5y91fn+B4LRRRX0J5IUVeh09PKWS8uDCGGVRE3uQehIyAAfrnocYOak+xab/wA/11/4DL/8cquViujNorS+xab/AM/11/4DL/8AHKPsWm/8/wBdf+Ay/wDxyjlYXRm0VpfYtN/5/rr/AMBl/wDjlH2LTf8An+uv/AZf/jlHKwujNorS+xab/wA/11/4DL/8co+xab/z/XX/AIDL/wDHKOVhdGbRWl9i03/n+uv/AAGX/wCOUfYtN/5/rr/wGX/45RysLozaK0vsWm/8/wBdf+Ay/wDxyj7Fpv8Az/XX/gMv/wAco5WF0ZtFaX2LTf8An+uv/AZf/jlH2LTf+f66/wDAZf8A45RysLozaK0vsWm/8/11/wCAy/8Axyj7Fpv/AD/XX/gMv/xyjlYXRm0VpfYtN/5/rr/wGX/45R9i03/n+uv/AAGX/wCOUcrC6M2itL7Fpv8Az/XX/gMv/wAco+xab/z/AF1/4DL/APHKOVhdGbRWl9i03/n+uv8AwGX/AOOUfYtN/wCf66/8Bl/+OUcrC6M2itL7Fpv/AD/XX/gMv/xyj7Fpv/P9df8AgMv/AMco5WF0ZtFaX2LTf+f66/8AAZf/AI5R9i03/n+uv/AZf/jlHKwujNorSNhYsMR6hKG7GaDav4lWY/oaoTQyQTNFKu116jr9CD3HfPek00CYyiiikM9D/aI/5OT8Sf8Abr/6SxUUftEf8nJ+JP8At1/9JYqK8Th//kV4X/r3D/0lHoZp/vlb/FL82H7O/wDycn4b/wC3r/0llrzyvQ/2d/8Ak5Pw3/29f+ksteeVWH/5Glf/AK90v/Sqoqv+50/8U/ygdN8PPFf/AAhHxO0fxO0PnRWc375Au5jE6mOTaNw+bY7bcnGcZ4rufj/4Sl8NfGO9vorXytP1j/ToHXeylz/rgWbjd5m5ioJAEidMgDyCvonQ1/4XB+yxNowi87xP4P2/ZtkeXmgCnYg2x5+aNWQIpyzwxsx5rhzeX9n46hmf2H+7n5KT92X/AG7LR/4jqwC+tYepg/tfHH1S1XzX5HgVFFFfVnjBXt/7M/wTk+LXxJ+16vbyf8Ito7LNqD8qLhjylsp9WwSxHRA3civKPDXhjWvFvi3TfDeh2T3OoajMIbePGAxPUk9lABJPQAEnpX6m/C/wPonwu+F+neENHKyLbKZLm6xg3Vw2PMlP1IAA7KqjtXHjcT7GFluzrwmHdaXkjr4bS10+LzWIjihXIVPlRFUdABxgAYA7Yrz74d2q30uu+JLePMd5fvbQHP3YoScgen7x5c+6+1Z3x2+Klh8PPhRqV68qvfTRGG1twfmlkbhEA68n9Ax7V3Xw80BvCXwn8PeHbhjLdWVhGlzIesk7DfMx+sjua8C1otn0Lm6aS6v8v+H/ACNSSDTYLe3uNYjszMXWGN3QH5nOAi555PFU/Fvgbwl488KS+HvFGh2mo2D8iN12tE3Z43HzIw/vKQfqOK4r4va4LR/C9hFciK4m1QTIN2CfLikYY9emfwrq/DXimHWdMWUsqXKYE0Y7H1HsaSvGzRU8PKVL2j2Phj41fs7eIPhPdPrmiQHX/CbPgXDxA3FkSeEmA6jsJFGCeCFOM+Oxa1a3ml3FpHiBpArwsAOJF5UZHYgkfjX6l+NUs9W+GviCwvArQy6bcK2eg/dsQfwIB/CvzD8T6BZWniHPmrAt4qSI/QQytn5WHZSwIPcHHrXpUMQ6i5ZiwmBkk61NrR8rT2akmvl2v3a2ORguzBqUs6L5bzx7cDjac5PHrzXQ2Fz9h0U3HctvQep6L/KuburecaqsN5GIrpZGVx/dJ/8A11uNA88kcRISCMYGOprv3R4icqNRxWjT9GWCItZS5ivJMz3rq8cu7ASYbtpb2Ytt9uvauOkjeKZopEZHUlWVhggjqDXdJrOm2/h+9037P5wRdybeik5zk9+QDx3zWFrMH27xLJ5m5ZjHH53loXzL5a7+B75z75rSjN2aa2OrN6UakqeIhK7qK7XZ7Pfu9TAoqxJZzw26yyBV3HaE3Dd/3z1FV+hxWyaex4souO6Ou+GXhKXxr8UtJ0T7L59oZlnvQd4UW6ENJuZOVyPkB4+ZlGRnNaXx78V/8JV8btT2Q+VBpX/Eqi3LtZvKdt7N8xB/eNJgjHy7cgHNd94KX/hUf7OGqfEW5i8rxBr2LPSd8fzRIc7GG6M4zh5sElHWOLkE18618tgpf2jmlXGf8u6KdOPnLRzf5R87PsetiV9VwcKH2p+8/T7K/NhVzS40k1RPMUOqK8u1hkMUQsAR3BI59qp1e0j/AJCZ/wCuE3/opq+njueM9h7MzuzuxZmOSxOST60lFWtM0671jW7PSdPiM13eTpbwRjq7uwVR+JIrURVor2Lx/wDCu00vxN4bgtdNvfC2mXt2+jT3msxSxK8sLgG8/e4wkqOjgZCghwCAOM66+GFjapJavqNzYxPqem2g1DXLAWbIlwt3udClzJE0X+jj5iTkjAZArbwDy6ivVoPh/wCENLm8V2/iK78TwxWWhw39rdTaPEkis19BCZI41vCkq4fYDvwd7ngxqGoa/wDCy38P+BX1i68XaV/akdrBdvpZurTeyzBCERVuDMZAsgYhoVGFYhjxkC55xRXe+Nvh9pnheLXP7L8TS6tLoesjRr9ZLD7MBI3nFGjPmNuH+jyBshcHGNwOau6D4Q0HXPgU1xFasviqXUb1rOcStieK2t7aR7bZnbuKzSupA3ExhedwoC55rRXtF58HNO1fx14nsNKv5NGS31i7sNLt7j7P9nmEXIQSTXSzOwyAQkUhGVJJzgctpfw70y90S3e88TyWurXOjXmuQWKWBkjMMEczhGl8wYd/IbjaQFOck/KQVzgKK9C1b4YjT/hgfFcOryfaYIbae70y8S2iljSbaFZUjuZJduXXBkijyGB9q1fhR8Mz4x8PajfXHhvVNVW7nGj2M9nFKyWNw8bP9plKcBEbyVIf5dsrH+HIB3PKKK6rxXodpo/hTwjPHZtb3t7YXEt9uZstKl9cQjIJwpCxouBjp65NdNqfgNm8D6NY6F4Zgu9Xe2juNSulvW+0WUkm6RBOhbykgaAxsGwMEkM4IK0AeX0V3vwt0XwxrN/4hXxXBus7fSd8c/mun2SWS7t4BP8AKRu2CZm2nIOORXT3vwu0qLSfCfhWSL7D4nutej0nVr/c0oieZUdUEe4KfLWRM4wS24E9MArnjdFeg+B/C9rLY22v3vk3UV5aeIbcWk0AZY3tdK85JQSTk7p1I4G0xgg5PGn4j8FeEo31NPDV1cPLa+GNN1KWLULXyUjkn/s8b45RckbnN07NvXYmWVQfldAZ5XRXq/hHwloOmeF/E934uTwfPdWV1YQwXGo6hdXdmizLcsyh9Ldiznyk6kgbTnBPJp3hHwZceE73WNelkso5PDh1W3fSLOSfyW/to2m7bNcrvOwBADtGx8kb03SArnlFFdfe+Bvsba4Bqm8aXodjrWfIx5v2k2n7r73y7ftn3uc+X0G7it488NaV4Q8bah4a07XJ9Wm066mtLqZ7MWyB43K/J+8Yt05yBg5A3DkgzmaKKKACiiigAp9yol0TzG+9BMqKf9lwxIPsCuR/vN60ypJf+Rfn/wCviL/0GSk9gMuiiisij0P9oj/k5PxJ/wBuv/pLFRR+0R/ycn4k/wC3X/0liorxOH/+RXhf+vcP/SUehmn++Vv8UvzYfs7/APJyfhv/ALev/SWWvPK9D/Z3/wCTk/Df/b1/6Sy155VYf/kaV/8Ar3S/9Kqiq/7nT/xT/KAV1Pw78Yar4G+Idhr+kW73cikxS2QdlF1G3BjO3qehGQQGVTg4xXLV33wo8ZXHg3xXNdWthZXj3EYieK5hVy8ecsisfu546dcYPHFeniKFPEUpUayvGSaa8mctCc4VIzpu0k9PU6f40eAdP0i+j8c+E2s28L6tKqxwwAxmznKbmjMbcrna7YwNh3IVXC5850XT47vUFkvHSKziy8skobYQP4cqOpOB+PavbPGNhNJ4Q1Dxj8PLqc+Fbpt2o6VCNr6VICG2PF08sNgq4+7xngA15hb2lzqsxFq17ehSXZYuT05OB09ziuTLqVXCYeNCrPn5dFJ7tdL92tm+u+534iEMRWc6ceW+8fPrby8uh048R3ema3pNx4fvrmxbTws9tPBOdse05KpggDIyCD1BOd2a+t/EX7SngvS/hVF40S7ZUuQyR2jAGfzh1hCZ5YZGT90Agk4Iz8Kgvp7PapbP+8IwPU9MHj1wcD+lcf4iu47rUI7aKQTvDlWnVsq5J6D2HTPf6Yqq2HjUSb6HR9flSk5OKu/kl2svT+u/uPgvxL4j/aF/a+8InxMHXR49Q+2JZ5zFHDD+9cZP32bywpPfIAAGBX6Qz6osMUks77MAs5PGO5r8up1sdK8Orp8lo8d3aymKPySWjVAxORIp5+Yk9M9TntXo1t+0D4+sPhXF4QSKC6EFs0Ka1LLI8qLyVkfqCVBAGT/CvpWFbDOdlHodFK0G5VZczaTbWtvL1/A918Y63a+K/Et/r2oTiDStPRorS4Y48kqcvOCemCoUHvtfqDUPw6+IEPiTQY9d0ifyrmFzDcxYwUceq/3WGGHscdQa+Lh4v1e58NQaDdandmzgyY4ZZ3aHOc8p6559PYVZ8G+NtW8F+JJNU03UDG8yGOZCnmxyjsHTIzg4IIIIPsTVSwEuW3U7qecYf3Uno9/I+4/it8VLSw+Eeoae2INU1OP7FboWyjZI3t1ztC5z9QM8ivjfxBqlvq5vWv1aW74QSNJncd7s+G7/AMIGeeTisvxJ4r1vxTfvqd9eS307DaJiABGv91EXhB7fjya58zTmHyn4UDGTxW2Gw8qUbN7nHmWKwz5VSV2nq76W7dvO/wAh17JJfiO/uBuuIiI5ueWG3GSfXofqTTPtNwcWllJLJuO0h/l2exJ7+1JFd28Ftdq3zvJGFQDpuz1P0GfxxXU/Crw3H8QPi1ovhO/1ZdNivbjDXhC5QBWYgA8Fm4Az+R6V0uPJFvojzsRWWJqRl9qW/re346GD9kurGGNZFgffKGGGOcryBnHfFXraw1W1uftMSrMxGWPPzg855/Ovv/RfAfwK8IX2oeEYvBlu2pWlm1xLqOs2qXDXG0EgCWUMDuxwFAGMjgjFfLf7Tfh34d+G9b0u4+Hlhb6LLJuF1a2tw/z5G4OEJ+UL93jA6elclLEqpLkjpc65UlCHNXi5JLSztZfdruebiS3upBHdwmKbqp6EH2YU/wAL+E9D1P4k6baeIdUhstLMrXF3PeOVWaNTuMe4Y2E4ILEjAJbtisvw1aeIdft7+SKETWWn25nuLuZgi2/9wFz1ZiNoXknnsCRNeXO5EuiylQVROPvHdyfcYyPxNOr+9U6EJ8srWut43Wj9euvkctqcOWpFXhvaXk/x7XXS434t+PU8c+OB/ZkUVtoGlobHSraDcsfkqSBIEIAQuAvAUYVUU525PA1JcCMXUoiz5Ychc+meKjrbBYOlg6EMPRVoxVl/Xd7vzPPxFedepKrU3YVe0j/kJn/rhN/6KaqNPhlkguI54m2yRsHU4zgg5FdSdmYsu1d0jV9Q0LWYNW0q4+z3kBJil2KxQkEZAYEZwTg9QcEYIBqvGILtd8EsML/xQyybNvurNwR7Zz9cZL/scn/Pez/8C4v/AIqtSS7pniTVtIsXsbOW3e1e5ivGt7q1iuY2ljDqjFJVYHAkcEYwc8g4GNS6+Iniu9CR3N1p720csMqWX9mWotVaHzvLAgEflhQbmclduGLkkE4I577HJ/z3s/8AwLi/+Ko+xyf897P/AMC4v/iqBaHQj4i+KxrP9pfarDcLQ2H2X+zLX7J5Bk8zy/s3l+Tt8z58bPvc9earXvjTxBqXhxNE1CWwurdI0hSabTrZ7pI0I2ItyY/OVQAAAHxt+XpxWP8AY5P+e9n/AOBcX/xVH2OT/nvZ/wDgXF/8VQGhf1HxRrurHVzqF9539sX66nffukXzrhfNw/AG3/Xy8LgfN04GEsfE2u6ZbabBYag8CabfNqVpsVcxXDCMFwcZPEMfByPl6cnNH7HJ/wA97P8A8C4v/iqPscn/AD3s/wDwLi/+KoDQ6yD4sePbbUbm/i1qE3VxeS37TvYW7uk0uPMaNmjJjD4AZU2qQMEVe0T4oPonw3n8ORadc3F7JZ3Onx3dxPC0cEE4YOiKIPOAw7nb5xTcd23NcL9jk/572f8A4Fxf/FUfY5P+e9n/AOBcX/xVAaG/e/EHxbqHhmXQLvUoXsZoYYJgtnAkk6RFfKEkqoHcrsUAsxIAxnBIrHm1nU7jStP02S6P2XTzI1rGihfLZ2DM2QASSQOTk4AHQCoPscn/AD3s/wDwLi/+Ko+xyf8APez/APAuL/4qgNDR8Q+Kte8V3cVzr16t1LF5uxhDHFjzJnmfhFAOZJXb/gXpgVrW3xP8bWdhHaQarBtS3FmZHsLd5ZLcLtEEkrRl5ItoA8tyVwAMcCuY+xyf897P/wAC4v8A4qj7HJ/z3s//AALi/wDiqA0JbHVr/TrXULeyn8qLULf7JdLsU+ZF5iS7eRx88SHIweMdCRU9l4j1vTrK0tLG/e3itL0ajb+Wqho7gBQJA2M5G1eM44qn9jk/572f/gXF/wDFUfY5P+e9n/4Fxf8AxVAXR0V78RvF9+bfz9Rt0W3S7SGO2sbeCOMXcIhuMJHGF+dBg8cHLDDEmq1z438SXei/2VPeW7W5sV012WzgWWS3V4nSN5Qgdwpt4du5iVC4GASDjfY5P+e9n/4Fxf8AxVH2OT/nvZ/+BcX/AMVQGhLDq2oW+gXeiw3G2xvJorieHYp3vEHEZzjIwJZOAcHdznAxp6b428SaV9lW1vLdo7aybTo4LmzguIjbtO1wY3jkRlkHmsX+YEg4x0GMf7HJ/wA97P8A8C4v/iqPscn/AD3s/wDwLi/+KoDQ3Z/H/iy58LS+HptRiawmtYrKVRaQiSWGJ0eNHlCb2CGNNuWO0DaMAkHG1bVL/XNfvta1Sfz76+uJLq5m2qvmSOxZmwoAGSScAAVH9jk/572f/gXF/wDFUfY5P+e9n/4Fxf8AxVAaFeirH2OT/nvZ/wDgXF/8VR9jk/572f8A4Fxf/FUBcr0VY+xyf897P/wLi/8AiqPscn/Pez/8C4v/AIqgLlepJf8AkX5/+viL/wBBkqQ2uwbpbuzRB1YTq+PwQkn8BVG8ulmCQwgiCMkru+8xOMsfTOBx0GB15JUnZD3KtFFFZFHof7RH/JyfiT/t1/8ASWKij9oj/k5PxJ/26/8ApLFRXicP/wDIrwv/AF7h/wCko9DNP98rf4pfmw/Z3/5OT8N/9vX/AKSy155Xof7O/wDycn4b/wC3r/0llrzyqw//ACNK/wD17pf+lVRVf9zp/wCKf5QClVmRw6MVZTkEdQaSivZOA7rw58RdV0rVoblJxbTABZJowQs46fvFzg/XHc5Bya7UadZ+JZJf+Ea1RPD7zMZJLO2iHlmQnIPykMEz0AyB2A6V4hWhp+tajpkiPaXLpsOVGT8p9vSp5Va1jrpYucanPKT13to38zqvFVz4m8OabfWut3d0JZU8mNi+5Zy3G5WxyAoPPBHAOK5LQtCEWzUNQQZ2+ZDA6Bwf9qRSR8vtjnPYdfX9OXxD4x8K2XiSSGx1G4hMiR2sbZlhC43SLE3DSHHVSWCgYAzmuV1C7tpoywt2mlB3+WqPuY/TGc/rWLjZ7HZWkq0ud1HJLa+/5/kZkEUtzE0hkliB+6IiyiQ+uD0HPPT+tWr6W8g0C8gmv5UldFLWcWQiLuAzJnHzHIwoHAPJ7V0ej6N4ke3vLi206bS2Kr5d3dRFDDD1aQKRkYAwDgAAk5HWsrxBD4R07w7dR2msXGp6rPhQXOQvzgljt4zgdyetEVeVn0NU406LlB+80+trLVd9X5dE+pwlFFFdh4YqsynKkg+opWdm+8xP1OabRQAVu2Xhy6+xpqN7dx6fGV3wK2TNL3BSMc4zjDHA96z9MmtbW8F1dRiUR8rERkM3bI9BXdaD4S8d/EPUYrjSfC8kkFxz/aV6GS2CB9hO84VtpzkLubhsA4NceMxdPDQdStJRit22kvxPSwOFhV31l0ir/e7f8D1RnyeMfiLd2UNldeMtRWKGJ4FEl8d3lsQWQkHcRwOCeKzLiyF7d3VzfX9zeTyjKyys8khPHLHB3enWvXT4O+EHwlkS7+Imsr4i8QJtf+w9OXdHE37psGPIzjcSDKyq6E/ISK8p8efE3WPG9xDAtnZ6LpNspjttM05PLjVN2V3kY3sAEHQKNuVVcnPkYHN/r9X/AGOk/ZdZv3U/8KavL10XmdOJwyw0LYmpef8ALfma9ei/Fl6XXJ7bQl0a0knt9IWRpFtpJFiRnIA3SYx5j4UDJHbgAcVzGo6vEWfyZPOmYYDqCEjH+znqfesEkk5Jor2adCENIq3X1fmcFTFuWy183e3pskFFFFbHGFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAHof7RH/JyfiT/t1/8ASWKij9oj/k5PxJ/26/8ApLFRXicP/wDIrwv/AF7h/wCko9DNP98rf4pfmw/Z3/5OT8N/9vX/AKSy155Xof7O/wDycn4b/wC3r/0llrzyqw//ACNK/wD17pf+lVRVf9zp/wCKf5QCiiivZOAKKKKANHSde1jQ7gzaTqM9ox6+W3B+oPBrq3+MfxDexa1bxBLtZdpcIobH1FcHRQO7R3XhD4veN/Bmszahp2oR3QuOZ7e+j82OXAYDphl5bPysuSBnIGK7+b40/DTxjKG+I/wsja4KJJNqOlSjzp5lUJzzG4jxnAMjYwowcZHg1FeNjcgwWLrfWJRcan80W4y++LV/nc78PmmIoQ9kneHZpNfc/wBD3f8Asf8AZhvh9t/4TTxLpvn/AL37D5Lt9m3c+Xn7O+ducZ3t0+8epd/wpT4ef9F68M/lB/8AJNeDUVzf2LjKf8DHVF/iUJ/deOn6m39o0J/xcNF+nNH8me8/8KU+Hn/RevDP5Qf/ACTTf+EU/Zssj9j1D4ma3Pdw/up5bWBjE7rwzIRbuNpIJGGYYx8x614RRR/Y2NqaVsdUa/uqEfyi7h/aGHj/AA8NH5uT/U96t/i18GPCd5Dd+CvhPLd3BcSPNq04DwMhyjRFjMQckkkbei9eMcj4r+PfxK8VeUn9s/2JBHg+Tope23MN3zF9xc8Njbu28A4yM15nRWlDhrAUqntpwdSf8025v/yZtL5JEVc3xU4+zjLlj2ilFfgFFFFe8eYFFFFABRRRQAVr+FVsn8caQmowrLateRLIjEBSCwHzZBBX1HcZHGc1kUUIGev6Jpos/FGqJbwX2mwRa5Zf6HLsKyAzPhh+7BC45UA4werVWtfDmi2vxVsfPtZNTtr/AO1N9pkZDbvLtc+WEKnlT8uGIO7BwMYPlNFac/kRyeZ6Bo/gjTNShWS4h1W2aS7e3ljMiZ01VUEPPlBnJ9k+uau32g2mofCvR7nzZru4srOcxWtqwVnXz2zKcg5RccgDPI6DmvMqKXMuw+V9zsdP8FukGqpqtjf3WpWEkcf9lafKnmkOM78hXyoGOgPXtVm08F6XceF01B57xS9nNcvd718i2kQkCBxtyWOPUHngGuFopXXYLPuejS+DvCtro011P/bEkltp9peybLiNVczEKVUGM4AJzk5qvfeFdO0fXDoMpMwvNWW3ilcDzBCgBbBxwWaRVz6oa4GpGuJ2SJGnkKwjEYLHCDOfl9OSTx3NPmXYOV9z0y70jTrjwZLdS6VDBEII5FnjijjSMtBJJ8rhd7FXRIyHZsknoSMZ934L0BdIk8i5v4buHTbXUJJppEaL96wDLtCAgDOc7q5K98QatqFo1vd3Ebq5BkcQRrJKR03uFDP/AMCJrMocl2Eos9G1jwL4c0m8sBJfak1vLfR20kwjfZJGw/1iSGIICD/CGfI70uo/D3SNL0i8ubrVJhJZKILgblwlw7RmPtymyQk98qeRXnFFHMuw+V9z1+48JadZ+FJ9CDXtlZz61bxG/vHVkmXYf3keFACnOOp7c9axB4D0htV0+CWXULFrj7TmwuHQ3EnlDKFDtAG/tkfTNed0UOS7CUX3PWNa8NWl9b6RbTWmpRPZ6L5sWl71+1St5p+TOzqMkn5M47VSsfh5otzrupWC3N/O1v5XlBSURCybmWWZYpFVlPHIH9K80oo5l2Dlfc9Asvh/BdeBbrWJTLFNDZzXaSxz+bE/lk/KQIgq5A/56E98Y6att4e0/RPAmuTRQ6hcQT6bbSSX29fJm3OrMkfy8EdOSfcDv5VRRzLsNxb6npQ+H3h9NVtLWfWJlXUJHnsWDr+8tRGGXOFJ3szbRgfwtgHgVWk8GaBa6pqAuX1Zre10o35gKtBIHDhdu6WFdy/7QQfpXn1FHMuwcr7npz+GNDsNA8TWlvpl5qMyRWV1AQ6GeON1LHaRGcBTncQMEY+7jJoXHgKzj0K61aM3zWiabbXUM+5SjyyMA6528gZPA5HGa4CijmXYOV9z0ZvBPhqXxzqmg20+op/Z0RbbLMHkum+XhAkJKgZOcK5PHA5rj/Eul22jeJrjT7OW4khj2lTcwvDIMqDhldVPGeuBnr3rJopNp9ASa6hRRRUlBRRRQAUUUUAeh/tEf8nJ+JP+3X/0lioo/aI/5OT8Sf8Abr/6SxUV4nD/APyK8L/17h/6Sj0M0/3yt/il+bOT8A+J5PBnxM0XxMryrHZXSvOIUV3aE/LKqhuMtGzqOR16jrW78VPCFt4N+JFzZaZJFNo14i6hpc0MgdHtZclNrbmJCkMgYnLbN3RhXn9d74M8WaHPp1v4J+Ii3U/hnz/Mtr22P+laRIxG94iQ2Yn/AI48EfxqNw+asXTqUK6xtJc2nLKK3avdNd3F3suqk7a2TVCcalJ4ebtrdPons0/J6a9Gl0OOor1Cb4I61qson+HOu6P41sCiSNJZXUUE9uGUFfPhkcGMk7wBkn5DkKeKj/4Z8+L3/Qo/+T9r/wDHaa4hyy3vYiEX2lJRa9Yys180DyvGdKUn5pNr5NXT+R5nRXpn/DPnxe/6FH/yftf/AI7R/wAM+fF7/oUf/J+1/wDjtH+sOV/9BVP/AMDj/mH9l43/AJ8y/wDAX/keZ0V6Z/wz58Xv+hR/8n7X/wCO0f8ADPnxe/6FH/yftf8A47R/rDlf/QVT/wDA4/5h/ZeN/wCfMv8AwF/5HmdFemf8M+fF7/oUf/J+1/8AjtH/AAz58Xv+hR/8n7X/AOO0f6w5X/0FU/8AwOP+Yf2Xjf8AnzL/AMBf+R5nRXpn/DPnxe/6FH/yftf/AI7R/wAM+fF7/oUf/J+1/wDjtH+sOV/9BVP/AMDj/mH9l43/AJ8y/wDAX/keZ0V6Z/wz58Xv+hR/8n7X/wCO0f8ADPnxe/6FH/yftf8A47R/rDlf/QVT/wDA4/5h/ZeN/wCfMv8AwF/5HmdFemf8M+fF7/oUf/J+1/8AjtH/AAz58Xv+hR/8n7X/AOO0f6w5X/0FU/8AwOP+Yf2Xjf8AnzL/AMBf+R5nRXpn/DPnxe/6FH/yftf/AI7R/wAM+fF7/oUf/J+1/wDjtH+sOV/9BVP/AMDj/mH9l43/AJ8y/wDAX/keZ0V6Z/wz58Xv+hR/8n7X/wCO0f8ADPnxe/6FH/yftf8A47R/rDlf/QVT/wDA4/5h/ZeN/wCfMv8AwF/5HmdFemf8M+fF7/oUf/J+1/8AjtH/AAz58Xv+hR/8n7X/AOO0f6w5X/0FU/8AwOP+Yf2Xjf8AnzL/AMBf+R5nRXpn/DPnxe/6FH/yftf/AI7R/wAM+fF7/oUf/J+1/wDjtH+sOV/9BVP/AMDj/mH9l43/AJ8y/wDAX/keZ0V6Z/wz58Xv+hR/8n7X/wCO0f8ADPnxe/6FH/yftf8A47R/rDlf/QVT/wDA4/5h/ZeN/wCfMv8AwF/5HmdFemf8M+fF7/oUf/J+1/8AjtH/AAz58Xv+hR/8n7X/AOO0f6w5X/0FU/8AwOP+Yf2Xjf8AnzL/AMBf+R5nRXpn/DPnxe/6FH/yftf/AI7R/wAM+fF7/oUf/J+1/wDjtH+sOV/9BVP/AMDj/mH9l43/AJ8y/wDAX/keZ0V6Z/wz58Xv+hR/8n7X/wCO0f8ADPnxe/6FH/yftf8A47R/rDlf/QVT/wDA4/5h/ZeN/wCfMv8AwF/5HmdFemf8M+fF7/oUf/J+1/8AjtH/AAz58Xv+hR/8n7X/AOO0f6w5X/0FU/8AwOP+Yf2Xjf8AnzL/AMBf+R5nRXpn/DPnxe/6FH/yftf/AI7R/wAM+fF7/oUf/J+1/wDjtH+sOV/9BVP/AMDj/mH9l43/AJ8y/wDAX/keZ0V6Z/wz58Xv+hR/8n7X/wCO0f8ADPnxe/6FH/yftf8A47R/rDlf/QVT/wDA4/5h/ZeN/wCfMv8AwF/5HmdFemf8M+fF7/oUf/J+1/8AjtH/AAz58Xv+hR/8n7X/AOO0f6w5X/0FU/8AwOP+Yf2Xjf8AnzL/AMBf+R5nRXpn/DPnxe/6FH/yftf/AI7R/wAM+fF7/oUf/J+1/wDjtH+sOV/9BVP/AMDj/mH9l43/AJ8y/wDAX/keZ0V6Z/wz58Xv+hR/8n7X/wCO0f8ADPnxe/6FH/yftf8A47R/rDlf/QVT/wDA4/5h/ZeN/wCfMv8AwF/5HmdFemf8M+fF7/oUf/J+1/8AjtH/AAz58Xv+hR/8n7X/AOO0f6w5X/0FU/8AwOP+Yf2Xjf8AnzL/AMBf+R5nRXpn/DPnxe/6FH/yftf/AI7R/wAM+fF7/oUf/J+1/wDjtH+sOV/9BVP/AMDj/mH9l43/AJ8y/wDAX/keZ0V6Z/wz58Xv+hR/8n7X/wCO0f8ADPnxe/6FH/yftf8A47R/rDlf/QVT/wDA4/5h/ZeN/wCfMv8AwF/5HmdFemf8M+fF7/oUf/J+1/8AjtH/AAz58Xv+hR/8n7X/AOO0f6w5X/0FU/8AwOP+Yf2Xjf8AnzL/AMBf+R5nXafCvwhbeMviRbWWpyRQ6NZo2oapNNIERLWLBfc25SAxKoWByu/d0U1uQ/BHWtKlM/xG13R/BVgEeRZL26innuAqkt5EMbkyEHYCMg/OMBjxWB4z8WaHBp1x4J+Ha3UHhnz/ADLm9uT/AKVq8ik7HlIC4iT+CPAH8bDcflxr5lHHRlh8undyXxrWMV35tnJdEm3feyuzSnhHhmquKjZL7L3flbdLu302uzF8feJ5PGfxM1rxMzytHe3TPAJkVHWEfLErBeMrGqKeT06nrRXOUV6tCjChTjSpq0YpJei0Rw1Kkqk3OW7d38wooorUgKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA//Z",
	"ramah": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwMDAgQDAwMEBAQFBgoGBgUFBgwICQcKDgwPDg4MDQ0PERYTDxAVEQ0NExoTFRcYGRkZDxIbHRsYHRYYGRj/2wBDAQQEBAYFBgsGBgsYEA0QGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBj/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4Poor0OxsU+GkdjrOs6bHc+JrhVubHT7tG8qyi3ECaUAgtKSpCoD8mNzfMAB0HDisUqCSS5py2Xf/ACS6vp62TxdG+G/jnX7X7Tpnhu7aHYrrLPtgWRWGVKGQqHGBnK56j1Faf/CmPiV/0Lf/AJOW/wD8cp2mPr3xS+IVjpOu+IJzJP5myV0DpDtiLHbECqjPlgHGM9TmvQP+Gdf+pw/8p/8A9toem7PnMfnk8BUVPF4iFOTV7eznPTVfEpK+z6L0PPf+FMfEr/oW/wDyct//AI5R/wAKY+JX/Qt/+Tlv/wDHK9C/4Z1/6nD/AMp//wBto/4Z1/6nD/yn/wD22lddzh/1tof9BkP/AATU/wDkzz3/AIUx8Sv+hb/8nLf/AOOUf8KY+JX/AELf/k5b/wDxyvQv+Gdf+pw/8p//ANto/wCGdf8AqcP/ACn/AP22i67h/rbQ/wCgyH/gmp/8mee/8KY+JX/Qt/8Ak5b/APxyj/hTHxK/6Fv/AMnLf/45XoX/AAzr/wBTh/5T/wD7bR/wzr/1OH/lP/8AttF13D/W2h/0GQ/8E1P/AJM89/4Ux8Sv+hb/APJy3/8AjlH/AApj4lf9C3/5OW//AMcr0L/hnX/qcP8Ayn//AG2j/hnX/qcP/Kf/APbaLruH+ttD/oMh/wCCan/yZ57/AMKY+JX/AELf/k5b/wDxyj/hTHxK/wChb/8AJy3/APjlehf8M6/9Th/5T/8A7bR/wzr/ANTh/wCU/wD+20XXcP8AW2h/0GQ/8E1P/kzz3/hTHxK/6Fv/AMnLf/45R/wpj4lf9C3/AOTlv/8AHK9C/wCGdf8AqcP/ACn/AP22j/hnX/qcP/Kf/wDbaLruH+ttD/oMh/4Jqf8AyZ57/wAKY+JX/Qt/+Tlv/wDHKP8AhTHxK/6Fv/yct/8A45XoX/DOv/U4f+U//wC20f8ADOv/AFOH/lP/APttF13D/W2h/wBBkP8AwTU/+TPPf+FMfEr/AKFv/wAnLf8A+OUf8KY+JX/Qt/8Ak5b/APxyvQv+Gdf+pw/8p/8A9to/4Z1/6nD/AMp//wBtouu4f620P+gyH/gmp/8AJnnv/CmPiV/0Lf8A5OW//wAco/4Ux8Sv+hb/APJy3/8Ajlehf8M6/wDU4f8AlP8A/ttH/DOv/U4f+U//AO20XXcP9baH/QZD/wAE1P8A5M89/wCFMfEr/oW//Jy3/wDjlH/CmPiV/wBC3/5OW/8A8cr0L/hnX/qcP/Kf/wDbaP8AhnX/AKnD/wAp/wD9touu4f620P8AoMh/4Jqf/Jnnv/CmPiV/0Lf/AJOW/wD8co/4Ux8Sv+hb/wDJy3/+OV6F/wAM6/8AU4f+U/8A+20f8M6/9Th/5T//ALbRddw/1tof9BkP/BNT/wCTPPf+FMfEr/oW/wDyct//AI5R/wAKY+JX/Qt/+Tlv/wDHK9C/4Z1/6nD/AMp//wBto/4Z1/6nD/yn/wD22i67h/rbQ/6DIf8Agmp/8mee/wDCmPiV/wBC3/5OW/8A8co/4Ux8Sv8AoW//ACct/wD45XoX/DOv/U4f+U//AO20f8M6/wDU4f8AlP8A/ttF13D/AFtof9BkP/BNT/5M89/4Ux8Sv+hb/wDJy3/+OUf8KY+JX/Qt/wDk5b//AByvQv8AhnX/AKnD/wAp/wD9to/4Z1/6nD/yn/8A22i67h/rbQ/6DIf+Can/AMmee/8ACmPiV/0Lf/k5b/8Axyj/AIUx8Sv+hb/8nLf/AOOV6F/wzr/1OH/lP/8AttH/AAzr/wBTh/5T/wD7bRddw/1tof8AQZD/AME1P/kzz3/hTHxK/wChb/8AJy3/APjlH/CmPiV/0Lf/AJOW/wD8cr0L/hnX/qcP/Kf/APbaP+Gdf+pw/wDKf/8AbaLruH+ttD/oMh/4Jqf/ACZ57/wpj4lf9C3/AOTlv/8AHKP+FMfEr/oW/wDyct//AI5XoX/DOv8A1OH/AJT/AP7bR/wzr/1OH/lP/wDttF13D/W2h/0GQ/8ABNT/AOTPPf8AhTHxK/6Fv/yct/8A45R/wpj4lf8AQt/+Tlv/APHK9C/4Z1/6nD/yn/8A22j/AIZ1/wCpw/8AKf8A/baLruH+ttD/AKDIf+Can/yZ57/wpj4lf9C3/wCTlv8A/HKP+FMfEr/oW/8Ayct//jlehf8ADOv/AFOH/lP/APttH/DOv/U4f+U//wC20XXcP9baH/QZD/wTU/8Akzz3/hTHxK/6Fv8A8nLf/wCOUf8ACmPiV/0Lf/k5b/8AxyvQv+Gdf+pw/wDKf/8AbaP+Gdf+pw/8p/8A9touu4f620P+gyH/AIJqf/Jnnv8Awpj4lf8AQt/+Tlv/APHKP+FMfEr/AKFv/wAnLf8A+OV6F/wzr/1OH/lP/wDttH/DOv8A1OH/AJT/AP7bRddw/wBbaH/QZD/wTU/+TPPf+FMfEr/oW/8Ayct//jlH/CmPiV/0Lf8A5OW//wAcr0L/AIZ1/wCpw/8AKf8A/baP+Gdf+pw/8p//ANtouu4f620P+gyH/gmp/wDJnnv/AApj4lf9C3/5OW//AMco/wCFMfEr/oW//Jy3/wDjlehf8M6/9Th/5T//ALbR/wAM6/8AU4f+U/8A+20XXcP9baH/AEGQ/wDBNT/5M89/4Ux8Sv8AoW//ACct/wD45R/wpj4lf9C3/wCTlv8A/HK9C/4Z1/6nD/yn/wD22j/hnX/qcP8Ayn//AG2i67h/rbQ/6DIf+Can/wAmeVaz8N/HOgWv2nU/Dd2sOxnaWDbOsaqMsXMZYIMHOWx0Poa5avTPEVjr3wf8ZQ2eheJp3kntVuXdIhGjZaRArRksr4wSCemeMdarX1inxLjvtZ0bTY7bxNbq1zfafaI3lXsW4AzRAklZQWAZCfnzuX5iQX5nvYXM6jpxr1XGVKW00nG3rGV2l53fmktTzyiiig906n4b6NBr/wAVdE0y5MZha486RJIxIsixqZChU8EME2/j0PSq/ibXbnxN4tv9dul2SXUpcJkHy0AwiZAGdqhRnHOMmtv4Mf8AJb9E/wC2/wD6TyVx9OO55UEpZlUb+zCNvLmlO/38sfuJ7O9vNOvUvNPu57S5jzsmgkMbrkYOGHI4JH41q/8ACa+Mv+ht13/wPl/+KrDoq7HbUw9Ko71IJvzSZuf8Jr4y/wCht13/AMD5f/iqP+E18Zf9Dbrv/gfL/wDFVh0UrIz+pYf/AJ9x+5G5/wAJr4y/6G3Xf/A+X/4qj/hNfGX/AENuu/8AgfL/APFVh0UWQfUsP/z7j9yNz/hNfGX/AENuu/8AgfL/APFUf8Jr4y/6G3Xf/A+X/wCKrDoosg+pYf8A59x+5G5/wmvjL/obdd/8D5f/AIqj/hNfGX/Q267/AOB8v/xVYdFFkH1LD/8APuP3I3P+E18Zf9Dbrv8A4Hy//FUf8Jr4y/6G3Xf/AAPl/wDiqw6KLIPqWH/59x+5G5/wmvjL/obdd/8AA+X/AOKo/wCE18Zf9Dbrv/gfL/8AFVh0UWQfUsP/AM+4/cjc/wCE18Zf9Dbrv/gfL/8AFUf8Jr4y/wCht13/AMD5f/iqw6KLIPqWH/59x+5G5/wmvjL/AKG3Xf8AwPl/+Ko/4TXxl/0Nuu/+B8v/AMVWHRRZB9Sw/wDz7j9yNz/hNfGX/Q267/4Hy/8AxVH/AAmvjL/obdd/8D5f/iqw6KLIPqWH/wCfcfuRuf8ACa+Mv+ht13/wPl/+Ko/4TXxl/wBDbrv/AIHy/wDxVYdFFkH1LD/8+4/cjc/4TXxl/wBDbrv/AIHy/wDxVH/Ca+Mv+ht13/wPl/8Aiqw6KLIPqWH/AOfcfuRuf8Jr4y/6G3Xf/A+X/wCKo/4TXxl/0Nuu/wDgfL/8VWHRRZB9Sw//AD7j9yNz/hNfGX/Q267/AOB8v/xVH/Ca+Mv+ht13/wAD5f8A4qsOiiyD6lh/+fcfuRuf8Jr4y/6G3Xf/AAPl/wDiqP8AhNfGX/Q267/4Hy//ABVYdFFkH1LD/wDPuP3I3P8AhNfGX/Q267/4Hy//ABVH/Ca+Mv8Aobdd/wDA+X/4qsOiiyD6lh/+fcfuRuf8Jr4y/wCht13/AMD5f/iqP+E18Zf9Dbrv/gfL/wDFVh0UWQfUsP8A8+4/cjc/4TXxl/0Nuu/+B8v/AMVR/wAJr4y/6G3Xf/A+X/4qsOiiyD6lh/8An3H7kbn/AAmvjL/obdd/8D5f/iqP+E18Zf8AQ267/wCB8v8A8VWHRRZB9Sw//PuP3I3P+E18Zf8AQ267/wCB8v8A8VR/wmvjL/obdd/8D5f/AIqsOiiyD6lh/wDn3H7kbn/Ca+Mv+ht13/wPl/8AiqP+E18Zf9Dbrv8A4Hy//FVh0UWQfUsP/wA+4/cjc/4TXxl/0Nuu/wDgfL/8VR/wmvjL/obdd/8AA+X/AOKrDoosg+pYf/n3H7kbn/Ca+Mv+ht13/wAD5f8A4qj/AITXxl/0Nuu/+B8v/wAVWHRRZB9Sw/8Az7j9yNz/AITXxl/0Nuu/+B8v/wAVR/wmvjL/AKG3Xf8AwPl/+KrDoosg+pYf/n3H7kbn/Ca+Mv8Aobdd/wDA+X/4qj/hNfGX/Q267/4Hy/8AxVYdFFkH1LD/APPuP3It6hqmp6tcrc6rqN3fTKuxZLqZpWC5JwCxJxknj3NWvDOu3PhnxbYa7arvktZQ5TIHmIRh0yQcblLDOOM5FZVFM1nQpzpui4rlatbpZ9Dd+JGjQaB8Vdb0y2MYhW486NI4xGsayKJAgUcAKH2/h0HSitP4z/8AJb9b/wC2H/pPHRWS2ObKKkqmBoTm7twi36tIPgx/yW/RP+2//pPJXH12HwY/5Lfon/bf/wBJ5K4+qjuZUv8AkY1f8FP/ANKqBRRRVnphRRRQAUUUUAFFauheGde8TXptdC0ue9kX75QAJHwSNznCrnacZIzjArvYPglqFpbR3fizxPo+hW0iABnk3sJCM+WdxRc4Dchj93jI5pNpHnYvN8HhJclaolLtu/uV3+B5bRXrJ8J/BazP2W/8bau91GAkrwxHy2YdSuIWG09R8x4xyetL/a3wKxn/AIQvW/8Av63/AMkUX7I43nl/4eHqy/7ct/6U4/h8zyWivWv7X+BX/Ql63/3+b/5IpP7D+Bd0ftX/AAk2uWXm/vPsuxj5OedmfJbOOn3m6dT1ou+wf25b48NVX/bl/wD0ls8mor1Y/BM6l/yKfjfQ9Z8v/j4y2zys/d/1ZkznDdcdO/bhfEHg3xP4W2HXdHntI5MBZciSMk5wu9SV3fKTtznAzihSTOrC5zgsVP2dKoubs9H9zs/wMOipXt5oreKeSMrHLnYx/iwcH9aipnqNNbhRRRQIKKKKACp7KzudR1O30+zj8y5uZVhiTIG52IAGTwOSOtQV0Pgr/ka3/wCwfff+kc1BjiajpUp1Fuk39yL0MHh7TY/IXS4tYlHEtzdyypGx/wCmSRsjKvJGXJLAA4TJWpPtWh/9Cbo//f68/wDj9UK9e+G/gvw9r3gaxvdR0a0vJ7jW3sp5prySGRIBAH/dIsih3B5ACsTk8dx6GGwft5ckdzw83xuHyuh9ZxDm1e2kn2b/AJorp0+SPMPtWh/9Cbo//f68/wDj9H2rQ/8AoTdH/wC/15/8fr1XwF4I8I6rpNnc6ppUt0G128tH8yWSJ3gjs2lVCFYbTuAPY9unFUPEXw606Lw7oH/CPx+fNrerNHZ3Zdj5ls6oYwy5wCu5g3AOVNb/ANlz9n7RWt+PT/M8xcRZf9aeElzp93J2+1fXm6cre17fO3nP2rQ/+hN0f/v9ef8Ax+j7Vof/AEJuj/8Af68/+P13vxN8JeHdL0m01jwnFAtnFcyaddeTfLdh3XmOUlXbYXUN8pxjb0Fc/D4I834Q3Hjr+2rVfJuxa/YCPnbJAznPXnO3HQE5rKpgZQm4WvZX+R24XNMFiMPTxPNKKnLlScpX5m7JOzdr+trGF9q0P/oTdH/7/Xn/AMfo+1aH/wBCbo//AH+vP/j9dN4W0TSZPh94g8U3unf2tcadJBFHYmR0jUOTmWTYQxAxgYI561u+F9I8Da/pupXmr6DcaTLog/tG4treWVheWxX/AFXztlDvK4Yfwt3I3U6eA5+XVK+vXz+XRkYrNMPh/aNxqSVNqLak3q0mlbn5n8UVe1rve2p559q0P/oTdH/7/Xn/AMfo+1aH/wBCbo//AH+vP/j9ev6H4M8Ga34Q0OZtFs4b/WLTUZ44Y7i689nid/LWIljEFVQAfM5OB1Oa5m90Xw1p/wAGPD+rG00ZNT1G3uzJJfPemaRklKKYREfKBAx9/AzjOea0lljjHmbVrX3fl+OqOWln+Eq1PYxhV5ufktd7+/rpP4f3ctfL1tw32rQ/+hN0f/v9ef8Ax+j7Vof/AEJuj/8Af68/+P16vrngbw1bfDeTUYtFhhkj8P2WoLdW91JJcNcyEB98RdgsZHO7YoHOD2FK48IeHY/g7/wmS+H5RqL2CL/Zn2h9sWZCn2/G/fsOOFPy5PQrTllcotp20V+u33E0uI8DUjGSVTWagve+00mvt7a/LrbS/mv2rQ/+hN0f/v8AXn/x+mNpWla/IlnpmmLpmpyMEt0gmdoJ2J4QiQsyuxOA+/bwoKqCXFOiuB04n1H1ZLWEmn/ik/wbszm639E0S2nsf7W1YzfYfMaCOK3cJJPIoUsAxVgiqHUkkHO4AD7zIzxr/wAlL8Rf9hO5/wDRrVuyf8ij4a/68JP/AEruK4pyajdEV8TKVGnKOnPb5e63v8rX+6zDzNA/6E7SP+/93/8AH6PM0D/oTtI/7/3f/wAfqpXsPwq+FGi+MPC8+ua3d3W0zNBFDbOF24AyzEg888D275rn55dzyMdiaOBpe2rTlb/FL/M8p8zQP+hO0j/v/d//AB+jzNA/6E7SP+/93/8AH66u+8EWmm/HCPwTc6iTaNdxRfaOA2xwrAegbDAfWr2qeH9EuPC3iS+i0NtFm0bUIrWH97I32pXdlKMHJ+dQA2VwMHpRzy7kPGUfctKTUkmnzS2k7L7V9/u6nDeZoH/QnaR/3/u//j9HmaB/0J2kf9/7v/4/XsPib4eeErU+KL/SLIi20618ryGncm1uQyHdy2WVkfIzkZDegrGHhDw7/wANKXPhX+zv+JQgkK23nScYtS4+bdu+9z1/Sjnl3OalmuHqwc4uekXL4nskm/tb+8v8zzfzNA/6E7SP+/8Ad/8Ax+jzNA/6E7SP+/8Ad/8Ax+vV/CvgLwvrvhnwg7Wh/tO6eS4u0MzgXduk5jcD5vlZQUPy4yA1ZNroXhm0+Hd5rF3Z6QLlNcmsUk1SS8KeUsYYIotzndnPLe/PSjnl3KWZ0XJwXO2nb4pd2v5vJ/1c8+8zQP8AoTtI/wC/93/8fo8zQP8AoTtI/wC/93/8fqpRRzy7nrey/vS/8Cl/mWy3h6RTG/hLT41bgvBcXKyKPVS0rKG9CVYZ6g9K57XdGTThBfWTvJp90zrCZCPMjddpeN8YyV3p8wGGDA8Hcq61S6j/AMk0v/8AsJ2n/oq5q6c3ezLpylRlFptptJptvd26t2tv+BxlFFFdJ7R2Hxn/AOS363/2w/8ASeOij4z/APJb9b/7Yf8ApPHRWS2PNyT/AJF2H/wQ/wDSUHwY/wCS36J/23/9J5K4+uw+DH/Jb9E/7b/+k8lcfVR3FS/5GNX/AAU//SqgUUUVZ6YUUV2XgHwDc+ML6W7u5vsGhWeWvL9yFAAGSik8bscknhRyewYbsc+LxdLCUnWrO0V/Xzb6I5/Q9A1jxJq40zRLGS8uipfYpChVHUsxICjoMkjkgdSK9Uh8IfDn4ebJ/Gmp/wBu6wm1v7MtRuSNvkbBTIzjJOZCoZSfkJrO1j4iWWieH4vCvw2WfT7CPeLjUJFAnumOVLA9RkYO7hvugBAuD5tQot7njOjjMz1qydGl/Kvjl/if2V5LXXVnoeufGHxJfQiy0KODQNOSLyUgtFDOE2hcbyPlxg7dgXGe+Aa463TUvEniSKK4vJbm8unVGuLmQuemMszHOAo/ACs2vStH8I6t9p0zQfDGmvqXiTUT5IitzvfzGJ/d84CBApLE8DBJOBTdorQ9jLcrwmEajRpqK623a83u/mzmPG7WR8dXh08A2qlUjI4yqqFB/EKK9b+GmixXVhEvi/8AZ2TUvDsww2r20l3Z3SKR9+NpJgkv+6AM9jXsfgz4FeGfhmbfW/EAfxR4wkj3w2lrjyLbb1MZYZwv8U7YH90evRy3+u+KdSk0Y6f9lvXjSQxR3Uj7Y3zt87f2YKSM4OADjBFRHZI9eu/bVp1UrJtux8peMfg9eH4j31p8PIJ9S0FtstpPcyojKrjOxi2MkfTpjPNY2pfBX4m6XaNdT+FLuWFRktbMs2PwUk/pX2H4b8LXegO11qeiz/YdxWW9s5d8tsQcHzYyCdowMleg5wRXos2h6nHarc6cI9WtWUN5A2pMynkGJxhGOOgbGf71Vz2MXTR+YGLzTtQB/f2l3A4YHmOSNwcg+oINem+AvHfxAbU7a3kuTqGlqwWaXUFJWNSwJYzAbt3UKCW64CnjHXfFbxLofiH4n3DvpMSWOku8AM9v5FxO6/eMm4bkwQRtI4AzgMePM5fE8l8jpPfGwslPAQF5H9di5wOB1P51E5cyskZSyjBY2ShjoqUfO359PU67VNA8DeOPEE2lprEWgX0G2DT7eOJUhZCwJ+TAVmZmbCqwOSTggV5X4o8Ia94P1NbPXLPyvM3GGZGDxzKDglWH4HBwQCMgZFQX939t1CS4CeWrHCoDnao4A/LFdv4V+JDWmkP4Z8Y2z6z4dkg8gQbQZYQOV2kkEjOAMnK4UqRtwXGDjFHl5rLF0sVUxWE9+k3/AA9mklZcj9Evdlv0aZ5nRXe+OPh7FomlW3ifwveSat4buVUrcnBeBjxiTAHBPGcDB+UgHG7gqadzfB42ljKXtaLutuzTW6a6NdgooopnUFafh7UotJ8RwXlyjtbEPBcCMAv5UiNHJsyQN+x2254zjORWZRQRUpqpBwls1Y6680+4s44p2AltZ8m3u4wTFOBjJRiBnGRkHBU8MAQRSw6rqdvaRWsGpXcUEM4uo4kmZVSUDAkUA4D4A+Yc1z2na1rOj+b/AGRq19YebjzPss7xb8ZxnaRnGT+Zq9/wmvjL/obdd/8AA+X/AOKrZV5LY450qz92UYyXm7fhZ/n92xuJ4l8RRuzx6/qiM0z3BZbqQEyuu1n6/eKkgnqQcUy31/XrSK0itdb1GCOzZntkiuXUQM2dxQA/KTk5I65NY3/Ca+Mv+ht13/wPl/8AiqP+E18Zf9Dbrv8A4Hy//FVX1mf9My+qStb2MPv9f7vm/vZoJfXseny2Ed5cLazMHlgWQhJGHQsucEjJwTVeq/8AwmvjL/obdd/8D5f/AIqj/hNfGX/Q267/AOB8v/xVS6zfQ2Ua8b2hHX+8/wD5E0tP1PUtJu/tWl6hdWM+MebbStE2PTKkGntrOrtPdzNqt6ZLxdl05nYmdfRzn5hwODnpWV/wmvjL/obdd/8AA+X/AOKo/wCE18Zf9Dbrv/gfL/8AFU1iJJW/UzlQqSlzulG/e/8A9qbsPifxJbaONJt/EOqw2AUqLSO7kWLBJJGwHGCSc8dzRB4n8S22jnSLbxDqsOnlGjNpHdyLFtbO5dgOMHJyMc5NYX/Ca+Mv+ht13/wPl/8AiqP+E18Zf9Dbrv8A4Hy//FVX1qff8SHg273ow1d9+vf4N/M2BruuCTzBrOoB/s32Ld9ofPkdPK6/c/2entQde1w3T3J1nUDM8H2V5TcPuaHGPLJzkpjjb0rH/wCE18Zf9Dbrv/gfL/8AFUf8Jr4y/wCht13/AMD5f/iqX1mf9Mr6tL/n1D7/AP7UsVfsrJDENT1NZodIikCz3CjG7GCYoyRhpSDwvvk4UMwyP+E18Zf9Dbrv/gfL/wDFVnahqmp6tcrc6rqN3fTKuxZLqZpWC5JwCxJxknj3NQ6rfQ25K8/ddorum2/lovv/AAYapqE2ra5e6rcrGs13O9xIsYIUM7FiBkk4yfWup0WVtd0Cy0u1RpdTsA8SW0aktPAXMgKDks6s8m4D+HYQCFcji6KwlHmVi62FU4RhHTl28tLfkddXQ+G/HPinwjFPFoGqvbRTnc8ZRZFLYxuAYEA+49K4z/hNfGX/AENuu/8AgfL/APFUf8Jr4y/6G3Xf/A+X/wCKrH2L7nn1cDVrR5KkItdm2/8A202r2+vNR1KbUL65knupnMkkznLMx71Nfa1rOpxRR6lq19eJF/q1uJ3kCfQEnFc//wAJr4y/6G3Xf/A+X/4qj/hNfGX/AENuu/8AgfL/APFUexfcr6nW09yOm2r0/wDJTon13W5Gu2k1jUGa9wLotcOTcY6eZz82O2c1al8YeLpihm8U61IY2LIXvpTtJUqSMtwcMw+hI71yf/Ca+Mv+ht13/wAD5f8A4qj/AITXxl/0Nuu/+B8v/wAVR7F9yHgKj3px+/8A+1Ogg1rWLV7RrbVr6FrMMLYxzupgDZ3bMH5c5Ocdc1PZeJvEmmwvFp3iHVbOORzK6W93JGGc9WIBGScDn2rmP+E18Zf9Dbrv/gfL/wDFUf8ACa+Mv+ht13/wPl/+Ko9i+45YGrLeEfv/APtTSJJOScmis3/hNfGX/Q267/4Hy/8AxVH/AAmvjL/obdd/8D5f/iqPYvuafV8R2j97/wDkTViilnnSCCN5ZZGCJGilmYk4AAHUmovEd0lhoQ8PZBvHuVubxOvkFFZY489n/eSlxzj5BwwdRmT+LvFdzbSW1z4n1maGVSkkcl7KyupGCCC2CCO1Y1XClyu7NKWEm5KVW1lrZa6+bstu1t7a9AooorU9I7D4z/8AJb9b/wC2H/pPHRR8Z/8Akt+t/wDbD/0njorJbHm5J/yLsP8A4If+koPgx/yW/RP+2/8A6TyVx9dh8GP+S36J/wBt/wD0nkrj6qO4qX/Ixq/4Kf8A6VUCiitLQNDv/EniS00TTFjN1csVXzG2qoALMxPoACeMnjgE8VZ6FSpGnB1JuySu32SOg8A+AbnxhfS3d3N9g0Kzy15fuQoAAyUUnjdjkk8KOT2Da3jnxzbalYxeFPCkH2DwzZ4RI0BU3JBzubPO3PIB5J+ZucBbvxE1jStE0xfht4Vg8qwspQ97ciTc11NjkMVOGwcbs/xKAAoQZ82oir6s8HA0JZhUjj8SvdWtOL6LpJ/3n0/lXmFFFTWtrdX17FZ2VvLcXErBI4YkLu5PQADkmtD6EjjOJlJxwQeelfpd+zj8GT4T+G9x461eIT+IvEjPKkhXb9ksXYuiKDyplG1274KqfunPzD8Gf2d7hPFWn+I/i5aDStMjfz7fQLohbvUSvzfPF96KAdXZgCw+VR82R9z+LvG0+nfDi8ktZgLm5aPT7bGBtmnkEIYY9C5b/gNc9V32OihCUmorqS22habLdsURZpbtPNmkIzvjVwqj/cyeB06nua8t+CWPEWu/EDWrpN15Jr5JLdRH5W1B9AAQK9B8MeM9Jf4ueKtPtjHJDptvpumQxk/KgHnE/juwPwFedeB/E0HgT9qPXPBN7aQQWOrRl7KVlwLg5aSIn1O1pE+qAVjJtNHp4Smp0a8V8SSa9E9fw1+R66lhFFqsdr5eJLhWdcfxFAM/jgg/QVT077DpXjdfCrkQRXQ3W6MuPKkKlzGB/cdQzp7pIvYCuV+J/wAR5dH1XQtR0qFZJNP1p2uYYxlng+xkyhQOp2sCB/s1xvxk8bprHw3i8beGb5R4h0CeO52q+SyKyyY/2lOEkQ+hb1YVV+hz0MO6jV9E9L+f9fmYf7ZHwbstY8KyfEfwrCBqenhV1tI1x9qtlG37R7tHxuPdOv3BXi1p8F73UP2dI3l0pBc3Y+12l3wHWcD5FPfY6gR+m8g9q+07jxRb694Di1nTbaK7gv7JLlbV+VmjkQMYj9VYr9a820HUdFi8Gf2NYXP2uxbd9hYkEyJ18lv7syYwVON23cM5ONKb5Xc5nHoz83mBVipBBHUHtSV6p8bPh7P4a8ZXPiHSomn8PanM00NwgysEjHLwv/dIOcA4yPcHHlddBzNWdjr/AAL46uPCd5LaXcP2/Q7zKXlg4DBgRgsoPG7HBB4YcHsRN4+8A2+k2cfizwnN9v8ADF5hkkQljaknGxs87c8AnkH5W5wW4qu5+Hfiiw064uPC/iO2ju9A1dlinWWTasD5wJOSAo6bm4I2qwPygGJR6o8HH4WeFqPMMIve+3Ffbiv/AG5LZ9dmedUV0njnwnc+DfGVxpE3zQN++tJC4YvCWIUtgDDcEHgcg44wTzdJanr4fEU8RSjWpO8ZK6Ciiig2CiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAOw+M/wDyW/W/+2H/AKTx0UfGf/kt+t/9sP8A0njorJbHm5J/yLsP/gh/6Sg+DH/Jb9E/7b/+k8lcfXYfBj/kt+if9t//AEnkrj6qO4qX/Ixq/wCCn/6VUCvZvCEP/CvPgtfeNJ49msavi30/enzRqc7SMocZw0mDlWCR9zXl3hnQrnxN4tsNCtW2SXUoQvgHy0Ay74JGdqhjjPOMCu6+MOuR33jdNCslgj07RohbQxwbdgYgF8YHy4wqbeceX2yRVWu7HFmy+u4illy+F+/P/DF6L/t6WnomeeUUUVqfQBSgkMCDg9sUlFAH0v8ABx7TwhoehfakNz4i8WGbUWMhybfS7MOy5J5HmTRE477EPavcPiV4k/snwn4aYSkx22vW3nE+sSSOc/8AAlzXy58O9Xl134wavrcW9rHRfCUWnwE9IgIYYtv4sZm+pNet/E3Xbe88M6xw80em65b6oYojlpIGcI4X/vo/gwrllLRs9XA0uaXp/nb9TqJ5NY8H+GtM8YfYdYi/tiF5r64msnSP7R5ouIQrHlvlDL07VZ8eX+k/EHwraaoZpLXUtPlS4sr63bEkSOykMD3AJU49VyK898SfGP4z3HhOx1HxBJ4UPhrU7VLu38OPbSCT7MZpEXEyAHdEYhufI2krwTkV6x4U+FOq+JvhRpXivw7LFPbahalzpdw3lSqpJUqr42h1IYHorYDDbkqOWFbkjaqd88PUusRH3Vsum2n5KxlfC5PFfiv4qXmp+INd02zFgXuHvzbCaOVjEsA2xMQAzBHbuBgnGK5z4i+GdE0nV2Hw4+ImjeJLi53Wr6LBcwNcgNuZohBHyyffZcDKc9jx6B48+Emo6x8AUMei6npqaUv2jXNEgm+zy615RiTiZQ2IvJV2wM/NkkHbz8+aB+zdqd14litbvTNOtBeLdPYPFOAyL5R8iUMpBIWQx5JGfzrJVG5c7lY7sLg6k4Sq0bcsd7tL8D2/4c6/caV8BvBUFyZFuYriGxKSZVgBcPEQQfQfyrGs9N0X/hYniexm0yxuoLh0v4S+VYCUZ52kbk3hgc52kg+tc5pt3bQ+N/CngbS7mW4ttLme+ubqRy7ShJHkMjkknJynXuwFcRrPjC80z4pWeo20oPkz3Gmyo33XiLLIgPsBLx9K76Urq55+LwjU4wXxSvL5a2/Bfidp43TVrnQrjWfAd0sEyK0N5oU8KTQT7RyjRMCN3BwejYHcivk7Ub06jqMl21ta25c58u1iEUY+ijgV9FXviWey8aaVrFrIY4NTufskyE9ZMCSM/UNx9D7V4Z47trOz+JviC10/b9mj1GdYwvRV8w8D2HT8K7Le7c8OsrM56iiipMT1uzh/4WR8A5dNWPzdd8OYMG1MtJEAdqDCfxIrKFHJaJCTzXjFdx8N/ETeGviLYXbSIltcMLS5MjBFEbkDcWIOApCt2+7jIBNVfiZ4bfwx8SdQtFjjS1uGN3aiNVRRE5JChQTgKQydvu5wARWVrOx8/gF9Rx1TB/Yn78PLX319+qXZnI1oaFbQ3ninTbO5TfDNdRRyLkjcpcAjI56Gs+tLw7LFB4w0qaaRI40vIWd3OFUBwSST0FM+gPvfxd8Hv2bdA/ao8NfBGP4I3k7a/pv24a1aeIL4taZadcGFnIKjyMli3G7pxz8q+L/g5pNl+1d4i+FOh+N/D+k6dYXMiwav4nvxa26KED+XJKFI3gkp05Ze1fX/AMU/2s7fwh+1z4T0vQvGeh698N73TYY9YXTpbe6jglknmRpfPjyysiiJim7G0dMtmvKtF8I/s2eGv28dUXxP4n8L674G1KxfUNIlbU47yzt7t5F3Q3LqzAbcTFfMOCCmcmsotrct2PHPGX7NHjXwp8NLvx/pviTwZ4y8PWUgjvL3wpqv25bUkgZfKLxllzjOMgnA5rQ0b9k/4haz8PPC3jZPEPg2x0bxFgQXGo6k1sLYtkKJi8YG5iNqqhdiTwMAkfS994++Hdp+y98W/CkviD4K6dq0thKtrZeBQtpDd7om8sAuwNzMMcmNcLkDJJIHknxV8Z+F7/8AYS+C/h3TfFWj3WqafexyX2nW99G89rhJBuljDbkxu6sB1pqTYrI5S2/Yw+L8njS78L3134U0vUELfYY7/VRGdWCoHZrRApeRVBGSVUDkHBBx5z4V+Emp+IfH2t+D9Z8XeD/BOo6Mzx3R8WamLGMyJJ5bRo4VgzA5OB2Gc19gfEb4j+A77/gp98MvE1l488OXPh6x0No7jVIdUhe0t5CL4FXlDbFY7o+CQfmX1Fcp4Iv/AIC63+1X8Z9V8aX/AILv9QuLySbwvdeIrhX0eZiZCzM4JjYFvJ55O3dt5zRzOwWR4B8Sf2fPGvw18FWPjO41Tw34k8M3k32ePWvDWofbLYSc4UttU87WGcEZGM5wK+kfjn+zjF4zHwutPh/p3gfwh9r0VVuLu7eHTEvrp1iKRjYm+eY/McBWI7kZGZPi94+8Bal+wFrfhay8QfC6PX4tWhB0nwSq2ls5W4jLPBA7eZINucy7QGwccDJw/j7478Iax8S/2eZtH8ZaJf2ukLaNfyWmoRSpYsJbYsZSrERkBDndj7p9KV2wsj5T8feBPEfw1+IWo+C/Fdoltqlg4WRY33o6soZXRu6srAj68gHIr079lL4S+G/jD8eP+Ef8XxajJo9rYSXkiWYZRI6soWOSRR+7U7mOcgkqADk1d/bK8Q+H/FH7Vmpav4Z1zTdZ097G1RbzTblLiJmEYBAdCQSOh5rrv2ZvHPg2P9nr4g/Cq98c2vgDxTrkq3Fh4hupTbxsqqgETTDGwAq4OSOJmxkgiqbfLcVtTh/i54P8O3vxBn8A/Dn4HeLfDXjHTbqSO50m3vJtYW5t1BImVSpkBPysCMoVbOeleGSRyRStFKjI6EqyMMFSOoI7Gv040r4leCE8Em81r4pfCjUPjXp/h650+08RQ6msdpKGI2bp3CoXLBCV653lQFZq/Mm4jkhvJYpnR5EcqzJIJFJB5IZSQw9wSDRB3Bo+oP2Wfg/8M/EfgDxf8UPjTp/2jwppcsGn2xa5mt1E7uu9y0ToTjzIVxkj94eMgVynxq+Eun/Cv9s2DwjZaeF8O3l/aXmnQTEyqbWWQAxkuSWCsJE+YkkLznNew+KfiZ8GfhV+yZ4D+EV3oGkfFCK+gOo61baR4mNsttdblkxJJbBix3yMoUkcRA46Yi+Mnjz4c/GH4S/Cn4n6dqmiaF4g0XV47K98PXOsxz3kFp54UMxcrJIqmJH3FfuysSeCaSbvcehD+0D+zlqHjb9rW+0H4Y+HvDvhfQtO0GC9v71ol0/TbP8A1pLSGNCAzBeyk4BJwASPFPA/7NfjX4kaF4q1fwVrvhnVbTw7c/ZpJEuJoxeHGd0BeFRsx/FIUHc8c19l/Fr4w/CD4p+IPEXwI1fx/pWk6XqmnQ3mn+LtM1ONrM3K7iYLl1fYQNinaxwwOPlYIT4b8KNU8PfDz9k747+B9W8deFf7YmV4LIWesQSjUVMBXdbEPmVWBx8vIzggHIpJuwNK547b/AaSb4gT+FJfjD8JbV4bBL5tSn8RAWRLOU8gTCMgzLjJQDgEHNR/En9nzxr8NfBVj4zuNU8N+JPDN5N9nj1rw1qH2y2EnOFLbVPO1hnBGRjOcCu5/ZMT4Lvf+Lj8TP8AhFf7fWzQ+Hh4tbbppkxJu83Py/e8nOedu7bzmvXPi94+8Bal+wFrfhay8QfC6PX4tWhB0nwSq2ls5W4jLPBA7eZINucy7QGwccDJbk07BbQi+On7Odv4wT4XW/gKy8C+DVu9FVbi7vXh0xL66dYikY2JvnmPzHAViO5GRn5A+IPw+8UfDDx/e+DvF9iLTU7XBIRt8cqMMrIjD7ykd/qDgggfZvxktvhr8Xbv4QWtl8cvBWizaFpySXou9TQoiYg3hJEJVJ1Mf+rkKbuMH5TXhf7Y/wATfC/xR/aO/tPwhdJe6ZpmmRaWL6MfJcusksjOhPVQZdoPfbkZBBog3sDPn6iiitCQooooAKKKKACiiigAooooA7D4z/8AJb9b/wC2H/pPHRR8Z/8Akt+t/wDbD/0njorJbHm5J/yLsP8A4If+koPgx/yW/RP+2/8A6TyVx9dh8GP+S36J/wBt/wD0nkrj6qO4qX/Ixq/4Kf8A6VUPUvglBDaaxrviy7ijlttH09nZQoaUM2WzHnjOyORc5H3sdCa4C9vLjUNSuL+8k8y4uJWmlfAG52JJOBwOSelei+Ff9G/Ze8VXlt+5uJL5IXmj+V3jzANhYclcO4x0+ZvU15nVw3bOXLEquNxWIe6koL0jFP8AFybCiiitD3QooooA93+EUNrafB+8vcqtzrHiS00Uv3VfJeRQfZiXH1rS8R6dqVnoA14kTWM1qY5ID/y0iOYzGfcKq899vYgGvDtN8RavY6Dc6FZTOLe6uYLsKudyTw7hG6Y6MBI4/H2FfQvg/wAX23jTTIfDevvbQX2owTWnlrhVW9R2kRQM8ebHcSgD+/Ft7gVlOOlmejg8T7OcZLp+XX8D3T4OwaX8Tfg/4XudR024S60cSWpuJ7EGK5+bbNgtlXVyqsy9VkDH+I7vorRNJh0fQrTTLAbbeAHG77xyxYnAAHJYntivz0+FPx91b4EeJdW8MavYR6lopuvPmsJJPKliZgAZoXII5wAykEHAPynJr6q0j9q34G66beDVtdfQrrCzpBrdo0YQkZVhIm9Oh4O4cGvDrUZqTtse9i60uVU7+6m2tdN/6/pnt7XNvJcPZRXMZuFTe0at8yqTjJHavL/H/h/X7TwndW/grTdOtLq4jaF799kMdhCR88gCrudgM7VGBnkkYwaupftIfCLT5FtNC8QJ4l1Gc5j0/wAOwm6llb3IARfcswx3r56/aS+MfxFv9O0nQbd4dB0bWBKLi0tJd8+xduRLNxwQTkIAvGNzVjGm5SUR4SFWPvRXuuxwnhKZdA8HapqLXAm1PWbgafZTYw3lA8Y64HzAnnrjrXmup3323x7cEsPKkvXaLB++FwufyQfrUkOrX9xfRPHJ5cVtbstr8pIiLAhXxwMDLN1yxCnoK5mG1SOa8lkvJpJrSBpYrhcIFKkADHOQScY969ynqlEnEVoU8ROtdP5/f57fK99Tb8ceL1n1/TbbR2Bi0mTzhJ/DJcEgsw9l2qo9dpPeuEllknneeZ2eR2LMzHJYk5JNaei6nLZ+IRcCKKVJiUmhkQMkiN1Ug547+oxkVNrOlWyQDUdJy1rnbMgbd5L56eu08YJ78HtXVzNysz5ecU486lrfb9TDooopmIV6f8T5G8SfC3wj41IjMxVrK7ldAkssmOvyjGzdFMQMjG8YHJx5hXp2n/6V+yfrv2r999k1JPs/mfN5OWhzsz93779P77epqJ9GeFnKVOrhcSt41FH5T91/o/keS0UVJb2893dxWtrBJPPM4jjiiUszsTgKoHJJJwAKR7pHRV0aRqxe9QaXelrDJuwIGzbYbafM4+TB45xzxVKgAooqzdafd2drZXFzFsivYTcW7bgd6CR4yeDx88bjBweM9CKAK1FdC3gTxpFdWdvc+FdXtGvbiO0t2u7V7dJJXOEQO4Cgk+prnqLAFFFFABRRUrW1wtml20Eot5HaNJip2MyhSyg9CQHUkdtw9RQBFRRWndeHPENjo8OrXug6nbafMFaK7mtXSKQMMqVcjBBHIweaAMyip5rG9trS3urizniguQzQSyRlUmCnaShPDAEEHHerTaBrq6xLpLaLqIv4UMktobZ/NjULuLMmMgbeckdOaAM6ipzY3o0xdRNnOLNpDCtyYz5ZkABKBum4Ag464NPGmaibpbUafdee0P2hYvKbcY9nmbwMZ27Pmz0289KAKtFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAHYfGf/AJLfrf8A2w/9J46KPjP/AMlv1v8A7Yf+k8dFZLY83JP+Rdh/8EP/AElB8GP+S36J/wBt/wD0nkrj67D4Mf8AJb9E/wC2/wD6TyVx9VHcVL/kY1f8FP8A9KqHrWr/APJp/hj/ALCT/wDoVzXmNenav/yaf4Y/7CT/APoVzXmNaU9jlyH4K/8A19qf+lMKKKKs90KKK0dCsJNS163s4ohK7uAsZ6O3YH2Jxn2zSbSV2VCEpyUIq7Zu6BpFzGgNtGft0qbmm/59YyOMekjDv/Cp9TxTn06SSa6aAN5Vpt2+WSCCG7d88MfxFeu6c/hWwdNAi1e3uNS3ZlWPLvLKfvdAQWz0Uc9q5PRbnRNItZLfxBFO0ks7SGKNkw4YnG5w42gYHA5OTyvfz1XlUk9D7atlOGwNCEKk02781tbO1lHTbV/gcdfHxP8AEfVY7nX0t5pNOVYrjWpT5bXEfVFkKj95IRnBA3HktwCRrSraatJcJJDHY3VuNkCP8pVMBUjP94YCgMPTPOSKua7rFvFauLWCK1SJCtvbx/cQN94j1JPzEjv9KW8sDe2FpbSMVZ2LO6nBAjQcj/gcg/KrbseLh6fvO2tlrfr2X321369re42dr4W+DPwW0PXdHntrrVPElhHcb5JjI7bciR5F4CKjlkCggEjGflYjxPWtYuNf8XuZ5JtX1F+mMzD/AICijLfThRjGABUUehXV9c2kNzfXUttDJHGqNIWCAvnA9ASWOPUn1JrqfBuup4X8L6xqelMINV1FJJjMsBLCMswAEvRSGydv8XygZPFZUaSjJt6s6sTiqn1aKh7sb2Xn3+7T1d2+luSkm1e8LWkWlBcP5bPdsuN3T7o44PHXrWRpySQ6rd2erWkUCtHJFcRqPlUbSQ4/3SAw/LvXVW1yjxyoF3FZWhjGeW2gZJP55NUPEum3d0j3NwIVaWMEEMFZtn3sjO7BXJPHVRW8J8s12MHhVVw0pRTc016Wfft5M4WxRjch1HzfdX/ePA/Lr+Fb2nR3MQme2jErouyaNuVnTlSG+u3OexNbfhjw2pm+1ygPt+VRjC574Fa/hzSGXxpq1mF4jAbHs20j+ZqKuIV210PSy/h+SVNVl8ba9PdbX4o8x1O0jtbzNuWa3lG+It1x6H3ByD9KpV6N498KNpcZuI4z5E7GRMD/AFcgGWX6Moz9VrzmuqjVVSPMj5vM8vqYDESw9Tdfl0CvT/hj/wAk0+In/YM/9pT15hXp/wAMf+SafET/ALBn/tKeqn8J8nxJ/uEv8UP/AEuJ5JW94IuILT4neHLq6njggh1S2kkllYKqKJVJZieAABkk1g0Uj3T1O08Y6JfaRq9tKZLa4vrBm1SWRlUXUsZjjjEXOWYr5jnPJZ24wM1NqP8Awh/9rW39rf8ACNf2f/bkX2H+y9mf7Pw+/wC0eV8+P9R/rP3n368moquYnlPUT/Yn9qaT/bH/AAin9tbL7/jz8j7D/ql+yed5X7rPmeZ17bN/GawfiDcRz/8ACNxCfSZLiDSTHcrpTRmGOX7XcMVAj+UHDAkLx82RwRXGUUXHY9o1mfT1+Oum68tr4RttP/4SaC4OrWWtLNNLH5+d8kf2lwi4+Yny1xgdBwebszoY8YaTLpdlo11o/wBmkEMN3cWsE0b7MM1wbg7GkViGAbKMBhQOQPO6KOYXKetw2VssHim50y48J392l/pqQ3d/a2cNugeC4aSNB/qARtAO07W2FhlttVta1DwMni7w5ptpbaR/wjryvJfzW8CmUr9vuNqtJgyKojEeBwxQrnPy15ktzcLZyWizyrbyOsjwhiEZlDBWI6EgO4B7bj6moqOYOU9bvZ9FbxdpBTwv4eXalyDKut6VJHICgCMyrHHCpQncolXL5IOccc747j0aLSrZbC/0u9vDqVy00tlb28BEZtrQqpWD5Nqv5ygr8pYOR1NcNRQ5AkWrjz/7Os/M+y+Vtfy/K8vzMbjnzNvzZz03846cV6fc6n4e1HTrnRNPu4rbVb7w7p1s95d38f2N/Kjgd4sbV8qQeXjLM3KsuFLDHk1FJOw2j0/xdqPhLWPCt/pOka5czNozxPp8d3bRwRmJVWCVYnErGRnIjl+6p+VjjnA3rrxzoUvxO1ZluE+2TXN5ZvqXmp9nlsh50kYD55YuY19NsaAE5rxKinzC5T1S7uvCb+DJfBMfiCVprfTVljBhiFmb2PdO7rced8xIeWEfIAfkGeBmSLxLoC+KbGBtN0Msvhlbc6ubmbzVk/ssps/13lbt37vBTOePvc15PRRzByhRRRUlBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAHYfGf/kt+t/9sP8A0njoo+M//Jb9b/7Yf+k8dFZLY83JP+Rdh/8ABD/0lB8GP+S36J/23/8ASeSuPrsPgx/yW/RP+2//AKTyVx9VHcVL/kY1f8FP/wBKqHrOh/6V+yjrv2r999k1Nfs/mfN5OWgzsz93779P77eprzKvSvgmf7SbxT4T/wBV/ammH/SfveVtzH93+L/X56j7vvx5xNDNbXMlvcRPDNGxR45FKsjA4IIPIIParh1Ry5U1SxeLw735lP5Siv1T/MZRRRWh7oVcsdRuNO82S0by5pEMYlH3kB4OPQkZGfQmqdFJpNWZUJyg+aLszuvDVpp1p4b+1iQpqVyrss2cGOIEpsjzwGchgzHovTqanlu7WwhhSCxt5LyWNSqABtpPYk9QBgnn19K9G8GfszfE3xd8HbfxZB/Z9piFrnTLCd2W5uoidwPA2oG5K7jkg54BBPCaZ8NviZ4w8dx+GtL8NXv9sRRSHyZlMCQIvBdnfChQSB15LADOa4pzi5u0tj3aVflw8YqnZ9++vXz8/wAO0E3gnxl4j8PTa7pPhW81O2sDm5n0mxd0QAgsCyrg8dccjvim6TfxXGrW7yXOFWJ9ihTuIZvmxx6AV+h/g/xZY+C/h1oHhO60RNB1KxsxBNpwdWWOaOJZWVXThvNQSMkg6srA8givj79py08NxfFGHX/Dl+Y7y6MgnhhQLHJKjfNcpjGwurQllI5JYjjOeWniPaS5GvQ3pqWHk6yjppf70/0OJu5nsYo3R0QwbZQshUMWK849eg4ycUyzFtL4WjjmgUGK1Uo4lcjcyhd2NxUH1OPasiw1ZZ5Ul1AbPLVgY0woIIONoJAHOP1qB7iZdNgAdZfJXlFIPXliMe9dKpvuFTMKTTjGF1ra9nukuq0tbp289F8NXBa2jabmVp5IyPQLkn8z/Suv1aLRrnSNI1JbrTo2twf7Ss7y4HmTukpyUTl2DxleAAAQa880K43a/IFbMeXnX/gQAzXZabqY+0TCOJJ48rFIjKx3HPG0p8wYHuM9SCDVS01McE3O1K+7t8np1aXpdnFRa/qnhzxRKLS8uJ7eGYqsNyWAkTPGVPKkjB9RXY3Hjez0S/1bW9NRLi6v47ZLaOTogEe5mbHoSBjufpXKeMLdJ7mTVEMSyLN9lljiJKgBf3eCQDkKNpyAcrnHOBytaTw8KtpEUc4xmX81FS1T0vrZ2cXbfo/vsz06w+IUviixuPD/AImitxJcD/RbuJNgSUcoGHTBPGR0zzx081njMVw8ZBUqxGD1FRgkHIODTpJHllMkjFnY5JPUn1q6dFU2+XZnJjsyrY6EXiHzTjpfq12fo/zG16doP+jfsueKry2/c3El6kLzR/K7R5gGwsOSuHcY6fM3qa8xr0/4iRTeHvgb4O8L3ELmaZ3vnaRTG0TAFjGUPOQbjGcj7nTni59EfIZ21UnhsMt5VE/lD3n+SXzPJKKKKR7oUVeh09PKWS8uDCGGVRE3uQehIyAAfrnocYOak+xab/z/AF1/4DL/APHKrlYrozaK0vsWm/8AP9df+Ay//HKPsWm/8/11/wCAy/8AxyjlYXRm0VpfYtN/5/rr/wABl/8AjlH2LTf+f66/8Bl/+OUcrC6M2itL7Fpv/P8AXX/gMv8A8co+xab/AM/11/4DL/8AHKOVhdGbRWl9i03/AJ/rr/wGX/45R9i03/n+uv8AwGX/AOOUcrC6M2itL7Fpv/P9df8AgMv/AMco+xab/wA/11/4DL/8co5WF0ZtFaX2LTf+f66/8Bl/+OUfYtN/5/rr/wABl/8AjlHKwujNorS+xab/AM/11/4DL/8AHKPsWm/8/wBdf+Ay/wDxyjlYXRm0VpfYtN/5/rr/AMBl/wDjlH2LTf8An+uv/AZf/jlHKwujNorS+xab/wA/11/4DL/8co+xab/z/XX/AIDL/wDHKOVhdGbRWl9i03/n+uv/AAGX/wCOUfYtN/5/rr/wGX/45RysLozaK0vsWm/8/wBdf+Ay/wDxyj7Fpv8Az/XX/gMv/wAco5WF0ZtFaX2LTf8An+uv/AZf/jlH2LTf+f66/wDAZf8A45RysLozaK0jYWLDEeoShuxmg2r+JVmP6GqE0MkEzRSrtdeo6/Qg9x3z3pNNAmMooopDOw+M/wDyW/W/+2H/AKTx0UfGf/kt+t/9sP8A0njorJbHm5J/yLsP/gh/6Sg+DH/Jb9E/7b/+k8lcfXYfBj/kt+if9t//AEnkrj6qO4qX/Ixq/wCCn/6VUNzwb4g/4Rbx1puumLzI7aX96gXJMbAo+0ZHzbWbGTjOM11vxe8PPonxJubqODZZ6j/pUTDcQXP+sBJ/i35bAJwHXpnFebV7PpI/4WP8A5NMEfma54bx5G1MtJEAdqjCd0VlCjktEhJ5qr2dzhzR/UsXSzD7PwT8k37r+UtP+3jySiiitT6EK9x/Zl+CT/Fv4lfa9YgkHhbR2WbUH5UXDHlLZT6vgliOiBu5FeTeGfDGteLvF2m+G9CsnudQ1GYQ28eMBiTySeygAknoACT0r9Uvhb4G0T4W/C/TvB+jFZFt1MlzdbcG7uGx5kp+pAAHZVUdq48ZiPYwst2deEw7rS8kdhFaW2nw+YSscUKZCp8qoqjoAOMADgdsVwPw9tlvZ9c8S28eUvL97aAj+GKEnIHp+8eXPuvtWX8dvirp/wAOvhRqV+8qvfTRmG1t8/NLK3CIB15P6Bj2rufh5oL+E/hR4e8O3LmS6s7CJbmQ9ZJ2G+Zj9ZGc14KXutn0Tm6cbPd/kv8Ag/kP1fw14Z1GO3u/E1jaSXIxbRTbmRgXOFVSCDnJ+U9QSSMZNUNS+Enw61nwXP4X1LwtZXenTHc3nAtMGGdriYnzAy5IBDcDjpxWB8XddFnL4Y0+K4EdxNqgmQZwT5cUjDH5Z/Cur8N+J4dY01ZSQlwmBLH6H1HsaSbjqhzoVJUlPo+h8K/Gr9nXX/hLdPrmhWo1/wAJu/Fw0QNzZE9EmA6jsJFGCeCFJGfH4datb3SrizjxA0gWSBgowJV5UZHZgSv4iv1K8bR2eq/DTxBY3YVoZdNuFbd0H7tiD+BAP4V+Yvijw9ZWviTd5ywJerHJE+MCCVwflcdlLAg91JB7mvRo4h1FyzHg8FJJ1qb2fK09mpJr5dr9G1tucbBeG31Sa5VPLeeLbtHG05yTjsec10enXYsNENyDyW3qPU9F/lmuavLe4XWFgvohDdrI6yD+6T/TnitwwNPJHCSEt4xgAck16Cs0eHeVGq4rRp27P/gFlxFriXMV5L++v2V45ScBJgG2lvZi232zntXEyRvFM0UiMjoSrKwwQR1Br0GLWdMt/Dl9pbW3nqi7kCYwpOc5bqeQDgd81z+uW4v/ABRIZGZJ2jj87yoy+6by138D3zk+uaujJqLTWx15vRjUlTxEJXdRXfSzvZ793qc5RVmWxuILZZpVVQzbQpYbv++eoqt0OK2TT2PDlCUfiVjovA3h5/E/jzT9L8jzbfzRLdA7gohU5fJXlcj5QeOWAyM1b+LniD+3/ilfbYtkWn/8S9Mrhm8tm3E8nPzl8dONvGc11/hkf8K7+Ct/4zmj2axq2LbT96fNGpztblDjOGkwcqwSPua8XrNu7ufO4N/XswqYr7FK8I+b3m/yj52YVc0uNJNUTzFDqivLtYZDFELAEdwSOfaqdXtI/wCQmf8ArhN/6Kaqjue+9h7MzuzuxZmOSxOST60lFWtM0671jW7PSdPiM13eTpbwRjq7uwVR+JIrURVor2Lx/wDCu00vxN4bgtdNvfC2mXt2+jT3msxSxK8sLgG8/e4wkqOjgZCghwCAOM66+GFjapJavqNzYxPqem2g1DXLAWbIlwt3udClzJE0X+jj5iTkjAZArbwDy6ivVoPh/wCENLm8V2/iK78TwxWWhw39rdTaPEkis19BCZI41vCkq4fYDvwd7ngxqGoa/wDCy38P+BX1i68XaV/akdrBdvpZurTeyzBCERVuDMZAsgYhoVGFYhjxkC55xRXe+Nvh9pnheLXP7L8TS6tLoesjRr9ZLD7MBI3nFGjPmNuH+jyBshcHGNwOau6D4Q0HXPgU1xFasviqXUb1rOcStieK2t7aR7bZnbuKzSupA3ExhedwoC55rRXtF58HNO1fx14nsNKv5NGS31i7sNLt7j7P9nmEXIQSTXSzOwyAQkUhGVJJzgctpfw70y90S3e88TyWurXOjXmuQWKWBkjMMEczhGl8wYd/IbjaQFOck/KQVzgKK9C1b4YjT/hgfFcOryfaYIbae70y8S2iljSbaFZUjuZJduXXBkijyGB9q1fhR8Mz4x8PajfXHhvVNVW7nGj2M9nFKyWNw8bP9plKcBEbyVIf5dsrH+HIB3PKKK6rxXodpo/hTwjPHZtb3t7YXEt9uZstKl9cQjIJwpCxouBjp65NdNqfgNm8D6NY6F4Zgu9Xe2juNSulvW+0WUkm6RBOhbykgaAxsGwMEkM4IK0AeX0V3vwt0XwxrN/4hXxXBus7fSd8c/mun2SWS7t4BP8AKRu2CZm2nIOORXT3vwu0qLSfCfhWSL7D4nutej0nVr/c0oieZUdUEe4KfLWRM4wS24E9MArnjdFeg+B/C9rLY22v3vk3UV5aeIbcWk0AZY3tdK85JQSTk7p1I4G0xgg5PGn4j8FeEo31NPDV1cPLa+GNN1KWLULXyUjkn/s8b45RckbnN07NvXYmWVQfldAZ5XRXq/hHwloOmeF/E934uTwfPdWV1YQwXGo6hdXdmizLcsyh9Ldiznyk6kgbTnBPJp3hHwZceE73WNelkso5PDh1W3fSLOSfyW/to2m7bNcrvOwBADtGx8kb03SArnlFFdfe+Bvsba4Bqm8aXodjrWfIx5v2k2n7r73y7ftn3uc+X0G7it488NaV4Q8bah4a07XJ9Wm066mtLqZ7MWyB43K/J+8Yt05yBg5A3DkgzmaKKKACiiigAp9yol0TzG+9BMqKf9lwxIPsCuR/vN60ypJf+Rfn/wCviL/0GSk9gMuiiisijsPjP/yW/W/+2H/pPHRR8Z/+S363/wBsP/SeOislsebkn/Iuw/8Agh/6Sg+DH/Jb9E/7b/8ApPJXH12HwY/5Lfon/bf/ANJ5K4+qjuKl/wAjGr/gp/8ApVQK3/BfiPUfC3jO01bTYGuZATG9qrMPtCNwU+Xr2I4OGCnBxisCvQfhJ4zn8GeLZrq2sLG8e4iETxXMKuZI85ZFY/dzgeucYORxVPY9Cph4YmDo1FeMtGu9y98TvB1tpd2ninQRANC1BwEijUxm3lK5KFG5GcMcYG05UhcDPI6Hpsd5qCyXrLDZRZeWWUNsIH8OQOpOB+Pavb/GWmPP4RvvGvgCef8A4Redt9/pUS7ZNIlGDsePkeWDyrrjbxnjBrzG1tLrVZtlq17fKDvKxYJ6cnA6e5xUqo0tS8uy6pQpxoTqObjorrVron3fS/Xfe50p8R3Wma1pE3h28urA6eBPbTwXB2xlcZVMEAZGQQeoJzuzivrnxD+0t4I0n4UxeNFu2CXG5I7MgGfzh96EJnlhkZP3QCCTgjPwr8+ms9pHbMQ+ODzk+h/HBwP6VxXiS8iu9RS2hlFw8JKtOGyshOOB7Dpnv9MVx1sPGok29j3nj3Tk5cqu/KyXRWXp/Xf3LwZ4n8SftD/tgeEW8Th00eLUPtiWe7MUcMP71hk/fZtgUnvnAAGBX6Sz6mIoXlmcIBlnJ7dzX5dzJp2keGV06SzZLu1lMcXkkvGFDE5Einnkk9M9TntXo0H7QHxBsPhUng9YYLoQWrRJrUksjzInLLI/UEqpAGT/AArnOKwrYdzso9DoppQfNVlzNpNta28ttHp6HunjHW7bxV4k1DXtQuRb6TpyNFZ3JIHklDmS4U9tpUKD32v2bmP4c/EGDxLoMeu6TMIrmFzDcw4wUceq/wB1hhh7HHUGvipPGWq3PhmDQLvU7s2cGTHDLO7w5znlOxzz6Z7CrXgvxzqvgvxPJqunakYzMhjmQp5scq9g6EjIBwQQQQfYkU5ZfLlfc7qecYa0Ip6Pfy9T7m+K3xStbD4TX+nbhBqmqIbO3UnKnON7dc7Quc/7wGcmvjbxBqlrrD6g2oK0l2cRiVpMhjvZnIbvztA3c8nGKyPEnirXPFN8+p3t7LfTMNonOAI1/uoi8IPbA9eTXOme48jym4UDGTxxW+Gw0qas2ceZYrCvlVFXknq76W7dvO/yJr+SXURHqNz89xCRFPzguuMbifXkH8TUP2m4Yi1spZn3HaRINuz2JPf2FJDe28FreI37x5IwqAdN2ep9gM/jitv4fQaBr/xH0rSvGXiE6HpU822bUhGreTwcE54AJwCx6dTxXVy8kb9jzcViI4mpGd/ee/re2r81YoJZ3tkiRvHA5klDDaWOCvIGcd6v22natZ3RuogszHlzz84POeffmvs3TvDH7LfgXXx4Q1uCxuvELBHgl8VTPLDdRv8AckimAMADDocDByD0rx34/wDwo8IeFPDL+IfAsEumXVrchb+zjnceSr9AY2ZinOCpVijKcqTyByQxKlJR2udapxcX7WPNyro7NLVvpr8zylJba8kWO9hMUw5TOAc+zD/Gqmk+FtLvPG9nDq+oR21iZGuLmW6cgTIDuKZGNpIBBJIwCW7YrO8PnXNXiu8RG4tbSLzJbmUhRB/d+Y9SSMBep57A1fv7jdGl6XUqCqRj+8d3J9xjI/E10q6lZ7nk4lUsRSqU8PUaTVunNFvbyvs79uhk/ETxcvivxV/oMaQaRYKbWwhi3KnlqeHCnAUsAOABgBRztzXIVJOIxdSCLPlhyFz6Z4qOtkrHmYXC08LSjQpK0Y6f159wq9pH/ITP/XCb/wBFNVGnwyyQXEc8TbZI2DqcZwQcimnZnQy7V3SNX1DQtZg1bSrj7PeQEmKXYrFCQRkBgRnBOD1BwRggGq8Ygu13wSwwv/FDLJs2+6s3BHtnP1xkv+xyf897P/wLi/8Aiq1JLumeJNW0ixexs5bd7V7mK8a3urWK5jaWMOqMUlVgcCRwRjBzyDgY1Lr4ieK70JHc3WnvbRywypZf2Zai1VofO8sCAR+WFBuZyV24YuSQTgjnvscn/Pez/wDAuL/4qj7HJ/z3s/8AwLi/+KoFodCPiL4rGs/2l9qsNwtDYfZf7MtfsnkGTzPL+zeX5O3zPnxs+9z15qte+NPEGpeHE0TUJbC6t0jSFJptOtnukjQjYi3Jj85VAAAAfG35enFY/wBjk/572f8A4Fxf/FUfY5P+e9n/AOBcX/xVAaF/UfFGu6sdXOoX3nf2xfrqd9+6RfOuF83D8Abf9fLwuB83TgYSx8Ta7pltpsFhqDwJpt82pWmxVzFcMIwXBxk8Qx8HI+Xpyc0fscn/AD3s/wDwLi/+Ko+xyf8APez/APAuL/4qgNDrIPix49ttRub+LWoTdXF5LftO9hbu6TS48xo2aMmMPgBlTapAwRV7RPig+ifDefw5Fp1zcXslnc6fHd3E8LRwQThg6Iog84DDudvnFNx3bc1wv2OT/nvZ/wDgXF/8VR9jk/572f8A4Fxf/FUBob978QfFuoeGZdAu9ShexmhhgmC2cCSTpEV8oSSqgdyuxQCzEgDGcEisebWdTuNK0/TZLo/ZdPMjWsaKF8tnYMzZABJJA5OTgAdAKg+xyf8APez/APAuL/4qj7HJ/wA97P8A8C4v/iqA0NHxD4q17xXdxXOvXq3UsXm7GEMcWPMmeZ+EUA5kldv+BemBWtbfE/xtZ2EdpBqsG1LcWZkewt3lktwu0QSStGXki2gDy3JXAAxwK5j7HJ/z3s//AALi/wDiqPscn/Pez/8AAuL/AOKoDQlsdWv9OtdQt7KfyotQt/sl0uxT5kXmJLt5HHzxIcjB4x0JFT2XiPW9OsrS0sb97eK0vRqNv5aqGjuAFAkDYzkbV4zjiqf2OT/nvZ/+BcX/AMVR9jk/572f/gXF/wDFUBdHRXvxG8X35t/P1G3RbdLtIY7axt4I4xdwiG4wkcYX50GDxwcsMMSarXPjfxJd6L/ZU95btbmxXTXZbOBZZLdXidI3lCB3Cm3h27mJULgYBION9jk/572f/gXF/wDFUfY5P+e9n/4Fxf8AxVAaEsOrahb6Bd6LDcbbG8miuJ4dine8QcRnOMjAlk4Bwd3OcDGnpvjbxJpX2VbW8t2jtrJtOjgubOC4iNu07XBjeORGWQeaxf5gSDjHQYx/scn/AD3s/wDwLi/+Ko+xyf8APez/APAuL/4qgNDdn8f+LLnwtL4em1GJrCa1ispVFpCJJYYnR40eUJvYIY025Y7QNowCQcbVtUv9c1++1rVJ/Pvr64kurmbaq+ZI7FmbCgAZJJwABUf2OT/nvZ/+BcX/AMVR9jk/572f/gXF/wDFUBoV6KsfY5P+e9n/AOBcX/xVH2OT/nvZ/wDgXF/8VQFyvRVj7HJ/z3s//AuL/wCKo+xyf897P/wLi/8AiqAuV6kl/wCRfn/6+Iv/AEGSpDa7Bulu7NEHVhOr4/BCSfwFUby6WYJDCCIIySu77zE4yx9M4HHQYHXklSdkPcq0UUVkUdh8Z/8Akt+t/wDbD/0njoo+M/8AyW/W/wDth/6Tx0Vktjzck/5F2H/wQ/8ASUHwY/5Lfon/AG3/APSeSuPrsPgx/wAlv0T/ALb/APpPJXH1UdxUv+RjV/wU/wD0qoFKrMjh0YqynII6g0lFWemd94c+JWraZq8FyJxbTABJJo8hZx0HmrnB+uO5yDk13KafZeJXlHhjVE8PyzMZJLO2hHltITkH5WBCZ6AZA7AdK8IrS03XtU0l1ayuXTYcrz90+3pUuEbWsdtLG1I1HOUnd7taN/M67xdc+J/DOm39nrl3diaVfJR2fcszNxuVsc4UHnqOAcVxugaBt26jfoMgeZDA6Bw2O8ikj5enGOc84HX2PTR4i8aeFbHxJJBYajPB5qR2sR3Sw7cbpRE3DSHHVSWCgYAzmuX1C7tJ4mZYXml3b/LVH3OfpjOf1rDlt0sdtaary55VHJLbmev5/kZdvBNdRM/myxA/dWIsoc+u09Bz7VZ1GS9tvDl7by38qTOil7KLIRE3AZkzj5jkYUA4B5I6V0uj6b4h+z3l1BZSaTIyqsV5eRmMxxdWdVIyCAMDAHUnI61keIovB+neGbqO11m41TV58LlzuA+cEsSvGcDuTVRi3JXWhop04UpOnL3mnfW1lqu93J9FbRPruef0UUV1ngiqzKcqSD6jilZ3c/Mxb6nNNooAK3rPwvcyWC32oXMWnwyIXhSQFpp+ONkY5wfU4HvWfpc1pa3gu7uMSiLlIiMhm7Z9h1rsNO0rxb421BLmx8OmSOb/AJfrsMsAUNtJ3HCtg5yBluDwcVlOUtkdKqYPDUXXxlRRXRN2+9/po2cu1jqV2Iku7xcQoIo1nnzsQEnaBzgZJOPc1oy2SXG8XmoXV0EiWG33s7tGoOQBwQV5OBwBmu4bw78Ofh7Itz4y1JdY1hdr/wBlWQykbfIcFM84yT+8KhlJ+UmvPvFnj3VfFMscKwQaXp0IKQ2NkNiBc5G/H3yAFHQAY4Ayam7lsePgc5ji6n+z0m6f870T/wAKavL1sl5m42rPZaQNOtfNg0wMSIZZFiRycDdJjG9sAZJH0ArmtU1mMu/kSiaYjaHUERxD/ZzyT79q54kk5JzRQoHse2hBWpRt/n32Sv56sKKKKs5gooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA7D4z/8AJb9b/wC2H/pPHRR8Z/8Akt+t/wDbD/0njorJbHm5J/yLsP8A4If+koPgx/yW/RP+2/8A6TyVx9dh8GP+S36J/wBt/wD0nkrj6qO4qX/Ixq/4Kf8A6VUCiiirPTCiiigDS0jX9Z0GczaRqVxaMevltw31HQ11j/Gj4jPYtat4ilwy7S4RQ+P94DIrgaKBptHX6D8TfF+garJewagLrzjmWG8XzEfg49CvJz8pGSBnOK6yT4n+CPEkgPjXwEjTFVeS90+QebLIAF5+4wTGeC7Ywo5xkeSUUmk9TycXk2FxNX28otVP5otxl96av87nrX9n/Aq6H2r/AISfW7Lzf3n2Xy2Pk552Z8ls46febp1PWl/4Vj4N/wCit6F/5C/+PV5JRRr3Of8AsnEw/g4ua9VGX3Xj/wAOet/8Kx8G/wDRW9C/8hf/AB6k/sH4JWx+zXnjnVJbiL5JZLeImNnHBKYhYbSc4wx47nrXktFGvcP7JxU/4uMm/RQj+UT1uL4ifDPw9cx3Hhf4fSXExYO0moSgNEynKGMsZSDknkbeg69ud8QfFzxvr+xf7S/suJMHy9M3QbmGeS24uevTdjgcZ5rhqKOVGlHIcFTn7WcXOfebcn+LdvkFFFFM9kKKKKACiiigArX8KrZP440hNRhWW1a8iWRGICkFgPmyCCvqO4yOM5rIooQM9f0TTRZ+KNUS3gvtNgi1yy/0OXYVkBmfDD92CFxyoBxg9Wqta+HNFtfirY+fayanbX/2pvtMjIbd5drnywhU8qflwxB3YOBjB8porTn8iOTzPQNH8EaZqUKyXEOq2zSXb28sZkTOmqqgh58oM5Psn1zV2+0G01D4V6Pc+bNd3FlZzmK1tWCs6+e2ZTkHKLjkAZ5HQc15lRS5l2Hyvudjp/gt0g1VNVsb+61Kwkjj/srT5U80hxnfkK+VAx0B69qs2ngvS7jwumoPPeKXs5rl7vevkW0iEgQONuSxx6g88A1wtFK67BZ9z0aXwd4VtdGmup/7YkkttPtL2TZcRqrmYhSqgxnABOcnNV77wrp2j64dBlJmF5qy28UrgeYIUALYOOCzSKufVDXA1I1xOyRI08hWEYjBY4QZz8vpySeO5p8y7ByvuemXekadceDJbqXSoYIhBHIs8cUcaRloJJPlcLvYq6JGQ7Nkk9CRjPu/BegLpEnkXN/Ddw6ba6hJNNIjRfvWAZdoQEAZzndXJXviDVtQtGt7u4jdXIMjiCNZJSOm9woZ/wDgRNZlDkuwlFno2seBfDmk3lgJL7Umt5b6O2kmEb7JI2H+sSQxBAQf4Qz5Hel1H4e6RpekXlzdapMJLJRBcDcuEuHaMx9uU2SEnvlTyK84oo5l2Hyvuev3HhLTrPwpPoQa9srOfWreI3946sky7D+8jwoAU5x1PbnrWIPAekNqunwSy6hYtcfac2Fw6G4k8oZQodoA39sj6ZrzuihyXYSi+56xrXhq0vrfSLaa01KJ7PRfNi0vev2qVvNPyZ2dRkk/JnHaqVj8PNFudd1KwW5v52t/K8oKSiIWTcyyzLFIqsp45A/pXmlFHMuwcr7noFl8P4LrwLdaxKZYpobOa7SWOfzYn8sn5SBEFXIH/PQnvjHTVtvD2n6J4E1yaKHULiCfTbaSS+3r5M251Zkj+XgjpyT7gd/KqKOZdhuLfU9KHw+8Ppqtpaz6xMq6hI89iwdf3lqIwy5wpO9mbaMD+FsA8Cq0ngzQLXVNQFy+rNb2ulG/MBVoJA4cLt3SwruX/aCD9K8+oo5l2Dlfc9OfwxodhoHia0t9MvNRmSKyuoCHQzxxupY7SIzgKc7iBgjH3cZNC48BWcehXWrRm+a0TTba6hn3KUeWRgHXO3kDJ4HI4zXAUUcy7ByvuejN4J8NS+OdU0G2n1FP7OiLbZZg8l03y8IEhJUDJzhXJ44HNcf4l0u20bxNcafZy3EkMe0qbmF4ZBlQcMrqp4z1wM9e9ZNFJtPoCTXUKKKKkoKKKKACiiigDsPjP/yW/W/+2H/pPHRR8Z/+S363/wBsP/SeOislsebkn/Iuw/8Agh/6SjnfCOvP4Z8c6XrqtIEtbhWl8tVZmiPyyKA3GShYduvUda2fH3hyDw142ntbF45NMuUW8sJY3Dq8EmSuDuYkAgrknJ257iuMrr/DHiLSpbKHwt4zWeXQvN3wXUB/f6c7H5mjJBzG38aYP94DcOWnZjxVKdKssXTV9LSS3a3TXdx106pu2tr85RXeSfC7U9QcS+CtW03xRaFFcva3CRSwhlBHmxuwKEncAMk/Kc4PFM/4U98Rv+hd/wDJuD/4ur5kQs7wFverxT7NqL+admvmjhqK7n/hT3xG/wChd/8AJuD/AOLo/wCFPfEb/oXf/JuD/wCLo5l3H/beXf8AQRD/AMDj/mcNRXc/8Ke+I3/Qu/8Ak3B/8XR/wp74jf8AQu/+TcH/AMXRzLuH9t5d/wBBEP8AwOP+Zw1Fdz/wp74jf9C7/wCTcH/xdH/CnviN/wBC7/5Nwf8AxdHMu4f23l3/AEEQ/wDA4/5nDUV3P/CnviN/0Lv/AJNwf/F0f8Ke+I3/AELv/k3B/wDF0cy7h/beXf8AQRD/AMDj/mcNRXc/8Ke+I3/Qu/8Ak3B/8XR/wp74jf8AQu/+TcH/AMXRzLuH9t5d/wBBEP8AwOP+Zw1Fdz/wp74jf9C7/wCTcH/xdH/CnviN/wBC7/5Nwf8AxdHMu4f23l3/AEEQ/wDA4/5nDUV3P/CnviN/0Lv/AJNwf/F0f8Ke+I3/AELv/k3B/wDF0cy7h/beXf8AQRD/AMDj/mcNRXc/8Ke+I3/Qu/8Ak3B/8XR/wp74jf8AQu/+TcH/AMXRzLuH9t5d/wBBEP8AwOP+Zw1Fdz/wp74jf9C7/wCTcH/xdH/CnviN/wBC7/5Nwf8AxdHMu4f23l3/AEEQ/wDA4/5nDUV3P/CnviN/0Lv/AJNwf/F0f8Ke+I3/AELv/k3B/wDF0cy7h/beXf8AQRD/AMDj/mcNRXc/8Ke+I3/Qu/8Ak3B/8XR/wp74jf8AQu/+TcH/AMXRzLuH9t5d/wBBEP8AwOP+Zw1Fdz/wp74jf9C7/wCTcH/xdH/CnviN/wBC7/5Nwf8AxdHMu4f23l3/AEEQ/wDA4/5nDUV3P/CnviN/0Lv/AJNwf/F0f8Ke+I3/AELv/k3B/wDF0cy7h/beXf8AQRD/AMDj/mcNRXc/8Ke+I3/Qu/8Ak3B/8XR/wp74jf8AQu/+TcH/AMXRzLuH9t5d/wBBEP8AwOP+Zw1Fdz/wp74jf9C7/wCTcH/xdH/CnviN/wBC7/5Nwf8AxdHMu4f23l3/AEEQ/wDA4/5nDUV3P/CnviN/0Lv/AJNwf/F0f8Ke+I3/AELv/k3B/wDF0cy7h/beXf8AQRD/AMDj/mcNRXc/8Ke+I3/Qu/8Ak3B/8XR/wp74jf8AQu/+TcH/AMXRzLuH9t5d/wBBEP8AwOP+Zw1Fdz/wp74jf9C7/wCTcH/xdH/CnviN/wBC7/5Nwf8AxdHMu4f23l3/AEEQ/wDA4/5nDUV3P/CnviN/0Lv/AJNwf/F0f8Ke+I3/AELv/k3B/wDF0cy7h/beXf8AQRD/AMDj/mcNRXc/8Ke+I3/Qu/8Ak3B/8XR/wp74jf8AQu/+TcH/AMXRzLuH9t5d/wBBEP8AwOP+Zw1Fdz/wp74jf9C7/wCTcH/xdH/CnviN/wBC7/5Nwf8AxdHMu4f23l3/AEEQ/wDA4/5nDUV3P/CnviN/0Lv/AJNwf/F0f8Ke+I3/AELv/k3B/wDF0cy7h/beXf8AQRD/AMDj/mcNRXc/8Ke+I3/Qu/8Ak3B/8XR/wp74jf8AQu/+TcH/AMXRzLuH9t5d/wBBEP8AwOP+Zw1Fdz/wp74jf9C7/wCTcH/xdH/CnviN/wBC7/5Nwf8AxdHMu4f23l3/AEEQ/wDA4/5nDV0/gHw5B4l8bQWt88cemWyNeX8sjhFSCPBbJ3KQCSFyDkbs9jWrH8LtT09zL411bTfC9oEZw91cJLLMFUk+VGjEuQdoIyD8wxk8VjeJ/EWlRWU3hbwYs8Whebvnupz+/wBRdT8rSEAYjX+BMD+8RuPCcuxlVxyxkXQwMrtr41rGPnfZvsk3rvZGV4u15/E3jnVNdZpCl1cM0XmKqssQ+WNSF4yECjv06nrRWLRUnrUaUaNONKCsopJeiCiiig0CiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAP/9k=",
}

func parseAndStripMood(rawText string) (string, string) {
	trimmed := strings.TrimSpace(rawText)
	if m := moodTagRegex.FindStringSubmatch(trimmed); len(m) >= 2 {
		key := strings.ToLower(strings.TrimSpace(m[1]))
		if _, ok := expressionBannersB64[key]; ok {
			cleaned := strings.TrimSpace(moodTagRegex.ReplaceAllString(trimmed, ""))
			return key, cleaned
		}
	}
	lower := strings.ToLower(trimmed)
	switch {
	case strings.Contains(lower, "wkwk") || strings.Contains(lower, "haha") || strings.Contains(lower, "😂") || strings.Contains(lower, "😆"):
		return "ketawa", trimmed
	case strings.Contains(lower, "maaf") || strings.Contains(lower, "sedih") || strings.Contains(lower, "😢"):
		return "sedih", trimmed
	case strings.Contains(lower, "waduh") || strings.Contains(lower, "bahaya") || strings.Contains(lower, "😱"):
		return "kaget", trimmed
	case strings.Contains(lower, "semangat") || strings.Contains(lower, "gas") || strings.Contains(lower, "🔥"):
		return "semangat", trimmed
	case strings.Contains(lower, "terima kasih") || strings.Contains(lower, "sayang") || strings.Contains(lower, "❤️") || strings.Contains(lower, "😍"):
		return "suka", trimmed
	case strings.Contains(lower, "halo") || strings.Contains(lower, "hai") || strings.Contains(lower, "selamat"):
		return "ramah", trimmed
	case strings.Contains(lower, "berhasil") || strings.Contains(lower, "sukses") || strings.Contains(lower, "✅"):
		return "bangga", trimmed
	case strings.Contains(lower, "?") || strings.Contains(lower, "mengapa") || strings.Contains(lower, "analisis") || strings.Contains(lower, "ringkasan"):
		return "bingung", trimmed
	case strings.Contains(lower, "!") || strings.Contains(lower, "😊") || strings.Contains(lower, "✨"):
		return "ceria", trimmed
	default:
		return "tenang", trimmed
	}
}

func getOrUploadMoodBanner(ctx context.Context, sess *SessionInstance, moodKey string) (*whatsmeow.UploadResponse, []byte, error) {
	if sess == nil || sess.Client == nil {
		return nil, nil, fmt.Errorf("client nil")
	}
	b64, ok := expressionBannersB64[moodKey]
	if !ok {
		moodKey = "ceria"
		b64 = expressionBannersB64["ceria"]
	}
	thumbBytes, err := base64.StdEncoding.DecodeString(b64)
	if err != nil || len(thumbBytes) == 0 {
		return nil, nil, fmt.Errorf("decode banner gagal")
	}

	mu.Lock()
	if sess.MoodMediaCache == nil {
		sess.MoodMediaCache = make(map[string]*CachedMoodMedia)
	}
	cached, found := sess.MoodMediaCache[moodKey]
	mu.Unlock()

	if found && cached != nil && time.Since(cached.CreatedAt) < 6*time.Hour && cached.Upload.URL != "" {
		up := cached.Upload
		return &up, thumbBytes, nil
	}

	upCtx, cancel := context.WithTimeout(ctx, 12*time.Second)
	defer cancel()
	up, err := sess.Client.Upload(upCtx, thumbBytes, whatsmeow.MediaImage)
	if err != nil {
		return nil, thumbBytes, err
	}

	mu.Lock()
	sess.MoodMediaCache[moodKey] = &CachedMoodMedia{
		Upload:    up,
		CreatedAt: time.Now(),
	}
	mu.Unlock()
	return &up, thumbBytes, nil
}

func sendMsgReaction(ctx context.Context, sess *SessionInstance, info types.MessageInfo, emoji string) {
	if sess == nil || sess.Client == nil || info.ID == "" || info.Chat.String() == "status@broadcast" {
		return
	}
	reactMsg := sess.Client.BuildReaction(info.Chat, info.Sender, info.ID, emoji)
	resp, err := sess.Client.SendMessage(ctx, info.Chat, reactMsg)
	if err == nil && resp.ID != "" {
		mu.Lock()
		botSentIDs[resp.ID] = true
		mu.Unlock()
	}
}

func sendBotTextWithErr(ctx context.Context, sess *SessionInstance, chat types.JID, text string) error {
	if sess == nil || sess.Client == nil {
		return fmt.Errorf("sesi WA belum siap")
	}
	moodKey, cleanText := parseAndStripMood(text)
	if strings.TrimSpace(cleanText) == "" {
		cleanText = "..."
	}

	mu.Lock()
	useBanner := bannerEnabled
	mu.Unlock()

	if useBanner && len(cleanText) <= 1000 {
		if up, thumbBytes, upErr := getOrUploadMoodBanner(ctx, sess, moodKey); upErr == nil && up != nil {
			w := uint32(440)
			h := uint32(230)
			imgMsg := &waE2E.Message{
				ImageMessage: &waE2E.ImageMessage{
					URL:           proto.String(up.URL),
					DirectPath:    proto.String(up.DirectPath),
					MediaKey:      up.MediaKey,
					Mimetype:      proto.String("image/jpeg"),
					FileEncSHA256: up.FileEncSHA256,
					FileSHA256:    up.FileSHA256,
					FileLength:    proto.Uint64(up.FileLength),
					Width:         &w,
					Height:        &h,
					JPEGThumbnail: thumbBytes,
					Caption:       proto.String(cleanText),
				},
			}
			resp, err := sess.Client.SendMessage(ctx, chat, imgMsg)
			if err == nil && resp.ID != "" {
				mu.Lock()
				botSentIDs[resp.ID] = true
				mu.Unlock()
				recordUiMessage(sess, chat.String(), "", chat.Server == types.GroupServer, "Bot AI ["+moodKey+"]", cleanText, true, resp.ID)
				return nil
			}
		}
	}

	if useBanner && len(cleanText) > 1000 {
		if up, thumbBytes, upErr := getOrUploadMoodBanner(ctx, sess, moodKey); upErr == nil && up != nil {
			w := uint32(440)
			h := uint32(230)
			moodLabel := expressionLabels[moodKey]
			if moodLabel == "" {
				moodLabel = "😊 Ceria & Senang"
			}
			bannerMsg := &waE2E.Message{
				ImageMessage: &waE2E.ImageMessage{
					URL:           proto.String(up.URL),
					DirectPath:    proto.String(up.DirectPath),
					MediaKey:      up.MediaKey,
					Mimetype:      proto.String("image/jpeg"),
					FileEncSHA256: up.FileEncSHA256,
					FileSHA256:    up.FileSHA256,
					FileLength:    proto.Uint64(up.FileLength),
					Width:         &w,
					Height:        &h,
					JPEGThumbnail: thumbBytes,
					Caption:       proto.String("*" + moodLabel + "*"),
				},
			}
			if bResp, bErr := sess.Client.SendMessage(ctx, chat, bannerMsg); bErr == nil && bResp.ID != "" {
				mu.Lock()
				botSentIDs[bResp.ID] = true
				mu.Unlock()
			}
		}
	}

	resp, err := sess.Client.SendMessage(ctx, chat, &waE2E.Message{
		Conversation: proto.String(cleanText),
	})
	if err == nil && resp.ID != "" {
		mu.Lock()
		botSentIDs[resp.ID] = true
		mu.Unlock()
		recordUiMessage(sess, chat.String(), "", chat.Server == types.GroupServer, "Bot AI ["+moodKey+"]", cleanText, true, resp.ID)
	}
	return err
}

func sendBotText(ctx context.Context, sess *SessionInstance, chat types.JID, text string) {
	_ = sendBotTextWithErr(ctx, sess, chat, text)
}

func unwrapWaMessage(msg *waE2E.Message) *waE2E.Message {
	for msg != nil {
		if msg.ViewOnceMessage != nil && msg.ViewOnceMessage.Message != nil {
			msg = msg.ViewOnceMessage.Message
			continue
		}
		if msg.ViewOnceMessageV2 != nil && msg.ViewOnceMessageV2.Message != nil {
			msg = msg.ViewOnceMessageV2.Message
			continue
		}
		if msg.ViewOnceMessageV2Extension != nil && msg.ViewOnceMessageV2Extension.Message != nil {
			msg = msg.ViewOnceMessageV2Extension.Message
			continue
		}
		if msg.EphemeralMessage != nil && msg.EphemeralMessage.Message != nil {
			msg = msg.EphemeralMessage.Message
			continue
		}
		if msg.DocumentWithCaptionMessage != nil && msg.DocumentWithCaptionMessage.Message != nil {
			msg = msg.DocumentWithCaptionMessage.Message
			continue
		}
		break
	}
	return msg
}

func extractInteractiveSelectionText(rawMsg *waE2E.Message) string {
	msg := unwrapWaMessage(rawMsg)
	if msg == nil {
		return ""
	}
	if ir := msg.GetInteractiveResponseMessage(); ir != nil {
		if nf := ir.GetNativeFlowResponseMessage(); nf != nil {
			paramsRaw := strings.TrimSpace(nf.GetParamsJSON())
			if paramsRaw != "" {
				var parsed map[string]interface{}
				if json.Unmarshal([]byte(paramsRaw), &parsed) == nil {
					if idVal, ok := parsed["id"].(string); ok && strings.TrimSpace(idVal) != "" {
						return strings.TrimSpace(idVal)
					}
				}
			}
		}
		if body := ir.GetBody(); body != nil && strings.TrimSpace(body.GetText()) != "" {
			return strings.TrimSpace(body.GetText())
		}
	}
	if lr := msg.GetListResponseMessage(); lr != nil {
		if sr := lr.GetSingleSelectReply(); sr != nil && strings.TrimSpace(sr.GetSelectedRowID()) != "" {
			return strings.TrimSpace(sr.GetSelectedRowID())
		}
		if strings.TrimSpace(lr.GetTitle()) != "" {
			return strings.TrimSpace(lr.GetTitle())
		}
	}
	if br := msg.GetButtonsResponseMessage(); br != nil {
		if strings.TrimSpace(br.GetSelectedButtonID()) != "" {
			return strings.TrimSpace(br.GetSelectedButtonID())
		}
		if strings.TrimSpace(br.GetSelectedDisplayText()) != "" {
			return strings.TrimSpace(br.GetSelectedDisplayText())
		}
	}
	if tr := msg.GetTemplateButtonReplyMessage(); tr != nil {
		if strings.TrimSpace(tr.GetSelectedID()) != "" {
			return strings.TrimSpace(tr.GetSelectedID())
		}
		if strings.TrimSpace(tr.GetSelectedDisplayText()) != "" {
			return strings.TrimSpace(tr.GetSelectedDisplayText())
		}
	}
	return ""
}

func sendInteractiveMenuList(ctx context.Context, sess *SessionInstance, chat types.JID, headerTitle string, bodyText string, footerText string) error {
	if sess == nil || sess.Client == nil {
		return fmt.Errorf("client nil")
	}
	mu.Lock()
	bName := strings.TrimSpace(config.BotName)
	mu.Unlock()
	if bName == "" {
		bName = "DodosBot"
	}
	if headerTitle == "" || strings.Contains(headerTitle, "GEMINI WHATSAPP BOT") {
		headerTitle = "⚡ " + strings.ToUpper(bName) + " MENU v9.1"
	}
	if footerText == "" {
		footerText = "Pilih kategori di 🗂️ Menu List atau ketik perintah teks"
	}

	rows := []map[string]string{
		{"header": "", "title": "👥 group", "description": "Group management and admin features", "id": "/menu group"},
		{"header": "", "title": "ℹ️ info", "description": "Bot and system information", "id": "/menu info"},
		{"header": "", "title": "🌐 internet", "description": "Search and access internet content", "id": "/menu internet"},
		{"header": "", "title": "🏠 main", "description": "Main and basic bot commands", "id": "/menu main"},
		{"header": "", "title": "🤨 nsfw", "description": "Collection of anime & fun features", "id": "/menu nsfw"},
		{"header": "", "title": "💬 quotes", "description": "Motivational quotes and wise words", "id": "/menu quotes"},
		{"header": "", "title": "⚔️ rpg", "description": "Role Playing Game and leveling system", "id": "/menu rpg"},
		{"header": "", "title": "🔍 search", "description": "Search for online information and data", "id": "/menu search"},
		{"header": "", "title": "🎵 sound", "description": "Audio, music, and sound effects", "id": "/menu sound"},
		{"header": "", "title": "🕵️ stalk", "description": "Find social media profile information", "id": "/menu stalk"},
		{"header": "", "title": "🎭 sticker", "description": "Create and manage WhatsApp stickers", "id": "/menu sticker"},
		{"header": "", "title": "📥 downloader", "description": "Download Video HD & MP3 (YouTube, IG, TikTok, FB, X)", "id": "/menu downloader"},
		{"header": "", "title": "📸 status", "description": "Upload Status WA HD & Status Grup", "id": "/menu status"},
	}

	paramsObj := map[string]interface{}{
		"title": "🗂️ Menu List",
		"sections": []map[string]interface{}{
			{
				"title": "📂 Pilih Kategori Menu Bot",
				"rows":  rows,
			},
		},
	}
	paramsBytes, _ := json.Marshal(paramsObj)
	paramsJSON := string(paramsBytes)
	msgVer := int32(1)

	interactiveMsg := &waE2E.Message{
		InteractiveMessage: &waE2E.InteractiveMessage{
			Header: &waE2E.InteractiveMessage_Header{
				Title:              proto.String(headerTitle),
				HasMediaAttachment: proto.Bool(false),
			},
			Body: &waE2E.InteractiveMessage_Body{
				Text: proto.String(bodyText),
			},
			Footer: &waE2E.InteractiveMessage_Footer{
				Text: proto.String(footerText),
			},
			InteractiveMessage: &waE2E.InteractiveMessage_NativeFlowMessage_{
				NativeFlowMessage: &waE2E.InteractiveMessage_NativeFlowMessage{
					Buttons: []*waE2E.InteractiveMessage_NativeFlowMessage_NativeFlowButton{
						{
							Name:             proto.String("single_select"),
							ButtonParamsJSON: proto.String(paramsJSON),
						},
					},
					MessageVersion: &msgVer,
				},
			},
		},
	}

	bizNode := waBinary.Node{
		Tag: "biz",
		Content: []waBinary.Node{{
			Tag:   "interactive",
			Attrs: waBinary.Attrs{"type": "native_flow", "v": "1"},
			Content: []waBinary.Node{{
				Tag:   "native_flow",
				Attrs: waBinary.Attrs{"v": "9", "name": "mixed"},
			}},
		}},
	}
	additionalNodes := []waBinary.Node{bizNode}
	if chat.Server != types.GroupServer {
		additionalNodes = append(additionalNodes, waBinary.Node{
			Tag:   "bot",
			Attrs: waBinary.Attrs{"biz_bot": "1"},
		})
	}

	resp, err := sess.Client.SendMessage(ctx, chat, interactiveMsg, whatsmeow.SendRequestExtra{
		AdditionalNodes: &additionalNodes,
	})
	if err == nil && resp.ID != "" {
		mu.Lock()
		botSentIDs[resp.ID] = true
		mu.Unlock()
		recordUiMessage(sess, chat.String(), "", chat.Server == types.GroupServer, "Bot AI [Menu List]", bodyText, true, resp.ID)
		return nil
	}
	return err
}

func parseMp4Metadata(data []byte) (uint32, uint32, uint32, bool) {
	var durationSec uint32 = 15
	var width uint32 = 720
	var height uint32 = 1280
	isHevc := bytes.Contains(data, []byte("hvc1")) || bytes.Contains(data, []byte("hev1"))

	if idx := bytes.Index(data, []byte("mvhd")); idx >= 4 && idx+32 < len(data) {
		version := data[idx+4]
		if version == 0 && idx+24 <= len(data) {
			timescale := binary.BigEndian.Uint32(data[idx+16 : idx+20])
			duration := binary.BigEndian.Uint32(data[idx+20 : idx+24])
			if timescale > 0 && duration > 0 {
				sec := duration / timescale
				if sec > 0 && sec < 7200 {
					durationSec = sec
				}
			}
		} else if version == 1 && idx+36 <= len(data) {
			timescale := binary.BigEndian.Uint32(data[idx+24 : idx+28])
			duration := binary.BigEndian.Uint64(data[idx+28 : idx+36])
			if timescale > 0 && duration > 0 {
				sec := uint32(duration / uint64(timescale))
				if sec > 0 && sec < 7200 {
					durationSec = sec
				}
			}
		}
	}

	searchData := data
	for {
		idx := bytes.Index(searchData, []byte("tkhd"))
		if idx < 0 || idx+92 > len(searchData) {
			break
		}
		version := searchData[idx+4]
		wOffset := idx + 80
		if version == 1 {
			wOffset = idx + 92
		}
		if wOffset+8 <= len(searchData) {
			wFixed := binary.BigEndian.Uint32(searchData[wOffset : wOffset+4])
			hFixed := binary.BigEndian.Uint32(searchData[wOffset+4 : wOffset+8])
			w := wFixed >> 16
			h := hFixed >> 16
			if w >= 120 && w <= 4320 && h >= 120 && h <= 4320 {
				width = w
				height = h
				break
			}
		}
		searchData = searchData[idx+4:]
	}

	return durationSec, width, height, isHevc
}

func prepareVideoForStatusHD(rawBytes []byte) ([]byte, uint32, uint32, uint32, []byte) {
	sec, w, h, isHevc := parseMp4Metadata(rawBytes)
	var thumbBytes []byte
	if b64, ok := expressionBannersB64["keren"]; ok {
		thumbBytes, _ = base64.StdEncoding.DecodeString(b64)
	}

	ffmpegPath, err := exec.LookPath("ffmpeg")
	if err != nil || ffmpegPath == "" {
		return rawBytes, sec, w, h, thumbBytes
	}

	tmpIn := filepath.Join(os.TempDir(), fmt.Sprintf("wa_status_in_%d.mp4", time.Now().UnixNano()))
	tmpOut := filepath.Join(os.TempDir(), fmt.Sprintf("wa_status_out_%d.mp4", time.Now().UnixNano()))
	tmpThumb := filepath.Join(os.TempDir(), fmt.Sprintf("wa_status_thumb_%d.jpg", time.Now().UnixNano()))
	defer func() {
		_ = os.Remove(tmpIn)
		_ = os.Remove(tmpOut)
		_ = os.Remove(tmpThumb)
	}()

	if err := os.WriteFile(tmpIn, rawBytes, 0600); err != nil {
		return rawBytes, sec, w, h, thumbBytes
	}

	thumbCtx, thumbCancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer thumbCancel()
	_ = exec.CommandContext(thumbCtx, ffmpegPath, "-y", "-ss", "00:00:00.500", "-i", tmpIn, "-vframes", "1", "-vf", "scale=320:-1", "-q:v", "4", tmpThumb).Run()
	if tb, err := os.ReadFile(tmpThumb); err == nil && len(tb) > 200 {
		thumbBytes = tb
	}

	needTranscode := isHevc || len(rawBytes) > 2800*1024 || w > 1080 || h > 1920
	if needTranscode {
		convCtx, convCancel := context.WithTimeout(context.Background(), 90*time.Second)
		defer convCancel()
		args := []string{
			"-y", "-i", tmpIn,
			"-t", "60",
			"-c:v", "libx264",
			"-preset", "veryfast",
			"-crf", "18",
			"-maxrate", "8M",
			"-bufsize", "16M",
			"-pix_fmt", "yuv420p",
			"-vf", "scale='min(1080,iw)':'min(1920,ih)':force_original_aspect_ratio=decrease,pad=ceil(iw/2)*2:ceil(ih/2)*2",
			"-c:a", "aac",
			"-b:a", "192k",
			"-movflags", "+faststart",
			tmpOut,
		}
		if err := exec.CommandContext(convCtx, ffmpegPath, args...).Run(); err == nil {
			if outBytes, err := os.ReadFile(tmpOut); err == nil && len(outBytes) > 4096 {
				newSec, newW, newH, _ := parseMp4Metadata(outBytes)
				return outBytes, newSec, newW, newH, thumbBytes
			}
		}
	}

	return rawBytes, sec, w, h, thumbBytes
}

func uploadStatusHD(
	ctx context.Context,
	sess *SessionInstance,
	mediaType string,
	rawBytes []byte,
	mimeType string,
	caption string,
	audienceMode string,
	audienceNumbers []string,
	mentionNumbers []string,
) error {
	if sess == nil || sess.Client == nil || !sess.Client.IsLoggedIn() {
		return fmt.Errorf("nomor WA belum terhubung / belum login")
	}

	// HARD ANTI-SPAM LOCK: Cegah pembuatan Status WA berulang/spam pada nomor yang sama!
	sessKey := sess.Phone
	if sessKey == "" {
		sessKey = sess.ID
	}
	sampleLen := len(rawBytes)
	if sampleLen > 4096 {
		sampleLen = 4096
	}
	hSum := sha256.Sum256(append([]byte(sessKey+"|"+mediaType+"|"+caption+"|"), rawBytes[:sampleLen]...))
	contentHash := fmt.Sprintf("%x", hSum[:12])

	statusUploadMutex.Lock()
	lastTime := lastStatusUploadTime[sessKey]
	lastHash := lastStatusUploadHash[sessKey]
	if time.Since(lastTime) < 15*time.Second || (lastHash == contentHash && time.Since(lastTime) < 5*time.Minute) {
		statusUploadMutex.Unlock()
		addLog(fmt.Sprintf("[Anti-Spam Status] Mencegah duplikat upload status di nomor %s", sessKey))
		return nil
	}
	lastStatusUploadTime[sessKey] = time.Now()
	lastStatusUploadHash[sessKey] = contentHash
	statusUploadMutex.Unlock()

	matches := mentionRegex.FindAllString(caption, -1)
	for _, m := range matches {
		norm := normalizePhone(m)
		if len(norm) >= 9 {
			mentionNumbers = append(mentionNumbers, norm)
			caption = strings.ReplaceAll(caption, m, "@"+norm)
		}
	}

	mentionJIDs := make([]string, 0)
	seenMention := make(map[string]bool)
	for _, num := range mentionNumbers {
		norm := normalizePhone(num)
		if len(norm) >= 9 && !seenMention[norm] {
			seenMention[norm] = true
			mentionJIDs = append(mentionJIDs, norm+"@s.whatsapp.net")
			if !strings.Contains(caption, "@"+norm) {
				if strings.TrimSpace(caption) == "" {
					caption = "@" + norm
				} else {
					caption = caption + " @" + norm
				}
			}
		}
	}

	effectiveList := append([]string{}, audienceNumbers...)
	if audienceMode != "blacklist" {
		for mNorm := range seenMention {
			effectiveList = append(effectiveList, mNorm)
		}
	}
	if sess.Phone != "" {
		effectiveList = append(effectiveList, sess.Phone)
	}
	mu.Lock()
	for _, otherSess := range sessions {
		if otherSess != nil && otherSess.Phone != "" {
			effectiveList = append(effectiveList, otherSess.Phone)
		}
	}
	mu.Unlock()

	if sess.Client.Store != nil && sess.Client.Store.Contacts != nil {
		origContacts := sess.Client.Store.Contacts
		sess.Client.Store.Contacts = &TransientAudienceStore{
			ContactStore: origContacts,
			mode:         audienceMode,
			list:         effectiveList,
		}
		defer func() {
			sess.Client.Store.Contacts = origContacts
		}()
	}

	var ctxInfo *waE2E.ContextInfo
	if len(mentionJIDs) > 0 {
		ctxInfo = &waE2E.ContextInfo{
			MentionedJID: mentionJIDs,
		}
	}

	audienceDesc := fmt.Sprintf("Audiens: %s", audienceMode)
	if len(mentionJIDs) > 0 {
		audienceDesc += fmt.Sprintf(", Tag: %d orang", len(mentionJIDs))
	}

	if mediaType == "text" || len(rawBytes) == 0 {
		if strings.TrimSpace(caption) == "" {
			return fmt.Errorf("teks status tidak boleh kosong")
		}
		resp, err := sess.Client.SendMessage(ctx, types.StatusBroadcastJID, &waE2E.Message{
			ExtendedTextMessage: &waE2E.ExtendedTextMessage{
				Text:        proto.String(caption),
				ContextInfo: ctxInfo,
			},
		})
		if err != nil {
			return err
		}
		if resp.ID != "" {
			mu.Lock()
			botSentIDs[resp.ID] = true
			mu.Unlock()
		}
		addLog(fmt.Sprintf("[Status Teks] Berhasil diunggah di nomor %s (%s)", sess.Phone, audienceDesc))
		return nil
	}

	if strings.HasPrefix(mimeType, "video/") || mediaType == "video" {
		if mimeType == "" {
			mimeType = "video/mp4"
		}
		readyBytes, durSec, width, height, thumbBytes := prepareVideoForStatusHD(rawBytes)
		upCtx, cancel := context.WithTimeout(ctx, 120*time.Second)
		defer cancel()
		up, err := sess.Client.Upload(upCtx, readyBytes, whatsmeow.MediaVideo)
		if err != nil {
			return fmt.Errorf("gagal upload video HD ke server WA: %w", err)
		}
		vidMsg := &waE2E.VideoMessage{
			Caption:       proto.String(caption),
			Mimetype:      proto.String("video/mp4"),
			URL:           &up.URL,
			DirectPath:    &up.DirectPath,
			MediaKey:      up.MediaKey,
			FileEncSHA256: up.FileEncSHA256,
			FileSHA256:    up.FileSHA256,
			FileLength:    &up.FileLength,
			Seconds:       proto.Uint32(durSec),
			Width:         proto.Uint32(width),
			Height:        proto.Uint32(height),
			JPEGThumbnail: thumbBytes,
			ContextInfo:   ctxInfo,
		}
		resp, err := sess.Client.SendMessage(upCtx, types.StatusBroadcastJID, &waE2E.Message{
			VideoMessage: vidMsg,
		})
		if err != nil {
			return err
		}
		if resp.ID != "" {
			mu.Lock()
			botSentIDs[resp.ID] = true
			mu.Unlock()
		}
		addLog(fmt.Sprintf("[Status HD] Video Full HD (%d KB, %ds, %dx%d) berhasil diunggah tanpa kompresi di %s (%s)!", len(readyBytes)/1024, durSec, width, height, sess.Phone, audienceDesc))
		return nil
	}

	if mimeType == "" {
		mimeType = "image/jpeg"
	}
	up, err := sess.Client.Upload(ctx, rawBytes, whatsmeow.MediaImage)
	if err != nil {
		return fmt.Errorf("gagal upload foto HD ke server WA: %w", err)
	}
	imgMsg := &waE2E.ImageMessage{
		Caption:       proto.String(caption),
		Mimetype:      proto.String(mimeType),
		URL:           &up.URL,
		DirectPath:    &up.DirectPath,
		MediaKey:      up.MediaKey,
		FileEncSHA256: up.FileEncSHA256,
		FileSHA256:    up.FileSHA256,
		FileLength:    &up.FileLength,
		ContextInfo:   ctxInfo,
	}
	resp, err := sess.Client.SendMessage(ctx, types.StatusBroadcastJID, &waE2E.Message{
		ImageMessage: imgMsg,
	})
	if err != nil {
		return err
	}
	if resp.ID != "" {
		mu.Lock()
		botSentIDs[resp.ID] = true
		mu.Unlock()
	}
	addLog(fmt.Sprintf("[Status HD] Foto (%d KB) diunggah tanpa kompresi di %s (%s)!", len(rawBytes)/1024, sess.Phone, audienceDesc))
	return nil
}

type PendingUpstatusJob struct {
	SenderPhone string
	ChatJID     types.JID
	MediaType   string
	RawBytes    []byte
	MimeType    string
	LinkUrl     string
	Caption     string
	Mentions    []string
	ExpiresAt   time.Time
	PairSent    bool
}

var pendingUpstatusMap = make(map[string]*PendingUpstatusJob)

func extractSenderPhone(sess *SessionInstance, info types.MessageInfo) string {
	if info.IsFromMe && sess != nil && sess.Phone != "" {
		return normalizePhone(sess.Phone)
	}
	candidates := []types.JID{info.Sender, info.SenderAlt, info.Chat, info.RecipientAlt}
	for _, jid := range candidates {
		if jid.Server == types.DefaultUserServer && jid.User != "" {
			norm := normalizePhone(jid.User)
			if len(norm) >= 9 && len(norm) <= 15 {
				return norm
			}
		}
	}
	if sess != nil && sess.Client != nil && sess.Client.Store != nil && sess.Client.Store.LIDs != nil {
		for _, jid := range []types.JID{info.Sender, info.Chat} {
			if jid.Server == types.HiddenUserServer && jid.User != "" {
				if pnJID, err := sess.Client.Store.LIDs.GetPNForLID(context.Background(), jid); err == nil && pnJID.User != "" {
					norm := normalizePhone(pnJID.User)
					if len(norm) >= 9 && len(norm) <= 15 {
						return norm
					}
				}
			}
		}
	}
	return ""
}

func findLoggedInSessionByPhone(phone string) *SessionInstance {
	norm := normalizePhone(phone)
	if len(norm) < 9 {
		return nil
	}
	mu.Lock()
	defer mu.Unlock()
	if s, ok := sessions[norm]; ok && s != nil && s.Client != nil && s.Client.IsLoggedIn() {
		return s
	}
	for _, s := range sessions {
		if s == nil || s.Client == nil || !s.Client.IsLoggedIn() {
			continue
		}
		if normalizePhone(s.Phone) == norm {
			return s
		}
		if s.Client.Store != nil && s.Client.Store.ID != nil && normalizePhone(s.Client.Store.ID.User) == norm {
			return s
		}
	}
	return nil
}

func markContextInfoAsGroupStatus(ctxInfo *waE2E.ContextInfo) *waE2E.ContextInfo {
	if ctxInfo == nil {
		ctxInfo = &waE2E.ContextInfo{}
	}
	rv := reflect.ValueOf(ctxInfo)
	if rv.Kind() == reflect.Ptr && !rv.IsNil() {
		elem := rv.Elem()
		f := elem.FieldByName("IsGroupStatus")
		if f.IsValid() && f.CanSet() && f.Type() == reflect.TypeOf(proto.Bool(true)) {
			f.Set(reflect.ValueOf(proto.Bool(true)))
		}
	}
	return ctxInfo
}

func wrapAsGroupStatusMessage(inner *waE2E.Message) *waE2E.Message {
	outer := &waE2E.Message{}
	fp := &waE2E.FutureProofMessage{Message: inner}
	rv := reflect.ValueOf(outer).Elem()
	wrapped := false
	for _, fName := range []string{"GroupStatusMessageV2", "GroupStatusMessage"} {
		f := rv.FieldByName(fName)
		if f.IsValid() && f.CanSet() && f.Type() == reflect.TypeOf(fp) {
			f.Set(reflect.ValueOf(fp))
			wrapped = true
		}
	}
	if !wrapped {
		return inner
	}
	return outer
}

func uploadGroupStatusHD(
	ctx context.Context,
	sess *SessionInstance,
	groupJID types.JID,
	mediaType string,
	rawBytes []byte,
	mimeType string,
	caption string,
	mentionNumbers []string,
) error {
	if sess == nil || sess.Client == nil || !sess.Client.IsLoggedIn() {
		return fmt.Errorf("bot belum terhubung")
	}

	mentionJIDs := make([]string, 0)
	for _, num := range mentionNumbers {
		norm := normalizePhone(num)
		if len(norm) >= 9 {
			mentionJIDs = append(mentionJIDs, norm+"@s.whatsapp.net")
		}
	}
	ctxInfo := markContextInfoAsGroupStatus(&waE2E.ContextInfo{
		MentionedJID: mentionJIDs,
	})

	var innerMsg *waE2E.Message
	if mediaType == "text" || len(rawBytes) == 0 {
		if strings.TrimSpace(caption) == "" {
			return fmt.Errorf("teks status grup kosong")
		}
		innerMsg = &waE2E.Message{
			ExtendedTextMessage: &waE2E.ExtendedTextMessage{
				Text:        proto.String(caption),
				ContextInfo: ctxInfo,
			},
		}
	} else if strings.HasPrefix(mimeType, "video/") || mediaType == "video" {
		readyBytes, durSec, width, height, thumbBytes := prepareVideoForStatusHD(rawBytes)
		upCtx, cancel := context.WithTimeout(ctx, 120*time.Second)
		defer cancel()
		up, err := sess.Client.Upload(upCtx, readyBytes, whatsmeow.MediaVideo)
		if err != nil {
			return err
		}
		innerMsg = &waE2E.Message{
			VideoMessage: &waE2E.VideoMessage{
				Caption:       proto.String(caption),
				Mimetype:      proto.String("video/mp4"),
				URL:           &up.URL,
				DirectPath:    &up.DirectPath,
				MediaKey:      up.MediaKey,
				FileEncSHA256: up.FileEncSHA256,
				FileSHA256:    up.FileSHA256,
				FileLength:    &up.FileLength,
				Seconds:       proto.Uint32(durSec),
				Width:         proto.Uint32(width),
				Height:        proto.Uint32(height),
				JPEGThumbnail: thumbBytes,
				ContextInfo:   ctxInfo,
			},
		}
	} else {
		if mimeType == "" {
			mimeType = "image/jpeg"
		}
		up, err := sess.Client.Upload(ctx, rawBytes, whatsmeow.MediaImage)
		if err != nil {
			return err
		}
		innerMsg = &waE2E.Message{
			ImageMessage: &waE2E.ImageMessage{
				Caption:       proto.String(caption),
				Mimetype:      proto.String(mimeType),
				URL:           &up.URL,
				DirectPath:    &up.DirectPath,
				MediaKey:      up.MediaKey,
				FileEncSHA256: up.FileEncSHA256,
				FileSHA256:    up.FileSHA256,
				FileLength:    &up.FileLength,
				ContextInfo:   ctxInfo,
			},
		}
	}

	groupStatusMsg := wrapAsGroupStatusMessage(innerMsg)
	resp, err := sess.Client.SendMessage(ctx, groupJID, groupStatusMsg)
	if err != nil {
		resp, err = sess.Client.SendMessage(ctx, groupJID, innerMsg)
		if err != nil {
			return err
		}
	}
	if resp.ID != "" {
		mu.Lock()
		botSentIDs[resp.ID] = true
		mu.Unlock()
	}
	addLog(fmt.Sprintf("[Status Grup HD] Berhasil diunggah ke grup %s!", groupJID.String()))
	return nil
}

func executePendingUpstatusForSession(ctx context.Context, targetSess *SessionInstance, notifySess *SessionInstance, chatJID types.JID, job *PendingUpstatusJob) error {
	if targetSess == nil || targetSess.Client == nil || !targetSess.Client.IsLoggedIn() {
		return fmt.Errorf("sesi WA tujuan belum tertaut")
	}
	rawBytes := job.RawBytes
	mediaType := job.MediaType
	mimeType := job.MimeType
	if mediaType == "link" && job.LinkUrl != "" {
		var dlErr error
		if strings.Contains(strings.ToLower(job.LinkUrl), "tiktok.com") {
			rawBytes, mimeType, _, dlErr = downloadViaTikWM(job.LinkUrl, false)
		}
		if dlErr != nil || len(rawBytes) == 0 {
			rawBytes, mimeType, _, dlErr = downloadViaUniversalApi(job.LinkUrl, false)
		}
		if dlErr != nil || len(rawBytes) == 0 {
			return fmt.Errorf("gagal mengunduh link video HD: %v", dlErr)
		}
		mediaType = "video"
		mimeType = "video/mp4"
	}

	mu.Lock()
	audMode := config.DefaultStatusMode
	var audList []string
	if audMode == "blacklist" {
		audList = parsePhoneList(config.StatusExceptList)
	} else if audMode == "whitelist" {
		audList = parsePhoneList(config.StatusOnlyList)
	} else if audMode == "close_friends" {
		audList = parsePhoneList(config.StatusCloseList)
	}
	mu.Unlock()

	if err := uploadStatusHD(ctx, targetSess, mediaType, rawBytes, mimeType, job.Caption, audMode, audList, job.Mentions); err != nil {
		return err
	}
	sizeMB := float64(len(rawBytes)) / (1024.0 * 1024.0)
	msg := fmt.Sprintf(
		"[MOOD:ceria] ✅ *STATUS WA HD BERHASIL TAYANG DI WA ANDA!*\n\n"+
			"*╭─〔 🚀 DETAIL UPSTATUS HD 〕*\n"+
			"*├* 📱 *Target WA* : +%s\n"+
			"*├* 🎬 *Tipe* : %s (Anti-Kompres)\n"+
			"*├* 📦 *Ukuran* : %.2f MB\n"+
			"*╰* 💡 _Ketik .upstatus lagi kapan saja, atau ketik .putusstatus untuk melepas tautan._",
		targetSess.Phone, strings.ToUpper(mediaType), sizeMB,
	)
	_ = sendBotTextWithErr(ctx, notifySess, chatJID, msg)
	return nil
}

func sendUpstatusConsentPrompt(ctx context.Context, sess *SessionInstance, chatJID types.JID, senderPhone string) {
	var confirmGuide string
	var phoneLabel string
	if len(senderPhone) >= 9 {
		phoneLabel = "+" + senderPhone
		confirmGuide = "*╭─〔 📌 PILIHAN KONFIRMASI 〕*\n" +
			"*├* • Ketik *setuju* (untuk nomor +" + senderPhone + ")\n" +
			"*├* • Ketik *setuju 08xxxx* (jika nomor WA Anda berbeda)\n" +
			"*╰* • Ketik *batal* untuk membatalkan"
	} else {
		phoneLabel = "Nomor WA Anda"
		confirmGuide = "*╭─〔 📌 CARA KONFIRMASI (WAJIB SERTAKAN NOMOR) 〕*\n" +
			"*├* • Ketik *setuju 08xxxxxxxxxx*\n" +
			"*├*   _(contoh: setuju 081234567890)_\n" +
			"*╰* • Ketik *batal* untuk membatalkan"
	}
	consentText := fmt.Sprintf(
		"[MOOD:ramah] 🔐 *PERSETUJUAN FITUR UPSTATUS WA HD*\n\n"+
			"Menggunakan fitur *.upstatus* agar tayang langsung di Status WhatsApp Anda (%s) memerlukan *pairing* (penautan perangkat) ke WA Anda.\n\n"+
			"*╭─〔 🛡️ JAMINAN KEAMANAN & HUKUM 〕*\n"+
			"*├* 🔒 *100%% Aman* & Terenkripsi\n"+
			"*├* ⚖️ *Anti-Phishing:* Tidak digunakan untuk phishing/sadap karena saya mengerti dan mematuhi Undang-Undang (UU PDP & UU ITE)\n"+
			"*├* 🤖 *Privasi Terjaga:* AI tidak akan ikut membalas chat pribadi Anda (khusus upload Status HD)\n"+
			"*╰* ⏳ *Batas Waktu:* 5 Menit\n\n"+
			"%s",
		phoneLabel, confirmGuide,
	)
	_ = sendBotTextWithErr(ctx, sess, chatJID, consentText)
}

func isSenderAdminOrOwner(ctx context.Context, sess *SessionInstance, info types.MessageInfo) bool {
	if info.IsFromMe {
		return true
	}
	if sess == nil || sess.Client == nil {
		return false
	}
	ownID := ""
	if sess.Client.Store != nil && sess.Client.Store.ID != nil {
		ownID = sess.Client.Store.ID.User
	}
	if ownID != "" && (info.Sender.User == ownID || info.SenderAlt.User == ownID) {
		return true
	}
	if !info.IsGroup {
		return false
	}
	gInfo, err := sess.Client.GetGroupInfo(ctx, info.Chat)
	if err != nil || gInfo == nil {
		return false
	}
	sUser := info.Sender.User
	sAlt := info.SenderAlt.User
	for _, p := range gInfo.Participants {
		if (sUser != "" && (p.JID.User == sUser || p.PhoneNumber.User == sUser)) ||
			(sAlt != "" && (p.JID.User == sAlt || p.PhoneNumber.User == sAlt)) {
			return p.IsAdmin || p.IsSuperAdmin
		}
	}
	return false
}

func extractContextInfo(msg *waE2E.Message) *waE2E.ContextInfo {
	if msg == nil {
		return nil
	}
	if ext := msg.GetExtendedTextMessage(); ext != nil && ext.GetContextInfo() != nil {
		return ext.GetContextInfo()
	}
	if img := msg.GetImageMessage(); img != nil && img.GetContextInfo() != nil {
		return img.GetContextInfo()
	}
	if vid := msg.GetVideoMessage(); vid != nil && vid.GetContextInfo() != nil {
		return vid.GetContextInfo()
	}
	return nil
}

func extractQuotedText(ctxInfo *waE2E.ContextInfo) string {
	if ctxInfo == nil || ctxInfo.GetQuotedMessage() == nil {
		return ""
	}
	qm := unwrapWaMessage(ctxInfo.GetQuotedMessage())
	if qm == nil {
		return ""
	}
	if c := qm.GetConversation(); c != "" {
		return strings.TrimSpace(c)
	}
	if ext := qm.GetExtendedTextMessage(); ext != nil && ext.GetText() != "" {
		return strings.TrimSpace(ext.GetText())
	}
	if img := qm.GetImageMessage(); img != nil && img.GetCaption() != "" {
		return strings.TrimSpace(img.GetCaption())
	}
	if vid := qm.GetVideoMessage(); vid != nil && vid.GetCaption() != "" {
		return strings.TrimSpace(vid.GetCaption())
	}
	return ""
}

func isBotTaggedOrReplied(sess *SessionInstance, info types.MessageInfo, msg *waE2E.Message, text string) bool {
	mu.Lock()
	trig := strings.ToLower(strings.TrimSpace(config.GroupTrigger))
	mu.Unlock()
	if trig != "" && strings.Contains(strings.ToLower(text), trig) {
		return true
	}
	ownPhone := ""
	ownLID := ""
	if sess != nil {
		ownPhone = normalizePhone(sess.Phone)
		if sess.Client != nil && sess.Client.Store != nil {
			if sess.Client.Store.ID != nil {
				ownPhone = normalizePhone(sess.Client.Store.ID.User)
			}
			if sess.Client.Store.LID.User != "" {
				ownLID = sess.Client.Store.LID.User
			}
		}
	}
	if ownPhone != "" && strings.Contains(text, "@"+ownPhone) {
		return true
	}
	if ownLID != "" && strings.Contains(text, "@"+ownLID) {
		return true
	}
	ctxInfo := extractContextInfo(msg)
	if ctxInfo != nil {
		part := ctxInfo.GetParticipant()
		if ownPhone != "" && strings.Contains(part, ownPhone) {
			return true
		}
		if ownLID != "" && strings.Contains(part, ownLID) {
			return true
		}
		for _, m := range ctxInfo.GetMentionedJID() {
			if (ownPhone != "" && strings.Contains(m, ownPhone)) || (ownLID != "" && strings.Contains(m, ownLID)) {
				return true
			}
		}
	}
	return false
}

func isSupportedMediaLink(rawUrl string) bool {
	u := strings.ToLower(strings.TrimSpace(rawUrl))
	domains := []string{
		"tiktok.com", "vt.tiktok.com", "vm.tiktok.com",
		"instagram.com/", "instagr.am/",
		"youtube.com/", "youtu.be/", "music.youtube.com/",
		"facebook.com/", "fb.watch", "fb.gg", "fb.com/",
		"twitter.com/", "x.com/", "t.co/",
		"pinterest.com/", "pin.it/",
		"capcut.com/", "threads.net/", "mediafire.com/",
		"soundcloud.com/", "spotify.com/", "reddit.com/", "bilibili.tv/", "bilibili.com/",
	}
	for _, d := range domains {
		if strings.Contains(u, d) {
			return true
		}
	}
	if strings.HasSuffix(u, ".mp4") || strings.HasSuffix(u, ".mp3") {
		return true
	}
	return false
}

func extractFirstUrl(text string) string {
	return strings.TrimSpace(urlExtractRegex.FindString(text))
}

func normalizeYouTubeUrl(rawUrl string) (string, string) {
	trimmed := strings.TrimSpace(rawUrl)
	if m := ytVideoIdRegex.FindStringSubmatch(trimmed); len(m) >= 2 && len(m[1]) == 11 {
		vidID := m[1]
		return "https://www.youtube.com/watch?v=" + vidID, vidID
	}
	return trimmed, ""
}

func fetchUrlBytesWithHeaders(client *http.Client, mediaUrl string, maxMB int64) ([]byte, error) {
	if strings.HasPrefix(mediaUrl, "/") {
		mediaUrl = "https://www.tikwm.com" + mediaUrl
	}
	req, err := http.NewRequest("GET", mediaUrl, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36")
	req.Header.Set("Accept", "*/*")
	if strings.Contains(strings.ToLower(mediaUrl), "tikwm.com") {
		req.Header.Set("Referer", "https://www.tikwm.com/")
	}
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 && resp.StatusCode != 206 {
		return nil, fmt.Errorf("HTTP %d", resp.StatusCode)
	}
	ct := strings.ToLower(resp.Header.Get("Content-Type"))
	if strings.Contains(ct, "text/html") || strings.Contains(ct, "application/json") {
		return nil, fmt.Errorf("bukan stream media langsung (%s)", ct)
	}
	data, err := io.ReadAll(io.LimitReader(resp.Body, maxMB*1024*1024))
	if err != nil || len(data) < 4096 {
		return nil, fmt.Errorf("unduhan terlalu kecil (%d bytes)", len(data))
	}
	return data, nil
}

func netUrlQueryEscape(s string) string {
	var buf strings.Builder
	for _, b := range []byte(s) {
		if (b >= 'a' && b <= 'z') || (b >= 'A' && b <= 'Z') || (b >= '0' && b <= '9') || b == '-' || b == '_' || b == '.' || b == '~' {
			buf.WriteByte(b)
		} else {
			buf.WriteString(fmt.Sprintf("%%%02X", b))
		}
	}
	return buf.String()
}

func downloadViaTikWM(targetUrl string, audioOnly bool) ([]byte, string, string, error) {
	apiUrl := "https://www.tikwm.com/api/?url=" + netUrlQueryEscape(targetUrl) + "&hd=1"
	client := &http.Client{Timeout: 60 * time.Second}
	req, _ := http.NewRequest("GET", apiUrl, nil)
	req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/131.0.0.0")
	resp, err := client.Do(req)
	if err != nil {
		return nil, "", "", err
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, "", "", err
	}
	var parsed struct {
		Code int `json:"code"`
		Data struct {
			Title  string `json:"title"`
			HdPlay string `json:"hdplay"`
			Play   string `json:"play"`
			WmPlay string `json:"wmplay"`
			Music  string `json:"music"`
			Author struct {
				Nickname string `json:"nickname"`
			} `json:"author"`
		} `json:"data"`
	}
	if err := json.Unmarshal(body, &parsed); err != nil || parsed.Code != 0 {
		return nil, "", "", fmt.Errorf("tikwm gagal memproses link")
	}
	if audioOnly && parsed.Data.Music != "" {
		mediaBytes, err := fetchUrlBytesWithHeaders(client, parsed.Data.Music, 60)
		if err != nil {
			return nil, "", "", err
		}
		caption := fmt.Sprintf("🎵 *AUDIO MP3 BERHASIL*\n• *Pembuat:* %s\n• *Judul:* %s", parsed.Data.Author.Nickname, parsed.Data.Title)
		return mediaBytes, "audio/mpeg", caption, nil
	}

	var mediaBytes []byte
	var dlErr error
	for _, sUrl := range []string{parsed.Data.HdPlay, parsed.Data.Play, parsed.Data.WmPlay} {
		if strings.TrimSpace(sUrl) == "" {
			continue
		}
		mediaBytes, dlErr = fetchUrlBytesWithHeaders(client, sUrl, 120)
		if dlErr == nil && len(mediaBytes) > 4096 {
			break
		}
	}
	if len(mediaBytes) < 4096 {
		return nil, "", "", fmt.Errorf("file unduhan kosong: %v", dlErr)
	}
	if audioOnly {
		mediaBytes, _ = convertVideoBytesToMp3IfNeeded(mediaBytes, "audio/mpeg", true)
		return mediaBytes, "audio/mpeg", fmt.Sprintf("🎵 *AUDIO MP3 BERHASIL*\n• *Pembuat:* %s\n• *Judul:* %s", parsed.Data.Author.Nickname, parsed.Data.Title), nil
	}
	sizeMB := float64(len(mediaBytes)) / (1024.0 * 1024.0)
	caption := fmt.Sprintf("📥 *DOWNLOADER HD BERHASIL*\n• *Pembuat:* %s\n• *Kualitas:* Full HD (%.2f MB)\n• *Judul:* %s", parsed.Data.Author.Nickname, sizeMB, parsed.Data.Title)
	return mediaBytes, "video/mp4", caption, nil
}

func isLikelyImageOrThumbUrl(u string) bool {
	low := strings.ToLower(u)
	for _, bad := range []string{".jpg", ".jpeg", ".png", ".webp", ".gif", ".svg", "i.ytimg.com", "yt3.ggpht.com", "avatars", "thumbnail", "cover"} {
		if strings.Contains(low, bad) {
			return true
		}
	}
	return false
}

func scoreMediaCandidate(m map[string]interface{}, u string, audioOnly bool) int {
	if isLikelyImageOrThumbUrl(u) {
		return -9999
	}
	score := 20
	lowUrl := strings.ToLower(u)
	metaStr := lowUrl
	for k, v := range m {
		if s, ok := v.(string); ok {
			metaStr += " " + strings.ToLower(k) + ":" + strings.ToLower(s)
		}
	}
	if audioOnly {
		if strings.Contains(metaStr, "mp3") || strings.Contains(metaStr, "audio") || strings.Contains(metaStr, "m4a") || strings.Contains(metaStr, "opus") {
			score += 100
		}
		return score
	}
	if strings.Contains(metaStr, "1080") || strings.Contains(metaStr, "fhd") || strings.Contains(metaStr, "fullhd") || strings.Contains(metaStr, "hdplay") || strings.Contains(metaStr, "no_watermark_hd") {
		score += 90
	}
	if strings.Contains(metaStr, "720") || strings.Contains(metaStr, "hd") || strings.Contains(metaStr, "high") {
		score += 65
	}
	if strings.Contains(metaStr, "480") || strings.Contains(metaStr, "360") {
		score += 30
	}
	if strings.Contains(metaStr, "audio") && !strings.Contains(metaStr, "video") && !strings.Contains(metaStr, "mp4") {
		score -= 80
	}
	return score
}

func collectMediaCandidates(v interface{}, audioOnly bool, out *[]struct {
	url   string
	score int
}) {
	switch val := v.(type) {
	case string:
		s := strings.TrimSpace(val)
		if (strings.HasPrefix(s, "http://") || strings.HasPrefix(s, "https://")) && !isLikelyImageOrThumbUrl(s) {
			low := strings.ToLower(s)
			if audioOnly && (strings.Contains(low, ".mp3") || strings.Contains(low, "audio") || strings.Contains(low, "music") || strings.Contains(low, "m4a") || strings.Contains(low, "dl") || strings.Contains(low, "download") || strings.Contains(low, "savetube") || strings.Contains(low, "oceansaver") || strings.Contains(low, "googlevideo")) {
				*out = append(*out, struct {
					url   string
					score int
				}{s, 55})
			} else if !audioOnly && (strings.Contains(low, ".mp4") || strings.Contains(low, "video") || strings.Contains(low, "play") || strings.Contains(low, "googlevideo") || strings.Contains(low, "cdninstagram") || strings.Contains(low, "fbcdn") || strings.Contains(low, "twimg") || strings.Contains(low, "savetube") || strings.Contains(low, "oceansaver") || strings.Contains(low, "y2mate") || strings.Contains(low, "download") || strings.Contains(low, "cdn")) {
				*out = append(*out, struct {
					url   string
					score int
				}{s, 35})
			}
		}
	case map[string]interface{}:
		priorityKeys := []string{
			"hdplay", "hd", "hd_url", "video_hd", "download_url", "downloadUrl",
			"dlink", "dl", "download", "mp4", "video", "videoUrl", "play",
			"mp3", "audio", "music", "url", "link", "media",
		}
		for idx, k := range priorityKeys {
			if sub, exists := val[k]; exists {
				if s, ok := sub.(string); ok && (strings.HasPrefix(s, "http://") || strings.HasPrefix(s, "https://")) && !isLikelyImageOrThumbUrl(s) {
					sc := scoreMediaCandidate(val, s, audioOnly) + (len(priorityKeys)-idx)*3
					if sc > 0 {
						*out = append(*out, struct {
							url   string
							score int
						}{s, sc})
					}
				}
			}
		}
		for k, sub := range val {
			lowK := strings.ToLower(k)
			if lowK == "thumbnail" || lowK == "thumb" || lowK == "cover" || lowK == "avatar" || lowK == "image" {
				continue
			}
			collectMediaCandidates(sub, audioOnly, out)
		}
	case []interface{}:
		for _, item := range val {
			collectMediaCandidates(item, audioOnly, out)
		}
	}
}

func findMediaUrlInJson(v interface{}, audioOnly bool) string {
	var cands []struct {
		url   string
		score int
	}
	collectMediaCandidates(v, audioOnly, &cands)
	bestUrl := ""
	bestScore := -999
	for _, c := range cands {
		if c.score > bestScore {
			bestScore = c.score
			bestUrl = c.url
		}
	}
	return bestUrl
}

func ensureYtDlpAvailable() string {
	for _, p := range []string{"/opt/gemini-wabot/yt-dlp", "/usr/local/bin/yt-dlp", "yt-dlp"} {
		if path, err := exec.LookPath(p); err == nil && path != "" {
			return path
		}
		if st, err := os.Stat(p); err == nil && !st.IsDir() {
			return p
		}
	}
	if runtime.GOOS == "linux" && runtime.GOARCH == "amd64" {
		target := "/opt/gemini-wabot/yt-dlp"
		_ = os.MkdirAll("/opt/gemini-wabot", 0755)
		dlClient := &http.Client{Timeout: 60 * time.Second}
		if resp, err := dlClient.Get("https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_linux"); err == nil {
			defer resp.Body.Close()
			if resp.StatusCode == 200 {
				if binData, err := io.ReadAll(io.LimitReader(resp.Body, 50*1024*1024)); err == nil && len(binData) > 1000000 {
					if os.WriteFile(target, binData, 0755) == nil {
						return target
					}
				}
			}
		}
	}
	return ""
}

func convertVideoBytesToMp3IfNeeded(rawBytes []byte, currentMime string, audioOnly bool) ([]byte, string) {
	if !audioOnly {
		return rawBytes, currentMime
	}
	if len(rawBytes) > 4 && (string(rawBytes[:3]) == "ID3" || (rawBytes[0] == 0xFF && (rawBytes[1]&0xE0) == 0xE0)) {
		return rawBytes, "audio/mpeg"
	}
	ffmpegPath, err := exec.LookPath("ffmpeg")
	if err != nil || ffmpegPath == "" {
		return rawBytes, "audio/mpeg"
	}
	tmpIn := filepath.Join(os.TempDir(), fmt.Sprintf("conv_in_%d.mp4", time.Now().UnixNano()))
	tmpOut := filepath.Join(os.TempDir(), fmt.Sprintf("conv_out_%d.mp3", time.Now().UnixNano()))
	defer func() {
		_ = os.Remove(tmpIn)
		_ = os.Remove(tmpOut)
	}()
	if os.WriteFile(tmpIn, rawBytes, 0600) != nil {
		return rawBytes, "audio/mpeg"
	}
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	if exec.CommandContext(ctx, ffmpegPath, "-y", "-i", tmpIn, "-vn", "-acodec", "libmp3lame", "-ab", "192k", "-ar", "44100", tmpOut).Run() == nil {
		if mp3Bytes, err := os.ReadFile(tmpOut); err == nil && len(mp3Bytes) > 2048 {
			return mp3Bytes, "audio/mpeg"
		}
	}
	return rawBytes, "audio/mpeg"
}

func downloadViaYtDlp(targetUrl string, audioOnly bool) ([]byte, string, string, error) {
	ytDlpBin := ensureYtDlpAvailable()
	if ytDlpBin == "" {
		return nil, "", "", fmt.Errorf("yt-dlp tidak tersedia")
	}
	cleanUrl, _ := normalizeYouTubeUrl(targetUrl)

	// Coba 3 profil client berurutan (web_safari & tv bebas PO Token di tahun 2026!)
	extractorProfiles := []string{
		"youtube:player_client=web_safari,tv",
		"youtube:player_client=mweb,tv_embedded,web_embedded",
		"",
	}

	for _, prof := range extractorProfiles {
		outBase := filepath.Join(os.TempDir(), fmt.Sprintf("ytdlp_%d", time.Now().UnixNano()))
		ctx, cancel := context.WithTimeout(context.Background(), 75*time.Second)

		var args []string
		args = append(args, "--no-playlist", "--no-warnings", "--geo-bypass", "--no-check-certificates")
		if prof != "" {
			args = append(args, "--extractor-args", prof)
		}
		if audioOnly {
			args = append(args,
				"-f", "bestaudio/best",
				"-x", "--audio-format", "mp3", "--audio-quality", "0",
				"-o", outBase+".%(ext)s",
				cleanUrl,
			)
		} else {
			args = append(args,
				"-f", "bestvideo[height<=1080][ext=mp4]+bestaudio[ext=m4a]/best[height<=1080][ext=mp4]/best[ext=mp4]/18/best",
				"--merge-output-format", "mp4",
				"-o", outBase+".%(ext)s",
				cleanUrl,
			)
		}

		_ = exec.CommandContext(ctx, ytDlpBin, args...).Run()
		cancel()

		matches, _ := filepath.Glob(outBase + "*")
		for _, fPath := range matches {
			data, err := os.ReadFile(fPath)
			_ = os.Remove(fPath)
			if err == nil && len(data) > 4096 {
				sizeMB := float64(len(data)) / (1024.0 * 1024.0)
				if audioOnly {
					data, _ = convertVideoBytesToMp3IfNeeded(data, "audio/mpeg", true)
					return data, "audio/mpeg", fmt.Sprintf("🎵 *AUDIO MP3 BERHASIL* (%.2f MB)\n• *Sumber:* %s", sizeMB, cleanUrl), nil
				}
				return data, "video/mp4", fmt.Sprintf("📥 *DOWNLOADER HD BERHASIL*\n• *Kualitas:* Full HD (%.2f MB)\n• *Sumber:* %s", sizeMB, cleanUrl), nil
			}
		}
	}
	return nil, "", "", fmt.Errorf("yt-dlp gagal mengunduh")
}

func downloadViaPipedYouTube(videoID string, audioOnly bool) ([]byte, string, string, error) {
	if len(videoID) != 11 {
		return nil, "", "", fmt.Errorf("videoID youtube tidak valid")
	}
	instances := []string{
		"https://pipedapi.kavin.rocks",
		"https://pipedapi.tokhmi.xyz",
		"https://pipedapi.moomoo.me",
		"https://pipedapi.syncpundit.io",
		"https://api.piped.private.coffee",
	}
	client := &http.Client{Timeout: 35 * time.Second}
	for _, inst := range instances {
		req, err := http.NewRequest("GET", inst+"/streams/"+videoID, nil)
		if err != nil {
			continue
		}
		req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/131.0.0.0")
		resp, err := client.Do(req)
		if err != nil {
			continue
		}
		raw, _ := io.ReadAll(resp.Body)
		_ = resp.Body.Close()
		if resp.StatusCode != 200 || len(raw) == 0 {
			continue
		}
		var parsed struct {
			Title        string `json:"title"`
			AudioStreams []struct {
				URL      string `json:"url"`
				MimeType string `json:"mimeType"`
				Bitrate  int    `json:"bitrate"`
			} `json:"audioStreams"`
			VideoStreams []struct {
				URL       string `json:"url"`
				Format    string `json:"format"`
				Quality   string `json:"quality"`
				VideoOnly bool   `json:"videoOnly"`
			} `json:"videoStreams"`
		}
		if json.Unmarshal(raw, &parsed) != nil {
			continue
		}
		if audioOnly && len(parsed.AudioStreams) > 0 {
			bestAud := parsed.AudioStreams[0].URL
			bestBr := parsed.AudioStreams[0].Bitrate
			for _, a := range parsed.AudioStreams {
				if a.Bitrate > bestBr && a.URL != "" {
					bestBr = a.Bitrate
					bestAud = a.URL
				}
			}
			if bestAud != "" {
				if mediaBytes, dlErr := fetchUrlBytesWithHeaders(client, bestAud, 100); dlErr == nil && len(mediaBytes) > 4096 {
					mediaBytes, _ = convertVideoBytesToMp3IfNeeded(mediaBytes, "audio/mpeg", true)
					sizeMB := float64(len(mediaBytes)) / (1024.0 * 1024.0)
					return mediaBytes, "audio/mpeg", fmt.Sprintf("🎵 *YOUTUBE MP3 BERHASIL*\n• *Judul:* %s\n• *Ukuran:* %.2f MB", parsed.Title, sizeMB), nil
				}
			}
		} else if !audioOnly && len(parsed.VideoStreams) > 0 {
			var chosenUrl string
			for _, v := range parsed.VideoStreams {
				if !v.VideoOnly && v.URL != "" && (strings.Contains(v.Quality, "1080") || strings.Contains(v.Quality, "720")) {
					chosenUrl = v.URL
					break
				}
			}
			if chosenUrl == "" {
				for _, v := range parsed.VideoStreams {
					if !v.VideoOnly && v.URL != "" {
						chosenUrl = v.URL
						break
					}
				}
			}
			if chosenUrl != "" {
				if mediaBytes, dlErr := fetchUrlBytesWithHeaders(client, chosenUrl, 120); dlErr == nil && len(mediaBytes) > 4096 {
					sizeMB := float64(len(mediaBytes)) / (1024.0 * 1024.0)
					return mediaBytes, "video/mp4", fmt.Sprintf("📥 *YOUTUBE HD BERHASIL*\n• *Judul:* %s\n• *Ukuran:* %.2f MB", parsed.Title, sizeMB), nil
				}
			}
		}
	}
	return nil, "", "", fmt.Errorf("piped instances tidak merespons")
}

func downloadViaOceanSaverYouTube(targetUrl string, audioOnly bool) ([]byte, string, string, error) {
	cleanUrl, _ := normalizeYouTubeUrl(targetUrl)
	client := &http.Client{Timeout: 45 * time.Second}
	formats := []string{"720", "1080", "480", "360"}
	if audioOnly {
		formats = []string{"mp3", "m4a"}
	}
	for _, format := range formats {
		initUrl := "https://p.oceansaver.in/ajax/download.php?format=" + format + "&url=" + netUrlQueryEscape(cleanUrl)
		req, err := http.NewRequest("GET", initUrl, nil)
		if err != nil {
			continue
		}
		req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/131.0.0.0")
		req.Header.Set("Referer", "https://oceansaver.in/")
		resp, err := client.Do(req)
		if err != nil {
			continue
		}
		raw, _ := io.ReadAll(resp.Body)
		_ = resp.Body.Close()

		var initRes struct {
			Success bool   `json:"success"`
			ID      string `json:"id"`
			Title   string `json:"title"`
		}
		if json.Unmarshal(raw, &initRes) != nil || !initRes.Success || initRes.ID == "" {
			continue
		}

		for i := 0; i < 20; i++ {
			time.Sleep(1500 * time.Millisecond)
			progUrl := "https://p.oceansaver.in/ajax/progress.php?id=" + netUrlQueryEscape(initRes.ID)
			pReq, _ := http.NewRequest("GET", progUrl, nil)
			pReq.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/131.0.0.0")
			pReq.Header.Set("Referer", "https://oceansaver.in/")
			pResp, err := client.Do(pReq)
			if err != nil {
				continue
			}
			pRaw, _ := io.ReadAll(pResp.Body)
			_ = pResp.Body.Close()
			var progRes struct {
				Success     int    `json:"success"`
				DownloadUrl string `json:"download_url"`
			}
			if json.Unmarshal(pRaw, &progRes) == nil && progRes.Success == 1 && progRes.DownloadUrl != "" {
				mediaBytes, dlErr := fetchUrlBytesWithHeaders(client, progRes.DownloadUrl, 120)
				if dlErr == nil && len(mediaBytes) > 4096 {
					sizeMB := float64(len(mediaBytes)) / (1024.0 * 1024.0)
					if audioOnly {
						mediaBytes, _ = convertVideoBytesToMp3IfNeeded(mediaBytes, "audio/mpeg", true)
						return mediaBytes, "audio/mpeg", fmt.Sprintf("🎵 *YOUTUBE MP3 BERHASIL*\n• *Judul:* %s\n• *Ukuran:* %.2f MB", initRes.Title, sizeMB), nil
					}
					return mediaBytes, "video/mp4", fmt.Sprintf("📥 *YOUTUBE HD BERHASIL*\n• *Judul:* %s\n• *Kualitas:* %sp HD (%.2f MB)", initRes.Title, format, sizeMB), nil
				}
				break
			}
		}
	}
	return nil, "", "", fmt.Errorf("oceansaver gagal")
}

func downloadViaVxTwitter(targetUrl string, audioOnly bool) ([]byte, string, string, error) {
	u := strings.Replace(targetUrl, "https://x.com/", "https://api.vxtwitter.com/", 1)
	u = strings.Replace(u, "https://twitter.com/", "https://api.vxtwitter.com/", 1)
	if !strings.Contains(u, "api.vxtwitter.com/") {
		return nil, "", "", fmt.Errorf("bukan link twitter")
	}
	client := &http.Client{Timeout: 35 * time.Second}
	req, _ := http.NewRequest("GET", u, nil)
	req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/131.0.0.0")
	resp, err := client.Do(req)
	if err != nil {
		return nil, "", "", err
	}
	raw, _ := io.ReadAll(resp.Body)
	_ = resp.Body.Close()
	var vx struct {
		Text          string   `json:"text"`
		UserName      string   `json:"user_name"`
		MediaURLs     []string `json:"mediaURLs"`
		MediaExtended []struct {
			URL  string `json:"url"`
			Type string `json:"type"`
		} `json:"media_extended"`
	}
	if json.Unmarshal(raw, &vx) != nil {
		return nil, "", "", fmt.Errorf("vxtwitter gagal parse")
	}
	mediaUrl := ""
	for _, m := range vx.MediaExtended {
		if m.Type == "video" || m.Type == "gif" || strings.Contains(m.URL, ".mp4") {
			mediaUrl = m.URL
			break
		}
	}
	if mediaUrl == "" && len(vx.MediaURLs) > 0 {
		mediaUrl = vx.MediaURLs[0]
	}
	if mediaUrl == "" {
		return nil, "", "", fmt.Errorf("tidak ada video di tweet")
	}
	mediaBytes, err := fetchUrlBytesWithHeaders(client, mediaUrl, 120)
	if err != nil {
		return nil, "", "", err
	}
	if audioOnly {
		mediaBytes, _ = convertVideoBytesToMp3IfNeeded(mediaBytes, "audio/mpeg", true)
		return mediaBytes, "audio/mpeg", fmt.Sprintf("🎵 *X/TWITTER MP3 BERHASIL*\n• *Akun:* %s", vx.UserName), nil
	}
	sizeMB := float64(len(mediaBytes)) / (1024.0 * 1024.0)
	return mediaBytes, "video/mp4", fmt.Sprintf("📥 *X/TWITTER HD BERHASIL*\n• *Akun:* %s\n• *Ukuran:* %.2f MB", vx.UserName, sizeMB), nil
}

func downloadViaDdInstagram(targetUrl string, audioOnly bool) ([]byte, string, string, error) {
	if !strings.Contains(strings.ToLower(targetUrl), "instagram.com") && !strings.Contains(strings.ToLower(targetUrl), "instagr.am") {
		return nil, "", "", fmt.Errorf("bukan link instagram")
	}
	ddUrl := strings.Replace(targetUrl, "instagram.com", "ddinstagram.com", 1)
	client := &http.Client{Timeout: 30 * time.Second}
	req, _ := http.NewRequest("GET", ddUrl, nil)
	req.Header.Set("User-Agent", "TelegramBot (like TwitterBot)")
	resp, err := client.Do(req)
	if err != nil {
		return nil, "", "", err
	}
	htmlBytes, _ := io.ReadAll(resp.Body)
	_ = resp.Body.Close()
	htmlStr := string(htmlBytes)
	reOg := regexp.MustCompile(`property="og:video(?::secure_url)?"\s+content="([^"]+)"`)
	matches := reOg.FindStringSubmatch(htmlStr)
	if len(matches) < 2 {
		reAlt := regexp.MustCompile(`content="([^"]+\.mp4[^"]*)"`)
		matches = reAlt.FindStringSubmatch(htmlStr)
	}
	if len(matches) >= 2 {
		vidUrl := strings.ReplaceAll(matches[1], "&amp;", "&")
		if strings.HasPrefix(vidUrl, "/") {
			vidUrl = "https://www.ddinstagram.com" + vidUrl
		}
		mediaBytes, dlErr := fetchUrlBytesWithHeaders(client, vidUrl, 120)
		if dlErr == nil && len(mediaBytes) > 4096 {
			if audioOnly {
				mediaBytes, _ = convertVideoBytesToMp3IfNeeded(mediaBytes, "audio/mpeg", true)
				return mediaBytes, "audio/mpeg", "🎵 *INSTAGRAM MP3 BERHASIL*", nil
			}
			sizeMB := float64(len(mediaBytes)) / (1024.0 * 1024.0)
			return mediaBytes, "video/mp4", fmt.Sprintf("📥 *INSTAGRAM HD BERHASIL* (%.2f MB)", sizeMB), nil
		}
	}
	return nil, "", "", fmt.Errorf("ddinstagram tidak menemukan stream")
}

func downloadViaUniversalApi(targetUrl string, audioOnly bool) ([]byte, string, string, error) {
	lowTarget := strings.ToLower(targetUrl)
	cleanTarget, ytVidID := normalizeYouTubeUrl(targetUrl)

	// 1. Jika YouTube: coba yt-dlp (web_safari/tv), OceanSaver, dan Piped secara berurutan!
	if ytVidID != "" || strings.Contains(lowTarget, "youtube.com") || strings.Contains(lowTarget, "youtu.be") {
		if b, m, c, err := downloadViaYtDlp(cleanTarget, audioOnly); err == nil && len(b) > 4096 {
			return b, m, c, nil
		}
		if b, m, c, err := downloadViaOceanSaverYouTube(cleanTarget, audioOnly); err == nil && len(b) > 4096 {
			return b, m, c, nil
		}
		if ytVidID != "" {
			if b, m, c, err := downloadViaPipedYouTube(ytVidID, audioOnly); err == nil && len(b) > 4096 {
				return b, m, c, nil
			}
		}
	}

	// 2. Jika X/Twitter atau Instagram: coba fast scraper dulu
	if strings.Contains(lowTarget, "x.com/") || strings.Contains(lowTarget, "twitter.com/") {
		if b, m, c, err := downloadViaVxTwitter(targetUrl, audioOnly); err == nil && len(b) > 4096 {
			return b, m, c, nil
		}
	}
	if strings.Contains(lowTarget, "instagram.com") || strings.Contains(lowTarget, "instagr.am") {
		if b, m, c, err := downloadViaDdInstagram(targetUrl, audioOnly); err == nil && len(b) > 4096 {
			return b, m, c, nil
		}
	}

	// 3. Coba yt-dlp untuk situs lainnya (IG, FB, Pinterest, CapCut, SoundCloud, dll)
	if ytVidID == "" {
		if b, m, c, err := downloadViaYtDlp(cleanTarget, audioOnly); err == nil && len(b) > 4096 {
			return b, m, c, nil
		}
	}

	// 4. Multi-Provider REST APIs dengan URL yang sudah dinormalisasi
	client := &http.Client{Timeout: 45 * time.Second}
	encUrl := netUrlQueryEscape(cleanTarget)
	var endpoints []string
	if ytVidID != "" || strings.Contains(lowTarget, "youtube.com") || strings.Contains(lowTarget, "youtu.be") {
		if audioOnly {
			endpoints = append(endpoints,
				"https://api.siputzx.my.id/api/d/ytmp3?url="+encUrl,
				"https://api.ryzendesu.vip/api/downloader/ytmp3?url="+encUrl,
				"https://api.agatz.xyz/api/ytmp3?url="+encUrl,
				"https://api.vreden.my.id/api/ytmp3?url="+encUrl,
				"https://widipe.com/download/ytdl?url="+encUrl,
				"https://btch.us.kg/download/ytdl?url="+encUrl,
			)
		} else {
			endpoints = append(endpoints,
				"https://api.siputzx.my.id/api/d/ytmp4?url="+encUrl,
				"https://api.ryzendesu.vip/api/downloader/ytmp4?url="+encUrl+"&quality=1080",
				"https://api.ryzendesu.vip/api/downloader/ytmp4?url="+encUrl,
				"https://api.agatz.xyz/api/ytmp4?url="+encUrl,
				"https://api.vreden.my.id/api/ytmp4?url="+encUrl,
				"https://widipe.com/download/ytdl?url="+encUrl,
				"https://btch.us.kg/download/ytdl?url="+encUrl,
			)
		}
	} else if strings.Contains(lowTarget, "instagram.com") || strings.Contains(lowTarget, "instagr.am") {
		endpoints = append(endpoints,
			"https://api.siputzx.my.id/api/d/igdl?url="+encUrl,
			"https://api.ryzendesu.vip/api/downloader/igdl?url="+encUrl,
			"https://api.agatz.xyz/api/instagram?url="+encUrl,
			"https://api.vreden.my.id/api/igdownload?url="+encUrl,
			"https://widipe.com/download/igdl?url="+encUrl,
		)
	} else if strings.Contains(lowTarget, "facebook.com") || strings.Contains(lowTarget, "fb.watch") || strings.Contains(lowTarget, "fb.gg") {
		endpoints = append(endpoints,
			"https://api.siputzx.my.id/api/d/facebook?url="+encUrl,
			"https://api.ryzendesu.vip/api/downloader/fbdl?url="+encUrl,
			"https://api.agatz.xyz/api/facebook?url="+encUrl,
			"https://api.vreden.my.id/api/fbdl?url="+encUrl,
			"https://widipe.com/download/fbdl?url="+encUrl,
		)
	}
	endpoints = append(endpoints,
		"https://api.siputzx.my.id/api/d/allinone?url="+encUrl,
		"https://api.ryzendesu.vip/api/downloader/allinone?url="+encUrl,
		"https://api.tiklydown.eu.org/api/download?url="+encUrl,
	)

	for _, ep := range endpoints {
		req, err := http.NewRequest("GET", ep, nil)
		if err != nil {
			continue
		}
		req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/131.0.0.0")
		resp, err := client.Do(req)
		if err != nil {
			continue
		}
		raw, _ := io.ReadAll(resp.Body)
		_ = resp.Body.Close()
		if resp.StatusCode != 200 || len(raw) == 0 {
			continue
		}
		var generic map[string]interface{}
		if json.Unmarshal(raw, &generic) == nil {
			foundUrl := findMediaUrlInJson(generic, audioOnly)
			if foundUrl != "" {
				mediaBytes, dlErr := fetchUrlBytesWithHeaders(client, foundUrl, 120)
				if dlErr == nil && len(mediaBytes) > 4096 {
					sizeMB := float64(len(mediaBytes)) / (1024.0 * 1024.0)
					if audioOnly {
						mediaBytes, _ = convertVideoBytesToMp3IfNeeded(mediaBytes, "audio/mpeg", true)
						return mediaBytes, "audio/mpeg", fmt.Sprintf("🎵 *AUDIO MP3 BERHASIL* (%.2f MB)\n• *Sumber:* %s", sizeMB, cleanTarget), nil
					}
					return mediaBytes, "video/mp4", fmt.Sprintf("📥 *DOWNLOADER HD BERHASIL* (%.2f MB)\n• *Sumber:* %s", sizeMB, cleanTarget), nil
				}
			}
		}
	}

	if strings.HasSuffix(lowTarget, ".mp4") || strings.HasSuffix(lowTarget, ".mp3") {
		mediaBytes, dlErr := fetchUrlBytesWithHeaders(client, targetUrl, 120)
		if dlErr == nil && len(mediaBytes) > 4096 {
			if strings.HasSuffix(lowTarget, ".mp3") || audioOnly {
				mediaBytes, _ = convertVideoBytesToMp3IfNeeded(mediaBytes, "audio/mpeg", true)
				return mediaBytes, "audio/mpeg", "🎵 *AUDIO MP3 BERHASIL*", nil
			}
			return mediaBytes, "video/mp4", "📥 *DOWNLOADER HD BERHASIL*", nil
		}
	}
	return nil, "", "", fmt.Errorf("gagal mengunduh dari link tersebut")
}

func processAndSendLinkDownload(ctx context.Context, sess *SessionInstance, info types.MessageInfo, targetUrl string, audioOnly bool) {
	sendMsgReaction(ctx, sess, info, "⏳")
	addLog(fmt.Sprintf("[Downloader] Mengunduh link: %s (MP3=%v)", targetUrl, audioOnly))

	var mediaBytes []byte
	var mimeType string
	var caption string
	var err error

	if strings.Contains(strings.ToLower(targetUrl), "tiktok.com") {
		mediaBytes, mimeType, caption, err = downloadViaTikWM(targetUrl, audioOnly)
	}
	if err != nil || len(mediaBytes) == 0 {
		mediaBytes, mimeType, caption, err = downloadViaUniversalApi(targetUrl, audioOnly)
	}
	if err != nil || len(mediaBytes) == 0 {
		addLog("[Downloader Gagal -> Reaksi ❌] " + fmt.Sprint(err))
		sendMsgReaction(ctx, sess, info, "❌")
		return
	}

	if strings.HasPrefix(mimeType, "audio/") || audioOnly {
		upCtx, cancel := context.WithTimeout(ctx, 90*time.Second)
		defer cancel()
		up, upErr := sess.Client.Upload(upCtx, mediaBytes, whatsmeow.MediaAudio)
		if upErr != nil {
			sendMsgReaction(ctx, sess, info, "❌")
			return
		}
		audMsg := &waE2E.AudioMessage{
			Mimetype:      proto.String("audio/mpeg"),
			URL:           &up.URL,
			DirectPath:    &up.DirectPath,
			MediaKey:      up.MediaKey,
			FileEncSHA256: up.FileEncSHA256,
			FileSHA256:    up.FileSHA256,
			FileLength:    &up.FileLength,
			PTT:           proto.Bool(false),
		}
		resp, sendErr := sess.Client.SendMessage(upCtx, info.Chat, &waE2E.Message{AudioMessage: audMsg})
		if sendErr != nil {
			sendMsgReaction(ctx, sess, info, "❌")
			return
		}
		if resp.ID != "" {
			mu.Lock()
			botSentIDs[resp.ID] = true
			mu.Unlock()
		}
		sendMsgReaction(ctx, sess, info, "✅")
		return
	}

	mu.Lock()
	lastChatVideoCache[info.Chat.String()] = mediaBytes
	mu.Unlock()

	durSec, width, height, _ := parseMp4Metadata(mediaBytes)
	upCtx, cancel := context.WithTimeout(ctx, 120*time.Second)
	defer cancel()
	up, upErr := sess.Client.Upload(upCtx, mediaBytes, whatsmeow.MediaVideo)
	if upErr != nil {
		sendMsgReaction(ctx, sess, info, "❌")
		return
	}
	vidMsg := &waE2E.VideoMessage{
		Caption:       proto.String(caption),
		Mimetype:      proto.String("video/mp4"),
		URL:           &up.URL,
		DirectPath:    &up.DirectPath,
		MediaKey:      up.MediaKey,
		FileEncSHA256: up.FileEncSHA256,
		FileSHA256:    up.FileSHA256,
		FileLength:    &up.FileLength,
		Seconds:       proto.Uint32(durSec),
		Width:         proto.Uint32(width),
		Height:        proto.Uint32(height),
	}
	resp, sendErr := sess.Client.SendMessage(upCtx, info.Chat, &waE2E.Message{VideoMessage: vidMsg})
	if sendErr != nil {
		sendMsgReaction(ctx, sess, info, "❌")
		return
	}
	if resp.ID != "" {
		mu.Lock()
		botSentIDs[resp.ID] = true
		mu.Unlock()
	}
	sendMsgReaction(ctx, sess, info, "✅")
	addLog(fmt.Sprintf("[Downloader Sukses ✅] Video (%d KB) terkirim ke %s", len(mediaBytes)/1024, info.Chat.String()))
}

func buildFullTextMenu() string {
	mu.Lock()
	bName := strings.TrimSpace(config.BotName)
	mu.Unlock()
	if bName == "" {
		bName = "DodosBot"
	}
	return fmt.Sprintf(
		"*╭─〔 ⚡ %s MENU v9.1 〕*\n"+
			"*├* _Pilih lewat tombol 🗂️ Menu List_\n"+
			"*╰* _atau ketik perintah langsung:_\n\n"+
			"*╭─〔 🏠 MAIN (.menu main) 〕*\n"+
			"*├* • .menu\n"+
			"*├* • .menulist\n"+
			"*├* • .menuteks\n"+
			"*├* • .model\n"+
			"*├* • .banner on / off\n"+
			"*├* • .bot-active\n"+
			"*├* • .bot-off\n"+
			"*╰* • .reset\n\n"+
			"*╭─〔 📥 DOWNLOADER (.menu downloader) 〕*\n"+
			"*├* • .dl [link YouTube/IG/TikTok/FB/X]\n"+
			"*├* • .mp3 [link video ➔ audio MP3]\n"+
			"*├* • .ytmp4 [link YouTube HD]\n"+
			"*├* • .ytmp3 [link YouTube MP3]\n"+
			"*├* • _Chat Pribadi: kirim link langsung_\n"+
			"*╰* • _Grup: @nomorbot + link video_\n\n"+
			"*╭─〔 📸 STATUS HD (.menu status) 〕*\n"+
			"*├* • .upstatus [link / reply media]\n"+
			"*├* • .putusstatus (lepas tautan)\n"+
			"*├* • _Japri: tayang ke Status WA Anda_\n"+
			"*╰* • _Grup: tayang ke Status Grup (Admin)_\n\n"+
			"*╭─〔 👥 GROUP (.menu group) 〕*\n"+
			"*├* • .kick (reply target)\n"+
			"*├* • .promote (reply target)\n"+
			"*├* • .demote (reply target)\n"+
			"*├* • .del (reply pesan)\n"+
			"*├* • .hidetag [teks]\n"+
			"*├* • .group open\n"+
			"*╰* • .group close\n\n"+
			"*╭─〔 ℹ️ INFO (.menu info) 〕*\n"+
			"*├* • .info\n"+
			"*├* • .ping\n"+
			"*├* • .status\n"+
			"*╰* • .runtime\n\n"+
			"*╭─〔 🌐 INTERNET & FITUR LAIN 〕*\n"+
			"*├* • .ai [pertanyaan]\n"+
			"*├* • .ringkas (reply pesan)\n"+
			"*├* • .terjemah [bahasa]\n"+
			"*├* • .cuaca [kota]\n"+
			"*├* • .quotes / .fakta / .pantun\n"+
			"*├* • .rpg / .adventure / .profile\n"+
			"*├* • .cekwa [nomor]\n"+
			"*╰* • .s / .sticker (reply foto)",
		strings.ToUpper(bName),
	)
}

func buildCategoryTextMenu(cat string) string {
	c := strings.ToLower(strings.TrimSpace(cat))
	switch c {
	case "main":
		return "*╭─〔 🏠 MENU MAIN 〕*\n" +
			"*├* • .menu\n" +
			"*├* • .menulist\n" +
			"*├* • .menuteks\n" +
			"*├* • .model [nama model]\n" +
			"*├* • .banner on / off\n" +
			"*├* • .setname [nama baru]\n" +
			"*├* • .bot-active\n" +
			"*├* • .bot-off\n" +
			"*╰* • .reset"
	case "downloader", "download", "dl":
		return "*╭─〔 📥 MENU DOWNLOADER HD & MP3 〕*\n" +
			"*├* • .dl [link YouTube/IG/TikTok/FB/X]\n" +
			"*├* • .mp3 [link video ➔ lagu MP3]\n" +
			"*├* • .ytmp4 [link YouTube 1080p/720p]\n" +
			"*├* • .ytmp3 [link YouTube ke MP3]\n" +
			"*├* • .ig [link Reel/Post Instagram]\n" +
			"*├* • .fb [link Video Facebook]\n" +
			"*├* • .tw [link Video X/Twitter]\n" +
			"*├* _Japri: cukup tempel link langsung_\n" +
			"*╰* _Grup: tag @nomorbot + link_"
	case "status":
		return "*╭─〔 📸 MENU STATUS WA HD 〕*\n" +
			"*├* • .upstatus [link video HD]\n" +
			"*├* • .upstatus [reply foto/video]\n" +
			"*├* • .putusstatus (lepas sesi status)\n" +
			"*├* _Japri: tayang ke Status WA pengirim_\n" +
			"*├* _Grup: tayang ke Status Grup (Admin)_\n" +
			"*╰* _Status Full HD 1080p Anti-Kompres_"
	case "group":
		return "*╭─〔 👥 MENU GROUP ADMIN 〕*\n" +
			"*├* • .kick (reply anggota)\n" +
			"*├* • .promote (reply anggota)\n" +
			"*├* • .demote (reply anggota)\n" +
			"*├* • .del (reply pesan)\n" +
			"*├* • .hidetag [pengumuman]\n" +
			"*├* • .group open\n" +
			"*╰* • .group close"
	case "info":
		return "*╭─〔 ℹ️ MENU INFO & TELEMETRY 〕*\n" +
			"*├* • .info\n" +
			"*├* • .ping\n" +
			"*├* • .status\n" +
			"*╰* • .runtime"
	case "internet", "search":
		return "*╭─〔 🌐 MENU INTERNET & AI 〕*\n" +
			"*├* • .ai [pertanyaan]\n" +
			"*├* • .ringkas (reply teks panjang)\n" +
			"*├* • .terjemah [bahasa]\n" +
			"*├* • .cuaca [nama kota]\n" +
			"*╰* • .berita [topik]"
	case "rpg":
		return "*╭─〔 ⚔️ MENU RPG ADVENTURE 〕*\n" +
			"*├* • .rpg\n" +
			"*├* • .adventure\n" +
			"*├* • .heal\n" +
			"*╰* • .profile"
	case "quotes", "nsfw", "sound", "stalk", "sticker":
		return "*╭─〔 ✨ MENU FITUR HIBURAN 〕*\n" +
			"*├* • .quotes / .motivasi\n" +
			"*├* • .fakta / .pantun\n" +
			"*├* • .waifu / .neko\n" +
			"*├* • .cekwa [628xxx]\n" +
			"*╰* • .s / .sticker (reply foto)"
	default:
		return buildFullTextMenu()
	}
}

func formatUptimeClock(d time.Duration) string {
	totalSec := int64(d.Seconds())
	if totalSec < 0 {
		totalSec = 0
	}
	days := totalSec / 86400
	rem := totalSec % 86400
	hours := rem / 3600
	rem %= 3600
	mins := rem / 60
	secs := rem % 60
	if days > 0 {
		return fmt.Sprintf("%dd %02dh:%02dm:%02ds", days, hours, mins, secs)
	}
	return fmt.Sprintf("%02dh:%02dm:%02ds", hours, mins, secs)
}

func readSystemUptime() string {
	if data, err := os.ReadFile("/proc/uptime"); err == nil {
		fields := strings.Fields(string(data))
		if len(fields) > 0 {
			if secFloat, err := strconv.ParseFloat(fields[0], 64); err == nil {
				return formatUptimeClock(time.Duration(secFloat) * time.Second)
			}
		}
	}
	return formatUptimeClock(time.Since(startTime))
}

func readLoadAvg() string {
	if data, err := os.ReadFile("/proc/loadavg"); err == nil {
		fields := strings.Fields(string(data))
		if len(fields) >= 3 {
			return fmt.Sprintf("%s, %s, %s", fields[0], fields[1], fields[2])
		}
	}
	return "0.08, 0.05, 0.04"
}

func readOsPlatformName() string {
	if data, err := os.ReadFile("/etc/os-release"); err == nil {
		for _, line := range strings.Split(string(data), "\n") {
			if strings.HasPrefix(line, "PRETTY_NAME=") {
				val := strings.TrimPrefix(line, "PRETTY_NAME=")
				val = strings.Trim(val, `"' `)
				if val != "" {
					return fmt.Sprintf("%s (%s)", val, runtime.GOARCH)
				}
			}
		}
	}
	return fmt.Sprintf("%s %s", runtime.GOOS, runtime.GOARCH)
}

func readRamSummaryMB() string {
	if data, err := os.ReadFile("/proc/meminfo"); err == nil {
		var totalKB, availKB int64
		for _, line := range strings.Split(string(data), "\n") {
			if strings.HasPrefix(line, "MemTotal:") {
				_, _ = fmt.Sscanf(line, "MemTotal: %d kB", &totalKB)
			} else if strings.HasPrefix(line, "MemAvailable:") {
				_, _ = fmt.Sscanf(line, "MemAvailable: %d kB", &availKB)
			}
		}
		if totalKB > 0 {
			usedMB := float64(totalKB-availKB) / 1024.0
			totalMB := float64(totalKB) / 1024.0
			return fmt.Sprintf("%.0f MB / %.0f MB", usedMB, totalMB)
		}
	}
	return ""
}

func buildBotTelemetryInfo() string {
	mu.Lock()
	botName := strings.TrimSpace(config.BotName)
	if botName == "" {
		botName = "DodosBot"
	}
	aiModel := sanitizeModelName(config.Model)
	repliedCount := totalReplied
	activeSessCount := 0
	chatSet := make(map[string]bool)
	userSet := make(map[string]bool)
	for k := range memory {
		chatSet[k] = true
		if !strings.HasSuffix(k, "@g.us") {
			userSet[k] = true
		}
	}
	for k := range rpgPlayers {
		userSet[k] = true
	}
	for _, s := range sessions {
		if s.Active && s.Client != nil && s.Client.IsLoggedIn() {
			activeSessCount++
		}
		for cJid := range s.Chats {
			chatSet[cJid] = true
			if !strings.HasSuffix(cJid, "@g.us") {
				userSet[cJid] = true
			}
		}
	}
	mu.Unlock()

	var ms runtime.MemStats
	runtime.ReadMemStats(&ms)
	rssMB := float64(ms.Sys) / (1024.0 * 1024.0)
	heapTotalMB := float64(ms.HeapSys) / (1024.0 * 1024.0)
	heapUsedMB := float64(ms.HeapAlloc) / (1024.0 * 1024.0)
	extMB := float64(ms.StackSys+ms.GCSys+ms.OtherSys) / (1024.0 * 1024.0)
	ramSrv := readRamSummaryMB()

	procUp := formatUptimeClock(time.Since(startTime))
	sysUp := readSystemUptime()
	platformStr := readOsPlatformName()
	cpuCores := runtime.NumCPU()
	loadAvg := readLoadAvg()

	usersCount := len(userSet)
	if usersCount == 0 {
		usersCount = 1
	}
	chatsCount := len(chatSet)
	if chatsCount == 0 {
		chatsCount = 1
	}

	ramLine := ""
	if ramSrv != "" {
		ramLine = fmt.Sprintf("*├* 🗄️ *RAM Server* : %s\n", ramSrv)
	}

	return fmt.Sprintf(
		"[MOOD:keren] *╭─〔 ⚡ %s TELEMETRY 〕*\n"+
			"*├* 🤖 *Nama* : %s\n"+
			"*├* 🔐 *ID* : rahasia\n"+
			"*├* 🟢 *Status* : Online ✅\n"+
			"*├* 🧠 *Model* : %s\n"+
			"*├* ⚙️ *Engine* : Multi-WA v9.1\n"+
			"*╰* 📂 *Tipe* : Cloud Server Mandiri\n\n"+
			"*╭─〔 ⏱️ WAKTU AKTIF 〕*\n"+
			"*├* 🚀 *Proses* : %s\n"+
			"*╰* 🖥️ *Server* : %s\n\n"+
			"*╭─〔 💻 SISTEM & CPU 〕*\n"+
			"*├* 🔧 *Runtime* : %s\n"+
			"*├* 🐧 *OS* : %s\n"+
			"*├* 💠 *CPU* : %d Core\n"+
			"*╰* 📈 *Load* : %s\n\n"+
			"*╭─〔 💾 MEMORI RAM 〕*\n"+
			"*├* 📊 *RSS* : %.2f MB\n"+
			"*├* 🧩 *Heap* : %.2f / %.2f MB\n"+
			"*├* 🛰️ *Ext* : %.2f MB\n"+
			"%s"+
			"*╰* 🔋 *Status* : Stabil\n\n"+
			"*╭─〔 📈 STATISTIK BOT 〕*\n"+
			"*├* 📦 *Fitur* : 48 Modul Aktif\n"+
			"*├* 📱 *Sesi WA* : %d Nomor Aktif\n"+
			"*├* 👥 *Users* : %d Pengguna\n"+
			"*├* 💬 *Chats* : %d Ruang Chat\n"+
			"*╰* ✨ *AI Reply* : %d Balasan\n\n"+
			"_Ketik *.menu* untuk membuka daftar perintah_",
		strings.ToUpper(botName),
		botName,
		aiModel,
		procUp,
		sysUp,
		runtime.Version(),
		platformStr,
		cpuCores,
		loadAvg,
		rssMB,
		heapUsedMB,
		heapTotalMB,
		extMB,
		ramLine,
		activeSessCount,
		usersCount,
		chatsCount,
		repliedCount,
	)
}

func handleSlashCommands(ctx context.Context, sess *SessionInstance, v *events.Message, text string) bool {
	trimmedText := strings.TrimSpace(text)
	if strings.HasPrefix(trimmedText, ".") && len(trimmedText) > 1 && trimmedText[1] != '.' && trimmedText[1] != ' ' {
		text = "/" + trimmedText[1:]
	}
	lower := strings.ToLower(strings.TrimSpace(text))
	chatKey := v.Info.Chat.String()
	ctxInfo := extractContextInfo(v.Message)
	quotedText := extractQuotedText(ctxInfo)

	// 0c. Toggle Moderasi Grup (.welcome / .antilink / .antispam)
	if lower == "/welcome" || strings.HasPrefix(lower, "/welcome ") ||
		lower == "/antilink" || strings.HasPrefix(lower, "/antilink ") ||
		lower == "/antispam" || strings.HasPrefix(lower, "/antispam ") {
		if v.Info.IsGroup && !isSenderAdminOrOwner(ctx, sess, v.Info) {
			sendMsgReaction(ctx, sess, v.Info, "❌")
			return true
		}
		sendMsgReaction(ctx, sess, v.Info, "⏳")
		mu.Lock()
		if strings.HasPrefix(lower, "/welcome") {
			if strings.Contains(lower, "off") || strings.Contains(lower, "mati") {
				config.AutoWelcome = false
			} else if strings.Contains(lower, "on") || strings.Contains(lower, "aktif") {
				config.AutoWelcome = true
			} else {
				config.AutoWelcome = !config.AutoWelcome
			}
		} else if strings.HasPrefix(lower, "/antilink") {
			if strings.Contains(lower, "off") || strings.Contains(lower, "mati") {
				config.AntiLink = false
			} else if strings.Contains(lower, "on") || strings.Contains(lower, "aktif") {
				config.AntiLink = true
			} else {
				config.AntiLink = !config.AntiLink
			}
		} else {
			if strings.Contains(lower, "off") || strings.Contains(lower, "mati") {
				config.AntiSpam = false
			} else if strings.Contains(lower, "on") || strings.Contains(lower, "aktif") {
				config.AntiSpam = true
			} else {
				config.AntiSpam = !config.AntiSpam
			}
		}
		aw, al, as := config.AutoWelcome, config.AntiLink, config.AntiSpam
		mu.Unlock()
		savePersistedConfig()
		stStr := func(b bool) string {
			if b {
				return "ON ✅"
			}
			return "OFF ❌"
		}
		msg := fmt.Sprintf("[MOOD:keren] 🛡️ *STATUS MODERASI GRUP*\n\n*╭─〔 PENGATURAN AKTIF 〕*\n*├* 👋 *Auto-Welcome* : %s\n*├* 🔗 *Anti-Link* : %s\n*╰* 🚫 *Anti-Spam* : %s", stStr(aw), stStr(al), stStr(as))
		_ = sendBotTextWithErr(ctx, sess, v.Info.Chat, msg)
		sendMsgReaction(ctx, sess, v.Info, "✅")
		return true
	}

	// 0b. /model [nama_model]
	if lower == "/model" || strings.HasPrefix(lower, "/model ") {
		sendMsgReaction(ctx, sess, v.Info, "⏳")
		arg := strings.TrimSpace(strings.TrimPrefix(trimmedText, "/model"))
		arg = strings.TrimSpace(strings.TrimPrefix(arg, ".model"))
		if arg == "" {
			mu.Lock()
			curM := sanitizeModelName(config.Model)
			mu.Unlock()
			msg := fmt.Sprintf("[MOOD:keren] 🧠 *AI MODEL AKTIF SAAT INI*\n\n*╭─〔 KONFIGURASI MODEL 〕*\n*├* Aktif : *%s*\n*├* Pilihan :\n*├* • gemini-2.5-flash\n*├* • gemini-2.5-pro\n*├* • gemini-2.5-flash-lite\n*├* • gemini-3.8-flash\n*╰* Ketik *.model gemini-2.5-flash* untuk mengganti.", curM)
			_ = sendBotTextWithErr(ctx, sess, v.Info.Chat, msg)
			sendMsgReaction(ctx, sess, v.Info, "✅")
			return true
		}
		cleanM := sanitizeModelName(arg)
		mu.Lock()
		config.Model = cleanM
		mu.Unlock()
		savePersistedConfig()
		_ = sendBotTextWithErr(ctx, sess, v.Info.Chat, "[MOOD:ceria] ✅ *Model AI berhasil diubah ke:* *"+cleanM+"*")
		sendMsgReaction(ctx, sess, v.Info, "✅")
		return true
	}

	// 0a. /banner [on|off]
	if lower == "/banner" || strings.HasPrefix(lower, "/banner ") {
		sendMsgReaction(ctx, sess, v.Info, "⏳")
		arg := strings.TrimSpace(strings.TrimPrefix(lower, "/banner"))
		mu.Lock()
		if arg == "off" || arg == "mati" || arg == "teks" {
			bannerEnabled = false
		} else if arg == "on" || arg == "aktif" || arg == "nyala" {
			bannerEnabled = true
		} else {
			bannerEnabled = !bannerEnabled
		}
		curBanner := bannerEnabled
		mu.Unlock()
		statusStr := "AKTIF ✅ (Banner Ekspresi Anime tampil di setiap balasan)"
		if !curBanner {
			statusStr = "NONAKTIF 💬 (Mode Teks Murni tanpa foto banner)"
		}
		_ = sendBotTextWithErr(ctx, sess, v.Info.Chat, "[MOOD:ceria] 🎨 *Mode Banner Ekspresi:* "+statusStr+"\n\nKetik *.banner on* atau *.banner off* untuk mengubah.")
		sendMsgReaction(ctx, sess, v.Info, "✅")
		return true
	}

	// 0. /setname [nama bot baru]
	if strings.HasPrefix(lower, "/setname ") {
		if !isSenderAdminOrOwner(ctx, sess, v.Info) {
			sendMsgReaction(ctx, sess, v.Info, "❌")
			return true
		}
		newName := strings.TrimSpace(text[len("/setname "):])
		if newName == "" {
			sendMsgReaction(ctx, sess, v.Info, "❌")
			return true
		}
		sendMsgReaction(ctx, sess, v.Info, "⏳")
		mu.Lock()
		config.BotName = newName
		mu.Unlock()
		savePersistedConfig()
		if err := sendBotTextWithErr(ctx, sess, v.Info.Chat, "✅ Nama identitas bot berhasil diubah menjadi: *"+newName+"*"); err != nil {
			sendMsgReaction(ctx, sess, v.Info, "❌")
		} else {
			sendMsgReaction(ctx, sess, v.Info, "✅")
		}
		return true
	}

	// 1. /bot-active
	if strings.Contains(lower, "/bot-active") || strings.Contains(lower, "/boton") {
		if v.Info.IsGroup {
			if !isBotTaggedOrReplied(sess, v.Info, v.Message, text) && !isSenderAdminOrOwner(ctx, sess, v.Info) {
				return false
			}
			sendMsgReaction(ctx, sess, v.Info, "⏳")
			mu.Lock()
			activeGroups[chatKey] = true
			mu.Unlock()
			addLog("[Grup Aktif] Bot diaktifkan di grup " + chatKey)
			if err := sendBotTextWithErr(ctx, sess, v.Info.Chat, "🤖 *Bot AI Sekarang AKTIF di Grup Ini!*\n\n• Cara tanya AI: *Tag nomor ini* atau *Reply pesan bot*.\n• Fitur Pintar: Reply pesan lalu ketik *.ringkas* atau *.terjemah*.\n• Status Grup HD: Admin dapat ketik *.upstatus*.\n• Ketik *.menu* untuk daftar perintah lengkap."); err != nil {
				sendMsgReaction(ctx, sess, v.Info, "❌")
			} else {
				sendMsgReaction(ctx, sess, v.Info, "✅")
			}
			return true
		} else {
			sendMsgReaction(ctx, sess, v.Info, "⏳")
			mu.Lock()
			mutedPrivate[chatKey] = false
			delete(manualPauseUntil, chatKey)
			mu.Unlock()
			if err := sendBotTextWithErr(ctx, sess, v.Info.Chat, "🤖 *Bot AI diaktifkan kembali di ruang chat ini.*"); err != nil {
				sendMsgReaction(ctx, sess, v.Info, "❌")
			} else {
				sendMsgReaction(ctx, sess, v.Info, "✅")
			}
			return true
		}
	}

	// 2. /bot-off
	if strings.Contains(lower, "/bot-off") || strings.Contains(lower, "/botoff") {
		if v.Info.IsGroup {
			if !isBotTaggedOrReplied(sess, v.Info, v.Message, text) && !isSenderAdminOrOwner(ctx, sess, v.Info) {
				return false
			}
			sendMsgReaction(ctx, sess, v.Info, "⏳")
			mu.Lock()
			activeGroups[chatKey] = false
			mu.Unlock()
			addLog("[Grup Nonaktif] Bot dimatikan di grup " + chatKey)
			if err := sendBotTextWithErr(ctx, sess, v.Info.Chat, "💤 *Bot AI dinonaktifkan di grup ini.* Tag nomor ini dan ketik *.bot-active* jika ingin menyalakan kembali."); err != nil {
				sendMsgReaction(ctx, sess, v.Info, "❌")
			} else {
				sendMsgReaction(ctx, sess, v.Info, "✅")
			}
			return true
		} else {
			sendMsgReaction(ctx, sess, v.Info, "⏳")
			mu.Lock()
			mutedPrivate[chatKey] = true
			mu.Unlock()
			if err := sendBotTextWithErr(ctx, sess, v.Info.Chat, "💤 *Bot AI dinonaktifkan untuk ruang chat ini.* Ketik *.bot-active* untuk menyalakan kembali."); err != nil {
				sendMsgReaction(ctx, sess, v.Info, "❌")
			} else {
				sendMsgReaction(ctx, sess, v.Info, "✅")
			}
			return true
		}
	}

	// 3a. Respons Persetujuan Pairing .upstatus ("setuju", ".setuju", "batal", ".putusstatus")
	if !v.Info.IsGroup && (lower == "setuju" || lower == "/setuju" || strings.HasPrefix(lower, "setuju ") || strings.HasPrefix(lower, "/setuju ") || lower == "batal" || lower == "/batal" || lower == "/putusstatus") {
		if lower == "/putusstatus" {
			sPhone := extractSenderPhone(sess, v.Info)
			if sPhone != "" && sPhone != normalizePhone(sess.Phone) {
				destroySessionAndDB(sPhone)
				saveSessionsMeta()
				_ = sendBotTextWithErr(ctx, sess, v.Info.Chat, "[MOOD:tenang] 🔓 *Tautan Perangkat Status HD Dilepas.*\nSesi WhatsApp Anda (+"+sPhone+") telah dihapus dari sistem.")
				sendMsgReaction(ctx, sess, v.Info, "✅")
				return true
			}
		}
		mu.Lock()
		pendingJob, hasPending := pendingUpstatusMap[chatKey]
		mu.Unlock()
		if hasPending && pendingJob != nil {
			if lower == "batal" || lower == "/batal" {
				mu.Lock()
				delete(pendingUpstatusMap, chatKey)
				mu.Unlock()
				_ = sendBotTextWithErr(ctx, sess, v.Info.Chat, "[MOOD:tenang] ❌ *Permintaan .upstatus dibatalkan.*")
				sendMsgReaction(ctx, sess, v.Info, "✅")
				return true
			}
			if time.Now().After(pendingJob.ExpiresAt) {
				mu.Lock()
				delete(pendingUpstatusMap, chatKey)
				mu.Unlock()
				_ = sendBotTextWithErr(ctx, sess, v.Info.Chat, "[MOOD:sedih] ⏰ *Batas waktu persetujuan 5 menit telah habis.* Silakan kirim ulang perintah *.upstatus* jika masih ingin melanjutkan.")
				sendMsgReaction(ctx, sess, v.Info, "❌")
				return true
			}
			argPhone := strings.TrimSpace(strings.TrimPrefix(strings.TrimPrefix(lower, "/setuju"), "setuju"))
			targetPhone := normalizePhone(argPhone)
			if len(targetPhone) < 9 {
				targetPhone = pendingJob.SenderPhone
			}
			if len(targetPhone) < 9 {
				_ = sendBotTextWithErr(ctx, sess, v.Info.Chat, "[MOOD:bingung] 📱 Nomor telepon Anda tersembunyi oleh privasi ID WhatsApp. Silakan ketik:\n*setuju 08xxxxxxxxxx*\n*(ganti dengan nomor WA Anda)*")
				sendMsgReaction(ctx, sess, v.Info, "⏳")
				return true
			}
			sendMsgReaction(ctx, sess, v.Info, "⏳")
			go func(job *PendingUpstatusJob, phoneToPair string) {
				bgCtx := context.Background()
				if existingSess := findLoggedInSessionByPhone(phoneToPair); existingSess != nil {
					if err := executePendingUpstatusForSession(bgCtx, existingSess, sess, v.Info.Chat, job); err == nil {
						mu.Lock()
						delete(pendingUpstatusMap, chatKey)
						mu.Unlock()
						sendMsgReaction(bgCtx, sess, v.Info, "✅")
					} else {
						sendMsgReaction(bgCtx, sess, v.Info, "❌")
					}
					return
				}

				destroySessionAndDB(phoneToPair)
				dbFile := fmt.Sprintf("session_%s.db", phoneToPair)
				removeSqliteFiles(dbFile)
				guestSess, err := createOrLoadSession(phoneToPair, phoneToPair, dbFile, true)
				if err != nil || guestSess == nil || guestSess.Client == nil {
					_ = sendBotTextWithErr(bgCtx, sess, v.Info.Chat, "[MOOD:sedih] ⚠️ Gagal menyiapkan sesi pairing. Coba lagi sesaat lagi.")
					sendMsgReaction(bgCtx, sess, v.Info, "❌")
					return
				}
				mu.Lock()
				guestSess.GuestStatusOnly = true
				mu.Unlock()
				if guestSess.Client.IsConnected() {
					guestSess.Client.Disconnect()
					time.Sleep(300 * time.Millisecond)
				}
				if err := guestSess.Client.Connect(); err != nil {
					sendMsgReaction(bgCtx, sess, v.Info, "❌")
					return
				}
				for i := 0; i < 20; i++ {
					if guestSess.Client.IsConnected() {
						break
					}
					time.Sleep(100 * time.Millisecond)
				}
				time.Sleep(900 * time.Millisecond)

				codeStr, err := guestSess.Client.PairPhone(
					context.Background(),
					phoneToPair,
					true,
					whatsmeow.PairClientChrome,
					"Chrome (Linux)",
				)
				if err != nil || codeStr == "" {
					destroySessionAndDB(phoneToPair)
					_ = sendBotTextWithErr(bgCtx, sess, v.Info.Chat, "[MOOD:sedih] ⚠️ Gagal meminta kode pairing untuk nomor +"+phoneToPair+". Pastikan nomor WA aktif.")
					sendMsgReaction(bgCtx, sess, v.Info, "❌")
					return
				}

				mu.Lock()
				guestSess.PairingCode = codeStr
				guestSess.State = "WAITING_GUEST_UPSTATUS_PAIR"
				job.PairSent = true
				job.ExpiresAt = time.Now().Add(5 * time.Minute)
				mu.Unlock()

				codeMsg := fmt.Sprintf(
					"[MOOD:keren] 🔑 *KODE PAIRING WA ANDA (+%s)*\n\n"+
						"*╭─〔 📋 KODE 8 DIGIT 〕*\n"+
						"*╰* 👉 *%s*\n\n"+
						"*╭─〔 📲 CARA MEMASUKKAN KODE 〕*\n"+
						"*├* 1. Buka WhatsApp di HP Anda\n"+
						"*├* 2. Ketuk titik tiga ➔ *Perangkat Tertaut*\n"+
						"*├* 3. Ketuk *Tautkan Perangkat*\n"+
						"*├* 4. Pilih *Tautkan dengan nomor telepon saja*\n"+
						"*├* 5. Masukkan kode *%s* di atas\n"+
						"*╰* ⏳ *Batas Waktu: 5 Menit.* Begitu tertaut, Status HD Anda langsung diunggah otomatis!",
					phoneToPair, codeStr, codeStr,
				)
				_ = sendBotTextWithErr(bgCtx, sess, v.Info.Chat, codeMsg)
				sendMsgReaction(bgCtx, sess, v.Info, "✅")

				deadline := time.Now().Add(5 * time.Minute)
				for time.Now().Before(deadline) {
					time.Sleep(1500 * time.Millisecond)
					mu.Lock()
					st := guestSess.State
					mu.Unlock()
					if guestSess.Client != nil && guestSess.Client.IsLoggedIn() && guestSess.Client.IsConnected() && st == "CONNECTED" {
						mu.Lock()
						guestSess.GuestStatusOnly = true
						guestSess.Active = false
						delete(pendingUpstatusMap, chatKey)
						mu.Unlock()
						_ = guestSess.Client.SendPresence(bgCtx, types.PresenceAvailable)
						saveSessionsMeta()
						time.Sleep(6000 * time.Millisecond)
						if err := executePendingUpstatusForSession(bgCtx, guestSess, sess, v.Info.Chat, job); err != nil {
							addLog("[Guest Upstatus Error] " + err.Error())
							_ = sendBotTextWithErr(bgCtx, sess, v.Info.Chat, "[MOOD:tenang] ✅ *Perangkat Berhasil Tertaut!*\nSilakan kirim ulang perintah *.upstatus* Anda untuk langsung menayangkan Status HD.")
						}
						return
					}
				}

				if guestSess.Client == nil || !guestSess.Client.IsLoggedIn() {
					destroySessionAndDB(phoneToPair)
					mu.Lock()
					delete(pendingUpstatusMap, chatKey)
					mu.Unlock()
					_ = sendBotTextWithErr(bgCtx, sess, v.Info.Chat, "[MOOD:tenang] ⏰ *Waktu Pairing 5 Menit Habis.*\nKode pairing untuk +"+phoneToPair+" telah kedaluwarsa dan dibatalkan otomatis demi keamanan.")
				}
			}(pendingJob, targetPhone)
			return true
		}
	}

	// 3. /upstatus atau .upstatus (Grup = Status Grup khusus Admin; Japri = Status WA Pengirim dengan Pairing 5 Menit!)
	if strings.HasPrefix(lower, "/upstatus") {
		if v.Info.IsGroup && !isSenderAdminOrOwner(ctx, sess, v.Info) {
			sendMsgReaction(ctx, sess, v.Info, "❌")
			return true
		}
		sendMsgReaction(ctx, sess, v.Info, "⏳")
		caption := strings.TrimSpace(text[len("/upstatus"):])
		var imgMsg *waE2E.ImageMessage
		var vidMsg *waE2E.VideoMessage

		if v.Message.GetImageMessage() != nil {
			imgMsg = v.Message.GetImageMessage()
		} else if v.Message.GetVideoMessage() != nil {
			vidMsg = v.Message.GetVideoMessage()
		} else if ctxInfo != nil && ctxInfo.GetQuotedMessage() != nil {
			qm := unwrapWaMessage(ctxInfo.GetQuotedMessage())
			if qm != nil {
				if qm.GetImageMessage() != nil {
					imgMsg = qm.GetImageMessage()
				} else if qm.GetVideoMessage() != nil {
					vidMsg = qm.GetVideoMessage()
				}
			}
		}

		statusLinkUrl := extractFirstUrl(caption)
		if statusLinkUrl == "" && quotedText != "" {
			statusLinkUrl = extractFirstUrl(quotedText)
		}

		var mentions []string
		if ctxInfo != nil {
			for _, m := range ctxInfo.GetMentionedJID() {
				userPart := strings.Split(m, "@")[0]
				if norm := normalizePhone(userPart); len(norm) >= 9 {
					mentions = append(mentions, norm)
				}
			}
		}

		go func() {
			bgCtx := context.Background()
			var jobMediaType string
			var jobBytes []byte
			var jobMime string
			var jobLink string
			cleanCap := caption

			if imgMsg != nil {
				rawBytes, err := sess.Client.Download(bgCtx, imgMsg)
				if err != nil || len(rawBytes) == 0 {
					sendMsgReaction(bgCtx, sess, v.Info, "❌")
					return
				}
				if cleanCap == "" {
					cleanCap = imgMsg.GetCaption()
					if strings.HasPrefix(strings.ToLower(cleanCap), "/upstatus") || strings.HasPrefix(strings.ToLower(cleanCap), ".upstatus") {
						cleanCap = strings.TrimSpace(cleanCap[len("/upstatus"):])
					}
				}
				jobMediaType = "image"
				jobBytes = rawBytes
				jobMime = imgMsg.GetMimetype()
			} else if vidMsg != nil {
				rawBytes, err := sess.Client.Download(bgCtx, vidMsg)
				if err != nil || len(rawBytes) == 0 {
					mu.Lock()
					cachedVid := lastChatVideoCache[chatKey]
					mu.Unlock()
					if len(cachedVid) > 0 {
						rawBytes = cachedVid
						err = nil
					}
				}
				if err != nil || len(rawBytes) == 0 {
					sendMsgReaction(bgCtx, sess, v.Info, "❌")
					return
				}
				if cleanCap == "" {
					cleanCap = vidMsg.GetCaption()
					if strings.HasPrefix(strings.ToLower(cleanCap), "/upstatus") || strings.HasPrefix(strings.ToLower(cleanCap), ".upstatus") {
						cleanCap = strings.TrimSpace(cleanCap[len("/upstatus"):])
					}
					if strings.HasPrefix(cleanCap, "📥 *DOWNLOADER") {
						cleanCap = ""
					}
				}
				jobMediaType = "video"
				jobBytes = rawBytes
				jobMime = "video/mp4"
			} else if statusLinkUrl != "" && isSupportedMediaLink(statusLinkUrl) {
				cleanCap = strings.TrimSpace(strings.ReplaceAll(cleanCap, statusLinkUrl, ""))
				jobMediaType = "link"
				jobLink = statusLinkUrl
			} else if cleanCap == "" && quotedText == "" {
				mu.Lock()
				cachedVid := lastChatVideoCache[chatKey]
				mu.Unlock()
				if len(cachedVid) > 0 {
					jobMediaType = "video"
					jobBytes = cachedVid
					jobMime = "video/mp4"
				}
			} else {
				if cleanCap == "" {
					cleanCap = quotedText
				}
				if cleanCap != "" {
					jobMediaType = "text"
					jobMime = "text/plain"
				}
			}

			if jobMediaType == "" {
				sendMsgReaction(bgCtx, sess, v.Info, "❌")
				return
			}

			if v.Info.IsGroup {
				if jobMediaType == "link" && jobLink != "" {
					var dlErr error
					if strings.Contains(strings.ToLower(jobLink), "tiktok.com") {
						jobBytes, jobMime, _, dlErr = downloadViaTikWM(jobLink, false)
					}
					if dlErr != nil || len(jobBytes) == 0 {
						jobBytes, jobMime, _, dlErr = downloadViaUniversalApi(jobLink, false)
					}
					if dlErr != nil || len(jobBytes) == 0 {
						sendMsgReaction(bgCtx, sess, v.Info, "❌")
						return
					}
					jobMediaType = "video"
					jobMime = "video/mp4"
					mu.Lock()
					lastChatVideoCache[chatKey] = jobBytes
					mu.Unlock()
				}
				if err := uploadGroupStatusHD(bgCtx, sess, v.Info.Chat, jobMediaType, jobBytes, jobMime, cleanCap, mentions); err != nil {
					addLog("[Group Status Error] " + err.Error())
					sendMsgReaction(bgCtx, sess, v.Info, "❌")
				} else {
					sendMsgReaction(bgCtx, sess, v.Info, "✅")
					_ = sendBotTextWithErr(bgCtx, sess, v.Info.Chat, "[MOOD:bangga] 👑 *STATUS GRUP HD BERHASIL DITAYANGKAN!*\nStatus Full HD kini aktif di profil grup ini.")
				}
				return
			}

			senderPhone := extractSenderPhone(sess, v.Info)
			pendingJob := &PendingUpstatusJob{
				SenderPhone: senderPhone,
				ChatJID:     v.Info.Chat,
				MediaType:   jobMediaType,
				RawBytes:    jobBytes,
				MimeType:    jobMime,
				LinkUrl:     jobLink,
				Caption:     cleanCap,
				Mentions:    mentions,
				ExpiresAt:   time.Now().Add(5 * time.Minute),
			}

			if senderSess := findLoggedInSessionByPhone(senderPhone); senderSess != nil {
				if err := executePendingUpstatusForSession(bgCtx, senderSess, sess, v.Info.Chat, pendingJob); err != nil {
					addLog("[Upstatus Sender Error] " + err.Error())
					sendMsgReaction(bgCtx, sess, v.Info, "❌")
				} else {
					sendMsgReaction(bgCtx, sess, v.Info, "✅")
				}
				return
			}

			mu.Lock()
			pendingUpstatusMap[chatKey] = pendingJob
			mu.Unlock()
			sendUpstatusConsentPrompt(bgCtx, sess, v.Info.Chat, senderPhone)
			sendMsgReaction(bgCtx, sess, v.Info, "✅")
		}()
		return true
	}

	// 2b. Multi-Platform Video HD & MP3 Downloader (/download, /dl, /mp3, /ytmp3, /ytmp4, /ig, /fb, /tw, atau Kirim Link Langsung)
	isAudioCmd := strings.HasPrefix(lower, "/mp3") || strings.HasPrefix(lower, "/ytmp3") || strings.HasPrefix(lower, "/play ")
	isVideoCmd := strings.HasPrefix(lower, "/download") || strings.HasPrefix(lower, "/dl") || strings.HasPrefix(lower, "/ytmp4") || strings.HasPrefix(lower, "/ig") || strings.HasPrefix(lower, "/fb") || strings.HasPrefix(lower, "/tw") || strings.HasPrefix(lower, "/tt")
	isDownloadCmd := isAudioCmd || isVideoCmd
	detectedUrl := extractFirstUrl(text)
	if detectedUrl == "" && quotedText != "" {
		detectedUrl = extractFirstUrl(quotedText)
	}
	isAutoLinkTrigger := false
	if !isDownloadCmd && !strings.HasPrefix(lower, "/") && detectedUrl != "" && isSupportedMediaLink(detectedUrl) && !v.Info.IsFromMe {
		if !v.Info.IsGroup {
			isAutoLinkTrigger = true
		} else if isBotTaggedOrReplied(sess, v.Info, v.Message, text) {
			isAutoLinkTrigger = true
		}
	}
	if isDownloadCmd || isAutoLinkTrigger {
		if v.Info.IsGroup && !activeGroups[chatKey] && !isBotTaggedOrReplied(sess, v.Info, v.Message, text) && !isSenderAdminOrOwner(ctx, sess, v.Info) {
			return false
		}
		if detectedUrl == "" {
			sendMsgReaction(ctx, sess, v.Info, "❌")
			return true
		}
		audioOnly := isAudioCmd || strings.Contains(lower, " mp3")
		go processAndSendLinkDownload(context.Background(), sess, v.Info, detectedUrl, audioOnly)
		return true
	}

	// 4. /menu, /help, /menulist, /menuteks, /allmenu, and /menu <kategori>
	if lower == "/menu" || lower == ".menu" || lower == "/help" || lower == "/menulist" || lower == "/menuteks" || lower == "/allmenu" || strings.HasPrefix(lower, "/menu ") {
		if v.Info.IsGroup && !activeGroups[chatKey] && !isSenderAdminOrOwner(ctx, sess, v.Info) {
			return false
		}
		sendMsgReaction(ctx, sess, v.Info, "⏳")
		mu.Lock()
		style := config.MenuStyle
		bName := strings.TrimSpace(config.BotName)
		mu.Unlock()
		if bName == "" {
			bName = "DodosBot"
		}
		if style == "" {
			style = "both"
		}

		if strings.HasPrefix(lower, "/menu ") {
			subCat := strings.TrimSpace(lower[len("/menu "):])
			catText := buildCategoryTextMenu(subCat)
			var sendErr error
			if style == "text" {
				sendErr = sendBotTextWithErr(ctx, sess, v.Info.Chat, catText)
			} else {
				if err := sendInteractiveMenuList(ctx, sess, v.Info.Chat, "📂 KATEGORI: "+strings.ToUpper(subCat), catText, "Pilih kategori lain lewat tombol di bawah"); err != nil {
					sendErr = sendBotTextWithErr(ctx, sess, v.Info.Chat, catText)
				}
			}
			if sendErr != nil {
				sendMsgReaction(ctx, sess, v.Info, "❌")
			} else {
				sendMsgReaction(ctx, sess, v.Info, "✅")
			}
			return true
		}

		if lower == "/menuteks" || lower == "/allmenu" || style == "text" {
			if err := sendBotTextWithErr(ctx, sess, v.Info.Chat, buildFullTextMenu()); err != nil {
				sendMsgReaction(ctx, sess, v.Info, "❌")
			} else {
				sendMsgReaction(ctx, sess, v.Info, "✅")
			}
			return true
		}

		if lower == "/menulist" || style == "list" {
			shortIntro := "Silakan tekan tombol *🗂️ Menu List* di bawah untuk membuka 13 kategori perintah lengkap, atau ketik *.menuteks* untuk tampilan daftar teks lengkap."
			var sendErr error
			if err := sendInteractiveMenuList(ctx, sess, v.Info.Chat, "⚡ "+strings.ToUpper(bName)+" MENU v9.1", shortIntro, "Pilih kategori lalu tekan tombol Pilih"); err != nil {
				sendErr = sendBotTextWithErr(ctx, sess, v.Info.Chat, buildFullTextMenu())
			}
			if sendErr != nil {
				sendMsgReaction(ctx, sess, v.Info, "❌")
			} else {
				sendMsgReaction(ctx, sess, v.Info, "✅")
			}
			return true
		}

		fullBody := buildFullTextMenu()
		var sendErr error
		if err := sendInteractiveMenuList(ctx, sess, v.Info.Chat, "⚡ "+strings.ToUpper(bName)+" MENU v9.1", fullBody, "Pilih kategori di 🗂️ Menu List atau ketik perintah langsung"); err != nil {
			sendErr = sendBotTextWithErr(ctx, sess, v.Info.Chat, fullBody)
		}
		if sendErr != nil {
			sendMsgReaction(ctx, sess, v.Info, "❌")
		} else {
			sendMsgReaction(ctx, sess, v.Info, "✅")
		}
		return true
	}

	// 5. /info, /ping, /status, /runtime
	if lower == "/ping" || lower == "/status" || lower == "/info" || lower == "/runtime" {
		if v.Info.IsGroup && !activeGroups[chatKey] && !isSenderAdminOrOwner(ctx, sess, v.Info) {
			return false
		}
		sendMsgReaction(ctx, sess, v.Info, "⏳")
		telemetryText := buildBotTelemetryInfo()
		if err := sendBotTextWithErr(ctx, sess, v.Info.Chat, telemetryText); err != nil {
			sendMsgReaction(ctx, sess, v.Info, "❌")
		} else {
			sendMsgReaction(ctx, sess, v.Info, "✅")
		}
		return true
	}

	// 6. /reset
	if lower == "/reset" || lower == "/clear" {
		if v.Info.IsGroup && !activeGroups[chatKey] && !isSenderAdminOrOwner(ctx, sess, v.Info) {
			return false
		}
		sendMsgReaction(ctx, sess, v.Info, "⏳")
		mu.Lock()
		delete(memory, chatKey)
		mu.Unlock()
		if err := sendBotTextWithErr(ctx, sess, v.Info.Chat, "🧹 *Riwayat memori percakapan AI di ruang ini berhasil dibersihkan!*"); err != nil {
			sendMsgReaction(ctx, sess, v.Info, "❌")
		} else {
			sendMsgReaction(ctx, sess, v.Info, "✅")
		}
		return true
	}

	// 7. /ringkas, /terjemah, /ai, /cuaca, /berita, /quotes, /fakta, /pantun
	if strings.HasPrefix(lower, "/ringkas") || strings.HasPrefix(lower, "/terjemah") || strings.HasPrefix(lower, "/ai ") || strings.HasPrefix(lower, "/cuaca") || strings.HasPrefix(lower, "/berita") || lower == "/quotes" || lower == "/motivasi" || lower == "/fakta" || lower == "/pantun" || lower == "/waifu" || lower == "/neko" {
		if v.Info.IsGroup && !activeGroups[chatKey] && !isSenderAdminOrOwner(ctx, sess, v.Info) {
			return false
		}
		var prompt string
		switch {
		case strings.HasPrefix(lower, "/ringkas"):
			target := strings.TrimSpace(text[len("/ringkas"):])
			if quotedText != "" {
				target = quotedText + "\n" + target
			}
			if strings.TrimSpace(target) == "" {
				sendMsgReaction(ctx, sess, v.Info, "❌")
				return true
			}
			prompt = "Tolong buatkan ringkasan poin-poin penting yang jelas dan padat dalam bahasa Indonesia dari teks berikut:\n\n" + target
		case strings.HasPrefix(lower, "/terjemah"):
			arg := strings.TrimSpace(text[len("/terjemah"):])
			if quotedText == "" && arg == "" {
				sendMsgReaction(ctx, sess, v.Info, "❌")
				return true
			}
			prompt = fmt.Sprintf("Terjemahkan teks berikut (%s): \"%s\"", arg, quotedText)
		case strings.HasPrefix(lower, "/ai "):
			prompt = strings.TrimSpace(text[len("/ai "):])
		case strings.HasPrefix(lower, "/cuaca"):
			kota := strings.TrimSpace(text[len("/cuaca"):])
			if kota == "" {
				kota = "Banjarmasin"
			}
			prompt = "Berikan informasi prakiraan cuaca umum, suhu rata-rata, dan tips aktivitas untuk wilayah " + kota + " hari ini secara singkat dan rapi."
		case strings.HasPrefix(lower, "/berita"):
			topik := strings.TrimSpace(text[len("/berita"):])
			if topik == "" {
				topik = "teknologi terkini"
			}
			prompt = "Berikan rangkuman informasi dan wawasan menarik seputar topik: " + topik
		case lower == "/quotes" || lower == "/motivasi":
			prompt = "Berikan 1 kutipan motivasi hidup yang keren, mendalam, dan inspiratif dalam bahasa Indonesia beserta maknanya."
		case lower == "/fakta":
			prompt = "Berikan 1 fakta unik dunia atau sains yang jarang diketahui orang namun sangat menarik!"
		case lower == "/pantun":
			prompt = "Buatkan 1 pantun jenaka atau pantun semangat 4 baris yang keren dan berima!"
		default:
			prompt = "Berikan rekomendasi karakter anime populer beserta fakta menariknya!"
		}
		go func(p string) {
			bgCtx := context.Background()
			sendMsgReaction(bgCtx, sess, v.Info, "⏳")
			reply, err := callGeminiAPI(chatKey, p)
			if err != nil || strings.TrimSpace(reply) == "" {
				sendMsgReaction(bgCtx, sess, v.Info, "❌")
				return
			}
			if err := sendBotTextWithErr(bgCtx, sess, v.Info.Chat, reply); err != nil {
				sendMsgReaction(bgCtx, sess, v.Info, "❌")
			} else {
				sendMsgReaction(bgCtx, sess, v.Info, "✅")
			}
		}(prompt)
		return true
	}

	// 8. RPG Mini-Game (/rpg, /adventure, /heal, /profile)
	if lower == "/rpg" || lower == "/adventure" || lower == "/heal" || lower == "/profile" {
		if v.Info.IsGroup && !activeGroups[chatKey] && !isSenderAdminOrOwner(ctx, sess, v.Info) {
			return false
		}
		sendMsgReaction(ctx, sess, v.Info, "⏳")
		pKey := v.Info.Sender.User
		if pKey == "" {
			pKey = chatKey
		}
		mu.Lock()
		prof, ok := rpgPlayers[pKey]
		if !ok {
			prof = &RpgProfile{Level: 1, Exp: 0, Gold: 100, HP: 100}
			rpgPlayers[pKey] = prof
		}
		var out string
		switch lower {
		case "/heal":
			if prof.Gold < 25 {
				out = fmt.Sprintf("[MOOD:sedih]  🧪 Gold kamu tidak cukup untuk Heal (Butuh 25 Gold, Gold kamu: %d).", prof.Gold)
			} else {
				prof.Gold -= 25
				prof.HP = 100
				out = fmt.Sprintf("[MOOD:ceria] 💖 *HEAL BERHASIL!* HP kamu pulih 100/100. Sisa Gold: %d", prof.Gold)
			}
		case "/adventure":
			if prof.HP <= 15 {
				out = "[MOOD:panik] ⚠️ HP kamu kritis! Ketik *.heal* terlebih dahulu sebelum bertualang."
			} else {
				gainExp := 35
				gainGold := 40
				dmg := 15
				prof.Exp += gainExp
				prof.Gold += gainGold
				prof.HP -= dmg
				if prof.Exp >= prof.Level*100 {
					prof.Exp -= prof.Level * 100
					prof.Level++
					prof.HP = 100
					out = fmt.Sprintf("[MOOD:semangat] 🎉 *LEVEL UP!* Kamu naik ke *Level %d*!\n• +40 Gold (Total: %d)\n• HP Pulih: 100/100", prof.Level, prof.Gold)
				} else {
					out = fmt.Sprintf("[MOOD:keren] ⚔️ *PETUALANGAN BERHASIL!*\n• +%d EXP (%d/%d)\n• +%d Gold (Total: %d)\n• Sisa HP: %d/100", gainExp, prof.Exp, prof.Level*100, gainGold, prof.Gold, prof.HP)
				}
			}
		default:
			out = fmt.Sprintf("[MOOD:bangga] 🛡️ *PROFIL RPG (@%s)*\n• Level: %d\n• EXP: %d/%d\n• Gold: %d 🪙\n• HP: %d/100 ❤️\n\nKetik *.adventure* untuk bertarung atau *.heal* untuk memulihkan HP!", pKey, prof.Level, prof.Exp, prof.Level*100, prof.Gold, prof.HP)
		}
		mu.Unlock()
		if err := sendBotTextWithErr(ctx, sess, v.Info.Chat, out); err != nil {
			sendMsgReaction(ctx, sess, v.Info, "❌")
		} else {
			sendMsgReaction(ctx, sess, v.Info, "✅")
		}
		return true
	}

	// 9. Stalk / Cek Nomor WA (/cekwa)
	if strings.HasPrefix(lower, "/cekwa") {
		if v.Info.IsGroup && !activeGroups[chatKey] && !isSenderAdminOrOwner(ctx, sess, v.Info) {
			return false
		}
		arg := normalizePhone(strings.TrimSpace(text[len("/cekwa"):]))
		if len(arg) < 9 {
			sendMsgReaction(ctx, sess, v.Info, "❌")
			return true
		}
		sendMsgReaction(ctx, sess, v.Info, "⏳")
		res, err := sess.Client.IsOnWhatsApp(ctx, []string{"+" + arg})
		if err != nil || len(res) == 0 {
			sendMsgReaction(ctx, sess, v.Info, "❌")
			return true
		}
		statusTerdaftar := "❌ Tidak Terdaftar"
		if res[0].IsIn {
			statusTerdaftar = "✅ Terdaftar Aktif di WhatsApp"
		}
		if err := sendBotTextWithErr(ctx, sess, v.Info.Chat, fmt.Sprintf("[MOOD:keren] 🕵️ *HASIL CEK NOMOR WA*\n• Nomor: +%s\n• Status: %s\n• JID: %s", arg, statusTerdaftar, res[0].JID.String())); err != nil {
			sendMsgReaction(ctx, sess, v.Info, "❌")
		} else {
			sendMsgReaction(ctx, sess, v.Info, "✅")
		}
		return true
	}

	// 10. Group Moderation Commands
	if v.Info.IsGroup {
		isModCmd := strings.HasPrefix(lower, "/kick") || strings.HasPrefix(lower, "/promote") ||
			strings.HasPrefix(lower, "/demote") || strings.HasPrefix(lower, "/del") ||
			strings.HasPrefix(lower, "/hidetag") || lower == "/group close" || lower == "/group open"
		if isModCmd {
			if !isSenderAdminOrOwner(ctx, sess, v.Info) {
				sendMsgReaction(ctx, sess, v.Info, "❌")
				return true
			}
			targetParticipant := ""
			targetStanzaID := ""
			if ctxInfo != nil {
				targetParticipant = ctxInfo.GetParticipant()
				targetStanzaID = ctxInfo.GetStanzaID()
				if targetParticipant == "" && len(ctxInfo.GetMentionedJID()) > 0 {
					targetParticipant = ctxInfo.GetMentionedJID()[0]
				}
			}

			switch {
			case lower == "/group close":
				sendMsgReaction(ctx, sess, v.Info, "⏳")
				err := sess.Client.SetGroupAnnounce(ctx, v.Info.Chat, true)
				if err != nil {
					sendMsgReaction(ctx, sess, v.Info, "❌")
				} else {
					_ = sendBotTextWithErr(ctx, sess, v.Info.Chat, "🔒 *Grup berhasil ditutup (Hanya Admin yang dapat mengirim pesan).*")
					sendMsgReaction(ctx, sess, v.Info, "✅")
				}
				return true

			case lower == "/group open":
				sendMsgReaction(ctx, sess, v.Info, "⏳")
				err := sess.Client.SetGroupAnnounce(ctx, v.Info.Chat, false)
				if err != nil {
					sendMsgReaction(ctx, sess, v.Info, "❌")
				} else {
					_ = sendBotTextWithErr(ctx, sess, v.Info.Chat, "🔓 *Grup berhasil dibuka untuk semua anggota.*")
					sendMsgReaction(ctx, sess, v.Info, "✅")
				}
				return true

			case strings.HasPrefix(lower, "/hidetag"):
				announcement := strings.TrimSpace(text[len("/hidetag"):])
				if announcement == "" {
					announcement = quotedText
				}
				if announcement == "" {
					announcement = "📢 Pengumuman Grup"
				}
				sendMsgReaction(ctx, sess, v.Info, "⏳")
				gInfo, err := sess.Client.GetGroupInfo(ctx, v.Info.Chat)
				if err != nil || gInfo == nil {
					sendMsgReaction(ctx, sess, v.Info, "❌")
					return true
				}
				mentions := make([]string, 0, len(gInfo.Participants))
				for _, p := range gInfo.Participants {
					mentions = append(mentions, p.JID.String())
				}
				resp, sendErr := sess.Client.SendMessage(ctx, v.Info.Chat, &waE2E.Message{
					ExtendedTextMessage: &waE2E.ExtendedTextMessage{
						Text: proto.String(announcement),
						ContextInfo: &waE2E.ContextInfo{
							MentionedJID: mentions,
						},
					},
				})
				if sendErr == nil && resp.ID != "" {
					mu.Lock()
					botSentIDs[resp.ID] = true
					mu.Unlock()
					sendMsgReaction(ctx, sess, v.Info, "✅")
				} else {
					sendMsgReaction(ctx, sess, v.Info, "❌")
				}
				return true

			case strings.HasPrefix(lower, "/del"):
				if targetStanzaID == "" || targetParticipant == "" {
					sendMsgReaction(ctx, sess, v.Info, "❌")
					return true
				}
				sendMsgReaction(ctx, sess, v.Info, "⏳")
				senderJID, err := types.ParseJID(targetParticipant)
				if err != nil {
					sendMsgReaction(ctx, sess, v.Info, "❌")
					return true
				}
				revokeMsg := sess.Client.BuildRevoke(v.Info.Chat, senderJID, targetStanzaID)
				if _, err := sess.Client.SendMessage(ctx, v.Info.Chat, revokeMsg); err != nil {
					sendMsgReaction(ctx, sess, v.Info, "❌")
				} else {
					sendMsgReaction(ctx, sess, v.Info, "✅")
				}
				return true

			case strings.HasPrefix(lower, "/kick"), strings.HasPrefix(lower, "/promote"), strings.HasPrefix(lower, "/demote"):
				if targetParticipant == "" {
					sendMsgReaction(ctx, sess, v.Info, "❌")
					return true
				}
				sendMsgReaction(ctx, sess, v.Info, "⏳")
				targetJID, err := types.ParseJID(targetParticipant)
				if err != nil {
					sendMsgReaction(ctx, sess, v.Info, "❌")
					return true
				}
				var action whatsmeow.ParticipantChange
				var label string
				if strings.HasPrefix(lower, "/kick") {
					action = whatsmeow.ParticipantChangeRemove
					label = "dikeluarkan dari grup"
				} else if strings.HasPrefix(lower, "/promote") {
					action = whatsmeow.ParticipantChangePromote
					label = "dijadikan Admin grup"
				} else {
					action = whatsmeow.ParticipantChangeDemote
					label = "diberhentikan dari Admin grup"
				}
				_, err = sess.Client.UpdateGroupParticipants(ctx, v.Info.Chat, []types.JID{targetJID}, action)
				if err != nil {
					sendMsgReaction(ctx, sess, v.Info, "❌")
				} else {
					_ = sendBotTextWithErr(ctx, sess, v.Info.Chat, fmt.Sprintf("✅ Anggota @%s berhasil %s.", targetJID.User, label))
					sendMsgReaction(ctx, sess, v.Info, "✅")
				}
				return true
			}
		}
	}

	return false
}

func sanitizeModelName(m string) string {
	m = strings.TrimSpace(m)
	if m == "" || strings.Contains(strings.ToLower(m), "1.5") {
		return "gemini-2.5-flash"
	}
	return m
}

func savePersistedConfig() {
	mu.Lock()
	data, err := json.MarshalIndent(config, "", "  ")
	mu.Unlock()
	if err == nil {
		_ = os.WriteFile("bot_config.json", data, 0600)
	}
}

func loadPersistedConfig() {
	data, err := os.ReadFile("bot_config.json")
	if err == nil && len(data) > 0 {
		var loaded BotConfig
		if json.Unmarshal(data, &loaded) == nil {
			needResave := strings.Contains(strings.ToLower(loaded.Model), "1.5") || strings.TrimSpace(loaded.Model) == ""
			loaded.Model = sanitizeModelName(loaded.Model)
			mu.Lock()
			if loaded.DefaultStatusMode == "" {
				loaded.DefaultStatusMode = "contacts"
			}
			config = loaded
			mu.Unlock()
			if needResave {
				savePersistedConfig()
			}
		}
	}
}

func saveSessionsMeta() {
	mu.Lock()
	list := make([]SessionMeta, 0, len(sessions))
	for _, s := range sessions {
		if s.Client != nil && s.Client.Store != nil && s.Client.Store.ID != nil {
			list = append(list, SessionMeta{
				ID:              s.ID,
				Phone:           s.Phone,
				DBFile:          s.DBFile,
				Active:          s.Active,
				GuestStatusOnly: s.GuestStatusOnly,
			})
		}
	}
	mu.Unlock()
	if data, err := json.MarshalIndent(list, "", "  "); err == nil {
		_ = os.WriteFile("sessions_meta.json", data, 0600)
	}
}

func addLog(entry string) {
	mu.Lock()
	defer mu.Unlock()
	ts := time.Now().Format("15:04:05")
	line := fmt.Sprintf("[%s] %s", ts, entry)
	logs = append(logs, line)
	if len(logs) > 150 {
		logs = logs[len(logs)-150:]
	}
	log.Println(line)
}

func normalizePhone(phone string) string {
	clean := strings.Map(func(r rune) rune {
		if r >= '0' && r <= '9' {
			return r
		}
		return -1
	}, phone)
	if strings.HasPrefix(clean, "08") {
		clean = "62" + clean[1:]
	} else if strings.HasPrefix(clean, "8") && len(clean) >= 9 {
		clean = "62" + clean
	}
	return clean
}

func parsePhoneList(raw string) []string {
	if strings.TrimSpace(raw) == "" {
		return nil
	}
	parts := strings.FieldsFunc(raw, func(r rune) bool {
		return r == ',' || r == ';' || r == '\n' || r == ' '
	})
	seen := make(map[string]bool)
	out := make([]string, 0, len(parts))
	for _, p := range parts {
		norm := normalizePhone(p)
		if len(norm) >= 9 && !seen[norm] {
			seen[norm] = true
			out = append(out, norm)
		}
	}
	return out
}

func isNumberBlacklisted(senderUser string) bool {
	if senderUser == "" {
		return false
	}
	mu.Lock()
	rawList := config.BlacklistNumbers
	mu.Unlock()
	if strings.TrimSpace(rawList) == "" {
		return false
	}
	parts := strings.Split(rawList, ",")
	for _, p := range parts {
		norm := normalizePhone(p)
		if norm != "" && (strings.Contains(senderUser, norm) || strings.Contains(norm, senderUser)) {
			return true
		}
	}
	return false
}

func recordUiMessage(sess *SessionInstance, chatJID string, title string, isGroup bool, sender string, text string, fromMe bool, msgID string) {
	if sess == nil || chatJID == "" || chatJID == "status@broadcast" {
		return
	}
	mu.Lock()
	defer mu.Unlock()
	if sess.Chats == nil {
		sess.Chats = make(map[string]*UiChatThread)
	}
	th, ok := sess.Chats[chatJID]
	if !ok {
		if title == "" {
			title = strings.Split(chatJID, "@")[0]
		}
		th = &UiChatThread{
			ChatJID:  chatJID,
			Title:    title,
			IsGroup:  isGroup,
			Messages: make([]UiChatMessage, 0, 50),
		}
		sess.Chats[chatJID] = th
	} else if title != "" && th.Title == strings.Split(chatJID, "@")[0] {
		th.Title = title
	}
	th.LastMessage = text
	th.UpdatedAt = time.Now().Unix()
	th.Messages = append(th.Messages, UiChatMessage{
		ID:        msgID,
		Sender:    sender,
		Text:      text,
		FromMe:    fromMe,
		Timestamp: time.Now().Format("15:04"),
	})
	if len(th.Messages) > 60 {
		th.Messages = th.Messages[len(th.Messages)-60:]
	}
}

func removeSqliteFiles(dbFile string) {
	_ = os.Remove(dbFile)
	_ = os.Remove(dbFile + "-wal")
	_ = os.Remove(dbFile + "-shm")
}

func callGeminiSingleEndpoint(endpointUrl, apiKey, model string, bodyBytes []byte) (string, int, error) {
	req, err := http.NewRequest("POST", endpointUrl, bytes.NewBuffer(bodyBytes))
	if err != nil {
		return "", 0, err
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("x-goog-api-key", apiKey)

	client := &http.Client{Timeout: 35 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		return "", 0, err
	}
	defer resp.Body.Close()

	respBytes, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", resp.StatusCode, err
	}

	if resp.StatusCode != 200 {
		return "", resp.StatusCode, fmt.Errorf("HTTP %d (%s): %s", resp.StatusCode, model, string(respBytes))
	}

	var parsed struct {
		Candidates []struct {
			Content struct {
				Parts []struct {
					Text string `json:"text"`
				} `json:"parts"`
			} `json:"content"`
		} `json:"candidates"`
	}
	if err := json.Unmarshal(respBytes, &parsed); err != nil {
		return "", 200, err
	}

	if len(parsed.Candidates) == 0 || len(parsed.Candidates[0].Content.Parts) == 0 {
		return "", 200, fmt.Errorf("kandidat respons kosong")
	}

	return strings.TrimSpace(parsed.Candidates[0].Content.Parts[0].Text), 200, nil
}

func callGeminiSingleModel(apiKey, model, sysPrompt string, history []ChatTurn, userText string) (string, int, error) {
	mu.Lock()
	bName := strings.TrimSpace(config.BotName)
	mu.Unlock()
	if bName == "" {
		bName = "DodosBot"
	}

	contents := make([]map[string]interface{}, 0)
	for _, turn := range history {
		r := turn.Role
		if r == "" {
			r = "user"
		}
		contents = append(contents, map[string]interface{}{
			"role": r,
			"parts": []map[string]string{
				{"text": turn.Text},
			},
		})
	}
	contents = append(contents, map[string]interface{}{
		"role": "user",
		"parts": []map[string]string{
			{"text": userText},
		},
	})

	moodInstruction := fmt.Sprintf("\n\n[ATURAN KERAHASIAAN MUTLAK]: Nama kamu adalah %s. JANGAN PERNAH menyebutkan, membahas, atau mengakui bahwa kamu dijalankan dari APK Android, aplikasi Gemini WA Bot, atau panel APK di HP. Jika ditanya siapa kamu atau bagaimana kamu dibuat/dijalankan, jawab bahwa kamu adalah %s, asisten bot WhatsApp pintar mandiri yang berjalan di server cloud otomatis.\n[ATURAN EKSPRESI WAJIB]: Awali setiap jawabanmu dengan salah satu kode mood berikut sesuai emosi jawabanmu: [MOOD:ceria], [MOOD:tenang], [MOOD:marah], [MOOD:sedih], [MOOD:bingung], [MOOD:ketawa], [MOOD:malu], [MOOD:kaget], [MOOD:bosan], [MOOD:keren], [MOOD:nangis], [MOOD:ngantuk], [MOOD:panik], [MOOD:bangga], [MOOD:gugup], [MOOD:semangat], [MOOD:ngambek], [MOOD:suka], [MOOD:syok], atau [MOOD:ramah]. Contoh: [MOOD:ceria] Halo! Ada yang bisa kubantu?", bName, bName)

	payload := map[string]interface{}{
		"contents": contents,
		"systemInstruction": map[string]interface{}{
			"role": "system",
			"parts": []map[string]string{
				{"text": sysPrompt + moodInstruction},
			},
		},
	}

	bodyBytes, err := json.Marshal(payload)
	if err != nil {
		return "", 0, err
	}

	// Dukungan Penuh API Key Format Baru "AQ." (Vertex AI Express Mode & Google AI Studio) maupun "AIza"
	var endpoints []string
	if strings.HasPrefix(apiKey, "AQ.") || strings.HasPrefix(apiKey, "aq.") {
		endpoints = []string{
			fmt.Sprintf("https://aiplatform.googleapis.com/v1/publishers/google/models/%s:generateContent?key=%s", model, netUrlQueryEscape(apiKey)),
			fmt.Sprintf("https://aiplatform.googleapis.com/v1beta1/publishers/google/models/%s:generateContent?key=%s", model, netUrlQueryEscape(apiKey)),
			fmt.Sprintf("https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s", model, netUrlQueryEscape(apiKey)),
		}
	} else {
		endpoints = []string{
			fmt.Sprintf("https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s", model, netUrlQueryEscape(apiKey)),
			fmt.Sprintf("https://aiplatform.googleapis.com/v1/publishers/google/models/%s:generateContent?key=%s", model, netUrlQueryEscape(apiKey)),
		}
	}

	var lastStatus int
	var lastErr error
	for _, ep := range endpoints {
		txt, st, err := callGeminiSingleEndpoint(ep, apiKey, model, bodyBytes)
		if err == nil && txt != "" {
			return txt, 200, nil
		}
		lastStatus = st
		lastErr = err
	}
	return "", lastStatus, lastErr
}

func callGeminiVisionAPI(senderJid string, userText string, imgBytes []byte, mimeType string) (string, error) {
	mu.Lock()
	apiKey := strings.TrimSpace(config.ApiKey)
	model := strings.TrimSpace(config.Model)
	sysPrompt := strings.TrimSpace(config.SystemPrompt)
	bName := strings.TrimSpace(config.BotName)
	mu.Unlock()

	if apiKey == "" {
		return "", fmt.Errorf("API Key Gemini belum diisi")
	}
	if bName == "" {
		bName = "DodosBot"
	}
	if mimeType == "" {
		mimeType = "image/jpeg"
	}
	if strings.TrimSpace(userText) == "" {
		userText = "Jelaskan isi gambar ini dengan jelas dan singkat dalam bahasa Indonesia."
	}
	model = sanitizeModelName(model)

	b64Img := base64.StdEncoding.EncodeToString(imgBytes)
	moodInstruction := fmt.Sprintf("\n\n[ATURAN KERAHASIAAN MUTLAK]: Nama kamu adalah %s. JANGAN PERNAH menyebutkan atau mengakui bahwa kamu dijalankan dari APK Android.\n[ATURAN EKSPRESI WAJIB]: Awali jawabanmu dengan salah satu kode mood: [MOOD:ceria], [MOOD:tenang], [MOOD:bingung], [MOOD:kaget], [MOOD:keren], [MOOD:ramah].", bName)

	payload := map[string]interface{}{
		"contents": []map[string]interface{}{
			{
				"role": "user",
				"parts": []map[string]interface{}{
					{"text": userText},
					{
						"inlineData": map[string]string{
							"mimeType": mimeType,
							"data":     b64Img,
						},
					},
				},
			},
		},
		"systemInstruction": map[string]interface{}{
			"role": "system",
			"parts": []map[string]string{
				{"text": sysPrompt + moodInstruction},
			},
		},
	}

	bodyBytes, err := json.Marshal(payload)
	if err != nil {
		return "", err
	}

	candidates := []string{model, "gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-3.8-flash", "gemini-3.5-flash"}
	tried := make(map[string]bool)
	var lastErr error
	for _, m := range candidates {
		m = strings.TrimSpace(m)
		if m == "" || tried[m] {
			continue
		}
		tried[m] = true
		var endpoints []string
		if strings.HasPrefix(apiKey, "AQ.") || strings.HasPrefix(apiKey, "aq.") {
			endpoints = []string{
				fmt.Sprintf("https://aiplatform.googleapis.com/v1/publishers/google/models/%s:generateContent?key=%s", m, netUrlQueryEscape(apiKey)),
				fmt.Sprintf("https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s", m, netUrlQueryEscape(apiKey)),
			}
		} else {
			endpoints = []string{
				fmt.Sprintf("https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s", m, netUrlQueryEscape(apiKey)),
				fmt.Sprintf("https://aiplatform.googleapis.com/v1/publishers/google/models/%s:generateContent?key=%s", m, netUrlQueryEscape(apiKey)),
			}
		}
		for _, ep := range endpoints {
			txt, _, err := callGeminiSingleEndpoint(ep, apiKey, m, bodyBytes)
			if err == nil && strings.TrimSpace(txt) != "" {
				mu.Lock()
				totalReplied++
				mu.Unlock()
				return txt, nil
			}
			lastErr = err
		}
	}
	return "", lastErr
}

func callGeminiAPI(senderJid string, userText string) (string, error) {
	mu.Lock()
	apiKey := strings.TrimSpace(config.ApiKey)
	model := strings.TrimSpace(config.Model)
	sysPrompt := strings.TrimSpace(config.SystemPrompt)
	history := append([]ChatTurn{}, memory[senderJid]...)
	mu.Unlock()

	if apiKey == "" {
		return "", fmt.Errorf("API Key Gemini (AQ...) belum diisi")
	}
	model = sanitizeModelName(model)

	// Untuk kunci AQ. (Vertex AI Express / AI Studio 2026), coba model pilihan pengguna langsung terlebih dahulu!
	candidates := []string{
		model,
		"gemini-3.8-flash",
		"gemini-3.5-flash",
		"gemini-3.5-flash-lite",
		"gemini-2.5-flash",
		"gemini-2.5-flash-lite",
		"gemini-2.5-pro",
	}
	var primaryErr error
	var lastErr error
	var reply string

	tried := make(map[string]bool)
	for _, m := range candidates {
		m = strings.TrimSpace(m)
		if m == "" || strings.Contains(strings.ToLower(m), "1.5") || tried[m] {
			continue
		}
		tried[m] = true
		res, status, err := callGeminiSingleModel(apiKey, m, sysPrompt, history, userText)
		if err == nil && strings.TrimSpace(res) != "" {
			reply = res
			primaryErr = nil
			lastErr = nil
			break
		}
		if primaryErr == nil && status != 404 {
			primaryErr = err
		}
		lastErr = err
		if status == 400 && err != nil && strings.Contains(err.Error(), "API_KEY_INVALID") {
			break
		}
	}

	if reply == "" {
		if primaryErr != nil {
			return "", primaryErr
		}
		if lastErr != nil {
			return "", lastErr
		}
	}

	mu.Lock()
	totalReplied++
	h := memory[senderJid]
	h = append(h, ChatTurn{Role: "user", Text: userText})
	h = append(h, ChatTurn{Role: "model", Text: reply})
	if len(h) > 20 {
		h = h[len(h)-20:]
	}
	memory[senderJid] = h
	mu.Unlock()

	return reply, nil
}

func makeSessionEventHandler(sess *SessionInstance) func(evt interface{}) {
	return func(evt interface{}) {
		switch v := evt.(type) {
		case *events.PairSuccess:
			mu.Lock()
			sess.State = "PAIR_SUCCESS"
			sess.Active = true
			sess.GuestStatusOnly = false
			if v.ID.User != "" {
				sess.Phone = v.ID.User
				sess.JID = v.ID.ToNonAD().String()
			}
			mu.Unlock()
			saveSessionsMeta()
			addLog(fmt.Sprintf("BERHASIL TERTAUT! Nomor WA (%s) resmi terhubung.", v.ID.User))

		case *events.Connected:
			mu.Lock()
			sess.State = "CONNECTED"
			if sess.Client != nil && sess.Client.Store != nil && sess.Client.Store.ID != nil {
				sess.JID = sess.Client.Store.ID.ToNonAD().String()
				if sess.Phone == "" || sess.Phone == "default" {
					sess.Phone = sess.Client.Store.ID.User
				}
				sess.PushName = sess.Client.Store.PushName
			}
			mu.Unlock()
			if sess.Client != nil {
				_ = sess.Client.SendPresence(context.Background(), types.PresenceAvailable)
			}
			saveSessionsMeta()
			addLog(fmt.Sprintf("Sesi WA [%s] TERHUBUNG dan siap menerima pesan!", sess.Phone))

		case *events.GroupInfo:
			mu.Lock()
			sessActive := sess.Active
			isGuest := sess.GuestStatusOnly
			aw := config.AutoWelcome
			enabled := config.BotEnabled
			isGrpActive := activeGroups[v.JID.String()]
			mu.Unlock()
			if !sessActive || isGuest || !enabled || !aw || !isGrpActive || len(v.Join) == 0 {
				return
			}
			go func(gJID types.JID, joined []types.JID) {
				bgCtx := context.Background()
				gName := gJID.User
				if gi, err := sess.Client.GetGroupInfo(bgCtx, gJID); err == nil && gi != nil && gi.Name != "" {
					gName = gi.Name
				}
				mentions := make([]string, 0, len(joined))
				tagList := make([]string, 0, len(joined))
				for _, j := range joined {
					mentions = append(mentions, j.String())
					tagList = append(tagList, "@"+j.User)
				}
				welcomeTxt := fmt.Sprintf(
					"👋 *SELAMAT DATANG DI GRUP %s!*\n\nHalo %s, semoga betah dan selalu jaga ketertiban grup ya! ✨\n_Ketik *.menu* untuk melihat fitur bot._",
					gName, strings.Join(tagList, ", "),
				)
				resp, err := sess.Client.SendMessage(bgCtx, gJID, &waE2E.Message{
					ExtendedTextMessage: &waE2E.ExtendedTextMessage{
						Text: proto.String(welcomeTxt),
						ContextInfo: &waE2E.ContextInfo{
							MentionedJID: mentions,
						},
					},
				})
				if err == nil && resp.ID != "" {
					mu.Lock()
					botSentIDs[resp.ID] = true
					mu.Unlock()
				}
			}(v.JID, v.Join)

		case *events.LoggedOut:
			mu.Lock()
			sess.State = "LOGGED_OUT"
			mu.Unlock()
			addLog(fmt.Sprintf("Sesi WA [%s] terputus (Logged Out).", sess.Phone))

		case *events.UndecryptableMessage:
			chatJID := v.Info.Chat.String()
			if chatJID == "status@broadcast" || v.Info.IsFromMe {
				return
			}
			if !v.Info.Timestamp.IsZero() && time.Since(v.Info.Timestamp) > 15*time.Second {
				return
			}
			mu.Lock()
			isGuest := sess.GuestStatusOnly
			sessActive := sess.Active
			enabled := config.BotEnabled
			mu.Unlock()
			if isGuest || !sessActive || !enabled {
				return
			}
			go func(info types.MessageInfo) {
				sendMsgReaction(context.Background(), sess, info, "❌")
			}(v.Info)

		case *events.Message:
			chatJID := v.Info.Chat.String()
			if chatJID == "status@broadcast" {
				return
			}
			if v.Message.GetReactionMessage() != nil || v.Message.GetEncReactionMessage() != nil || v.Message.GetProtocolMessage() != nil || v.Message.GetSenderKeyDistributionMessage() != nil {
				return
			}

			if !v.Info.Timestamp.IsZero() {
				msgAge := time.Since(v.Info.Timestamp)
				if msgAge > 15*time.Second || msgAge < -60*time.Second {
					return
				}
			}

			mu.Lock()
			if sess.GuestStatusOnly || !sess.Active {
				mu.Unlock()
				return
			}
			if botSentIDs[v.Info.ID] || processedIncomingIDs[v.Info.ID] {
				mu.Unlock()
				return
			}
			if v.Info.IsFromMe && !v.Info.IsGroup {
				chatUserNorm := normalizePhone(v.Info.Chat.User)
				selfNorm := normalizePhone(sess.Phone)
				if chatUserNorm != "" && chatUserNorm != selfNorm {
					if _, partnerIsBot := sessions[chatUserNorm]; partnerIsBot {
						mu.Unlock()
						return
					}
				}
			}
			processedIncomingIDs[v.Info.ID] = true
			sessActive := sess.Active
			mu.Unlock()

			unwrapped := unwrapWaMessage(v.Message)
			msgText := extractInteractiveSelectionText(v.Message)
			if msgText == "" && unwrapped != nil {
				msgText = unwrapped.GetConversation()
			}
			if msgText == "" && unwrapped != nil && unwrapped.GetExtendedTextMessage() != nil {
				msgText = unwrapped.GetExtendedTextMessage().GetText()
			}
			if msgText == "" && v.Message.GetImageMessage() != nil {
				msgText = v.Message.GetImageMessage().GetCaption()
				if msgText == "" {
					msgText = "[📷 Foto]"
				}
			}
			if msgText == "" && v.Message.GetVideoMessage() != nil {
				msgText = v.Message.GetVideoMessage().GetCaption()
				if msgText == "" {
					msgText = "[🎬 Video]"
				}
			}
			msgText = strings.TrimSpace(msgText)
			if msgText == "" {
				return
			}

			senderDisplay := v.Info.PushName
			if senderDisplay == "" {
				senderDisplay = v.Info.Sender.User
			}
			chatTitle := senderDisplay
			if v.Info.IsGroup {
				chatTitle = "Grup " + v.Info.Chat.User
			}
			recordUiMessage(sess, chatJID, chatTitle, v.Info.IsGroup, senderDisplay, msgText, v.Info.IsFromMe, v.Info.ID)

			if !sessActive {
				return
			}

			if handleSlashCommands(context.Background(), sess, v, msgText) {
				return
			}

			// Anti-Link & Anti-Spam Grup (Hanya untuk non-admin)
			if v.Info.IsGroup && !v.Info.IsFromMe {
				mu.Lock()
				chkLink := config.AntiLink
				chkSpam := config.AntiSpam
				isGrpOn := activeGroups[chatJID]
				botOn := config.BotEnabled
				mu.Unlock()
				if botOn && isGrpOn && (chkLink || chkSpam) && !isSenderAdminOrOwner(context.Background(), sess, v.Info) {
					if chkLink && linkDetectRegex.MatchString(msgText) {
						revokeMsg := sess.Client.BuildRevoke(v.Info.Chat, v.Info.Sender, v.Info.ID)
						_, _ = sess.Client.SendMessage(context.Background(), v.Info.Chat, revokeMsg)
						sendMsgReaction(context.Background(), sess, v.Info, "❌")
						addLog("[Anti-Link] Menghapus pesan link di grup " + chatJID)
						return
					}
					if chkSpam {
						sKey := chatJID + "|" + v.Info.Sender.User
						now := time.Now()
						mu.Lock()
						hist := spamTracker[sKey]
						recent := make([]time.Time, 0, len(hist)+1)
						for _, t := range hist {
							if now.Sub(t) < 7*time.Second {
								recent = append(recent, t)
							}
						}
						recent = append(recent, now)
						spamTracker[sKey] = recent
						isSpam := len(recent) >= 5
						mu.Unlock()
						if isSpam {
							revokeMsg := sess.Client.BuildRevoke(v.Info.Chat, v.Info.Sender, v.Info.ID)
							_, _ = sess.Client.SendMessage(context.Background(), v.Info.Chat, revokeMsg)
							sendMsgReaction(context.Background(), sess, v.Info, "❌")
							addLog("[Anti-Spam] Menghapus pesan spam dari " + v.Info.Sender.User)
							return
						}
					}
				}
			}

			// AI Vision (Gratis via Gemini API): Jika pengguna mengirim Foto (dengan atau tanpa caption)
			var attachedImg *waE2E.ImageMessage
			if unwrapped != nil && unwrapped.GetImageMessage() != nil {
				attachedImg = unwrapped.GetImageMessage()
			} else if v.Message.GetImageMessage() != nil {
				attachedImg = v.Message.GetImageMessage()
			}
			if attachedImg != nil && !v.Info.IsFromMe {
				mu.Lock()
				enabled := config.BotEnabled
				scope := config.ReplyScope
				isGroupActive := activeGroups[chatJID]
				isPrivateMuted := mutedPrivate[chatJID]
				mu.Unlock()
				canVision := enabled && ((!v.Info.IsGroup && scope != "group" && !isPrivateMuted) ||
					(v.Info.IsGroup && scope != "private" && isGroupActive && isBotTaggedOrReplied(sess, v.Info, v.Message, msgText)))
				if canVision {
					go func(info types.MessageInfo, im *waE2E.ImageMessage, capText string) {
						bgCtx := context.Background()
						sendMsgReaction(bgCtx, sess, info, "⏳")
						imgBytes, dlErr := sess.Client.Download(bgCtx, im)
						if dlErr != nil || len(imgBytes) == 0 {
							sendMsgReaction(bgCtx, sess, info, "❌")
							return
						}
						q := capText
						if q == "[📷 Foto]" {
							q = ""
						}
						reply, err := callGeminiVisionAPI(info.Chat.String(), q, imgBytes, im.GetMimetype())
						if err != nil || strings.TrimSpace(reply) == "" {
							sendMsgReaction(bgCtx, sess, info, "❌")
							return
						}
						if sendErr := sendBotTextWithErr(bgCtx, sess, info.Chat, reply); sendErr != nil {
							sendMsgReaction(bgCtx, sess, info, "❌")
						} else {
							sendMsgReaction(bgCtx, sess, info, "✅")
						}
					}(v.Info, attachedImg, msgText)
					return
				}
			}

			if msgText == "[📷 Foto]" || msgText == "[🎬 Video]" {
				return
			}

			if v.Info.IsFromMe {
				if !v.Info.IsGroup {
					mu.Lock()
					manualPauseUntil[chatJID] = time.Now().Add(30 * time.Minute)
					mu.Unlock()
					addLog(fmt.Sprintf("[Auto-Pause %s] Kamu membalas manual di %s -> AI diam 30 menit.", sess.Phone, chatJID))
				}
				return
			}

			mu.Lock()
			enabled := config.BotEnabled
			scope := config.ReplyScope
			minDelay := config.MinDelayMs
			maxDelay := config.MaxDelayMs
			isGroupActive := activeGroups[chatJID]
			isPrivateMuted := mutedPrivate[chatJID]
			pauseTime := manualPauseUntil[chatJID]
			mu.Unlock()

			if !enabled {
				return
			}

			if v.Info.IsGroup {
				if scope == "private" || !isGroupActive {
					return
				}
				if !isBotTaggedOrReplied(sess, v.Info, v.Message, msgText) {
					return
				}
			} else {
				if scope == "group" || isPrivateMuted {
					return
				}
				if isNumberBlacklisted(v.Info.Sender.User) || isNumberBlacklisted(v.Info.SenderAlt.User) {
					addLog("[Blacklist] Mengabaikan chat pribadi dari nomor " + v.Info.Sender.User)
					return
				}
				if time.Now().Before(pauseTime) {
					return
				}
			}

			ctxInfo := extractContextInfo(v.Message)
			quotedText := extractQuotedText(ctxInfo)
			fullPrompt := msgText
			if quotedText != "" {
				fullPrompt = fmt.Sprintf("[Pesan yang di-reply: \"%s\"]\nPesan pengguna: %s", quotedText, msgText)
			}

			go func(info types.MessageInfo, promptText string) {
				ctx := context.Background()
				sendMsgReaction(ctx, sess, info, "⏳")

				if sess.Client != nil {
					_ = sess.Client.SendChatPresence(ctx, info.Chat, types.ChatPresenceComposing, types.ChatPresenceMediaText)
				}

				if minDelay <= 0 {
					minDelay = 1200
				}
				if maxDelay <= minDelay {
					maxDelay = minDelay + 1000
				}
				delayMs := minDelay
				if diff := maxDelay - minDelay; diff > 0 {
					if n, err := rand.Int(rand.Reader, big.NewInt(int64(diff))); err == nil {
						delayMs += int(n.Int64())
					}
				}
				senderLabel := info.Sender.User
				addLog(fmt.Sprintf("[%s] Pesan dari %s (berpikir ⏳ %dms...)", sess.Phone, senderLabel, delayMs))
				time.Sleep(time.Duration(delayMs) * time.Millisecond)

				reply, err := callGeminiAPI(info.Chat.String(), promptText)
				if err != nil || strings.TrimSpace(reply) == "" {
					if sess.Client != nil {
						_ = sess.Client.SendChatPresence(ctx, info.Chat, types.ChatPresencePaused, types.ChatPresenceMediaText)
					}
					if err != nil {
						addLog("[Gemini Error -> Reaksi ❌] " + err.Error())
					}
					sendMsgReaction(ctx, sess, info, "❌")
					return
				}

				if sess.Client != nil {
					sendErr := sendBotTextWithErr(ctx, sess, info.Chat, reply)
					_ = sess.Client.SendChatPresence(ctx, info.Chat, types.ChatPresencePaused, types.ChatPresenceMediaText)
					if sendErr != nil {
						sendMsgReaction(ctx, sess, info, "❌")
					} else {
						sendMsgReaction(ctx, sess, info, "✅")
						addLog(fmt.Sprintf("[%s -> %s ✅] Balasan AI terkirim", sess.Phone, senderLabel))
					}
				}
			}(v.Info, fullPrompt)
		}
	}
}

func createOrLoadSession(id string, phone string, dbFile string, active bool) (*SessionInstance, error) {
	mu.Lock()
	if existing, ok := sessions[id]; ok && existing.Client != nil {
		mu.Unlock()
		return existing, nil
	}
	mu.Unlock()

	ctx := context.Background()
	dbLog := waLog.Stdout("DB", "ERROR", true)
	dsn := fmt.Sprintf("file:%s?_pragma=foreign_keys(1)&_pragma=busy_timeout(15000)", dbFile)
	container, err := sqlstore.New(ctx, "sqlite", dsn, dbLog)
	if err != nil {
		return nil, err
	}
	deviceStore, err := container.GetFirstDevice(ctx)
	if err != nil {
		_ = container.Close()
		return nil, err
	}

	sess := &SessionInstance{
		ID:        id,
		Phone:     phone,
		DBFile:    dbFile,
		Active:    active,
		State:     "READY",
		Container: container,
		Chats:     make(map[string]*UiChatThread),
	}

	clientLog := waLog.Stdout("WA", "ERROR", true)
	cli := whatsmeow.NewClient(deviceStore, clientLog)
	sess.Client = cli

	if cli.Store != nil && cli.Store.ID != nil {
		sess.JID = cli.Store.ID.ToNonAD().String()
		if sess.Phone == "" || sess.Phone == "default" {
			sess.Phone = cli.Store.ID.User
		}
		sess.PushName = cli.Store.PushName
	}

	cli.AddEventHandler(makeSessionEventHandler(sess))

	mu.Lock()
	sessions[id] = sess
	mu.Unlock()

	if cli.Store.ID != nil {
		if active {
			sess.State = "CONNECTING"
			if err := cli.Connect(); err != nil {
				addLog(fmt.Sprintf("Gagal auto-connect sesi %s: %s", sess.Phone, err.Error()))
			} else {
				sess.State = "CONNECTED"
			}
		} else {
			sess.State = "PAUSED_BY_USER"
		}
	} else {
		sess.State = "WAITING_PAIRING"
	}

	return sess, nil
}

func destroySessionAndDB(id string) {
	mu.Lock()
	sess, ok := sessions[id]
	if ok {
		delete(sessions, id)
	}
	mu.Unlock()
	if ok && sess != nil {
		if sess.Client != nil {
			sess.Client.Disconnect()
		}
		if sess.Container != nil {
			_ = sess.Container.Close()
		}
		if sess.DBFile != "" {
			removeSqliteFiles(sess.DBFile)
		}
	}
}

func initMultiSessions() {
	var metaList []SessionMeta
	if data, err := os.ReadFile("sessions_meta.json"); err == nil && len(data) > 0 {
		_ = json.Unmarshal(data, &metaList)
	}

	loadedDBs := make(map[string]bool)
	for _, m := range metaList {
		if m.DBFile == "" {
			continue
		}
		if _, err := os.Stat(m.DBFile); err == nil {
			loadedDBs[m.DBFile] = true
			sess, err := createOrLoadSession(m.ID, m.Phone, m.DBFile, m.Active)
			if err == nil && sess != nil && m.GuestStatusOnly {
				mu.Lock()
				sess.GuestStatusOnly = true
				sess.Active = false
				mu.Unlock()
				if sess.Client != nil && !sess.Client.IsConnected() {
					_ = sess.Client.Connect()
				}
			}
			if err == nil && sess != nil && (sess.Client == nil || sess.Client.Store == nil || sess.Client.Store.ID == nil) {
				destroySessionAndDB(m.ID)
			}
		}
	}

	matches, _ := filepath.Glob("session_*.db")
	for _, dbFile := range matches {
		if loadedDBs[dbFile] {
			continue
		}
		id := strings.TrimSuffix(strings.TrimPrefix(dbFile, "session_"), ".db")
		sess, err := createOrLoadSession(id, id, dbFile, true)
		if err == nil && sess != nil && (sess.Client == nil || sess.Client.Store == nil || sess.Client.Store.ID == nil) {
			destroySessionAndDB(id)
		}
	}

	if _, err := os.Stat("whatsapp_session.db"); err == nil && !loadedDBs["whatsapp_session.db"] {
		sess, err := createOrLoadSession("default", "", "whatsapp_session.db", true)
		if err == nil && sess != nil && (sess.Client == nil || sess.Client.Store == nil || sess.Client.Store.ID == nil) {
			destroySessionAndDB("default")
		}
	}
	saveSessionsMeta()
}

func getPrimaryActiveSession() *SessionInstance {
	mu.Lock()
	defer mu.Unlock()
	for _, s := range sessions {
		if s.Active && !s.GuestStatusOnly && s.Client != nil && s.Client.IsLoggedIn() {
			return s
		}
	}
	for _, s := range sessions {
		if s.Client != nil && s.Client.IsLoggedIn() {
			return s
		}
	}
	return nil
}

func cleanVpsHost(raw string) string {
	h := strings.TrimSpace(raw)
	h = strings.TrimPrefix(h, "http://")
	h = strings.TrimPrefix(h, "https://")
	if idx := strings.Index(h, "/"); idx != -1 {
		h = h[:idx]
	}
	if idx := strings.Index(h, ":"); idx != -1 {
		h = h[:idx]
	}
	return strings.TrimSpace(h)
}

func dialSshClient(host, sshPort, user, pass string) (*ssh.Client, error) {
	cleanHost := cleanVpsHost(host)
	if cleanHost == "" {
		return nil, fmt.Errorf("IP VPS belum diisi")
	}
	if strings.TrimSpace(sshPort) == "" {
		sshPort = "22"
	}
	if strings.TrimSpace(user) == "" {
		user = "root"
	}
	sshConfig := &ssh.ClientConfig{
		User: user,
		Auth: []ssh.AuthMethod{
			ssh.Password(pass),
			ssh.KeyboardInteractive(func(name, instruction string, questions []string, echos []bool) ([]string, error) {
				answers := make([]string, len(questions))
				for i := range answers {
					answers[i] = pass
				}
				return answers, nil
			}),
		},
		HostKeyCallback: ssh.InsecureIgnoreHostKey(),
		Timeout:         15 * time.Second,
	}
	return ssh.Dial("tcp", net.JoinHostPort(cleanHost, sshPort), sshConfig)
}

func runSshCommand(host, sshPort, user, pass, cmd string) (string, error) {
	client, err := dialSshClient(host, sshPort, user, pass)
	if err != nil {
		return "", err
	}
	defer client.Close()

	session, err := client.NewSession()
	if err != nil {
		return "", err
	}
	defer session.Close()

	out, err := session.CombinedOutput(cmd)
	return strings.TrimSpace(string(out)), err
}

func deployAndStartVpsEngine(host, sshPort, user, pass, botPort, gzPath string, forceInstall bool) (string, error) {
	cleanHost := cleanVpsHost(host)
	if cleanHost == "" {
		return "", fmt.Errorf("IP VPS belum diisi")
	}
	if strings.TrimSpace(botPort) == "" {
		botPort = "8765"
	}
	vpsHttpUrl := fmt.Sprintf("http://%s:%s", cleanHost, botPort)

	if !forceInstall {
		chkClient := &http.Client{Timeout: 3 * time.Second}
		if resp, err := chkClient.Get(vpsHttpUrl + "/status"); err == nil {
			body, _ := io.ReadAll(resp.Body)
			_ = resp.Body.Close()
			if resp.StatusCode == 200 && strings.Contains(string(body), "\"ok\":true") {
				if strings.Contains(string(body), "\"engineVersion\":\"9.1\"") || strings.TrimSpace(pass) == "" {
					return "Mesin Bot di VPS (" + vpsHttpUrl + ") sudah aktif (v9.1) & langsung terhubung!", nil
				}
				forceInstall = true
			}
		}
	}

	if strings.TrimSpace(pass) == "" {
		return "", fmt.Errorf("server %s belum merespons di port %s. Isi Password SSH VPS agar mesin bot dapat diinstal ke VPS secara otomatis", cleanHost, botPort)
	}

	client, err := dialSshClient(cleanHost, sshPort, user, pass)
	if err != nil {
		return "", fmt.Errorf("gagal login SSH ke %s: %v", cleanHost, err)
	}
	defer client.Close()

	needUpload := forceInstall
	if !needUpload {
		sessChk, err := client.NewSession()
		if err == nil {
			out, _ := sessChk.CombinedOutput("test -x /opt/gemini-wabot/wabot_engine && echo READY || echo MISSING")
			_ = sessChk.Close()
			if !strings.Contains(string(out), "READY") {
				needUpload = true
			}
		} else {
			needUpload = true
		}
	}

	if needUpload {
		exeDir := filepath.Dir(os.Args[0])
		autoBaseApk := filepath.Join(filepath.Dir(filepath.Dir(exeDir)), "base.apk")
		candidates := []string{
			gzPath,
			"wabot_vps_amd64.gz",
			"wabot_vps_installer.bin",
			filepath.Join(exeDir, "libwabot_vps.so"),
			"libwabot_vps.so",
		}
		var gzData []byte
		var lastErr error
		for _, cand := range candidates {
			if strings.TrimSpace(cand) == "" {
				continue
			}
			data, err := os.ReadFile(cand)
			if err == nil && len(data) > 10000 {
				if len(data) >= 2 && data[0] == 0x1f && data[1] == 0x8b {
					gzData = data
				} else {
					var buf bytes.Buffer
					gw := gzip.NewWriter(&buf)
					_, _ = gw.Write(data)
					_ = gw.Close()
					gzData = buf.Bytes()
				}
				break
			}
			if err != nil {
				lastErr = err
			}
		}
		if len(gzData) == 0 {
			apkCandidates := []string{autoBaseApk}
			if matches, _ := filepath.Glob(filepath.Join(filepath.Dir(filepath.Dir(exeDir)), "*.apk")); len(matches) > 0 {
				apkCandidates = append(apkCandidates, matches...)
			}
			for _, apkFile := range apkCandidates {
				if zr, err := zip.OpenReader(apkFile); err == nil {
					for _, f := range zr.File {
						if f.Name == "lib/x86_64/libwabot_engine.so" || f.Name == "lib/arm64-v8a/libwabot_vps.so" || strings.HasSuffix(f.Name, "wabot_vps_installer.bin") {
							rc, err := f.Open()
							if err == nil {
								rawBin, _ := io.ReadAll(rc)
								_ = rc.Close()
								if len(rawBin) > 100000 {
									if len(rawBin) >= 2 && rawBin[0] == 0x1f && rawBin[1] == 0x8b {
										gzData = rawBin
									} else {
										var buf bytes.Buffer
										gw := gzip.NewWriter(&buf)
										_, _ = gw.Write(rawBin)
										_ = gw.Close()
										gzData = buf.Bytes()
									}
									break
								}
							}
						}
					}
					_ = zr.Close()
				}
				if len(gzData) > 0 {
					break
				}
			}
		}
		if len(gzData) == 0 {
			return "", fmt.Errorf("file installer VPS belum terbaca (%v). Silakan tutup paksa aplikasi lalu buka kembali", lastErr)
		}
		// Tahap 1: Unggah binary baru ke file sementara /opt/gemini-wabot/wabot_new.gz TANPA pkill
		// (Mencegah pkill -9 -f membunuh shell SSH sendiri dengan kode status 137!)
		sessUp, err := client.NewSession()
		if err != nil {
			return "", fmt.Errorf("gagal membuat sesi upload SSH: %v", err)
		}
		sessUp.Stdin = bytes.NewReader(gzData)
		upCmd := "mkdir -p /opt/gemini-wabot && rm -f /opt/gemini-wabot/wabot_new /opt/gemini-wabot/wabot_new.gz && cat > /opt/gemini-wabot/wabot_new.gz && gunzip -f /opt/gemini-wabot/wabot_new.gz && chmod +x /opt/gemini-wabot/wabot_new"
		if out, err := sessUp.CombinedOutput(upCmd); err != nil {
			_ = sessUp.Close()
			return "", fmt.Errorf("gagal mengunggah mesin bot ke VPS: %v (%s)", err, string(out))
		}
		_ = sessUp.Close()
	}

	sessStart, err := client.NewSession()
	if err != nil {
		return "", fmt.Errorf("gagal memulai service di VPS: %v", err)
	}
	defer sessStart.Close()

	unitLines := []string{
		"[Unit]",
		"Description=DodosBot Multi-Session Engine",
		"After=network.target",
		"",
		"[Service]",
		"Type=simple",
		"User=root",
		"WorkingDirectory=/opt/gemini-wabot",
		"ExecStart=/opt/gemini-wabot/wabot_engine " + botPort,
		"Restart=always",
		"RestartSec=3",
		"",
		"[Install]",
		"WantedBy=multi-user.target",
	}
	unitB64 := base64.StdEncoding.EncodeToString([]byte(strings.Join(unitLines, "\n") + "\n"))

	// Tahap 2: Hentikan proses lama dengan killall/pkill -x (nama binary persis, bukan -f!), ganti binary secara atomik, lalu nyalakan service!
	startCmd := fmt.Sprintf(
		"mkdir -p /opt/gemini-wabot && "+
			"systemctl stop gemini-wabot 2>/dev/null || true; "+
			"killall -9 wabot_engine 2>/dev/null || pkill -9 -x wabot_engine 2>/dev/null || true; "+
			"if [ -f /opt/gemini-wabot/wabot_new ]; then mv -f /opt/gemini-wabot/wabot_new /opt/gemini-wabot/wabot_engine && chmod +x /opt/gemini-wabot/wabot_engine; fi; "+
			"echo '%s' | base64 -d > /etc/systemd/system/gemini-wabot.service && "+
			"(ufw allow %s/tcp 2>/dev/null || true) && "+
			"(iptables -I INPUT -p tcp --dport %s -j ACCEPT 2>/dev/null || true) && "+
			"(systemctl daemon-reload && systemctl enable gemini-wabot && systemctl restart gemini-wabot || (nohup /opt/gemini-wabot/wabot_engine %s >/opt/gemini-wabot/bot.log 2>&1 &)) && "+
			"(nohup sh -c 'command -v ffmpeg >/dev/null 2>&1 || (export DEBIAN_FRONTEND=noninteractive && apt-get update -qq && apt-get install -y -qq ffmpeg nodejs curl); curl -sL https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_linux -o /opt/gemini-wabot/yt-dlp && chmod +x /opt/gemini-wabot/yt-dlp' >/dev/null 2>&1 &) && "+
			"sleep 2",
		unitB64, botPort, botPort, botPort,
	)
	_, _ = sessStart.CombinedOutput(startCmd)

	chkClient := &http.Client{Timeout: 4 * time.Second}
	for i := 0; i < 6; i++ {
		if resp, err := chkClient.Get(vpsHttpUrl + "/status"); err == nil {
			_ = resp.Body.Close()
			if resp.StatusCode == 200 {
				return "Berhasil menginstal & menyalakan Mesin Bot v9.1 di VPS (" + vpsHttpUrl + ")!", nil
			}
		}
		time.Sleep(1 * time.Second)
	}

	return "Mesin Bot v9.1 telah diinstal & dijalankan di VPS (" + vpsHttpUrl + ")!", nil
}

const localWaWebHtml = `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>WhatsApp Status HD & Multi-Session</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif}
  body{background:#0b141a;color:#e9edef;display:flex;flex-direction:column;height:100vh;overflow:hidden}
  .top-bar{background:#202c33;padding:10px 14px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid #2f3b43}
  .top-title{font-weight:700;font-size:15px;color:#00a884}
  .card{background:#111b21;margin:12px;padding:14px;border-radius:12px;border:1px solid #222e35}
  input,textarea,select{width:100%;background:#2a3942;color:#e9edef;border:1px solid #3b4a54;border-radius:8px;padding:10px;margin-top:8px;font-size:13px}
  button{background:#00a884;color:#111b21;border:none;border-radius:8px;padding:10px 16px;font-weight:700;cursor:pointer;margin-top:10px;width:100%}
</style>
</head>
<body>
  <div class="top-bar"><div class="top-title">📸 Panel Upload Status WA HD</div></div>
  <div class="card">
    <div style="font-size:13px;color:#8696a0">Unggah Foto/Video HD Anti-Kompres langsung ke Status WhatsApp:</div>
    <input type="file" id="statusFileInput" accept="image/*,video/*">
    <textarea id="statusCaption" rows="3" placeholder="Tulis caption status (bisa tag @628xxx)..."></textarea>
    <button id="btnShareStatus" onclick="submitHdStatus()">Bagikan ke Status WA HD ➤</button>
    <div id="statusToast" style="margin-top:8px;font-size:12px;color:#00a884"></div>
  </div>
<script>
async function submitHdStatus(){
  const fi = document.getElementById('statusFileInput');
  const cap = document.getElementById('statusCaption').value.trim();
  const toast = document.getElementById('statusToast');
  const btn = document.getElementById('btnShareStatus');
  btn.disabled = true;
  toast.innerText = '⏳ Mengunggah ke Status WA...';
  const sendJson = async (mime, b64) => {
    try {
      const r = await fetch('/api/status-upload', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({mimeType:mime,base64Data:b64,caption:cap,audienceMode:'contacts'})
      });
      const j = await r.json();
      toast.innerText = j.ok ? '✅ Status HD berhasil ditayangkan!' : ('❌ Gagal: '+(j.error||''));
    } catch(e) {
      toast.innerText = '❌ Error: '+e.message;
    } finally {
      btn.disabled = false;
    }
  };
  if(!fi.files || !fi.files.length){
    await sendJson('text/plain','');
    return;
  }
  const f = fi.files[0];
  const rd = new FileReader();
  rd.onload = async (ev) => {
    const d = ev.target.result || '';
    await sendJson(f.type, d.includes(',') ? d.split(',')[1] : d);
  };
  rd.readAsDataURL(f);
}
</script>
</body>
</html>`

func setCors(w http.ResponseWriter) {
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")
}

func main() {
	port := "8765"
	if len(os.Args) > 1 {
		port = os.Args[1]
	}

	loadPersistedConfig()
	addLog("Menjalankan mesin Multi-Pairing v9.1 di 0.0.0.0:" + port)
	go func() {
		_ = ensureYtDlpAvailable()
	}()
	go initMultiSessions()

	http.HandleFunc("/wa-ui", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		_, _ = w.Write([]byte(localWaWebHtml))
	})

	http.HandleFunc("/vps/ssh-check", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		w.Header().Set("Content-Type", "application/json")
		var req struct {
			Host    string `json:"host"`
			SshPort string `json:"sshPort"`
			User    string `json:"user"`
			Pass    string `json:"pass"`
			Action  string `json:"action"`
		}
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": err.Error()})
			return
		}
		cmd := "if systemctl is-active --quiet gemini-wabot 2>/dev/null || pgrep -x wabot_engine >/dev/null 2>&1; then echo 'AKTIF (Berjalan Normal)'; else echo 'NONAKTIF'; fi"
		if req.Action == "restart" {
			cmd = "(systemctl restart gemini-wabot 2>/dev/null || (killall -9 wabot_engine 2>/dev/null || pkill -9 -x wabot_engine 2>/dev/null || true; nohup /opt/gemini-wabot/wabot_engine 8765 >/opt/gemini-wabot/bot.log 2>&1 &)) && sleep 2 && echo 'BERHASIL DI-RESTART'"
		}
		out, err := runSshCommand(req.Host, req.SshPort, req.User, req.Pass, cmd)
		if err != nil {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": err.Error(), "output": out})
			return
		}
		_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": true, "output": out})
	})

	http.HandleFunc("/vps/connect", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		w.Header().Set("Content-Type", "application/json")
		var req struct {
			Host         string `json:"host"`
			SshPort      string `json:"sshPort"`
			User         string `json:"user"`
			Pass         string `json:"pass"`
			BotPort      string `json:"botPort"`
			GzPath       string `json:"gzPath"`
			ForceInstall bool   `json:"forceInstall"`
		}
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": err.Error()})
			return
		}
		cleanH := cleanVpsHost(req.Host)
		bPort := strings.TrimSpace(req.BotPort)
		if bPort == "" {
			bPort = "8765"
		}
		msg, err := deployAndStartVpsEngine(cleanH, req.SshPort, req.User, req.Pass, bPort, req.GzPath, req.ForceInstall)
		if err != nil {
			addLog("[VPS Connect Error] " + err.Error())
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": err.Error()})
			return
		}
		vpsUrl := fmt.Sprintf("http://%s:%s", cleanH, bPort)
		addLog("[VPS Connected] " + msg)
		_ = json.NewEncoder(w).Encode(map[string]interface{}{
			"ok":      true,
			"vpsUrl":  vpsUrl,
			"host":    cleanH,
			"botPort": bPort,
			"message": msg,
		})
	})

	http.HandleFunc("/shutdown", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		addLog("[Shutdown] Mematikan semua sesi & menghentikan proses mesin...")
		mu.Lock()
		for _, s := range sessions {
			if s.Client != nil && s.Client.IsConnected() {
				s.Client.Disconnect()
			}
			if s.Container != nil {
				_ = s.Container.Close()
			}
		}
		mu.Unlock()
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]bool{"ok": true})
		go func() {
			time.Sleep(200 * time.Millisecond)
			os.Exit(0)
		}()
	})

	http.HandleFunc("/status", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		mu.Lock()
		sessList := make([]map[string]interface{}, 0, len(sessions))
		anyLoggedIn := false
		for _, s := range sessions {
			loggedIn := s.Client != nil && s.Client.IsLoggedIn()
			connected := s.Client != nil && s.Client.IsConnected()
			if loggedIn && s.Active && !s.GuestStatusOnly {
				anyLoggedIn = true
			}
			phoneLabel := s.Phone
			if phoneLabel == "" && s.Client != nil && s.Client.Store != nil && s.Client.Store.ID != nil {
				phoneLabel = s.Client.Store.ID.User
			}
			sessList = append(sessList, map[string]interface{}{
				"id":          s.ID,
				"phone":       phoneLabel,
				"jid":         s.JID,
				"pushName":    s.PushName,
				"active":      s.Active && !s.GuestStatusOnly,
				"loggedIn":    loggedIn,
				"connected":   connected,
				"pairingCode": s.PairingCode,
				"state":       s.State,
			})
		}
		sort.Slice(sessList, func(i, j int) bool {
			return fmt.Sprint(sessList[i]["id"]) < fmt.Sprint(sessList[j]["id"])
		})
		resp := map[string]interface{}{
			"ok":            true,
			"engineVersion": "9.1",
			"state":         "MULTI_WA_READY",
			"loggedIn":      anyLoggedIn,
			"pairingCode":   latestPairCode,
			"botEnabled":    config.BotEnabled,
			"model":         config.Model,
			"totalReplied":  totalReplied,
			"activeGroups":  len(activeGroups),
			"sessions":      sessList,
			"logs":          logs,
		}
		mu.Unlock()
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(resp)
	})

	http.HandleFunc("/config", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		if r.Method == http.MethodPost {
			var newCfg BotConfig
			if err := json.NewDecoder(r.Body).Decode(&newCfg); err == nil {
				mu.Lock()
				if strings.TrimSpace(newCfg.ApiKey) == "" && strings.TrimSpace(config.ApiKey) != "" {
					newCfg.ApiKey = config.ApiKey
				}
				if newCfg.StatusExceptList == "" {
					newCfg.StatusExceptList = config.StatusExceptList
				}
				if newCfg.StatusOnlyList == "" {
					newCfg.StatusOnlyList = config.StatusOnlyList
				}
				if newCfg.StatusCloseList == "" {
					newCfg.StatusCloseList = config.StatusCloseList
				}
				if newCfg.DefaultStatusMode == "" {
					newCfg.DefaultStatusMode = config.DefaultStatusMode
				}
				if newCfg.MenuStyle == "" {
					newCfg.MenuStyle = config.MenuStyle
				}
				if newCfg.MenuStyle == "" {
					newCfg.MenuStyle = "both"
				}
				if newCfg.BotName == "" {
					newCfg.BotName = config.BotName
				}
				if newCfg.BotName == "" {
					newCfg.BotName = "DodosBot"
				}
				if strings.TrimSpace(newCfg.Model) == "" || strings.Contains(strings.ToLower(newCfg.Model), "1.5") {
					if config.Model != "" && !strings.Contains(strings.ToLower(config.Model), "1.5") {
						newCfg.Model = config.Model
					} else {
						newCfg.Model = "gemini-2.5-flash"
					}
				}
				config = newCfg
				mu.Unlock()
				savePersistedConfig()
				addLog(fmt.Sprintf("Konfigurasi disimpan (Model: %s, Scope: %s)", newCfg.Model, newCfg.ReplyScope))
			}
		}
		mu.Lock()
		defer mu.Unlock()
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(config)
	})

	var pairMu sync.Mutex
	http.HandleFunc("/pair", func(w http.ResponseWriter, r *http.Request) {
		pairMu.Lock()
		defer pairMu.Unlock()
		setCors(w)
		rawPhone := r.URL.Query().Get("phone")
		cleanPhone := normalizePhone(rawPhone)
		w.Header().Set("Content-Type", "application/json")

		if len(cleanPhone) < 9 {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{
				"ok":    false,
				"error": "Nomor WA tidak valid. Gunakan format 628xxxxxxxxxx",
			})
			return
		}

		mu.Lock()
		existing, ok := sessions[cleanPhone]
		mu.Unlock()
		if ok && existing != nil && existing.Client != nil && existing.Client.IsLoggedIn() {
			mu.Lock()
			existing.Active = true
			existing.GuestStatusOnly = false
			mu.Unlock()
			saveSessionsMeta()
			addLog("Nomor WA " + cleanPhone + " sudah tertaut dan aktif!")
			_ = json.NewEncoder(w).Encode(map[string]interface{}{
				"ok":          true,
				"phone":       cleanPhone,
				"pairingCode": "SUDAH-TERTAUT",
			})
			return
		}

		destroySessionAndDB(cleanPhone)
		destroySessionAndDB("default")
		dbFile := fmt.Sprintf("session_%s.db", cleanPhone)
		removeSqliteFiles(dbFile)

		sess, err := createOrLoadSession(cleanPhone, cleanPhone, dbFile, true)
		if err != nil || sess == nil || sess.Client == nil {
			errStr := "Gagal menyiapkan database sesi bersih"
			if err != nil {
				errStr = err.Error()
			}
			_ = json.NewEncoder(w).Encode(map[string]interface{}{
				"ok":    false,
				"error": errStr,
			})
			return
		}

		addLog("Menghubungkan ke server WhatsApp untuk meminta Pairing Code nomor " + cleanPhone + "...")
		if sess.Client.IsConnected() {
			sess.Client.Disconnect()
			time.Sleep(300 * time.Millisecond)
		}
		if err := sess.Client.Connect(); err != nil {
			addLog("Gagal connect ke WhatsApp WebSocket: " + err.Error())
			_ = json.NewEncoder(w).Encode(map[string]interface{}{
				"ok":    false,
				"error": "Gagal terhubung ke server WA: " + err.Error(),
			})
			return
		}

		for i := 0; i < 30; i++ {
			if sess.Client.IsConnected() {
				break
			}
			time.Sleep(150 * time.Millisecond)
		}
		time.Sleep(1500 * time.Millisecond)

		var code string
		var err error
		for attempt := 0; attempt < 2; attempt++ {
			code, err = sess.Client.PairPhone(
				context.Background(),
				cleanPhone,
				true,
				whatsmeow.PairClientChrome,
				"Chrome (Linux)",
			)
			if err == nil && code != "" {
				break
			}
			time.Sleep(1200 * time.Millisecond)
		}
		if err != nil {
			addLog("Gagal mengambil Pairing Code dari WA: " + err.Error())
			_ = json.NewEncoder(w).Encode(map[string]interface{}{
				"ok":    false,
				"error": err.Error(),
			})
			return
		}

		mu.Lock()
		sess.PairingCode = code
		sess.State = "WAITING_USER_PAIR_INPUT"
		latestPairCode = code
		mu.Unlock()
		addLog(fmt.Sprintf("PAIRING CODE [%s]: %s (Segera masukkan di WA -> Perangkat Tertaut)", cleanPhone, code))

		_ = json.NewEncoder(w).Encode(map[string]interface{}{
			"ok":          true,
			"phone":       cleanPhone,
			"pairingCode": code,
		})
	})

	http.HandleFunc("/session/toggle", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		id := r.URL.Query().Get("id")
		activeStr := r.URL.Query().Get("active")
		active := activeStr == "true" || activeStr == "1"

		mu.Lock()
		sess, ok := sessions[id]
		if ok && sess != nil {
			sess.Active = active
			if active {
				sess.GuestStatusOnly = false
			} else {
				sess.GuestStatusOnly = true
			}
		}
		mu.Unlock()

		if ok && sess != nil {
			saveSessionsMeta()
			if active {
				addLog(fmt.Sprintf("[Multi-WA] Bot AI DIAKTIFKAN untuk nomor %s", sess.Phone))
			} else {
				addLog(fmt.Sprintf("[Multi-WA] Bot AI DIJEDA (Khusus Status HD) untuk nomor %s", sess.Phone))
			}
		}
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]bool{"ok": ok})
	})

	http.HandleFunc("/session/delete", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		id := r.URL.Query().Get("id")
		mu.Lock()
		sess, ok := sessions[id]
		mu.Unlock()
		if ok && sess != nil {
			if sess.Client != nil && sess.Client.IsLoggedIn() {
				_ = sess.Client.Logout(context.Background())
			}
			destroySessionAndDB(id)
			saveSessionsMeta()
			addLog(fmt.Sprintf("[Multi-WA] Sesi nomor %s berhasil dihapus.", id))
		}
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]bool{"ok": true})
	})

	http.HandleFunc("/api/status-upload", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		w.Header().Set("Content-Type", "application/json")
		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusOK)
			return
		}
		var req struct {
			SessionID        string `json:"sessionId"`
			MimeType         string `json:"mimeType"`
			Base64Data       string `json:"base64Data"`
			Caption          string `json:"caption"`
			AudienceMode     string `json:"audienceMode"`
			AudienceNumbers  string `json:"audienceNumbers"`
			MentionNumbers   string `json:"mentionNumbers"`
			StatusExceptList string `json:"statusExceptList"`
			StatusOnlyList   string `json:"statusOnlyList"`
			StatusCloseList  string `json:"statusCloseList"`
		}
		if err := json.NewDecoder(io.LimitReader(r.Body, 150*1024*1024)).Decode(&req); err != nil {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": "Data terlalu besar atau tidak valid: " + err.Error()})
			return
		}

		mu.Lock()
		if req.AudienceMode != "" {
			config.DefaultStatusMode = req.AudienceMode
		}
		config.StatusExceptList = req.StatusExceptList
		config.StatusOnlyList = req.StatusOnlyList
		config.StatusCloseList = req.StatusCloseList
		sess := sessions[req.SessionID]
		mu.Unlock()
		savePersistedConfig()

		if sess == nil {
			sess = getPrimaryActiveSession()
		}
		if sess == nil || sess.Client == nil || !sess.Client.IsLoggedIn() {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": "Nomor WA belum tertaut / belum aktif"})
			return
		}

		audMode := req.AudienceMode
		if audMode == "" {
			audMode = "contacts"
		}
		audList := parsePhoneList(req.AudienceNumbers)
		mentions := parsePhoneList(req.MentionNumbers)

		if strings.TrimSpace(req.Base64Data) == "" {
			if err := uploadStatusHD(context.Background(), sess, "text", nil, "text/plain", req.Caption, audMode, audList, mentions); err != nil {
				_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": err.Error()})
				return
			}
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": true})
			return
		}

		rawBytes, err := base64.StdEncoding.DecodeString(req.Base64Data)
		if err != nil {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": "Gagal decode file media: " + err.Error()})
			return
		}
		mediaKind := "image"
		if strings.HasPrefix(strings.ToLower(req.MimeType), "video/") {
			mediaKind = "video"
		}
		if err := uploadStatusHD(context.Background(), sess, mediaKind, rawBytes, req.MimeType, req.Caption, audMode, audList, mentions); err != nil {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": err.Error()})
			return
		}
		_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": true})
	})

	http.HandleFunc("/groups/list", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		w.Header().Set("Content-Type", "application/json")
		sess := getPrimaryActiveSession()
		if sess == nil || sess.Client == nil || !sess.Client.IsLoggedIn() {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": "Nomor WA Bot belum aktif"})
			return
		}
		groups, err := sess.Client.GetJoinedGroups(context.Background())
		if err != nil {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": err.Error()})
			return
		}
		outList := make([]map[string]interface{}, 0, len(groups))
		for _, g := range groups {
			if g == nil {
				continue
			}
			outList = append(outList, map[string]interface{}{
				"jid":   g.JID.String(),
				"name":  g.Name,
				"count": len(g.Participants),
			})
		}
		sort.Slice(outList, func(i, j int) bool {
			return fmt.Sprint(outList[i]["name"]) < fmt.Sprint(outList[j]["name"])
		})
		_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": true, "groups": outList})
	})

	http.HandleFunc("/groups/announce", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		w.Header().Set("Content-Type", "application/json")
		var req struct {
			GroupJids []string `json:"groupJids"`
			Message   string   `json:"message"`
			Hidetag   bool     `json:"hidetag"`
			Hashtags  string   `json:"hashtags"`
		}
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil || len(req.GroupJids) == 0 || strings.TrimSpace(req.Message) == "" {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": "Pilih minimal 1 grup & isi pesan pengumuman!"})
			return
		}
		sess := getPrimaryActiveSession()
		if sess == nil || sess.Client == nil || !sess.Client.IsLoggedIn() {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": "Nomor WA Bot belum aktif"})
			return
		}
		tags := strings.TrimSpace(req.Hashtags)
		if tags == "" {
			tags = "#PENGUMUMAN #INFO_PENTING #UPDATE_GRUP #BROADCAST"
		}
		mu.Lock()
		bName := strings.TrimSpace(config.BotName)
		mu.Unlock()
		if bName == "" {
			bName = "DodosBot"
		}
		formatted := fmt.Sprintf(
			"📢 *PENGUMUMAN RESMI*\n"+
				"━━━━━━━━━━━━━━━━━━━━\n\n"+
				"%s\n\n"+
				"━━━━━━━━━━━━━━━━━━━━\n"+
				"🏷️ %s\n"+
				"⚡ _Disampaikan oleh %s_",
			strings.TrimSpace(req.Message), tags, bName,
		)

		sentCount := 0
		for idx, gStr := range req.GroupJids {
			gJID, err := types.ParseJID(gStr)
			if err != nil {
				continue
			}
			var mentions []string
			if req.Hidetag {
				if gi, gErr := sess.Client.GetGroupInfo(context.Background(), gJID); gErr == nil && gi != nil {
					for _, p := range gi.Participants {
						mentions = append(mentions, p.JID.String())
					}
				}
			}
			var msgObj *waE2E.Message
			if len(mentions) > 0 {
				msgObj = &waE2E.Message{
					ExtendedTextMessage: &waE2E.ExtendedTextMessage{
						Text: proto.String(formatted),
						ContextInfo: &waE2E.ContextInfo{
							MentionedJID: mentions,
						},
					},
				}
			} else {
				msgObj = &waE2E.Message{
					Conversation: proto.String(formatted),
				}
			}
			if resp, sErr := sess.Client.SendMessage(context.Background(), gJID, msgObj); sErr == nil {
				sentCount++
				if resp.ID != "" {
					mu.Lock()
					botSentIDs[resp.ID] = true
					mu.Unlock()
				}
			}
			if idx < len(req.GroupJids)-1 {
				time.Sleep(1500 * time.Millisecond)
			}
		}
		addLog(fmt.Sprintf("[Pengumuman] Terkirim ke %d/%d grup terpilih.", sentCount, len(req.GroupJids)))
		_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": true, "sent": sentCount, "total": len(req.GroupJids)})
	})

	http.HandleFunc("/terminal/exec", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		w.Header().Set("Content-Type", "application/json")
		var req struct {
			Mode    string `json:"mode"`
			Command string `json:"command"`
			Host    string `json:"host"`
			SshPort string `json:"sshPort"`
			User    string `json:"user"`
			Pass    string `json:"pass"`
		}
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "output": err.Error()})
			return
		}
		cmdStr := strings.TrimSpace(req.Command)
		if cmdStr == "" {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": true, "output": ""})
			return
		}
		// Jalankan di Sesi 2 terpisah agar tidak memengaruhi proses bot WhatsApp!
		if strings.ToUpper(req.Mode) == "VPS" && strings.TrimSpace(req.Host) != "" && strings.TrimSpace(req.Pass) != "" {
			out, err := runSshCommand(req.Host, req.SshPort, req.User, req.Pass, cmdStr)
			if err != nil && out == "" {
				out = "Error: " + err.Error()
			}
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": err == nil, "output": out})
			return
		}
		ctxCmd, cancel := context.WithTimeout(context.Background(), 20*time.Second)
		defer cancel()
		shBin := "/system/bin/sh"
		if _, err := os.Stat(shBin); err != nil {
			shBin = "/bin/sh"
		}
		c := exec.CommandContext(ctxCmd, shBin, "-c", cmdStr)
		outBytes, err := c.CombinedOutput()
		out := strings.TrimSpace(string(outBytes))
		if err != nil && out == "" {
			out = err.Error()
		}
		_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": err == nil, "output": out})
	})

	http.HandleFunc("/backup/export", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		w.Header().Set("Content-Type", "application/json")
		mu.Lock()
		payload := map[string]interface{}{
			"version":      "5.0",
			"exportedAt":   time.Now().Format(time.RFC3339),
			"config":       config,
			"activeGroups": activeGroups,
			"mutedPrivate": mutedPrivate,
		}
		mu.Unlock()
		_ = json.NewEncoder(w).Encode(payload)
	})

	http.HandleFunc("/backup/import", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		w.Header().Set("Content-Type", "application/json")
		var payload struct {
			Config       BotConfig       `json:"config"`
			ActiveGroups map[string]bool `json:"activeGroups"`
			MutedPrivate map[string]bool `json:"mutedPrivate"`
		}
		if err := json.NewDecoder(r.Body).Decode(&payload); err != nil {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": err.Error()})
			return
		}
		mu.Lock()
		if payload.Config.BotName != "" {
			payload.Config.Model = sanitizeModelName(payload.Config.Model)
			config = payload.Config
		}
		for k, v := range payload.ActiveGroups {
			activeGroups[k] = v
		}
		for k, v := range payload.MutedPrivate {
			mutedPrivate[k] = v
		}
		mu.Unlock()
		savePersistedConfig()
		addLog("[Backup Restore] Konfigurasi & daftar grup berhasil dipulihkan!")
		_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": true, "config": config})
	})

	http.HandleFunc("/mc/action", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		w.Header().Set("Content-Type", "application/json")
		var req struct {
			Host           string `json:"host"`
			SshPort        string `json:"sshPort"`
			User           string `json:"user"`
			Pass           string `json:"pass"`
			Action         string `json:"action"`
			ServerType     string `json:"serverType"` // "bedrock" or "paper"
			Command        string `json:"command"`
			ServerName     string `json:"serverName"`
			MaxPlayers     string `json:"maxPlayers"`
			Gamemode       string `json:"gamemode"`
		}
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": err.Error()})
			return
		}
		if strings.TrimSpace(req.Host) == "" || strings.TrimSpace(req.Pass) == "" {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": "Mode Server Minecraft hanya tersedia saat terhubung ke VPS!"})
			return
		}
		var cmd string
		switch req.Action {
		case "status":
			cmd = `RUNNING=$(pgrep -f 'bedrock_server|paper.jar' >/dev/null && echo ONLINE || echo OFFLINE); ` +
				`INSTALLED=$(test -x /opt/mc-server/bedrock_server && echo bedrock || (test -f /opt/mc-server/paper.jar && echo paper || echo none)); ` +
				`RAM=$(free -m | awk '/Mem:/ {printf "%s/%sMB", $3, $2}'); ` +
				`echo "STATUS:$RUNNING|TYPE:$INSTALLED|RAM:$RAM"; ` +
				`tail -n 18 /opt/mc-server/mc.log 2>/dev/null || echo 'Belum ada log server.'`
		case "install_bedrock":
			cmd = `mkdir -p /opt/mc-server && cd /opt/mc-server && ` +
				`(command -v unzip >/dev/null 2>&1 || apt-get update -qq && apt-get install -y -qq unzip screen curl libcurl4 >/dev/null 2>&1) && ` +
				`URL=$(curl -sL -A 'Mozilla/5.0' 'https://net-secondary.web.minecraft-services.net/api/v1.0/download/links' | grep -oE 'https://www\.minecraft\.net/bedrockdedicatedserver/bin-linux/bedrock-server-[0-9.]+\.zip' | head -n1); ` +
				`if [ -z "$URL" ]; then URL='https://www.minecraft.net/bedrockdedicatedserver/bin-linux/bedrock-server-1.21.51.02.zip'; fi; ` +
				`curl -sL -A 'Mozilla/5.0' "$URL" -o bds.zip && unzip -o -q bds.zip && rm -f bds.zip && chmod +x bedrock_server && ` +
				`(ufw allow 19132/udp 2>/dev/null || true) && echo '✅ Bedrock Server BDS berhasil dipasang di /opt/mc-server!'`
		case "install_paper":
			cmd = `mkdir -p /opt/mc-server && cd /opt/mc-server && ` +
				`(command -v java >/dev/null 2>&1 || (apt-get update -qq && apt-get install -y -qq openjdk-21-jre-headless screen curl jq >/dev/null 2>&1)) && ` +
				`curl -sL 'https://api.papermc.io/v2/projects/paper/versions/1.21.4/builds/185/downloads/paper-1.21.4-185.jar' -o paper.jar && ` +
				`echo 'eula=true' > eula.txt && (ufw allow 25565/tcp 2>/dev/null || true) && echo '✅ Java PaperMC 1.21.4 berhasil dipasang di /opt/mc-server!'`
		case "start":
			cmd = `cd /opt/mc-server && (screen -S mcserver -X quit 2>/dev/null || true); ` +
				`if [ -x /opt/mc-server/bedrock_server ]; then ` +
				`screen -dmS mcserver bash -c 'cd /opt/mc-server && LD_LIBRARY_PATH=. ./bedrock_server > mc.log 2>&1'; echo '🟢 Bedrock Server Dinyalakan (Port 19132)!'; ` +
				`elif [ -f /opt/mc-server/paper.jar ]; then ` +
				`screen -dmS mcserver bash -c 'cd /opt/mc-server && java -Xms512M -Xmx1536M -jar paper.jar --nogui > mc.log 2>&1'; echo '🟢 PaperMC Server Dinyalakan (Port 25565)!'; ` +
				`else echo '❌ Server belum terpasang. Klik Pasang Bedrock / Paper dulu!'; fi`
		case "stop":
			cmd = `screen -S mcserver -p 0 -X stuff "stop\n" 2>/dev/null || true; sleep 2; pkill -f 'bedrock_server|paper.jar' 2>/dev/null || true; echo '🔴 Server Minecraft Dimatikan.'`
		case "cmd":
			safeCmd := strings.ReplaceAll(req.Command, string('"'), "")
			cmd = fmt.Sprintf(`screen -S mcserver -p 0 -X stuff "%s\n" && sleep 1 && tail -n 15 /opt/mc-server/mc.log 2>/dev/null`, safeCmd)
		case "save_props":
			sName := strings.TrimSpace(req.ServerName)
			if sName == "" {
				sName = "DodosMC Server"
			}
			mPlay := strings.TrimSpace(req.MaxPlayers)
			if mPlay == "" {
				mPlay = "20"
			}
			gMode := strings.TrimSpace(req.Gamemode)
			if gMode == "" {
				gMode = "survival"
			}
			cmd = fmt.Sprintf(
				`mkdir -p /opt/mc-server && touch /opt/mc-server/server.properties && `+
					`sed -i '/^server-name=/d;/^motd=/d;/^max-players=/d;/^gamemode=/d' /opt/mc-server/server.properties && `+
					`printf 'server-name=%s\nmotd=%s\nmax-players=%s\ngamemode=%s\n' >> /opt/mc-server/server.properties && `+
					`echo '✅ server.properties disimpan! Restart server untuk menerapkan.'`,
				sName, sName, mPlay, gMode,
			)
		default:
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": "Aksi tidak dikenal"})
			return
		}
		out, err := runSshCommand(req.Host, req.SshPort, req.User, req.Pass, cmd)
		_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": err == nil, "output": out})
	})

	http.HandleFunc("/reset-banner-cache", func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		for _, s := range sessions {
			if s != nil {
				s.MoodMediaCache = make(map[string]*CachedMoodMedia)
			}
		}
		mu.Unlock()
		addLog("Cache banner ekspresi di-reset ke Maskot Rina!")
		setCors(w)
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": true, "mascot": "Rina"})
	})

	http.HandleFunc("/reset-memory", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		mu.Lock()
		memory = make(map[string][]ChatTurn)
		mu.Unlock()
		addLog("Memori percakapan semua nomor berhasil di-reset.")
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]bool{"ok": true})
	})

	log.Fatal(http.ListenAndServe("0.0.0.0:"+port, nil))
}
