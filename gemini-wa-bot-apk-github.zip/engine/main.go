package main

import (
	"archive/zip"
	"bytes"
	"compress/gzip"
	"context"
	"crypto/rand"
	"crypto/sha256"
	"crypto/tls"
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"math/big"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"reflect"
	"regexp"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"golang.org/x/crypto/ssh"
	_ "golang.org/x/crypto/x509roots/fallback"

	"go.mau.fi/whatsmeow"
	waBinary "go.mau.fi/whatsmeow/binary"
	"go.mau.fi/whatsmeow/proto/waE2E"
	"go.mau.fi/whatsmeow/store"
	"go.mau.fi/whatsmeow/store/sqlstore"
	"go.mau.fi/whatsmeow/types"
	"go.mau.fi/whatsmeow/types/events"
	waLog "go.mau.fi/whatsmeow/util/log"
	"google.golang.org/protobuf/proto"
	_ "modernc.org/sqlite"
)

func ensureAndroidRootCAs() {
	// Jika /etc/ssl/certs/ca-certificates.crt sudah ada (misal di VPS Ubuntu), tidak perlu buat ulang
	if st, err := os.Stat("/etc/ssl/certs/ca-certificates.crt"); err == nil && st.Size() > 1024 {
		return
	}
	// Jika berjalan di Mode Mandiri HP (Android), kumpulkan semua sertifikat Root CA dari sistem Android
	certDirs := []string{
		"/system/etc/security/cacerts",
		"/apex/com.android.conscrypt/cacerts",
		"/system/etc/security/cacerts_google",
	}
	existingDirs := make([]string, 0, len(certDirs))
	var bundleBuf bytes.Buffer

	if data, err := os.ReadFile("cacert.pem"); err == nil && len(data) > 1024 {
		bundleBuf.Write(data)
		bundleBuf.WriteByte(10)
	}

	for _, dir := range certDirs {
		entries, err := os.ReadDir(dir)
		if err != nil || len(entries) == 0 {
			continue
		}
		existingDirs = append(existingDirs, dir)
		for _, ent := range entries {
			if ent.IsDir() {
				continue
			}
			cBytes, err := os.ReadFile(filepath.Join(dir, ent.Name()))
			if err == nil && bytes.Contains(cBytes, []byte("-----BEGIN CERTIFICATE-----")) {
				bundleBuf.Write(cBytes)
				bundleBuf.WriteByte(10)
			}
		}
	}

	if len(existingDirs) > 0 {
		_ = os.Setenv("SSL_CERT_DIR", strings.Join(existingDirs, ":"))
	}
	if bundleBuf.Len() > 1024 {
		bundlePath := filepath.Join(os.TempDir(), "wabot_android_cacerts.pem")
		if err := os.WriteFile(bundlePath, bundleBuf.Bytes(), 0644); err != nil {
			bundlePath = "wabot_android_cacerts.pem"
			_ = os.WriteFile(bundlePath, bundleBuf.Bytes(), 0644)
		}
		if absPath, err := filepath.Abs(bundlePath); err == nil {
			_ = os.Setenv("SSL_CERT_FILE", absPath)
		} else {
			_ = os.Setenv("SSL_CERT_FILE", bundlePath)
		}
	}
}

func init() {
	ensureAndroidRootCAs()
	net.DefaultResolver = &net.Resolver{
		PreferGo: true,
		Dial: func(ctx context.Context, network, address string) (net.Conn, error) {
			d := net.Dialer{Timeout: 5 * time.Second}
			conn, err := d.DialContext(ctx, "udp", "8.8.8.8:53")
			if err != nil {
				return d.DialContext(ctx, "udp", "1.1.1.1:53")
			}
			return conn, nil
		},
	}
	if tr, ok := http.DefaultTransport.(*http.Transport); ok {
		tr.TLSClientConfig = &tls.Config{InsecureSkipVerify: true}
	}
}

type BotConfig struct {
	ApiKey            string `json:"apiKey"`
	Model             string `json:"model"`
	SystemPrompt      string `json:"systemPrompt"`
	ReplyScope        string `json:"replyScope"`
	GroupTrigger      string `json:"groupTrigger"`
	BlacklistNumbers  string `json:"blacklistNumbers"`
	MinDelayMs        int    `json:"minDelayMs"`
	MaxDelayMs        int    `json:"maxDelayMs"`
	PhoneNumber       string `json:"phoneNumber"`
	BotEnabled        bool   `json:"botEnabled"`
	DefaultStatusMode string `json:"defaultStatusMode"`
	StatusExceptList  string `json:"statusExceptList"`
	StatusOnlyList    string `json:"statusOnlyList"`
	StatusCloseList   string `json:"statusCloseList"`
	MenuStyle         string `json:"menuStyle"`
	BotName           string `json:"botName"`
	AutoWelcome       bool   `json:"autoWelcome"`
	AntiLink          bool   `json:"antiLink"`
	AntiSpam          bool   `json:"antiSpam"`
}

type ChatTurn struct {
	Role string `json:"role"`
	Text string `json:"text"`
}

type RpgProfile struct {
	Level int   `json:"level"`
	Exp   int   `json:"exp"`
	Gold  int   `json:"gold"`
	HP    int   `json:"hp"`
	Last  int64 `json:"last"`
}

type UiChatMessage struct {
	ID        string `json:"id"`
	Sender    string `json:"sender"`
	Text      string `json:"text"`
	FromMe    bool   `json:"fromMe"`
	Timestamp string `json:"timestamp"`
}

type UiChatThread struct {
	ChatJID     string          `json:"chatJid"`
	Title       string          `json:"title"`
	IsGroup     bool            `json:"isGroup"`
	LastMessage string          `json:"lastMessage"`
	UpdatedAt   int64           `json:"updatedAt"`
	Messages    []UiChatMessage `json:"messages"`
}

type SessionMeta struct {
	ID              string `json:"id"`
	Phone           string `json:"phone"`
	DBFile          string `json:"dbFile"`
	Active          bool   `json:"active"`
	GuestStatusOnly bool   `json:"guestStatusOnly"`
}

type CachedMoodMedia struct {
	Upload    whatsmeow.UploadResponse
	CreatedAt time.Time
}

type SessionInstance struct {
	ID              string                      `json:"id"`
	Phone           string                      `json:"phone"`
	JID             string                      `json:"jid"`
	PushName        string                      `json:"pushName"`
	DBFile          string                      `json:"dbFile"`
	Active          bool                        `json:"active"`
	GuestStatusOnly bool                        `json:"guestStatusOnly"`
	PairingCode     string                      `json:"pairingCode"`
	State           string                      `json:"state"`
	Container       *sqlstore.Container         `json:"-"`
	Client          *whatsmeow.Client           `json:"-"`
	Chats           map[string]*UiChatThread    `json:"-"`
	MoodMediaCache  map[string]*CachedMoodMedia `json:"-"`
}

type TransientAudienceStore struct {
	store.ContactStore
	mode string
	list []string
}

func (a *TransientAudienceStore) GetAllContacts(ctx context.Context) (map[types.JID]types.ContactInfo, error) {
	baseMap, err := a.ContactStore.GetAllContacts(ctx)
	if err != nil || baseMap == nil {
		baseMap = make(map[types.JID]types.ContactInfo)
	}
	for _, raw := range a.list {
		norm := normalizePhone(raw)
		if len(norm) >= 9 {
			jid := types.NewJID(norm, types.DefaultUserServer)
			if _, exists := baseMap[jid]; !exists {
				baseMap[jid] = types.ContactInfo{Found: true, FirstName: norm, FullName: norm}
			}
		}
	}

	if a.mode == "whitelist" || a.mode == "close_friends" {
		filtered := make(map[types.JID]types.ContactInfo)
		for _, raw := range a.list {
			norm := normalizePhone(raw)
			if norm != "" {
				jid := types.NewJID(norm, types.DefaultUserServer)
				filtered[jid] = types.ContactInfo{Found: true, FirstName: norm, FullName: norm}
			}
		}
		return filtered, nil
	}

	if a.mode == "blacklist" {
		blocked := make(map[string]bool)
		for _, raw := range a.list {
			norm := normalizePhone(raw)
			if norm != "" {
				blocked[norm] = true
			}
		}
		filtered := make(map[types.JID]types.ContactInfo)
		for jid, info := range baseMap {
			if !blocked[normalizePhone(jid.User)] {
				filtered[jid] = info
			}
		}
		return filtered, nil
	}

	return baseMap, nil
}

var (
	mu                   sync.Mutex
	sessions             = make(map[string]*SessionInstance)
	startTime            = time.Now()
	totalReplied         = 0
	config               = BotConfig{
		Model:             "gemini-2.5-flash",
		SystemPrompt:      "Kamu adalah asisten AI pribadi yang ramah, pintar, dan membantu di WhatsApp. Jawab dengan bahasa Indonesia yang natural dan ringkas.",
		ReplyScope:        "all",
		GroupTrigger:      "@bot",
		MinDelayMs:        1500,
		MaxDelayMs:        3000,
		BotEnabled:        true,
		DefaultStatusMode: "contacts",
		MenuStyle:         "both",
		BotName:           "DodosBot",
	}
	logs                 = make([]string, 0, 200)
	memory               = make(map[string][]ChatTurn)
	activeGroups         = make(map[string]bool)
	mutedPrivate         = make(map[string]bool)
	manualPauseUntil     = make(map[string]time.Time)
	botSentIDs           = make(map[string]bool)
	processedIncomingIDs = make(map[string]bool)
	rpgPlayers           = make(map[string]*RpgProfile)
	latestPairCode       = ""
	mentionRegex         = regexp.MustCompile(`@(628[0-9]{7,13}|08[0-9]{7,13})`)
	urlExtractRegex      = regexp.MustCompile(`https?://[^\s<>"]+`)
	ytVideoIdRegex       = regexp.MustCompile(`(?:youtu\.be/|youtube\.com/(?:watch\?(?:.*&)?v=|shorts/|embed/|live/|v/))([a-zA-Z0-9_-]{11})`)
	moodTagRegex         = regexp.MustCompile(`(?i)^\s*\[MOOD\s*:\s*([a-z_]+)\]\s*`)
	lastChatVideoCache   = make(map[string][]byte)
	statusUploadMutex    sync.Mutex
	lastStatusUploadTime = make(map[string]time.Time)
	lastStatusUploadHash = make(map[string]string)
	bannerEnabled        = true
	spamTracker          = make(map[string][]time.Time)
	linkDetectRegex      = regexp.MustCompile(`(?i)(https?://[^\s]+|chat\.whatsapp\.com/[^\s]+|wa\.me/[^\s]+)`)
)

var expressionLabels = map[string]string{
	"ceria":    "😊 Ceria & Senang",
	"tenang":   "😌 Tenang & Kalem",
	"marah":    "😠 Kesal & Tegas",
	"sedih":    "😢 Sedih & Terharu",
	"bingung":  "🤔 Bingung & Mikir",
	"ketawa":   "😆 Ngakak & Seru",
	"malu":     "😳 Malu-Malu",
	"kaget":    "😲 Kaget & Terkejut",
	"bosan":    "😒 Bosan & Datar",
	"keren":    "😎 Santai & Keren",
	"nangis":   "😭 Nangis Kejer",
	"ngantuk":  "😴 Ngantuk Berat",
	"panik":    "😵‍💫 Panik & Pusing",
	"bangga":   "😤 Bangga & Pede",
	"gugup":    "😰 Gugup & Canggung",
	"semangat": "🔥 Semangat Membara",
	"ngambek":  "😣 Ngambek & Cemberut",
	"suka":     "😍 Suka & Gemas",
	"syok":     "😱 Syok Berat",
	"ramah":    "😉 Ramah & Akrab",
}
var expressionBannersB64 = map[string]string{
	"ceria": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4lkkcOwDN1Pem+Y/99vzok/1j/U16LNNF8NYLa0tLZB4yC77u8f8AeLZq4BEUYI2ltmMtg43MATn5erU4cRiHScYQjzSlsttt230S0u7PdaNsx9P+GvjHUoWlh0a6RVbaRcMsLZwD91yCRz1xirg+EvjXaf8AiUtnI/5eof8A4uuav9SvdUmWa+vLi6mVdgeeRnYLknGSenJ/OqtPlfcw5Mc9faQX/bjf486/I67/AIVJ42/6BLf+BcP/AMXR/wAKk8bf9Alv/AuH/wCLrkaKOV9w9njv+fsP/AH/APLDrv8AhUnjb/oEt/4Fw/8AxdK/wl8almxpLYzx/pUP/wAXXIUUcr7h7PHf8/Yf+AP/AOWHXf8ACpPG3/QJb/wLh/8Ai6P+FSeNv+gS3/gXD/8AF1yNFHK+4ezx3/P2H/gD/wDlh14+EvjXaf8AiUtnI/5eof8A4uk/4VJ42/6BLf8AgXD/APF1yNFHK+4ezx3/AD9h/wCAP/5Ydd/wqTxt/wBAlv8AwLh/+Lo/4VJ42/6BLf8AgXD/APF1yNFHK+4ezx3/AD9h/wCAP/5Yde/wl8almxpLYzx/pUP/AMXSf8Kk8bf9Alv/AALh/wDi65GijlfcPZ47/n7D/wAAf/yw67/hUnjb/oEt/wCBcP8A8XSj4S+Ndp/4lLZyP+XqH/4uuQoo5X3D2eO/5+w/8Af/AMsOu/4VJ42/6BLf+BcP/wAXR/wqTxt/0CW/8C4f/i65GijlfcPZ47/n7D/wB/8Ayw67/hUnjb/oEt/4Fw//ABdK/wAJfGpZsaS2M8f6VD/8XXIUUcr7h7PHf8/Yf+AP/wCWHXf8Kk8bf9Alv/AuH/4uj/hUnjb/AKBLf+BcP/xdcjRRyvuHs8d/z9h/4A//AJYdePhL412n/iUtnI/5eof/AIuk/wCFSeNv+gS3/gXD/wDF1yNFHK+4ezx3/P2H/gD/APlh13/CpPG3/QJb/wAC4f8A4uj/AIVJ42/6BLf+BcP/AMXXI0Ucr7h7PHf8/Yf+AP8A+WHXv8JfGpZsaS2M8f6VD/8AF0n/AAqTxt/0CW/8C4f/AIuuRoo5X3D2eO/5+w/8Af8A8sOu/wCFSeNv+gS3/gXD/wDF0o+EvjXaf+JS2cj/AJeof/i65CijlfcPZ47/AJ+w/wDAH/8ALDrv+FSeNv8AoEt/4Fw//F0f8Kk8bf8AQJb/AMC4f/i65GijlfcPZ47/AJ+w/wDAH/8ALDrv+FSeNv8AoEt/4Fw//F0r/CXxqWbGktjPH+lQ/wDxdchRRyvuHs8d/wA/Yf8AgD/+WHXf8Kk8bf8AQJb/AMC4f/i6P+FSeNv+gS3/AIFw/wDxdcjRRyvuHs8d/wA/Yf8AgD/+WHXj4S+Ndp/4lLZyP+XqH/4uk/4VJ42/6BLf+BcP/wAXXI0Ucr7h7PHf8/Yf+AP/AOWHXf8ACpPG3/QJb/wLh/8Ai6P+FSeNv+gS3/gXD/8AF1yNFHK+4ezx3/P2H/gD/wDlh17/AAl8almxpLYzx/pUP/xdJ/wqTxt/0CW/8C4f/i65GijlfcPZ47/n7D/wB/8Ayw67/hUnjb/oEt/4Fw//ABdKPhL412n/AIlLZyP+XqH/AOLrkKKOV9w9njv+fsP/AAB//LDrv+FSeNv+gS3/AIFw/wDxdH/CpPG3/QJb/wAC4f8A4uuRoo5X3D2eO/5+w/8AAH/8sOu/4VJ42/6BLf8AgXD/APF0r/CXxqWbGktjPH+lQ/8AxdchRRyvuHs8d/z9h/4A/wD5Ydd/wqTxt/0CW/8AAuH/AOLo/wCFSeNv+gS3/gXD/wDF1yNFHK+4ezx3/P2H/gD/APlh0t/8NfGGm2wln0a6cM4UC3ZZm6H+FCSBx16VyHmP/fb861LDUr3S5mmsby4tZmXYXgkZGK5BxkHpwPyrsYZoviVBc2l3bIfGRXfaXifu1vFQEmKQAbQ2zOGwM7VBIx8w00KVfEYZc2ItKPVxTVvNpt6Lq76b2tt515j/AN9vzoptFI9E6/4a6fFqXxB0aGVnVUnM4KEA7o1aRfwyoz7VjalfyapqN5fTKizXUzzOEBChmYk4z25rpfhKF/4WPpPJzmft/wBMXrkKcd2efDXHVL9IQ/Fzv+SPdvhB4h8M6b4beGW6tLHUxITdNcyLGZuTsKljyAvGB0OeOcn0L/hMfDv/AEH9K/8AAyP/ABr5HopOkm7nhY3hOjiq868qsk5O/f8Apduy0Prj/hMfDv8A0H9K/wDAyP8Axo/4THw7/wBB/Sv/AAMj/wAa+R6KXsV3OX/Uqh/z9f3I+uP+Ex8O/wDQf0r/AMDI/wDGj/hMfDv/AEH9K/8AAyP/ABr5Hoo9iu4f6lUP+fr+5H1x/wAJj4d/6D+lf+Bkf+NH/CY+Hf8AoP6V/wCBkf8AjXyPRR7Fdw/1Kof8/X9yPrj/AITHw7/0H9K/8DI/8aP+Ex8O/wDQf0r/AMDI/wDGvkeij2K7h/qVQ/5+v7kfXH/CY+Hf+g/pX/gZH/jR/wAJj4d/6D+lf+Bkf+NfI9FHsV3D/Uqh/wA/X9yPrj/hMfDv/Qf0r/wMj/xo/wCEx8O/9B/Sv/AyP/Gvkeij2K7h/qVQ/wCfr+5H1x/wmPh3/oP6V/4GR/40f8Jj4d/6D+lf+Bkf+NfI9FHsV3D/AFKof8/X9yPrj/hMfDv/AEH9K/8AAyP/ABo/4THw7/0H9K/8DI/8a+R6KPYruH+pVD/n6/uR9cf8Jj4d/wCg/pX/AIGR/wCNH/CY+Hf+g/pX/gZH/jXyPRR7Fdw/1Kof8/X9yPrj/hMfDv8A0H9K/wDAyP8Axo/4THw7/wBB/Sv/AAMj/wAa+R6KPYruH+pVD/n6/uR9cf8ACY+Hf+g/pX/gZH/jR/wmPh3/AKD+lf8AgZH/AI18j0UexXcP9SqH/P1/cj64/wCEx8O/9B/Sv/AyP/Gj/hMfDv8A0H9K/wDAyP8Axr5Hoo9iu4f6lUP+fr+5H1x/wmPh3/oP6V/4GR/40f8ACY+Hf+g/pX/gZH/jXyPRR7Fdw/1Kof8AP1/cj64/4THw7/0H9K/8DI/8aP8AhMfDv/Qf0r/wMj/xr5Hoo9iu4f6lUP8An6/uR9cf8Jj4d/6D+lf+Bkf+NH/CY+Hf+g/pX/gZH/jXyPRR7Fdw/wBSqH/P1/cj64/4THw7/wBB/Sv/AAMj/wAaP+Ex8O/9B/Sv/AyP/Gvkeij2K7h/qVQ/5+v7kfXH/CY+Hf8AoP6V/wCBkf8AjR/wmPh3/oP6V/4GR/418j0UexXcP9SqH/P1/cj64/4THw7/ANB/Sv8AwMj/AMaP+Ex8O/8AQf0r/wADI/8AGvkeij2K7h/qVQ/5+v7kfXH/AAmPh3/oP6V/4GR/40f8Jj4d/wCg/pX/AIGR/wCNfI9FHsV3D/Uqh/z9f3I+uP8AhMfDv/Qf0r/wMj/xo/4THw7/ANB/Sv8AwMj/AMa+R6KPYruH+pVD/n6/uR9cf8Jj4d/6D+lf+Bkf+NH/AAmPh3/oP6V/4GR/418j0UexXcP9SqH/AD9f3I+uP+Ex8O/9B/Sv/AyP/Gj/AITHw7/0H9K/8DI/8a+R6KPYruH+pVD/AJ+v7kfXH/CY+Hf+g/pX/gZH/jR/wmPh3/oP6V/4GR/418j0UexXcP8AUqh/z9f3I+uP+Ex8O/8AQf0r/wADI/8AGj/hMfDv/Qf0r/wMj/xr5Hoo9iu4f6lUP+fr+5H0b8RvE/hW88JX0E19ZX8zqRbRW8qyOs2DscbT8oHc+mRznB+fNNv5NL1GzvoVRprWZJkDglSysCM47cVVoq4x5VY+gyvKaeX0JUIyclJ9f8jofifp8Wm+PdchiZ2V5hOS5BO6RRI34ZY49qKufF4L/wALE1nJOf3Pb/pilFQtjpyyTlgqMnu4x/JC/CT/AJKRpP1n/wDRL1yNdd8JP+SkaT9Z/wD0S9cjVR3ZNP8A36p/gh+dQKKKKs7wooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAoorZ0rSoHtf7Q1DzTZGRoY4oHCyTOAC3zEEKFDKSSDnIAHUqETmoK7/4f+v+C9DGorrPtmmf9C5pv/f25/8Aj1H2zTP+hc03/v7c/wDx6nZmPt5f8+3/AOS//JHJ0V1n2zTP+hc03/v7c/8Ax6j7Zpn/AELmm/8Af25/+PUWYe3l/wA+3/5L/wDJHJ0V1n2zTP8AoXNN/wC/tz/8eo+2aZ/0Lmm/9/bn/wCPUWYe3l/z7f8A5L/8kcnRXWfbNM/6FzTf+/tz/wDHqPtmmf8AQuab/wB/bn/49RZh7eX/AD7f/kv/AMkcnRXWfbNM/wChc03/AL+3P/x6j7Zpn/Quab/39uf/AI9RZh7eX/Pt/wDkv/yRydFdZ9s0z/oXNN/7+3P/AMeo+2aZ/wBC5pv/AH9uf/j1FmHt5f8APt/+S/8AyRydFdZ9s0z/AKFzTf8Av7c//HqPtmmf9C5pv/f25/8Aj1FmHt5f8+3/AOS//JHJ0V1R06x110t7OyWx1KQhIFikZoZW7IQ5ZlYk4DbtvQEAEsOVpGlOqp3VrNdH/wAC4UVs6VpUD2v9oah5psjI0McUDhZJnABb5iCFChlJJBzkADqV0/tmmf8AQuab/wB/bn/49USqKLsYzxajK0YuXpb9Wv68zk6K6z7Zpn/Quab/AN/bn/49R9s0z/oXNN/7+3P/AMeqfbRI+uf9O5f+S/8AyRydFdZ9s0z/AKFzTf8Av7c//HqPtmmf9C5pv/f25/8Aj1Htoh9c/wCncv8AyX/5I5Oius+2aZ/0Lmm/9/bn/wCPUfbNM/6FzTf+/tz/APHqPbRD65/07l/5L/8AJHJ0V1n2zTP+hc03/v7c/wDx6j7Zpn/Quab/AN/bn/49R7aIfXP+ncv/ACX/AOSOTorrPtmmf9C5pv8A39uf/j1UtR0u1urWe+06N4fs4D3Ns77gqlgodGIzt3MF2nLDIOWyxVxqxbsVDFptKUWr97fo2YFFFFaHYdX8X/8Akoms/wDbH/0SlFHxf/5KJrP/AGx/9EpRWS2OHKv9xof4I/kh/wAJP+SkaT9Z/wD0S9cjXX/CV2PxH0kbjjM/Gf8Api9chVR3Yqf+/VP8EPzqBRRRVneFFFFABRT4YZLiaOGGN5JpGCIiAlmYnAAA6k16bB8N9L8K2kOo+NNR8vzOYtOtPmeUgBtpb81OMAZHzjNJtI48VjqOFspu8pbJK7fov6R55pWkX+t3a2mnWktzcNj5I1zgZAyT0AyRycAZru7P4Naqlul3rWoafpNmM+a0sm54ucLnonJx/H39eKfefFCeyiWw8K2Fvo+nxtkFY1eWXHGWyCMkBc9TkfeNcdd3GoarKs1/dz3EqqFD3EhdgvJxkk8cnj3oSk/I428xxDurUY/+BS/+RX4nbjwn8OtP/wBHv/FV3Pdp9+S0T902eRjCOOhH8R5z06Bf7W+F3/Qt6p/38b/49XBizXHLEn2p4to8fd/Wq9k+rD+y3LWpXqN+UuX8IpfrY7n+1vhd/wBC3qn/AH8b/wCPUh0D4aalzb69qFjcXP8Aq4plJSBm6KxKYwpOD8/b73euH+zRf3f1NMNouOGYH3o9l5h/ZVtYV6if+K//AKUmdtP8G7u7ikuNA1vTdWto1OSj7WMg52DBZc429WHXnHWuH1vw5qvhy4EGqWMts7fdLDKvwCdrDIbGRnBOM0+3N3p9wlxZ3EkM6Z2yQuUdcjBwR04JFdfpnxT1a3iNnrUEGtacVVWgu0XdhRx82Dk52klgx47HmpcZLzDlzLDu6lGrHs/dl8n8L+dvkec0V6oPAvhvxwskvhC/eyvUXc+nX2cKMhchuSBwScF+WUfLXmuo6ddaRfT2V7A8F1A21436g/1B6gjgg5FCkmdWFzCjiZOEbqa3i1Zr5dvNXXmVaKKKZ3BRRRQAV1l5/wAgbw5/15P/AOlM9cnXV3JD6H4fdTuRLWSJmHIDi4lYqffa6HHowPcU1uc1f4qfr/7bIh060/tDULS037PtEqRb8Z27iBnHfrXVTeBIpNU1DSbDU2n1OyUuYZbfyxKAASEYM3PPQ4rmNKuksdUsbqQMY4J0kYL1IVgTj8q7N/GmlWXiDUtfsY72a/uVKwxzxqkcJIAySGYt09qcua+h52Pni41LYe9uV20VnK6tdvZWvfVfeYMPhqKHRbbVtTvWtbe7cpAkUPmu+OrEblAH459q07b4eyya42nzXyrA1mb2K5jj3iWPjHykjB59aqf8JBYap4esNJ1QXUT2DsYZ7dFfcrHJVlLL+efwrZtfiBZLrwuZba4j06DTzYQJGFeQDjDNkgdvX0qW59Dmr1MxSl7O9/e6KyV/dt3bW979dtDnrjwysmiPrGmXZu7SKQRTI8Xlyxk4xlcsCDkcg96vt4Hht9UttHutVWLV7hQREIC0SMRkKz7s5PspFQN4js9N8Oz6PpS3DtdTLLPc3Cqh+UgqqqCccgc59a0Z/Fuj3/iC08Q3VveLfwhGe2jCmKSRRwd5OQOBxtPSneRU6mP1tfl96zsrvRct1bRX5ui6XsZ9r4JuDY6heXrzRR2VybV0toPPk3jqcbgAoyOc96ZpXhez1OPWrhdTkFnpkayF1tsvICDkbS4wRjHWrGneL2hvr3UG1LUbG8urhpXS1iSWJlPQFWYcjkZ54xWsnxAsX1HxHc+XeWX9pxxxwyWqqzxlQRvPzLzz2NJuZFWrmUeZJdtltrG6s4u+nNZpv0vYxrjwJcnVdIsrK4WcapCJ4nkTyyi4ydy5OMD3NRjwlBew6mdL1I3dxpqmSWJ4PLDoOrIdxzj3ArUm8fxQavod9bQzXEmnRNFNPc4WW5BGOcE4xzjk9ap2viPStETWJNKjvJLrUY2hX7QqqsCMeeQx3Hp6dKLzHGpmPKrp3sraLV8zvzdly2fTr10IoPDGlz6Bc60uq3otbeUQshsV3ljjoPNxjn1rmlgM90sFtvkMj7I8rhmycDjJwT9TW7aa/bQeDL/RWSY3VxcrMrADYFG3qc5zx6VX8J6nY6Nrlvf38UssVvl0SIAkvj5c5I4B5/CqV1e520pYmnCtOd5NN8q01VlbZLd3NHxf4IfwrBbTrereRyu0UjLHt8qQAHb1Oe/5Vn+K/Dv/AAjGprZfaftG6JZd+zZ1zxjJ9K15vGlvqmiaxYahYrFJdyfaoXttzYnzyW3ucAjA+XpzxWf411+28Sawl5apMkSwJHiUAHIznoTSjzXszDBTx/tIU8R05ruy1+Fx29WtO2pzlN8Y/wDI3a//ANf9x/6MapYopJ5UiiRpJZGCoiDJYngADuar+K5o7jxRrc0MiSQyXs7o6EFWUyEggjqDTluj0/8Al/H0f5xNW8/5A3hz/ryf/wBKZ6pQwyXM0cMKNJLIwREUZLEnAAq5ckPofh91O5EtZImYcgOLiVip99rocejA9xT/AA/qn9h67pupGPzBZ3CTFP7wVgcVwz+JnCm1Gbiru8vzZ31x8BvFEGkm8DWclwq7zZpITJ9AcbSfbP415zp2n3GqahbWFsm65uZFijU8ZYnA+lfVFx8ZPCMOlG+TUhK+zK2qowlLf3cY4+vT3r5isden0/xHDrcSJ58Vz9pCfw53btv07VCPIyrF46vGp9YhZra6trrodWnw1gutbu/D9nriz6/bIzGA2xWGR1GWRZN2SRz1UDioU+GlzN4C/wCEogu98qFzJYmLDKiOVZg2eccEjAwD7Vp2/jzw/pviu98WWdrqDapOrtHZyqghilcYZjIGyw5PG0detQ6d8S49M0Pw5bRwzyXen3U8t4rqvlTxSltyDnnIbuOtGpTnj7R5P7t7pdnzL0vZX892Kvwo3eJm0X+1/u6Z/aPnfZvp8m3f79c/hXOeCfCX/CY6ndWX2z7L5FrJc7/L37tuPlxkdc9a7p/ijoR8dT6ylrqCac+lHT1Ty0MitnrjfjGPfNc74N8SaB4N1i4vI59TvIriymt2DWccTKzFdpH71sjg56Y469gcKuN9lLmT5uVW0W+t+lu2/wAiKL4b3F14AXxVbXolcF2ey8rDLGjlWcNu5xwTx0NaMXwoV/FJ0RtYKqNNGomcWuTjj5Nu/wB+ufwqLSfiPBo3h7wzY28E73GmXMz3SOq+VPDITuQc5OQe461u/wDC1NDXx5LrkVvqMVgdL+woqxp5qNkYON+MAD1zRqRUqZgnNRWnvW0Xf3V92q7312PLNSi0yIx/2dd3dwDnebm1WHb6Y2yPnv6VLoX/AB9XX/Xhef8ApNJVnxJqa6m9u41vVtVZAQW1KPaYxxgL+9fOec9Oneq2iEJNeysdsaWF3uc8Bd0DouT2yzKo9SwHU1Ud0enJt4d33s/62X5HIUUUV2nuHV/F/wD5KJrP/bH/ANEpRTvi87D4iayAxA/c9/8ApilFZLY4cq/3Gh/gj+SF+En/ACUjSfrP/wCiXrka674Sf8lI0n6z/wDol65GqjuxU/8Afqn+CH51AoooqzvCtTw/4fv/ABNqkWn6fFvnfkseFjXuzHsB/gBkkCqunaddavfQWVlA891O21I06k/0A6kngAZNep69qcXw00aPw3o2xdauYlk1G/R9zKxH3VPBB64yBtUgjlshN9EebjsZOnKOHw6TqS2vsl1k/Jfi9BLrVtE+F8N7pugF73xG6iKfUJVUpCcfMqj1BGdvIyRuJ27a89u7i71m9mvr6d5biZtzyP1Y+3oMcADgDAFQQW4IDt07CrLyLGMsfw9auMEtWVg8DDDNzvzVJbye7/yXZLQEjWMYUf8A16HkSP7zAVSkunfgfKPbrUFJ1Utj0lS7l43kYOPmPuBTPtv/AEz/AFqpRUOrIr2cS39t/wCmf608XiHGQwqjRR7SQeziaaSo/wB1gT6U5lDjDAEVlVLHcPHxnK+hq1V7kul2LAjltJY57eR0ljYMjIcMpHIII75r0Kw8YaV43sYNG8ab1uRLm31SEKhjz1DHGFHAGcEEYJAK7q4KKZZRkHnuKjntw2XXg9x605QUldHn4vA08Slz6SjtJaNej/NbPqW/GHg+/wDBuqG0uxvgfLQXKjCzL/QjjI7e4IJ56vVPBHiG28R2cfg3xGvn2U/y2dyWAe3cA7VDH8l69duCpwPP/EHh+/8ADOqS6fqEWydOQw5WRezKe4P+IOCCKhPozLBYupzvC4q3tIq9+kl/Ml+a6PyZl0UUUz0wrU0vV1s42truFrmwZt/lLJsdHx95GIO0nAB4IIAyMhSuXRQROEZq0jqPP8O/9BDVf/BfH/8AH6PP8O/9BDVf/BfH/wDH65eind9zH2Ev+fj/APJf/kTqPP8ADv8A0ENV/wDBfH/8fo8/w7/0ENV/8F8f/wAfrl6KLvuHsJf8/H/5L/8AInUef4d/6CGq/wDgvj/+P0ef4d/6CGq/+C+P/wCP1y9FF33D2Ev+fj/8l/8AkTqPP8O/9BDVf/BfH/8AH6PP8O/9BDVf/BfH/wDH65eii77h7CX/AD8f/kv/AMidR5/h3/oIar/4L4//AI/R5/h3/oIar/4L4/8A4/XL0UXfcPYS/wCfj/8AJf8A5E6jz/Dv/QQ1X/wXx/8Ax+jz/Dv/AEENV/8ABfH/APH65eii77h7CX/Px/8Akv8A8idR5/h3/oIar/4L4/8A4/R5/h3/AKCGq/8Agvj/APj9cvRRd9w9hL/n4/8AyX/5E6ObWrDT1J0n7VJeH7t3cKsZh/3I1LfMOzluMnCggMOcoopGtOmoebfV/wBfhsaml6utnG1tdwtc2DNv8pZNjo+PvIxB2k4APBBAGRkKV1PP8O/9BDVf/BfH/wDH65eiolTjLVmVTCxlLmTa9LfqmdR5/h3/AKCGq/8Agvj/APj9Hn+Hf+ghqv8A4L4//j9cvRS9lEj6n/ff4f5HUef4d/6CGq/+C+P/AOP0ef4d/wCghqv/AIL4/wD4/XL0UeyiH1P++/w/yOo8/wAO/wDQQ1X/AMF8f/x+jz/Dv/QQ1X/wXx//AB+uXoo9lEPqf99/h/kdR5/h3/oIar/4L4//AI/R5/h3/oIar/4L4/8A4/XL0UeyiH1P++/w/wAjqPP8O/8AQQ1X/wAF8f8A8fqhqWsQtA9npscsVq+POklYGS4weM44VcgNsBPPVmwuMaimqcU7lQwsYtSk27d7fol+IUUUVZ1HV/F//koms/8AbH/0SlFHxf8A+Siaz/2x/wDRKUVktjhyr/caH+CP5Ik+EoX/AIWPpPJzmft/0xeuQrrvhJ/yUjSfrP8A+iXrkaqO7FT/AN+qf4IfnUCiit7wd4ck8VeIbPTVDiF23zuufkiHLHODg9hkYyQO9W3Y6q1WFGnKrN2SV2dz4Ugs/APhH/hKbyCKTXr7K6dDOSMJwNwXGRwSxPdSoBG7nz1PMu55Li4d5HdizO5yzsTkkk9a6b4h6/H4g8RG3sii6Xp6/ZbVIsCMKvVlAJXBI4IxlQvpWCqhFCjoKdOPVnnZbRkovE1vjqavyX2Y/Jb+bYkjiNCx/wD11mu7SMWY81PePlwgPA6/Wq1RUld2PapxsrhRRRWZoFFFFABRRRQAUUUUAKrFSCDgitGGUSpnjd3FZtTWr7JQM8NxWlOVnYznG6JrmH+NR9a9IIt/iZ4Ll3ojeLNFh/dlWYy3MK45IwS5PIxz8+DkB8HgSMjB6Vc8La9J4S8R2l+pcwo22ZF/jiPDDGRk9xnjIBrSpG+qPIzHDSrU1UpfxIax/Vej2ZytFdj8SvDcegeInmswh0rUV+1Wrx/6vDclVIAXAJ4AzhSvrXHVKd1c68NiIYmjGtDaSv8A16BRRXo3we+CviX41a7Pp2grDDbWiiS8v7klYbZTnGcAkscHCjrg9ACQN21Z0HnNFe5a18GPh1YR39tYfG3Rr3WbNHJtn0uaKCR1BOxLjcUbOMAjg14bQncAooooAKK9K134a+H9J+FGi+Mbbx7pd9ruoTLFP4biEf2m0U+Z87YlLYGxeqD74/HzWhO4BRRW74M8J6h478VaT4b0oR/2hqk6wRGVtqKT1Zj6AZJwCeOhoAwqK93+JPwA8NfDs6tpkvxT0qfxbpVuJ59Hm0+aDdmMOEjmJKs5UjA4zkdK8IoTvsAUV1nw1+Hmr/FPxjp/hfRBEL28LEyzEiOJFBZnYgE4AHbknA717I37N3gRvEs/hWL426OPFFvKbeSzuNKliiEwODGJy+wtnjA5zxjNJySCx830UUUwCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA634vBf+FiazknP7nt/wBMUopvxf8A+Siaz/2x/wDRKUVktjhyr/caH+CP5If8JP8AkpGk/Wf/ANEvXI113wk/5KRpP1n/APRL1yNVHdip/wC/VP8ABD86gV6v8OHTw74G8UeJlb/Sx/okLLErNE2Bg5PYtIhI/wBjv0ryivU/F4/sj4ZeDtK/1v2rde+b93bkFtuOc/6/Gc/w9OeHLWyObN17VUsL/wA/JK/+GPvP8rf57Hn9omSzkdOBVuo4F2xL055qSuhbHqsgkgjeTLMQzdqT7HH6t+dR3rfMi9wM11Xwt1Tw7YePvD1x4xWV/DkF2kl15cSy8Dld6EHfHuC7wASU3AAnFYylFN3RrGMmlZn0L8Ef2QdL8ceC4PEni3UdWs/7S/eWVrZbYnWEEgPIZI2zv4ZdoxtwcndhfSv+GGPh3/0GfFP/AIFW/wD8Yr6O0fVrPX9IsNW06bztP1CCO5t5dpXfG6hlbDAEZBBwQDV2vEniKjk3ex60aEEkrXPmT/hhj4d/9BnxT/4FW/8A8Yo/4YY+Hf8A0GfFP/gVb/8Axivpuip9vU7lexh2PmT/AIYY+Hf/AEGfFP8A4FW//wAYo/4YY+Hf/QZ8U/8AgVb/APxivpuij29TuHsYdjxr4e/sufDrwD/aOdN/t/7b5f8AyMEFvd+Rs3f6v90Nu7dz67V9K7C7+FXw1srSe5l8AeGmjgjaRhDoUMrkAZO1FjLMeOAoJPQAmu2XAYZ6VJuT2/KumlWk46yXzOWtSipaJ/I/Mr9o/VPAHiTxxp938PYbGHRU02OKVbCwNnGZxLKWJQouTtKfNjpgZ4rx9baNZFwzbhzivqH9p34jfCPxh4Rtz4EOlyeJpdWW5u7i30h7aeSIxy72aVol3ZdkJBJJPPbNfLFo377nJLA16cXHRWOFqVm7l6q92mUDY5H8qsU113oy8cjvW7Mkd5qbp4m+Ddvdyt/pehTrDvaJcsuQoRSOg2yR5Pcpz615PXqnwjH9pDxLoP8Aq/7SsD+/6+XjKfd7/wCtz1H3ffjyuueOjaPKyxexrYjDLZS5l6TV7femFfb37JQOpfs5/FvStF+bxO63WxIv9YQ9mFhx35dZAPeviGuq+H/xH8S/DDXl1rwvqclje7fLkAAaOZM5KOh4Ycd+nUYPNOSuj2E7HLMpVirAhgcEHtX3f8D9F8N/D79mOHx1Hrln4b13VZ3Fx4km0g6nJZgXDRLGsQ5AIQdeMvkg8V4BrP7UPiDWIr5h4Q8C2ep30bxz6ra6Kq3b7gQzeYzH5iCecVz3w0+Pvi74X6Te6Jp/9nal4evSWm0nV7b7RbMxABO3IIzgZAOD3FTJOSGtD3L40eOvhd498J+Fns/FVn4g+JOn6hbrJqdtoc+ntfRGTDB1ZNowCp+91U4wGIrsf2yPjB4i+GnjvRbXwsbOw1C80ndc6i1nFNO8RlkCxAyKwVQQx4AJLdeBXy14x+OWteMLGy04aH4Y0XS7S7jvls9E0tLWN5UDBSxBLHAZhjOOaqfGD4ya78bNfsta1+0022urO1FoiafG6IUDs+SHdjnLnv6cUlDVBc+hPiWpf9hj4cKoJY6jEAB35uq9H0WTxx8K38DaB48+Nen2Et4tvbWvhuPwyl6JowVjEJmjUMOybz35ycV8d658b/EPiD4UaJ8Nrmz0tND0eZZ4J4o5Bcsw8zG5i5Uj963RR0Fdfc/tcePb6w0iO9tPDt5qmlbRb6zcacHvkAxkCQthdwGCUCsfUHmjkYXNH9tXwjpHhL4zBdGsobKHUtNhvpYYECJ5peRGIUcDPlgnHck96ufsXfD7TfFfj7UfEWpNcSDwnAl/b2tu5V5pyx2Hg5IG0/L3JUHjIPk/xd+Lut/GjxNb+INftdOtryC0SyVNPjdIyiu7AkO7HOZD39OKzfh38SfEfws8RJrvhm++y3oQxSKyh45oyQSjqeCMgH1BAIINVZ8tg6n2HrfhTwx+2loen+K/D4h0XxtpdxFa6vZTSZ3WxfqxABOFyyNjnDIegI+bf2ldD8GeF/ivqWg+BrFLTStLijt51S4knDXIyZPmkZjkbghGcAofeupt/wBsbxvpt5JeaNoHg3Rrq4lWW8l07SPLe9IOSJWLktnnJBB54Iryf4keP5/iZ4nuPEV5o2kaXf3QzcLpUUkcc795GV3f5j3IxnGSM5JUU0/IGzV+CnxF1L4VeP7LxTp2mtqS2UcgurUZG+Blw/zAHbjIO7GAQM19U+HdH+Af7VWvarDYaJrHh7xncxSX08iNs8xtw3yABnib5nBOVUnJPvXx78PPiFrXww8TQ+IdBe3W/ijeLFxEJEZHGGBU+or1OL9rjxdpsN6dB8NeCvD2o3qFJtS0jRxDcsD6sXIPPPINEotu6BM9t/Zu+HXh7wL4I+KHibUb2xj1/wAO6peaUusz6eb1dPjgVczpAOTksWOOyjnGawvit8SPhb45+D+q6brnj+z8W+PbYmfS9Wi8Nz6dMSCpERwm3BG4EkgEEcZXNfO/w1+OHjH4V6jqN3ol9HNFqnN9aX8fnw3R55cE5zyeQQTk5rR8YfHzWfFnh++0KDw14Q0DTtQ2i6XQ9IS3eYK4cAuSzfeUHgilyu9wvofSer+MbrwL+xb8PdY0+2s5dUju0S0murdJ1tZC9wfNVHBUsFDAZBxuz1Aqn+0Zolx8Svhv8EPElvZ2v/CbeI5LS1NxHGIxLJPErAN/shxkZztBPvXzZrvxu8QeIPhRovw2ubPS00LSJlngniikFyzDzOGYuVI/et0UdBVzxD+0H4s8Q+EfBfhtotOsoPB0kEunXdnHItwHhTajMzOykjAPCjn8qFBrULn2z4c1TxNofxI0bwb4++M+na7q9+m6XwwvhZCk6lGOPtCKAnALZYDgcjmvKPh94Y03wd+3dquj6RbR2unQpNLFBGMJH5lmshVR2ALnAHQcV5VP+2L48uNY0zWm0nwqNZsgEe/XTMXF1GM/u5JN+4ISclUKA/TIrlrb9obxPafGO6+KaWGjnxBcpsa3aGX7KB5Kw8L5m77qg/e6/lSUHqF0fXXwr+IN14q/aP8AiZ8PrzTdK/4RFReyNYiyj/ezJOivJI+N0hfe5IYkcgDAFcd8DdA0v4b/AA2+NPjvR9OtrnxJoGo39jYPOnmG1ihRShGeQMuS3qEAzXzj4Q+P/iXwX8T9e+IVhY6RLrWt+f58NxFI1uvmyLI21RIGGCoxljx612vwA+JWvWviXxjd2vjHwpoM2tyG4m03xLHJ/Zt8zs5f5wcxld2OT8wbBzihxaC57V4F8aal4/8A2RfipresWtqmqyPdxz3VtbJALwiGIiRlQBd2G2kgDIQZ5zXwXX3H8Qvi74f8GfAjxH4Rl8T+GNc8T6+zxw2PhOJV03ToX2hlQqMBQFZsn5mZ/QZHw5VQ6gwoooqxBRRRQAUUUUAFFFFAHV/F/wD5KJrP/bH/ANEpRR8X/wDkoms/9sf/AESlFZLY4cq/3Gh/gj+SJPhK7H4j6SNxxmfjP/TF65Cuu+En/JSNJ+s//ol65GqjuxU/9+qf4IfnUCvVfjMPsWq6NpUHyWFlYr5EXXZlip5PJ4jUcnt9a8qr1X44f8jZZ/8AXin/AKMkqvtI58XrmOGXlP8AKP8Am/vOHUbVAHQDFVL1vmVfQZq5VC7bMxHoMVpV+E9en8RBRRRXMdB+n0niy4+E37Nmk63dWMq6jo/h6yiFrPEQUuTFHEiyISpAEjLuGQQA2OeK8v8ACX7P+pfHDw1pfi/4peMdeur3UoFubOxtGhiitI3HDAYdP3kawvhVQg53ZPT6mvdRtdOjD3U6RKegPU/QdT1qta+IdMvJhFDdoZD0DArntgZAyfavHVRpPlWvc9dYac1zcrcV5aHzRp154r/Z2+K3g7wdd+Ib/X/h94lkNpZLeRo81pIWWKOJG37gI82+T8qFZH2x7hx9VUUVM581nbUiMeXQK+aPiT4o8Z/Ej41P8KfCGvXXhzTNPsRc6tqVtEvnhiqSKyt5ivsy8CYQo2ZJN25RX0vRRCXK72CUeZWPmK8/ZNHga0n1v4Z+LvEen+KbSNpIUmlhdLwKN627ALGMPIsed5ZOOVPb0X9nT4nXnxV+Glrqup86xZTvYXsqxCNJpECsHUAnqjoTwo3bsADFekXuuafp0gjuLpEk/ugFiPqBnHXvT7HVrLUt32W4SRl6ryG7c4POOetVKo5RtLXzLWGnFc6i1H00Px0vLO4067uLO8t5be7t5GimgmQo8bqcMrKeQQQQQelQ12nxg/5K149/7D1//wClD1xdeundXPIas7E9o2JgPUYq/WbA22ZD74rSrppPQwqrU6b4TXMtr48s4Yn2x3CSxSDAO5QhbHt8yKePSuP8SWkOn+ItXtLdNlvb3c0UaZJ2qrkAZPJ4FdV8Lv8AkoWl/Wb/ANFPXN+Mf+Ru1/8A6/7j/wBGNUP4zx4aZrNLrTj/AOlSMWiituDwte3Hha48RRvAbO3uPs8ke4+aOF+fGMbcugznOWHFUesYlFdHqvgjV9Ln0m28n7Xd6nbC6it7RWkkUEkFWXH3gVOQM4rJj0fUZtQOnR2F0+oAlTarCxlyOo2Yzn8KAKVFaEGg6rdXk9nBpl7LeQAmWBIHaSMDruUDI/Gr174Ylt/Fcfh+GdJJ5JooElkUou59uMgZIALe9AGDRXTp4St31vTdKj8QafczXl5HZuLWKctDuYKWIkjQEAnoD/jWOmi6hPJGttZXU4mlaGIxws3muvVVwOSAQcD1oC5QorUi8M63PdTWsWj6hJdQMEkhS2cujEEgFcZBIBPPoajs9B1XUJpYbTTL24mhcRyJDAzsjc/KQBwflbj/AGT6UAZ9FXW0fUV05dRawuhp7NtF0YW8on034xn8as/8I1qkU8MN3Y3VmZ4nmjNxbSDzFRCxIAUkjA6gYHUkDJABk0UVpaJodzrt1JDbtFGkMbTTTzPtjhjGMsx9MkDjJJIABJoAzaK6K18JG/1e10+z1jTLgXCyP9pjaTy0CIXbcpQOOAcfLz271Ja+EIb6edLbxFpEsNtbNdT3AS5CRKrKuCDCGJJcdAe/SiwXOZorom8GXo1m20xLi0kN1bNdwXCO3lSxBGfIyu4fcYYIByOcVAvhW/bwu3iIGH7Es/keXuPm9vn24xsyQuc9TigLmJRRRSGFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAdb8XnYfETWQGIH7nv/wBMUopvxf8A+Siaz/2x/wDRKUVktjhyr/caH+CP5If8JP8AkpGk/Wf/ANEvXI11/wAJQv8AwsfSeTnM/b/pi9chVR3Yqf8Av1T/AAQ/OoFeqfFc/wBo2fhPXJeLvUbAeai/cXAV/lHXrK3UnoPx8rr1K4P9v/BuyuPvXGh3Zikln5bYTgKh5OMSRDBx9z2FN6NM58x/d4jDV+ik4v8A7eTX5pHEoSUUnqQKz523TOT64q3atmLHdTVFm3MWPUnNXVeiPZprViUUV0/w31az0D4ieEdW1GbydP0/VrS5uJdpbZGkyMzYUEnABOACa527I2W5+m/jHT7tdRku2R3tWVQrjJCYAGD6c8/j9a5+1tJ72YRW8TyyHso6dsn0HPWvWrO8t9RtLe8s7iK4tLiNZYZ4XDpIjDKsrDgggggjrU1eLzWPrKObSp0lDlvYhs45IbS3jmffKkaq7ZzuYDk5NTV5p8dNA17XfA4Ph3U9Zsbywu47qVdGmaK5uIQGSRFZTk4D+ZtAYsYgoGWBHzPDY65cQxzQ/Evx1JFIodHTXXKsp5BBHUUe7a7Zy4bBVsW5Oklp52PuOivh/wDsvxB/0Ufx5/4O5P8ACvdv2ddE1600nWdY1bxBr2q6fqckI04axdtcExIrEzxljwkjSYAwMiIOCyuuD3WtGPFZfXwsVKqkr+Zo6np93YXTrdo+9mJ8w5Ik9SD36/rzV3w1p93c6nbTQI6xRSBnl5CgDGRn1IOMe/pXplFHMdUs3lKnycuv9dD8lfjB/wAla8e/9h6//wDSh64uvVP2kfEWl+K/jX4r1XRb2K+02WSCOO5hOUkMcEcbFT/ENyMAw4OMgkEGvK69mHwo+Tn8TFVtrBh1BzWrWTWhJJ/o+44yy/zropPcwqrY7T4NWUd54z8+RnD2ltJMm3GCxwnPthz+OK891K/k1TUby+mVFmupnmcICFDMxJxntzXpPgU/2H4F8Xa+fldoxZwSw8TRORjIPGBukjPB/h6cCvLKlaybPGwf7zHYir0XLBfJXf8A6UgrtvD3iyy0Pw9a208Avs3tw1zYsSglheKNR8+CB8yZHXlRxXE0VZ61j0pvF9jq+nLb3mpfZr++02aCe7MblYZWvnnKttBO1kIBKg43AeoqGXxFpdzdahY/2k0az6RBpy6q8T4d42RiWABfYwQp0zgLkdRXndFFxWPStQ8Q6Tqun3GkprRtZIlsv+JlJFLi78hHVgQoLjBcbcjogzt4xman4g0+5+KUOtpdvJpq6hBO1w6MGKKU3MVxnPB4riKKLjsejXGt2kfirRNSm1vQbmzt9UiuHGnaY1vLHGJAxZyLeMsAB0yxz2qK48S2N9rFlqdvqEVipgks5LGeCRoIEKFTt2DIjcMScfOGJPP3j59RRcLHqSnSLnw74lhstZ+x2jyadG05E7QeYFnJRcgyeXxkZBOQO3NZOv8AiqzvrPxRHa3cu6/nsFUsrK1ykMUivI3puba2Cc5b2NcQtzMkElussiwSsrvGGIVmXO0kdCRuOPTJ9aiouKx6fe+MdKm0zz7U6dDcSadFYPE0V29yu1FU4HmCDbuXcDwf9nOSWyeINEXUE1CbUoZb+4F6072kc6xMZLZ1Uukg4kLsB8nygGvMqKLhY1dDu/sh1H/iYfYvNs5Yv9T5nn5x+6/2d397tir3hXU7K2i1nTdQla3tdWtRB9pVC/kusiSKxA5K5TBxzg55xiucooHY7TwvLpPhnxZp9wdbtbiFY51kuFtpTDGWidUyrJuYZYZGzH15rStvEcOkTancPqugXs82myQQLY6SI4/MMsRCvG1uitkBiCQQMdRxXnNFFwsehx+KtNu/EOja3c3Kwzf2fPbXcCRMEhkEMkabFAwFfcp2rwCW4AxV6PxV4VQxaKUvPsA0v+zGvxP+43N+9MvkeVvOJufvZwo47V5dRRcVgooopFBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAHV/F//AJKJrP8A2x/9EpRTvi8F/wCFiazknP7nt/0xSislscOVf7jQ/wAEfyQvwk/5KRpP1n/9EvXI113wk/5KRpP1n/8ARL1yNVHdip/79U/wQ/OoFen/AAe1OG4m1bwveSSrb6xAwjKuflYKwYKMEAlCTk/88wOeK8wqezu5tPu7e7t32XFvIssb4B2spyDg8HkVUldWKzDCLF4eVG9m9n2a1T+8vTQz6Zd3VpOvlzwM0Ui5B2upIIyODyKpV6R8RrBdesNO8aadA/2XUIVW7C5IhlX5eSe2RsyABlB/eFeb1EpXsa5biliqCqtWltJdpLRr5P8ADUKKlt4fOcgttRVLM2M4A9qf5dn/AM/v/kI1J3tpH1B+zJ+03Z+ANPTwd4xfyvDkXmSWOoRQl2tGYl2jkVAWdGYsQwBZWbBypBT7ws7y31G0t7yzuIri0uI1lhnhcOkiMMqysOCCCCCOtfjf5dn/AM/v/kI16d8NPj14t+FWyDRvEX2jSVz/AMSvUIXmtRneflXIaP5nLHy2Xccbs9K5K2F53zR3OiliVHSWx+pFeb+JPgj4a8QXtzf28upaPqF1KZp59OuMLITnd+5lDxKWb5iyoGLZJPzNmL4Q/F1/i3oVlq1n4Yvbe1nklimuY7y1mgt3TPyt+8WYEjacGIH5wfukMfUDE4ONp/KuGVOcd0d1LEJPmpys/J2Z5RpXwA8L2kvmandavroVlZItQuFSJcdVaOBI1lVuAVlDjAxgAtn1SneW5/hP5VxXxJ8fS/DjQtS1ifw/e3mn2Nobh7tbq1ht1fkLGxklD5LbR8qOTvAUM3y0KnOWiQ6uI5nzVJ3fm7nZ18bftJ/tT6Xd6JfeDfAt3Fftfxy2upaoEzFHEco8UW4YcsM5kGVCkbSS25PGvil+014t+Jv2my/tn+xdAl3J/Z2nI6eZGd42yy/ekyj7WHCNtB2A14v5dn/z+/8AkI120cJyvmmcNXFJ6RK9FWPLs/8An9/8hGmzwLGsbxyeZFIDhsY6Hniuw5rpkNTPIWijXPQVDXefDDQFutUfXb9XTR9GVrmSYqSpdBuAGDkkff4B+6AR8wqoy5Tkx+JhhaEq0+n4vol5t6Gn8Q7n/hGvBXh7wkplS7ZBdXamT7uSx2HA2sDIWxzx5Y65BryitTxHrc3iPXL7VJxte5k3BODsUcKuQBnCgDOOcZrLq4qyOPLcLLDUFGfxyblL/E9X/l8gooqxbW3m/vJMiIHGR1Y+g/x7fkDR3leitLFuOBaxkDuzNk/XBFL+4/59Iv8Avp//AIqnyi5jMorT/cf8+kX/AH0//wAVR+4/59Iv++n/APiqOUOYzKK0/wBx/wA+kX/fT/8AxVH7j/n0i/76f/4qjlDmMyitP9x/z6Rf99P/APFUfuP+fSL/AL6f/wCKo5Q5jMorT/cf8+kX/fT/APxVH7j/AJ9Iv++n/wDiqOUOYzKK0/3H/PpF/wB9P/8AFUfuP+fSL/vp/wD4qjlDmMyitP8Acf8APpF/30//AMVR+4/59Iv++n/+Ko5Q5jMorT/cf8+kX/fT/wDxVH7j/n0i/wC+n/8AiqOUOYzKK0/3H/PpF/30/wD8VR+4/wCfSL/vp/8A4qjlDmMyitP9x/z6Rf8AfT//ABVH7j/n0i/76f8A+Ko5Q5jMorT/AHH/AD6Rf99P/wDFUfuP+fSL/vp//iqOUOYzKK0/3H/PpF/30/8A8VR+4/59Iv8Avp//AIqjlDmMyitP9x/z6Rf99P8A/FUfuP8An0i/76f/AOKo5Q5jMorT/cf8+kX/AH0//wAVVa4tlVTJDuMY+8rHJX/Ee/4emRoLlWiiipKOr+L/APyUTWf+2P8A6JSij4v/APJRNZ/7Y/8AolKKyWxw5V/uND/BH8kP+En/ACUjSfrP/wCiXrka6/4Sux+I+kjccZn4z/0xeuQqo7sVP/fqn+CH51AoooqzvNe28QX0OhT6GkuNPmnW5ZBwSwGMZHUH5Tg55RSMc5oVHF3qeGIzSpGM5Y44GcVnLcqlTjBNxVru79SSZvs9hsP37gg49FHQ/iazqtX8wmuW248uP5Ewc8D3qrUMYUUUUgPon9kb41f8K18dLomtap9m8Ia5lJvtEu2C0ucDy5z8p252iNjlRhgzHEYx+l9fiPX6Ufsh/HGT4meEZPDut3U0/irQI18y4uZkaS+tyxCSAcMSnyo5IPJRixZyAMaPpCvgf9tr41f21rEHw+0DVN+mafl9Y+zS5Sa5DfLA/wAvPlbdxAYjc+CA0XH0x+0h8ZIvg58Pp7y3bd4h1TfZ6XGrx7o5ShzcFXzuSPgn5WBZkU4DZH5XXt7c6leXF5eXE1zeXMjSzTzOXkldjlmZjySSSSTySaEDIKKKKBBWhZN59tLbfxg+anuQOR+VZ9S207W08cq9VOceo7imgJa0IvEF9aaJe6NFLixvZEklQ88pzx2GTtyRydi844Na7iEM7KnMZ+ZT2INVZfuj61S3CrThUjaSvs/mndEVFFFakBWkOLS1A4BQsfc7mGfyA/Ks2tP/AJdbT/rmf/Q2qokyGUVa0zTrjV9Ss9Ps4zJd3kyQRIP4nYhVH5kV7b8Rfh5Y28mhTXOk3Ph3RdP1IaBdX0li0P2mFQpS85A3s+JiW56L7U7knhFFelXHhGxtrfxBPa2t3bWqaM1zCZ7i2vkkZbqGMlJ0TbjDnO0KyngnBIOp4X8IeG/7d8HXFvbXerWcl/YJeTi7gkgZpSu6OSDYXiAclfn3BwpAxkEFwPIaK9R0fwZoHiH+3tYiguLbS7G6itI7G41u0tpHkcSMW+0TIiBQIzhAhY564BNTv4C8I6WbcXl9qGorea3JpcE2m3UHliIRwOJCwV1ZlM+CqnBI4ZcclwPJ6K1pPD903id/D9qPPvTemxjAGPMffsH5mvcfE/w+htPEPgyceGJNP07T9eg0Cf7TYmJNRiVkKXDBlAk8zE2488BR6UXA+eKK9E+H1jaXHxWNtPDZG1Rr8hLqASwJsgmKloyrAhSAcbT06GtfVl0HXdI1FrWfTbrV9N0aWe8vNL01ba2mY3cCxhY3iTawV2y6IhOQMkbslwPJKK9Q8W+C/C+kTeKYNN/th38NX0cM7XNxFi6iaQowXEf7tgQAGO4Hk7R0q54o8OaFqPxR8SWOm+HL4afYSz/aI49XtrOGIiQKHEjwCOKPkKEOeSMN2JcDyOivVNW+H/h7wzF4hvNTfUbq2sjprWkNndwZkW6hkkKtMquh27MB0BDYOB8wIwPhlY2UmsX2p6qkB0rSrOSed54fOWJnxDC/ldJNsssZKnggHPpRcDiqK7Dxv4X1TSimrajHpsEd9MY7cWChIrlVRCZ4lUbfLbevIwNxI2jBA7zSPCWj+KPAXhK0e3tbO8t45dUvL5I1WWWzW6ljuNzdXKKI2UHoA1FwPE6K9Z+J2i6Vew6n4isrGLTSsWiGKys0WOBBdWUksnygdd0a857nOc8b3hTw3peja7qWhzwS3mmL4l0KJop2UmQOJ+GypBXLcjHIyOM5ouB4RRXoLaHpus6V4ll0a3eyWLUbK3hi1C6t2ALi43EztHGEXKDgFR/e3YBGt4H0tNH8P+M2u7vw1a39nPYxpfahbRanboH84sqFIp1JbC8qP4cEjFFwPKKK9qsNN0D+w7/UtYsk1Q3Gg3F2H05ILJFZdU8rdF/o+VyMYLLlVLLgAgLyum+CdN1HUPBsQkvEh12xubuYeYpaMxzXKKFO3ptgTOR1J6ZABcZ5/RXX+M9G0Lw/b6Ta2K6jJqdzYWd9cTTzJ5KedAsjRqgTJ5YEMW4HGD96uQoEFFFFMAqSHnzQeQYnyPXCkj9QD+FR1LB1k/65Sf8AoBoQGVRRRWZodX8X/wDkoms/9sf/AESlFO+LzsPiJrIDED9z3/6YpRWS2OHKv9xof4I/khfhJ/yUjSfrP/6JeuRrrvhJ/wAlI0n6z/8Aol65GqjuxU/9+qf4IfnUCiiirO8li+6frVyFvs9tNcHrjy09dx757YFUVk2jGK0rq2WaK3jS6tgsSnO6Tncev4Vm073NOZWsZFFXv7N/6e7T/v5/9aj+zf8Ap7tP+/n/ANap5WTco0Ve/s3/AKe7T/v5/wDWrTtPBGtahbpcWlnLcW752ywxO6tg4OCFweQRSsyZ1IU1ebSXmc9XYfC/4i6t8K/GumeJdJmmDW0ii5t45NgvLcsDJAxIIwwHUg7SAw5UEV/+FeeI/wDoF3X/AIDyf/E1jf2W3/Pza/8Afz/61FmxU61Op8Ek/Rnofx8+Ml78aPHVxq267h0G2/c6XYXDqfs8WAGYheA7ldzfeI4XcwRa8tq//Zbf8/Nr/wB/P/rVrQ+AtfuIo5odPuJIpFDI6QyFWB5BBC8iizQTqwp6zkl6nNUV0s3gLXreGSabT7iOGNS7u8MgVVAySSV4ArI/s3/p7tP+/n/1qLMIVYVNYST9CjRV7+zf+nu0/wC/n/1qP7N/6e7T/v5/9anysu5IrfaLBG/jtztbPUqenP6Yqq/3DV+ytVt5WL3VsY3Qo22TnB9Kz5G2s6cHBIypyDVJMrmVrEVFFFaGYVp/8utp/wBcz/6G1ZlX7aUTxJAf9amQn+0Dzt+ucn3z9AaiSy/o2sXvh/U7fUtOm8i+tyWil2qxQkEZAIIzzwex5HNWNH8TaroEV1Fp12YI7sxmVdisGKNuU/MDgg+nYkHgkHKZSpKsCCOCD2pKok6O/wDHWvaik0U13EkE1sbNoLe1hhiERkWQhURQqkuikkAE45NK3j7xAbS3tVvliSCSKUSQ28UcrtGcxl5FUPJtPI3E4rm6KQHTJ4/12K/vL1JbJXvVUXEI062+zzbeVZofL8ssCSd23PJ55qnceLdYuvI828LfZ7xr+P8Adp8szBAWHHTESDb0G3gdaxaKANWz8Sanp+vf27bXPl6t5rzi48tSRI2csARgHkkccHkYwKfofinVvDfm/wBmXfkCWSGVwY0cF4pBJG2GBwQwz9CQeCQceigDRsNe1DTNVfVLW48u/cSgy7FOfMVlfgjHKuw6cZ4qKx1W702K+itZvLjv4Ps1wNoO+Per7eRx8yKcjB4+tU6KANi98VavqMusy3N35j61IJb0+Wg85g+8HgfL83Py4rSPxG8RNfSXr3No9xNB9nnZ9Pt2Fym4N+9Ux4lbKqdzhmyBzXK0UAb+seNtd1+O7j1G+89Ls25lHlIu7yEZIvuqMbVdhx1zznAqnofiDUfDd491ptwIZZI2hkDRrIksZ6o6OCrKcDhgRwKzKKAN7XfGeteJbS3tNTuo5ra1cvBElvFGsGQAVQIo2IcA7FwuecZ5rOu9WvL6y0+yuJt9tp6PHbptA8tWcuwyBk5Ziec9apUUAdLbeP8AxBaSySJeRP5ltBaMk1rDLGY4ECRfI6FdyKAA2N3U5yTUdx468Q3V5e3kupSNd3t1BezTBFDNNDu8t8gcEbm6YznnNc9RQBt6n4t1XVo7+O4ktliv5IpbiO3tIYFkeMOEbEaKAf3j5I655zxVG31e8tdMvdMim22V68ck8e0He0e7Yc4yMb26HnPNUqKAN/TvGut6ULRbe6iMdpbPZxxTW0UsZheQyMjI6lXBdi3zA849BVrS/iN4k0a1S2sb6KKOMyeUfskLPEJM71RihZEbJyqkLyeK5aigC5qWq3erzQzXs3myQwRWyHaFxHGgRF4A6KoGepxzmqdFFMAooooAKlg6yf8AXKT/ANANRU6Z/siOrAid1KhT1QHqT9RkY98+mQZm0UUVmWdX8X/+Siaz/wBsf/RKUUfF/wD5KJrP/bH/ANEpRWS2OHKv9xof4I/kiT4Shf8AhY+k8nOZ+3/TF65Cuu+En/JSNJ+s/wD6JeuRqo7sVP8A36p/gh+dQKKKKs7wooooAKKKKACp7S8udPuEuLS4lt7hM7ZYXKMuRg4I5HBIqCigTSkrPY660+J/i2yt0gi1mVkTODNGkrcnPLMpJ69zXQ/8L18Rf8+Wlf8AfqT/AOOV5hRScIvoedVyfAVXedGN/S35Hp//AAvXxF/z5aV/36k/+OViXnxY8W3n2hf7U8mKbcNkMKLsB7K2Nwx2Oc++a4uilyR7Cp5NgKbvGjH7r/mWr/Ur3VJlmvry4uplXYHnkZ2C5JxknpyfzqrRRVHoxioq0VZBRRRQUFFFFABRRRQAUUUUAWFvrpFCrczBQMABzgCl/tC7/wCfqf8A7+Gq1FO7FYs/2hd/8/U//fw0f2hd/wDP1P8A9/DVaii7CxZ/tC7/AOfqf/v4aP7Qu/8An6n/AO/hqtRRdhYs/wBoXf8Az9T/APfw0f2hd/8AP1P/AN/DVaii7CxZ/tC7/wCfqf8A7+Gj+0Lv/n6n/wC/hqtRRdhYs/2hd/8AP1P/AN/DR/aF3/z9T/8Afw1WoouwsWf7Qu/+fqf/AL+Gj+0Lv/n6n/7+Gq1FF2Fiz/aF3/z9T/8Afw0f2hd/8/U//fw1WoouwsWf7Qu/+fqf/v4aP7Qu/wDn6n/7+Gq1FF2Fiz/aF3/z9T/9/DR/aF3/AM/U/wD38NVqKLsLFn+0Lv8A5+p/+/ho/tC7/wCfqf8A7+Gq1FF2Fiz/AGhd/wDP1P8A9/DR/aF3/wA/U/8A38NVqKLsLFn+0Lv/AJ+p/wDv4aP7Qu/+fqf/AL+Gq1FF2Fiz/aF3/wA/U/8A38NVqKKLgFFFFIZ1vxeC/wDCxNZyTn9z2/6YpRTfi/8A8lE1n/tj/wCiUorJbHDlX+40P8EfyRk+DNbXw54w0zUpCiwwz7ZWdSwWNsq5wOchWJHuOh6U7xToreHfEOpaYQ4W3mIj3sGYxnlCSOMlSD+Pauek/wBY/wBTXa6dr+ka/pFho3iEvZzWKsltrKK0rLHnIikj6svLAEH5flAGNxLTs7hXjKjWWJim01aSW9ldppbu13dK7d9NrPlKK7QfC7Xrr59KbT9Xtxw1xYXkbRq3dSWIOcYPToRR/wAKl8Y/9Af/AMmYf/i6vmXcn+1cF1rRXrJJ/czi6K7T/hUvjH/oD/8AkzD/APF0f8Kl8Y/9Af8A8mYf/i6OaPcP7VwP/P8Ah/4Ev8zi6K7T/hUvjH/oD/8AkzD/APF0f8Kl8Y/9Af8A8mYf/i6OaPcP7VwP/P8Ah/4Ev8zi6K7T/hUvjH/oD/8AkzD/APF0f8Kl8Y/9Af8A8mYf/i6OaPcP7VwP/P8Ah/4Ev8zi6K7T/hUvjH/oD/8AkzD/APF0f8Kl8Y/9Af8A8mYf/i6OaPcP7VwP/P8Ah/4Ev8zi6K7T/hUvjH/oD/8AkzD/APF0f8Kl8Y/9Af8A8mYf/i6OaPcP7VwP/P8Ah/4Ev8zi6K7T/hUvjH/oD/8AkzD/APF0f8Kl8Y/9Af8A8mYf/i6OaPcP7VwP/P8Ah/4Ev8zi6K7T/hUvjH/oD/8AkzD/APF0f8Kl8Y/9Af8A8mYf/i6OaPcP7VwP/P8Ah/4Ev8zi6K7T/hUvjH/oD/8AkzD/APF0f8Kl8Y/9Af8A8mYf/i6OaPcP7VwP/P8Ah/4Ev8zi6K7T/hUvjH/oD/8AkzD/APF0f8Kl8Y/9Af8A8mYf/i6OaPcP7VwP/P8Ah/4Ev8zi6K7T/hUvjH/oD/8AkzD/APF0f8Kl8Y/9Af8A8mYf/i6OaPcP7VwP/P8Ah/4Ev8zi6K7T/hUvjH/oD/8AkzD/APF0f8Kl8Y/9Af8A8mYf/i6OaPcP7VwP/P8Ah/4Ev8zi6K7T/hUvjH/oD/8AkzD/APF0f8Kl8Y/9Af8A8mYf/i6OaPcP7VwP/P8Ah/4Ev8zi6K7T/hUvjH/oD/8AkzD/APF0f8Kl8Y/9Af8A8mYf/i6OaPcP7VwP/P8Ah/4Ev8zi6K7T/hUvjH/oD/8AkzD/APF0f8Kl8Y/9Af8A8mYf/i6OaPcP7VwP/P8Ah/4Ev8zi6K7T/hUvjH/oD/8AkzD/APF0f8Kl8Y/9Af8A8mYf/i6OaPcP7VwP/P8Ah/4Ev8zi6K7T/hUvjH/oD/8AkzD/APF0f8Kl8Y/9Af8A8mYf/i6OaPcP7VwP/P8Ah/4Ev8zi6K7T/hUvjH/oD/8AkzD/APF0f8Kl8Y/9Af8A8mYf/i6OaPcP7VwP/P8Ah/4Ev8zi6K7T/hUvjH/oD/8AkzD/APF0f8Kl8Y/9Af8A8mYf/i6OaPcP7VwP/P8Ah/4Ev8zi6K7T/hUvjH/oD/8AkzD/APF0f8Kl8Y/9Af8A8mYf/i6OaPcP7VwP/P8Ah/4Ev8zi6K7T/hUvjH/oD/8AkzD/APF0f8Kl8Y/9Af8A8mYf/i6OaPcP7VwP/P8Ah/4Ev8zi6K7T/hUvjH/oD/8AkzD/APF0f8Kl8Y/9Af8A8mYf/i6OaPcP7VwP/P8Ah/4Ev8zi6K7T/hUvjH/oD/8AkzD/APF0f8Kl8Y/9Af8A8mYf/i6OaPcP7VwP/P8Ah/4Ev8zi6K7T/hUvjH/oD/8AkzD/APF0f8Kl8Y/9Af8A8mYf/i6OaPcP7VwP/P8Ah/4Ev8zi6K7T/hUvjH/oD/8AkzD/APF0f8Kl8Y/9Af8A8mYf/i6OaPcP7VwP/P8Ah/4Ev8zi61/C2it4i8Q6dpgDlbiYCTYwVhGOXIJ4yFBP4d63T8Ltetfn1VtP0i3PC3F/eRrGzdlBUk5xk9OgNVtR1/SNA0i/0bw8XvJr5VS51l1aJmjzkxRx9VXhQST83zAjG0hOS6E1MdGvF08G+eT6rVLzb203te76dWsfxvra+I/FmralGUaGaYrEyKVDRqAqHB5yVUE+56DpRWBRUHfRpRo040obRSS+RJJI4dgGbqe9N8x/77fnRRTNA8x/77fnThI+xjubqO/1oooAb5j/AN9vzo8x/wC+350UUAHmP/fb86dJI4dgGbqe9FFADfMf++350eY/99vzoooAcJH2MdzdR3+tN8x/77fnRRQAeY/99vzo8x/77fnRRQA6SRw7AM3U96b5j/32/OiigA8x/wC+3504SPsY7m6jv9aKKAG+Y/8Afb86PMf++350UUAHmP8A32/OnSSOHYBm6nvRRQA3zH/vt+dHmP8A32/OiigBwkfYx3N1Hf603zH/AL7fnRRQAeY/99vzo8x/77fnRRQA6SRw7AM3U96b5j/32/OiigA8x/77fnThI+xjubqO/wBaKKAG+Y/99vzo8x/77fnRRQAeY/8Afb86dJI4dgGbqe9FFADfMf8Avt+dHmP/AH2/OiigBwkfYx3N1Hf603zH/vt+dFFAB5j/AN9vzo8x/wC+350UUAOkkcOwDN1Pem+Y/wDfb86KKADzH/vt+dOEj7GO5uo7/WiigBvmP/fb86PMf++350UUAHmP/fb86dJI4dgGbqe9FFADfMf++350eY/99vzoooAcJH2MdzdR3+tN8x/77fnRRQAeY/8Afb86KKKAP//Z",
	"tenang": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4lkkcOwDN1Pem+Y/99vzok/1j/U16rcXEPwit7SxsbRB4/C+Ze6hJiVbBXAZYYlI2Fym3c+DjcwDHPy+hSpc95Sdkt3+i8zir13TahBc0pbLbbdt9EtLuz3Whh6Z8IfHmr27T2/h+8RFYoRdOtu2cA8LIykjnrjHX0NXh8DfiFtP/ABImzkf8vsH/AMcrjtT1fUNanW41K/ur2dV2LJczNIwXJOAWJOMk8e5qnW3+zr7Mv/Al/wDIsx5Ma9eeK/7db/HnX5Hef8KM+If/AEAm/wDA2D/45R/woz4h/wDQCb/wNg/+OVwdFF8P/LL/AMCX/wAiHJjf+fkf/AH/APJnef8ACjPiH/0Am/8AA2D/AOOUr/A34hFmxoTYzx/psH/xyuCoovh/5Zf+BL/5EOTG/wDPyP8A4A//AJM7z/hRnxD/AOgE3/gbB/8AHKP+FGfEP/oBN/4Gwf8AxyuDoovh/wCWX/gS/wDkQ5Mb/wA/I/8AgD/+TO9HwN+IW0/8SJs5H/L7B/8AHKT/AIUZ8Q/+gE3/AIGwf/HK4Oii+H/ll/4Ev/kQ5Mb/AM/I/wDgD/8AkzvP+FGfEP8A6ATf+BsH/wAco/4UZ8Q/+gE3/gbB/wDHK4Oii+H/AJZf+BL/AORDkxv/AD8j/wCAP/5M71/gb8QizY0JsZ4/02D/AOOUn/CjPiH/ANAJv/A2D/45XB0UXw/8sv8AwJf/ACIcmN/5+R/8Af8A8md5/wAKM+If/QCb/wADYP8A45Sj4G/ELaf+JE2cj/l9g/8AjlcFRRfD/wAsv/Al/wDIhyY3/n5H/wAAf/yZ3n/CjPiH/wBAJv8AwNg/+OUf8KM+If8A0Am/8DYP/jlcHRRfD/yy/wDAl/8AIhyY3/n5H/wB/wDyZ3n/AAoz4h/9AJv/AANg/wDjlK/wN+IRZsaE2M8f6bB/8crgqKL4f+WX/gS/+RDkxv8Az8j/AOAP/wCTO8/4UZ8Q/wDoBN/4Gwf/AByj/hRnxD/6ATf+BsH/AMcrg6KL4f8All/4Ev8A5EOTG/8APyP/AIA//kzvR8DfiFtP/EibOR/y+wf/AByk/wCFGfEP/oBN/wCBsH/xyuDoovh/5Zf+BL/5EOTG/wDPyP8A4A//AJM7z/hRnxD/AOgE3/gbB/8AHKP+FGfEP/oBN/4Gwf8AxyuDoovh/wCWX/gS/wDkQ5Mb/wA/I/8AgD/+TO9f4G/EIs2NCbGeP9Ng/wDjlJ/woz4h/wDQCb/wNg/+OVwdFF8P/LL/AMCX/wAiHJjf+fkf/AH/APJnef8ACjPiH/0Am/8AA2D/AOOUo+BvxC2n/iRNnI/5fYP/AI5XBUUXw/8ALL/wJf8AyIcmN/5+R/8AAH/8md5/woz4h/8AQCb/AMDYP/jlH/CjPiH/ANAJv/A2D/45XB0UXw/8sv8AwJf/ACIcmN/5+R/8Af8A8md5/wAKM+If/QCb/wADYP8A45Sv8DfiEWbGhNjPH+mwf/HK4Kii+H/ll/4Ev/kQ5Mb/AM/I/wDgD/8AkzvP+FGfEP8A6ATf+BsH/wAco/4UZ8Q/+gE3/gbB/wDHK4Oii+H/AJZf+BL/AORDkxv/AD8j/wCAP/5M70fA34hbT/xImzkf8vsH/wAcpP8AhRnxD/6ATf8AgbB/8crg6KL4f+WX/gS/+RDkxv8Az8j/AOAP/wCTO8/4UZ8Q/wDoBN/4Gwf/AByj/hRnxD/6ATf+BsH/AMcrg6KL4f8All/4Ev8A5EOTG/8APyP/AIA//kzvX+BvxCLNjQmxnj/TYP8A45Sf8KM+If8A0Am/8DYP/jlcHRRfD/yy/wDAl/8AIhyY3/n5H/wB/wDyZ3n/AAoz4h/9AJv/AANg/wDjlKPgb8Qtp/4kTZyP+X2D/wCOVwVFF8P/ACy/8CX/AMiHJjf+fkf/AAB//Jnef8KM+If/AEAm/wDA2D/45R/woz4h/wDQCb/wNg/+OVwdFF8P/LL/AMCX/wAiHJjf+fkf/AH/APJnef8ACjPiH/0Am/8AA2D/AOOUr/A34hFmxoTYzx/psH/xyuCoovh/5Zf+BL/5EOTG/wDPyP8A4A//AJM7z/hRnxD/AOgE3/gbB/8AHKP+FGfEP/oBN/4Gwf8AxyuDoovh/wCWX/gS/wDkQ5Mb/wA/I/8AgD/+TOw1P4Q+O9ItRNceH7x1ZwgFqy3DZwT92NmIHHXGOnqK4XzH/vt+da2mavqGiztcabf3VlOy7GktpmjYrkHBKkHGQOPYV39vcQ/F23u7G+tEPj8r5llqEeIlv1QFmhlUDYHCbtr4GdqgsMfMeyp1dKV0+z1v6NJa9lb5idavh1zV7Sj1aVrebTb0XV307dvKvMf++350U2iuM7zu/hDpkOr/ABQ8P287OqJctcAoQDuiVpFHIPG5AD7Z6da5zV9Tl1rVr/UrhUWe9nkuJFjBChnYsQMknGT612PwNC/8LY0Lk5zcdv8AphJXBV17YeP+KX5R/wAzhhrjZ36Rj+Lnf8kfS3wH8VeD9I8JPbzXtlpusCUm8e7lWI3HLeWVZj8yheMDocnHzZb1P/hPvCn/AEM+if8AgfF/8VXwtRXpUM5nRpxpqC0PFxfDFLE1pVnUfvO/f+vI+6f+E+8Kf9DPon/gfF/8VR/wn3hT/oZ9E/8AA+L/AOKr4Worb+3qn8iOf/VCj/z9f3I+6f8AhPvCn/Qz6J/4Hxf/ABVH/CfeFP8AoZ9E/wDA+L/4qvhaij+3qn8iD/VCj/z9f3I+6f8AhPvCn/Qz6J/4Hxf/ABVH/CfeFP8AoZ9E/wDA+L/4qvhaij+3qn8iD/VCj/z9f3I+6f8AhPvCn/Qz6J/4Hxf/ABVH/CfeFP8AoZ9E/wDA+L/4qvhaij+3qn8iD/VCj/z9f3I+6f8AhPvCn/Qz6J/4Hxf/ABVH/CfeFP8AoZ9E/wDA+L/4qvhaij+3qn8iD/VCj/z9f3I+6f8AhPvCn/Qz6J/4Hxf/ABVH/CfeFP8AoZ9E/wDA+L/4qvhaij+3qn8iD/VCj/z9f3I+6f8AhPvCn/Qz6J/4Hxf/ABVH/CfeFP8AoZ9E/wDA+L/4qvhaij+3qn8iD/VCj/z9f3I+6f8AhPvCn/Qz6J/4Hxf/ABVH/CfeFP8AoZ9E/wDA+L/4qvhaij+3qn8iD/VCj/z9f3I+6f8AhPvCn/Qz6J/4Hxf/ABVH/CfeFP8AoZ9E/wDA+L/4qvhaij+3qn8iD/VCj/z9f3I+6f8AhPvCn/Qz6J/4Hxf/ABVH/CfeFP8AoZ9E/wDA+L/4qvhaij+3qn8iD/VCj/z9f3I+6f8AhPvCn/Qz6J/4Hxf/ABVH/CfeFP8AoZ9E/wDA+L/4qvhaij+3qn8iD/VCj/z9f3I+6f8AhPvCn/Qz6J/4Hxf/ABVH/CfeFP8AoZ9E/wDA+L/4qvhaij+3qn8iD/VCj/z9f3I+6f8AhPvCn/Qz6J/4Hxf/ABVH/CfeFP8AoZ9E/wDA+L/4qvhaij+3qn8iD/VCj/z9f3I+6f8AhPvCn/Qz6J/4Hxf/ABVH/CfeFP8AoZ9E/wDA+L/4qvhaij+3qn8iD/VCj/z9f3I+6f8AhPvCn/Qz6J/4Hxf/ABVH/CfeFP8AoZ9E/wDA+L/4qvhaij+3qn8iD/VCj/z9f3I+6f8AhPvCn/Qz6J/4Hxf/ABVH/CfeFP8AoZ9E/wDA+L/4qvhaij+3qn8iD/VCj/z9f3I+6f8AhPvCn/Qz6J/4Hxf/ABVH/CfeFP8AoZ9E/wDA+L/4qvhaij+3qn8iD/VCj/z9f3I+6f8AhPvCn/Qz6J/4Hxf/ABVH/CfeFP8AoZ9E/wDA+L/4qvhaij+3qn8iD/VCj/z9f3I+6f8AhPvCn/Qz6J/4Hxf/ABVH/CfeFP8AoZ9E/wDA+L/4qvhaij+3qn8iD/VCj/z9f3I+6f8AhPvCn/Qz6J/4Hxf/ABVH/CfeFP8AoZ9E/wDA+L/4qvhaij+3qn8iD/VCj/z9f3I+6f8AhPvCn/Qz6J/4Hxf/ABVH/CfeFP8AoZ9E/wDA+L/4qvhaij+3qn8iD/VCj/z9f3I+6f8AhPvCn/Qz6J/4Hxf/ABVH/CfeFP8AoZ9E/wDA+L/4qvhaij+3qn8iD/VCj/z9f3I+6f8AhPvCn/Qz6J/4Hxf/ABVH/CfeFP8AoZ9E/wDA+L/4qvhaij+3qn8iD/VCj/z9f3I+6f8AhPvCn/Qz6J/4Hxf/ABVH/CfeFP8AoZ9E/wDA+L/4qvhaij+3qn8iD/VCj/z9f3I+s/iz4x8Fah4G1K3uNS07U55FItIbWdJpEuMHY42nKhTyTwMZHO7afljSNTl0XVrDUrdUaeynjuI1kBKlkYMAcEHGR61TorzcXjZYmoqjVmux7eW5XDA0ZUVJyT7nWfGLTIdI+JniO3gZ2R5xcEuQTulRZGHAHG5yB7Y69aKv/HYL/wALV1/JOf8AR+3/AE7x0VzYxJYiol3f5nTl0nLCUZPdxj+SF+Bn/JWtC+tx/wCiJK4Ou8+Bn/JWtC+tx/6Ikrg6t/7vH/FL8okw/wB9qf4YfnMKKKKwO0KKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKK39G0a2ay/tTVPOOnmVoIobdwkk8ihSw3FWCKodSSQSSwAH3mSoxcnZETmoK7MCiuz/tPSP+hT0f/v8AXn/x+j+09I/6FPR/+/15/wDH609kv5l+P+Rl7aX/AD7f/kv+ZxlFdn/aekf9Cno//f68/wDj9H9p6R/0Kej/APf68/8Aj9Hsl/Mvx/yD20v+fb/8l/zOMors/wC09I/6FPR/+/15/wDH6P7T0j/oU9H/AO/15/8AH6PZL+Zfj/kHtpf8+3/5L/mcZRXZ/wBp6R/0Kej/APf68/8Aj9H9p6R/0Kej/wDf68/+P0eyX8y/H/IPbS/59v8A8l/zOMors/7T0j/oU9H/AO/15/8AH6P7T0j/AKFPR/8Av9ef/H6PZL+Zfj/kHtpf8+3/AOS/5nGUV2f9p6R/0Kej/wDf68/+P0f2npH/AEKej/8Af68/+P0eyX8y/H/IPbS/59v/AMl/zOMors/7T0j/AKFPR/8Av9ef/H6P7T0j/oU9H/7/AF5/8fo9kv5l+P8AkHtpf8+3/wCS/wCZxlFdkNN03xLLHaWGnJpurSsI7dIJna3nYniMiQsyuxOA+/bkKCqgs442onBx8y6dTnurWa6BRWzpWlQPa/2hqHmmyMjQxxQOFkmcAFvmIIUKGUkkHOQAOpXT+2aZ/wBC5pv/AH9uf/j1YyqKLsYzxajK0YuXpb9Wv68zk6K6z7Zpn/Quab/39uf/AI9R9s0z/oXNN/7+3P8A8eqfbRI+uf8ATuX/AJL/APJHJ0V1n2zTP+hc03/v7c//AB6j7Zpn/Quab/39uf8A49R7aIfXP+ncv/Jf/kjk6K6z7Zpn/Quab/39uf8A49R9s0z/AKFzTf8Av7c//HqPbRD65/07l/5L/wDJHJ0V1n2zTP8AoXNN/wC/tz/8eo+2aZ/0Lmm/9/bn/wCPUe2iH1z/AKdy/wDJf/kjk6K6z7Zpn/Quab/39uf/AI9VLUdLtbq1nvtOjeH7OA9zbO+4KpYKHRiM7dzBdpywyDlssVcasW7FQxabSlFq/e36NmBRRRWh2Hc/Hf8A5Ktr/wD27/8ApPHRR8d/+Sra/wD9u/8A6Tx0Vrjf95qf4n+Zx5Z/uVH/AAx/JD/gZ/yVrQvrcf8AoiSuDrvfga7H4saENxxm44z/ANMJK4Krf+7x/wAUvyiKH++1P8MPzmFFFFc52hRRRQAUVJb28t3PFb28TyzysEjjjUszsTgAAckk9q9ht/hLo3gmxt9W+IWq+V5uWh0mxy0kzAKxRnH4qduACVPmDIrejh51ruOy3b0SOTE42lhrKbu3slq36I8r0XQdT8R36WOlWM95dNg7IlztGQNzHoq5IyxwBnk16XYfs/63Hax33iHVdL0PTxnz3nm3vDyQucYQ5O3+P+L14p2ofGe506BdM8E6Za6BpcTAqViWSaYgFQz7gRkqEzkM2V++a89v73U9bnW41K+ubuZVCCS6maRguScAkk4yTx710JYanveb+5f5v8Dkvj67urUo/wDgUv8A5FfielDwR8KNL/0TU/G19c30f+slsY8wtnkbdscg6EA/MeQenQL/AG78GP8AoUda/wC/rf8AyRXlws1xyxJ9qeLaPH3f1p/WrfDTivlf87h/ZrlrUrzb/wAVvwil/wAA9O/t34Mf9CjrX/f1v/kikPhn4QavzaeJtU066vP9VDOhMds7fdViY8bVJAJMnQfe715l9mi/u/qaYbRccMwPvR9av8VOL+VvysH9m2+CtNP/ABX/ADuelXHwAvr6CW68MeItI1y0iUgtHJsYygZ8sbSy5wV5LD73OBzXnHiLwnrXhK6W21nTp7ORvuFwCknAJ2uMq2NwzgnGcGi0kvdLukurC6mt7mPOyaCQxuuRg4IORwSPxrvdG+NWuW0B0/xDbW3iHSWVUe2vo13EKPl+facnO0kuGJ29jzSf1Wpo04P71/n+YWzCg7qSqx7fDL5P4fvseU0V7Uvw38I/EdJp/Ampvp2oxrvk0nUgxCrkLkN8xA4LEgycsoO3NeQ6tpN7oWpXOnajbPbXts2ySJ+qn+RBGCCOCCCODWFbDTpJSeqezWq/r1OrDY6liG4RupLeLVmvl+quinRRRXOdgUUUUAFdnqf/ACAfCf8A2DpP/Sy5rjK7LUCJPDvhWRDuRLKWFmHIWQXUzFCezBZEbHXDqe4raltL0/VHPW+KHr/7ayrpNh/amq2Nj5nl/ap0h34zt3MBnHfGa7e4+GMMutaroemay1zrOnoZDbz2vlLOAASEYO2TyOCBXF6HfR6ZrWm3swZorW5jmcIMsQrAnGe/FeiSfETQ9P8AFWr+KNMh1CfVLxGSCK5iSOKAkAFiQ7F+nTA6114eNFx/ed/wt0ODGzxSqWoX+F20Vua6tfsrX7fecxb+DoLfw7Z67rOpNY2t9I0dtHDb+dJJt4ZiCygKD759q2LP4UTTeJW0q41NEtmsDqMF5DD5gmiyMYUsuDz69vfNUP8AhKtL1nwppmh62t7DJpcjtBdWkayF0Y5KsrMuD7g9uldFY/FTTk8ULeT2d3DpNtpR0y2jiCySgZGGbJUZ47H0+ta044a65ttO/wA7nPWqY9KXJe/vdFbf3bd21vv120OTuvBqS+HH1/R79r6xgmEFxHLB5M0LNjaSoZgQSQMg9/rWo/w2gtdas9AvdcWDX7pFYQC2LwxuwyqNJuyCfZSOaqv4tsNH8JXOgaGt3I17Ok9zeXaLGfkIKqqKzY5UHJJ7+vGvc+O9A1PxTY+K7211BNUt1RpLOFUMMsqDCsJC2VHA42np1pRjh9L2vpfV263t+H4lSnjdbXt71nZXei5bq2ivfoul7GTY/Dm6Om6rf6jJcQxadeGykjs7X7TL5gGWO3coCjI5z3pmieCrDWYvEV2uszLYaNEkxkWzy8oYHI2F12kEEdTVvSfHrQalqOqvq+rabf3t008kdlDHNA6nBAKu68jkZOeMVuR/FPTJNX8XXnlX+nHWYYoreWzRWkiKAgu3zryc54P41UIYZ2v5/PR266dNNPUipUx65kl226axutU76X1Tfpsc9dfDK8Ot6Dp2n3aXK61bi6gklTymjTGSXXJxgehOe1RjwLa6hBrJ0XWDfXWkI0s8Mlt5QkRThmjO5twHuFNbVx8UoLbXvDWp2dvcXc2kwNBcXV5hJrxWGDuwWxjkjJPJrPsvF2h+G4tfm0SLUJb3VoXt0F0iIlrG5y2CrEuemDhelJxw13bb59unzv3+4camP5VdO9lbRavmd79vds+nXroQ23gzRLrwveeIl1zUBZWk627odNTzCxxyB5+MfMO9cclsbq9W2sw8xlk8uHcu1nycLkZOCeOMn610tj4os7X4eap4eeOc3t3eJcI4UeWFAXIJznPyntVXwLrOm+HvEtpqmqQzzw2m6SOOFVJaTHy5yRgA859hWE1SlKCjZX337nZTliIRqyneTTfKtNVZW2S6mv49+G8ngi2s7lNRS/hmkaGVki2CGUAHYfmOcjPp0rK8ceE/+EM1lNO+2fa90CTeZ5fl43Z4xk+nrW7P8RLTWvDmv6XqumpDLfTfbYJLPewFzn5mbzJDgEAD5egJ4rL+I3imz8X6/HqFjHPHCttHCVnUBsrnPQnjmtK8cPyylT8rLXTe/wChhhJ43nhCv05ruy12a29WtO2pyNS+Pv8AkevE/wD2E7r/ANGtSQQS3U8cEEbyzSsESNFLM7E4AAHUk9qZ42uIrvxn4iuLeVJYJdRuHjkjYMrqZWIII4II71xv+G/Vfqej/wAvo+j/ADRfvP8AkDeHP+vJ/wD0pnqlDDJczRwwo0ksjBERRksScACrlyQ+h+H3U7kS1kiZhyA4uJWKn32uhx6MD3FP8P6p/Yeu6bqRj8wWdwkxT+8FYHFeZP4mcCbUZuKu7y/NnfXHwG8UQaSbwNZyXCrvNmkhMn0BxtJ9s/jXnOnafcapqFtYWybrm5kWKNTxlicD6V9UXHxk8Iw6Ub5NSEr7MraqjCUt/dxjj69PevmKx16fT/EcOtxInnxXP2kJ/Dndu2/TtUI8jKsXjq8an1iFmtrq2uuh1afDWC61u78P2euLPr9sjMYDbFYZHUZZFk3ZJHPVQOKhT4aXM3gL/hKILvfKhcyWJiwyojlWYNnnHBIwMA+1adv488P6b4rvfFlna6g2qTq7R2cqoIYpXGGYyBssOTxtHXrUOnfEuPTND8OW0cM8l3p91PLeK6r5U8Upbcg55yG7jrRqU54+0eT+7e6XZ8y9L2V/Pdir8KN3iZtF/tf7umf2j532b6fJt3+/XP4Vzngnwl/wmOp3Vl9s+y+RayXO/wAvfu24+XGR1z1run+KOhHx1PrKWuoJpz6UdPVPLQyK2euN+MY981zvg3xJoHg3WLi8jn1O8iuLKa3YNZxxMrMV2kfvWyODnpjjr2Bwq432UuZPm5VbRb636W7b/Iii+G9xdeAF8VW16JXBdnsvKwyxo5VnDbuccE8dDWjF8KFfxSdEbWCqjTRqJnFrk44+Tbv9+ufwqLSfiPBo3h7wzY28E73GmXMz3SOq+VPDITuQc5OQe461u/8AC1NDXx5LrkVvqMVgdL+woqxp5qNkYON+MAD1zRqRUqZgnNRWnvW0Xf3V92q7312PLNSi0yIx/wBnXd3cA53m5tVh2+mNsj57+lS6F/x9XX/Xhef+k0lWfEmprqb27jW9W1VkBBbUo9pjHGAv71855z06d6raIQk17Kx2xpYXe5zwF3QOi5PbLMqj1LAdTVR3R6cm3h3fez/rZfkchRRRXae4dz8d/wDkq2v/APbv/wCk8dFO+OzsPirr4DED/R+//TvHRWuN/wB5qf4n+Zx5Z/uVH/DH8kL8DP8AkrWhfW4/9ESVwdd58DP+StaF9bj/ANESVwdU/wDd4/4pflEUP99qf4YfnMKKKKwO0K2fC/hfU/GOswaVpUHmXEnLM3CRIOrueyjP6gDJIBpaTpN7rupW2nadbPc3ty2yOJOrH+QAGSSeAASeBXtHifWYfg/4fi8I+HwieIbyBJdV1OOQM6MQfkQ8EHrtyBtUggbmLDqw9CM06lTSC38/Jef5HBjMVKm1QoK9SW3ZL+Z+S/F6Be674d+DMGo6R4XZ9R8WSKsNzqkyqY7c4+dEHqCM7ORkjczbNteT6he33iDUbjUdSuJJ7u4bfJK/Vj7dgAMAAcAAAcCq0FuCA7dOwqy8ixjLH8PWqrV3UVtorZdP+H8x4XBQw7cr803vJ7v/ACXlsCRrGMKP/r0PIkf3mAqlJdO/A+Ue3WoK5HVS2PQVLuXjeRg4+Y+4FM+2/wDTP9aqUVDqyK9nEt/bf+mf608XiHGQwqjRR7SQeziaaSo/3WBPpTmUOMMARWVUsdw8fGcr6GrVXuS6XYsqs1lNFcWsskc0TB0eNirowOQQRyCD3Fer6Z4+0T4jadb+H/iFvS7WfNrrNuqRmLd1DnGFBwFztKkEEgFd1eWRTLKMg89xUc9uGy68HuPWuqjXlS+HVPddGcOKwdPEW59JLaS3Xo/02ZqePfAWp+ANZNjfDzLeTLW12i4SdB3HowyMr2z3BBPK17T8OfFdp4tsIvh/4sT7Tp9z8un3bOFktZADtUMfyXqcnZhlbA8v8UeF9T8HazPpWqweXcR8qy8pKh6Oh7qcfoQcEEAxFGPKq1L4X+D7f5MywmJqc7w2J/iLW/SS7r9V0fkY1FFFch6IVs6PriWUTWd9bveaY7GTyUlEbxyYA3xuVbaSAAwIIYAZGVVlxqKqMnF3RE4KatI6/wA3wp/0Ftb/APBVF/8AJNHm+FP+gtrf/gqi/wDkmuQorT2q/lX4/wCZl7GX87/8l/yOv83wp/0Ftb/8FUX/AMk0eb4U/wCgtrf/AIKov/kmuQoo9qv5V+P+Yexl/O//ACX/ACOv83wp/wBBbW//AAVRf/JNHm+FP+gtrf8A4Kov/kmuQoo9qv5V+P8AmHsZfzv/AMl/yOv83wp/0Ftb/wDBVF/8k0eb4U/6C2t/+CqL/wCSa5Cij2q/lX4/5h7GX87/APJf8jr/ADfCn/QW1v8A8FUX/wAk0eb4U/6C2t/+CqL/AOSa5Cij2q/lX4/5h7GX87/8l/yOv83wp/0Ftb/8FUX/AMk0eb4U/wCgtrf/AIKov/kmuQoo9qv5V+P+Yexl/O//ACX/ACOv83wp/wBBbW//AAVRf/JNHm+FP+gtrf8A4Kov/kmuQoo9qv5V+P8AmHsZfzv/AMl/yOqm17TNJUtof22a/wD4L67RYTB/uRKz/OMcSF+MnChgrjlaKKiU3I0hTUPN9zU0vV1s42truFrmwZt/lLJsdHx95GIO0nAB4IIAyMhSup5/h3/oIar/AOC+P/4/XL0VjKnGWrMqmFjKXMm16W/VM6jz/Dv/AEENV/8ABfH/APH6PP8ADv8A0ENV/wDBfH/8frl6KXsokfU/77/D/I6jz/Dv/QQ1X/wXx/8Ax+jz/Dv/AEENV/8ABfH/APH65eij2UQ+p/33+H+R1Hn+Hf8AoIar/wCC+P8A+P0ef4d/6CGq/wDgvj/+P1y9FHsoh9T/AL7/AA/yOo8/w7/0ENV/8F8f/wAfo8/w7/0ENV/8F8f/AMfrl6KPZRD6n/ff4f5HUef4d/6CGq/+C+P/AOP1Q1LWIWgez02OWK1fHnSSsDJcYPGccKuQG2AnnqzYXGNRTVOKdyoYWMWpSbdu9v0S/EKKKKs6jufjv/yVbX/+3f8A9J46KPjv/wAlW1//ALd//SeOitcb/vNT/E/zOPLP9yo/4Y/kiT4Ghf8AhbGhcnObjt/0wkrgq7z4Gf8AJWtC+tx/6Ikrg6t/7vH/ABS/KIof77U/ww/OYUUV0vgHwlL428VWGkIHEEjb7mRM/u4V5c5wQDjgEjG5lB61lCDnJQjuzpq1Y0oOpN2SV2ek+Cbew+GHgX/hNNQt4ZfE2pbk0m3uCwKxnALhcZGQSxbOChUBl3nPkwMt7cS3NzI8ssrF3kkYszsTkkk8k5712fxW8UReKPFZttPKLoulL9jso4cCIKvDOoBK4JHBXGVVOOK5RVCKFHQV2YmabVKHwx09X1fz/I4MvpSUXiKvx1NX5LpH5L8biSOI0LH/APXWa7tIxZjzU94+XCA8Dr9arV51SV3Y9enGyuFFFFZmgUUUUAFFFFABRRRQAqsVIIOCK0YZRKmeN3cVm1NavslAzw3FaU5WdjOcbomuYf41H1r1/Fr8Yfh7N5kaN448PQYjKuzTXkC45IwS5PzDAyQ+DlQ+D5URkYPStPwR4nl8D+LLHVELm3RtlxGucyQtwwxkAnuATjcqntXfh6ihLln8MtH/AJ/I8rH4eVWmp0vjhrH/AC9HszjqK774veEovDHip57AI2iasv2yykhwYtrcsikALgE8Bc4Vk55rga5qtJ0puEt0dWHrxxFKNWGzQUUV7H8MvhV8P/H1tolpf/FT+xvFOrXAtU0f/hH7i42yNIUjHnBwh3Dac8AbsHpWbdjc8cor6R+I/wCzl4A+FuoT6T4g+Mf2fW1tftMVl/wjM7+YDu2DekjKMlSOTxXzdSTT2AKKKKYBRRRQAUUUUAFFFFABRXbfCj4Zar8XfGln4Y0iWCCedXlkuLgnZDGoyzEDk9gAOpI6dR1HxN+EPhbwLb6tHpPxM03XNZ0e4+zXultYS2kwcPsYRliyybTnOD0BPaldXsB5DRRXtXwN/Z+/4XRofi7U/wDhIv7J/wCEejjk8v7F5/n7lkbGfMXbjy8dD19qbdtWB4rRXuvw2/ZsufFfgPUvHnizxFF4Q8JWqb4Ly5tDO91zglI96HGeAckseADXiN4lvHdzpZzSzWiuwilljEbumeCyhmCkjtk49TQmmBBRRXsfxj+BH/CpfCvgjXf7f/tP/hKLc3HkfY/J+zYjjfG7zG3/AOtxnA6e9F1sB45RRRQAUUUUAFFFFABRRRQAUUUUAFFFFAHd/HYL/wALV1/JOf8AR+3/AE7x0U347/8AJVtf/wC3f/0njorXG/7zU/xP8zjyz/cqP+GP5If8DP8AkrWhfW4/9ESVwdd58DP+StaF9bj/ANESVwdU/wDd4/4pflEUP99qf4YfnMK9t+EsieFPhv4z8YI3+nDFjbssKs8L4XawLdVLyoSMf8s888CvEq9o8ej+wvg74A0T/XfbN2o+d93ZkF9m3nP/AB84zn+DpzxvgnyOdb+VP73ovzOfNF7VU8N/PJX9F7z/ACPKrRMlnI6cCrdRwLtiXpzzUlc62PSZBJBG8mWYhm7Un2OP1b86jvW+ZF7gZrqvhbqnh2w8feHrjxisr+HILtJLry4ll4HK70IO+PcF3gAkpuABOKxlKKbujWMZNKzPoX4I/sg6X448FweJPFuo6tZ/2l+8srWy2xOsIJAeQyRtnfwy7Rjbg5O7C+lf8MMfDv8A6DPin/wKt/8A4xX0do+rWev6RYatp03nafqEEdzby7Su+N1DK2GAIyCDggGrteJPEVHJu9j1o0IJJWufMn/DDHw7/wCgz4p/8Crf/wCMUf8ADDHw7/6DPin/AMCrf/4xX03RU+3qdyvYw7HzJ/wwx8O/+gz4p/8AAq3/APjFH/DDHw7/AOgz4p/8Crf/AOMV9N0Ue3qdw9jDseNfD39lz4deAf7Rzpv9v/bfL/5GCC3u/I2bv9X+6G3du59dq+ldhd/Cr4a2VpPcy+APDTRwRtIwh0KGVyAMnaixlmPHAUEnoATXbLgMM9Kk3J7flXTSrScdZL5nLWpRUtE/kfmV+0fqngDxJ440+7+HsNjDoqabHFKthYGzjM4llLEoUXJ2lPmx0wM8V4+ttGsi4Ztw5xX1D+078RvhH4w8I258CHS5PE0urLc3dxb6Q9tPJEY5d7NK0S7suyEgkknntmvli0b99zklga9OLjorHC1Kzdy9Ve7TKBscj+VWKa670ZeOR3rdmSPU9XkTxh8ALS+mb/TvDVytuZHhXLplUCKR0XZLFk9zHyD1rxCvafgSP7XHjDwx/qv7X0xv9J+95WMx/d43f67PUfd9+PFq6MX78KdXurP1Wn5WPNy5eyrV8OtlLmXpJX/O4V3nwR/5LL8Pf+w9Y/8Ao9K4Otfwt4iuvCPibRvEFjHDJeaTdxXsKTgmNnjcOoYAgkZAzgj61wvY9U+1vi74Q0nx3+2x4Q0LXEWXS59NjklhY4E3lpPIEPsSgBHcE13Hif4peBPBnxE1Tw/4n+IWkQ+FLRPssvgpvB0pjiBjG0i4VTuPIbgFSDgAdR8Q/EH42+KPiH4+sfG9ybTS9esY4kgk0tXjWMxsWVhvdjnLHvj2rtL/APa08V6uYrnVfC3gbUtZiQIur3miLJdjHQ7i20evC49qy5HoO57T+yEnhuP4/fEkeEJzP4ZazZ7Byjr+6MyELhwGwM45GeK0v2f/ABe/xk8L/Fnwpr+l6WPDWnQA6dY29nHGtoricYBAyzDYpDsS24E5r5f+HP7QXir4aeM/EHi3T7fSr3V9eD/azfQN5ZLyeYxVY3Tb83bpjtUHwt+OviL4R/8ACS/2JZaVcf8ACQxrHc/bopH2Bd+Nm11x/rD1z0FNweoXPcvgXYePPBPwXHi2b4q2fgXwLdXjyQq2ix6jLLIW8ottK7hkx4ABPCk4HWup/af0PRdV+Hfws8cwT2upaxd6la2761BYGyOoRSRs+9ojyMmMEA9Nxxwa+c/BH7RvizwT4Jk8GCx0HW/DpcvFZ63Y/aUgJbcdo3AH5iWwwYAmneOf2kvGHxD8J6D4c1u30lrfRbyO+iuIYHSaSRFdQH+fZtw54VVxgYwBRyu9wufXnx5+KOq+B/2h/htpWj21hGdWW1gv7mW1SSaa3kumTyQ7AlFGXb5cElhnOAK878f/AAy8Mar+254f0O40+2j0jVIU1C6tVULFNKkMr4K9MO0K7h3ye5r588f/AB/8S/Ebx94d8aarY6RDqmgeT9mitIpFhfypjKu8NIzH5jg4YcenWm+KfjP4g+JXxU0Txlql5ZeH9Utnt4VvtOhk2Wqo+fN2MzFsbiSM8gYxQoNBc+uNP+KWtaj+2HbeAp9L0/8A4RvSWlisYBZIslkVs2fzkkA3DdkrjO3a+MZ5r5R/ai/5L745/wCvxf8A0UlfWfhv4m29j4qtPGHjP4lfCxrCygdZJvDsROq6kuwqiTAgyKoJD7E7qBjFfEfxc8ZwfEP4l+JvE1rC8NpqV20kKSfeEYAVN3oSqgkeppQWoM9//ZF8P6d4a8LeOfi/cw3F/qPhWCWOzsIZSgJ8ks7PjqCGA5BAwxwSBj0q4+Dngr9p7XfCvxQ8OmGGxurlU8UaTJIyMSi5YZTBEhwFJGNysHBBzn5B+Fvxl8V/B/ULu68N3UPkXqhLqyuo/Nt7gDONy5ByMnkEHkjOCa9J0r9snxx4enj/ALC0Dwbo9jvaSaw0/SfJguGIxlwH3Z75DA8c5HFOUZXugTR5V8WY/DMHxI8SW/g63WDw1b3TQWaJM8qlUAUsHcliGYMwJJ4NfV37Astvb+G/ifLeJ5lpGLVpkxncgScsMd+M18b+K/EC+KfEF9rA0rTtKa8fzGtNNR0t0Y9SiuzFQTzjOBngAcV2/wAKfjv4j+D+leI9N0Oy0q4g19ES5a+ikdkCq6jZskUDiQ9QegqpJuNgT1PpH9r7RNc+IPgfw7408GapHqnw0tLYMdPsU2rakZHnFR1AHyEEAx4IwMtjgv2YNB8eWHgvxZ4v0b4gWfgnwhbyql/eTabHfPK8S7uI3UkBRKOhGS2MHHHl/wAJP2gvF/wag1G00U2N7pV+P3unapG8tvu6FwqspDEcHnBHUHAxd8GftH+JvAf/AAkNppGj+Hf+Ee12Vp7jQbm0eWxR2UK2xGk3AEAAqWIwAMYAqeVpWC/U+lPjnY6L49/ZYm8ZS65aeLNX026j+z+I49IOnSTA3KxMhjPOAHIPYlQcZFVf2g9CtPFGk/s0aJqEhjsdTeC0ncHBEciWitg9jgmvnrxL+0z4v8VfDjUPAd9Y6FHol5Irg2tm0L26rKsixxKriNUBQDGzpnJJOaxviN8c/EnxN0PwnpOqW2m2kPheLyrKWwSSORhtjXLlnbnESnKgc5oUGFz7j8feNPB/wi8aaP4ek8d6V4U8M2ltE8/hVfCUl0l7CSQWNwoOCQCAR0IywbkV4/8ACO48C337ZMV98O5o5PDd5YzzKkVvJBHFKYT5iqjqpC5GcYwN2BwK8nb9rHxhqGn2Vt4h0Dwd4murJNkF/rekC4uEHs24DPvjnvXLaB8ePFHh/wCKLfEWODSrjXWiMPlS2uy2VPKEQAjiZMYQADB7c5pKDsFz7Q+Fvio/ED42fGD4faxpely+Ebd52Fj9kQb5PP2SSO+Nzs5YsSScHG3GK5L4X+J2+MXwf+M2ja9pumDRtChlOk2ltZxxLYqIpWQJtA5QxqQxyc5yTXzZ4L/aO8U+BfiF4n8b6dYaNLqviNpGuormGVoE3yCQ7AsgYcjux4qh4A+O3iP4caH4v0fSrLSprbxUhjvGu4pGeMFHX92VkUDiQ9Q3QUcjC55fRRRWogooooAKKKKACiiigDufjv8A8lW1/wD7d/8A0njoo+O//JVtf/7d/wD0njorXG/7zU/xP8zjyz/cqP8Ahj+SJPga7H4saENxxm44z/0wkrgq7z4Gf8la0L63H/oiSuDq3/u8f8UvyiKH++1P8MPzmFe1ftBj+z9b8P6JbfJpen6an2eHr5eWZD8x5PyxIOSenua8Vr2r9o//AJHjT/8AsGx/+jZa2of7tV9Y/qYYnXH4deU/yj/mzzJRtUAdAMVUvW+ZV9BmrlULtszEegxXJV+E9Sn8RBRRRXMdB+r/AIMvz4K+CPh++1e0uojonhu3mu7by9syeTaqXTa2MONpGDjnrivn34PaX4a/aPbxlrnxR8UyzalZRyvb6SLprWDSLYqu67iyduFKhTnKrsDS7y6mvrXVtLtNc0q+0u/i86xvoHtp4txXfG6lWXIIIyCRkEGvzo8efs5+PfBWsy2kGh32t6ezsLa+0y3aYSoMHLIm5oz8wGG7htpYDNcGEcW5XdmdmIjKyS2PWv2Y/itfWPxDufh7Lrl1r/huczRaRdzRsGTyVJRlDtuiiaGM/u+drbQAMsT9k18m/sv/AAA1vwxro8aeK7L7DNFAV06ykY+crSIN0zhW+TCMybHBbLNkKVXP1lWWKcHU9w0oKSh7wV8zftP/ABWvtA13w14J0/XLrw7b6kY7rVNYt42aS3t2l2KYyjB+NkjMqgFgqgNgsD9M187ftO/AvU/iXHpuv+GoYptesE+yy2rybDcwFsrtZmCKUZnODjcHPOVVTOHcVUXPsVWUnB8p5r8ePCHhL4Dr4O134X+LLqw167t491vb3Zn+32v3xdswO3YzqoKEeXJ/CoCNn6k+FnjX/hYnw+0HxK0PkzX0B86MLtUTIxjk2jc3yb0bbkk7cZ5r8+fDPwF+IvijVY7CHwpqdjuwXudTt3tYY13AFizgZxuztXcxAOFOK/RHwB4OtPh/4N0bw3ZNvh06ARtLgjzZCS0kmCTt3OzNtyQM4HAFdOMcOVJO7MMMpJu+x+Rd5Z3GnXdxZ3lvLb3dvI0U0EyFHjdThlZTyCCCCD0qGu0+MH/JWvHv/Yev/wD0oeuLrsTurnI1Z2J7RsTAeoxV+s2BtsyH3xWlXTSehhVWp23wMvJ7L4mafBDJtiuo54ZhgHegjZwPb5kU8en1rhPF1jb6X4r12xtI/LtbW+nhiTJO1FkYKMnk8Ada7P4Lf8lT0X63H/oiSuU8ff8AI9eJ/wDsJ3X/AKNauyeuEj/if5I8mGmZTS6wj/6VI56iituDwte3Hha48RRvAbO3uPs8ke4+aOF+fGMbcugznOWHFcR6hiUV0eq+CNX0ufSbbyftd3qdsLqK3tFaSRQSQVZcfeBU5AzismPR9Rm1A6dHYXT6gCVNqsLGXI6jZjOfwoApUVoQaDqt1eT2cGmXst5ACZYEgdpIwOu5QMj8avXvhiW38Vx+H4Z0knkmigSWRSi7n24yBkgAt70AYNFdOnhK3fW9N0qPxBp9zNeXkdm4tYpy0O5gpYiSNAQCegP+NY6aLqE8ka21ldTiaVoYjHCzea69VXA5IBBwPWgLlCitSLwzrc91NaxaPqEl1AwSSFLZy6MQSAVxkEgE8+hqOz0HVdQmlhtNMvbiaFxHIkMDOyNz8pAHB+VuP9k+lAGfRV1tH1FdOXUWsLoaezbRdGFvKJ9N+MZ/GrP/AAjWqRTww3djdWZnieaM3FtIPMVELEgBSSMDqBgdSQMkAGTRRWz4b8Pr4jvo7JdVsbK6mljhgS6E3753OAAY42A5x97HUe+ADGorp4PByXN9d20Ov6U8dnbtc3FyFuRHEFdVIIMO4nLDopHvS2/gi41Cz1i70zUtP1CDSokllMHmqXDbiQgkjUkqqMx6cDjNFgucvRW5D4Vvp9Q0SxjaFptYjSWE7jtRWdly5xxjaScZwKvWPw/1XUfEGqaJBJam90+J5jlyFnAKhRGccl967c4zkdKLBc5Wityy8J6jqMeltbCJ21KSaONC+0p5QUuzk4CqA2c56A5xUWqaJFp0Ilh1jTb8BgjLau+5Tg9nRcjjquR78igDIooopDCiiigAooooAKKKKACiiigAooooA7v47Ow+KuvgMQP9H7/9O8dFN+O//JVtf/7d/wD0njorXG/7zU/xP8zjyz/cqP8Ahj+SH/Az/krWhfW4/wDRElcHXe/A0L/wtjQuTnNx2/6YSVwVW/8Ad4/4pflEUP8Afan+GH5zCvafjgf7VsPA/iSb5b7VtMHnInEa4CP8oPI5mbqTwB758Wr2e8P/AAlHwA0+6Hz3Xhy+MEs1xy/lscBI25O3EsIwcD93/sjO2F96nVp+V/uf+Vznx/uV8PW7Scf/AAJW/Ox5ohJRSepArPnbdM5Prirdq2Ysd1NUWbcxY9Sc1xVXoj16a1YlFFdP8N9Ws9A+InhHVtRm8nT9P1a0ubiXaW2RpMjM2FBJwATgAmuduyNlufrvRUNneW+o2lveWdxFcWlxGssM8Lh0kRhlWVhwQQQQR1qavDPWCiiuD8a+FfG+uarDceGviD/wjlisAje0/saC83yBmJk3uQRkFRt6fLnvTSu9XYTdjvKK838LeDPiFpOu2l5rnxO/tvS4t/naf/YNvbedlCF/eI25cMQ3HXbjvXpFOSS2dwTv0CiiipGfkr8YP+StePf+w9f/APpQ9cXXqn7SPiLS/Ffxr8V6rot7FfabLJBHHcwnKSGOCONip/iG5GAYcHGQSCDXlde3D4UeVP4mKrbWDDqDmtWsmtCST/R9xxll/nXRSe5hVWx6P+z9p0WofEL7RKziSxtJbiPaQAzErHzx0xI3THIFeWavqcutatf6lcKiz3s8lxIsYIUM7FiBkk4yfWvXPhof+Ec+GvjvxQ3yyPELC2mg4nhkIxkNxtXdLEeDn5M44GfF67q/u4enDvd/fovyPIwv7zG16vRcsV8ld/mFdt4e8WWWh+HrW2ngF9m9uGubFiUEsLxRqPnwQPmTI68qOK4miuI9Sx6U3i+x1fTlt7zUvs1/fabNBPdmNysMrXzzlW2gnayEAlQcbgPUVDL4i0u5utQsf7SaNZ9Ig05dVeJ8O8bIxLAAvsYIU6ZwFyOorzuii4rHpWoeIdJ1XT7jSU1o2skS2X/Eykilxd+QjqwIUFxguNuR0QZ28YzNT8Qafc/FKHW0u3k01dQgna4dGDFFKbmK4zng8VxFFFx2PRrjW7SPxVompTa3oNzZ2+qRXDjTtMa3ljjEgYs5FvGWAA6ZY57VFceJbG+1iy1O31CKxUwSWcljPBI0ECFCp27BkRuGJOPnDEnn7x8+oouFj1JTpFz4d8Sw2Ws/Y7R5NOjacidoPMCzkouQZPL4yMgnIHbmsnX/ABVZ31n4ojtbuXdfz2CqWVla5SGKRXkb03NtbBOct7GuIW5mSCS3WWRYJWV3jDEKzLnaSOhI3HHpk+tRUXFY9PvfGOlTaZ59qdOhuJNOisHiaK7e5XaiqcDzBBt3LuB4P+znJLZPEGiLqCahNqUMt/cC9ad7SOdYmMls6qXSQcSF2A+T5QDXmVFFwsauh3f2Q6j/AMTD7F5tnLF/qfM8/OP3X+zu/vdsU/wnfQaZ4q0O9upPLtbW+gmlfBO1FkUk4HJ4B6Vj0UDO08HazZ2GreIJJr60tReWcsUE15bGeEuZUYBkCPkYU9VNXo/FKaHBqUsOp6Xd6i1xZzw/2fZGCBxH5u9SnlRjowB45DdTzjz2ii4WPVbzxN4Ss9QF9ZyXNxBb6N9jtbWMtFLHJLJJvXzGRlBjjkYbsHJIx7VJ/FmiSW8l9ZTXFlfvo39n+TK5llEkUsRibzFRQcxrjOBjy+eoz5rRRcVj1W68baC50SdGkX7XFfpqcMURBtXuY1jZkzgEbgzgA9Dt4rm9QuNJsfClzpkd/p2pXT3Eb201tYGOSJBvLh5XjVjksvGWAx2rjqKLjsFFFFIYUUUUAFFFFABRRRQAUUUUAFFFFAHc/Hf/AJKtr/8A27/+k8dFO+OwX/hauv5Jz/o/b/p3jorXG/7zU/xP8zjyz/cqP+GP5IX4Gf8AJWtC+tx/6Ikrg67z4Gf8la0L63H/AKIkrg6p/wC7x/xS/KIof77U/wAMPzmFeyfAXWILqfXfBt/LOtrr1s6xFHPyOEYOFXBAZkJO4/8APMDnivG6sWF9caXf2t9aSeXdWsqzRPgHa6kFTg8HkDrRhq3sKqqdvy6lY7CrFUJUb2b2fZrVP7y9c21xpF9eWN0nlXVs7wypkHa6kgjI4PII4qjXrvxa0tfE2maT8QtKt3+xapAqX6ruYW8y/JyTg4yPLyFC5jB6uK8iqMZS9lU5N1un3T2Zrl+J+s0VUas9muzW6+8KKlt4fOcgttRVLM2M4A9qf5dn/wA/v/kI1yna2kfUH7Mn7Tdn4A09PB3jF/K8OReZJY6hFCXa0ZiXaORUBZ0ZixDAFlZsHKkFPvCzvLfUbS3vLO4iuLS4jWWGeFw6SIwyrKw4IIIII61+N/l2f/P7/wCQjXp3w0+PXi34VbING8RfaNJXP/Er1CF5rUZ3n5VyGj+Zyx8tl3HG7PSuSthed80dzopYlR0lsfqRRXmXwh+Lr/FvQrLVrPwxe29rPJLFNcx3lrNBbumflb94swJG04MQPzg/dIY+oGJwcbT+VcMqU47o641YS2YyineW5/hP5VxXxJ8fS/DjQtS1ifw/e3mn2Nobh7tbq1ht1fkLGxklD5LbR8qOTvAUM3y0o05y2Q5VIR3Z2dfG37Sf7U+l3eiX3g3wLdxX7X8ctrqWqBMxRxHKPFFuGHLDOZBlQpG0ktuTxr4pftNeLfib9psv7Z/sXQJdyf2dpyOnmRneNssv3pMo+1hwjbQdgNeL+XZ/8/v/AJCNd1HCcr5pnJVxSekSvRVjy7P/AJ/f/IRps8CxrG8cnmRSA4bGOh54rsOa6ZDUzyFoo1z0FQ16b8GvC63utSeJdTR49A0BWu5ZyrFTIg3Kowckr984B+6AR8wrowtKVWoqcev9XOXHYiOGoyrT6fi+iXm3obHxUuv+EP8Ah34V8DK06XzRre3yGX7mSxKHaNrqZWfHJx5Q65BrxKtnxZ4iuPFviPUdZuV2yXkpcJkHy0AwiZAGdqhRnHOMmsat8VWVWpeOy0Xotjky/DPD0FGfxO7l6vV/5BRRVi2tvN/eSZEQOMjqx9B/j2/IHnO0r0VpYtxwLWMgd2Zsn64Ipf3H/PpF/wB9P/8AFU+UXMZlFaf7j/n0i/76f/4qj9x/z6Rf99P/APFUcocxmUVp/uP+fSL/AL6f/wCKo/cf8+kX/fT/APxVHKHMZlFaf7j/AJ9Iv++n/wDiqP3H/PpF/wB9P/8AFUcocxmUVp/uP+fSL/vp/wD4qj9x/wA+kX/fT/8AxVHKHMZlFaf7j/n0i/76f/4qj9x/z6Rf99P/APFUcocxmUVp/uP+fSL/AL6f/wCKo/cf8+kX/fT/APxVHKHMZlFaf7j/AJ9Iv++n/wDiqP3H/PpF/wB9P/8AFUcocxmUVp/uP+fSL/vp/wD4qj9x/wA+kX/fT/8AxVHKHMZlFaf7j/n0i/76f/4qj9x/z6Rf99P/APFUcocxmUVp/uP+fSL/AL6f/wCKo/cf8+kX/fT/APxVHKHMZlFaf7j/AJ9Iv++n/wDiqP3H/PpF/wB9P/8AFUcocxmUVp/uP+fSL/vp/wD4qj9x/wA+kX/fT/8AxVHKHMZlFaf7j/n0i/76f/4qq1xbKqmSHcYx95WOSv8AiPf8PTI0FyrRRRUlHc/Hf/kq2v8A/bv/AOk8dFHx3/5Ktr//AG7/APpPHRWuN/3mp/if5nHln+5Uf8MfyQ/4Gf8AJWtC+tx/6Ikrg6734Gux+LGhDccZuOM/9MJK4Krf+7x/xS/KIof77U/ww/OYUUUVznablr4o1KDw1c+HI5tul3Fyt26DglwuMEjqpwpwc8opGOc5dRxd6nhiM0qRjOWOOBnFTUk5NXexdKEYJuKtfV+pJM32ew2H79wQceijofxNZ1Wr+YTXLbceXH8iYOeB71VrJgFFFFID6J/ZG+NX/CtfHS6JrWqfZvCGuZSb7RLtgtLnA8uc/KdudojY5UYYMxxGMfpfX4j1+lH7Ifxxk+JnhGTw7rd1NP4q0CNfMuLmZGkvrcsQkgHDEp8qOSDyUYsWcgDGj6Qr4H/ba+NX9taxB8PtA1Tfpmn5fWPs0uUmuQ3ywP8ALz5W3cQGI3PggNFx9MftIfGSL4OfD6e8t23eIdU32elxq8e6OUoc3BV87kj4J+VgWZFOA2R+V17e3OpXlxeXlxNc3lzI0s08zl5JXY5ZmY8kkkkk8kmhAyCiiigQVoWTefbS238YPmp7kDkflWfUttO1tPHKvVTnHqO4poCWtWDxRqVj4c1HQIZsabqMscs0bc8ocjbnhcnaSQMnYozgEGjdxCGdlTmM/Mp7EGqsv3R9a0hJxlowqwjUjaSvs/mtURUUUVZAVpDi0tQOAULH3O5hn8gPyrNrT/5dbT/rmf8A0NqqJMhlFWtM0641fUrPT7OMyXd5MkESD+J2IVR+ZFe2/EX4eWNvJoU1zpNz4d0XT9SGgXV9JYtD9phUKUvOQN7PiYluei+1O5J4RRXpVx4Rsba38QT2trd21qmjNcwme4tr5JGW6hjJSdE24w5ztCsp4JwSDqeF/CHhv+3fB1xb213q1nJf2CXk4u4JIGaUrujkg2F4gHJX59wcKQMZBBcDyGivUdH8GaB4h/t7WIoLi20uxuorSOxuNbtLaR5HEjFvtEyIgUCM4QIWOeuATU7+AvCOlm3F5fahqK3mtyaXBNpt1B5YiEcDiQsFdWZTPgqpwSOGXHJcDyeitaTw/dN4nfw/ajz703psYwBjzH37B+Zr3HxP8PobTxD4MnHhiTT9O0/XoNAn+02JiTUYlZClwwZQJPMxNuPPAUelFwPniivRPh9Y2lx8VjbTw2RtUa/IS6gEsCbIJipaMqwIUgHG09OhrX1ZdB13SNRa1n0261fTdGlnvLzS9NW2tpmN3AsYWN4k2sFdsuiITkDJG7JcDySivUPFvgvwvpE3imDTf7Yd/DV9HDO1zcRYuomkKMFxH+7YEABjuB5O0dKueKPDmhaj8UfEljpvhy+Gn2Es/wBojj1e2s4YiJAocSPAI4o+QoQ55Iw3YlwPI6K9U1b4f+HvDMXiG81N9RurayOmtaQ2d3BmRbqGSQq0yq6HbswHQENg4HzAjA+GVjZSaxfanqqQHStKs5J53nh85YmfEML+V0k2yyxkqeCAc+lFwOKorsPG/hfVNKKatqMemwR30xjtxYKEiuVVEJniVRt8tt68jA3EjaMEDvNI8JaP4o8BeErR7e1s7y3jl1S8vkjVZZbNbqWO43N1coojZQegDUXA8Tor1n4naLpV7DqfiKysYtNKxaIYrKzRY4EF1ZSSyfKB13Rrznuc5zxveFPDel6NrupaHPBLeaYviXQominZSZA4n4bKkFctyMcjI4zmi4HhFFegtoem6zpXiWXRrd7JYtRsreGLULq3YAuLjcTO0cYRcoOAVH97dgEa3gfS00fw/wCM2u7vw1a39nPYxpfahbRanboH84sqFIp1JbC8qP4cEjFFwPKKK9qsNN0D+w7/AFLWLJNUNxoNxdh9OSCyRWXVPK3Rf6PlcjGCy5VSy4AIC8rpvgnTdR1DwbEJLxIddsbm7mHmKWjMc1yihTt6bYEzkdSemQAXGef0V1/jPRtC8P2+k2tiuoyanc2FnfXE08yeSnnQLI0aoEyeWBDFuBxg/erkKBBRRRTAKkh580HkGJ8j1wpI/UA/hUdSwdZP+uUn/oBoQGVRRRWZodz8d/8Akq2v/wDbv/6Tx0U747Ow+KuvgMQP9H7/APTvHRWuN/3mp/if5nHln+5Uf8MfyQvwM/5K1oX1uP8A0RJXB13nwM/5K1oX1uP/AERJXB1T/wB3j/il+URQ/wB9qf4YfnMKKKKwO0li+6frVyFvs9tNcHrjy09dx757YFUVk2jGK0rq2WaK3jS6tgsSnO6Tncev4Vm073NOZWsZFFXv7N/6e7T/AL+f/Wo/s3/p7tP+/n/1qnlZNyjRV7+zf+nu0/7+f/WrZsfh/wCIdUtY7ux025urWTOyaCCR0bBIOGC4PII/CnGnKTtFXJnUhBXm7epzFdh8L/iLq3wr8a6Z4l0maYNbSKLm3jk2C8tywMkDEgjDAdSDtIDDlQQn/Cr/ABZ/0A9Q/wDASX/4muf/ALLb/n5tf+/n/wBanKlOPxKwoVYT+CSfoeh/Hz4yXvxo8dXGrbruHQbb9zpdhcOp+zxYAZiF4DuV3N94jhdzBFry2r/9lt/z82v/AH8/+tW5B8N/E91BFPBpF7LBKoeOSO2lZXUjIIIXBBHeiNKcvhVxzqwhrNpepylFdXcfDfxNaQS3FxpF7FBEpeSSS2lVUUDJJJXAAHesL+zf+nu0/wC/n/1qJU5x+JWFCrCesGn6FGir39m/9Pdp/wB/P/rUf2b/ANPdp/38/wDrVPKy7kit9osEb+O3O1s9Sp6c/piqr/cNX7K1W3lYvdWxjdCjbZOcH0rPkbazpwcEjKnINUkyuZWsRUUUVoZhWn/y62n/AFzP/obVmVftpRPEkB/1qZCf7QPO365yffP0BqJLL+jaxe+H9Tt9S06byL63JaKXarFCQRkAgjPPB7Hkc1Y0fxNqugRXUWnXZgjuzGZV2KwYo25T8wOCD6diQeCQcplKkqwII4IPakqiTo7/AMda9qKTRTXcSQTWxs2gt7WGGIRGRZCFRFCqS6KSQATjk0rePvEBtLe1W+WJIJIpRJDbxRyu0ZzGXkVQ8m08jcTiubopAdMnj/XYr+8vUlsle9VRcQjTrb7PNt5Vmh8vyywJJ3bc8nnmqdx4t1i68jzbwt9nvGv4/wB2nyzMEBYcdMRINvQbeB1rFooA1bPxJqen69/bttc+Xq3mvOLjy1JEjZywBGAeSRxweRjAp+h+KdW8N+b/AGZd+QJZIZXBjRwXikEkbYYHBDDP0JB4JBx6KANGw17UNM1V9Utbjy79xKDLsU58xWV+CMcq7DpxniorHVbvTYr6K1m8uO/g+zXA2g7496vt5HHzIpyMHj61TooA2L3xVq+oy6zLc3fmPrUglvT5aDzmD7weB8vzc/LitI/EbxE19Jevc2j3E0H2edn0+3YXKbg371THiVsqp3OGbIHNcrRQBv6x4213X47uPUb7z0uzbmUeUi7vIRki+6oxtV2HHXPOcCqeh+INR8N3j3Wm3AhlkjaGQNGsiSxnqjo4KspwOGBHArMooA3td8Z614ltLe01O6jmtrVy8ESW8UawZABVAijYhwDsXC55xnms671a8vrLT7K4m322no8dum0Dy1Zy7DIGTlmJ5z1qlRQB0tt4/wDEFpLJIl5E/mW0FoyTWsMsZjgQJF8joV3IoADY3dTnJNR3HjrxDdXl7eS6lI13e3UF7NMEUM00O7y3yBwRubpjOec1z1FAG3qfi3VdWjv47iS2WK/kiluI7e0hgWR4w4RsRooB/ePkjrnnPFUbfV7y10y90yKbbZXrxyTx7Qd7R7thzjIxvboec81SooA39O8a63pQtFt7qIx2ls9nHFNbRSxmF5DIyMjqVcF2LfMDzj0FWtL+I3iTRrVLaxvooo4zJ5R+yQs8QkzvVGKFkRsnKqQvJ4rlqKALmpard6vNDNezebJDBFbIdoXEcaBEXgDoqgZ6nHOap0UUwCiiigAqWDrJ/wBcpP8A0A1FTpn+yI6sCJ3UqFPVAepP1GRj3z6ZBmbRRRWZZ3Px3/5Ktr//AG7/APpPHRR8d/8Akq2v/wDbv/6Tx0Vrjf8Aean+J/mceWf7lR/wx/JEnwNC/wDC2NC5Oc3Hb/phJXBV3nwM/wCStaF9bj/0RJXB1b/3eP8Ail+URQ/32p/hh+cwooornO0KKKKACiiigAqxY393pd1Hd2N1Pa3Uedk0EhR1yCDhhyOCR+NV6KabTuhNJqzO6sfjL45061jtofEE7Rx5wZ4o5nOSTy7qWPXufauq/wCGlPFf/QP0T/vzL/8AHK8borqhjsRBWU395wVMqwVR3lSj91vyPZP+GlPFf/QP0T/vzL/8crnb/wCN/jm/+1L/AGz9nhuNw8u3gjTy1bPCtt3jAPB3bh655rz2iiWOxMlZ1H94qeU4Gm7xpR+6/wCZc1PV9Q1qdbjUr+6vZ1XYslzM0jBck4BYk4yTx7mqdFFcrbbuzvjFRVoqyCiiikUFFFFABRRRQAUUUUAWFvrpFCrczBQMABzgCl/tC7/5+p/+/hqtRTuxWLP9oXf/AD9T/wDfw0f2hd/8/U//AH8NVqKLsLFn+0Lv/n6n/wC/ho/tC7/5+p/+/hqtRRdhYs/2hd/8/U//AH8NH9oXf/P1P/38NVqKLsLFn+0Lv/n6n/7+Gj+0Lv8A5+p/+/hqtRRdhYs/2hd/8/U//fw0f2hd/wDP1P8A9/DVaii7CxZ/tC7/AOfqf/v4aP7Qu/8An6n/AO/hqtRRdhYs/wBoXf8Az9T/APfw0f2hd/8AP1P/AN/DVaii7CxZ/tC7/wCfqf8A7+Gj+0Lv/n6n/wC/hqtRRdhYs/2hd/8AP1P/AN/DR/aF3/z9T/8Afw1WoouwsWf7Qu/+fqf/AL+Gj+0Lv/n6n/7+Gq1FF2Fiz/aF3/z9T/8Afw0f2hd/8/U//fw1WoouwsWf7Qu/+fqf/v4aP7Qu/wDn6n/7+Gq1FF2Fiz/aF3/z9T/9/DVaiii4BRRRSGd38dgv/C1dfyTn/R+3/TvHRTfjv/yVbX/+3f8A9J46K1xv+81P8T/M48s/3Kj/AIY/kjD+H/iJfCnjvR9WkZFggudszurMEifKSNheSQrMRjPIHB6UeNPDzeFfFWraOyuEtJ2WLzGVmaI/NGxK8ZKFT269B0rmJP8AWP8AU16FpfibQvE+hab4f8Us+n3GnK0dpr8atOyRZ3CGWLqyDLBSp+X5QABuJdKSnB0m7a3X5NfPTXbQVaMqVVYiKbTVpW3stU7dbXei1102s+Hor0IfBjxNefvNEfS9dtR8rXOmX8Txo/dCWKncBg9OjCj/AIUb49/6AP8A5Nwf/F1f1PEdIP7mL+0sH1qxXq0vwZ57RXoX/CjfHv8A0Af/ACbg/wDi6P8AhRvj3/oA/wDk3B/8XR9TxH/PuX3MP7TwX/P6P/gS/wAzz2ivQv8AhRvj3/oA/wDk3B/8XR/wo3x7/wBAH/ybg/8Ai6PqeI/59y+5h/aeC/5/R/8AAl/mee0V6F/wo3x7/wBAH/ybg/8Ai6P+FG+Pf+gD/wCTcH/xdH1PEf8APuX3MP7TwX/P6P8A4Ev8zz2ivQv+FG+Pf+gD/wCTcH/xdH/CjfHv/QB/8m4P/i6PqeI/59y+5h/aeC/5/R/8CX+Z57RXoX/CjfHv/QB/8m4P/i6P+FG+Pf8AoA/+TcH/AMXR9TxH/PuX3MP7TwX/AD+j/wCBL/M89or0L/hRvj3/AKAP/k3B/wDF0f8ACjfHv/QB/wDJuD/4uj6niP8An3L7mH9p4L/n9H/wJf5nntFehf8ACjfHv/QB/wDJuD/4uj/hRvj3/oA/+TcH/wAXR9TxH/PuX3MP7TwX/P6P/gS/zPPaK9C/4Ub49/6AP/k3B/8AF0f8KN8e/wDQB/8AJuD/AOLo+p4j/n3L7mH9p4L/AJ/R/wDAl/mee0V6F/wo3x7/ANAH/wAm4P8A4uj/AIUb49/6AP8A5Nwf/F0fU8R/z7l9zD+08F/z+j/4Ev8AM89or0L/AIUb49/6AP8A5Nwf/F0f8KN8e/8AQB/8m4P/AIuj6niP+fcvuYf2ngv+f0f/AAJf5nntFehf8KN8e/8AQB/8m4P/AIuj/hRvj3/oA/8Ak3B/8XR9TxH/AD7l9zD+08F/z+j/AOBL/M89or0L/hRvj3/oA/8Ak3B/8XR/wo3x7/0Af/JuD/4uj6niP+fcvuYf2ngv+f0f/Al/mee0V6F/wo3x7/0Af/JuD/4uj/hRvj3/AKAP/k3B/wDF0fU8R/z7l9zD+08F/wA/o/8AgS/zPPaK9C/4Ub49/wCgD/5Nwf8AxdH/AAo3x7/0Af8Aybg/+Lo+p4j/AJ9y+5h/aeC/5/R/8CX+Z57RXoX/AAo3x7/0Af8Aybg/+Lo/4Ub49/6AP/k3B/8AF0fU8R/z7l9zD+08F/z+j/4Ev8zz2ivQv+FG+Pf+gD/5Nwf/ABdH/CjfHv8A0Af/ACbg/wDi6PqeI/59y+5h/aeC/wCf0f8AwJf5nntFehf8KN8e/wDQB/8AJuD/AOLo/wCFG+Pf+gD/AOTcH/xdH1PEf8+5fcw/tPBf8/o/+BL/ADPPaK9C/wCFG+Pf+gD/AOTcH/xdH/CjfHv/AEAf/JuD/wCLo+p4j/n3L7mH9p4L/n9H/wACX+Z57RXoX/CjfHv/AEAf/JuD/wCLo/4Ub49/6AP/AJNwf/F0fU8R/wA+5fcw/tPBf8/o/wDgS/zPPaK9C/4Ub49/6AP/AJNwf/F0f8KN8e/9AH/ybg/+Lo+p4j/n3L7mH9p4L/n9H/wJf5nntFehf8KN8e/9AH/ybg/+Lo/4Ub49/wCgD/5Nwf8AxdH1PEf8+5fcw/tPBf8AP6P/AIEv8zz2ivQv+FG+Pf8AoA/+TcH/AMXR/wAKN8e/9AH/AMm4P/i6PqeI/wCfcvuYf2ngv+f0f/Al/mee0V6F/wAKN8e/9AH/AMm4P/i6P+FG+Pf+gD/5Nwf/ABdH1PEf8+5fcw/tPBf8/o/+BL/M89or0L/hRvj3/oA/+TcH/wAXR/wo3x7/ANAH/wAm4P8A4uj6niP+fcvuYf2ngv8An9H/AMCX+Z57W74M8PN4q8VaTo6q5S7nVZfLZVZYh80jAtxkIGPfp0PSulPwY8TWf7zW30vQrU/Ktzqd/Ekbv2QFSx3EZPTopqrqnibQvDGhal4f8LM+oXGoqsd3r8itAzxZ3GGKLqqHChix+b5gQRtIaoOm+aurJdHu/K2+vfZEzxka0XDCvmk+q1S829tO17vp1awviL4iXxX431vVo2RoJ5ysLorKHiQBI2w3IJVVJzjkngdKK5iiuOpN1JOct3qdtKlGlTjTjskkvkSSSOHYBm6nvTfMf++350UVJoHmP/fb86cJH2MdzdR3+tFFADfMf++350eY/wDfb86KKADzH/vt+dOkkcOwDN1PeiigBvmP/fb86PMf++350UUAOEj7GO5uo7/Wm+Y/99vzoooAPMf++350eY/99vzoooAdJI4dgGbqe9N8x/77fnRRQAeY/wDfb86cJH2MdzdR3+tFFADfMf8Avt+dHmP/AH2/OiigA8x/77fnTpJHDsAzdT3oooAb5j/32/OjzH/vt+dFFADhI+xjubqO/wBab5j/AN9vzoooAPMf++350eY/99vzoooAdJI4dgGbqe9N8x/77fnRRQAeY/8Afb86cJH2MdzdR3+tFFADfMf++350eY/99vzoooAPMf8Avt+dOkkcOwDN1PeiigBvmP8A32/OjzH/AL7fnRRQA4SPsY7m6jv9ab5j/wB9vzoooAPMf++350eY/wDfb86KKAHSSOHYBm6nvTfMf++350UUAHmP/fb86cJH2MdzdR3+tFFADfMf++350eY/99vzoooAPMf++3506SRw7AM3U96KKAG+Y/8Afb86PMf++350UUAOEj7GO5uo7/Wm+Y/99vzoooAPMf8Avt+dFFFAH//Z",
	"marah": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4lkkcOwDN1Pem+Y/99vzok/1j/U138ssXw8ht7W1t0Hi4Lvurt/3i2gbBEcYI2ltuMtg43MATnjac2moxV2/6+41w2GVVSqVJcsI2u7X32SXVvWyutm20kZVj8O/FuowtLDpFyqhtuJ2WFs8fwuQcc9elWx8LPGO0/wDErbOR/wAvUX/xdc7e6jeanKJb27nuZVXaHnkLsB1xk9uT+dVqXJX/AJl9z/zN/aZctPZzf/b8V+Hs3+bOp/4VZ4y/6Bbf+BUX/wAXR/wqzxl/0C2/8Cov/i65aij2df8AnX/gL/8Akg9rl3/Pqf8A4Mj/APKzqf8AhVnjL/oFt/4FRf8AxdOf4WeMSzY0tsZ4/wBKi/8Ai65Sij2df+df+Av/AOSD2uXf8+p/+DI//Kzqf+FWeMv+gW3/AIFRf/F0f8Ks8Zf9Atv/AAKi/wDi65aij2df+df+Av8A+SD2uXf8+p/+DI//ACs6sfCzxjtP/ErbOR/y9Rf/ABdN/wCFWeMv+gW3/gVF/wDF1y1FHs6/86/8Bf8A8kHtcu/59T/8GR/+VnU/8Ks8Zf8AQLb/AMCov/i6P+FWeMv+gW3/AIFRf/F1y1FHs6/86/8AAX/8kHtcu/59T/8ABkf/AJWdW/ws8YlmxpbYzx/pUX/xdN/4VZ4y/wCgW3/gVF/8XXLUUezr/wA6/wDAX/8AJB7XLv8An1P/AMGR/wDlZ1P/AAqzxl/0C2/8Cov/AIunD4WeMdp/4lbZyP8Al6i/+LrlKKPZ1/51/wCAv/5IPa5d/wA+p/8AgyP/AMrOp/4VZ4y/6Bbf+BUX/wAXR/wqzxl/0C2/8Cov/i65aij2df8AnX/gL/8Akg9rl3/Pqf8A4Mj/APKzqf8AhVnjL/oFt/4FRf8AxdOf4WeMSzY0tsZ4/wBKi/8Ai65Sij2df+df+Av/AOSD2uXf8+p/+DI//Kzqf+FWeMv+gW3/AIFRf/F0f8Ks8Zf9Atv/AAKi/wDi65aij2df+df+Av8A+SD2uXf8+p/+DI//ACs6sfCzxjtP/ErbOR/y9Rf/ABdN/wCFWeMv+gW3/gVF/wDF1y1FHs6/86/8Bf8A8kHtcu/59T/8GR/+VnU/8Ks8Zf8AQLb/AMCov/i6P+FWeMv+gW3/AIFRf/F1y1FHs6/86/8AAX/8kHtcu/59T/8ABkf/AJWdW/ws8YlmxpbYzx/pUX/xdN/4VZ4y/wCgW3/gVF/8XXLUUezr/wA6/wDAX/8AJB7XLv8An1P/AMGR/wDlZ1P/AAqzxl/0C2/8Cov/AIunD4WeMdp/4lbZyP8Al6i/+LrlKKPZ1/51/wCAv/5IPa5d/wA+p/8AgyP/AMrOp/4VZ4y/6Bbf+BUX/wAXR/wqzxl/0C2/8Cov/i65aij2df8AnX/gL/8Akg9rl3/Pqf8A4Mj/APKzqf8AhVnjL/oFt/4FRf8AxdOf4WeMSzY0tsZ4/wBKi/8Ai65Sij2df+df+Av/AOSD2uXf8+p/+DI//Kzqf+FWeMv+gW3/AIFRf/F0f8Ks8Zf9Atv/AAKi/wDi65aij2df+df+Av8A+SD2uXf8+p/+DI//ACs6sfCzxjtP/ErbOR/y9Rf/ABdN/wCFWeMv+gW3/gVF/wDF1y1FHs6/86/8Bf8A8kHtcu/59T/8GR/+VnU/8Ks8Zf8AQLb/AMCov/i6P+FWeMv+gW3/AIFRf/F1y1FHs6/86/8AAX/8kHtcu/59T/8ABkf/AJWdW/ws8YlmxpbYzx/pUX/xdN/4VZ4y/wCgW3/gVF/8XXLUUezr/wA6/wDAX/8AJB7XLv8An1P/AMGR/wDlZ1P/AAqzxl/0C2/8Cov/AIunD4WeMdp/4lbZyP8Al6i/+LrlKKPZ1/51/wCAv/5IPa5d/wA+p/8AgyP/AMrOp/4VZ4y/6Bbf+BUX/wAXR/wqzxl/0C2/8Cov/i65aij2df8AnX/gL/8Akg9rl3/Pqf8A4Mj/APKzqf8AhVnjL/oFt/4FRf8AxdOf4WeMSzY0tsZ4/wBKi/8Ai65Sij2df+df+Av/AOSD2uXf8+p/+DI//Kzqf+FWeMv+gW3/AIFRf/F0f8Ks8Zf9Atv/AAKi/wDi65aij2df+df+Av8A+SD2uXf8+p/+DI//ACs6G++HfizTrfzJtIuWDOFAgZZm6HshJA469K5TzH/vt+dadlqN5pkplsrue2lZdpeCQoxHXGR24H5V1kUsXxDhuLW6t0Pi4rvtbtP3a3YXJMcgA2htucNgZ2qCRjlSlUpq87Nd1pb5a6fMqNDDYp8mGvGfRSalfyTSWr6Ll12ve1+A8x/77fnRTaK2PMOs+HdjHqPjzSIZWcKs5mBQ87o1Lj8MqM+1ZGo3smp6hd3soVZbmV5nCDCgsSTjPbmui+FgX/hYWl8nOZu3/TJ65Ssofx5ei/Nno1NMup26zn+Eadvzf3ntnwo17w5p/h5oZLm1stRDk3LXDiMy8nYQSeQF4wOhzxzk95/wlmgf9BzTP/AuP/GvleiuOtlMKtR1HJ6n0OA4zr4PDQw8aUWoq3Vf0+/d6n1R/wAJZoH/AEHNM/8AAuP/ABo/4SzQP+g5pn/gXH/jXyvRWX9iU/52df8Ar9iP+fMfvZ9Uf8JZoH/Qc0z/AMC4/wDGj/hLNA/6Dmmf+Bcf+NfK9FH9iU/52H+v2I/58x+9n1R/wlmgf9BzTP8AwLj/AMaP+Es0D/oOaZ/4Fx/418r0Uf2JT/nYf6/Yj/nzH72fVH/CWaB/0HNM/wDAuP8Axo/4SzQP+g5pn/gXH/jXyvRR/YlP+dh/r9iP+fMfvZ9Uf8JZoH/Qc0z/AMC4/wDGj/hLNA/6Dmmf+Bcf+NfK9FH9iU/52H+v2I/58x+9n1R/wlmgf9BzTP8AwLj/AMaP+Es0D/oOaZ/4Fx/418r0Uf2JT/nYf6/Yj/nzH72fVH/CWaB/0HNM/wDAuP8Axo/4SzQP+g5pn/gXH/jXyvRR/YlP+dh/r9iP+fMfvZ9Uf8JZoH/Qc0z/AMC4/wDGj/hLNA/6Dmmf+Bcf+NfK9FH9iU/52H+v2I/58x+9n1R/wlmgf9BzTP8AwLj/AMaP+Es0D/oOaZ/4Fx/418r0Uf2JT/nYf6/Yj/nzH72fVH/CWaB/0HNM/wDAuP8Axo/4SzQP+g5pn/gXH/jXyvRR/YlP+dh/r9iP+fMfvZ9Uf8JZoH/Qc0z/AMC4/wDGj/hLNA/6Dmmf+Bcf+NfK9FH9iU/52H+v2I/58x+9n1R/wlmgf9BzTP8AwLj/AMaP+Es0D/oOaZ/4Fx/418r0Uf2JT/nYf6/Yj/nzH72fVH/CWaB/0HNM/wDAuP8Axo/4SzQP+g5pn/gXH/jXyvRR/YlP+dh/r9iP+fMfvZ9Uf8JZoH/Qc0z/AMC4/wDGj/hLNA/6Dmmf+Bcf+NfK9FH9iU/52H+v2I/58x+9n1R/wlmgf9BzTP8AwLj/AMaP+Es0D/oOaZ/4Fx/418r0Uf2JT/nYf6/Yj/nzH72fVH/CWaB/0HNM/wDAuP8Axo/4SzQP+g5pn/gXH/jXyvRR/YlP+dh/r9iP+fMfvZ9Uf8JZoH/Qc0z/AMC4/wDGj/hLNA/6Dmmf+Bcf+NfK9FH9iU/52H+v2I/58x+9n1R/wlmgf9BzTP8AwLj/AMaP+Es0D/oOaZ/4Fx/418r0Uf2JT/nYf6/Yj/nzH72fVH/CWaB/0HNM/wDAuP8Axo/4SzQP+g5pn/gXH/jXyvRR/YlP+dh/r9iP+fMfvZ9Uf8JZoH/Qc0z/AMC4/wDGj/hLNA/6Dmmf+Bcf+NfK9FH9iU/52H+v2I/58x+9n1R/wlmgf9BzTP8AwLj/AMaP+Es0D/oOaZ/4Fx/418r0Uf2JT/nYf6/Yj/nzH72fVH/CWaB/0HNM/wDAuP8Axo/4SzQP+g5pn/gXH/jXyvRR/YlP+dh/r9iP+fMfvZ9Uf8JZoH/Qc0z/AMC4/wDGj/hLNA/6Dmmf+Bcf+NfK9FH9iU/52H+v2I/58x+9n1R/wlmgf9BzTP8AwLj/AMaP+Es0D/oOaZ/4Fx/418r0Uf2JT/nYf6/Yj/nzH72fQPxA8SeGLvwtewy3tnfSupFvHBKsjrLg7W+U8Adz6ZHOcHwfTr2TTNQtL2IK0ttKkyBxlSVIIzjtxVaiu/C4SOHg4J3TPms3zqrmeIjiJRUXFWVvv3N34kWMeneONahiZyrSiYlzzukUOfwyxx7UVc+KwX/hPtXyTn9z2/6YpRTwzbowb7L8jnzaKhj68Y7Kcv8A0ph8LP8Akoel/Wb/ANFPXLV1Pws/5KHpf1m/9FPXLU6f8efpH85Dq/8AIuo/46n/AKTTCiiiuk80KKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKK2NL0uF7b7dfeYbMu0SRwsFeVwAW+YghQoZSSQc5AA6lU3YunTc3ZfN9v6/wCAtTHorqftWm/9C/p//fy4/wDjtH2rTf8AoX9P/wC/lx/8dpXl/K/w/wAzX2NP/n7H/wAm/wDkTlqK6n7Vpv8A0L+n/wDfy4/+O0fatN/6F/T/APv5cf8Ax2i8v5X+H+Yexp/8/Y/+Tf8AyJy1FdT9q03/AKF/T/8Av5cf/HaPtWm/9C/p/wD38uP/AI7ReX8r/D/MPY0/+fsf/Jv/AJE5aiup+1ab/wBC/p//AH8uP/jtH2rTf+hf0/8A7+XH/wAdovL+V/h/mHsaf/P2P/k3/wAictRXU/atN/6F/T/+/lx/8do+1ab/ANC/p/8A38uP/jtF5fyv8P8AMPY0/wDn7H/yb/5E5aiup+1ab/0L+n/9/Lj/AOO0fatN/wChf0//AL+XH/x2i8v5X+H+Yexp/wDP2P8A5N/8ictRXU/atN/6F/T/APv5cf8Ax2j7Vpv/AEL+n/8Afy4/+O0Xl/K/w/zD2NP/AJ+x/wDJv/kTlqK6dtPstadLe0s1stQkIWFYpGaGU9lIcllYk4DbtvQEDJYcxTTvo1YzqUuRJp3T6q/62YUVs6VpUD2v9oah5psjI0McUDhZJnABb5iCFChlJJBzkADqV0/tmmf9C5pv/f25/wDj1TKoouxwTxajK0YuXpb9Wv68zk6K6z7Zpn/Quab/AN/bn/49R9s0z/oXNN/7+3P/AMeqfbRI+uf9O5f+S/8AyRydFdZ9s0z/AKFzTf8Av7c//HqPtmmf9C5pv/f25/8Aj1Htoh9c/wCncv8AyX/5I5Oius+2aZ/0Lmm/9/bn/wCPUfbNM/6FzTf+/tz/APHqPbRD65/07l/5L/8AJHJ0V1n2zTP+hc03/v7c/wDx6j7Zpn/Quab/AN/bn/49R7aIfXP+ncv/ACX/AOSOTorrPtmmf9C5pv8A39uf/j1UtR0u1urWe+06N4fs4D3Ns77gqlgodGIzt3MF2nLDIOWyxVxqxbsVDFptKUWr97fo2YFFFFaHYdP8V/8Akf8AV/8Atj/6JSij4r/8j/q//bH/ANEpRXJhf4EPRfkennH/ACMMR/jl/wClMd8LP+Sh6X9Zv/RT1y1dX8LHY/ELSxuOMzcZ/wCmT1ylVT/jy9I/nIVX/kXUv8dT/wBJphRRRXSeaFFFFABRT4YZLiWOKKNpJZGCoiDLMTwAAOpr0aH4e6b4ZtYdQ8X3+zfzHYWvzPIQA20t+anGAMj5xmsqteFKylu9kt2d2Dy6vjOaVNJRjvJu0V6t/wDDnBaZpV7rN0trYWstzO2PljXOBkDJPQDJHJ4Ga7a0+EWppAl1rF/Y6XaDPmtLJuaPnAz0Xk4/i7+vFPu/iTPZxLY+GLGDSbFGyCsavLJjjLZBGSNuepyPvGuTupr/AFSVZr26mnkChQ88hdgvXGT9Tx71lbE1drQX3v8AyX4nb/wlYVWlzVpevLD/AOSf/kv6nYjwt4Bsf9HvvE11NdJ9+S1T92c8jGEcdCP4jznp0p39qfDX/oXtS/7+N/8AHa4kWa45Yk+1PFtHj7v61X1Jv4qkn87fkT/bUYaUsNTS848z++Tf36X6nZ/2p8Nf+he1L/v43/x2mnQvh3qHNvrd9Zz3H+rjlUlIGboGJToCefn7fe71x32aL+7+pphtFxwzA+9H1Fr4akl87/ncP7bUtKmHpNf4OX8YtHXzfCO6uonn0PWdP1S3RTkq+1i452DG5c4x1Yde3WuM1nw/qfh+cQalZy2zt90sMq/AJ2sOGxkZweM1LB9qsJ1ntJ5Ipkztkico65GDgjpwSK6nTviXqkERtNYgg1ewKqrQXSDdhenzY5OcElgx47HmpccTT6qa+5/5fkVz5VilZxlRl3T54/NP3l8m/mef0V6aPBXh7xmskvhS+azvEXc+n3ucAZAyG5IHBJwX5YD5a871DT7nSr2azvIWhuYW2vG3UH+o7gjgjmtKWIhUbitGt09zjxmW1sJFVJWlCW0ou8X8+j8nZ+RWooorY4AooooAK6m6/wCQR4f/AOvN/wD0omrlq6mch9F0JlO5VtpI2I5AcTyMVPvh1OPRge4qX8UfX9GdFH+HV/w/+3RItPtft1/a2u/Z58qx7sZ25IGcfjXTS+CY31K+0yy1Fp9RtFLeVLB5YlAAJ2sGPPPfFc3plyllqVncyBjHBMkjBepAYE4/Kuvfxfplpruoa5ZR3ct9cKVijmjVEiJAGSQxLdPassRKspfuu343W56GW08DKlfFWvzK+ruo2d2knq72to/uMSLw7FFo9vqmo3jW0F05SFI4vMd8dWIyAB+P4Vo2/gOSTWWsJb1VhNqbyK4jj3iROMcEjB59aq/27Y6loNlpmpC5jexdjFPbqr7lY5KlSR+efwrXtvHVmuuC4kt549PhsTZQogDuBxhjkgdv5VlUlideXfXt8rHXh6WVNw9pa3udXdu3v82uiT2tbpZvUwJ/Dqvo7arp10bq1ikEUqPF5ckZOMZGSCDkdD3q+3g2KDUrfSbnU1i1WdQREIS0aMRwrPnOT7A1A2v2mn6BNpWmLcObmVZZridVQ/KQQFUE45A71fm8U6Te67a69cwXa30IVnt4wpjd1HB3k5A4HGDTlLEa2vbW2iv0tf8AH8LkU6WW6c1ub3OZXlyrWXPZ3u2ly9Xu7XKNt4PnNnfXV480aWdwbZ0t4POfeOpxkALyOc0zTPDVrqUerzrqMgtNOjWQuttlpAQcjaWGCMY61YsPFRivLu/bUL+zurmdpXS2jSSJlPQFWYcjkZ54xWmnjqyfUPEFxsu7P+0o0SKS2UF4yoI3H5l557GpnPFK9vLbpqr9NeuuvoaUaOUy5G3be929dJWd1JW15bppa9bXMmfwVcHU9Ks7SdZhqUInid12FFxk7lycYHuajHheC7i1E6bqP2qfT1LyxvD5e9R1KHcc498VpS+OYodV0a9t4ZbiSwiMU09xhZLgEY5wTjHOOT1qpbeINM0ZNVk0yO7e5v42hXz1VVgRjzyCdx/LpTUsVZX3+XfW/wArdvvFKllXO+Vq13fV3S5Fbl11fNdPfp01I4fDmmz6Hcauup3YtoJREymyXeScdB5uMc+tc6sJnuRDb7pC77I8rhmycDjJwfxratdct4PCN9pDJKbme4WZWAGwAY6nOc8elQeF9Rs9I1mC+vo5ZY7fLokYBJfHy5yRwDz+FbwdWKm5Xdttux59aGEqzoQp2gmlzO70d3fdvZWZoeKvBr+GYbeZbxbuORjG5VNvluADt6nPf8qoeJ9A/wCEc1FbP7R5+6JZN+zb17YyfStWXxfBqWj6tY31kscl1J9pie23NibPJbe5wDwOPfiqPjDXLfxBqyXdskqRiFI8SgA5GfQms6EsRzRjV6Xu9NdrfqjpzCnlvs6lTC2u+XlV3dfEpLXfaL176HP1H4s/5GrXP+v6f/0Y1TxRPPIkUSM8jkKqKMliegA7mqvieaO48S6zLFIskUl5MyOhyrAuSCCOoron/EXo/wBDyqf+7z/xR/KRr3n/ACBvDn/Xk/8A6Uz1ShhkuZo4YUaSWRgiIoyWJOABVy5IfQ/D7qdyJayRMw5AcXErFT77XQ49GB7in+H9U/sPXdN1Ix+YLO4SYp/eCsDiuSfxM8BNqM3FXd5fmzvrj4DeKINJN4Gs5LhV3mzSQmT6A42k+2fxrznTtPuNU1C2sLZN1zcyLFGp4yxOB9K+qLj4yeEYdKN8mpCV9mVtVRhKW/u4xx9envXzFY69Pp/iOHW4kTz4rn7SE/hzu3bfp2qEeRlWLx1eNT6xCzW11bXXQ6tPhrBda3d+H7PXFn1+2RmMBtisMjqMsiybskjnqoHFQp8NLmbwF/wlEF3vlQuZLExYZURyrMGzzjgkYGAfatO38eeH9N8V3viyztdQbVJ1do7OVUEMUrjDMZA2WHJ42jr1qHTviXHpmh+HLaOGeS70+6nlvFdV8qeKUtuQc85Ddx1o1Kc8faPJ/dvdLs+Zel7K/nuxV+FG7xM2i/2v93TP7R877N9Pk27/AH65/Cuc8E+Ev+Ex1O6svtn2XyLWS53+Xv3bcfLjI65613T/ABR0I+Op9ZS11BNOfSjp6p5aGRWz1xvxjHvmud8G+JNA8G6xcXkc+p3kVxZTW7BrOOJlZiu0j962Rwc9McdewOFXG+ylzJ83KraLfW/S3bf5EUXw3uLrwAviq2vRK4Ls9l5WGWNHKs4bdzjgnjoa0YvhQr+KTojawVUaaNRM4tcnHHybd/v1z+FRaT8R4NG8PeGbG3gne40y5me6R1Xyp4ZCdyDnJyD3HWt3/hamhr48l1yK31GKwOl/YUVY081GyMHG/GAB65o1IqVMwTmorT3raLv7q+7Vd767HlmpRaZEY/7Ou7u4BzvNzarDt9MbZHz39Kl0L/j6uv8ArwvP/SaSrPiTU11N7dxreraqyAgtqUe0xjjAX96+c856dO9VtEISa9lY7Y0sLvc54C7oHRcntlmVR6lgOpqo7o9OTbw7vvZ/1svyOQooortPcOn+K/8AyP8Aq/8A2x/9EpRTvis7Dx9q4DED9z3/AOmKUVyYX+BD0X5Hp5x/yMMR/jl/6Uw+Fn/JQ9L+s3/op65aup+Fn/JQ9L+s3/op65aqp/x5+kfzkKr/AMi6j/jqf+k0wooorpPNCtLQtCvfEepRWFhFvmfkseFjXuzHsB/9YZJAqtp+n3Oq3sNnZwtNczNtSNepP9B3JPAHNema3qMfw60iPw9pG1dYuYlkv71HyysR91TwQeuMgYUgjlsjnr1nFqnT1k/w835HqZfgYVYyxOJbjShu1u30jHzf4LVhc6no3w2ivNP0MteeIHURzX0iqUhP8SqPUEZ288kbiduK4O6nutYvJr29meWeZtzyN1b/AAGOB2HaoYLcEB26dhVl5FjGWP4etaUMNGleT1k929/+G8jLHZlUxdqcVy04/DFbL/N929WCRrGMKP8A69DyJH95gKpSXTvwPlHt1qCtXVS2OJUu5eN5GDj5j7gUz7b/ANM/1qpRUOrIr2cS39t/6Z/rTxeIcZDCqNFHtJB7OJppKj/dYE+lOZQ4wwBFZVSx3Dx8ZyvoatVe5Lpdix5ctrIk1vI6yRsGVkOGUjoQR3zXd2XizTPGVlDpHi/ctwJcwalEFQx56huMKOAM4IIwSBt3VxMUyyjIPPcVHPbhsuvB7j1rOth4Vkn1WzW6OvA5jWwbcY6xl8UXrGXqvye66MseLPCd74S1I2t0N8L5aC4UYWVf6EcZHb3BBODXpvg3XrfxBaJ4R8QL51nN8tpcFgHgcA7QCfyX67cEHA4TXdCvfDmpS2F/FsmTkMOVkXsynuD/APWOCCKxo1ZczpVfiX4rv/mdOPwdL2axmEv7KTtZ7wl/K31/uvqvNMzaKKK6TyQrT0zVhaI1tdQtcWLHf5SvsZH/ALyNg7ScAHgggDIyFIzKKTSe5UJyg7xOm+0aB/z/AGp/+AMf/wAeo+0aB/z/AGp/+AMf/wAermaKVpfzP8P8jb21P/n1H/yb/wCSOm+0aB/z/an/AOAMf/x6j7RoH/P9qf8A4Ax//Hq5mii0v5n+H+Qe2p/8+o/+Tf8AyR032jQP+f7U/wDwBj/+PUfaNA/5/tT/APAGP/49XM0UWl/M/wAP8g9tT/59R/8AJv8A5I6b7RoH/P8Aan/4Ax//AB6j7RoH/P8Aan/4Ax//AB6uZootL+Z/h/kHtqf/AD6j/wCTf/JHTfaNA/5/tT/8AY//AI9R9o0D/n+1P/wBj/8Aj1czRRaX8z/D/IPbU/8An1H/AMm/+SOm+0aB/wA/2p/+AMf/AMeo+0aB/wA/2p/+AMf/AMermaKLS/mf4f5B7an/AM+o/wDk3/yR032jQP8An+1P/wAAY/8A49R9o0D/AJ/tT/8AAGP/AOPVzNFFpfzP8P8AIPbU/wDn1H/yb/5I6GbWbKxXOlfaZLo/durhVjMX+6gLfN6Pu4zwoIDVz1FFNRsZ1KjnZWsl0W39eb1NTS9XWzja2u4WubBm3+Usmx0fH3kYg7ScAHgggDIyFK6nn+Hf+ghqv/gvj/8Aj9cvRUypxlqziqYWMpcybXpb9UzqPP8ADv8A0ENV/wDBfH/8fo8/w7/0ENV/8F8f/wAfrl6KXsokfU/77/D/ACOo8/w7/wBBDVf/AAXx/wDx+jz/AA7/ANBDVf8AwXx//H65eij2UQ+p/wB9/h/kdR5/h3/oIar/AOC+P/4/R5/h3/oIar/4L4//AI/XL0UeyiH1P++/w/yOo8/w7/0ENV/8F8f/AMfo8/w7/wBBDVf/AAXx/wDx+uXoo9lEPqf99/h/kdR5/h3/AKCGq/8Agvj/APj9UNS1iFoHs9NjlitXx50krAyXGDxnHCrkBtgJ56s2FxjUU1TincqGFjFqUm3bvb9EvxCiiirOo6f4r/8AI/6v/wBsf/RKUUfFf/kf9X/7Y/8AolKK5ML/AAIei/I9POP+RhiP8cv/AEpknwsC/wDCwtL5Oczdv+mT1yldT8LP+Sh6X9Zv/RT1y1VT/jy9I/nIVX/kXUv8dT/0mmFFFbfhLw/J4n1+009Qwidt0zr/AARjljnBwewzxkj1rec1CLlLZHFQozr1I0qavKTsvVna+F4LTwP4V/4Sa7hifW73K6fDMTwnA3BcZ6Eknuu0AjdzwaCS6meedmkd2LM7nJdieST3rovHmuJruvmCzKrpliPs1skeNgVerAAkYJHBGMqF9KxlUIoUdBWWDpOzqz+KX4Lovl+Z6Ob4mHNHB0P4dLRW+0/tSfq9vJISRxGhY/8A66zXdpGLMeanvHy4QHgdfrVatakrux5tONlcKKKKzNAooooAKKKKACiiigBVYqQQcEVowyiVM8bu4rNqa1fZKBnhuK0pys7Gc43RNcw/xqPrXoBEHxG8ISb0U+KNHi+QqzGS5iXHUYJYnkY5+bByA2DxJGRg9Ks+Gtbk8LeILW+UuYVO2VF/jjPDDGRk9xnjIBqMXRc488Pijqv8vmd2U4yFGo6VfWnU92Xp0kvOL1RzFFdb8RPD0eh6+0toFOmagv2m2eP7mG5KggAYB6AZwpX1rkqqlUVSCnHqcuLw08LXnQqbxdv+D6PdBRRXtXwN/Z+/4XRofi7U/wDhIv7J/wCEejjk8v7F5/n7lkbGfMXbjy8dD19qtu2rOc8Vor3X4bfs2XPivwHqXjzxZ4ii8IeErVN8F5c2hne65wSke9DjPAOSWPABrxG8S3ju50s5pZrRXYRSyxiN3TPBZQzBSR2ycepoTTAgooooAKKKKACivY/E/wACP+Ec+Bfhz4n/ANv+f/bNwtv/AGZ9j2+TnzefN8w7v9V02j73tz45QmnsAUV73oP7N9mvwz0vx7438d2XhXSNYkEdipsJbx5C24ruCEbchGPGeOuOleOeKtFt/Duv3um2mr2WsWsDL5d/ZEmGdSoYEZAIPOCD0II7Uk0wMeitvwjpmjaz4isrHxBrv9g6PMW8/Uvsj3XkYQlf3SEM2WAXjpuz2r6M0H9lPwP4m8Far4z0r4x/aPDWktIt3ef8IzOnlFFV2+RpQ5wrqeFPWhyS3Cx8sUV2XxC8OeEfDl5ZReEfG3/CV28sbNPN/ZUtj5DA8LtkJLZHORXG0wCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA6n4rBf+E+1fJOf3Pb/pilFN+K//ACP+r/8AbH/0SlFcmF/gQ9F+R6ecf8jDEf45f+lMd8LP+Sh6X9Zv/RT1y1dT8LP+Sh6X9Zv/AEU9ctVU/wCPP0j+chVf+RdR/wAdT/0mmFen/D1l0DwX4l8RKf8ASh/osJWNS0TYGDk9i0ikj/Y79K8wr0zxWP7K+HPhLTP9Z9pzeeb025Bbbjv/AK7Gc/w9OeJxa5+Sl/M/wWr/ACOnJH7F1sZ/z7g7f4pWivzv8um5w1omSzkdOBVuo4F2xL055qSvRWx4LIJII3kyzEM3ak+xx+rfnUd63zIvcDNdV8LdU8O2Hj7w9ceMVlfw5BdpJdeXEsvA5XehB3x7gu8AElNwAJxWMpRTd0axjJpWZ9C/BH9kHS/HHguDxJ4t1HVrP+0v3lla2W2J1hBIDyGSNs7+GXaMbcHJ3YX0r/hhj4d/9BnxT/4FW/8A8Yr07xr8QvFOn6RoXiLwN4Q/4TDQL6wlvZxFdC1nVCsTwOiuCz7kMn7sIWJ29Dw0Hgz9ofwF4z1JNHTU5dI8QmRoX0jWYTa3Ecok8vyjn5DIWIwisW56ZBA8aVWrJuS2/I9SNOnFKLPOP+GGPh3/ANBnxT/4FW//AMYo/wCGGPh3/wBBnxT/AOBVv/8AGK+m6Kz9vU7mnsYdj5k/4YY+Hf8A0GfFP/gVb/8Axij/AIYY+Hf/AEGfFP8A4FW//wAYr6boo9vU7h7GHY8a+Hv7Lnw68A/2jnTf7f8Atvl/8jBBb3fkbN3+r/dDbu3c+u1fSuwu/hV8NbK0nuZfAHhpo4I2kYQ6FDK5AGTtRYyzHjgKCT0AJqr4z+OHw++Heopp/iPxNaWt+c7raNJLiWL5VYeYkSsY8h1I3AZByM4NdvpOrWutafDfW0d1HDLnat3aS20owSDmOVVdeRxkDIwRwQa6qVSfLeTS9Tkq04c1kn8j81/2j9U8AeJPHGn3fw9hsYdFTTY4pVsLA2cZnEspYlCi5O0p82OmBnivH1to1kXDNuHOK+of2nfiN8I/GHhG3PgQ6XJ4ml1Zbm7uLfSHtp5IjHLvZpWiXdl2QkEkk89s18sWjfvucksDXpRcdFY4mpWbuXqr3aZQNjkfyqxTXXejLxyO9bsyR2upMviL4SW91If9K0SdYd7RrllyFCqR0G10z6lOfWvLq9O+FY/tAeItD+5/aNkf33Xy8ZT7vf8A1ueo6e9eY152GXJOpS7O/wAn/wAG572bP29DDYt7yjyv1g7X+cXH/gu4V9w/sCy29v4b+J8t4nmWkYtWmTGdyBJywx34zXw9XqHwp+O/iP4P6V4j03Q7LSriDX0RLlr6KR2QKrqNmyRQOJD1B6CumaurHiLRn0j+19omufEHwP4d8aeDNUj1T4aWlsGOn2KbVtSMjzio6gD5CCAY8EYGWxf+B+i+G/h9+zHD46j1yz8N67qs7i48STaQdTkswLholjWIcgEIOvGXyQeK+Y/hJ+0F4v8Ag1BqNpopsb3Sr8fvdO1SN5bfd0LhVZSGI4POCOoOBi54R/aQ8VeCTrVppWnaD/wjerzNNN4dubRptPRmxuCIzllU4+7ux7cCp5Xaw79T1D9onx18LvHvw00t7PxVZ+IPiTp8yLJqdtoc+ntfREsGDqybRgFT97qpxgMRXtmn+LtG8f6V4b0r4RfEvwz4YiFosJ8LX+kwu1xLjJVvMwxIHB2Bs4Jya+KvH3xo1fx9o0WivonhrQ9HjuFuvsmhaYlqjSKrKrE8scB2GM45rsNJ/at8UaVNDenwr4HutcgGI9Zm0RReKcY3CRGUZx7UODsFz0T4V/Dj4pWXxn+JMul+INE8GXekD/ic3trZRzWqRzHzlEMLqQFITf8Aw4AweuK9X1VdG+LP7O/xDvNT8ZWfj+60W3uJ7fWBoH9myWk0UPmBF4+boMlcZDYOa+SPCH7SPj3wf4y1/wAUw31tfX3iAg6lDfwb4LnbkJlVK42gkDaRgHHStlv2rfGP/CLeJfDMOj+F7TRNegltmtbPT2t47RJEKP5Ko4UE7icsGJPUkAChxdwuj1L4m/8AJi3w5/7CMf8AO6r5M8O6Qdf8QaTpImWA6hdxWvmt0Te4XcfYZzXb678bvEHiD4UaL8Nrmz0tNC0iZZ4J4opBcsw8zhmLlSP3rdFHQV5srMjBlJVlOQQcEGqimkJn6T+I7n4daHfaX+zfr+n3UGhXmlRtp+q3U+5vtTSPtwxHytuBKt93cdm3GBXz/wDGD4C+GPgd8FXGupbX3j/UtWeLT72G4lUi1Vgd3lbtn3F5yDgygZ4Fcnb/ALXPjdrHTYdY0jwr4gvtMA+yanrGl+fdwkdGVwwAbgfNjJxkkmsb4i/tJ+Kfit4Uh0HxXpXh+/kt5DLBqYtXju4GJydrLIEAx8pGwggDOSAalRkmO6PHK+1vgR/yZX8Vf+vi/wD/AElgr4pr1Dwn8d/Efg34X+IPh5YWWlSaLrjzPcTTxSG4QyRojbGEgUcIMZU85qpK4kfUHwP0Xw38Pv2Y4fHUeuWfhvXdVncXHiSbSDqclmBcNEsaxDkAhB14y+SDxXAftD+Ofhd4++G2lNaeK7PX/iRp86LLqlvoc+ntexEsG3qU2jAKn73VTtwGIrx74afH3xd8L9JvdE0/+ztS8PXpLTaTq9t9otmYgAnbkEZwMgHB7iq3j740av4+0aLRX0Tw1oejx3C3X2TQtMS1RpFVlVieWOA7DGcc1Ki73HfQ+qf2kvFM3wF0PwF4H8G6PpbeGr23c3sFxZRzrqYUopRiQeW3Elh82WGCK1v2oPDviHxL8bvg9pvhG4isdfEc81pcTgMlsYishdgQwO0ITgg5xjvXGeB/Gur+I/APhjT7/wCKXww+xWMMZW71+D/ic6SwABEKyfIzoBhX6nAOa5P9pH9ou31f4t+GNc+HmpMx8KwvHFqJQ7ZpXJ8wAMPmTbhSSOctjjBMpO47n0p4AvrnVvH2q+AvGvxU07x3ew2kn23w9J4XSFISNuW89RsONwBU5+92Ir51+A+t/D/4W/F74n6Rr13a6TcxXNxYaFqt5b+elkY5pUPUHBx5ZycA7CCRnnloP2yvHNp4mPiC10PwjbX0sZS68jTWj+2nACtM4k8xyoHA3bR6cDHAaD8bNe0DxP4n1xNN0G+HiW6a7v8AT9RsFubV3Lu4wrksoBkbGGzg8k01B6iue9ftE+HPGur/AAq/4Sa58aeFPHnhm3vIy2sWOnw293ASSgUNFlShZwGXOc7eOtfHletePf2hvFHjvwnH4T/s7QNB8NLIJW03QbH7NDIwOQWG5u/OBgZwT0FeS1cU0tRMKKKKoAooooAKKKKACiiigAooooA6f4r/API/6v8A9sf/AESlFHxX/wCR/wBX/wC2P/olKK5ML/Ah6L8j084/5GGI/wAcv/SmSfCx2PxC0sbjjM3Gf+mT1yldT8LP+Sh6X9Zv/RT1y1VT/jy9I/nIVX/kXUv8dT/0mmFenfF0fY9T0jS4flsbOyXyYuuzLFep5PCKOT2+teY16d8Zv+RotP8AryT/ANGSUqv+80/SX6HRgtMsxTXemvleT/RfcjjlG1QB0AxVS9b5lX0GauVQu2zMR6DFdtX4TxafxEFFFFcx0H64/CuzuNO+GHgqzvLeW3u7fRbKKaCZCjxusCBlZTyCCCCD0r4h/aN+OsHxV1QaVpFla/8ACOWG6OG7uLRGubhiylpEdl3woSigKpVmH3+uxf0Lr86/iv8As2eKvAviRoNB0vU/EGhXO6S0ubO2aeSNQeY5lQHa4yPmwFYcjB3KvnYVwc25b9DurqSikjR/Zf8AE/ig+LLDwvpnje6060eeGaLR7m2FzbXUKSGS5iR23G3cxGVwVUByMFlO01+gdfH/AOy18Atb0jXrfx14lhutKez82Ox06aMxzSMyNG0kqsMogDMFXhmPzcKBv+wKjFOLn7pVBNR1Cvi39rnxT4p0fWrjRP8AhN7qLTNTKTQ6DZWwiVLMw+U5muRtZ/MlEw8n512jJI+Va+0q+af2qPgbqfj2ODxd4fMt1q2mWot5tNAyZ4FZnDRY5MgLtledwxt+YAPOHcVUXMOsm46HzL8C/i+/we8SJctplrd6Rc7o7wLbR/awjFMmOYjfwUU+WW2HngE7x+kmk6raa5pVjqlhL51jfQJcwS7Su+N1DK2CARkEHBANfm/4F/Z78deM/ElrpdxoOp6JZt89xqGpWUkMcMYIyRuA3vzgIDknrgAsP0a8PaJb+GtA0rRbR5XtdMtYrSJ5iC7JGgRSxAAJwBnAH0rbGcl047meH5ra7H483lncadd3FneW8tvd28jRTQTIUeN1OGVlPIIIIIPSoa7T4wf8la8e/wDYev8A/wBKHri6707q5xNWdie0bEwHqMVfrNgbbMh98VpV00noYVVqdD8LriW18b2kUT4SdZYpBgHcoQtj25VTx6VyXiG1hsdf1W1t02QQXUsca5J2qrkAZPPQV1Hw2/5HzTfrN/6Keud8Wf8AI1a5/wBf0/8A6MauNaYuVv5V+bPZnrk9NvpUkl6csWY9FFbcHha9uPC1x4ijeA2dvcfZ5I9x80cL8+MY25dBnOcsOK6zxDEoro9V8Eavpc+k23k/a7vU7YXUVvaK0kigkgqy4+8CpyBnFZMej6jNqB06Owun1AEqbVYWMuR1GzGc/hQBSorQg0HVbq8ns4NMvZbyAEywJA7SRgddygZH41evfDEtv4rj8PwzpJPJNFAksilF3PtxkDJABb3oAwaK6dPCVu+t6bpUfiDT7ma8vI7NxaxTlodzBSxEkaAgE9Af8ax00XUJ5I1trK6nE0rQxGOFm8116quByQCDgetAXKFFakXhnW57qa1i0fUJLqBgkkKWzl0YgkArjIJAJ59DUdnoOq6hNLDaaZe3E0LiORIYGdkbn5SAOD8rcf7J9KAM+irraPqK6cuotYXQ09m2i6MLeUT6b8Yz+NWf+Ea1SKeGG7sbqzM8TzRm4tpB5iohYkAKSRgdQMDqSBkgAyaKK2/DHha98WXd1a2LwLNb27XG2ZiPMwVUIuAcsSwABwOetAGJRW2PC17/AMIq3iMvAtkLkWojLHzWJBIYDGNvysM56g0aj4Vv9M0DTNamMJtdQLBEViZI8E43jHG7BK8nIBoC5iUV1WueBbrRIdQcalp94+muiXkVsZd8BY4BO9FBGcDKk9RVDUfCt/pmgaZrUxhNrqBYIisTJHgnG8Y43YJXk5ANAXMSit+Xwjew63qmktLbm502KaaVgzbGEaFm2nGc4HGQPwrAoAKKKKQwooooAKKKKACiiigAooooAKKKKAOp+KzsPH2rgMQP3Pf/AKYpRTfiv/yP+r/9sf8A0SlFcmF/gQ9F+R6ecf8AIwxH+OX/AKUx3ws/5KHpf1m/9FPXLV1fwsC/8LC0vk5zN2/6ZPXKVVP+PL0j+chVf+RdS/x1P/SaYV6b8Tz9vtPC+tScXV/ZDzFX7gwFbgdesjdSegrzKvS5z/bvwktJ/vT6NdGKSSblthOAqHk4xJGMcfc9hU4j3alOfnb71/nY6Mr/AHuFxWH6uKkv+3Gm/wAG/wATkEJKKT1IFZ87bpnJ9cVbtWzFjupqizbmLHqTmuyq9EePTWrEoorp/hvq1noHxE8I6tqM3k6fp+rWlzcS7S2yNJkZmwoJOACcAE1zt2Rstz9d6Khs7y31G0t7yzuIri0uI1lhnhcOkiMMqysOCCCCCOtTV4Z6xieLvEH/AAi3h681b7N9p+zbP3W/Zu3Oq9cHH3s9O1eX/wDDQP8A1Lv/AJO//a61Pj1dwp4c020Z8XEt35qJg8qiMGOenBdfz+teAVnKTT0PqsnyvD18N7StG7bfVrT5M9r/AOGgf+pd/wDJ3/7XXofgPxj/AMJtpE+ofYvsnlXDQeX5vmZwqtnOB/e/SvlGvZPgBdwpea7aM+LiWOKVEweVQsGOenBdfz+tEZNvU0zTKcNRwsqlGNmrdW+vqe5UUUVofIn5K/GD/krXj3/sPX//AKUPXF16p+0j4i0vxX8a/Feq6LexX2myyQRx3MJykhjgjjYqf4huRgGHBxkEgg15XXtw+FHlT+Jiq21gw6g5rVrJrQkk/wBH3HGWX+ddFJ7mFVbHXfCSzS78X+dIzB7W3kmTGMFjhOfbDn8cVwWo3smp6hd3soVZbmV5nCDCgsSTjPbmvRPBR/sXwV4q1w/K7Ri0gki4ljcjGQeMDdJGeD/D7CvMq5KXvV6k+1l+r/M9jHfusuw1HZy5pv5tRX4RYV23h7xZZaH4etbaeAX2b24a5sWJQSwvFGo+fBA+ZMjryo4riaK7DxLHpTeL7HV9OW3vNS+zX99ps0E92Y3KwytfPOVbaCdrIQCVBxuA9RUMviLS7m61Cx/tJo1n0iDTl1V4nw7xsjEsAC+xghTpnAXI6ivO6KLiselah4h0nVdPuNJTWjayRLZf8TKSKXF35COrAhQXGC425HRBnbxjM1PxBp9z8UodbS7eTTV1CCdrh0YMUUpuYrjOeDxXEUUXHY9GuNbtI/FWialNreg3Nnb6pFcONO0xreWOMSBizkW8ZYADpljntUVx4lsb7WLLU7fUIrFTBJZyWM8EjQQIUKnbsGRG4Yk4+cMSefvHz6ii4WPUlOkXPh3xLDZaz9jtHk06NpyJ2g8wLOSi5Bk8vjIyCcgduaydf8VWd9Z+KI7W7l3X89gqllZWuUhikV5G9NzbWwTnLexriFuZkgkt1lkWCVld4wxCsy52kjoSNxx6ZPrUVFxWPT73xjpU2mefanTobiTTorB4miu3uV2oqnA8wQbdy7geD/s5yS2TxBoi6gmoTalDLf3AvWne0jnWJjJbOql0kHEhdgPk+UA15lRRcLGrod39kOo/8TD7F5tnLF/qfM8/OP3X+zu/vdsVe8Ja1Hog1qY3BguZbEx2zAEkyiaJx0HHCE5PHFc5RQOx3+p+LtP8RaTqdoyR6VFPd2X2e2XdIkMa/aDK2QvTfMWx1+bAziruteLvDOsQeIdPht761gmhiFlPNcCSLNsNsIESxAoWTcuSxwX59R5nRRcLHp+veMdN8TXviTTZ723tdNupkntL6Kz8suyMPll2IHkBVmILgkMo96ZrXi7wzrEHiHT4be+tYJoYhZTzXAkizbDbCBEsQKFk3LkscF+fUeZ0UXFY9Q1D4gW134j8THzLD+y7u0uoredNNiSV2aIhAZBGJOTxkn615fRRRcaVgooopDCiiigAooooAKKKKACiiigAooooA6f4r/8AI/6v/wBsf/RKUU74rBf+E+1fJOf3Pb/pilFcmF/gQ9F+R6ecf8jDEf45f+lMPhZ/yUPS/rN/6KeuWrqfhZ/yUPS/rN/6KeuWqqf8efpH85Cq/wDIuo/46n/pNMK9I+E+pRTy6p4bu5JVg1aBhGVY/KwUhsDBAJUk5P8AcA54rzeprS6msbqC6t32TwOskbYB2spyDg8dRV4il7am4f1foZ5ZjXgsVCva6W67p6NfNXL0sU2nXVzazrsnhZo3XIO11JBGRweRVOvQviBYrrdjp/i+whb7NfRKt0BkiGRfl5J7cbMgAZQf3hXntTTre1gpdeq7PqjTHYL6nXlTTvHeL7xeqfzX43QUVLbw+c5BbaiqWZsZwB7U/wAuz/5/f/IRqjkbSPqD9mT9puz8Aaeng7xi/leHIvMksdQihLtaMxLtHIqAs6MxYhgCys2DlSCn3hZ3lvqNpb3lncRXFpcRrLDPC4dJEYZVlYcEEEEEda/G/wAuz/5/f/IRr074afHrxb8KtkGjeIvtGkrn/iV6hC81qM7z8q5DR/M5Y+Wy7jjdnpXJWwvO+aO50UsSo6S2P0t8QeEdG8U/Zv7Ws/tP2bd5X71027sZ+6Rn7o6+lYv/AAqTwd/0B/8AyZm/+LrH+EPxdf4t6FZatZ+GL23tZ5JYprmO8tZoLd0z8rfvFmBI2nBiB+cH7pDH1AxODjafyrglRlF6o9OlmFSMeWnVaXZNr8Dh/wDhUng7/oD/APkzN/8AF1qaD4G0DwzePd6VYfZ7h4zEz+dI+VJBIwzEdVFdH5bn+E/lXFfEnx9L8ONC1LWJ/D97eafY2huHu1urWG3V+QsbGSUPkttHyo5O8BQzfLRGjKWyHUzCq4uM6rafmzs6+Nv2k/2p9Lu9EvvBvgW7iv2v45bXUtUCZijiOUeKLcMOWGcyDKhSNpJbcnjXxS/aa8W/E37TZf2z/YugS7k/s7TkdPMjO8bZZfvSZR9rDhG2g7Aa8X8uz/5/f/IRruo4TlfNM8yrik9IleirHl2f/P7/AOQjTZ4FjWN45PMikBw2MdDzxXYc10yGpnkLRRrnoKhrt/hvoa3OpPrV6rJpOkq1xJKVJBdRuAGDkkfe4z0AI+YUp1lRi5s6MLg54ytChDdvfsurfklqzQ8e3H/CO+DtB8LKZVumQXV0pf7uSTtOBhhvLY548sdeDXmFaXiDWZvEGs3mpTja9y+4LwdijhVyAM4UAZxzis2jDUnSp2lu9X6vcrNcZHF4lyp/BFKMf8MdF9+782FFFWLa28395JkRA4yOrH0H+Pb8geg80r0VpYtxwLWMgd2Zsn64Ipf3H/PpF/30/wD8VT5RcxmUVp/uP+fSL/vp/wD4qj9x/wA+kX/fT/8AxVHKHMZlFaf7j/n0i/76f/4qj9x/z6Rf99P/APFUcocxmUVp/uP+fSL/AL6f/wCKo/cf8+kX/fT/APxVHKHMZlFaf7j/AJ9Iv++n/wDiqP3H/PpF/wB9P/8AFUcocxmUVp/uP+fSL/vp/wD4qj9x/wA+kX/fT/8AxVHKHMZlFaf7j/n0i/76f/4qj9x/z6Rf99P/APFUcocxmUVp/uP+fSL/AL6f/wCKo/cf8+kX/fT/APxVHKHMZlFaf7j/AJ9Iv++n/wDiqP3H/PpF/wB9P/8AFUcocxmUVp/uP+fSL/vp/wD4qj9x/wA+kX/fT/8AxVHKHMZlFaf7j/n0i/76f/4qj9x/z6Rf99P/APFUcocxmUVp/uP+fSL/AL6f/wCKo/cf8+kX/fT/APxVHKHMZlFaf7j/AJ9Iv++n/wDiqP3H/PpF/wB9P/8AFUcocxmUVp/uP+fSL/vp/wD4qq1xbKqmSHcYx95WOSv+I9/w9MjQXKtFFFSUdP8AFf8A5H/V/wDtj/6JSij4r/8AI/6v/wBsf/RKUVyYX+BD0X5Hp5x/yMMR/jl/6Ux3ws/5KHpf1m/9FPXLV1fwsdj8QtLG44zNxn/pk9cpVU/48vSP5yFV/wCRdS/x1P8A0mmFFFFdJ5pq22u3sWiz6MkuLGaYXDKOCWAxjI6g/KcHPKgjHOaVRxd6nhiM0qRjOWOOBnFZOKTdludPtJziud3srLyXYkmb7PYbD9+4IOPRR0P4ms6rV/MJrltuPLj+RMHPA96q1LMQooopAfRP7I3xq/4Vr46XRNa1T7N4Q1zKTfaJdsFpc4Hlzn5TtztEbHKjDBmOIxj9L6/Eev0o/ZD+OMnxM8IyeHdbupp/FWgRr5lxczI0l9bliEkA4YlPlRyQeSjFizkAY0fSFfA/7bXxq/trWIPh9oGqb9M0/L6x9mlyk1yG+WB/l58rbuIDEbnwQGi4+mP2kPjJF8HPh9PeW7bvEOqb7PS41ePdHKUObgq+dyR8E/KwLMinAbI/K69vbnUry4vLy4muby5kaWaeZy8krscszMeSSSSSeSTQgZBRRRQIK0LJvPtpbb+MHzU9yByPyrPqW2na2njlXqpzj1HcU0BLV6PXb210a80iOXFleOkkiHnleeOwyduSOTtHOKgu4hDOypzGfmU9iDVWX7o+tPlTdmjaNWdNNwdrpr5PRr5oiooorY5grSHFpagcAoWPudzDP5AflWbWn/y62n/XM/8AobVUSZDKKtaZp1xq+pWen2cZku7yZIIkH8TsQqj8yK9t+Ivw8sbeTQprnSbnw7oun6kNAur6SxaH7TCoUpecgb2fExLc9F9qdyTwiivSrjwjY21v4gntbW7trVNGa5hM9xbXySMt1DGSk6JtxhznaFZTwTgkHU8L+EPDf9u+Dri3trvVrOS/sEvJxdwSQM0pXdHJBsLxAOSvz7g4UgYyCC4HkNFeo6P4M0DxD/b2sRQXFtpdjdRWkdjca3aW0jyOJGLfaJkRAoEZwgQsc9cAmp38BeEdLNuLy+1DUVvNbk0uCbTbqDyxEI4HEhYK6symfBVTgkcMuOS4Hk9Fa0nh+6bxO/h+1Hn3pvTYxgDHmPv2D8zXuPif4fQ2niHwZOPDEmn6dp+vQaBP9psTEmoxKyFLhgygSeZibceeAo9KLgfPFFeifD6xtLj4rG2nhsjao1+Ql1AJYE2QTFS0ZVgQpAONp6dDWvqy6Drukai1rPpt1q+m6NLPeXml6attbTMbuBYwsbxJtYK7ZdEQnIGSN2S4HklFeoeLfBfhfSJvFMGm/wBsO/hq+jhna5uIsXUTSFGC4j/dsCAAx3A8naOlXPFHhzQtR+KPiSx03w5fDT7CWf7RHHq9tZwxESBQ4keARxR8hQhzyRhuxLgeR0V6pq3w/wDD3hmLxDeam+o3VtZHTWtIbO7gzIt1DJIVaZVdDt2YDoCGwcD5gRgfDKxspNYvtT1VIDpWlWck87zw+csTPiGF/K6SbZZYyVPBAOfSi4HFUV2HjfwvqmlFNW1GPTYI76Yx24sFCRXKqiEzxKo2+W29eRgbiRtGCB3mkeEtH8UeAvCVo9va2d5bxy6peXyRqsstmt1LHcbm6uUURsoPQBqLgeJ0V6z8TtF0q9h1PxFZWMWmlYtEMVlZoscCC6spJZPlA67o15z3Oc543vCnhvS9G13UtDnglvNMXxLoUTRTspMgcT8NlSCuW5GORkcZzRcDwiivQW0PTdZ0rxLLo1u9ksWo2VvDFqF1bsAXFxuJnaOMIuUHAKj+9uwCNbwPpaaP4f8AGbXd34atb+znsY0vtQtotTt0D+cWVCkU6ktheVH8OCRii4HlFFe1WGm6B/Yd/qWsWSaobjQbi7D6ckFkisuqeVui/wBHyuRjBZcqpZcAEBeV03wTpuo6h4NiEl4kOu2NzdzDzFLRmOa5RQp29NsCZyOpPTIALjPP6K6/xno2heH7fSbWxXUZNTubCzvriaeZPJTzoFkaNUCZPLAhi3A4wfvVyFAgooopgFSQ8+aDyDE+R64UkfqAfwqOpYOsn/XKT/0A0IDKooorM0On+K//ACP+r/8AbH/0SlFO+KzsPH2rgMQP3Pf/AKYpRXJhf4EPRfkennH/ACMMR/jl/wClMPhZ/wAlD0v6zf8Aop65aup+Fn/JQ9L+s3/op65aqp/x5+kfzkKr/wAi6j/jqf8ApNMKKKK6TzSWL7p+tXIW+z201weuPLT13HvntgVRWTaMYrSurZZoreNLq2CxKc7pOdx6/hWbTvc05laxkUVe/s3/AKe7T/v5/wDWo/s3/p7tP+/n/wBap5WTco0Ve/s3/p7tP+/n/wBatK18GaxfQJcWtrJPA+dskUbsrYODghcdQamXu6vQ0p051HaCbflqc/XYfC/4i6t8K/GumeJdJmmDW0ii5t45NgvLcsDJAxIIwwHUg7SAw5UEVf8AhAPEH/QOuf8AvxJ/8TWR/Zbf8/Nr/wB/P/rURal8Oo6lGpSt7SLV+6seh/Hz4yXvxo8dXGrbruHQbb9zpdhcOp+zxYAZiF4DuV3N94jhdzBFry2r/wDZbf8APza/9/P/AK1akXgbXJ4klisZpIpFDI6ROQwPIIO3kUStH4tBU6U6rtTi36K5zlFdHN4G1y3ikllsZo4o1LO7xOFUDkkkrwKyv7N/6e7T/v5/9aiLUvh1CpSnTdqkWvVWKNFXv7N/6e7T/v5/9aj+zf8Ap7tP+/n/ANaq5WZ3JFb7RYI38dudrZ6lT05/TFVX+4av2VqtvKxe6tjG6FG2yc4PpWfI21nTg4JGVOQapJlcytYiooorQzCtP/l1tP8Armf/AENqzKv20oniSA/61MhP9oHnb9c5Pvn6A1Ell/RtYvfD+p2+padN5F9bktFLtVihIIyAQRnng9jyOasaP4m1XQIrqLTrswR3ZjMq7FYMUbcp+YHBB9OxIPBIOUylSVYEEcEHtSVRJ0d/4617UUmimu4kgmtjZtBb2sMMQiMiyEKiKFUl0UkgAnHJpW8feIDaW9qt8sSQSRSiSG3ijldozmMvIqh5Np5G4nFc3RSA6ZPH+uxX95epLZK96qi4hGnW32ebbyrND5fllgSTu255PPNU7jxbrF15Hm3hb7PeNfx/u0+WZggLDjpiJBt6DbwOtYtFAGrZ+JNT0/Xv7dtrny9W815xceWpIkbOWAIwDySOODyMYFP0PxTq3hvzf7Mu/IEskMrgxo4LxSCSNsMDghhn6Eg8Eg49FAGjYa9qGmaq+qWtx5d+4lBl2Kc+YrK/BGOVdh04zxUVjqt3psV9FazeXHfwfZrgbQd8e9X28jj5kU5GDx9ap0UAbF74q1fUZdZlubvzH1qQS3p8tB5zB94PA+X5uflxWkfiN4ia+kvXubR7iaD7POz6fbsLlNwb96pjxK2VU7nDNkDmuVooA39Y8ba7r8d3HqN956XZtzKPKRd3kIyRfdUY2q7DjrnnOBVPQ/EGo+G7x7rTbgQyyRtDIGjWRJYz1R0cFWU4HDAjgVmUUAb2u+M9a8S2lvaandRzW1q5eCJLeKNYMgAqgRRsQ4B2Lhc84zzWdd6teX1lp9lcTb7bT0eO3TaB5as5dhkDJyzE8561SooA6W28f+ILSWSRLyJ/MtoLRkmtYZYzHAgSL5HQruRQAGxu6nOSajuPHXiG6vL28l1KRru9uoL2aYIoZpod3lvkDgjc3TGc85rnqKANvU/Fuq6tHfx3ElssV/JFLcR29pDAsjxhwjYjRQD+8fJHXPOeKo2+r3lrpl7pkU22yvXjknj2g72j3bDnGRje3Q855qlRQBv6d411vShaLb3URjtLZ7OOKa2iljMLyGRkZHUq4LsW+YHnHoKtaX8RvEmjWqW1jfRRRxmTyj9khZ4hJneqMULIjZOVUheTxXLUUAXNS1W71eaGa9m82SGCK2Q7QuI40CIvAHRVAz1OOc1ToopgFFFFABUsHWT/AK5Sf+gGoqdM/wBkR1YETupUKeqA9SfqMjHvn0yDM2iiisyzp/iv/wAj/q//AGx/9EpRR8V/+R/1f/tj/wCiUorkwv8AAh6L8j084/5GGI/xy/8ASmSfCwL/AMLC0vk5zN2/6ZPXKV1Pws/5KHpf1m/9FPXLVVP+PL0j+chVf+RdS/x1P/SaYUUUV0nmhRRRQAUUUUAFTWt3cWM6XFrPLBOmdskTlWXIwcEc9Cahooavoxxk4tNOzR1Vr8SfFNnAkEerysiZwZUSRuTnlmUk/ia3v+F16/8A8+emf9+5P/i683ormlg6EtXBfcepRzzMaKtCvK3q3+ex6R/wuvX/APnz0z/v3J/8XWPd/FDxTd+ev9peTHNuGyGJF2A9lbG4Y7HOffNcfRRHBYeOqgvuHVz7MqqtKvL5Nr8rFm91G81OUS3t3Pcyqu0PPIXYDrjJ7cn86rUUV0pJKyPKlKU3zSd2FFFFAgooooAKKKKACiiigCwt9dIoVbmYKBgAOcAUv9oXf/P1P/38NVqKd2KxZ/tC7/5+p/8Av4aP7Qu/+fqf/v4arUUXYWLP9oXf/P1P/wB/DR/aF3/z9T/9/DVaii7CxZ/tC7/5+p/+/ho/tC7/AOfqf/v4arUUXYWLP9oXf/P1P/38NH9oXf8Az9T/APfw1WoouwsWf7Qu/wDn6n/7+Gj+0Lv/AJ+p/wDv4arUUXYWLP8AaF3/AM/U/wD38NH9oXf/AD9T/wDfw1WoouwsWf7Qu/8An6n/AO/ho/tC7/5+p/8Av4arUUXYWLP9oXf/AD9T/wDfw0f2hd/8/U//AH8NVqKLsLFn+0Lv/n6n/wC/ho/tC7/5+p/+/hqtRRdhYs/2hd/8/U//AH8NH9oXf/P1P/38NVqKLsLFn+0Lv/n6n/7+Gj+0Lv8A5+p/+/hqtRRdhYs/2hd/8/U//fw0f2hd/wDP1P8A9/DVaii7CxZ/tC7/AOfqf/v4arUUUXAKKKKQzqfisF/4T7V8k5/c9v8ApilFN+K//I/6v/2x/wDRKUVyYX+BD0X5Hp5x/wAjDEf45f8ApTMvwjrK+H/Fmnag5RYop8Ss6lgsbZVzgc5CsSPf16U7xLo7aBr+oacQwW3lIj3sCxQ8oSRxkqQfx7VgSf6x/qa7DT9d0rXNKstI14vaTWaslvq6K0rLHnIikTqy8kAg/L8vGN2XK8J+0Sutn+j/AD+8WHca9B4WUlFp80W9Fd2TTeyvZNN2StrvdczRXXj4a63c/PpjWGq244aexu0ZFb+6SxBzjB6dxS/8Kt8Wf9An/wAmIv8A4qr+tUP5196F/Y+YdKE36RbX3pWOPorsP+FW+LP+gT/5MRf/ABVH/CrfFn/QJ/8AJiL/AOKo+t0P5196D+xsx/6B5/8AgMv8jj6K7D/hVviz/oE/+TEX/wAVR/wq3xZ/0Cf/ACYi/wDiqPrdD+dfeg/sbMf+gef/AIDL/I4+iuw/4Vb4s/6BP/kxF/8AFUf8Kt8Wf9An/wAmIv8A4qj63Q/nX3oP7GzH/oHn/wCAy/yOPorsP+FW+LP+gT/5MRf/ABVH/CrfFn/QJ/8AJiL/AOKo+t0P5196D+xsx/6B5/8AgMv8jj6K7D/hVviz/oE/+TEX/wAVR/wq3xZ/0Cf/ACYi/wDiqPrdD+dfeg/sbMf+gef/AIDL/I4+iuw/4Vb4s/6BP/kxF/8AFUf8Kt8Wf9An/wAmIv8A4qj63Q/nX3oP7GzH/oHn/wCAy/yOPorsP+FW+LP+gT/5MRf/ABVH/CrfFn/QJ/8AJiL/AOKo+t0P5196D+xsx/6B5/8AgMv8jj6K7D/hVviz/oE/+TEX/wAVR/wq3xZ/0Cf/ACYi/wDiqPrdD+dfeg/sbMf+gef/AIDL/I4+iuw/4Vb4s/6BP/kxF/8AFUf8Kt8Wf9An/wAmIv8A4qj63Q/nX3oP7GzH/oHn/wCAy/yOPorsP+FW+LP+gT/5MRf/ABVH/CrfFn/QJ/8AJiL/AOKo+t0P5196D+xsx/6B5/8AgMv8jj6K7D/hVviz/oE/+TEX/wAVR/wq3xZ/0Cf/ACYi/wDiqPrdD+dfeg/sbMf+gef/AIDL/I4+iuw/4Vb4s/6BP/kxF/8AFUf8Kt8Wf9An/wAmIv8A4qj63Q/nX3oP7GzH/oHn/wCAy/yOPorsP+FW+LP+gT/5MRf/ABVH/CrfFn/QJ/8AJiL/AOKo+t0P5196D+xsx/6B5/8AgMv8jj6K7D/hVviz/oE/+TEX/wAVR/wq3xZ/0Cf/ACYi/wDiqPrdD+dfeg/sbMf+gef/AIDL/I4+iuw/4Vb4s/6BP/kxF/8AFUf8Kt8Wf9An/wAmIv8A4qj63Q/nX3oP7GzH/oHn/wCAy/yOPorsP+FW+LP+gT/5MRf/ABVH/CrfFn/QJ/8AJiL/AOKo+t0P5196D+xsx/6B5/8AgMv8jj6K7D/hVviz/oE/+TEX/wAVR/wq3xZ/0Cf/ACYi/wDiqPrdD+dfeg/sbMf+gef/AIDL/I4+iuw/4Vb4s/6BP/kxF/8AFUf8Kt8Wf9An/wAmIv8A4qj63Q/nX3oP7GzH/oHn/wCAy/yOPorsP+FW+LP+gT/5MRf/ABVH/CrfFn/QJ/8AJiL/AOKo+t0P5196D+xsx/6B5/8AgMv8jj6K7D/hVviz/oE/+TEX/wAVR/wq3xZ/0Cf/ACYi/wDiqPrdD+dfeg/sbMf+gef/AIDL/I4+iuw/4Vb4s/6BP/kxF/8AFUf8Kt8Wf9An/wAmIv8A4qj63Q/nX3oP7GzH/oHn/wCAy/yOPorsP+FW+LP+gT/5MRf/ABVH/CrfFn/QJ/8AJiL/AOKo+t0P5196D+xsx/6B5/8AgMv8jj6K7D/hVviz/oE/+TEX/wAVR/wq3xZ/0Cf/ACYi/wDiqPrdD+dfeg/sbMf+gef/AIDL/I4+iuw/4Vb4s/6BP/kxF/8AFUf8Kt8Wf9An/wAmIv8A4qj63Q/nX3oP7GzH/oHn/wCAy/yOPrV8NaO2v6/p+nAMVuJQJNjAMEHLkE8ZCgn8O9bR+Gut23z6m1hpVueFnvrtFRm/ugqSc4yenY1W1DXdK0PSr3SNBL3c14qpcau6tEzR5yYo06qvABJPzfNxjbiZ4iM1y0Xd+Wy87/puaUsunh5qpjo8kVrZ6Sl5Jb67XtZbvonleMtZXxB4o1TUEKNFLKREyKVDRqAqHB5yVUE+/p0orCoq4RUIqK2RwV60q9WVWe8m2/V6kkkjh2AZup703zH/AL7fnRRVGQeY/wDfb86cJH2MdzdR3+tFFADfMf8Avt+dHmP/AH2/OiigA8x/77fnTpJHDsAzdT3oooAb5j/32/OjzH/vt+dFFADhI+xjubqO/wBab5j/AN9vzoooAPMf++350eY/99vzoooAdJI4dgGbqe9N8x/77fnRRQAeY/8Afb86cJH2MdzdR3+tFFADfMf++350eY/99vzoooAPMf8Avt+dOkkcOwDN1PeiigBvmP8A32/OjzH/AL7fnRRQA4SPsY7m6jv9ab5j/wB9vzoooAPMf++350eY/wDfb86KKAHSSOHYBm6nvTfMf++350UUAHmP/fb86cJH2MdzdR3+tFFADfMf++350eY/99vzoooAPMf++3506SRw7AM3U96KKAG+Y/8Afb86PMf++350UUAOEj7GO5uo7/Wm+Y/99vzoooAPMf8Avt+dHmP/AH2/OiigB0kjh2AZup703zH/AL7fnRRQAeY/99vzpwkfYx3N1Hf60UUAN8x/77fnR5j/AN9vzoooAPMf++3506SRw7AM3U96KKAG+Y/99vzo8x/77fnRRQA4SPsY7m6jv9ab5j/32/OiigA8x/77fnRRRQB//9k=",
	"sedih": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4lkkcOwDN1Pem+Y/99vzok/1j/U16pcXEPwkt7SysrRB4+C772/kxKtirgFYYlI2Fym3c2DjcwDHPy+hSpc95Sdkt3+i8zlqVOWySu3/X3GHpnwi8d6tA09v4fvERWKEXTrbtnAPCyMpI564x19DV4fA/4g7T/wASNs5H/L7B/wDHK4/UtX1DWZ1n1K+ur2dV2CS5maRguScAsScZJ496p1tfDL7Mv/Al/wDIsi1f+Zfc/wDM7v8A4Ud8Qv8AoBt/4Gwf/HKP+FHfEL/oBt/4Gwf/AByuEoovhv5Zf+BL/wCRDlr/AMy/8Bf/AMkd3/wo74hf9ANv/A2D/wCOUr/A/wCIJZsaG2M8f6bB/wDHK4Oii+G/ll/4Ev8A5EOWv/Mv/AX/APJHd/8ACjviF/0A2/8AA2D/AOOUf8KO+IX/AEA2/wDA2D/45XCUUXw38sv/AAJf/Ihy1/5l/wCAv/5I7wfA/wCIO0/8SNs5H/L7B/8AHKT/AIUd8Qv+gG3/AIGwf/HK4Sii+G/ll/4Ev/kQ5a/8y/8AAX/8kd3/AMKO+IX/AEA2/wDA2D/45R/wo74hf9ANv/A2D/45XCUUXw38sv8AwJf/ACIctf8AmX/gL/8AkjvH+B/xBLNjQ2xnj/TYP/jlJ/wo74hf9ANv/A2D/wCOVwlFF8N/LL/wJf8AyIctf+Zf+Av/AOSO7/4Ud8Qv+gG3/gbB/wDHKUfA/wCIO0/8SNs5H/L7B/8AHK4Oii+G/ll/4Ev/AJEOWv8AzL/wF/8AyR3f/CjviF/0A2/8DYP/AI5R/wAKO+IX/QDb/wADYP8A45XCUUXw38sv/Al/8iHLX/mX/gL/APkju/8AhR3xC/6Abf8AgbB/8cpX+B/xBLNjQ2xnj/TYP/jlcHRRfDfyy/8AAl/8iHLX/mX/AIC//kju/wDhR3xC/wCgG3/gbB/8co/4Ud8Qv+gG3/gbB/8AHK4Sii+G/ll/4Ev/AJEOWv8AzL/wF/8AyR3g+B/xB2n/AIkbZyP+X2D/AOOUn/CjviF/0A2/8DYP/jlcJRRfDfyy/wDAl/8AIhy1/wCZf+Av/wCSO7/4Ud8Qv+gG3/gbB/8AHKP+FHfEL/oBt/4Gwf8AxyuEoovhv5Zf+BL/AORDlr/zL/wF/wDyR3j/AAP+IJZsaG2M8f6bB/8AHKT/AIUd8Qv+gG3/AIGwf/HK4Sii+G/ll/4Ev/kQ5a/8y/8AAX/8kd3/AMKO+IX/AEA2/wDA2D/45Sj4H/EHaf8AiRtnI/5fYP8A45XB0UXw38sv/Al/8iHLX/mX/gL/APkju/8AhR3xC/6Abf8AgbB/8co/4Ud8Qv8AoBt/4Gwf/HK4Sii+G/ll/wCBL/5EOWv/ADL/AMBf/wAkd3/wo74hf9ANv/A2D/45Sv8AA/4glmxobYzx/psH/wAcrg6KL4b+WX/gS/8AkQ5a/wDMv/AX/wDJHd/8KO+IX/QDb/wNg/8AjlH/AAo74hf9ANv/AANg/wDjlcJRRfDfyy/8CX/yIctf+Zf+Av8A+SO8HwP+IO0/8SNs5H/L7B/8cpP+FHfEL/oBt/4Gwf8AxyuEoovhv5Zf+BL/AORDlr/zL/wF/wDyR3f/AAo74hf9ANv/AANg/wDjlH/CjviF/wBANv8AwNg/+OVwlFF8N/LL/wACX/yIctf+Zf8AgL/+SO8f4H/EEs2NDbGeP9Ng/wDjlJ/wo74hf9ANv/A2D/45XCUUXw38sv8AwJf/ACIctf8AmX/gL/8Akju/+FHfEL/oBt/4Gwf/ABylHwP+IO0/8SNs5H/L7B/8crg6KL4b+WX/AIEv/kQ5a/8AMv8AwF//ACR3f/CjviF/0A2/8DYP/jlH/CjviF/0A2/8DYP/AI5XCUUXw38sv/Al/wDIhy1/5l/4C/8A5I7v/hR3xC/6Abf+BsH/AMcpX+B/xBLNjQ2xnj/TYP8A45XB0UXw38sv/Al/8iHLX/mX/gL/APkju/8AhR3xC/6Abf8AgbB/8co/4Ud8Qv8AoBt/4Gwf/HK4Sii+G/ll/wCBL/5EOWv/ADL/AMBf/wAkdfqfwj8daRaia48P3jqzhALVluGzgn7sbMQOOuMdPUVw3mP/AH2/OtbTdX1DRp2n02+urKdl2GS2maNiuQcEqQcZA49q763uIfi3b3dle2iHx8V32V/HiJb5UBLQyqBsDhN21sDO1QWGPmPZU6ulK6fZ639Gkteytr3E6lSnrUs13Wlvld6fM8r8x/77fnRTaK4zpO6+EWmQ6v8AE/w/bzs6oly1wChAO6JWkUcg8bkGfbPTrXO6vqUus6rfalOqLPezyXEixghQzsWIGSTjJ9a7D4Hhf+Fr6Hyc5uO3/TCSuDrs2w0fOUvyj/mc6/jy9F+bPpP4E+KfCGk+Ent5ryy03WBKTePdyrEZ+W8sqzH5lC8YHQ5OPmy3qX/Ce+FP+hn0X/wPi/8Aiq+GqK9KhnVSjTjTUFocFbKoVajqOT1PuX/hPfCn/Qz6L/4Hxf8AxVH/AAnvhT/oZ9F/8D4v/iq+GqK2/t+p/IjP+xYfzs+5f+E98Kf9DPov/gfF/wDFUf8ACe+FP+hn0X/wPi/+Kr4aoo/t+p/Ig/sWH87PuX/hPfCn/Qz6L/4Hxf8AxVH/AAnvhT/oZ9F/8D4v/iq+GqKP7fqfyIP7Fh/Oz7l/4T3wp/0M+i/+B8X/AMVR/wAJ74U/6GfRf/A+L/4qvhqij+36n8iD+xYfzs+5f+E98Kf9DPov/gfF/wDFUf8ACe+FP+hn0X/wPi/+Kr4aoo/t+p/Ig/sWH87PuX/hPfCn/Qz6L/4Hxf8AxVH/AAnvhT/oZ9F/8D4v/iq+GqKP7fqfyIP7Fh/Oz7l/4T3wp/0M+i/+B8X/AMVR/wAJ74U/6GfRf/A+L/4qvhqij+36n8iD+xYfzs+5f+E98Kf9DPov/gfF/wDFUf8ACe+FP+hn0X/wPi/+Kr4aoo/t+p/Ig/sWH87PuX/hPfCn/Qz6L/4Hxf8AxVH/AAnvhT/oZ9F/8D4v/iq+GqKP7fqfyIP7Fh/Oz7l/4T3wp/0M+i/+B8X/AMVR/wAJ74U/6GfRf/A+L/4qvhqij+36n8iD+xYfzs+5f+E98Kf9DPov/gfF/wDFUf8ACe+FP+hn0X/wPi/+Kr4aoo/t+p/Ig/sWH87PuX/hPfCn/Qz6L/4Hxf8AxVH/AAnvhT/oZ9F/8D4v/iq+GqKP7fqfyIP7Fh/Oz7l/4T3wp/0M+i/+B8X/AMVR/wAJ74U/6GfRf/A+L/4qvhqij+36n8iD+xYfzs+5f+E98Kf9DPov/gfF/wDFUf8ACe+FP+hn0X/wPi/+Kr4aoo/t+p/Ig/sWH87PuX/hPfCn/Qz6L/4Hxf8AxVH/AAnvhT/oZ9F/8D4v/iq+GqKP7fqfyIP7Fh/Oz7l/4T3wp/0M+i/+B8X/AMVR/wAJ74U/6GfRf/A+L/4qvhqij+36n8iD+xYfzs+5f+E98Kf9DPov/gfF/wDFUf8ACe+FP+hn0X/wPi/+Kr4aoo/t+p/Ig/sWH87PuX/hPfCn/Qz6L/4Hxf8AxVH/AAnvhT/oZ9F/8D4v/iq+GqKP7fqfyIP7Fh/Oz7l/4T3wp/0M+i/+B8X/AMVR/wAJ74U/6GfRf/A+L/4qvhqij+36n8iD+xYfzs+5f+E98Kf9DPov/gfF/wDFUf8ACe+FP+hn0X/wPi/+Kr4aoo/t+p/Ig/sWH87PuX/hPfCn/Qz6L/4Hxf8AxVH/AAnvhT/oZ9F/8D4v/iq+GqKP7fqfyIP7Fh/Oz7l/4T3wp/0M+i/+B8X/AMVR/wAJ74U/6GfRf/A+L/4qvhqij+36n8iD+xYfzs+5f+E98Kf9DPov/gfF/wDFUf8ACe+FP+hn0X/wPi/+Kr4aoo/t+p/Ig/sWH87PuX/hPfCn/Qz6L/4Hxf8AxVH/AAnvhT/oZ9F/8D4v/iq+GqKP7fqfyIP7Fh/Oz6w+K/jHwVf+B9St59R0/U55FItIbWdJpEnwdjjacqFPJPAxkc52n5b0jUpdG1Wx1KBUaeynjuI1kBKlkYMAcEHGR61TorzMZjZYqoqjSTXY78LhI4eDgne51nxh0yHSPiX4it4GdkecXBLkE7pUWRhwBxuc49sdetFXvjoF/wCFqa/knP7jt/0wjornxkUsRUS/mf5muFbdGDfZfkL8Dv8AkrGh/W4/9ESVwld38Dv+SsaH9bj/ANESVwlW/wDdof4pflEUf48vSP5yCiiiuc3CiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiit7R9Htms/7U1TzjYGRoIobdwkk8ihSw3FWCKodSSQSSwAH3mSoxcnZEykoowaK7L+09J/6FPSP+/15/wDH6P7T0n/oU9I/7/Xn/wAfrT2S/mX4/wCRHtH/ACv8P8zjaK7L+09J/wChT0j/AL/Xn/x+j+09J/6FPSP+/wBef/H6PZL+Zfj/AJB7R/yv8P8AM42iuy/tPSf+hT0j/v8AXn/x+j+09J/6FPSP+/15/wDH6PZL+Zfj/kHtH/K/w/zONorsv7T0n/oU9I/7/Xn/AMfo/tPSf+hT0j/v9ef/AB+j2S/mX4/5B7R/yv8AD/M42iuy/tPSf+hT0j/v9ef/AB+j+09J/wChT0j/AL/Xn/x+j2S/mX4/5B7R/wAr/D/M42iuy/tPSf8AoU9I/wC/15/8fo/tPSf+hT0j/v8AXn/x+j2S/mX4/wCQe0f8r/D/ADONorsv7T0n/oU9I/7/AF5/8fo/tPSf+hT0j/v9ef8Ax+j2S/mX4/5B7R/yv8P8zjaK7EadpviWWO0sdOTTdWlYR26QTO1vOxPEZEhZldicB9+3IUFVBZxx1RODj5oqM+YKK2dK0qB7X+0NQ802RkaGOKBwskzgAt8xBChQykkg5yAB1K6f2zTP+hc03/v7c/8Ax6sZVFF2OeeLUZWjFy9Lfq1/XmcnRXWfbNM/6FzTf+/tz/8AHqPtmmf9C5pv/f25/wDj1T7aJH1z/p3L/wAl/wDkjk6K6z7Zpn/Quab/AN/bn/49R9s0z/oXNN/7+3P/AMeo9tEPrn/TuX/kv/yRydFdZ9s0z/oXNN/7+3P/AMeo+2aZ/wBC5pv/AH9uf/j1Htoh9c/6dy/8l/8Akjk6K6z7Zpn/AELmm/8Af25/+PUfbNM/6FzTf+/tz/8AHqPbRD65/wBO5f8Akv8A8kcnRXWfbNM/6FzTf+/tz/8AHqpajpdrdWs99p0bw/ZwHubZ33BVLBQ6MRnbuYLtOWGQctlirjVi3YqGLTaUotX72/RswKKKK0Ow7j46/wDJVNf/AO2H/oiOij46/wDJVNf/AO2H/oiOitcb/vNT/E/zMcJ/Ah6L8h/wO/5Kxof1uP8A0RJXCV3nwPdj8V9DG44zccZ/6YSVwdW/92h/il+URR/jy9I/nIKKKK5zcKKKKACipLe3lu54oIInlnlYJHHGpZnYnAAA5JJ7V6/b/CbRvBVjb6r8QdV8vzMtDpVjlpJmAVihcfipxgAlT5gyK3o4eda7jst29EjGrXhSspbvZdWeWaLoWpeIr5LHSrKe8umwdkS52jIG5j0VckZY4Azya9KsPgDrUdrHfeIdU0zQ7AZ8955d7w8kLnGEOTt/j/i9eKdqHxludOgXTfBWmW2gaXEwKlYlkmmIBUM+4EZKhM5DNlfvmvP7+81PWp1uNSvrm7mVQgkupmkYLknAJJOMk8e9dCWFpaO839y/zf4GP+0VO0F97/y/M9IHgn4U6X/omp+Nb25vo/8AWS2MeYWzyNu2Nx0IB+Y8g9Ogd/bvwZ/6FLWf+/rf/JFeXizXHLEn2p4to8fd/Wq+tW+CnFfK/wCdxfVr/FUk/nb8rHpv9u/Bn/oUtZ/7+t/8kUh8M/CHVubTxLqmnXV3/qoZ0JjtnborEx42qSASZOg+93rzP7NF/d/U0w2i44Zgfej63f4qcX8rflYPqtvhnJfO/wCdz0m4+AV9ewS3XhnxFpGt2kSkFkk2MZQM+WNpZc4K9WH3ucDmvOfEXhTWvCd0ttrOnT2cjfcLgFJOATtcZVsbhnBOM4NFpJe6XdJdWF1Nb3Medk0EhjdcjBwRyOCR+Nd5o3xp1u2hNh4htrbxDpTKqPbX0a7iFHy/NtOTnaSXDE7ex5pP6rU0acH96/z/ADHbE09U1Nfc/wDL8jyqivaF+HHhL4jJNP4F1N9P1CNd8mk6iGIVchchvmIHBYkGTllB25ryPVtJvdD1G507UbZ7a9tm2SRP1U/yIIwQRwQQRxXPWw06KUnrF7Nar+vU1pYiFRuK0a6Pcp0UUVzm4UUUUAFdlqf/ACAfCf8A2DpP/Sy5rja7LUCJPD3haRDuRLOWFmHIWQXUzFCf7wWRGx1w6nuK2pbS9P1RlU3j6/oyrpNj/amq2Nj5nl/ap0h34zt3MBnHfrXbXHwzhl1nVND0zWGudZ09C5t57XylmAAJCMHbJ5HBArjNEvY9N1rTr2UM0VtcRzOEGWIVgTj34r0KT4haJp/inV/E+mw6hPql4jJBFcxJHFASACxIdi3Tpgda7MPGi4/ve/4W6HNXdVS/d9vxv1OZt/B8Nv4ds9c1nUWsrW+kaO2jht/Okk28MxBZQFB98+1bFn8KppfEjaVcakiWzWB1GC8hh8wTRZGMKWXB59e3vVD/AISnTNZ8KaZoetLeQyaXI7QXNoiyb0Y5KsrMuD7g9uldDZfFLTl8TreT2d1DpNtpZ0y2jiCySgZGGbJUZ47H0+ta044W65ttO/zuZTliNeXfXt8rHKXXg5JfDr69o9819YwzCC4jkg8maFmxtJUMwIJIGQe/1rUf4cQWus2egXutrBr10isIBbl4Y2YZVGk3ZBPspHNVn8W2GkeE7nQNDW7ka9nSe5vLtFjPyEFVVFZscqDkk9/w1bnx1oGp+KbHxVe2uoLqluqNJaQqhhllQYVhIWyo4HG09OtKMcNpe19L6u3W9vw/Gw3Kvra9tbbX6Wv+Jl2Xw6ujpuqX+oyXEMWnXZspI7S2+0y+YBknG5QFGRznvUeieC7DWYvEN0usTLYaPEkxkWzy8oYHI2Fxgggjqat6T48aDUtQ1V9X1bTb+9umnkjsoY5oGU4IBV3XkcjJzxityP4pabJq3i288q/046zDFFBLZorSRFAQXb515Oc8H8acIYV2v579dHbrp0009RSliFe3l+av09e5z918M7w61oWnafdpcrrVuLmGSVDE0aYyS65OMD0JzUQ8DWuoQawdF1g311pCNLPDJbeUJEU4ZozubcB7hTWzcfFGC317w3qVnb3F3NpUDQXFzeYWa8Vhg7sFsY5I5PJqhZ+LdD8ORa9NokV/Le6tC9un2pERLaNzlsFWJc9MHC9KHHC3dtvn20t31v3+7UFLEWV9/l36/L0Ibbwbot14XvPEK63qAs7Sdbd0Omp5hY45A8/GPmHeuOS2NzerbWe+YyyeXDuXaz5OF4ycE8cZP1rprHxRZ23w+1Tw88c5vbu8S4Rwo8sKAuQTnOflPaqngbWNN8P+JLXVNThnnhtN0kccKglpMfLnJGADzn2Fc81SlKCjZX337m8XUipt622Nfx58OJPBNtZ3Cail/DNI0MrJFsEMoAO0/Mc5GfTpWV438Kf8IbrCad9r+1boEm8zy9n3s8YyfSt2f4h2us+HNf0vVNNSGW+m+2QSWe9gLjPzM3mSHAIAHy9ATxWX8RPFFn4u1+O/so544Vto4SJ1AbK5z0J45rWvHD8spUutrLXTe/6MzouvzKNTzvt5W/U5KpfHv/I8+J/+wnc/+jWpIIJbmaOCCN5ZpWCJGilmdicAADqSe1M8a3EV34y8RTwSpLBLqFw8ckbBldTIxBBHBBHeuJ/w36r9TqX8Rej/AEL95/yBvDn/AF5P/wClM9UoYZLmaOGFGklkYIiKMliTgAVcuSH0Pw+6nciWskTMOQHFxKxU++10OPRge4p/h/VP7D13TdSMfmCzuEmKf3grA4rzJ/EzzU2ozcVd3l+bO+uPgN4og0k3gazkuFXebNJCZPoDjaT7Z/GvOdO0+41TULawtk3XNzIsUanjLE4H0r6ouPjJ4Rh0o3yakJX2ZW1VGEpb+7jHH16e9fMVjr0+n+I4dbiRPPiuftIT+HO7dt+naoR5GVYvHV41PrELNbXVtddDq0+GsF1rd34fs9cWfX7ZGYwG2KwyOoyyLJuySOeqgcVCnw0uZvAX/CUQXe+VC5ksTFhlRHKswbPOOCRgYB9q07fx54f03xXe+LLO11BtUnV2js5VQQxSuMMxkDZYcnjaOvWodO+JcemaH4cto4Z5LvT7qeW8V1Xyp4pS25BzzkN3HWjUpzx9o8n9290uz5l6Xsr+e7FX4UbvEzaL/a/3dM/tHzvs30+Tbv8Afrn8K5zwT4S/4THU7qy+2fZfItZLnf5e/dtx8uMjrnrXdP8AFHQj46n1lLXUE059KOnqnloZFbPXG/GMe+a53wb4k0DwbrFxeRz6neRXFlNbsGs44mVmK7SP3rZHBz0xx17A4Vcb7KXMnzcqtot9b9Ldt/kRRfDe4uvAC+Kra9Erguz2XlYZY0cqzht3OOCeOhrRi+FCv4pOiNrBVRpo1Ezi1yccfJt3+/XP4VFpPxHg0bw94ZsbeCd7jTLmZ7pHVfKnhkJ3IOcnIPcda3f+FqaGvjyXXIrfUYrA6X9hRVjTzUbIwcb8YAHrmjUipUzBOaitPetou/ur7tV3vrseWalFpkRj/s67u7gHO83NqsO30xtkfPf0qXQv+Pq6/wCvC8/9JpKs+JNTXU3t3Gt6tqrICC2pR7TGOMBf3r5zznp071W0QhJr2VjtjSwu9zngLugdFye2WZVHqWA6mqjuj05NvDu+9n/Wy/I5Ciiiu09w7j46/wDJVNf/AO2H/oiOinfHR2HxU18BiB+47/8ATCOitcb/ALzU/wAT/Mxwn8CHovyF+B3/ACVjQ/rcf+iJK4Su7+B3/JWND+tx/wCiJK4Srf8Au0P8UvyiKP8AHl6R/OQUUUVzm4Vs+F/C+peMNYg0rSoPMuJOWZuEiQdXc9lGf1AGSQDS0nSb3XNRttO062e5vbltkcSdWP8AIADJJPAAJPFez+J9Yh+EPh+LwjoARPEN5Akuq6lHIGdGIPyIeCD125A2qQQNzFh14ehGadSppBb+fkvP8jmr1nFqnT1k/wAPN+Ql7rnh34NwajpHhhn1HxZIqw3OqTKpjtzj5kQeoIzs5GSNzNs215Tf3t9r+o3Go6lcST3Vw2+SV+rH27AAYAA4AAA4qtBbggO3TsKsvIsYyx/D1p1sRKqrbRWyWy/4PmOlQVPXeT3fX+vIEjWMYUf/AF6HkSP7zAVSkunfgfKPbrUFcjqpbHUqXcvG8jBx8x9wKZ9t/wCmf61UoqHVkV7OJb+2/wDTP9aeLxDjIYVRoo9pIPZxNNJUf7rAn0pzKHGGAIrKqWO4ePjOV9DVqr3JdLsWVWaymiuLWWSOaJg6PGSrowOQQR0IPcV6rpnj3RPiLp1voHxB3pdrPm11mAJGYt3UOcYUHAXO0qQQSAV3V5dFMsoyDz3FRz24bLrwe49a6qNeVK/Lqnunszlq0Y1Pi0a2fVGn488B6l4B1g2N8PMt5MtbXarhJ0HcejDIyvbPcEE8tXtHw68VWniywi8AeLE+0afcfLp92zhZLWQA7VDH8l6nJ2YZWwPMPFHhfUvB+sT6VqsHl3EfKsvKSoejoe6nH6EHBBAeIoR5VWo/C/wfZ/oyaNWXM6VX4l+K7/5mNRRRXGdQVsaPriWUTWd9bveaY7GTyUlEbxvgDfG5VtpIADDBDADIyqsuPRVRk4u6JlFSVmdf5vhT/oK61/4K4v8A5Jo83wp/0Fda/wDBXF/8k1yFFae1X8q/H/Mj2b/mf4f5HX+b4U/6Cutf+CuL/wCSaPN8Kf8AQV1r/wAFcX/yTXIUUe1X8q/H/MPZv+Z/h/kdf5vhT/oK61/4K4v/AJJo83wp/wBBXWv/AAVxf/JNchRR7Vfyr8f8w9m/5n+H+R1/m+FP+grrX/gri/8AkmjzfCn/AEFda/8ABXF/8k1yFFHtV/Kvx/zD2b/mf4f5HX+b4U/6Cutf+CuL/wCSaPN8Kf8AQV1r/wAFcX/yTXIUUe1X8q/H/MPZv+Z/h/kdf5vhT/oK61/4K4v/AJJo83wp/wBBXWv/AAVxf/JNchRR7Vfyr8f8w9m/5n+H+R1/m+FP+grrX/gri/8AkmjzfCn/AEFda/8ABXF/8k1yFFHtV/Kvx/zD2b/mf4f5HVTa7pmkqW0P7bNfn7l9dIsJg/3IlZ/nGOJC/GThQwVxytFFRKbkVGKiaml6utnG1tdwtc2DNv8AKWTY6Pj7yMQdpOADwQQBkZCldTz/AA7/ANBDVf8AwXx//H65eisZU4y1ZjUwsZS5k2vS36pnUef4d/6CGq/+C+P/AOP0ef4d/wCghqv/AIL4/wD4/XL0UvZRI+p/33+H+R1Hn+Hf+ghqv/gvj/8Aj9Hn+Hf+ghqv/gvj/wDj9cvRR7KIfU/77/D/ACOo8/w7/wBBDVf/AAXx/wDx+jz/AA7/ANBDVf8AwXx//H65eij2UQ+p/wB9/h/kdR5/h3/oIar/AOC+P/4/R5/h3/oIar/4L4//AI/XL0UeyiH1P++/w/yOo8/w7/0ENV/8F8f/AMfqhqWsQtA9npscsVq+POklYGS4weM44VcgNsBPPVmwuMaimqcU7lQwsYtSk27d7fol+IUUUVZ1HcfHX/kqmv8A/bD/ANER0UfHX/kqmv8A/bD/ANER0Vrjf95qf4n+ZjhP4EPRfkSfA8L/AMLX0Pk5zcdv+mElcHXd/A7/AJKxof1uP/RElcJVv/dof4pflEUf48vSP5yCiiul8BeE5fGviqw0lA4gkbfcyJn93CvLnOCAccAkY3Mo71lCEqklCO7NZzUIuUtkej+Crew+GPgb/hM7+3hl8S6luTSbe4LArGcAuFxkZBLFs4KFQGXec+UAy3txLc3MjyyysXeSRizOxOSSTyTnvXZfFXxRF4n8VG208oui6Wv2OyjhwIgq8M6gErgkcFcZVU44rlVUIoUdBXZiZptUofDHT1fV/P8AI5sPBpOpP4pfgui/rqJI4jQsf/11mu7SMWY81PePlwgPA6/Wq1edUld2O+nGyuFFFFZmgUUUUAFFFFABRRRQAqsVIIOCK0YZRKmeN3cVm1NavslAzw3FaU5WdjOcbomuYf41H1r13Fr8YPh9N5iI3jfw/BiMq7NNeQLjkjBLk/MMDJD4OVD4PlhGRg9K0/BPiaXwR4rsdUQubdG2XEa9ZIW4YYyAT3AJxuVT2r0MNUUJOM/hlo/8/lucOIpuceaHxR1X+XzOOorvvi54Ti8M+KnnsAjaLqy/bLKSHBi2tyyKQAuATwFzhWTnmuBrmrUpUpunLdG1KoqkFOPUKKK9X+DXwL1D4uRa7qT6vaaH4b0GHztQ1S7UusY2s2FUEbiFUk8gAfUVk3bc0PKKK9l8U/B/wXZeC9a8R+FPitpviN9I8oy6e2nSWVw6vKke5VkYlgC4JIGPfmvGqE7gFFFbPhHQf+Eq8V6FoX2j7N/at9BZefs3+V5kipu25Gcbs4yM46igDGor3zxJ+znpXhH40Wvw+1r4gWWnafNY/bG1y9tUgijJViEKNMByVxnf36VF8Kv2dbT4qfErxb4SsPGUCWWhCR4dWt7MXEd6iyhAyqJQAGB3Ahm/HrS5luFjwiipbmH7PczQ7t3luUzjGcHFRUwCivYPg18BLr4r6T4h1+71210Hwz4fjMl7fzQtOwwhdtsakE4VcnkdRjPbk/iD4P0DwrNYSeHPGmn+KdPvA5EtvbyW0sJXHEkUnK53cHJzg+lK6vYLHF0UV7/8MfgR8P8A4nXOh6RYfF3yvFWp2/mvpP8Awjdw3kyCMySR+cZFRtoVvmyAccdaG7bgeAUV7r8T/gp4A+Gza7pknxa+2+K9KXA0j/hHZ4/NkIDBPO3sgyGBzkivCqadwCiivXv2ffgb/wAL28RarpH9vf2N9gtPtXm/ZPtG/wCdV243pj72c5NDdtWB5DRUtzD9nuZod27y3KZxjODioqACiiigAooooAKKKKACiiigAooooAKKKKAO6+OgX/hamv5Jz+47f9MI6Kb8df8Akqmv/wDbD/0RHRWuN/3mp/if5mOE/gQ9F+Q/4Hf8lY0P63H/AKIkrhK7v4Hf8lY0P63H/oiSuEq3/u0P8UvyiKP8eXpH85BXtnwmkTwp8OPGXi9G/wBOGLG3ZYVZ4Xwu1gW6qXlQkY/5Z554FeJ17P48H9hfB/wDon+u+2btR877uzIL7NvOf+PjGc/wdOeN8C+Rzrfyp29XovzMsX76jS/mf4LV/keV2iZLOR04FW6jgXbEvTnmpK5lsdLIJII3kyzEM3ak+xx+rfnUd63zIvcDNdV8LdU8O2Hj7w9ceMVlfw5BdpJdeXEsvA5XehB3x7gu8AElNwAJxWMpRTd0axjJpWZ9C/BH9kHS/HHguDxJ4t1HVrP+0v3lla2W2J1hBIDyGSNs7+GXaMbcHJ3YX0r/AIYY+Hf/AEGfFP8A4FW//wAYr6O0fVrPX9IsNW06bztP1CCO5t5dpXfG6hlbDAEZBBwQDV2vEniKjk3ex60aEEkrXPmT/hhj4d/9BnxT/wCBVv8A/GKP+GGPh3/0GfFP/gVb/wDxivpuip9vU7lexh2PmT/hhj4d/wDQZ8U/+BVv/wDGKP8Ahhj4d/8AQZ8U/wDgVb//ABivpuij29TuHsYdjxr4e/sufDrwD/aOdN/t/wC2+X/yMEFvd+Rs3f6v90Nu7dz67V9K7C7+FXw1srSe5l8AeGmjgjaRhDoUMrkAZO1FjLMeOAoJPQAmu2XAYZ6VJuT2/KumlWk46yXzOWtSipaJ/I/Mr9o/VPAHiTxxp938PYbGHRU02OKVbCwNnGZxLKWJQouTtKfNjpgZ4rx9baNZFwzbhzivqH9p34jfCPxh4Rtz4EOlyeJpdWW5u7i30h7aeSIxy72aVol3ZdkJBJJPPbNfLFo377nJLA16cXHRWOFqVm7l6q92mUDY5H8qsU113oy8cjvW7Mkeo6vIni/4BWl9M3+neGrlbcyPCuXTKoEUjouyWLJ7mPkHrXiVe0fAsf2sPF/hn/Vf2vprf6T97ysZj+7xn/XZ6j7vvx4vXTjPfp0q3dWfrHT8rHNhlyTqUuzv9/8AwbhXvn7PPx1g+EmmeIdL8Q+G5ta8Ga+RDdCMD5H2EMvzfK+5GwVJHQHPXPgdekfDX42+IfhfpuqaVp1lo2o6TqjrJdWWrWQuIpGUYBIyD39a8+SujsR9A+Jvg38Hvih8H/E3xB+GSalotxoUcss1pcuxQtGgkaNldmwSp4KPjJ/CvRNJs/DXwa+AHgTUdL8YWXgi912C3ubrXm8Ptqst3LJD5jRcfdHJAz2XAwcmvlXxh+0p4t8VeEJvCVpp3h7w34duTm4svD9h9lSbkEhvmbgkDOMZxg5HFR+Cf2j/ABd4M8KDwpNaaH4h8NIcxad4gsftUUXOcKNynGTnBJA7YqOV2HdHrPxj1D4SfF3xr8MU8Paza3muX+p22m69cWemzWC3MbuimYq6gA53Y+YkBgCSADXpPxW+IOoeD/2gfh38MtJ0TS4/BYl08jTvsMZDM8+BKjY3IY9oIKkcoc5r468ffFrW/iC+lC4s9H0m10pnks7XRLFbSOF327mG3kn5F6k4xxXoFx+174+vV0Wa7svDdzrGksnlaxNpoN6yAgshk3fKrgYbYFJBPIzmjkegXPp3VP8Ak/HRf+wA3/oqWsX9nP8A5Ou+NX/XW6/9KxXzTP8AtO+Lrj4tWvxMbTtDGu21mbJYBBL9mKFWXJXzd2cMf4sdOKq+C/2jvFXgX4g+KPG+nafo0uq+I2ka6iuYZWgTfJ5h2BZAw5HdjxS5HYLn0v8As/8Ai9/jJ4X+LPhTX9L0seGtOgB06xt7OONbRXE4wCBlmGxSHYltwJzXwTXp/wALfjr4i+Ef/CS/2JZaVcf8JDGsdz9uikfYF342bXXH+sPXPQV5hVxVmxNn3r8MNV8Nfs0/Avwn4j1KwudWg8eXUS6tKH3RW8TxyEAR8g7V4K9W+bngAV779mL4ceEZfGfxC1R7XVvhs2k/b9ItxeSxlJnOQivGyll+6qZJz5gBBIyfm/wJ+0b4u8DeFX8KG10TX/DO4smm69ZfaoYiTuO0blOM84JIB5A5NdLc/tgeNdR0TUdA1LQfCV94dvYFtxpUunOlvAg7RiORWHY8k4Kgrio5ZX0HdHz7Xuv7HP8AycT4R/3bz/0kmrwtyGZiFCgnIUZwPbmur+GvxB1P4WeM9O8V6PBZz6jp4lEcd4jNEd8bRnIVlPRzjBHOK0krqwkfXfhrwLoPjr9t7x1F4gtYby20yD7fDaTqGjllVLdF3KeGAEhbB7gV1F78XvhkdY8UaD8Q/iTpmu+HpGltY/D7eD7i2/sx1fGEmVWJKgEZ65AIIxg/GN98Z/Fdz8Ubn4j2dzDpfiSeUSk2SERD5AhXY5bKlRyGJrub/wDax8U310+or4V8C2+vPgtrMeiK14WH8Rd2YZ/CocGO57f8MNatPCP7HnjrU7CC21W1sNXnNmL2HfHJ++gEUjIQM4JV9pHUYI7VD+xt8QvEXxK+LvibWPE1+t7fx6Elski28cIWJZ1KqFjVRwWPbPNfM+mfHDxDpXwl1f4aQ2elvoWqTm4muHik+0hi6N8rBwoGYx1U9TUXwe+NOv8AwS1nUNV8P2mmXVxfW/2aRdQjkdAu4NkBHU5yB3NDhowufWH7P/i9/jJ4X+LPhTX9L0seGtOgB06xt7OONbRXE4wCBlmGxSHYltwJzXFfAuw8eeCfguPFs3xVs/AvgW6vHkhVtFj1GWWQt5RbaV3DJjwACeFJwOteG/C346+IvhH/AMJL/YllpVx/wkMax3P26KR9gXfjZtdcf6w9c9BV/wAEftG+LPBPgmTwYLHQdb8Oly8Vnrdj9pSAltx2jcAfmJbDBgCaHF62C571+1/oei6r8HPAPjmCe11LWLu4it31qCwNkdQikgkfe0R5GTGCAem444NdF+0N8TNX+GXwu+D994ejs4dbuNOCRajPaxzyWyC3g3iMSAqCxK5OM4XHc18v/EX9ojxb8UfA+k+E9fg0o2emXC3UdzbwPHPI6o6AN85QLiQ8KqgYGMAYrP8AiV8bvEHxT8P+FtE1iz0uC18NQmC1ezikV3UoiZcs7AnEa9AOpoUHpcLn0Tpep3eu/sLeO9SvZfPv73VmuLiQKF3yPewMzYAAGSScAAVW1uGSH/gn7oAkQqWviwBGMg30xB/EV4V8M/2gfFPwu8O6p4csbXR9V0DUmMk2n6xam4h3EAMQoZeoVcg5HHSrni79pLxf42+HI8C6ra6N/ZSzCZZre1aKZArl1jUK/lqi5CgBBhVA96OV3+YXPHqKKK0EFFFFABRRRQAUUUUAdx8df+Sqa/8A9sP/AERHRR8df+Sqa/8A9sP/AERHRWuN/wB5qf4n+ZjhP4EPRfkSfA92PxX0MbjjNxxn/phJXB13fwO/5Kxof1uP/RElcJVv/dof4pflEUf48vSP5yCvaP2gB/Z+t6Bolt8mmafpqfZ4evl5ZkPzHk/LEg5J6e5rxevaP2jf+R3sP+wbH/6Nlrah/utX1j+pnV/3in6S/Q80UbVAHQDFVL1vmVfQZq5VC7bMxHoMVyVfhOun8RBRRRXMdB+qOheJrT4XfAbw5rHiWK6tYdG0KxW5g8k+esnlRoIthxhy5C4bABPJABI8i0fW/wBov4tRDxFoFxo3g7w/cRh7G3vI0c3ETM5V8tFI5O3b8xEasNrKuCTX07qukafr1hNp+q2Frf2E2PMtruFZYnwQwyrAg4IB57gVj3OtW/h3UNL0G006KO0McUUKwkRpCmdiqqAYAAAwBj0rzcPTnWk40o3lq/kvU7MTWp0IqVWVo6Lru/Q8U8EfGDx34I8b6Z4F+L+nxeZq8hg0nXrOMFLuXzSoDhPlw25AMKjJlC64csPpCszU/Dmja1d2F3qWk2F7d6dJ5tpNc26SPbPkHdGzAlDlVORj7o9K0655yUtUrHRFNaNhXgPxb+M/iiPxc3w5+F+jf2n4xWBpr24mQCKxjMe5Spcqm/Do25zsBKrh2YhffqzIPDmjW2tXOtw6TYRa1dRiKfUEt0W4lQbcK0gG5h8i8E/wj0FEGou7Vwkm1ZM+b9Stf2n/AAVCNZbWNB8Vw224y6XbW6FnXYx3bRFC7YIGFjbcW2jawyK9q+E3xQ0v4ueD4PEGmRS27CQ291ay8m3nVVLJuwA4wykMOoYZAOVG1qniX+zdbstN+y+Z9p2fvPMxt3MV6Y56etXND8OaN4YtHtNE0mw0u0eQytDY26QIzkAFiqAAnCgZ9h6VvXpThCMqkbc2qtbVHPQrU6k5Qpyvyuz30Z+PV5Z3GnXdxZ3lvLb3dvI0U0EyFHjdThlZTyCCCCD0qGu0+MH/ACVrx7/2Hr//ANKHri69JO6ucbVnYntGxMB6jFX6zYG2zIffFaVdNJ6GFVanafA68nsviXp8EMm2O6jnhmGAd6CNnA9vmRTx6fWuG8W2NvpnivXbG0j8u1tb6eGJMk7UWRgBk8ngDrXZfBj/AJKlo31uP/RElcr49/5HnxP/ANhO5/8ARrV2z1wcb/zP8kcUdMU/8K/NnPUUVtweFr248LXHiKN4DZ29x9nkj3HzRwvz4xjbl0Gc5yw4rhOsxKK6PVfBGr6XPpNt5P2u71O2F1Fb2itJIoJIKsuPvAqcgZxWTHo+ozagdOjsLp9QBKm1WFjLkdRsxnP4UAUqK0INB1W6vJ7ODTL2W8gBMsCQO0kYHXcoGR+NXr3wxLb+K4/D8M6STyTRQJLIpRdz7cZAyQAW96AMGiunTwlbvrem6VH4g0+5mvLyOzcWsU5aHcwUsRJGgIBPQH/GsdNF1CeSNbayupxNK0MRjhZvNdeqrgckAg4HrQFyhRWpF4Z1ue6mtYtH1CS6gYJJCls5dGIJAK4yCQCefQ1HZ6DquoTSw2mmXtxNC4jkSGBnZG5+UgDg/K3H+yfSgDPoq62j6iunLqLWF0NPZtoujC3lE+m/GM/jVn/hGtUinhhu7G6szPE80ZuLaQeYqIWJACkkYHUDA6kgZIAMmiitTRNDm1uS62T29tb2kXn3FxcMRHEm5VBO0EnLMoAAJ5oAy6K6Gx8KNf317bpq2mrb2dsbuS8LSNF5e5V4CoXzlhwVBqa28IRXUV9cR+ItI+w2XlCS6K3IQtJu2qB5O7PyHJKgdOaAucxRXRnwXqA1a208S2r/AGu3e6t7lJC0M0aK7EggZ/gYYIBBGDio4fCN7NrelaSstuLnU4oZomLNsUSKGXccZBwecA/jQFzAooopDCiiigAooooAKKKKACiiigAooooAKKKKAO6+OjsPipr4DED9x3/6YR0U346/8lU1/wD7Yf8AoiOitcb/ALzU/wAT/Mxwn8CHovyH/A7/AJKxof1uP/RElcJXefA8L/wtfQ+TnNx2/wCmElcHVv8A3aH+KX5RFH+PL0j+cgr2j43H+1bDwR4jm+W+1XTR5yJxGuAj/KDyOZm6k8Ae+fF69muz/wAJP8AtPuh8914cvjBLNccv5ZOAkbcnbiWEYOB8n+yM7YX3qVWn5X+5/wCVzLEe7Upz87fev87HmqElFJ6kCs+dt0zk+uKt2rZix3U1RZtzFj1JzXFVeiO6mtWJRRXT/DfVrPQPiJ4R1bUZvJ0/T9WtLm4l2ltkaTIzNhQScAE4AJrnbsjZbn671wNr/pvxHmlg+eODdvPTGI9h6/7RxXcWd5b6jaW95Z3EVxaXEaywzwuHSRGGVZWHBBBBBHWuH8Ff6d4i1jUY+IG3YVvvfO+4e3RT3rPLPco4mr2hb/wJ2/4Yxzb95XwtHvPm/wDAVf8AXU76vMfEHxs0jS7iW20+1l1GWKTYZA4jhYY5KtyTzx0weSDjGe38T6NJ4h0G90yK8eza5UIZkUsQu4EjGRkEAg89DXl3/Cgf+ph/8kv/ALZXjO/Q+vy+GCd5YuXotfvujQ0n466ZczbNS024s1ZlCyROJlAJ5LcKQBx0DE8/j6rDNHcQxzQyJJDIodHQgqykZBBHUGvGv+FA/wDUw/8Akl/9sr0TwR4Wk8H6M2mvqD3q+c0iMyFBGpA+UDceMgn6saSv1LzCGA5ebCS17a/qZPxKgkaDTpwv7pGdGbPQkAgf+On8q7aCeO5ginibdFKodWxjIIyDXNeP7Z59AMilQIJlkbPccrx+LCtTwzcpdaBp0iBgBCsfzeq/Kf1Fe1iP3mW0Zfyykvv1PjcN+7zWvD+eMZfd7uh+VXxg/wCStePf+w9f/wDpQ9cXXqn7SPiLS/Ffxr8V6rot7FfabLJBHHcwnKSGOCONip/iG5GAYcHGQSCDXldXD4Ubz+Jiq21gw6g5rVrJrQkk/wBH3HGWX+ddFJ7mFVbHovwA06K/+IH2iVnEljaS3Ee0gBmJWPnjpiRumOQK8u1fUpdZ1W+1KdUWe9nkuJFjBChnYsQMknGT61638NT/AMI58NvHXidvlkeIWFtNBxPDIRjIbjau6WI8HPyZxwM+MV3V/cw9KHe7+/RfkcNH3q9Sfay/V/mFdt4e8WWWh+HrW2ngF9m9uGubFiUEsLxRqPnwQPmTI68qOK4miuI67HpTeL7HV9OW3vNS+zX99ps0E92Y3KwytfPOVbaCdrIQCVBxuA9RUMviLS7m61Cx/tJo1n0iDTl1V4nw7xsjEsAC+xghTpnAXI6ivO6KLiselah4h0nVdPuNJTWjayRLZf8AEykilxd+QjqwIUFxguNuR0QZ28YzNT8Qafc/FKHW0u3k01dQgna4dGDFFKbmK4zng8VxFFFx2PRrjW7SPxVompTa3oNzZ2+qRXDjTtMa3ljjEgYs5FvGWAA6ZY57VFceJbG+1iy1O31CKxUwSWcljPBI0ECFCp27BkRuGJOPnDEnn7x8+oouFj1JTpFz4d8Sw2Ws/Y7R5NOjacidoPMCzkouQZPL4yMgnIHbmsnX/FVnfWfiiO1u5d1/PYKpZWVrlIYpFeRvTc21sE5y3sa4hbmZIJLdZZFglZXeMMQrMudpI6EjccemT61FRcVj0+98Y6VNpnn2p06G4k06KweJort7ldqKpwPMEG3cu4Hg/wCznJLZPEGiLqCahNqUMt/cC9ad7SOdYmMls6qXSQcSF2A+T5QDXmVFFwsauh3f2Q6j/wATD7F5tnLF/qfM8/OP3X+zu/vdsVP4WvnsL6V01aPTGkiKeZPAZoZASMpIoVsrxn7rcgcd6w6KBnp1lr+hWuuag9reabatcaP9me6ksGNpLdeYjFhD5bYUqvdAMgnAzVL7Vp15puu6fd+ItEjmu2tJI57WxmhgIjMu5dkdupDDcOduDnrXn1FFxWPQ7TxJpGn6poFpFdvJYaTY3cL3jRMBLLKkp+VeoXLqoyB3JxV3TviBbWfiPwwfMsP7Ls7S1iuJn02J5Y2WMBwJDGZOD3U/SvL6KLjsFFFFIYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB3Hx1/5Kpr/AP2w/wDREdFO+OgX/hamv5Jz+47f9MI6K1xv+81P8T/Mxwn8CHovyF+B3/JWND+tx/6IkrhK7v4Hf8lY0P63H/oiSuEq3/u0P8UvyiKP8eXpH85BXsfwH1iC6n1zwbfyzLa69bOsRRz8jhGDhVwQGZCTuP8AzzA54rxyrFhfXGmX1rfWknl3VrKs0T4B2upBBweDyB1ow1f2FVVO2/p1HiKXtqbh/V+heuba40m+vLK6Ty7m3d4ZUyDtdSQRkcHkEcVRr1v4s6YviXTdJ+IOlW7/AGPU4FS+VdzC3mX5OScHGRsyFC5jB6uK8krPGUvY1OTdbp909maYSr7Wnzdevk1ugoqW3h85yC21FUszYzgD2p/l2f8Az+/+QjXKdLaR9P8A7M37SyeB9NHgnxK0UejqJG0u/K4FrKxL+XLjrGzsSH6qWOTtOY/sL4aQI2jSajGxeO+KPFIDlJYtoZHQ9wd55GQeMV+T3l2f/P7/AOQjXp3w0+PXi34VbING8RfaNJXP/Er1CF5rUZ3n5VyGj+Zyx8tl3HG7PSlJtUJ0aaXvtN/Iz5IyxFOvN/AmkvU/UiivMvhD8XX+LehWWrWfhi9t7WeSWKa5jvLWaC3dM/K37xZgSNpwYgfnB+6Qx9QMTg42n8q8eVKcd0evGrCWzGUU7y3P8J/KuK+JPj6X4caFqWsT+H7280+xtDcPdrdWsNur8hY2MkofJbaPlRyd4Chm+WlGnOWyHKpCO7Og8RWf2/Q76AB2YxllVBkll+YD8SBXxp8bv2kUsfBDeBvC01ndyanBIl5qUEiTRx20mQ0S4JHmN84JONqkYBZgyeX/ABS/aa8W/E37TZf2z/YugS7k/s7TkdPMjO8bZZfvSZR9rDhG2g7Aa8X8uz/5/f8AyEa9ihzQw7oTSavzejtY8itGEsUsTB2ajy+qvcr0VY8uz/5/f/IRps8CxrG8cnmRSA4bGOh54qi7pkNTPIWijXPQVDXpnwc8MLe6zJ4k1NHj0HQFa7lnKsVMiDcqjBySv3zgH7oBHzCujC0pVqipx6/1f5GGJqKlTc30Nj4p3X/CIfDzwt4GVpkvmjW9vUMv3MliUO0bXUys+OTjyh1yDXidbPivxFceLPEWo6zcrtkvJSwTIPloBhEyAM7VAGcc4yaxq3xdZVqjcdlovRbHPhqTp07S3er9WFFFWLa28395JkRA4yOrH0H+Pb8gec3K9FaWLccC1jIHdmbJ+uCKX9x/z6Rf99P/APFU+UXMZlFaf7j/AJ9Iv++n/wDiqP3H/PpF/wB9P/8AFUcocxmUVp/uP+fSL/vp/wD4qj9x/wA+kX/fT/8AxVHKHMZlFaf7j/n0i/76f/4qj9x/z6Rf99P/APFUcocxmUVp/uP+fSL/AL6f/wCKo/cf8+kX/fT/APxVHKHMZlFaf7j/AJ9Iv++n/wDiqP3H/PpF/wB9P/8AFUcocxmUVp/uP+fSL/vp/wD4qj9x/wA+kX/fT/8AxVHKHMZlFaf7j/n0i/76f/4qj9x/z6Rf99P/APFUcocxmUVp/uP+fSL/AL6f/wCKo/cf8+kX/fT/APxVHKHMZlFaf7j/AJ9Iv++n/wDiqP3H/PpF/wB9P/8AFUcocxmUVp/uP+fSL/vp/wD4qj9x/wA+kX/fT/8AxVHKHMZlFaf7j/n0i/76f/4qj9x/z6Rf99P/APFUcocxmUVp/uP+fSL/AL6f/wCKo/cf8+kX/fT/APxVHKHMZlFaf7j/AJ9Iv++n/wDiqrXFsqqZIdxjH3lY5K/4j3/D0yNBcq0UUVJR3Hx1/wCSqa//ANsP/REdFHx1/wCSqa//ANsP/REdFa43/ean+J/mY4T+BD0X5D/gd/yVjQ/rcf8AoiSuErvPge7H4r6GNxxm44z/ANMJK4Orf+7Q/wAUvyiKP8eXpH85BRRRXObm3a+KNSg8NXPhxJtul3Fyt26DglwuMEjqpwpwc8opGOc5lRxd6nhiM0qRjOWOOBnFTUlKTV3saU4qKuupJM32ew2H79wQceijofxNZ1Wr+YTXLbceXH8iYOeB71VrJiCiiikB9E/sjfGr/hWvjpdE1rVPs3hDXMpN9ol2wWlzgeXOflO3O0RscqMMGY4jGP0vr8R6/Sj9kP44yfEzwjJ4d1u6mn8VaBGvmXFzMjSX1uWISQDhiU+VHJB5KMWLOQBjR9IV8D/ttfGr+2tYg+H2gapv0zT8vrH2aXKTXIb5YH+Xnytu4gMRufBAaLj6Y/aQ+MkXwc+H095btu8Q6pvs9LjV490cpQ5uCr53JHwT8rAsyKcBsj8rr29udSvLi8vLia5vLmRpZp5nLySuxyzMx5JJJJJ5JNCBkFFFFAgrQsm8+2ltv4wfNT3IHI/Ks+pbadraeOVeqnOPUdxTQEtakHijUrHw7qOgQzY03UZY5ZozzyhyNueFydpJAydijOAQaV3EIZ2VOYz8ynsQaqy/dH1rSEpQlox1IqUdSKiiirMwrSHFpagcAoWPudzDP5AflWbWn/y62n/XM/8AobVUSZDKKtaZp1xq+pWen2cZku7yZIIkH8TsQqj8yK9t+Ivw8sbeTQprnSbnw7oun6kNAur6SxaH7TCoUpecgb2fExLc9F9qdyTwiivSrjwjY21v4gntbW7trVNGa5hM9xbXySMt1DGSk6JtxhznaFZTwTgkHU8L+EPDf9u+Dri3trvVrOS/sEvJxdwSQM0pXdHJBsLxAOSvz7g4UgYyCC4HkNFeo6P4M0DxD/b2sRQXFtpdjdRWkdjca3aW0jyOJGLfaJkRAoEZwgQsc9cAmp38BeEdLNuLy+1DUVvNbk0uCbTbqDyxEI4HEhYK6symfBVTgkcMuOS4Hk9Fa0nh+6bxO/h+1Hn3pvTYxgDHmPv2D8zXuPif4fQ2niHwZOPDEmn6dp+vQaBP9psTEmoxKyFLhgygSeZibceeAo9KLgfPFFeifD6xtLj4rG2nhsjao1+Ql1AJYE2QTFS0ZVgQpAONp6dDWvqy6Drukai1rPpt1q+m6NLPeXml6attbTMbuBYwsbxJtYK7ZdEQnIGSN2S4HklFeoeLfBfhfSJvFMGm/wBsO/hq+jhna5uIsXUTSFGC4j/dsCAAx3A8naOlXPFHhzQtR+KPiSx03w5fDT7CWf7RHHq9tZwxESBQ4keARxR8hQhzyRhuxLgeR0V6pq3w/wDD3hmLxDeam+o3VtZHTWtIbO7gzIt1DJIVaZVdDt2YDoCGwcD5gRgfDKxspNYvtT1VIDpWlWck87zw+csTPiGF/K6SbZZYyVPBAOfSi4HFUV2HjfwvqmlFNW1GPTYI76Yx24sFCRXKqiEzxKo2+W29eRgbiRtGCB3mkeEtH8UeAvCVo9va2d5bxy6peXyRqsstmt1LHcbm6uUURsoPQBqLgeJ0V6z8TtF0q9h1PxFZWMWmlYtEMVlZoscCC6spJZPlA67o15z3Oc543vCnhvS9G13UtDnglvNMXxLoUTRTspMgcT8NlSCuW5GORkcZzRcDwiivQW0PTdZ0rxLLo1u9ksWo2VvDFqF1bsAXFxuJnaOMIuUHAKj+9uwCNbwPpaaP4f8AGbXd34atb+znsY0vtQtotTt0D+cWVCkU6ktheVH8OCRii4HlFFe1WGm6B/Yd/qWsWSaobjQbi7D6ckFkisuqeVui/wBHyuRjBZcqpZcAEBeV03wTpuo6h4NiEl4kOu2NzdzDzFLRmOa5RQp29NsCZyOpPTIALjPP6K6/xno2heH7fSbWxXUZNTubCzvriaeZPJTzoFkaNUCZPLAhi3A4wfvVyFAgooopgFSQ8+aDyDE+R64UkfqAfwqOpYOsn/XKT/0A0IDKooorM0O4+Ov/ACVTX/8Ath/6Ijop3x0dh8VNfAYgfuO//TCOitcb/vNT/E/zMcJ/Ah6L8hfgd/yVjQ/rcf8AoiSuEru/gd/yVjQ/rcf+iJK4Srf+7Q/xS/KIo/x5ekfzkFFFFc5uSxfdP1q5C32e2muD1x5aeu4989sCqKybRjFaV1bLNFbxpdWwWJTndJzuPX8Kzad7mnMrWMiir39m/wDT3af9/P8A61H9m/8AT3af9/P/AK1Tysm5Roq9/Zv/AE92n/fz/wCtWxY/D/xBqdrHd2Om3N1ayZ2TQQSOjYODhguDyCPwpxpzk7RVxSlGOrdjma7D4X/EXVvhX410zxLpM0wa2kUXNvHJsF5blgZIGJBGGA6kHaQGHKghv/CsPFf/AEA9Q/8AASX/AOJrA/stv+fm1/7+f/WpypTj8SsEZxl8Lueh/Hz4yXvxo8dXGrbruHQbb9zpdhcOp+zxYAZiF4DuV3N94jhdzBFry2r/APZbf8/Nr/38/wDrVuQfDjxNdQRTwaReSwSqHSSO2kZXUjIIIXBBHeiNKcvhVwlOMfidjlKK6q4+HHia0glnn0i8igiUvJJJbSKqKBkkkrgADvWH/Zv/AE92n/fz/wCtRKnOPxKwRnGXwu5Roq9/Zv8A092n/fz/AOtR/Zv/AE92n/fz/wCtU8rHckVvtFgjfx252tnqVPTn9MVVf7hq/ZWq28rF7q2MboUbbJzg+lZ8jbWdODgkZU5BqkmVzK1iKiiitDMK0/8Al1tP+uZ/9Dasyr9tKJ4kgP8ArUyE/wBoHnb9c5Pvn6A1Ell/RtYvfD+p2+padN5F9bktFLtVihIIyAQRnng9jyOasaP4m1XQIrqLTrswR3ZjMq7FYMUbcp+YHBB9OxIPBIOUylSVYEEcEHtSVRJ0d/4617UUmimu4kgmtjZtBb2sMMQiMiyEKiKFUl0UkgAnHJpW8feIDaW9qt8sSQSRSiSG3ijldozmMvIqh5Np5G4nFc3RSA6ZPH+uxX95epLZK96qi4hGnW32ebbyrND5fllgSTu255PPNU7jxbrF15Hm3hb7PeNfx/u0+WZggLDjpiJBt6DbwOtYtFAGrZ+JNT0/Xv7dtrny9W815xceWpIkbOWAIwDySOODyMYFP0PxTq3hvzf7Mu/IEskMrgxo4LxSCSNsMDghhn6Eg8Eg49FAGjYa9qGmaq+qWtx5d+4lBl2Kc+YrK/BGOVdh04zxUVjqt3psV9FazeXHfwfZrgbQd8e9X28jj5kU5GDx9ap0UAbF74q1fUZdZlubvzH1qQS3p8tB5zB94PA+X5uflxWkfiN4ia+kvXubR7iaD7POz6fbsLlNwb96pjxK2VU7nDNkDmuVooA39Y8ba7r8d3HqN956XZtzKPKRd3kIyRfdUY2q7DjrnnOBVPQ/EGo+G7x7rTbgQyyRtDIGjWRJYz1R0cFWU4HDAjgVmUUAb2u+M9a8S2lvaandRzW1q5eCJLeKNYMgAqgRRsQ4B2Lhc84zzWdd6teX1lp9lcTb7bT0eO3TaB5as5dhkDJyzE8561SooA6W28f+ILSWSRLyJ/MtoLRkmtYZYzHAgSL5HQruRQAGxu6nOSajuPHXiG6vL28l1KRru9uoL2aYIoZpod3lvkDgjc3TGc85rnqKANvU/Fuq6tHfx3ElssV/JFLcR29pDAsjxhwjYjRQD+8fJHXPOeKo2+r3lrpl7pkU22yvXjknj2g72j3bDnGRje3Q855qlRQBv6d411vShaLb3URjtLZ7OOKa2iljMLyGRkZHUq4LsW+YHnHoKtaX8RvEmjWqW1jfRRRxmTyj9khZ4hJneqMULIjZOVUheTxXLUUAXNS1W71eaGa9m82SGCK2Q7QuI40CIvAHRVAz1OOc1ToopgFFFFABUsHWT/rlJ/6Aaip0z/ZEdWBE7qVCnqgPUn6jIx759MgzNooorMs7j46/8lU1/wD7Yf8AoiOij46/8lU1/wD7Yf8AoiOitcb/ALzU/wAT/Mxwn8CHovyJPgeF/wCFr6Hyc5uO3/TCSuDru/gd/wAlY0P63H/oiSuEq3/u0P8AFL8oij/Hl6R/OQUUUVzm4UUUUAFFFFABVixv7vTLqO7sbqe1uo87JoJCjrkYOGHI4JH41XopptO6E1fRnc2Pxj8cafax20PiCdo0zgzxRzOcnPLupY9e59q6n/hpLxX/ANA/Rf8AvzL/APHK8dorqhjsTBWjUf3nPLB0JauC+49i/wCGkvFf/QP0X/vzL/8AHK56/wDjd44v/tS/2z9nhuNw8u3gjTy1bPCtt3jAPB3Z988159RTlj8TJWdR/eKODw8dVBFzUtX1DWZ1n1K+ur2dV2CS5maRguScAsScZJ496p0UVyNtu7OlJJWQUUUUhhRRRQAUUUUAFFFFAFhb66RQq3MwUDAAc4Apf7Qu/wDn6n/7+Gq1FO7FYs/2hd/8/U//AH8NH9oXf/P1P/38NVqKLsLFn+0Lv/n6n/7+Gj+0Lv8A5+p/+/hqtRRdhYs/2hd/8/U//fw0f2hd/wDP1P8A9/DVaii7CxZ/tC7/AOfqf/v4aP7Qu/8An6n/AO/hqtRRdhYs/wBoXf8Az9T/APfw0f2hd/8AP1P/AN/DVaii7CxZ/tC7/wCfqf8A7+Gj+0Lv/n6n/wC/hqtRRdhYs/2hd/8AP1P/AN/DR/aF3/z9T/8Afw1WoouwsWf7Qu/+fqf/AL+Gj+0Lv/n6n/7+Gq1FF2Fiz/aF3/z9T/8Afw0f2hd/8/U//fw1WoouwsWf7Qu/+fqf/v4aP7Qu/wDn6n/7+Gq1FF2Fiz/aF3/z9T/9/DR/aF3/AM/U/wD38NVqKLsLFn+0Lv8A5+p/+/ho/tC7/wCfqf8A7+Gq1FF2Fiz/AGhd/wDP1P8A9/DVaiii4BRRRSGd18dAv/C1NfyTn9x2/wCmEdFN+Ov/ACVTX/8Ath/6IjorXG/7zU/xP8zHCfwIei/IxPh/4iXwp460fVpGRYILnbM7qzBInyjtheSQrMRjuBwelHjPw+3hXxVq2jlXCWk7LF5jKzNEeY2JXjJQqe3XoOlcxJ/rH+pr0HS/EuheJ9D03QPFDPYXGnKyWmvxq07JFncIZYurIMsFIPy/KAANxLoyU4OlJ2d7r8mvK+mu2moqicJ+0Sv0f6P8/vOIor0EfBrxLefvNFfS9dtR8rXOmX8Txo/dCWKncBg9OjCj/hR/j3/oBf8Ak3B/8XV/U8R0pv7mL61Q6zX3nn1Feg/8KP8AHv8A0Av/ACbg/wDi6P8AhR/j3/oBf+TcH/xdH1PEf8+5fcw+tUP5196PPqK9B/4Uf49/6AX/AJNwf/F0f8KP8e/9AL/ybg/+Lo+p4j/n3L7mH1qh/OvvR59RXoP/AAo/x7/0Av8Aybg/+Lo/4Uf49/6AX/k3B/8AF0fU8R/z7l9zD61Q/nX3o8+or0H/AIUf49/6AX/k3B/8XR/wo/x7/wBAL/ybg/8Ai6PqeI/59y+5h9aofzr70efUV6D/AMKP8e/9AL/ybg/+Lo/4Uf49/wCgF/5Nwf8AxdH1PEf8+5fcw+tUP5196PPqK9B/4Uf49/6AX/k3B/8AF0f8KP8AHv8A0Av/ACbg/wDi6PqeI/59y+5h9aofzr70efUV6D/wo/x7/wBAL/ybg/8Ai6P+FH+Pf+gF/wCTcH/xdH1PEf8APuX3MPrVD+dfejz6ivQf+FH+Pf8AoBf+TcH/AMXR/wAKP8e/9AL/AMm4P/i6PqeI/wCfcvuYfWqH86+9Hn1Feg/8KP8AHv8A0Av/ACbg/wDi6P8AhR/j3/oBf+TcH/xdH1PEf8+5fcw+tUP5196PPqK9B/4Uf49/6AX/AJNwf/F0f8KP8e/9AL/ybg/+Lo+p4j/n3L7mH1qh/OvvR59RXoP/AAo/x7/0Av8Aybg/+Lo/4Uf49/6AX/k3B/8AF0fU8R/z7l9zD61Q/nX3o8+or0H/AIUf49/6AX/k3B/8XR/wo/x7/wBAL/ybg/8Ai6PqeI/59y+5h9aofzr70efUV6D/AMKP8e/9AL/ybg/+Lo/4Uf49/wCgF/5Nwf8AxdH1PEf8+5fcw+tUP5196PPqK9B/4Uf49/6AX/k3B/8AF0f8KP8AHv8A0Av/ACbg/wDi6PqeI/59y+5h9aofzr70efUV6D/wo/x7/wBAL/ybg/8Ai6P+FH+Pf+gF/wCTcH/xdH1PEf8APuX3MPrVD+dfejz6ivQf+FH+Pf8AoBf+TcH/AMXR/wAKP8e/9AL/AMm4P/i6PqeI/wCfcvuYfWqH86+9Hn1Feg/8KP8AHv8A0Av/ACbg/wDi6P8AhR/j3/oBf+TcH/xdH1PEf8+5fcw+tUP5196PPqK9B/4Uf49/6AX/AJNwf/F0f8KP8e/9AL/ybg/+Lo+p4j/n3L7mH1qh/OvvR59RXoP/AAo/x7/0Av8Aybg/+Lo/4Uf49/6AX/k3B/8AF0fU8R/z7l9zD61Q/nX3o8+or0H/AIUf49/6AX/k3B/8XR/wo/x7/wBAL/ybg/8Ai6PqeI/59y+5h9aofzr70efUV6D/AMKP8e/9AL/ybg/+Lo/4Uf49/wCgF/5Nwf8AxdH1PEf8+5fcw+tUP5196PPqK9B/4Uf49/6AX/k3B/8AF0f8KP8AHv8A0Av/ACbg/wDi6PqeI/59y+5h9aofzr70efUV6D/wo/x7/wBAL/ybg/8Ai6P+FH+Pf+gF/wCTcH/xdH1PEf8APuX3MPrVD+dfejz6ivQf+FH+Pf8AoBf+TcH/AMXR/wAKP8e/9AL/AMm4P/i6PqeI/wCfcvuYfWqH86+9Hn1bvgzw+3irxVpOjhXKXc6rL5bKrLEOZGBbjIQMe/ToeldIfg14ls/3mtPpehWp+VbnU7+JI3fsgKljuIyenRTVXVPEuheGND1LQPC7Pf3GoqqXevyK0DPFncYYouqocKGJPzfMCCNpDjQdJ81dWS6Pd+SW+vfZClXU1y0Xd91svO/6bsw/iJ4iXxX421vVo2RoJ5ysLorKHiQBEbDcglVUnPcngdKK5iiuOpN1Juct3qdEIKEVFbIkkkcOwDN1Pem+Y/8Afb86KKkoPMf++3504SPsY7m6jv8AWiigBvmP/fb86PMf++350UUAHmP/AH2/OnSSOHYBm6nvRRQA3zH/AL7fnR5j/wB9vzoooAcJH2MdzdR3+tN8x/77fnRRQAeY/wDfb86PMf8Avt+dFFADpJHDsAzdT3pvmP8A32/OiigA8x/77fnThI+xjubqO/1oooAb5j/32/OjzH/vt+dFFAB5j/32/OnSSOHYBm6nvRRQA3zH/vt+dHmP/fb86KKAHCR9jHc3Ud/rTfMf++350UUAHmP/AH2/OjzH/vt+dFFADpJHDsAzdT3pvmP/AH2/OiigA8x/77fnThI+xjubqO/1oooAb5j/AN9vzo8x/wC+350UUAHmP/fb86dJI4dgGbqe9FFADfMf++350eY/99vzoooAcJH2MdzdR3+tN8x/77fnRRQAeY/99vzo8x/77fnRRQA6SRw7AM3U96b5j/32/OiigA8x/wC+3504SPsY7m6jv9aKKAG+Y/8Afb86PMf++350UUAHmP8A32/OnSSOHYBm6nvRRQA3zH/vt+dHmP8A32/OiigBwkfYx3N1Hf603zH/AL7fnRRQAeY/99vzooooA//Z",
	"bingung": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4lkkcOwDN1Pem+Y/99vzok/1j/U17deXlv8B7Wx03TbGJfikqebqOqS4nTTEkAZYIVYeWXMZXc+GxvdVZg3yTisXKjKNKlHmnK9le227b6RWl2k3dpJNtIKdNSTlJ2S/qy8zmtG+AnxN161e5tfCl/HGjmMi9dLV8gA8JKysRyOQMdRng1pj9mr4q7T/xTLZyP+Yhbf8Ax2vPdY17VfEVyl1rGp3uo3KII1mvJ3mdUBJCgsScZJOPc1n1h7HNHr7amvL2cn+PtFf7kVzYf+V/ev8A5FnqH/DNPxW/6Flv/Bhbf/HaP+Gafit/0LLf+DC2/wDjteX0UfV80/5/0/8AwXL/AOWj58P/ACP/AMCX/wAieof8M0/Fb/oWW/8ABhbf/Hac/wCzV8VSzY8MtjPH/Ewtv/jteW0UewzT/n/T/wDBcv8A5aLnw/8AI/8AwJf/ACJ6h/wzT8Vv+hZb/wAGFt/8do/4Zp+K3/Qst/4MLb/47Xl9FH1fNP8An/T/APBcv/lo+fD/AMj/APAl/wDInqQ/Zq+Ku0/8Uy2cj/mIW3/x2m/8M0/Fb/oWW/8ABhbf/Ha8voo9hmn/AD/p/wDguX/y0XPh/wCR/wDgS/8AkT1D/hmn4rf9Cy3/AIMLb/47R/wzT8Vv+hZb/wAGFt/8dry+ij6vmn/P+n/4Ll/8tHz4f+R/+BL/AORPUn/Zq+KpZseGWxnj/iYW3/x2m/8ADNPxW/6Flv8AwYW3/wAdry+ij2Gaf8/6f/guX/y0XPh/5H/4Ev8A5E9Q/wCGafit/wBCy3/gwtv/AI7Th+zV8Vdp/wCKZbOR/wAxC2/+O15bRR7DNP8An/T/APBcv/loc+H/AJH/AOBL/wCRPUP+Gafit/0LLf8Agwtv/jtH/DNPxW/6Flv/AAYW3/x2vL6KPq+af8/6f/guX/y0fPh/5H/4Ev8A5E9Q/wCGafit/wBCy3/gwtv/AI7Tn/Zq+KpZseGWxnj/AImFt/8AHa8too9hmn/P+n/4Ll/8tFz4f+R/+BL/AORPUP8Ahmn4rf8AQst/4MLb/wCO0f8ADNPxW/6Flv8AwYW3/wAdry+ij6vmn/P+n/4Ll/8ALR8+H/kf/gS/+RPUh+zV8Vdp/wCKZbOR/wAxC2/+O03/AIZp+K3/AELLf+DC2/8AjteX0UewzT/n/T/8Fy/+Wi58P/I//Al/8ieof8M0/Fb/AKFlv/Bhbf8Ax2j/AIZp+K3/AELLf+DC2/8AjteX0UfV80/5/wBP/wAFy/8Alo+fD/yP/wACX/yJ6k/7NXxVLNjwy2M8f8TC2/8AjtN/4Zp+K3/Qst/4MLb/AOO15fRR7DNP+f8AT/8ABcv/AJaLnw/8j/8AAl/8ieof8M0/Fb/oWW/8GFt/8dpw/Zq+Ku0/8Uy2cj/mIW3/AMdry2ij2Gaf8/6f/guX/wAtDnw/8j/8CX/yJ6h/wzT8Vv8AoWW/8GFt/wDHaP8Ahmn4rf8AQst/4MLb/wCO15fRR9XzT/n/AE//AAXL/wCWj58P/I//AAJf/InqH/DNPxW/6Flv/Bhbf/Hac/7NXxVLNjwy2M8f8TC2/wDjteW0UewzT/n/AE//AAXL/wCWi58P/I//AAJf/InqH/DNPxW/6Flv/Bhbf/HaP+Gafit/0LLf+DC2/wDjteX0UfV80/5/0/8AwXL/AOWj58P/ACP/AMCX/wAiepD9mr4q7T/xTLZyP+Yhbf8Ax2m/8M0/Fb/oWW/8GFt/8dry+ij2Gaf8/wCn/wCC5f8Ay0XPh/5H/wCBL/5E9Q/4Zp+K3/Qst/4MLb/47R/wzT8Vv+hZb/wYW3/x2vL6KPq+af8AP+n/AOC5f/LR8+H/AJH/AOBL/wCRPUn/AGaviqWbHhlsZ4/4mFt/8dpv/DNPxW/6Flv/AAYW3/x2vL6KPYZp/wA/6f8A4Ll/8tFz4f8Akf8A4Ev/AJE9Q/4Zp+K3/Qst/wCDC2/+O04fs1fFXaf+KZbOR/zELb/47XltFHsM0/5/0/8AwXL/AOWhz4f+R/8AgS/+RPUP+Gafit/0LLf+DC2/+O0f8M0/Fb/oWW/8GFt/8dry+ij6vmn/AD/p/wDguX/y0fPh/wCR/wDgS/8AkT1D/hmn4rf9Cy3/AIMLb/47Tn/Zq+KpZseGWxnj/iYW3/x2vLaKPYZp/wA/6f8A4Ll/8tFz4f8Akf8A4Ev/AJE9Q/4Zp+K3/Qst/wCDC2/+O0f8M0/Fb/oWW/8ABhbf/Ha8voo+r5p/z/p/+C5f/LR8+H/kf/gS/wDkT0HWfgJ8TNBs1uLrwpfyI8gjAsnS6fOCeUiZmA46kY6DPIrzTzH/AL7fnW1o+var4duXutH1O9065dDG01nO8LshIJUlSDjIBx7CvVLO8t/jxa32m6lYxN8UmTzdO1SLECamkYLNBMqjyw4jDbXwudiKzKF+eZ4jGYNe0xfLOHWUU48vm4ty91dWpXS1s1ewoU6rtTun2et/mkte2nzPEfMf++350U2ivVOc9L+AmjQa98Z/ClrcvKkcd212DGQDvgRpkHIPBaMA+xPTrXIa9rE/iLXNT1i6SNLnUbmW6lWIEIryOWIUEk4yeMk16F+zUF/4Xl4Z5Oc3Xb/p2lry2vMo65pWv0p07fOVS/32X3G8v93j6v8AKP8AmfYn7MXjbwBoPgSS0uNR07R/EAmJ1CS/mSBrrLMYmRnb5lVPl2jG0hiQN2W9t/4Wh4G/6HPw5/4NIP8A4qvzOor5jMuAcPj8VUxUq8k5u9tHb/gduy0PQoZxOjTjTUFofpj/AMLQ8Df9Dn4c/wDBpB/8VR/wtDwN/wBDn4c/8GkH/wAVX5nUVxf8Q0wv/P8Al9yNf7dqfyI/TH/haHgb/oc/Dn/g0g/+Ko/4Wh4G/wChz8Of+DSD/wCKr8zqKP8AiGmF/wCf8vuQf27U/kR+mP8AwtDwN/0Ofhz/AMGkH/xVH/C0PA3/AEOfhz/waQf/ABVfmdRR/wAQ0wv/AD/l9yD+3an8iP0x/wCFoeBv+hz8Of8Ag0g/+Ko/4Wh4G/6HPw5/4NIP/iq/M6ij/iGmF/5/y+5B/btT+RH6Y/8AC0PA3/Q5+HP/AAaQf/FUf8LQ8Df9Dn4c/wDBpB/8VX5nUUf8Q0wv/P8Al9yD+3an8iP0x/4Wh4G/6HPw5/4NIP8A4qj/AIWh4G/6HPw5/wCDSD/4qvzOoo/4hphf+f8AL7kH9u1P5Efpj/wtDwN/0Ofhz/waQf8AxVH/AAtDwN/0Ofhz/wAGkH/xVfmdRR/xDTC/8/5fcg/t2p/Ij9Mf+FoeBv8Aoc/Dn/g0g/8AiqP+FoeBv+hz8Of+DSD/AOKr8zqKP+IaYX/n/L7kH9u1P5Efpj/wtDwN/wBDn4c/8GkH/wAVR/wtDwN/0Ofhz/waQf8AxVfmdRR/xDTC/wDP+X3IP7dqfyI/TH/haHgb/oc/Dn/g0g/+Ko/4Wh4G/wChz8Of+DSD/wCKr8zqKP8AiGmF/wCf8vuQf27U/kR+mP8AwtDwN/0Ofhz/AMGkH/xVH/C0PA3/AEOfhz/waQf/ABVfmdRR/wAQ0wv/AD/l9yD+3an8iP0x/wCFoeBv+hz8Of8Ag0g/+Ko/4Wh4G/6HPw5/4NIP/iq/M6ij/iGmF/5/y+5B/btT+RH6Y/8AC0PA3/Q5+HP/AAaQf/FUf8LQ8Df9Dn4c/wDBpB/8VX5nUUf8Q0wv/P8Al9yD+3an8iP0x/4Wh4G/6HPw5/4NIP8A4qj/AIWh4G/6HPw5/wCDSD/4qvzOoo/4hphf+f8AL7kH9u1P5Efpj/wtDwN/0Ofhz/waQf8AxVH/AAtDwN/0Ofhz/wAGkH/xVfmdRR/xDTC/8/5fcg/t2p/Ij9Mf+FoeBv8Aoc/Dn/g0g/8AiqP+FoeBv+hz8Of+DSD/AOKr8zqKP+IaYX/n/L7kH9u1P5Efpj/wtDwN/wBDn4c/8GkH/wAVR/wtDwN/0Ofhz/waQf8AxVfmdRR/xDTC/wDP+X3IP7dqfyI/TH/haHgb/oc/Dn/g0g/+Ko/4Wh4G/wChz8Of+DSD/wCKr8zqKP8AiGmF/wCf8vuQf27U/kR+mP8AwtDwN/0Ofhz/AMGkH/xVH/C0PA3/AEOfhz/waQf/ABVfmdRR/wAQ0wv/AD/l9yD+3an8iP0x/wCFoeBv+hz8Of8Ag0g/+Ko/4Wh4G/6HPw5/4NIP/iq/M6ij/iGmF/5/y+5B/btT+RH6Y/8AC0PA3/Q5+HP/AAaQf/FUf8LQ8Df9Dn4c/wDBpB/8VX5nUUf8Q0wv/P8Al9yD+3an8iP0x/4Wh4G/6HPw5/4NIP8A4qj/AIWh4G/6HPw5/wCDSD/4qvzOoo/4hphf+f8AL7kH9u1P5Efpj/wtDwN/0Ofhz/waQf8AxVH/AAtDwN/0Ofhz/wAGkH/xVfmdRR/xDTC/8/5fcg/t2p/Ij9Mf+FoeBv8Aoc/Dn/g0g/8AiqP+FoeBv+hz8Of+DSD/AOKr8zqKP+IaYX/n/L7kH9u1P5EfdXx0+IPw51T4a6xaXWr6TrNzKhWxt7G5jnljutp8uQbGygU8liQNuV53bW+JdB1ifw7rmmaxapG9zp1zFdRLKCUZ43DAMAQcZHOCKz6K+syPh+jlGGnhYzc1J3d/NW0X5nnYvGSxNRVGrNHe/H/RoNB+Mfi21tnleOS6F2TIQTvnjWZxwBwGkIHsB160Vp/tMhf+F3eKMk5/0Xt/06xUV0ZLKU8tw0pO7cIf+kojFJKvNLu/zD9mn/kufhn63X/pLNXl9eofs0/8lz8M/W6/9JZq8vow/wDyNK//AF7p/wDpVUU/93h6y/KIUUUV65zhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRXTaDoNl/Zw1vWxcNpbTPbQW9pIsc11KqqzgOVYRqiyISSpJLKqg5Zo4qVFTV3q3surfZf1ZLV2SHGNzmaK73+3tD/6ETw//wCBGof/ACVR/b2h/wDQieH/APwI1D/5KrH29X/nzL74f/JFcsf5l+P+RwVFd7/b2h/9CJ4f/wDAjUP/AJKo/t7Q/wDoRPD/AP4Eah/8lUe3q/8APmX3w/8Akg5Y/wAy/H/I4Kiu9/t7Q/8AoRPD/wD4Eah/8lUf29of/QieH/8AwI1D/wCSqPb1f+fMvvh/8kHLH+Zfj/kcFRXe/wBvaH/0Inh//wACNQ/+SqP7e0P/AKETw/8A+BGof/JVHt6v/PmX3w/+SDlj/Mvx/wAjgqK73+3tD/6ETw//AOBGof8AyVR/b2h/9CJ4f/8AAjUP/kqj29X/AJ8y++H/AMkHLH+Zfj/kcFRXe/29of8A0Inh/wD8CNQ/+SqP7e0P/oRPD/8A4Eah/wDJVHt6v/PmX3w/+SDlj/Mvx/yOCorvf7e0P/oRPD//AIEah/8AJVH9vaH/ANCJ4f8A/AjUP/kqj29X/nzL74f/ACQcsf5l+P8AkcFRXeppmkeMp4tP03SI9H164dYrRLWeR7S5cnCxMsrO6OxOBJv2ZCgqoLSDgq0pVeduLTi10duu2za/EUo21TugorZ0rSoHtf7Q1DzTZGRoY4oHCyTOAC3zEEKFDKSSDnIAHUrp/bNM/wChc03/AL+3P/x6qlUUXY4p4tRlaMXL0t+rX9eZydFdZ9s0z/oXNN/7+3P/AMeo+2aZ/wBC5pv/AH9uf/j1T7aJH1z/AKdy/wDJf/kjk6K6z7Zpn/Quab/39uf/AI9R9s0z/oXNN/7+3P8A8eo9tEPrn/TuX/kv/wAkcnRXWfbNM/6FzTf+/tz/APHqPtmmf9C5pv8A39uf/j1Htoh9c/6dy/8AJf8A5I5Oius+2aZ/0Lmm/wDf25/+PUfbNM/6FzTf+/tz/wDHqPbRD65/07l/5L/8kcnRXWfbNM/6FzTf+/tz/wDHqpajpdrdWs99p0bw/ZwHubZ33BVLBQ6MRnbuYLtOWGQctlirjVi3YqGLTaUotX72/RswKKKK0Ow9O/aa/wCS3+Kf+3X/ANJYqKP2mv8Akt/in/t1/wDSWKivGyL/AJFeF/69w/8ASUdOL/3ip6v8x37NP/Jc/DP1uv8A0lmry+vUv2anY/HLwyNxxm64z/07S15bVYf/AJGlf/r3T/8ASqop/wC7w9ZflEKKKK9c5wooooAKKltbWe+uYbW1hknuZ3WOKGJSzyOTgKoHJJJwAK9/tfgV4e+HGm2mu/FbXPJ87LW+h6bl5rhlVXMbOP8AgSNtwoLKfNGRXn4/NMPgeWNVtyl8MUryl6JfnsurNqOHnVu47LdvZHiPh3wxrHi7U49N0PTbm/vXwfLgTdtUsF3MeiqCwyzEAZ5Ir2LTP2WPEcVlFqfivW9F8NaWM/aZLmcSSW/JVM4xGdzbf+WnRvX5aXVv2ibzSbZNH+HGjWXhbRIXBVkhSW4uCAVDSFgVyyiPOQzZX75FeTarqmseI7lLrWNSvL+4RBGs17O0zhMk7QWJOMknHua8+2c413jy4eHpzz+f2F/5N59nt/stLe839y/zf4Hso+HPwM0X/Qda+I+pXmpQ/wCtn02LNu+eRt2xSjhSAcO3IPToF/4Sj9nf/oQ/EX/f9/8A5Krw8Wa45Yk+1PFtHj7v61f+r0p61sXVk/KfKvOygl9zvboL66l8FOK+V/zue2/8JR+zv/0IfiL/AL/v/wDJVIfB3wC17mx8Za1pF7f/AOot7qMmGzkf7qOTFgqhIBJlxgH5/wCKvE/s0X939TTDaLjhmB96P9XXHWliq0X/AI+b8JKS/IPrqfxU4v5W/Kx7Rd/stalqVtNe+DPFug+JLGFGDPFL5btMBkxLtLpnBTBZ1+9zgcnyLxb4G8ReBb1bPxDpFzYSvny2kAaOXAUnZIpKvjcudpOCcHBqLT7nUdFvYr7TL24tLyLPl3FtK0UiZBBwwIIyCR16GvU/Dv7RviWztjpfiuzs/FmhMiRvZ6lEm8hAdvz7TuO7YxMiuTt6gkmodPOsG7qUcRHs1yT+TXuP5qPqh82Fqq1nB/ev8/zPEKK+io/hD4D+L0c9z8MdZk0nVoUEkuhauGIRNypuVxuYDhmJBl5dAdmcV4Lruhaj4Z1e70nVrSS01G0fy5oJByp69RwQQQQRkEEEEg13YDNsPjZSpRvGpHeElaS+XVeabXmZVsNOklJ6p7Naoz6KKK9IwCiiigArvde/5FnwJ/2CJf8A04XdcFXe60RL4V8ESxnfFHp01u7ryFlW9uHMZPZgksbEdcSKejDPNX/i0f8AE/8A0iRcfhl6fqjO0HS/7b1zTNM83yft1zFb+bt3bN7hc4yM4znGRXpV18F7efxFrnhnRfEL3viLSYzKbW5sfIW5AAJEbiR8nDDhgv8AWvOfDOpRaN4j0fUp1doLK8huJFjALFUcMQMkDOB6163L8W/DWk+OPEHjbRrfVrrW9QjZLWC8gjhhtSyhSxKyOXI29ML1P1rzM2qZjGtbB3tyO2iac+ZWUm1orXvqtPOxtho0HH973/Cz2OLtfh7bWnhHT/E3iLWH02x1OZorKK3tPtE0oU4ZypdAqgj1J9uldDp/wLuZ/GL6FdazHFZPpZ1e21C3tzKtxDkYwhZcHk8E8Y981l/8JxoniLwLovhnxImo28uiTSNa3thEkxkjc5ZHR3TBzjDAnoOPXrdM+OOkR+Nk1C50++t9Bs9DbRbKGEJLMFyuHfLKM8HOD2H1rhxVbOkqnsk+b3+kbJX/AHfLpq2t7363S0NqccK2ubbTv87nB33w8jn8ISeKfD2qPqem21wttdRTW32e4t3bAUlAzgqSwGQx5P1xuSfB21sfEWn+FdS8SpbeKb6NWW2W0L28TuMpG828EMeOiEc9apSePdK8P+A7zwr4aS/mfUbqO5vNQvo0iY+WVZESNWcAZUHJY9/XjevPih4V1rxxpnjrUbHVk1u0WN5dPt1jNvPPGMIwlLbkXheNjdOtXUrZt73Lzcvv8rtHmekeTmTVkm+botFG9tRRjhtL2vpfV263t+H42MLTfhDeto+uapq813bw6RqB02aHT7L7ZN5qgFm270AQZHzZ71H4b+HGl+IoPFt8niG4XSvD0EdwZk07dLOrA5HltIu0gqR94g+tXtB+KT2usatrsmv69o+qalfPcyxadbxXFs6HBClJHX5h8wyc8Y989ND8cNGm17x9qBg1XSD4it4ILWfTo0eaBo1YGRv3ifMcg8H8e5zr186j7RRV3aLVkrR96CkrOLvpzNNOWl7xTsOEMK7X89+ujt106aWXqcne/BjUD4k8L6RpN9HeL4jtFvbaWaIwNFGV3EyJltuBzwTnoKhX4Y2WrWviE+HPEB1O+0CNprm3ls/IEsSkhnhbe24DHcKTXR3fxvtrPxT4O1nT7S7v7jQrV7W7vdQ2pcagrDB3bS2MDJBLNyec98rTvH3hnwfD4quPDUGqzajr1vJaRi+jjjjsonOWwVdjI3TBIXp0pwrZ04R5k+aytpGzfO0+bTRcnK1bl3fXQHHC3dtvntZWt31v3+7UrWfw68N3vgnUPFqeJdWGnWNytpJE2jx+aXYLggfacY+YdSPpXnsdmb3Uks9PEtwZ5hFbhkCvJlsLlQSATkcZP1NdnpnjbT7L4Ta34SkhujqV/qEd3HIqr5QRQmQTuzn5T2NUfhl4h0fwn4xsdb1q3ubm3sA0sUNuqsWmx8mdzDABOc8nIHFepQnjaNPE1Kt5uLfIrRV0oq2yW7urs55qlKUIxsrpXevf/I3/AIp/B6X4a2en3cerx6rb3Er207xw+WLeZQDsPzHOQT6fdPFYXxL8Cf8ACu/EMekf2h9u32sdz5vk+Vjfn5cbm6Y65rqLr4uWPiPwf4q0TXNGjt59TuBqNrNpwkcC8zlmfzpm2qwAHydATxWH8XvG+n+P/FUWq6bDdRW6WcVuVuVVX3LnJwrEY59a5MsqZt7WnSxibS5+Z2jaXwuL02teS07amuIjhuWUqXW1lrpvf9GcFV/4of8AJTPGf/YZvP8A0e9Vba2nvbmG2toZJ7mdxHHFEpZ3YnAUAckknAAqX4jXUF98QvFt1azRz20+rXckU0TBkkQzMQykcEEHIIr2av8AvUP8Mvzicsf4b9V+pNef8gbw5/15P/6Uz1ShhkuZo4YUaSWRgiIoyWJOABVy5IfQ/D7qdyJayRMw5AcXErFT77XQ49GB7in+H9U/sPXdN1Ix+YLO4SYp/eCsDis5/EzxU2ozcVd3l+bO+uPgN4og0k3gazkuFXebNJCZPoDjaT7Z/GvOdO0+41TULawtk3XNzIsUanjLE4H0r6ouPjJ4Rh0o3yakJX2ZW1VGEpb+7jHH16e9fMVjr0+n+I4dbiRPPiuftIT+HO7dt+naoR5GVYvHV41PrELNbXVtddDq0+GsF1rd34fs9cWfX7ZGYwG2KwyOoyyLJuySOeqgcVCnw0uZvAX/AAlEF3vlQuZLExYZURyrMGzzjgkYGAfatO38eeH9N8V3viyztdQbVJ1do7OVUEMUrjDMZA2WHJ42jr1qHTviXHpmh+HLaOGeS70+6nlvFdV8qeKUtuQc85Ddx1o1Kc8faPJ/dvdLs+Zel7K/nuxV+FG7xM2i/wBr/d0z+0fO+zfT5Nu/365/Cuc8E+Ev+Ex1O6svtn2XyLWS53+Xv3bcfLjI65613T/FHQj46n1lLXUE059KOnqnloZFbPXG/GMe+a53wb4k0DwbrFxeRz6neRXFlNbsGs44mVmK7SP3rZHBz0xx17A4Vcb7KXMnzcqtot9b9Ldt/kRRfDe4uvAC+Kra9Erguz2XlYZY0cqzht3OOCeOhrRi+FCv4pOiNrBVRpo1Ezi1yccfJt3+/XP4VFpPxHg0bw94ZsbeCd7jTLmZ7pHVfKnhkJ3IOcnIPcda3f8Ahamhr48l1yK31GKwOl/YUVY081GyMHG/GAB65o1IqVMwTmorT3raLv7q+7Vd767HlmpRaZEY/wCzru7uAc7zc2qw7fTG2R89/SpdC/4+rr/rwvP/AEmkqz4k1NdTe3ca3q2qsgILalHtMY4wF/evnPOenTvVbRCEmvZWO2NLC73OeAu6B0XJ7ZZlUepYDqaqO6PTk28O772f9bL8jkKKKK7T3D079pr/AJLf4p/7df8A0liop37TLsPjd4oAYgf6L3/6dYqK8bIv+RXhf+vcP/SUdOL/AN4qer/MP2af+S5+Gfrdf+ks1eX16h+zT/yXPwz9br/0lmry+qw//I0r/wDXun/6VVFP/d4esvyiFFFFeuc4V0PgrwVrHj/xBbaJolt513N8zO3EcEYxukdv4VGR7kkAAkgHO0LQtR8TavaaTpNpJd6jdv5cMEY5Y9ep4AABJJwAASSAK+h/GviGD4A+FYPAXhURx+K9Qto59c1mGUO8bsD+7jbAZT125C7EYMAWcuPHzPMKlGUcJhEpVp7J7RXWcutl+L0R04ejGSdSppFfj5Lz/INS8T+Ev2ebbV9B8FtJq3jqVFt7vW7hEaK0OPnRB6hlB2cgMRvZjHsrwjVtU1LxRq13q+r3ct1f3b+ZLPJ1c+w6AAYAA4AAAGBVKC3BAdunYVZeRYxlj+HrW+W5RSwV6snz1ZfFN/E9vuWmkVoiK+JlVtFK0Vslt/w/mCRrGMKP/r0PIkf3mAqlJdO/A+Ue3WoK9J1UtjNUu5eN5GDj5j7gUz7b/wBM/wBaqUVDqyK9nEt/bf8Apn+tPF4hxkMKo0Ue0kHs4mmkqP8AdYE+lOZQ4wwBFZVSx3Dx8ZyvoatVe5Lpdi1F9o0+5hu7OaWK4gdZI5YmKvGwOQykcggjOR0r3bRfin4c+LmkWnhX4r+Yl8tzmy8RWqxwmHd1EhxtQHAUkKVIKlgpTfXhkUyyjIPPcVHPbhsuvB7j1rgzHKqGPjGUvdnHWMlpKL8n+aej6ouhiJ0W1ununszoPif8MNY+FviBtN1JfOtJsvZ3yLiO6jHcf3WGRuXOQSOoKseJr6I+EXjmw8d6ZD8K/HSfa9Ku/k0q/aRVmspQp2IHb/vlOpydmGRsL4x418Fax4A8QXOia3beTdw/MrrzHPGc7ZEb+JTg+4IIIBBA48tx9b2ssBjre2ir3W047cyXTtJdHto0a16MeVVqXwv8H2/yOeooor2jlCt/QfEcWn276fqdpJf6NI5l+zxzCGWGXAHmRSFWCEgBWBVgygZG5UZMCioqU41Fyy/r59BqTTujuc+Bv+g94j/8EcH/AMmUZ8Df9B7xH/4I4P8A5MrhqKx9hV/5/S+6H/yJXNH+Vfj/AJnc58Df9B7xH/4I4P8A5Moz4G/6D3iP/wAEcH/yZXDUUewq/wDP6X3Q/wDkQ5o/yr8f8zuc+Bv+g94j/wDBHB/8mUZ8Df8AQe8R/wDgjg/+TK4aij2FX/n9L7of/IhzR/lX4/5nc58Df9B7xH/4I4P/AJMoz4G/6D3iP/wRwf8AyZXDUUewq/8AP6X3Q/8AkQ5o/wAq/H/M7nPgb/oPeI//AARwf/JlGfA3/Qe8R/8Agjg/+TK4aij2FX/n9L7of/IhzR/lX4/5nc58Df8AQe8R/wDgjg/+TKM+Bv8AoPeI/wDwRwf/ACZXDUUewq/8/pfdD/5EOaP8q/H/ADO5z4G/6D3iP/wRwf8AyZRnwN/0HvEf/gjg/wDkyuGoo9hV/wCf0vuh/wDIhzR/lX4/5nazeI9F0Fd/hv8AtG41TrHqd9GkBtc9THCrPiQY4lMny7jtRWVZBxVFFaU6Sp3d22929/68lZfeTKVzU0vV1s42truFrmwZt/lLJsdHx95GIO0nAB4IIAyMhSup5/h3/oIar/4L4/8A4/XL0VUqcZas5amFjKXMm16W/VM6jz/Dv/QQ1X/wXx//AB+jz/Dv/QQ1X/wXx/8Ax+uXopeyiR9T/vv8P8jqPP8ADv8A0ENV/wDBfH/8fo8/w7/0ENV/8F8f/wAfrl6KPZRD6n/ff4f5HUef4d/6CGq/+C+P/wCP0ef4d/6CGq/+C+P/AOP1y9FHsoh9T/vv8P8AI6jz/Dv/AEENV/8ABfH/APH6PP8ADv8A0ENV/wDBfH/8frl6KPZRD6n/AH3+H+R1Hn+Hf+ghqv8A4L4//j9UNS1iFoHs9NjlitXx50krAyXGDxnHCrkBtgJ56s2FxjUU1TincqGFjFqUm3bvb9EvxCiiirOo9O/aa/5Lf4p/7df/AElioo/aa/5Lf4p/7df/AEliorxsi/5FeF/69w/9JR04v/eKnq/zJP2agv8AwvLwzyc5uu3/AE7S15bXqH7NP/Jc/DP1uv8A0lmry+qw/wDyNK//AF7p/wDpVUU/93h6y/KIUUV2Pwt8CT/EbxvpegxiQW0r+ZeTR5/c268u2drBSR8qkjG5lB616OIxFPDUpV6rtGKbfojGEHOShHdnr3w5tdL+C/wy/wCFiapaW83jLV90ehWl2WBWI4UyBNoIyCzlgcFCihl8w58HMk+oXU15eSyTzzO0kksrFnkcnJZieSSSSSepr0T45+NoPGnjhrPSjGnh3REGn6dFb4EIROGdFVimGIwCuMosfHFcCqhFCjoK8zIsJPkljsSv3tbV3+zH7MF2snr/AHmzfGVFdUYfDH8X1fz/ACEkcRoWP/66zXdpGLMeanvHy4QHgdfrVavXqSu7GVONlcKKKKzNAooooAKKKKACiiigBVYqQQcEVowyiVM8bu4rNqa1fZKBnhuK0pys7Gc43RNcw/xqPrX0Eosv2gPhTcebFG/xK8KWwELJI7XGoWqAElhtZpC2WGASRLg5QSEHwcjIwelb/wANfGs/w28c6ZrcZka1jfy7qJM5mt24dcblDED5lBONyqT0rzM8wE8RRVfD6VafvQ831i/KS0ZphKyhLkn8MtH/AJ/I4KivUvj14Eg8GeN5LrSxG/hzXU/tDTpbfBh2PyyIVUJhWOQFzhGj55ry2uvBYunjcPDE0tpK/wDwPVbPzM6tN0puEt0FFFe4fAL9nqL426b4nv5/FH9hQaAImkP2A3XmK6yEniRCMCP3zmupu2rMzw+ivoi6/Zj07XPh/rnjL4e/EKz8V2WiK73cD6bLYyqETe21XYknbyMgA44OeK4HSvhr4f1D4R6r4zn8e6Xa69ZTeVF4akEf2m5Xci71zKGxh2PCH7h/BcyCx5rRRRTAKKKKACiiigAooooAKKKKACive9B/Zvs1+Gel+PfG/juy8K6RrEgjsVNhLePIW3FdwQjbkIx4zx1x0rxzxVotv4d1+90201ey1i1gZfLv7IkwzqVDAjIBB5wQehBHakmmBj0UV9P+IP2N73Svg2PiDYeKP7QmGlw6q2l/2d5ZEboruBJ5pzsVmP3edvbNDaW4HzBRX0D+z7+y3e/HTRdW1mTX/wCw9PsrhbaGQ2X2j7RJt3OMeYmAoKc853dsVh+FfgpoGr/Ezxh4O8QfEPTPDVv4ennt49S1CKNEvGjm8vAV5kCkgFsbmx+tHMgseNUV7P8ACv4CL8TfBvj3xGviIWK+E4XmEIs/OF2Fjkf73mLsz5eM4brXjFNNMAor0r4lfDXw/wCB/D/hbUtH8e6X4kutZhMt1ZWYj36c2xG2Ptlc5y7DkL9w/h5rQncAooooAKKKKACiiigAooooA9Q/aZC/8Lu8UZJz/ovb/p1iopv7TX/Jb/FP/br/AOksVFeNkX/Irwv/AF7h/wCko6cX/vFT1f5jv2af+S5+Gfrdf+ks1eX16h+zT/yXPwz9br/0lmry+qw//I0r/wDXun/6VVFP/d4esvyiFfR/wKlj8DfCD4h+P0f/AImQxpto6W6PJbvtXawZjgqZJ4yy4xiIH5uAPnCvof4pD/hGf2f/AIW+G/8Aj4/tDfq32j7nl5UyeXt5z/x943ZH3OnzccvEMfrCoYD/AJ+zSa7xjecv/SbfPrsa4J8jnW/lX4vRfmeF2iZLOR04FW6jgXbEvTnmpK+nWx57IJII3kyzEM3ak+xx+rfnUd63zIvcDNdV8LdU8O2Hj7w9ceMVlfw5BdpJdeXEsvA5XehB3x7gu8AElNwAJxWMpRTd0axjJpWZ9C/BH9kHS/HHguDxJ4t1HVrP+0v3lla2W2J1hBIDyGSNs7+GXaMbcHJ3YX0r/hhj4d/9BnxT/wCBVv8A/GK+jtH1az1/SLDVtOm87T9QgjubeXaV3xuoZWwwBGQQcEA1drxJ4io5N3setGhBJK1z5k/4YY+Hf/QZ8U/+BVv/APGKP+GGPh3/ANBnxT/4FW//AMYr6boqfb1O5XsYdj5k/wCGGPh3/wBBnxT/AOBVv/8AGKP+GGPh3/0GfFP/AIFW/wD8Yr6boo9vU7h7GHY8a+Hv7Lnw68A/2jnTf7f+2+X/AMjBBb3fkbN3+r/dDbu3c+u1fSuwu/hV8NbK0nuZfAHhpo4I2kYQ6FDK5AGTtRYyzHjgKCT0AJrtlwGGelSbk9vyrppVpOOsl8zlrUoqWifyPzK/aP1TwB4k8cafd/D2Gxh0VNNjilWwsDZxmcSyliUKLk7SnzY6YGeK8fW2jWRcM24c4r6h/ad+I3wj8YeEbc+BDpcniaXVlubu4t9Ie2nkiMcu9mlaJd2XZCQSSTz2zXyxaN++5ySwNenFx0VjhalZu5eqvdplA2OR/KrFNdd6MvHI71uzJHumuyx+P/2WLHUrh/8AiZeDrxLQzSW6bnj3LGsaMDkL5c0JJxkmHkHhq+b6+iP2Yx/bo8f+DP8AU/2/ozf6Z97yNu6L7nG7/j5z1H3Md8j53r5jJY/V8Ti8Etoz515Kor2+UlL/ACSsehinzwp1e6s/VaflYK+2/wBhCSKHwj8VZJ4fPgSK2aSLcV8xRHcZXI5GRxmviSvVvg/8fvEfwVtNctdD03Rb6DWvL+0rqkEkowgcAAJIowQ5znPavfmrqyOJbn1N8E9Y8O/FX4MfEzwt8PPDj+ArlIczMLxr9Z/OjcYMsgDAFYmU/wB0Nkc1xPgf/kwvxz/2ET/6Ptq8s1P9qrxdN4Y1Dw7oOieFPCenagrJc/8ACO6Z9laQMMNyXYAkcZAB9CK5bSvjd4g0f4R6r8MoLPS20HU5vPlnkikNyrbkbCsHCgZjXqp6mp5WO59P6v4xuvAv7Fvw91jT7azl1SO7RLSa6t0nW1kL3B81UcFSwUMBkHG7PUCpPjfoOm/E/wAJ/s++Idct7eLVfEt7YWeo3cCCMyR3CIZMkdgckf3cnHU18ua78bvEHiD4UaL8Nrmz0tNC0iZZ4J4opBcsw8zhmLlSP3rdFHQVJ4w+OviTxp4E8KeDry20220/wx5X2O4tEkS4Jjj2KXYuRnHPAHNCgwufWnxV+IOoeD/2gfh38MtJ0PS4/BYl08jTvsMZDM8+BKjY3IY9oIKkcoc5rE+LJA/bm8B5OPlsv5yVreH/AIg3GrX3hrV/EfxX+FlxpmktHI2rCDy9ekiUhmh2P/q9+CrFADgmvm/4/fGSHxp8b28ZeEriaGHSzAmn3ZTaztCdwk2noCxOAR0xkdRUxWo2e9TwSyf8FEYyqMVRQ5IHAX+ysZ/Piuu+C3/J33xk/wCvcf8AocVfOMv7ZPjyTxHp/iBdI8KxaraoYpriPTSsl6m0qEmk37ygJ3BVZRuA4OMVgeGP2mvFvhP4j+JfHllp2hyav4hTZcwzwymBBlT8iiUMPuDqx703FtfIVz6O/Z/8Xv8AGTwv8WfCmv6XpY8NadADp1jb2cca2iuJxgEDLMNikOxLbgTmuf8Ah9dL8H/2O5vH/ha0tf8AhLdWuWjn1CWBZWgX7UYQMMCNoVRhTxufODXzx8Lfjr4i+Ef/AAkv9iWWlXH/AAkMax3P26KR9gXfjZtdcf6w9c9BXpP7OvjXWNP8G61oNt428B2ljc3B8zQfG8bi1dSq5lRxwckYKHj5c45puNgTPTvH+uTeJv2F7HWLmxtrK6vbxZJo7WEQxu/21w0gQcLvI3kAAZY4GK+LPDukHX/EGk6SJlgOoXcVr5rdE3uF3H2Gc19aftC/F3w/F8EdL+HNl4k03xL4hkuFmvbrSIgljbRq7OI49o2hVyiKq/wpk4PX45VmRgykqynIIOCDTgtAZ+k/iO5+HWh32l/s36/p91BoV5pUbafqt1Pub7U0j7cMR8rbgSrfd3HZtxgV8/8Axg+Avhj4HfBVxrqW194/1LVni0+9huJVItVYHd5W7Z9xecg4MoGeBXJ2/wC1z43ax02HWNI8K+IL7TAPsmp6xpfn3cJHRlcMAG4HzYycZJJrG+Iv7Sfin4reFIdB8V6V4fv5LeQywamLV47uBicnayyBAMfKRsIIAzkgGkoyTC6PHK/TO++IEXgPw7+z+l+ynQ9e0+LSb9JPuFJbWEKzA8YD7cn+7u9a/MyvTPiH8cfEPxK8I+FvDGrWelw2HhqJYbWS0ikWVwsaxjeWdgThR0A5qpR5rCTPvDwpc6V8OPit4H+DfhqRv7O0vTrzVL4scs8smfLDH1AZzg9mT0rzv9mn/k6n41/9fF9/6XV8efCv4n6v8IfFsfiXRLaxuL+OGSAR3yO8e1xg8IynPHrXUeB/2i/FPgD4geKPGum2GjS6r4keV7qK5hlaFDJL5rbAsgYfNwMsePzqHB6jufQ37HNhaar4A+M9hf3i2Vjd5gnumxiCNoZgznPHygk8+lYP7U+q6v8ACHw1o/wy8H6Q+i+Abq3Ej6nE+59Xcgbw8g/DcOrcdFwK8I8BfHTxF8O/Dfi/QdLstKms/FUbRXj3UUjSRhkdD5ZV1AOJD1Dc4q3b/tC+Jm+F7fDvVrDR9c0FRi3k1OGV7i0AHyeVIki42c7cg4Bxyvy0+V81wvoe/wD7U3/Ik/s+f9cE/wDRVrW3+2R8YPEXw08d6La+FjZ2GoXmk7rnUWs4pp3iMsgWIGRWCqCGPABJbrwK+XfH3x48R/EXS/B2napZaTDB4TUJZtaxSK0gCxr+83SMDxEvQL1P4UfjB8ZNd+Nmv2Wta/aabbXVnai0RNPjdEKB2fJDuxzlz39OKFDa4XPPKKKK0EFFFFABRRRQAUUUUAenftNf8lv8U/8Abr/6SxUUftNf8lv8U/8Abr/6SxUV42Rf8ivC/wDXuH/pKOnF/wC8VPV/mSfs1Ox+OXhkbjjN1xn/AKdpa8tr1D9mn/kufhn63X/pLNXl9Vh/+RpX/wCvdP8A9Kqin/u8PWX5RCvoj9qwf2V4k8K+G7T93ouk6PH9kt+vlZdoz8x+Y/LDGOSfu+pOfnevon9r3/kpWlf9geL/ANHz1z4/XOMEn2qv52ir/c2vmzSj/u1X1j+p4mo2qAOgGKqXrfMq+gzVyqF22ZiPQYr6Kr8Jx0/iIKKKK5joP1x+Fdncad8MPBVneW8tvd2+i2UU0EyFHjdYEDKynkEEEEHpXzD4Nsrn9r34l6/Hrvie607wfpQ8+00W3lWOeSPLpE6xncm5d2ZJDuILqgwGXb9l18D/ABJ+AXjv4ZeNLjWfA1pqk2lPOzafdaG0hubRZA/7khWMo2rlS/KsCMkFio8/CSjzO+j6HbiIy5UkbXwv8Xa38EfjefhtceIRrvhpr4aXtt2MkUckjfu2jUtiFxJJiVQSAfMB3sqmvt6viP8AZ1/Z18RSeLtL8VeKtLl0zSdMcXVvbXYMc9xOpIT5AQ0YR1D5cDdhQAysSPtypxbg5+78ysOpKPvBXyj8b/F2t/EL4x6V8INJ8Qjw7pcxSC/upWMYuJJYi5QkNmRTG6osZ2h5H2nPykfV1fJv7UHwA1vxPrp8aeFLL7dNLAF1GyjY+czRodsyBm+fKKqbEAbKrgMWbE4VxVT3h11Jw904j4q+GNR/ZN+IGk3HgnxVLPY6lGLltNupg0hEfylbmNNqvGxZ9j4Uj5wMMm8/a/h7W7fxLoGla1aJKlrqdrFdxJMAHVJEDqGAJAOCM4J+tfn34a+BnxO+Knikza7ZazaeY8YvtY15ZBIqbSAQJSHmIVNoC5x8oJUHNfoVpOl2mh6VY6XYReTY2MCW0EW4tsjRQqrkkk4AAySTWuMcXazuzPDKSTvsfjneWdxp13cWd5by293byNFNBMhR43U4ZWU8ggggg9KhrtPjB/yVrx7/ANh6/wD/AEoeuLruTurnG1Z2J7RsTAeoxV+s2BtsyH3xWlXTSehhVWp6b+zNqNzp/wAY9JtreXZDfRXNvOu0HfGImkA5HHzxocjB4x0JFea+PNMtdF8c+JtNsYvKsrLU7m3gj3FtkaSsqjJJJwAOSc16B+zn/wAls8OfW6/9Jpa4n4of8lM8Z/8AYZvP/R7189T93PqiXWlBvzfPNXfy0OuWuDjf+Z/kjlKKK24PC17ceFrjxFG8Bs7e4+zyR7j5o4X58Yxty6DOc5YcV9AcRiUV0eq+CNX0ufSbbyftd3qdsLqK3tFaSRQSQVZcfeBU5AzismPR9Rm1A6dHYXT6gCVNqsLGXI6jZjOfwoApUVoQaDqt1eT2cGmXst5ACZYEgdpIwOu5QMj8avXvhiW38Vx+H4Z0knkmigSWRSi7n24yBkgAt70AYNFdOnhK3fW9N0qPxBp9zNeXkdm4tYpy0O5gpYiSNAQCegP+NY6aLqE8ka21ldTiaVoYjHCzea69VXA5IBBwPWgLlCitSLwzrc91NaxaPqEl1AwSSFLZy6MQSAVxkEgE8+hqOz0HVdQmlhtNMvbiaFxHIkMDOyNz8pAHB+VuP9k+lAGfRV1tH1FdOXUWsLoaezbRdGFvKJ9N+MZ/GrP/AAjWqRTww3djdWZnieaM3FtIPMVELEgBSSMDqBgdSQMkAGTRRWtoGgvr0t4ovLWzis7c3Ms1zv2qgZV6IrMTlh2oAyaK6O58GXlu1wUurOe3jsP7SSeJm2TQ+YI8rlQc7sjDAfdNWJPh9qsdz4ehMlqRrsayW8gdiiFgG2P8uQwDKSADww60WC5ylFb9n4Vkn02DULzUtP023uSwt/tbPun2nBKqiMQAcjJwMg88Gql5oNxZaYuoPLbvA13LZjyn3ZeNUYkEcFSJBgg+tAGXRXV/8K91UprjJJau2jRRTTIrtukWRC/yDbyVUEnOOFOM1VtvB2oXUtoqyWyx3Fl/aDTPIVjgh3FSzkjjlcYGc5AGScUWC5z1FaWq6VHpvlNDqdjfxSZG+0Z/lIx1V1Vh164wfXis2gAooopDCiiigAooooAKKKKACiiigD1D9pl2Hxu8UAMQP9F7/wDTrFRTf2mv+S3+Kf8At1/9JYqK8bIv+RXhf+vcP/SUdOL/AN4qer/Md+zT/wAlz8M/W6/9JZq8vr1L9moL/wALy8M8nObrt/07S15bVYf/AJGlf/r3T/8ASqop/wC7w9ZflEK+iP2lD/bel/DbxfcfLqWuaMPtEUfEKbVjlGwHJHzXDjkngL7k/O9fQ2on/hNP2WNKvR+8vfCOpG2nuLvmTymbAjibk7QJ7cYO0Yi/2VzzZx+5xmCxXRTcH/2/Fpf+TKP4GmG96lVp+V/uf+VzxVCSik9SBWfO26ZyfXFW7VsxY7qaos25ix6k5r6Gq9EctNasSiiun+G+rWegfETwjq2ozeTp+n6taXNxLtLbI0mRmbCgk4AJwATXO3ZGy3P13oqGzvLfUbS3vLO4iuLS4jWWGeFw6SIwyrKw4IIIII61NXhnrBXN+KvHWjeD1QahO7XMi70toV3SMucZ7ADr1Izg4yRXSV85fGmwvbfxk9zcM72t1ChtiSxVVUAMgzwCGyxA/vg96Tdj0MswsMVX9nUdla/r5Hr/AIW+JGheLLj7LaSywXp3Fbe5QKzgAElSCQep4zngnGBmuur5Y+G1he3/AI10gWTOjQzCaV1LALEvL5I6Aj5eeCWAPWvqehO5ea4OnhaqjTejV/QKKKKZ5h+Svxg/5K149/7D1/8A+lD1xdeqftI+ItL8V/GvxXqui3sV9psskEcdzCcpIY4I42Kn+IbkYBhwcZBIINeV17cPhR5U/iYqttYMOoOa1aya0JJP9H3HGWX+ddFJ7mFVbHsX7KmkQ6p8VhdzPIJdMsJ7uIIQAzkrEQ3HTbMx4xyB9D4rr2sT+Itc1PWLpI0udRuZbqVYgQivI5YhQSTjJ4yTXu/wbP8AwiPwf+JvjRvkleEaXZ3FtxdW8rDG4NxtXfPA2Q2f3ZOMqufnivn8v/fZpi8Ruo8lNfJOUl98l8zqre5h6cO939+i/IK7bw94sstD8PWttPAL7N7cNc2LEoJYXijUfPggfMmR15UcVxNFfQnFY9KbxfY6vpy295qX2a/vtNmgnuzG5WGVr55yrbQTtZCASoONwHqKhl8RaXc3WoWP9pNGs+kQacuqvE+HeNkYlgAX2MEKdM4C5HUV53RRcVj0rUPEOk6rp9xpKa0bWSJbL/iZSRS4u/IR1YEKC4wXG3I6IM7eMZmp+INPufilDraXbyaauoQTtcOjBiilNzFcZzweK4iii47Ho1xrdpH4q0TUptb0G5s7fVIrhxp2mNbyxxiQMWci3jLAAdMsc9qiuPEtjfaxZanb6hFYqYJLOSxngkaCBChU7dgyI3DEnHzhiTz94+fUUXCx6kp0i58O+JYbLWfsdo8mnRtORO0HmBZyUXIMnl8ZGQTkDtzWTr/iqzvrPxRHa3cu6/nsFUsrK1ykMUivI3puba2Cc5b2NcQtzMkElussiwSsrvGGIVmXO0kdCRuOPTJ9aiouKx6fe+MdKm0zz7U6dDcSadFYPE0V29yu1FU4HmCDbuXcDwf9nOSWyeINEXUE1CbUoZb+4F6072kc6xMZLZ1Uukg4kLsB8nygGvMqKLhY1dDu/sh1H/iYfYvNs5Yv9T5nn5x+6/2d397titjwDqttpV1rH2m8tLNrrT3ghlvLczw7zJGQGQI+RhT1UiuSooHY9J1TxPpUwvFa/huLx9Caxee2t3igll89WVY49o2AIOflUZB4yeb/AIf8baJFrWmQ6jdMumQWdnIs4idvIuoYgpGAMkMNyHAxnaegryeii4rHbwanp2qWGgyvqlnp2paPbtamO/s2uIZk8x3VgoRwT+8IIYAcAg+lrV9U8P8AiOC/sYL2HSLaPVZr22822cRtFIiKVCxK20jywQMAc9RivPqKLjsejT+OrWC61+/0+Vlne8sXtEljP76OFHRtwHABGMqT0YjmrWreJPDU9xJptndSx6PfaOlp5xiYtZyC4M6owxlguApK5z1GeleX0UXFY6zxFeaaPD2m6dBc6ffX9vM7Nd2Vl5AMO1AiMxjRnbIY5YHr1NcnRRQMKKKKQwooooAKKKKACiiigAooooA9O/aa/wCS3+Kf+3X/ANJYqKd+0yF/4Xd4oyTn/Re3/TrFRXjZF/yK8L/17h/6Sjpxf+8VPV/mH7NP/Jc/DP1uv/SWavL69Q/Zp/5Ln4Z+t1/6SzV5fVYf/kaV/wDr3T/9Kqin/u8PWX5RCvoP9l/X7W+ufE3w91Oe5Sy8UWciQGOQ/JII3EgRdpUM0ZJ3HA/cqDnIFfPlW9L1O60XU7LUrGXyr2ymS4gk2htkiMGU4IIOCBwRits2y9Zhg54a9m9n2ktYv5NL5E4at7Gqqn9W6l6+sbvQtTv9NvY/JvbOWS3mj3BtkiEqRkZBwQRwcVnV718d9FTxlo+hfFfQ7ST+ztatkj1NUDMLW4TEY3M2DjI8rIVVzEDnMgz4LU5dmCx+GjVatJaSX8slpJfJ/hZ9TWrR9jNx6dH3XRhRUtvD5zkFtqKpZmxnAHtT/Ls/+f3/AMhGu0zbSPqD9mT9puz8Aaeng7xi/leHIvMksdQihLtaMxLtHIqAs6MxYhgCys2DlSCn3hZ3lvqNpb3lncRXFpcRrLDPC4dJEYZVlYcEEEEEda/G/wAuz/5/f/IRr074afHrxb8KtkGjeIvtGkrn/iV6hC81qM7z8q5DR/M5Y+Wy7jjdnpXJWwvO+aO50UsSo6S2P1IqC7s7bULd7e7t4ri3fG6KZA6tg5GQeDyAa85+EPxdf4t6FZatZ+GL23tZ5JYprmO8tZoLd0z8rfvFmBI2nBiB+cH7pDH1AxODjafyrhlSnHdHZCtF6xZSsNNstLhaGxs7e1hZt5SCNUUtgDOAOvA/KrVO8tz/AAn8q4r4k+PpfhxoWpaxP4fvbzT7G0Nw92t1aw26vyFjYySh8lto+VHJ3gKGb5aUaU5bIc6sd5M7Ovjb9pP9qfS7vRL7wb4Fu4r9r+OW11LVAmYo4jlHii3DDlhnMgyoUjaSW3J418Uv2mvFvxN+02X9s/2LoEu5P7O05HTzIzvG2WX70mUfaw4RtoOwGvF/Ls/+f3/yEa7qOE5XzTOOrik9IleirHl2f/P7/wCQjTZ4FjWN45PMikBw2MdDzxXYc10yGpnkLRRrnoKhr2X9nrwUmpeIpfGGsxyReF/CyPfzXRRijTRrvVRtIYlf9YQob7gBHzjPLjcfTwGHniam0Vt1b6JebeiLhRdaahH+vM6L423v/CAfCXwR8NEa5j1J4V1HUozN9zJdjE20bHUzM5GCceSpOchq+cK6Hxz4tuvHXi7V/EN4uyW/mLrHkHyowAqJkAZ2oFXOATjJ5Nc9WWS4CWCwqhV/iSblP/FJ3f3bLyROKrKrUvHZaL0WwUUVYtrbzf3kmREDjI6sfQf49vyB9Y5ivRWli3HAtYyB3Zmyfrgil/cf8+kX/fT/APxVPlFzGZRWn+4/59Iv++n/APiqP3H/AD6Rf99P/wDFUcocxmUVp/uP+fSL/vp//iqP3H/PpF/30/8A8VRyhzGZRWn+4/59Iv8Avp//AIqj9x/z6Rf99P8A/FUcocxmUVp/uP8An0i/76f/AOKo/cf8+kX/AH0//wAVRyhzGZRWn+4/59Iv++n/APiqP3H/AD6Rf99P/wDFUcocxmUVp/uP+fSL/vp//iqP3H/PpF/30/8A8VRyhzGZRWn+4/59Iv8Avp//AIqj9x/z6Rf99P8A/FUcocxmUVp/uP8An0i/76f/AOKo/cf8+kX/AH0//wAVRyhzGZRWn+4/59Iv++n/APiqP3H/AD6Rf99P/wDFUcocxmUVp/uP+fSL/vp//iqP3H/PpF/30/8A8VRyhzGZRWn+4/59Iv8Avp//AIqj9x/z6Rf99P8A/FUcocxmUVp/uP8An0i/76f/AOKo/cf8+kX/AH0//wAVRyhzGZRWn+4/59Iv++n/APiqrXFsqqZIdxjH3lY5K/4j3/D0yNBcq0UUVJR6d+01/wAlv8U/9uv/AKSxUUftNf8AJb/FP/br/wCksVFeNkX/ACK8L/17h/6Sjpxf+8VPV/mO/Zp/5Ln4Z+t1/wCks1eX16l+zU7H45eGRuOM3XGf+naWvLarD/8AI0r/APXun/6VVFP/AHeHrL8ohRRRXrnOdHZ+NdYtvB154Riudui3d4l9JGowxkVduCR95ThCVbIzGhGDnOJUcXep4YjNKkYzljjgZxXPGlCnKXIrXd35vubqTcVd7EkzfZ7DYfv3BBx6KOh/E1nVav5hNcttx5cfyJg54HvVWmzMKKKKQH0T+yN8av8AhWvjpdE1rVPs3hDXMpN9ol2wWlzgeXOflO3O0RscqMMGY4jGP0vr8R6/Sj9kP44yfEzwjJ4d1u6mn8VaBGvmXFzMjSX1uWISQDhiU+VHJB5KMWLOQBjR9IV8D/ttfGr+2tYg+H2gapv0zT8vrH2aXKTXIb5YH+Xnytu4gMRufBAaLj6Y/aQ+MkXwc+H095btu8Q6pvs9LjV490cpQ5uCr53JHwT8rAsyKcBsj8rr29udSvLi8vLia5vLmRpZp5nLySuxyzMx5JJJJJ5JNCBkFFFFAgrQsm8+2ltv4wfNT3IHI/Ks+pbadraeOVeqnOPUdxTQEtblp411jTPCOreFre5xo+rTRT3ETDdzGcjbnhdx2FiBk+WgzgEHKu4hDOypzGfmU9iDVWX7o+tKdKFW0aivZp6907p/J6mnM0m4sioooroMArSHFpagcAoWPudzDP5AflWbWn/y62n/AFzP/obVUSZDKKtaZp1xq+pWen2cZku7yZIIkH8TsQqj8yK9t+Ivw8sbeTQprnSbnw7oun6kNAur6SxaH7TCoUpecgb2fExLc9F9qdyTwiivSrjwjY21v4gntbW7trVNGa5hM9xbXySMt1DGSk6JtxhznaFZTwTgkHU8L+EPDf8Abvg64t7a71azkv7BLycXcEkDNKV3RyQbC8QDkr8+4OFIGMgguB5DRXqOj+DNA8Q/29rEUFxbaXY3UVpHY3Gt2ltI8jiRi32iZEQKBGcIELHPXAJqd/AXhHSzbi8vtQ1FbzW5NLgm026g8sRCOBxIWCurMpnwVU4JHDLjkuB5PRWtJ4fum8Tv4ftR596b02MYAx5j79g/M17j4n+H0Np4h8GTjwxJp+nafr0GgT/abExJqMSshS4YMoEnmYm3HngKPSi4HzxRXonw+sbS4+Kxtp4bI2qNfkJdQCWBNkExUtGVYEKQDjaenQ1r6sug67pGotaz6bdavpujSz3l5pemrbW0zG7gWMLG8SbWCu2XREJyBkjdkuB5JRXqHi3wX4X0ibxTBpv9sO/hq+jhna5uIsXUTSFGC4j/AHbAgAMdwPJ2jpVzxR4c0LUfij4ksdN8OXw0+wln+0Rx6vbWcMREgUOJHgEcUfIUIc8kYbsS4HkdFeqat8P/AA94Zi8Q3mpvqN1bWR01rSGzu4MyLdQySFWmVXQ7dmA6AhsHA+YEYHwysbKTWL7U9VSA6VpVnJPO88PnLEz4hhfyukm2WWMlTwQDn0ouBxVFdh438L6ppRTVtRj02CO+mMduLBQkVyqohM8SqNvltvXkYG4kbRggd5pHhLR/FHgLwlaPb2tneW8cuqXl8karLLZrdSx3G5urlFEbKD0Aai4HidFes/E7RdKvYdT8RWVjFppWLRDFZWaLHAgurKSWT5QOu6Nec9znOeN7wp4b0vRtd1LQ54JbzTF8S6FE0U7KTIHE/DZUgrluRjkZHGc0XA8Ior0FtD03WdK8Sy6NbvZLFqNlbwxahdW7AFxcbiZ2jjCLlBwCo/vbsAjW8D6Wmj+H/GbXd34atb+znsY0vtQtotTt0D+cWVCkU6ktheVH8OCRii4HlFFe1WGm6B/Yd/qWsWSaobjQbi7D6ckFkisuqeVui/0fK5GMFlyqllwAQF5XTfBOm6jqHg2ISXiQ67Y3N3MPMUtGY5rlFCnb02wJnI6k9MgAuM8/orr/ABno2heH7fSbWxXUZNTubCzvriaeZPJTzoFkaNUCZPLAhi3A4wfvVyFAgooopgFSQ8+aDyDE+R64UkfqAfwqOpYOsn/XKT/0A0IDKooorM0PTv2mv+S3+Kf+3X/0liop37TLsPjd4oAYgf6L3/6dYqK8bIv+RXhf+vcP/SUdOL/3ip6v8w/Zp/5Ln4Z+t1/6SzV5fXqH7NP/ACXPwz9br/0lmry+qw//ACNK/wD17p/+lVRT/wB3h6y/KIUUUV65zksX3T9auQt9ntprg9ceWnruPfPbAqism0YxWldWyzRW8aXVsFiU53Sc7j1/Cs2ne5pzK1jIoq9/Zv8A092n/fz/AOtR/Zv/AE92n/fz/wCtU8rJuUaKvf2b/wBPdp/38/8ArV0GmfDHxXrVlFfabomoXtlLny7i2tZZI3wSDhlUg4II+oNZ1akKS5qjSXm7FRi5O0Vc5Guw+F/xF1b4V+NdM8S6TNMGtpFFzbxybBeW5YGSBiQRhgOpB2kBhyoIs/8ACnPHP/Qr6x/4AT//ABFcr/Zbf8/Nr/38/wDrVNKtTrX9lJSt2aY5RlH4lY9D+PnxkvfjR46uNW3XcOg237nS7C4dT9niwAzELwHcrub7xHC7mCLXltX/AOy2/wCfm1/7+f8A1q6W1+E3jK+tobq18O6pPbToskUsVlMySIRkMpCYIIOQRTq1YUVepJR9XYUYuXwq5xdFdpdfCbxlY2011deHdUgtoEaSWaWymVI0AyWYlMAADJJrmf7N/wCnu0/7+f8A1qKVWFVXpyUvR3CUXH4lYo0Ve/s3/p7tP+/n/wBaj+zf+nu0/wC/n/1q15WTckVvtFgjfx252tnqVPTn9MVVf7hq/ZWq28rF7q2MboUbbJzg+lZ8jbWdODgkZU5BqkmVzK1iKiiitDMK0/8Al1tP+uZ/9Dasyr9tKJ4kgP8ArUyE/wBoHnb9c5Pvn6A1Ell/RtYvfD+p2+padN5F9bktFLtVihIIyAQRnng9jyOasaP4m1XQIrqLTrswR3ZjMq7FYMUbcp+YHBB9OxIPBIOUylSVYEEcEHtSVRJ0d/4617UUmimu4kgmtjZtBb2sMMQiMiyEKiKFUl0UkgAnHJpW8feIDaW9qt8sSQSRSiSG3ijldozmMvIqh5Np5G4nFc3RSA6ZPH+uxX95epLZK96qi4hGnW32ebbyrND5fllgSTu255PPNU7jxbrF15Hm3hb7PeNfx/u0+WZggLDjpiJBt6DbwOtYtFAGrZ+JNT0/Xv7dtrny9W815xceWpIkbOWAIwDySOODyMYFP0PxTq3hvzf7Mu/IEskMrgxo4LxSCSNsMDghhn6Eg8Eg49FAGjYa9qGmaq+qWtx5d+4lBl2Kc+YrK/BGOVdh04zxUVjqt3psV9FazeXHfwfZrgbQd8e9X28jj5kU5GDx9ap0UAbF74q1fUZdZlubvzH1qQS3p8tB5zB94PA+X5uflxWkfiN4ia+kvXubR7iaD7POz6fbsLlNwb96pjxK2VU7nDNkDmuVooA39Y8ba7r8d3HqN956XZtzKPKRd3kIyRfdUY2q7DjrnnOBVPQ/EGo+G7x7rTbgQyyRtDIGjWRJYz1R0cFWU4HDAjgVmUUAb2u+M9a8S2lvaandRzW1q5eCJLeKNYMgAqgRRsQ4B2Lhc84zzWdd6teX1lp9lcTb7bT0eO3TaB5as5dhkDJyzE8561SooA6W28f+ILSWSRLyJ/MtoLRkmtYZYzHAgSL5HQruRQAGxu6nOSajuPHXiG6vL28l1KRru9uoL2aYIoZpod3lvkDgjc3TGc85rnqKANvU/Fuq6tHfx3ElssV/JFLcR29pDAsjxhwjYjRQD+8fJHXPOeKo2+r3lrpl7pkU22yvXjknj2g72j3bDnGRje3Q855qlRQBv6d411vShaLb3URjtLZ7OOKa2iljMLyGRkZHUq4LsW+YHnHoKtaX8RvEmjWqW1jfRRRxmTyj9khZ4hJneqMULIjZOVUheTxXLUUAXNS1W71eaGa9m82SGCK2Q7QuI40CIvAHRVAz1OOc1ToopgFFFFABUsHWT/rlJ/6Aaip0z/ZEdWBE7qVCnqgPUn6jIx759MgzNooorMs9O/aa/wCS3+Kf+3X/ANJYqKP2mv8Akt/in/t1/wDSWKivGyL/AJFeF/69w/8ASUdOL/3ip6v8yT9moL/wvLwzyc5uu3/TtLXlteofs0/8lz8M/W6/9JZq8vqsP/yNK/8A17p/+lVRT/3eHrL8ohRRRXrnOFFFFABRRRQAVb0zVL7Rb2K+029ubK9iz5dxbStHImQQcMpBGQSPoTVSilKKknGSumCdndHpmmftCfEvSbKKzt/FVy8UWdrXMMVxIcknmSRGZuvcnAwBwBXbf8NheOf+gV4c/wDAef8A+PV8+0V49fh3Kq75qmGhfyilv3ta/wAzqhjcRDRTf3n0F/w2F45/6BXhz/wHn/8Aj1cpqn7SXxL1T7an/CQ/Zbe63jyrW1iTylbPyo+3euAcBt24YBznmvKKKmjw3lNF80MNC/mk/wA7hLHYmWjm/vNDWNe1XxFcpdaxqd7qNyiCNZryd5nVASQoLEnGSTj3NZ9FFezCEYRUYqyRyttu7CiiiqAKKKKACiiigAooooAsLfXSKFW5mCgYADnAFL/aF3/z9T/9/DVaindisWf7Qu/+fqf/AL+Gj+0Lv/n6n/7+Gq1FF2Fiz/aF3/z9T/8Afw0f2hd/8/U//fw1WoouwsWf7Qu/+fqf/v4aP7Qu/wDn6n/7+Gq1FF2Fiz/aF3/z9T/9/DR/aF3/AM/U/wD38NVqKLsLFn+0Lv8A5+p/+/ho/tC7/wCfqf8A7+Gq1FF2Fiz/AGhd/wDP1P8A9/DR/aF3/wA/U/8A38NVqKLsLFn+0Lv/AJ+p/wDv4aP7Qu/+fqf/AL+Gq1FF2Fiz/aF3/wA/U/8A38NH9oXf/P1P/wB/DVaii7CxZ/tC7/5+p/8Av4aP7Qu/+fqf/v4arUUXYWLP9oXf/P1P/wB/DR/aF3/z9T/9/DVaii7CxZ/tC7/5+p/+/ho/tC7/AOfqf/v4arUUXYWLP9oXf/P1P/38NH9oXf8Az9T/APfw1WoouwsWf7Qu/wDn6n/7+Gq1FFFwCiiikM9Q/aZC/wDC7vFGSc/6L2/6dYqKb+01/wAlv8U/9uv/AKSxUV42Rf8AIrwv/XuH/pKOnF/7xU9X+ZzXwq8WJ4H+Jfh/XZmiS1trvZcPIjOEhkBjlbC8khHYjGeQOD0LPiH4UfwP4313QGWRY7G5ZYTK6u7Qn5omYrxkxspPTr0HSuPk/wBY/wBTXqujeMPDPjTw1o/hbxq0ul3eko8Vj4oiR7l44d25beaEfM6DLhSp+T5AFA3k1iVPDYlYyEXKLXLJLV2TbjJLd2vJNJNvmutrMp2nT9k3Z7r9V89NfI80or1Yfs8eMtQ/e+HX0TxNZD5XvNG1SGSFJO8ZLsp3AFTjGMMOaX/hmr4of9Cx/wCT9r/8cqv7eyzriYLyckn9zaaF9Tr9IP7meUUV6v8A8M1fFD/oWP8Ayftf/jlH/DNXxQ/6Fj/yftf/AI5R/b2V/wDQVT/8Dj/mH1PEf8+5fczyiivV/wDhmr4of9Cx/wCT9r/8co/4Zq+KH/Qsf+T9r/8AHKP7eyv/AKCqf/gcf8w+p4j/AJ9y+5nlFFer/wDDNXxQ/wChY/8AJ+1/+OUf8M1fFD/oWP8Ayftf/jlH9vZX/wBBVP8A8Dj/AJh9TxH/AD7l9zPKKK9X/wCGavih/wBCx/5P2v8A8co/4Zq+KH/Qsf8Ak/a//HKP7eyv/oKp/wDgcf8AMPqeI/59y+5nlFFer/8ADNXxQ/6Fj/yftf8A45R/wzV8UP8AoWP/ACftf/jlH9vZX/0FU/8AwOP+YfU8R/z7l9zPKKK9X/4Zq+KH/Qsf+T9r/wDHKP8Ahmr4of8AQsf+T9r/APHKP7eyv/oKp/8Agcf8w+p4j/n3L7meUUV6v/wzV8UP+hY/8n7X/wCOUf8ADNXxQ/6Fj/yftf8A45R/b2V/9BVP/wADj/mH1PEf8+5fczyiivV/+Gavih/0LH/k/a//AByj/hmr4of9Cx/5P2v/AMco/t7K/wDoKp/+Bx/zD6niP+fcvuZ5RRXq/wDwzV8UP+hY/wDJ+1/+OUf8M1fFD/oWP/J+1/8AjlH9vZX/ANBVP/wOP+YfU8R/z7l9zPKKK9X/AOGavih/0LH/AJP2v/xyj/hmr4of9Cx/5P2v/wAco/t7K/8AoKp/+Bx/zD6niP8An3L7meUUV6v/AMM1fFD/AKFj/wAn7X/45R/wzV8UP+hY/wDJ+1/+OUf29lf/AEFU/wDwOP8AmH1PEf8APuX3M8oor1f/AIZq+KH/AELH/k/a/wDxyj/hmr4of9Cx/wCT9r/8co/t7K/+gqn/AOBx/wAw+p4j/n3L7meUUV6v/wAM1fFD/oWP/J+1/wDjlH/DNXxQ/wChY/8AJ+1/+OUf29lf/QVT/wDA4/5h9TxH/PuX3M8oor1f/hmr4of9Cx/5P2v/AMco/wCGavih/wBCx/5P2v8A8co/t7K/+gqn/wCBx/zD6niP+fcvuZ5RRXq//DNXxQ/6Fj/yftf/AI5R/wAM1fFD/oWP/J+1/wDjlH9vZX/0FU//AAOP+YfU8R/z7l9zPKKK9X/4Zq+KH/Qsf+T9r/8AHKP+Gavih/0LH/k/a/8Axyj+3sr/AOgqn/4HH/MPqeI/59y+5nlFFer/APDNXxQ/6Fj/AMn7X/45R/wzV8UP+hY/8n7X/wCOUf29lf8A0FU//A4/5h9TxH/PuX3M8oor1f8A4Zq+KH/Qsf8Ak/a//HKP+Gavih/0LH/k/a//AByj+3sr/wCgqn/4HH/MPqeI/wCfcvuZ5RRXq/8AwzV8UP8AoWP/ACftf/jlH/DNXxQ/6Fj/AMn7X/45R/b2V/8AQVT/APA4/wCYfU8R/wA+5fczyiivV/8Ahmr4of8AQsf+T9r/APHKP+Gavih/0LH/AJP2v/xyj+3sr/6Cqf8A4HH/ADD6niP+fcvuZ5RRXq//AAzV8UP+hY/8n7X/AOOUf8M1fFD/AKFj/wAn7X/45R/b2V/9BVP/AMDj/mH1PEf8+5fczyiivV/+Gavih/0LH/k/a/8Axyj/AIZq+KH/AELH/k/a/wDxyj+3sr/6Cqf/AIHH/MPqeI/59y+5nlFFer/8M1fFD/oWP/J+1/8AjlH/AAzV8UP+hY/8n7X/AOOUf29lf/QVT/8AA4/5h9TxH/PuX3M8oor1f/hmr4of9Cx/5P2v/wAco/4Zq+KH/Qsf+T9r/wDHKP7eyv8A6Cqf/gcf8w+p4j/n3L7meUV03w88KP448b6FoCrI0d9cqsxidUdYR80rKW4yI1Yjr06HpXYH9njxlp/73xE+ieGbI/Kl5rOqQxwvJ2jBRmO4gMcYxhTzVTWfGHhnwX4a1jwt4KaXVLvVkSK+8USo9s8kO7c1vDCfmRDhAxY/P84KkbCMq2a08TB0svkqk3peOsY3+05bab8qfM9l1aqOHdN81ZWS6Pd+Vv12RzfxZ8WJ44+I/iPXYWie1ubopbvGjIHhjAjibDcglEUnOOSeB0BXGUV6GHoQw9GFCn8MUkvRKyMJzc5Ob3ZJJI4dgGbqe9N8x/77fnRRWxIeY/8Afb86cJH2MdzdR3+tFFADfMf++350eY/99vzoooAPMf8Avt+dOkkcOwDN1PeiigBvmP8A32/OjzH/AL7fnRRQA4SPsY7m6jv9ab5j/wB9vzoooAPMf++350eY/wDfb86KKAHSSOHYBm6nvTfMf++350UUAHmP/fb86cJH2MdzdR3+tFFADfMf++350eY/99vzoooAPMf++3506SRw7AM3U96KKAG+Y/8Afb86PMf++350UUAOEj7GO5uo7/Wm+Y/99vzoooAPMf8Avt+dHmP/AH2/OiigB0kjh2AZup703zH/AL7fnRRQAeY/99vzpwkfYx3N1Hf60UUAN8x/77fnR5j/AN9vzoooAPMf++3506SRw7AM3U96KKAG+Y/99vzo8x/77fnRRQA4SPsY7m6jv9ab5j/32/OiigA8x/77fnR5j/32/OiigB0kjh2AZup703zH/vt+dFFAB5j/AN9vzpwkfYx3N1Hf60UUAN8x/wC+350eY/8Afb86KKADzH/vt+dOkkcOwDN1PeiigBvmP/fb86PMf++350UUAOEj7GO5uo7/AFpvmP8A32/OiigA8x/77fnRRRQB/9k=",
	"ketawa": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4lkkcOwDN1Pem+Y/99vzok/1j/U165dXUPwbtrOwsLOMfEQJ5l9qMmJl09ZAGWGJWGwuU27nw2N7gMd3yrE4mVJxp04805Xsr223bfSK0u7N3aSTbKo0VNOUnaK3f6Lu30Wmz1MDSvgz8QdZt2ntvDl6iK5Qi6dLZs4B4WVlJHPXGOvoa0B8A/iPtP/EgbOR/y/W//wAcridU1nUtcuFuNU1C7vrhUEay3UzSsFBJ2gsScZJOPc1SrL2OZPX2sF5ckn+PtFf7kac+EX2JP/t5L/21/meg/wDCg/iR/wBABv8AwOt//jlH/Cg/iR/0AG/8Drf/AOOV59RS9hmX/P6H/guX/wAtD2mE/wCfcv8AwJf/ACB6D/woP4kf9ABv/A63/wDjlOf4B/Ecs2NAbGeP9Ot//jleeUU/YZl/z+h/4Ll/8tD2mE/59y/8CX/yB6D/AMKD+JH/AEAG/wDA63/+OUf8KD+JH/QAb/wOt/8A45Xn1FL2GZf8/of+C5f/AC0PaYT/AJ9y/wDAl/8AIHoY+AfxH2n/AIkDZyP+X63/APjlN/4UH8SP+gA3/gdb/wDxyvPqKfsMy/5/Q/8ABcv/AJaHtMJ/z7l/4Ev/AJA9B/4UH8SP+gA3/gdb/wDxyj/hQfxI/wCgA3/gdb//AByvPqKXsMy/5/Q/8Fy/+Wh7TCf8+5f+BL/5A9Df4B/Ecs2NAbGeP9Ot/wD45Tf+FB/Ej/oAN/4HW/8A8crz6in7DMv+f0P/AAXL/wCWh7TCf8+5f+BL/wCQPQf+FB/Ej/oAN/4HW/8A8cpw+AfxH2n/AIkDZyP+X63/APjleeUUewzL/n9D/wAFy/8Aloe0wn/PuX/gS/8AkD0H/hQfxI/6ADf+B1v/APHKP+FB/Ej/AKADf+B1v/8AHK8+opewzL/n9D/wXL/5aHtMJ/z7l/4Ev/kD0H/hQfxI/wCgA3/gdb//ABynP8A/iOWbGgNjPH+nW/8A8crzyin7DMv+f0P/AAXL/wCWh7TCf8+5f+BL/wCQPQf+FB/Ej/oAN/4HW/8A8co/4UH8SP8AoAN/4HW//wAcrz6il7DMv+f0P/Bcv/loe0wn/PuX/gS/+QPQx8A/iPtP/EgbOR/y/W//AMcpv/Cg/iR/0AG/8Drf/wCOV59RT9hmX/P6H/guX/y0PaYT/n3L/wACX/yB6D/woP4kf9ABv/A63/8AjlH/AAoP4kf9ABv/AAOt/wD45Xn1FL2GZf8AP6H/AILl/wDLQ9phP+fcv/Al/wDIHob/AAD+I5ZsaA2M8f6db/8Axym/8KD+JH/QAb/wOt//AI5Xn1FP2GZf8/of+C5f/LQ9phP+fcv/AAJf/IHoP/Cg/iR/0AG/8Drf/wCOU4fAP4j7T/xIGzkf8v1v/wDHK88oo9hmX/P6H/guX/y0PaYT/n3L/wACX/yB6D/woP4kf9ABv/A63/8AjlH/AAoP4kf9ABv/AAOt/wD45Xn1FL2GZf8AP6H/AILl/wDLQ9phP+fcv/Al/wDIHoP/AAoP4kf9ABv/AAOt/wD45Tn+AfxHLNjQGxnj/Trf/wCOV55RT9hmX/P6H/guX/y0PaYT/n3L/wACX/yB6D/woP4kf9ABv/A63/8AjlH/AAoP4kf9ABv/AAOt/wD45Xn1FL2GZf8AP6H/AILl/wDLQ9phP+fcv/Al/wDIHoY+AfxH2n/iQNnI/wCX63/+OU3/AIUH8SP+gA3/AIHW/wD8crz6in7DMv8An9D/AMFy/wDloe0wn/PuX/gS/wDkD0H/AIUH8SP+gA3/AIHW/wD8co/4UH8SP+gA3/gdb/8AxyvPqKXsMy/5/Q/8Fy/+Wh7TCf8APuX/AIEv/kD0N/gH8RyzY0BsZ4/063/+OU3/AIUH8SP+gA3/AIHW/wD8crz6in7DMv8An9D/AMFy/wDloe0wn/PuX/gS/wDkD0H/AIUH8SP+gA3/AIHW/wD8cpw+AfxH2n/iQNnI/wCX63/+OV55RR7DMv8An9D/AMFy/wDloe0wn/PuX/gS/wDkD0H/AIUH8SP+gA3/AIHW/wD8co/4UH8SP+gA3/gdb/8AxyvPqKXsMy/5/Q/8Fy/+Wh7TCf8APuX/AIEv/kD0H/hQfxI/6ADf+B1v/wDHKc/wD+I5ZsaA2M8f6db/APxyvPKKfsMy/wCf0P8AwXL/AOWh7TCf8+5f+BL/AOQPQf8AhQfxI/6ADf8Agdb/APxyj/hQfxI/6ADf+B1v/wDHK8+opewzL/n9D/wXL/5aHtMJ/wA+5f8AgS/+QO11T4M/EDRrQT3Phy9dWcIBauly+cE8rEzEDjqRjp6iuA8x/wC+351r6XrOpaHcNcaXqF3Y3DIY2ltZmiYqSDtJUg4yAcewr0W2uofjJbXlhf2cZ+IhTzLHUY8QrqCxgs0MqqNgcJu2vhc7EBYbfmmdfFYRc+K5ZQ6yinHl83FuXurq1K6Wtmr2caVGu+WjdS6J638k0lr2Vte/fyPzH/vt+dFNor0zjO/+DOlQ6z8VvDltO0ioly1yDGQDuiRpVHIPBZAD7Z6da5nWdUm1zWNQ1S4WNbi+uJLmRYwQoZ2LEAEk4yfU123wDC/8Lf0Dk5zc9v8Ap3lrzyvOo65lVv0hC3zlUv8AfZfcdc9MJDzlL8FH/Nn1F+z74t8F6N4Oktpr6x0vWhKTeveSrEbj5m8sqzH5lC8YHQ7jgbst61/wsPwh/wBDVoX/AIMIf/iq+A6K+dzDgfD43EzxMq0k5u/R/wBLt2Wh62F4iq4ejGiqa91WPvz/AIWH4Q/6GrQv/BhD/wDFUf8ACw/CH/Q1aF/4MIf/AIqvgOiuL/iHeG/5/wAvuRv/AK01v+fa+9n35/wsPwh/0NWhf+DCH/4qj/hYfhD/AKGrQv8AwYQ//FV8B0Uf8Q7w3/P+X3IP9aa3/Ptfez78/wCFh+EP+hq0L/wYQ/8AxVH/AAsPwh/0NWhf+DCH/wCKr4Doo/4h3hv+f8vuQf601v8An2vvZ9+f8LD8If8AQ1aF/wCDCH/4qj/hYfhD/oatC/8ABhD/APFV8B0Uf8Q7w3/P+X3IP9aa3/Ptfez78/4WH4Q/6GrQv/BhD/8AFUf8LD8If9DVoX/gwh/+Kr4Doo/4h3hv+f8AL7kH+tNb/n2vvZ9+f8LD8If9DVoX/gwh/wDiqP8AhYfhD/oatC/8GEP/AMVXwHRR/wAQ7w3/AD/l9yD/AFprf8+197Pvz/hYfhD/AKGrQv8AwYQ//FUf8LD8If8AQ1aF/wCDCH/4qvgOij/iHeG/5/y+5B/rTW/59r72ffn/AAsPwh/0NWhf+DCH/wCKo/4WH4Q/6GrQv/BhD/8AFV8B0Uf8Q7w3/P8Al9yD/Wmt/wA+197Pvz/hYfhD/oatC/8ABhD/APFUf8LD8If9DVoX/gwh/wDiq+A6KP8AiHeG/wCf8vuQf601v+fa+9n35/wsPwh/0NWhf+DCH/4qj/hYfhD/AKGrQv8AwYQ//FV8B0Uf8Q7w3/P+X3IP9aa3/Ptfez78/wCFh+EP+hq0L/wYQ/8AxVH/AAsPwh/0NWhf+DCH/wCKr4Doo/4h3hv+f8vuQf601v8An2vvZ9+f8LD8If8AQ1aF/wCDCH/4qj/hYfhD/oatC/8ABhD/APFV8B0Uf8Q7w3/P+X3IP9aa3/Ptfez78/4WH4Q/6GrQv/BhD/8AFUf8LD8If9DVoX/gwh/+Kr4Doo/4h3hv+f8AL7kH+tNb/n2vvZ9+f8LD8If9DVoX/gwh/wDiqP8AhYfhD/oatC/8GEP/AMVXwHRR/wAQ7w3/AD/l9yD/AFprf8+197Pvz/hYfhD/AKGrQv8AwYQ//FUf8LD8If8AQ1aF/wCDCH/4qvgOij/iHeG/5/y+5B/rTW/59r72ffn/AAsPwh/0NWhf+DCH/wCKo/4WH4Q/6GrQv/BhD/8AFV8B0Uf8Q7w3/P8Al9yD/Wmt/wA+197Pvz/hYfhD/oatC/8ABhD/APFUf8LD8If9DVoX/gwh/wDiq+A6KP8AiHeG/wCf8vuQf601v+fa+9n35/wsPwh/0NWhf+DCH/4qj/hYfhD/AKGrQv8AwYQ//FV8B0Uf8Q7w3/P+X3IP9aa3/Ptfez78/wCFh+EP+hq0L/wYQ/8AxVH/AAsPwh/0NWhf+DCH/wCKr4Doo/4h3hv+f8vuQf601v8An2vvZ9+f8LD8If8AQ1aF/wCDCH/4qj/hYfhD/oatC/8ABhD/APFV8B0Uf8Q7w3/P+X3IP9aa3/Ptfez78/4WH4Q/6GrQv/BhD/8AFUf8LD8If9DVoX/gwh/+Kr4Doo/4h3hv+f8AL7kH+tNb/n2vvZ9+f8LD8If9DVoX/gwh/wDiqP8AhYfhD/oatC/8GEP/AMVXwHRR/wAQ7w3/AD/l9yD/AFprf8+197Pvz/hYfhD/AKGrQv8AwYQ//FUf8LD8If8AQ1aF/wCDCH/4qvgOij/iHeG/5/y+5B/rTW/59r72ffn/AAsPwh/0NWhf+DCH/wCKo/4WH4Q/6GrQv/BhD/8AFV8B0Uf8Q7w3/P8Al9yD/Wmt/wA+197PsH4weNfAuo+AtUtrjU9N1W4kQizhtJ0mkS42nZINrZUKeSeBjI53bT8l6Nqk2h6xp+qW6xtcWNxHcxrICVLIwYAgEHGR6iqVFfU5NkVLKsPLDRm5qTu7+ltEePj8xnjaqquKi12Ox+NWlQ6N8UvE1tA0jI9wLkmQgndKiysOAOAzkD2x160VofH8L/wtzxFknP8Ao/b/AKd46K2yeTnl+HlJ6uEf/SUZY9KOKqpfzP8ANh8A/wDksGgfW5/9J5a8+r0H4B/8lg0D63P/AKTy159RQ/5GVb/BT/8ASqoVP90p/wCKX5QCiiivVOMKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKK6HRdFtTY/2tq3ntpzStbwwW0gSW4kUKWG8qwRVDoSSpJLKAOWZIqVFBXfyXVv+vu3ehUYuTOeortf7W0f/AKE/Rf8Av9e//JFH9raP/wBCfov/AH+vf/kisvbVP+fUvvj/APJFckP51+P+RxVFdr/a2j/9Cfov/f69/wDkij+1tH/6E/Rf+/17/wDJFHtqn/PqX3x/+SDkh/Ovx/yOKortf7W0f/oT9F/7/Xv/AMkUf2to/wD0J+i/9/r3/wCSKPbVP+fUvvj/APJByQ/nX4/5HFUV2v8Aa2j/APQn6L/3+vf/AJIo/tbR/wDoT9F/7/Xv/wAkUe2qf8+pffH/AOSDkh/Ovx/yOKortf7W0f8A6E/Rf+/17/8AJFH9raP/ANCfov8A3+vf/kij21T/AJ9S++P/AMkHJD+dfj/kcVRXa/2to/8A0J+i/wDf69/+SKP7W0f/AKE/Rf8Av9e//JFHtqn/AD6l98f/AJIOSH86/H/I4qiu1/tbR/8AoT9F/wC/17/8kUf2to//AEJ+i/8Af69/+SKPbVP+fUvvj/8AJByQ/nX4/wCRxVFdqNN0zxTLHZafpiaXrEzCO2S3mdradicLGwkLMjsTgPv25CgqoLOOKq6dXnbi0010dv0bQpQ5dU7oKK2dK0qB7X+0NQ802RkaGOKBwskzgAt8xBChQykkg5yAB1K6f2zTP+hc03/v7c//AB6qlUUXY4Z4tRlaMXL0t+rX9eZydFdZ9s0z/oXNN/7+3P8A8eo+2aZ/0Lmm/wDf25/+PVPtokfXP+ncv/Jf/kjk6K6z7Zpn/Quab/39uf8A49R9s0z/AKFzTf8Av7c//HqPbRD65/07l/5L/wDJHJ0V1n2zTP8AoXNN/wC/tz/8eo+2aZ/0Lmm/9/bn/wCPUe2iH1z/AKdy/wDJf/kjk6K6z7Zpn/Quab/39uf/AI9R9s0z/oXNN/7+3P8A8eo9tEPrn/TuX/kv/wAkcnRXWfbNM/6FzTf+/tz/APHqpajpdrdWs99p0bw/ZwHubZ33BVLBQ6MRnbuYLtOWGQctlirjVi3YqGLTaUotX72/RswKKKK0Ow7/APaA/wCSueIv+3f/ANJ4qKP2gP8AkrniL/t3/wDSeKivIyX/AJFuG/wQ/wDSUduYf73V/wAUvzY74B/8lg0D63P/AKTy159XofwDdj8X9AG44zc8Z/6d5a88qqH/ACMq3+Cn/wClVRVP90p/4pflAKKKK9U4wooooAKKkt7ea8uIre3ikmuJnEccUalmdicBQBySTxivabf4O6J4FsLbWPiPq/leblodIsMtLOyhWKM4/wCBI23CglT5gyK4MbmVDBcsajblL4YpXk/RL89u7OnD4SpiLuGy3b0S9WeSaH4f1TxNqCWGkWE97dvg+XCmdoJA3MeirlhljgDPJr1HT/2dNdjtI7/xJq2laBpwz57zzB3g5KrnGIzk7f4/4vXinal8cLrTLdNL8C6Va+HdJicFSsSSTzkAqGfcCuSoTOQzZX75rzfUb/VNduFuNUv7q8nVQiy3UzSuFyTgFiTjJJx71w2zfFu8eWhD055//Ir/AMm/Q6f9hoKzvUl/4DH/ADf4HqI8CfCDSf8AQ9V8dX91fxf6yawjzA2eRt2xyDoQD855B6dA7/hIPgf/ANCdrn/f5/8A5IryUWa45Yk+1PFtHj7v61f9gynrWxVWT8pcq87KKX3O9uhP9pKOkKMEvS/5tnq//CQfA/8A6E7XP+/z/wDyRTT4W+DGs82finVtMu73/UwXCExWrv8AdVyY8bVJAJMnQff/AIq8q+zRf3f1NMNouOGYH3o/sBx1p4mqn/j5vwkmH9pJ/HRg/wDt235WPUrn9na/v7eW78K+JdG16ziQhmjk2M0oGfLG0umcFeWYfe5wOT5l4l8Ia54Pu1tdc0yeylf7jOAUkwATtcZVsbhnBOM4PNJZzX2k3cd3p93NbXUedk1vIY5FyCDhgcjgkde9eh6J8dNetYDp3iS1tfEmjsqI9rfxruIUfL8+07ju2klw5O3sTmodPN8I7qUa8ezXJP5Ne6/mo+qK5sDWVrOm/wDwKPz6/meRUV7knwx8G/E1Jp/h/qr6bqUS75dH1MMQq7guQ/zEDgsSDJy6g7M4rxrWNHvtA1O503UraS2vrZ9ksUnVT/IgjBBHBBBGQa7MFmlDGSlTjeM47xkrSXy6rzV15nPiMHUoJTdnF7Nap/12dmUqKKK9E5QooooAK7XVv+Rf8H/9gyT/ANLbmuKrtdTIk8N+EpEO6NLGWBmXkLILudyhPZgskbY64dT0IrnrfxKX+J/+kyNafwT9P1RT0bT/AO1tX0/T/M8r7XcRweZt3bdzBc44zjNd7cfCqCXXNX0DStba61zTUMhtp7TyVnAAJEbh2yeRwQK4bQL+PStd0u/mV2htbmKZwgBYqrgnGe/FekyfErQdN8Xa14s0uHUrjVr1GS3huoo4orclQCxKuxc8dMDr+NedmlTHxrWwl7crtomnO6sm2tFa99V99jqwccM4Xr2311d+Wzvbu727nK23gqC38M2Wv63qb2FpqErRWscNt58sgU4ZyCygKD7k+1bdl8IJ5vFD6Rcaokdq2nHU7e9hh8wTxZGMKWXB57nt75rO/wCEt0nXPB+laBrq30Emkyu1vd2caSl0c5KsrMuD6EHt0rpbD4uaYnixb2eyvIdHtdIOlWsUQWSUDIwzZZRnjsfT61x4mtm6U/ZJ39/pGyV/c5dNW1ve/W6WhvRhgW489re71d9vev2V9tum+px934JSXwzJ4i0TUG1CwgmWC4jlt/JmhZsBSVDMCCSBkN1P1xrSfDC3tNcsvDt9ry2/iG7jVhALYvBG7DKo8u7IY8dFI561Ufxlp2i+Drrw7oCXkrX1wk91e3iLGTsIKqiKzYGVByWPf142br4g+HdV8W2Hi++tNSTVrZY3ksoVQwSyoMKwkLblHA42np1q6lXNPe5b8vv8rtHmekeS6tZJvm6LRK9hRhg9L2v7t1d2Wr5rO+rtbq+trmRYfDK7Ol6vqOpy3MEWmXpsJYrK1+1S+YBljt3KAgyPmz3qPQfAuna5D4lu01uZdO0SFJjKljmSYMDkbGkXaQQR1NXNH+IbW+qalq76zrGl6hfXbXEkdjBHPA6HBAKO68jkZOeMe9b8Xxb0uXWfGV75Wo6Ydchiit5rFFaWEoCDI3zp8xyDwfx71nXrZxHnSV/htZKy96HMrOLvpzNNN6Xur2Kp08C+Vt99+ukrPRq2ttLL13Obu/hXenXvD2mabeJdLrtst1BJLGYmjQjJMi5bGB6E57VEvw/tNSt9bOha0b+70ZGlnhktfJEkanDNG25twHuFNblx8WoLXxD4X1Sytrm8m0e3a3ubq92pPeqwwd2C2MckZJ5PPvnWPjLQPDEXiKbQYdRlvtYhe2QXaIiWsbnLYKsxc9MHC9KcK2b8keZPmsraKzfO782mi5LNW5d310FKGB5nba7vq9Fyq1u/vX7/AHakFr4H0K78J3viVNe1IWNncLbPGdLTzCzYwQPtGMfMO9cSlqbu/W1shJMZZRHDuUKz5OFyMnBPHGT9a6rT/FllafDbVvDTxXBvry9S5SRVXywoC5BOc5+U9qp+ANb0vw34os9W1aC4ngs90kcUCqS0uPkzkjABOc+w4r0qM8ZSp4idS83FvkVlqrK2yW7utTkqRoTlSjG0U0uZ66O7vu30Nn4h/DCTwHa2VymppqMM8jQTNHFsEEoAOw/Mc5GfTp0rI8e+D/8AhCNbTTPtv2zfbpP5nleXjdnjGT6dc10Fx8S7PXPDHiLSdX0tIJtQmF9by2IdgLnOWZ/NkOAQAPl6Anisn4meLbLxn4ij1GwiuI4FtY4Stwqhty5z0JGOfWuTLqmae1p0sXdpc/M7Kz+Fxem28lp21N8XHB8kp0OvLZXem6e/on8zjasfEP8A5H/xV/2Fbr/0c1R29vLdTxQQRPLPKwSOONSzOxOAAByST2pPHVxDeeN/EtxbyxzW82pXMkcsbBldTKxDAjggjnNevV/3mH+GX5xOGH8KXqvyZdvP+QN4c/68n/8ASmeqUMMlzNHDCjSSyMERFGSxJwAKuXJD6H4fdTuRLWSJmHIDi4lYqffa6HHowPcU/wAP6p/Yeu6bqRj8wWdwkxT+8FYHFZT+JnhptRm4q7vL82d9cfAbxRBpJvA1nJcKu82aSEyfQHG0n2z+Nec6dp9xqmoW1hbJuubmRYo1PGWJwPpX1RcfGTwjDpRvk1ISvsytqqMJS393GOPr096+YrHXp9P8Rw63EiefFc/aQn8Od27b9O1QjyMqxeOrxqfWIWa2ura66HVp8NYLrW7vw/Z64s+v2yMxgNsVhkdRlkWTdkkc9VA4qFPhpczeAv8AhKILvfKhcyWJiwyojlWYNnnHBIwMA+1adv488P6b4rvfFlna6g2qTq7R2cqoIYpXGGYyBssOTxtHXrUOnfEuPTND8OW0cM8l3p91PLeK6r5U8Upbcg55yG7jrRqU54+0eT+7e6XZ8y9L2V/Pdir8KN3iZtF/tf7umf2j532b6fJt3+/XP4Vzngnwl/wmOp3Vl9s+y+RayXO/y9+7bj5cZHXPWu6f4o6EfHU+spa6gmnPpR09U8tDIrZ6434xj3zXO+DfEmgeDdYuLyOfU7yK4sprdg1nHEysxXaR+9bI4OemOOvYHCrjfZS5k+blVtFvrfpbtv8AIii+G9xdeAF8VW16JXBdnsvKwyxo5VnDbuccE8dDWjF8KFfxSdEbWCqjTRqJnFrk44+Tbv8Afrn8Ki0n4jwaN4e8M2NvBO9xplzM90jqvlTwyE7kHOTkHuOtbv8AwtTQ18eS65Fb6jFYHS/sKKsaeajZGDjfjAA9c0akVKmYJzUVp71tF391fdqu99djyzUotMiMf9nXd3cA53m5tVh2+mNsj57+lS6F/wAfV1/14Xn/AKTSVZ8SamupvbuNb1bVWQEFtSj2mMcYC/vXznnPTp3qtohCTXsrHbGlhd7nPAXdA6Lk9ssyqPUsB1NVHdHpybeHd97P+tl+RyFFFFdp7h3/AO0B/wAlc8Rf9u//AKTxUU74/uw+LniIBiB/o/f/AKd46K8jJf8AkW4b/BD/ANJR25h/vdX/ABS/Nh8A/wDksGgfW5/9J5a8+r0H4B/8lg0D63P/AKTy159VUP8AkZVv8FP/ANKqiqf7pT/xS/KAUUUV6pxhW34T8J6p411uDSNIg825l+ZmbhIUHV3PZRkfmAASQDR0fR77X9TttN022kub65fZFFH1Y/yAAySTwACTgCvcfFetw/Bfw5D4N8OCNPEl7bpNq+qRSBnRiD8iHgqeu3IG1WBALOWHlZjj6lKUcLhUpVp7J7JdZS62X4vRHbhMNGadas7Qjv3b7Lzf4biX2v8Ahr4I2+p6N4UaTUvGEqLDc6tOqmO2OPnRB6hhnZyASNzMU214/qN/f+ItSudT1O5kuLy5bfJNJ1Y+3YADAAHAAAAwKqwW4IDt07CrLyLGMsfw9a2y/KqWDvVk+epL4pvd/wCS00itERisZOvaCXLFbRWy/wA35gkaxjCj/wCvQ8iR/eYCqUl078D5R7dagr0HVS2OdUu5eN5GDj5j7gUz7b/0z/WqlFQ6sivZxLf23/pn+tPF4hxkMKo0Ue0kHs4mmkqP91gT6U5lDjDAEVlVLHcPHxnK+hq1V7kul2LKCexniubSWSOeFw8ckbFXRgchgRyCDzkV6/pXxE0L4maZbeHfiR5iXi3GbTXLdUiMW7qHOMIDgKTtKkEFgpXfXkkUyyjIPPcVHPbhsuvB7j1rix+WUcdFSlpKPwyWkovyf5rZ9UbYbF1MO2lqnuns/VfrujX+IXw91T4d62bC/Hm20uWtbxFwlwg7j0YZGV7Z7ggnkq9x+GXi+z8YafF8OfGCfadNufk068ZwstpIAdihj+SdTk7MMrYHlPizwnqngrW59I1eDyrmL5lZeUmQ9HQ91OD+RBAIIHHl+Nq+0lgsZb2sVe62nH+ZLp/eXR+TRtisPDkWIw/wP74vs/0fUxKKKK9g4Qra0XXksYXstQtnvdKdjJ5KSiKSKTAG+NyrBSQAGBUhgBkZVGXFoqZ04zVpDjJxd0dl5nhD/oMa7/4KYf8A5Jo8zwh/0GNd/wDBTD/8k1xtFY+xq/8AP2X3R/8AkTT2kP5F+P8Amdl5nhD/AKDGu/8Agph/+SaPM8If9BjXf/BTD/8AJNcbRR7Gr/z9l90f/kQ9pD+Rfj/mdl5nhD/oMa7/AOCmH/5Jo8zwh/0GNd/8FMP/AMk1xtFHsav/AD9l90f/AJEPaQ/kX4/5nZeZ4Q/6DGu/+CmH/wCSaPM8If8AQY13/wAFMP8A8k1xtFHsav8Az9l90f8A5EPaQ/kX4/5nZeZ4Q/6DGu/+CmH/AOSaPM8If9BjXf8AwUw//JNcbRR7Gr/z9l90f/kQ9pD+Rfj/AJnZeZ4Q/wCgxrv/AIKYf/kmjzPCH/QY13/wUw//ACTXG0Uexq/8/ZfdH/5EPaQ/kX4/5nZeZ4Q/6DGu/wDgph/+SaPM8If9BjXf/BTD/wDJNcbRR7Gr/wA/ZfdH/wCRD2kP5F+P+Z1s2v6Vo6ltB+3Tah/BqF2iQm3/AOucSs/7wY4kL8bjhQyq45KiitKdJQu73b3b3/ryWhEpuWmyNTS9XWzja2u4WubBm3+Usmx0fH3kYg7ScAHgggDIyFK6nn+Hf+ghqv8A4L4//j9cvRTlTjLVnJUwsZS5k2vS36pnUef4d/6CGq/+C+P/AOP0ef4d/wCghqv/AIL4/wD4/XL0UvZRI+p/33+H+R1Hn+Hf+ghqv/gvj/8Aj9Hn+Hf+ghqv/gvj/wDj9cvRR7KIfU/77/D/ACOo8/w7/wBBDVf/AAXx/wDx+jz/AA7/ANBDVf8AwXx//H65eij2UQ+p/wB9/h/kdR5/h3/oIar/AOC+P/4/R5/h3/oIar/4L4//AI/XL0UeyiH1P++/w/yOo8/w7/0ENV/8F8f/AMfqhqWsQtA9npscsVq+POklYGS4weM44VcgNsBPPVmwuMaimqcU7lQwsYtSk27d7fol+IUUUVZ1Hf8A7QH/ACVzxF/27/8ApPFRR+0B/wAlc8Rf9u//AKTxUV5GS/8AItw3+CH/AKSjtzD/AHur/il+bJPgGF/4W/oHJzm57f8ATvLXnleg/AP/AJLBoH1uf/SeWvPqqh/yMq3+Cn/6VVFU/wB0p/4pflAKKK6j4d+DpvHXi7T9HQSC3kfzLqVM/uoV5ds4IBx8oJGNzKD1r0K9eGHpSrVHaMU2/RHNSpyqzVOC1eh6f4FttP8AhT4A/wCE51G2gl8U6nuTR7a5LArGcKXC4yMgli2cFCgDLvOfHt019cy3V1I80srF3kkYs0jE5JJPJJPU12/xe8WReK/FzWunGNND0lfsNjHDgRBV4Z1AJXBI4K4yipxxXHqoRQo6CvOyXCz5JY3EfxKurv8AZj9mK9Fv5tnXmFaPMsPS+GGnq+r+f5WEkcRoWP8A+us13aRizHmp7x8uEB4HX61Wr1Kkruxy042VwooorM0CiiigAooooAKKKKAFVipBBwRWjDKJUzxu7is2prV9koGeG4rSnKzsZzjdE1zD/Go+te0AWnxp+HE3mRo3j3w3b4iKu7TXtumOWGCXLZYYGSJMHKiTB8hIyMHpWv4D8VzeAvF9hqyGRreNtlxGmcywNw4xkAkDkAnG5VJ6V5+c4Kdekq1DSrT96Pr1i/KS0Z0YDERpzdOr8EtH/n6rc4qivRPjL4Oh8K+LnuNOCNoWsL9usZIcGLa3LIpUBcAnIC5wjJzzXnddODxUMXQhiKe0lf8A4HqtmYV6MqFSVKe6Ciivdv2eP2cP+F92/iGX/hJv7F/sd4Fx9h+0+b5gc/8APRNuNnvnNdLaSuzI8Jor2rwB+ztqHi34y6x8NNV1X+xr7S0md7kWvnhwhXaQm9flZWDA56EV5f4w0D/hFPFuvaB9o+0/2Tfz2Xn7Nnm+VIybtuTjO3OMnGeppXT0AxaKKKYBRRXsfxj+BH/CpfCvgjXf7f8A7T/4Si3Nx5H2Pyfs2I43xu8xt/8ArcZwOnvRdbAeOUUUUAFFex6H8CP7Z+AuufFP+3/K/sq4Nv8A2Z9j3eb88a583zBj/W5xtPT3rxyhO4BRRXveg/s32a/DPS/Hvjfx3ZeFdI1iQR2KmwlvHkLbiu4IRtyEY8Z4646UNpAeCUVseKtFt/Duv3um2mr2WsWsDL5d/ZEmGdSoYEZAIPOCD0II7Vl28Et1PFBCjSTSsERFGSzE4AH40AR0V9H63+zH4c8BnTLD4gfFjTPDviLUIVnXTk0yW7WNSSAWlVgFGQRkgDIOCcZrxn4jeD4vAXjHUNAg1i01m3tVhePULM5huEkiSVWXk8YcDqelJST2Cxy1FFFMAooooAKKKKACiiigAooooAKKKKACiiigD0H4/hf+FueIsk5/0ft/07x0U39oD/krniL/ALd//SeKivIyX/kW4b/BD/0lHbmH+91f8UvzY74B/wDJYNA+tz/6Ty159XoPwD/5LBoH1uf/AEnlrz6qof8AIyrf4Kf/AKVVFU/3Sn/il+UAr3b4PSR+EPhj438aI3+njFhbMkCs8D4XawLHlS80ZIx/yzB+bgV4TXuHxDH9gfBX4d6F/r/t27UvP+7sypfZt5z/AMfOM5/g6c8c2er26oYL/n7NJr+7G85flb59djbLX7N1MR/JF29X7q/M8itEyWcjpwKt1HAu2JenPNSV9ItjymQSQRvJlmIZu1J9jj9W/Oo71vmRe4Ga6r4W6p4dsPH3h648YrK/hyC7SS68uJZeByu9CDvj3Bd4AJKbgATisZSim7o1jGTSsz6F+CP7IOl+OPBcHiTxbqOrWf8AaX7yytbLbE6wgkB5DJG2d/DLtGNuDk7sL6V/wwx8O/8AoM+Kf/Aq3/8AjFfR2j6tZ6/pFhq2nTedp+oQR3NvLtK743UMrYYAjIIOCAau14k8RUcm72PWjQgkla58yf8ADDHw7/6DPin/AMCrf/4xR/wwx8O/+gz4p/8AAq3/APjFfTdFT7ep3K9jDsfMn/DDHw7/AOgz4p/8Crf/AOMUf8MMfDv/AKDPin/wKt//AIxX03RR7ep3D2MOx418Pf2XPh14B/tHOm/2/wDbfL/5GCC3u/I2bv8AV/uht3bufXavpXYXfwq+GtlaT3MvgDw00cEbSMIdChlcgDJ2osZZjxwFBJ6AE12y4DDPSpNye35V00q0nHWS+Zy1qUVLRP5H5lftH6p4A8SeONPu/h7DYw6KmmxxSrYWBs4zOJZSxKFFydpT5sdMDPFePrbRrIuGbcOcV9Q/tO/Eb4R+MPCNufAh0uTxNLqy3N3cW+kPbTyRGOXezStEu7LshIJJJ57Zr5YtG/fc5JYGvTi46KxwtSs3cvVXu0ygbHI/lVimuu9GXjkd63Zkj1zWZI/Gn7Otnfzt/p/ha6W2MrwLl0yqCNWB4XZLFk9zFyDw1eD17l+z+P7YHjTwr/qv7Z0tv9K+95OMx/c43f6/PUfdx348Nr5vKF9XxGKwa2jLmXpNXt8pKX+SVj1ce/a0qNfq1Z+sdPysFfaH7El1NZfD74xXNvI0VxBaQyRyKcFGENyQR7givi+vTPhj8cfEPwn0PxPpGi2el3Ft4jiWG6a9ikd0AV1+Qq6gHEjdQegr3JK6seaj7t+Dq2Pxa8QeEPjNYCGPVG0qfRdegTAxcLsKtj8D77Xj9K8w/Z58K6PqHxt+Onie9sIdQ1Xw9qVy1hBKobazz3BZlB/i/dKoPbcfWvmz4N/tCeLfggmqxeH4tOurXUijS2+oxySRq65AdQjqQSDg88gD0FbHwY+JWuQfF/WfEtv4s0bwtqGtG4uZm1KJ20+4kklDmF8ElFyxIbORtxnmocGrjufS/wCy58UNc+KukfFTVPEVtYvqUNtEov7a0SBpI2SciJtoG4JglSct85yTxXnXwLsPHngn4LjxbN8VbPwL4Furx5IVbRY9RllkLeUW2ldwyY8AAnhScDrXoUfxl0P4YeCvGd5rfivwNqWt6zCUsND8Dxj7KspVwZHYclnLqWZzwIxjJOK+WvBH7RvizwT4Jk8GCx0HW/DpcvFZ63Y/aUgJbcdo3AH5iWwwYAmhJu9h3Pev2v8AQ9F1X4OeAfHME9rqWsXdxFbvrUFgbI6hFJBI+9ojyMmMEA9Nxxwa99f4e+HPG3hv4VX2tQR6nf6BohvNO0SSRUW+l8iDlt3UKQvB4y4J4GD8CfEX9ojxb8UfA+k+E9fg0o2emXC3UdzbwPHPI6o6AN85QLiQ8KqgYGMAYqXxN+0n418SJ4HKmw0u58GLt06606ORJD8iIfM3uwbKxgEYAOWBGDijkdkhXPTPCeu/GH43/tFTT2uqL4a8RaHFcYjuYBJFpMGRG6LE6kM53gEkZJOcgAY+jPAK6d8VrLxt4S8UfEWw+IxtIfJnT/hHBYnT5DvXckoG1zlTgryCmQa+PNQ/at8Z3fjyy8b2mmeHtM8RQW5tLieytZVF/AcHy51aRgwBUYI2sMDngY1NI/bJ8caFq2pX+naF4RtI9RXM1pbaa0MLSE5aY7JAzyHoWdm9sZORxbBM91/Zn8K6R43/AGV9U8P69fGx0nUNa8qeYOFOPNtyEBPALMAgPq3evI/2ufF/iPRNYg+Gdtox8N+BNJjU2Fnbn5NQQdJmYfeGc/L2bJbLdPKdJ+N/iHRvhJqvwzt7TTDoWpT+fLcPHJ9pVt6N8rBwoGY16qepq94u/aE8TePfAGn+EPE2n6NqqacALbV7iGX+0IiO/mCQKSVAU5U7gATkjNNRd7hfQ858O6Qdf8QaTpImWA6hdxWvmt0Te4XcfYZzX6K+I7n4daHfaX+zfr+n3UGhXmlRtp+q3U+5vtTSPtwxHytuBKt93cdm3GBX5sKzIwZSVZTkEHBBr3u3/a58btY6bDrGkeFfEF9pgH2TU9Y0vz7uEjoyuGADcD5sZOMkk05xbBM6z4wfAXwx8Dvgq411La+8f6lqzxafew3EqkWqsDu8rds+4vOQcGUDPAr5h0y4urTUrO4sgxvIpkeEKu47wwK4Hc5xxXrPxF/aT8U/FbwpDoPivSvD9/JbyGWDUxavHdwMTk7WWQIBj5SNhBAGckA15HZXkun3lvdwMFnt5FljJGcMpyOPqKcU7aiZ9sL8ZPg3+0JrGi6T8S/Bmoab4wkKacl5CzhEkL4Cb0YOBvY4V0YLuPPU0/wD+zV4U8JftTTeG71/7X0Sz0Q65Y2t8FcljKsQSQYAfad7dOflyOtePj9r3xXJqMWrXfhLwJea9Dgx6tcaNm7Rh0YSBxg155cfGrxvcfEUfEA65KvidW+W4RFCKmNvlhMbdmONuMHvzzU8r2Q7n2he/F74ZHWPFGg/EP4k6Zrvh6RpbWPw+3g+4tv7MdXxhJlViSoBGeuQCCMYPG/skT6dpPw2+OE8EaanpNpG7ok6kLdQrDOQGHBAZRyODzXjl/8AtY+Kb66fUV8K+BbfXnwW1mPRFa8LD+Iu7MM/hXIfD344eIfht4X8WeHdKs9LnsvE8LQ3cl3FI0iAxuhMZV1AOHPUHnFHI7WC57l+zF8VfE/xM+Pnh1fEV5byQaZp97HY29taQ28dujICUURqMj5R1zjFdV+zpBKf2x/i3JsbYn9qBmxwM38WPzwfyr458D+NdY+HfinT/Emg3Ag1OxYtGzLuVgQVZWHdSCQfrXtFl+2Z4707xPc6/Z6L4St7i7hMd1DBpzRpdPlcSyssgkd1C4GXIAZuOaJRfQEzxbx3/wAjx4m/7CVz/wCjWrn6uatqUus6rfalOqLPezvcSLGCFDOxYgZJOMn1qnWggooooAKKKKACiiigAooooA7/APaA/wCSueIv+3f/ANJ4qKP2gP8AkrniL/t3/wDSeKivIyX/AJFuG/wQ/wDSUduYf73V/wAUvzZJ8A3Y/F/QBuOM3PGf+neWvPK9B+Af/JYNA+tz/wCk8tefVVD/AJGVb/BT/wDSqoqn+6U/8UvygFe5ftHD+zte8O6Dbfu9K03S0+zQdfLy7IfmPzH5YkHJP3fc58Nr3L9pv/kfdO/7Bcf/AKNlrDG65rhE+1R/O0Vf7m/vZrh/9yrvzh+bPKlG1QB0AxVS9b5lX0GauVQu2zMR6DFe/V+E86n8RBRRRXMdB+n0niy4+E37Nmk63dWMq6jo/h6yiFrPEQUuTFHEiyISpAEjLuGQQA2OeK8v8Jfs/wCpfHDw1pfi/wCKXjHXrq91KBbmzsbRoYorSNxwwGHT95GsL4VUIOd2T0+pr3UbXTow91OkSnoD1P0HU9arWviHTLyYRQ3aGQ9AwK57YGQMn2rx1UaT5Vr3PXWGnNc3K3FeWh80adeeK/2dvit4O8HXfiG/1/4feJZDaWS3kaPNaSFlijiRt+4CPNvk/KhWR9se4cfVVFFTOfNZ21IjHl0Cvmj4k+KPGfxI+NT/AAp8Ia9deHNM0+xFzq2pW0S+eGKpIrK3mK+zLwJhCjZkk3blFfS9FEJcrvYJR5lY+Yrz9k0eBrSfW/hn4u8R6f4ptI2khSaWF0vAo3rbsAsYw8ix53lk45U9vRf2dPidefFX4aWuq6nzrFlO9heyrEI0mkQKwdQCeqOhPCjduwAMV6Re65p+nSCO4ukST+6AWI+oGcde9PsdWstS3fZbhJGXqvIbtzg84561UqjlG0tfMtYacVzqLUfTQ/HS8s7jTru4s7y3lt7u3kaKaCZCjxupwysp5BBBBB6VDXafGD/krXj3/sPX/wD6UPXF166d1c8hqzsT2jYmA9Rir9ZsDbZkPvitKumk9DCqtTvPgFe3Fj8UtOggk2xXcc8EwwDvQRs4HPT5o1PHp6ZrgPGVhb6V4v8AEFhZx+VaWl/cQQx7i21FkYKMnk4AHWu3+Bv/ACVrQ/rcf+iJK5H4h/8AI/8Air/sK3X/AKOavBh7ud1EutKLfm+aSv8AcehLXL4N9Jv8onN0UVtweFr248LXHiKN4DZ29x9nkj3HzRwvz4xjbl0Gc5yw4r3TzTEoro9V8Eavpc+k23k/a7vU7YXUVvaK0kigkgqy4+8CpyBnFZMej6jNqB06Owun1AEqbVYWMuR1GzGc/hQBSorQg0HVbq8ns4NMvZbyAEywJA7SRgddygZH41evfDEtv4rj8PwzpJPJNFAksilF3PtxkDJABb3oAwaK6dPCVu+t6bpUfiDT7ma8vI7NxaxTlodzBSxEkaAgE9Af8ax00XUJ5I1trK6nE0rQxGOFm8116quByQCDgetAXKFFakXhnW57qa1i0fUJLqBgkkKWzl0YgkArjIJAJ59DUdnoOq6hNLDaaZe3E0LiORIYGdkbn5SAOD8rcf7J9KAM+irraPqK6cuotYXQ09m2i6MLeUT6b8Yz+NWf+Ea1SKeGG7sbqzM8TzRm4tpB5iohYkAKSRgdQMDqSBkgAyaKK0dK0a51hb82xTNlbm5dWzllDKuFwDk5cUgM6iupi8DXX224tLnUdPtJrS0N3dCZpG+zAMq7H2Ix3/MPlGcdDggio9N8J2+q6tHptt4l0hppnjigcpdBZnc4Cj9zkEHGSwA+YYJ5w7Bc5qiuss/AVzql5e22mapp181nbtPK8XnIu4HAiHmRqS7HoAMH1rOsPC15qMejyQyQbNUuntIyWOInXZnfxwMSKcjPGaAuYlFbt14S1C0XUy5iLaffJp7KpJMsrb8bOOR+7Jzx1HrUfifw1eeE9WfTr14JJVUOJbdy0bg+hIGcEFT7g0BcxqKKKQwooooAKKKKACiiigAooooAKKKKAPQfj+7D4ueIgGIH+j9/+neOim/tAf8AJXPEX/bv/wCk8VFeRkv/ACLcN/gh/wCko7cw/wB7q/4pfmx3wD/5LBoH1uf/AEnlrz6vQ/gGF/4W/oHJzm57f9O8teeVVD/kZVv8FP8A9Kqiqf7pT/xS/KAV7j8ej/a+neA/E8/y3+r6WPPjTiJcBJBtByRzM3UngD3z4dXt96f+Er/Z1067Hz3fhm/ME01zy/lscBI25O3E0AwcD93/ALK5wzX91i8Jieim4v8A7fi0v/JkvwNcF79GvS7xv/4C7/lc8sQkopPUgVnztumcn1xVu1bMWO6mqLNuYsepOa92q9EcFNasSiiun+G+rWegfETwjq2ozeTp+n6taXNxLtLbI0mRmbCgk4AJwATXO3ZGy3P038Y6fdrqMl2yO9qyqFcZITAAwfTnn8frXP2tpPezCK3ieWQ9lHTtk+g56161Z3lvqNpb3lncRXFpcRrLDPC4dJEYZVlYcEEEEEdamrxeax9ZRzaVOkoct7ENnHJDaW8cz75UjVXbOdzAcnJqavNPjpoGva74HB8O6nrNjeWF3HdSro0zRXNxCAySIrKcnAfzNoDFjEFAywI+Z4bHXLiGOaH4l+OpIpFDo6a65VlPIII6ij3bXbOXDYKti3J0ktPOx9x0V8P/ANl+IP8Aoo/jz/wdyf4V7t+zromvWmk6zrGreINe1XT9TkhGnDWLtrgmJFYmeMseEkaTAGBkRBwWV1we61ox4rL6+FipVUlfzNHU9Pu7C6dbtH3sxPmHJEnqQe/X9eau+GtPu7nU7aaBHWKKQM8vIUAYyM+pBxj39K9Moo5jqlm8pU+Tl1/rofkr8YP+StePf+w9f/8ApQ9cXXqn7SPiLS/Ffxr8V6rot7FfabLJBHHcwnKSGOCONip/iG5GAYcHGQSCDXldezD4UfJz+Jiq21gw6g5rVrJrQkk/0fccZZf510UnuYVVsenfs56bFqPxH+0ys4ksLOa5jCkAMxKxkNx0xKx4xyB9K8m1nVJtc1jUNUuFjW4vriS5kWMEKGdixABJOMn1NeyfC0/8Iz8L/iB4rb5ZXiGnWs1vxcQyEYyG42rumhOQc/JnGQM+HV4eB/fZliq+6jyQXyTlJffJHfif3eEo0+/NL73ZfkFdt4e8WWWh+HrW2ngF9m9uGubFiUEsLxRqPnwQPmTI68qOK4mivdPNselN4vsdX05be81L7Nf32mzQT3ZjcrDK1885VtoJ2shAJUHG4D1FQy+ItLubrULH+0mjWfSINOXVXifDvGyMSwAL7GCFOmcBcjqK87oouKx6VqHiHSdV0+40lNaNrJEtl/xMpIpcXfkI6sCFBcYLjbkdEGdvGMzU/EGn3PxSh1tLt5NNXUIJ2uHRgxRSm5iuM54PFcRRRcdj0a41u0j8VaJqU2t6Dc2dvqkVw407TGt5Y4xIGLORbxlgAOmWOe1RXHiWxvtYstTt9QisVMElnJYzwSNBAhQqduwZEbhiTj5wxJ5+8fPqKLhY9SU6Rc+HfEsNlrP2O0eTTo2nInaDzAs5KLkGTy+MjIJyB25rJ1/xVZ31n4ojtbuXdfz2CqWVla5SGKRXkb03NtbBOct7GuIW5mSCS3WWRYJWV3jDEKzLnaSOhI3HHpk+tRUXFY9PvfGOlTaZ59qdOhuJNOisHiaK7e5XaiqcDzBBt3LuB4P+znJLZPEGiLqCahNqUMt/cC9ad7SOdYmMls6qXSQcSF2A+T5QDXmVFFwsauh3f2Q6j/xMPsXm2csX+p8zz84/df7O7+92xWz8P/FK+Eb7VNQWREujYsluHQsryebG2046cK3PGPUHFcjRQOx6Loep6Bp2qapd2Op29pHqmnSIkOpWz3C2sxkjJjf924kXCsQ2DxjIBrJttSt7Lx3oWo3Wo6bcW1vdW80txptmYIkVZAT+7EUZyAM8Lz6muQoouFj0LSfFmieH9MjZYry71CbVP7Qc2twLfyhET5KsWifcCWdsDHUd+lmHxH4esIfFMVrcsIvNa80hBE3DywvG8Z44KCRTk4BMXGcivNKKLisesQeMvD0T+HrySZ5ZbRW1K7gCMpkvEhjiiQMVI5aMybsEDefpXLeJNa0bWvDumJaR3dvf6fLJD5d3OLh5YXJk3b1jQDa5fgjPz9+3IUUXHYKKKKQwooooAKKKKACiiigAooooAKKKKAO//aA/5K54i/7d/wD0niop3x/C/wDC3PEWSc/6P2/6d46K8jJf+Rbhv8EP/SUduYf73V/xS/Nh8A/+SwaB9bn/ANJ5a8+r0H4B/wDJYNA+tz/6Ty159VUP+RlW/wAFP/0qqKp/ulP/ABS/KAV7Z+z3rVvdz6/4I1CadbTxDausRRz8jhGDhVwQGaMk7j/zyA54rxOrOnX9xpWoWl/ZyeVd2kqTwybQ211IKnB4OCB1rbNMCsfhJ4e9m9n2a1T+TSIweJeGrRq7pb+aejX3F66tLnR9QvbC7Tyrq2keGVNwOyRCQRkZBwQRxxVCvZfjFpKeKdL0f4kaRbP9h1W3VNQVdzC3nXCfMTg4yPLyFC5jB6uM+NVGAx313DxqtWltJfyyWkl8n+FmaYjDfV6rgtVun3T2f3BRUtvD5zkFtqKpZmxnAHtT/Ls/+f3/AMhGuwxbSPqD9mT9puz8Aaeng7xi/leHIvMksdQihLtaMxLtHIqAs6MxYhgCys2DlSCn3hZ3lvqNpb3lncRXFpcRrLDPC4dJEYZVlYcEEEEEda/G/wAuz/5/f/IRr074afHrxb8KtkGjeIvtGkrn/iV6hC81qM7z8q5DR/M5Y+Wy7jjdnpXJWwvO+aO50UsSo6S2P1IrzfxJ8EfDXiC9ub+3l1LR9QupTNPPp1xhZCc7v3MoeJSzfMWVAxbJJ+ZsxfCH4uv8W9CstWs/DF7b2s8ksU1zHeWs0Fu6Z+Vv3izAkbTgxA/OD90hj6gYnBxtP5VwypzjujupYhJ81OVn5OzPKNK+AHhe0l8zU7rV9dCsrJFqFwqRLjqrRwJGsqtwCsocYGMAFs+qU7y3P8J/KuK+JPj6X4caFqWsT+H7280+xtDcPdrdWsNur8hY2MkofJbaPlRyd4Chm+WhU5y0SHVxHM+apO783c7Ovjb9pP8Aan0u70S+8G+BbuK/a/jltdS1QJmKOI5R4otww5YZzIMqFI2kltyeNfFL9prxb8TftNl/bP8AYugS7k/s7TkdPMjO8bZZfvSZR9rDhG2g7Aa8X8uz/wCf3/yEa7aOE5XzTOGrik9IleirHl2f/P7/AOQjTZ4FjWN45PMikBw2MdDzxXYc10yGpnkLRRrnoKhr1T4JeFEv9ck8UaojxeHvDqNeS3BRipljG5VG05JX/WHAb7oBHzCufGY2GBoTxFTZLbu+iXm3ojWjh5YipGlHr+C6v5G18W7v/hC/hr4S8Aq08d+8S31+hl+5ksTGdo2uplZyOTjyl65Brwmtvxf4luPGHibU9cul2S3spcR5B8tAMImQBnaoVc45xk81iVllGClg8Mo1Pjk3KX+KTu/u2XkhY7EKvWbh8Ksl6LRf5hRRVi2tvN/eSZEQOMjqx9B/j2/IH1DjK9FaWLccC1jIHdmbJ+uCKX9x/wA+kX/fT/8AxVPlFzGZRWn+4/59Iv8Avp//AIqj9x/z6Rf99P8A/FUcocxmUVp/uP8An0i/76f/AOKo/cf8+kX/AH0//wAVRyhzGZRWn+4/59Iv++n/APiqP3H/AD6Rf99P/wDFUcocxmUVp/uP+fSL/vp//iqP3H/PpF/30/8A8VRyhzGZRWn+4/59Iv8Avp//AIqj9x/z6Rf99P8A/FUcocxmUVp/uP8An0i/76f/AOKo/cf8+kX/AH0//wAVRyhzGZRWn+4/59Iv++n/APiqP3H/AD6Rf99P/wDFUcocxmUVp/uP+fSL/vp//iqP3H/PpF/30/8A8VRyhzGZRWn+4/59Iv8Avp//AIqj9x/z6Rf99P8A/FUcocxmUVp/uP8An0i/76f/AOKo/cf8+kX/AH0//wAVRyhzGZRWn+4/59Iv++n/APiqP3H/AD6Rf99P/wDFUcocxmUVp/uP+fSL/vp//iqP3H/PpF/30/8A8VRyhzGZRWn+4/59Iv8Avp//AIqq1xbKqmSHcYx95WOSv+I9/wAPTI0FyrRRRUlHf/tAf8lc8Rf9u/8A6TxUUftAf8lc8Rf9u/8A6TxUV5GS/wDItw3+CH/pKO3MP97q/wCKX5sd8A/+SwaB9bn/ANJ5a8+r0P4Bux+L+gDccZueM/8ATvLXnlVQ/wCRlW/wU/8A0qqKp/ulP/FL8oBRRRXqnGb1p4s1S38LXXhmOfbpNzdLeOg4JcLtwSOqnCEg55RSMc5yaji71PDEZpUjGcsccDOK51ShCUuRWu7vzfc3U5SiuZ3sSTN9nsNh+/cEHHoo6H8TWdVq/mE1y23Hlx/ImDnge9VabMwooopAfRP7I3xq/wCFa+Ol0TWtU+zeENcyk32iXbBaXOB5c5+U7c7RGxyowwZjiMY/S+vxHr9KP2Q/jjJ8TPCMnh3W7qafxVoEa+ZcXMyNJfW5YhJAOGJT5UckHkoxYs5AGNH0hXwP+218av7a1iD4faBqm/TNPy+sfZpcpNchvlgf5efK27iAxG58EBouPpj9pD4yRfBz4fT3lu27xDqm+z0uNXj3RylDm4KvnckfBPysCzIpwGyPyuvb251K8uLy8uJrm8uZGlmnmcvJK7HLMzHkkkkknkk0IGQUUUUCCtCybz7aW2/jB81Pcgcj8qz6ltp2tp45V6qc49R3FNAS1r2/izVLDwzqXh2CfGl6lLHLPG3PKHI254XJ2kkDJ8tRnAIOfdxCGdlTmM/Mp7EGqsv3R9aUqUKllUV7NP5p3T+TNeeUU3F2/wCDuRUUUV0HOFaQ4tLUDgFCx9zuYZ/ID8qza0/+XW0/65n/ANDaqiTIZRVrTNOuNX1Kz0+zjMl3eTJBEg/idiFUfmRXtvxF+HljbyaFNc6Tc+HdF0/UhoF1fSWLQ/aYVClLzkDez4mJbnovtTuSeEUV6VceEbG2t/EE9ra3dtapozXMJnuLa+SRluoYyUnRNuMOc7QrKeCcEg6nhfwh4b/t3wdcW9td6tZyX9gl5OLuCSBmlK7o5INheIByV+fcHCkDGQQXA8hor1HR/BmgeIf7e1iKC4ttLsbqK0jsbjW7S2keRxIxb7RMiIFAjOECFjnrgE1O/gLwjpZtxeX2oait5rcmlwTabdQeWIhHA4kLBXVmUz4KqcEjhlxyXA8norWk8P3TeJ38P2o8+9N6bGMAY8x9+wfma9x8T/D6G08Q+DJx4Yk0/TtP16DQJ/tNiYk1GJWQpcMGUCTzMTbjzwFHpRcD54or0T4fWNpcfFY208NkbVGvyEuoBLAmyCYqWjKsCFIBxtPToa19WXQdd0jUWtZ9NutX03RpZ7y80vTVtraZjdwLGFjeJNrBXbLoiE5AyRuyXA8kor1Dxb4L8L6RN4pg03+2Hfw1fRwztc3EWLqJpCjBcR/u2BAAY7geTtHSrnijw5oWo/FHxJY6b4cvhp9hLP8AaI49XtrOGIiQKHEjwCOKPkKEOeSMN2JcDyOivVNW+H/h7wzF4hvNTfUbq2sjprWkNndwZkW6hkkKtMquh27MB0BDYOB8wIwPhlY2UmsX2p6qkB0rSrOSed54fOWJnxDC/ldJNsssZKnggHPpRcDiqK7Dxv4X1TSimrajHpsEd9MY7cWChIrlVRCZ4lUbfLbevIwNxI2jBA7zSPCWj+KPAXhK0e3tbO8t45dUvL5I1WWWzW6ljuNzdXKKI2UHoA1FwPE6K9Z+J2i6Vew6n4isrGLTSsWiGKys0WOBBdWUksnygdd0a857nOc8b3hTw3peja7qWhzwS3mmL4l0KJop2UmQOJ+GypBXLcjHIyOM5ouB4RRXoLaHpus6V4ll0a3eyWLUbK3hi1C6t2ALi43EztHGEXKDgFR/e3YBGt4H0tNH8P8AjNru78NWt/Zz2MaX2oW0Wp26B/OLKhSKdSWwvKj+HBIxRcDyiivarDTdA/sO/wBS1iyTVDcaDcXYfTkgskVl1Tyt0X+j5XIxgsuVUsuACAvK6b4J03UdQ8GxCS8SHXbG5u5h5ilozHNcooU7em2BM5HUnpkAFxnn9Fdf4z0bQvD9vpNrYrqMmp3NhZ31xNPMnkp50CyNGqBMnlgQxbgcYP3q5CgQUUUUwCpIefNB5BifI9cKSP1AP4VHUsHWT/rlJ/6AaEBlUUUVmaHf/tAf8lc8Rf8Abv8A+k8VFO+P7sPi54iAYgf6P3/6d46K8jJf+Rbhv8EP/SUduYf73V/xS/Nh8A/+SwaB9bn/ANJ5a8+r0H4B/wDJYNA+tz/6Ty159VUP+RlW/wAFP/0qqKp/ulP/ABS/KAUUUV6pxksX3T9auQt9ntprg9ceWnruPfPbAqism0YxWldWyzRW8aXVsFiU53Sc7j1/Cs2ne5pzK1jIoq9/Zv8A092n/fz/AOtR/Zv/AE92n/fz/wCtU8rJuUaKvf2b/wBPdp/38/8ArVt2Hw78SaraR3lhpV3d2kudk9vbySI2CQcMFwcEEfhWdScaS5qjSXnoXCEpu0Vc5auw+F/xF1b4V+NdM8S6TNMGtpFFzbxybBeW5YGSBiQRhgOpB2kBhyoId/wqrxf/ANADUv8AwDm/+IrnP7Lb/n5tf+/n/wBalTq06t/ZyTt2dwnTlD4lY9D+PnxkvfjR46uNW3XcOg237nS7C4dT9niwAzELwHcrub7xHC7mCLXltX/7Lb/n5tf+/n/1q3rf4ZeKru3iuLfRb+aCZQ8ckdrKyupGQQQuCCOc0VKkKSvUkl6uwQhKfwq5yVFdbcfDPxTZ28txcaLfw28KGSSWS1lVUUDJYkrgADnNYH9m/wDT3af9/P8A61FOpCqr05J+juE4ShpJWKNFXv7N/wCnu0/7+f8A1qP7N/6e7T/v5/8AWrXlZFyRW+0WCN/Hbna2epU9Of0xVV/uGr9larbysXurYxuhRtsnOD6VnyNtZ04OCRlTkGqSZXMrWIqKKK0MwrT/AOXW0/65n/0NqzKv20oniSA/61MhP9oHnb9c5Pvn6A1Ell/RtYvfD+p2+padN5F9bktFLtVihIIyAQRnng9jyOasaP4m1XQIrqLTrswR3ZjMq7FYMUbcp+YHBB9OxIPBIOUylSVYEEcEHtSVRJ0d/wCOte1FJopruJIJrY2bQW9rDDEIjIshCoihVJdFJIAJxyaVvH3iA2lvarfLEkEkUokht4o5XaM5jLyKoeTaeRuJxXN0UgOmTx/rsV/eXqS2SveqouIRp1t9nm28qzQ+X5ZYEk7tueTzzVO48W6xdeR5t4W+z3jX8f7tPlmYICw46YiQbeg28DrWLRQBq2fiTU9P17+3ba58vVvNecXHlqSJGzlgCMA8kjjg8jGBT9D8U6t4b83+zLvyBLJDK4MaOC8UgkjbDA4IYZ+hIPBIOPRQBo2GvahpmqvqlrceXfuJQZdinPmKyvwRjlXYdOM8VFY6rd6bFfRWs3lx38H2a4G0HfHvV9vI4+ZFORg8fWqdFAGxe+KtX1GXWZbm78x9akEt6fLQecwfeDwPl+bn5cVpH4jeImvpL17m0e4mg+zzs+n27C5TcG/eqY8StlVO5wzZA5rlaKAN/WPG2u6/Hdx6jfeel2bcyjykXd5CMkX3VGNquw4655zgVT0PxBqPhu8e6024EMskbQyBo1kSWM9UdHBVlOBwwI4FZlFAG9rvjPWvEtpb2mp3Uc1tauXgiS3ijWDIAKoEUbEOAdi4XPOM81nXerXl9ZafZXE2+209Hjt02geWrOXYZAycsxPOetUqKAOltvH/AIgtJZJEvIn8y2gtGSa1hljMcCBIvkdCu5FAAbG7qc5JqO48deIbq8vbyXUpGu726gvZpgihmmh3eW+QOCNzdMZzzmueooA29T8W6rq0d/HcSWyxX8kUtxHb2kMCyPGHCNiNFAP7x8kdc854qjb6veWumXumRTbbK9eOSePaDvaPdsOcZGN7dDznmqVFAG/p3jXW9KFotvdRGO0tns44praKWMwvIZGRkdSrguxb5gecegq1pfxG8SaNapbWN9FFHGZPKP2SFniEmd6oxQsiNk5VSF5PFctRQBc1LVbvV5oZr2bzZIYIrZDtC4jjQIi8AdFUDPU45zVOiimAUUUUAFSwdZP+uUn/AKAaip0z/ZEdWBE7qVCnqgPUn6jIx759MgzNooorMs7/APaA/wCSueIv+3f/ANJ4qKP2gP8AkrniL/t3/wDSeKivIyX/AJFuG/wQ/wDSUduYf73V/wAUvzZJ8Awv/C39A5Oc3Pb/AKd5a88r0H4B/wDJYNA+tz/6Ty159VUP+RlW/wAFP/0qqKp/ulP/ABS/KAUUUV6pxhRRRQAUUUUAFWbDUbzSruO8sLue0u4s7J7eQxuuQQcMORkEj8arUUpRUk4yV0wTad0d/YfG3x9ptpHaw+I53ijzhriKKZzkk8u6lj17njp0rrf+GofF/wD0DdC/78Tf/Ha8Torya2QZZWfNPDxv6Jffa1/md1PM8XTVo1X99/zPbP8AhqHxf/0DdC/78Tf/AB2ub1H48+PtQ+1r/bf2eG43jy7e3iTy1bPCPt3jAPB3bh1znmvN6KVLh/K6TvHDx+aT/O4TzTGTVnVf32/Iu6prOpa5cLcapqF3fXCoI1lupmlYKCTtBYk4ySce5qlRRXrxhGC5YqyOJycndsKKKKYgooooAKKKKACiiigCwt9dIoVbmYKBgAOcAUv9oXf/AD9T/wDfw1Wop3YrFn+0Lv8A5+p/+/ho/tC7/wCfqf8A7+Gq1FF2Fiz/AGhd/wDP1P8A9/DR/aF3/wA/U/8A38NVqKLsLFn+0Lv/AJ+p/wDv4aP7Qu/+fqf/AL+Gq1FF2Fiz/aF3/wA/U/8A38NH9oXf/P1P/wB/DVaii7CxZ/tC7/5+p/8Av4aP7Qu/+fqf/v4arUUXYWLP9oXf/P1P/wB/DR/aF3/z9T/9/DVaii7CxZ/tC7/5+p/+/ho/tC7/AOfqf/v4arUUXYWLP9oXf/P1P/38NH9oXf8Az9T/APfw1WoouwsWf7Qu/wDn6n/7+Gj+0Lv/AJ+p/wDv4arUUXYWLP8AaF3/AM/U/wD38NH9oXf/AD9T/wDfw1WoouwsWf7Qu/8An6n/AO/ho/tC7/5+p/8Av4arUUXYWLP9oXf/AD9T/wDfw0f2hd/8/U//AH8NVqKLsLFn+0Lv/n6n/wC/hqtRRRcAooopDPQfj+F/4W54iyTn/R+3/TvHRTf2gP8AkrniL/t3/wDSeKivIyX/AJFuG/wQ/wDSUduYf73V/wAUvzZgfDnxKnhDx/omsStGlvb3O2d5FZgkTgpI2F5JCMxGM8gcHpSeOPDjeEfF2saKyyBLO4ZYvMZWZoj80bErxkoVPbr0HSuWk/1j/U16PpXinQPFegaX4d8WNJp1zpqNHZ+Io1adkizuEEsXV0GWClT8vyAADcTWIUsPiFioxck1yyS1dk21JLd2u00rt3utrNUmqtL2MnZp3V9tdGvK+mr001304KivRx8EPFN7+80J9J1+0HytdaVqMTxI/dCWKncAQenRhzS/8KE+If8A0L//AJOW/wD8cqv7by7riIL1kk/ubuL+z8V0pSfomzzeivSP+FCfEP8A6F//AMnLf/45R/woT4h/9C//AOTlv/8AHKP7by3/AKCYf+Bx/wAw/s/F/wDPqX/gL/yPN6K9I/4UJ8Q/+hf/APJy3/8AjlH/AAoT4h/9C/8A+Tlv/wDHKP7by3/oJh/4HH/MP7Pxf/PqX/gL/wAjzeivSP8AhQnxD/6F/wD8nLf/AOOUf8KE+If/AEL/AP5OW/8A8co/tvLf+gmH/gcf8w/s/F/8+pf+Av8AyPN6K9I/4UJ8Q/8AoX//ACct/wD45R/woT4h/wDQv/8Ak5b/APxyj+28t/6CYf8Agcf8w/s/F/8APqX/AIC/8jzeivSP+FCfEP8A6F//AMnLf/45R/woT4h/9C//AOTlv/8AHKP7by3/AKCYf+Bx/wAw/s/F/wDPqX/gL/yPN6K9I/4UJ8Q/+hf/APJy3/8AjlH/AAoT4h/9C/8A+Tlv/wDHKP7by3/oJh/4HH/MP7Pxf/PqX/gL/wAjzeivSP8AhQnxD/6F/wD8nLf/AOOUf8KE+If/AEL/AP5OW/8A8co/tvLf+gmH/gcf8w/s/F/8+pf+Av8AyPN6K9I/4UJ8Q/8AoX//ACct/wD45R/woT4h/wDQv/8Ak5b/APxyj+28t/6CYf8Agcf8w/s/F/8APqX/AIC/8jzeivSP+FCfEP8A6F//AMnLf/45R/woT4h/9C//AOTlv/8AHKP7by3/AKCYf+Bx/wAw/s/F/wDPqX/gL/yPN6K9I/4UJ8Q/+hf/APJy3/8AjlH/AAoT4h/9C/8A+Tlv/wDHKP7by3/oJh/4HH/MP7Pxf/PqX/gL/wAjzeivSP8AhQnxD/6F/wD8nLf/AOOUf8KE+If/AEL/AP5OW/8A8co/tvLf+gmH/gcf8w/s/F/8+pf+Av8AyPN6K9I/4UJ8Q/8AoX//ACct/wD45R/woT4h/wDQv/8Ak5b/APxyj+28t/6CYf8Agcf8w/s/F/8APqX/AIC/8jzeivSP+FCfEP8A6F//AMnLf/45R/woT4h/9C//AOTlv/8AHKP7by3/AKCYf+Bx/wAw/s/F/wDPqX/gL/yPN6K9I/4UJ8Q/+hf/APJy3/8AjlH/AAoT4h/9C/8A+Tlv/wDHKP7by3/oJh/4HH/MP7Pxf/PqX/gL/wAjzeivSP8AhQnxD/6F/wD8nLf/AOOUf8KE+If/AEL/AP5OW/8A8co/tvLf+gmH/gcf8w/s/F/8+pf+Av8AyPN6K9I/4UJ8Q/8AoX//ACct/wD45R/woT4h/wDQv/8Ak5b/APxyj+28t/6CYf8Agcf8w/s/F/8APqX/AIC/8jzeivSP+FCfEP8A6F//AMnLf/45R/woT4h/9C//AOTlv/8AHKP7by3/AKCYf+Bx/wAw/s/F/wDPqX/gL/yPN6K9I/4UJ8Q/+hf/APJy3/8AjlH/AAoT4h/9C/8A+Tlv/wDHKP7by3/oJh/4HH/MP7Pxf/PqX/gL/wAjzeivSP8AhQnxD/6F/wD8nLf/AOOUf8KE+If/AEL/AP5OW/8A8co/tvLf+gmH/gcf8w/s/F/8+pf+Av8AyPN6K9I/4UJ8Q/8AoX//ACct/wD45R/woT4h/wDQv/8Ak5b/APxyj+28t/6CYf8Agcf8w/s/F/8APqX/AIC/8jzeivSP+FCfEP8A6F//AMnLf/45R/woT4h/9C//AOTlv/8AHKP7by3/AKCYf+Bx/wAw/s/F/wDPqX/gL/yPN6K9I/4UJ8Q/+hf/APJy3/8AjlH/AAoT4h/9C/8A+Tlv/wDHKP7by3/oJh/4HH/MP7Pxf/PqX/gL/wAjzeivSP8AhQnxD/6F/wD8nLf/AOOUf8KE+If/AEL/AP5OW/8A8co/tvLf+gmH/gcf8w/s/F/8+pf+Av8AyPN6K9I/4UJ8Q/8AoX//ACct/wD45R/woT4h/wDQv/8Ak5b/APxyj+28t/6CYf8Agcf8w/s/F/8APqX/AIC/8jzet/wP4cbxd4u0fRVWQpeXCrL5bKrLEPmkYFuMhAx79Oh6V1B+CHimy/ea6+k6BaH5VutV1GJInfsgKljuIBPTop5qrqvinQPCmgap4d8JtJqNzqSLHeeIpFaBnizuMEUXVEOFDFj83zggjaRnVzOGIg6eAlzyel1rGN+re2m/Le72XVq4YSVKSniVypdHo35Jb697WX54HxK8Sp4v8d67rETRvb3FwVgeNWUPEgCRthuQSiqTnHJPA6UVytFdtCjGhSjRhtFJL0SsctWo6k3Ulu3f7ySSRw7AM3U96b5j/wB9vzoorYgPMf8Avt+dOEj7GO5uo7/WiigBvmP/AH2/OjzH/vt+dFFAB5j/AN9vzp0kjh2AZup70UUAN8x/77fnR5j/AN9vzoooAcJH2MdzdR3+tN8x/wC+350UUAHmP/fb86PMf++350UUAOkkcOwDN1Pem+Y/99vzoooAPMf++3504SPsY7m6jv8AWiigBvmP/fb86PMf++350UUAHmP/AH2/OnSSOHYBm6nvRRQA3zH/AL7fnR5j/wB9vzoooAcJH2MdzdR3+tN8x/77fnRRQAeY/wDfb86PMf8Avt+dFFADpJHDsAzdT3pvmP8A32/OiigA8x/77fnThI+xjubqO/1oooAb5j/32/OjzH/vt+dFFAB5j/32/OnSSOHYBm6nvRRQA3zH/vt+dHmP/fb86KKAHCR9jHc3Ud/rTfMf++350UUAHmP/AH2/OjzH/vt+dFFADpJHDsAzdT3pvmP/AH2/OiigA8x/77fnThI+xjubqO/1oooAb5j/AN9vzo8x/wC+350UUAHmP/fb86dJI4dgGbqe9FFADfMf++350eY/99vzoooAcJH2MdzdR3+tN8x/77fnRRQAeY/99vzooooA/9k=",
	"malu": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4lkkcOwDN1Pem+Y/99vzok/1j/U16xc3MPwft7SxsbSMfEEJ5l9qEmJVsFcBlhiUjYXKbdz4bG5gGO75etK5VGippzm7RW7/Rd2+iutnqYWl/B3x9rFu09v4evURXKEXTrbtnAPCyMpI564x19DV8fAn4i7T/AMSFs5H/AC+2/wD8crjNT1jUdbuFuNTv7q+nVQiyXUzSsFyTgFiTjJJx7mqVXZGvPg1pySf/AG8l+HI/zO+/4UR8Rf8AoAt/4G2//wAco/4UR8Rf+gC3/gbb/wDxyuBoosg9pg/+fcv/AANf/IHff8KI+Iv/AEAW/wDA23/+OU5/gT8RSzY0FsZ4/wBNt/8A45Xn9FFkHtMH/wA+5f8Aga/+QO+/4UR8Rf8AoAt/4G2//wAco/4UR8Rf+gC3/gbb/wDxyuBoosg9pg/+fcv/AANf/IHoA+BPxF2n/iQtnI/5fbf/AOOU3/hRHxF/6ALf+Btv/wDHK4GiiyD2mD/59y/8DX/yB33/AAoj4i/9AFv/AANt/wD45R/woj4i/wDQBb/wNt//AI5XA0UWQe0wf/PuX/ga/wDkD0B/gT8RSzY0FsZ4/wBNt/8A45Tf+FEfEX/oAt/4G2//AMcrgaKLIPaYP/n3L/wNf/IHff8ACiPiL/0AW/8AA23/APjlOHwJ+Iu0/wDEhbOR/wAvtv8A/HK8/oosg9pg/wDn3L/wNf8AyB33/CiPiL/0AW/8Dbf/AOOUf8KI+Iv/AEAW/wDA23/+OVwNFFkHtMH/AM+5f+Br/wCQO+/4UR8Rf+gC3/gbb/8AxynP8CfiKWbGgtjPH+m2/wD8crz+iiyD2mD/AOfcv/A1/wDIHff8KI+Iv/QBb/wNt/8A45R/woj4i/8AQBb/AMDbf/45XA0UWQe0wf8Az7l/4Gv/AJA9AHwJ+Iu0/wDEhbOR/wAvtv8A/HKb/wAKI+Iv/QBb/wADbf8A+OVwNFFkHtMH/wA+5f8Aga/+QO+/4UR8Rf8AoAt/4G2//wAco/4UR8Rf+gC3/gbb/wDxyuBoosg9pg/+fcv/AANf/IHoD/An4ilmxoLYzx/ptv8A/HKb/wAKI+Iv/QBb/wADbf8A+OVwNFFkHtMH/wA+5f8Aga/+QO+/4UR8Rf8AoAt/4G2//wAcpw+BPxF2n/iQtnI/5fbf/wCOV5/RRZB7TB/8+5f+Br/5A77/AIUR8Rf+gC3/AIG2/wD8co/4UR8Rf+gC3/gbb/8AxyuBoosg9pg/+fcv/A1/8gd9/wAKI+Iv/QBb/wADbf8A+OU5/gT8RSzY0FsZ4/023/8Ajlef0UWQe0wf/PuX/ga/+QO+/wCFEfEX/oAt/wCBtv8A/HKP+FEfEX/oAt/4G2//AMcrgaKLIPaYP/n3L/wNf/IHoA+BPxF2n/iQtnI/5fbf/wCOU3/hRHxF/wCgC3/gbb//AByuBoosg9pg/wDn3L/wNf8AyB33/CiPiL/0AW/8Dbf/AOOUf8KI+Iv/AEAW/wDA23/+OVwNFFkHtMH/AM+5f+Br/wCQPQH+BPxFLNjQWxnj/Tbf/wCOU3/hRHxF/wCgC3/gbb//AByuBoosg9pg/wDn3L/wNf8AyB33/CiPiL/0AW/8Dbf/AOOU4fAn4i7T/wASFs5H/L7b/wDxyvP6KLIPaYP/AJ9y/wDA1/8AIHff8KI+Iv8A0AW/8Dbf/wCOUf8ACiPiL/0AW/8AA23/APjlcDRRZB7TB/8APuX/AIGv/kDvv+FEfEX/AKALf+Btv/8AHKc/wJ+IpZsaC2M8f6bb/wDxyvP6KLIPaYP/AJ9y/wDA1/8AIHff8KI+Iv8A0AW/8Dbf/wCOUf8ACiPiL/0AW/8AA23/APjlcDRRZB7TB/8APuX/AIGv/kDstU+D3j3R7UT3Hh28dWcIBastw+cE/djZiBx1xjp6iuD8x/77fnWvpmsajolw1xpl/dWM7KUaS1maJiuQcEqQcZAOPYV6DbXMPxgt7uxvrSM/EEp5ljqEeIlv1QFmhlUDYHCbtr4XO1QWG35k49hxpUK75aN4y6J638k0lr2Vte/fyfzH/vt+dFNoqDiO9+Dulw6x8U/D1vO0ioly1yDGQDuiVpVHIPBZAD7Z6da5vWNTm1vV7/U7hUWe+nkuJFjBChnYsQMknGT6muz+BIX/AIW3oPJzm47f9O8lef1a2OyemDh5yl+Chb82fTfwD8V+DdH8ISW817Y6ZrIlJvXvJViNx8zeWVZj8yheMDocnA3Zb1f/AIWB4S/6GnQ//A+L/wCKr4Noq1I9fC8SVcPRjRVNe6rdj7y/4WB4S/6GnQ//AAPi/wDiqP8AhYHhL/oadD/8D4v/AIqvg2inzHR/rZW/59r72feX/CwPCX/Q06H/AOB8X/xVH/CwPCX/AENOh/8AgfF/8VXwbRRzB/rZW/59r72feX/CwPCX/Q06H/4Hxf8AxVH/AAsDwl/0NOh/+B8X/wAVXwbRRzB/rZW/59r72feX/CwPCX/Q06H/AOB8X/xVH/CwPCX/AENOh/8AgfF/8VXwbRRzB/rZW/59r72feX/CwPCX/Q06H/4Hxf8AxVH/AAsDwl/0NOh/+B8X/wAVXwbRRzB/rZW/59r72feX/CwPCX/Q06H/AOB8X/xVH/CwPCX/AENOh/8AgfF/8VXwbRRzB/rZW/59r72feX/CwPCX/Q06H/4Hxf8AxVH/AAsDwl/0NOh/+B8X/wAVXwbRRzB/rZW/59r72feX/CwPCX/Q06H/AOB8X/xVH/CwPCX/AENOh/8AgfF/8VXwbRRzB/rZW/59r72feX/CwPCX/Q06H/4Hxf8AxVH/AAsDwl/0NOh/+B8X/wAVXwbRRzB/rZW/59r72feX/CwPCX/Q06H/AOB8X/xVH/CwPCX/AENOh/8AgfF/8VXwbRRzB/rZW/59r72feX/CwPCX/Q06H/4Hxf8AxVH/AAsDwl/0NOh/+B8X/wAVXwbRRzB/rZW/59r72feX/CwPCX/Q06H/AOB8X/xVH/CwPCX/AENOh/8AgfF/8VXwbRRzB/rZW/59r72feX/CwPCX/Q06H/4Hxf8AxVH/AAsDwl/0NOh/+B8X/wAVXwbRRzB/rZW/59r72feX/CwPCX/Q06H/AOB8X/xVH/CwPCX/AENOh/8AgfF/8VXwbRRzB/rZW/59r72feX/CwPCX/Q06H/4Hxf8AxVH/AAsDwl/0NOh/+B8X/wAVXwbRRzB/rZW/59r72feX/CwPCX/Q06H/AOB8X/xVH/CwPCX/AENOh/8AgfF/8VXwbRRzB/rZW/59r72feX/CwPCX/Q06H/4Hxf8AxVH/AAsDwl/0NOh/+B8X/wAVXwbRRzB/rZW/59r72feX/CwPCX/Q06H/AOB8X/xVH/CwPCX/AENOh/8AgfF/8VXwbRRzB/rZW/59r72feX/CwPCX/Q06H/4Hxf8AxVH/AAsDwl/0NOh/+B8X/wAVXwbRRzB/rZW/59r72feX/CwPCX/Q06H/AOB8X/xVH/CwPCX/AENOh/8AgfF/8VXwbRRzB/rZW/59r72feX/CwPCX/Q06H/4Hxf8AxVH/AAsDwl/0NOh/+B8X/wAVXwbRRzB/rZW/59r72feX/CwPCX/Q06H/AOB8X/xVH/CwPCX/AENOh/8AgfF/8VXwbRRzB/rZW/59r72feX/CwPCX/Q06H/4Hxf8AxVH/AAsDwl/0NOh/+B8X/wAVXwbRRzB/rZW/59r72feX/CwPCX/Q06H/AOB8X/xVH/CwPCX/AENOh/8AgfF/8VXwbRRzB/rZW/59r72fXPxc8Z+CNQ8CanbXGpadqk8ikWkNpOk0iXGDskG1sqFPJPAxkc7tp+U9H1ObRNXsNTt1Rp7GeO4jWQEqWRgwBwQcZHqKpUVLdzxcxzOeNqxrOKi12Ou+M2lw6P8AE/xJbwNIyPcC5JkIJ3SosrDgDgM5A9sdetFaHx6C/wDC2PEGSc/6P2/6d46Kze5jmCUcXVS2Upfmw+BH/JXdB+tz/wCk8lcDXffAj/krug/W5/8ASeSuBqo7Dqf7nT/xT/KAUUUUziCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiug0bRrVrL+1dV886eZWgihtpAks8ihSw3FWCKodCSQSSygDlmRlRi5M5+iu0/tXSP8AoUdG/wC/15/8kUf2rpH/AEKOjf8Af68/+SKfKy/Zw/nX4/5HF0V2n9q6R/0KOjf9/rz/AOSKP7V0j/oUdG/7/Xn/AMkUcrD2cP51+P8AkcXRXaf2rpH/AEKOjf8Af68/+SKP7V0j/oUdG/7/AF5/8kUcrD2cP51+P+RxdFdp/aukf9Cjo3/f68/+SKP7V0j/AKFHRv8Av9ef/JFHKw9nD+dfj/kcXRXaf2rpH/Qo6N/3+vP/AJIo/tXSP+hR0b/v9ef/ACRRysPZw/nX4/5HF0V2n9q6R/0KOjf9/rz/AOSKP7V0j/oUdG/7/Xn/AMkUcrD2cP51+P8AkcXRXaf2rpH/AEKOjf8Af68/+SKP7V0j/oUdG/7/AF5/8kUcrD2cP51+P+RxdFdmNN0zxPLHZ2GmppmrzMI7ZIJna3nYn5Y2EhZldicB9+3IUFVBZxxlJqxM4cqTTugorZ0rSoHtf7Q1DzTZGRoY4oHCyTOAC3zEEKFDKSSDnIAHUrp/bNM/6FzTf+/tz/8AHqzlUUXY4Z4tRlaMXL0t+rX9eZydFdZ9s0z/AKFzTf8Av7c//HqPtmmf9C5pv/f25/8Aj1T7aJH1z/p3L/yX/wCSOTorrPtmmf8AQuab/wB/bn/49R9s0z/oXNN/7+3P/wAeo9tEPrn/AE7l/wCS/wDyRydFdZ9s0z/oXNN/7+3P/wAeo+2aZ/0Lmm/9/bn/AOPUe2iH1z/p3L/yX/5I5Oius+2aZ/0Lmm/9/bn/AOPUfbNM/wChc03/AL+3P/x6j20Q+uf9O5f+S/8AyRydFdZ9s0z/AKFzTf8Av7c//HqpajpdrdWs99p0bw/ZwHubZ33BVLBQ6MRnbuYLtOWGQctlirjVi3YqGLTaUotX72/RswKKKK0Ow7z49/8AJWfEH/bv/wCk8dFHx7/5Kz4g/wC3f/0njoqJbs7sx/3yt/il+bHfAj/krug/W5/9J5K4GvQPgS7H4t6CNxxm44z/ANO8lef1a2FU/wBzp/4p/lAKKKKDiCiiigAoqS3t5ru4it7eJ5p5mCRxxqWZ2JwAAOSSeMV7Lb/CHRfA9jb6v8RNW8rzctDpNjlpJmAVijOPxQ7cKCVPmDIp2OnDYOriLuGy3b0S9WeT6JoGp+JL9LHSbGe8umwdkK52gkDcx6KuSMscAZ5NenWH7PWuR2sd/wCItV0vQtPGfPeeYO8PJC5xhDk7f4/4vXinaj8a7rTYE0zwPpdr4f0qJwVKxLJPMQCoZ9wK5KhM5DNlfvmvO9QvtU1ydbjU765u5lUIJLqZpHC5JwCxJxknj3ppHV/sFBWd6kv/AAGP/wAk/wAD00eBvhJpX+iap44vrm/j/wBZNYx5hbPI27Y5B0IB+c8g9OgX+3/gp/0KGt/9/m/+SK8qFmuOWJPtTxbR4+7+tVyk/wBpqOlOjBL/AA3/APSmz1L+3/gp/wBChrf/AH+b/wCSKQ+F/g5rHNp4o1XTbq8/1UNwhMVq7/dViY8bVJAJMnQfe715d9mi/u/qaYbRccMwPvRyh/aifx0YP/t235WPTrn9ny+voJbrwv4k0fXbSJCGaOTYzSgZ8sbS65wV5LD73OBzXmviTwlrfhG7W21rTZ7ORvuFwCkmACdrjKtjcM4JxnB5pLOW+0q6ju9Pupre6jzsmgkMbrkEHBByOCR1716Bovxu121gOn+Ira18RaQyoj2t/Gu4hR8vz7Tk52klwxO3sTmk0VzYCurWdN/+BR+a+L8zyaivbk+Gng/4lJNP4C1R9O1GJd8mkakGIVdwXIf5iBwWJBk5dQdmcV49q+kX2g6lc6bqVs9te2zbJIn6qf5EEYII4III4NS0c+JwVXDpTdnF7STun/XZ2ZSooopHIFFFFABXaar/AMgDwj/2DZP/AEsua4uu01EiTw54UkQ7o0spYWZeQsgup3KE9mCyI2OuHU9xVR3NafwT9P8A25FTSLD+1dWsLDzPL+1zxweZtzt3MBnHfGa7m4+F0Mut6toWl6011rWnIZDbz2nkrOAASEYO2TyOCBXE6FfR6XrmmX0yu0VrcxTOEGWKqwJxnvxXo0nxG0LTvFms+KtMh1G41W9Rkt4rmJIorclQCxKuxc8dMDrVnXgoYV0717fFrq78tne3d3t3+45a38GQW/huz17WtSaxtL+Vo7WOG38+WQLwzEFlAUH3z7VtWfwlnm8TPpNxqaR2raedSgvIYfME0WRjCllwefXt75qh/wAJXpet+EtL0LXFvYZNKkdre6tI0lLo5yVZWZcH0IPbpXR2PxX01PFS3s9ndw6RbaSdLtY4gskoGRhmyVGeOx9PrQdFGngG489re71d9vev2Se23TfU5C78FpL4bfxBo1+1/YwTCC4jlg8maFmxtJUMwIJIGQe/1xrP8M7e01uz8PX2urB4gu0VhALYvDG7DKo0m7IJ9lI561Ufxfp+jeELnw/oS3cjXtwk9zeXaLGfkIKqqKzYGVByWPf142Lnx94f1TxXYeLb201FNVtlRpLOFUMMsqDCsJC2VHA42np1oJhDBaXtf3bq7stXzWd9Xa3V9bXMmx+G10dM1bUNSluYYtNvDYyRWdr9pl8wDLHbuUBRkfNnvTND8EafrUXiO7XWpl0/RYUmMi2WZJgwORsLrtIII6mrWkeP2t9T1HVn1jV9M1C+u2nkjsoI5oHU4IBR3XkcjJzxit6L4r6ZLq/jC88rUNNOtQxRW81kitJEUBBdvnT5jnPB/GgunTwD5W33366Ss9Gra20aXruc7dfC+9OuaBpunXaXS63bLdQSSxmJo0IyS65OMD0Jz2qJfAVrqNvrR0PWTf3ejo0s8Mlt5QkjU4Zo23NuA9wprbuPitBba/4Z1Oztri7m0iBoLm6vcJNeqwwd2C2MckZJ5PPvnWXjDQvDUXiCbQ4tQlvdXhe3QXaIiWsbnLYKsxc9MHC9KBSp4DmdmrXd9XouVWt39666/dqQ23grQ7rwreeI113URZWk627xnTE8wsccgefjHzDvXGJbG6vltrPzJjLL5cO5QrPk4XIycE8cZP1rp7DxVZ2vw61Xw48Vwb67vUuEcKPLCgLkE5zn5T2qp4D1rTPDvia01XVIJ54bTdJHFCqktLj5c5IwAec+woOOpHDzlSjC0U0uZ66O7vu30Nj4gfDSTwNa2VympJqEM0jQSskWwQygA7D8xzkZ9OlZPjrwj/whWtJpv2z7XugSfzPK8vG7PGMn09a37j4j2mt+GvEOlatpiQS38wvbeSyDsBc5+Zn8yQ4BAA+XoCeKyviT4rs/GPiCPULGK4jhW2jhKzqA25c56E8c0G+LhguSc6HXlsrvTdPf0T176HH1N8QP+R88U/8AYUuv/RrU2CCW6niggieWeVgiRxqWZ2JwAAOSSe1N8cXEN3418SXFvKk0E2o3LxyRsGV1MrEEEcEEc5qZHBD+DL1X5MvXn/IG8Of9eT/+lM9UoYZLmaOGFGklkYIiKMliTgAVcuSH0Pw+6nciWskTMOQHFxKxU++10OPRge4p/h/VP7D13TdSMfmCzuEmKf3grA4rgn8TPDTajNxV3eX5s764+A3iiDSTeBrOS4Vd5s0kJk+gONpPtn8a8507T7jVNQtrC2Tdc3MixRqeMsTgfSvqi4+MnhGHSjfJqQlfZlbVUYSlv7uMcfXp718xWOvT6f4jh1uJE8+K5+0hP4c7t236dqhHkZVi8dXjU+sQs1tdW110OrT4awXWt3fh+z1xZ9ftkZjAbYrDI6jLIsm7JI56qBxUKfDS5m8Bf8JRBd75ULmSxMWGVEcqzBs844JGBgH2rTt/Hnh/TfFd74ss7XUG1SdXaOzlVBDFK4wzGQNlhyeNo69ah074lx6Zofhy2jhnku9Pup5bxXVfKnilLbkHPOQ3cdaNSnPH2jyf3b3S7PmXpeyv57sVfhRu8TNov9r/AHdM/tHzvs30+Tbv9+ufwrnPBPhL/hMdTurL7Z9l8i1kud/l7923Hy4yOuetd0/xR0I+Op9ZS11BNOfSjp6p5aGRWz1xvxjHvmud8G+JNA8G6xcXkc+p3kVxZTW7BrOOJlZiu0j962Rwc9McdewOFXG+ylzJ83KraLfW/S3bf5EUXw3uLrwAviq2vRK4Ls9l5WGWNHKs4bdzjgnjoa0YvhQr+KTojawVUaaNRM4tcnHHybd/v1z+FRaT8R4NG8PeGbG3gne40y5me6R1Xyp4ZCdyDnJyD3HWt3/hamhr48l1yK31GKwOl/YUVY081GyMHG/GAB65o1IqVMwTmorT3raLv7q+7Vd767HlmpRaZEY/7Ou7u4BzvNzarDt9MbZHz39Kl0L/AI+rr/rwvP8A0mkqz4k1NdTe3ca3q2qsgILalHtMY4wF/evnPOenTvVbRCEmvZWO2NLC73OeAu6B0XJ7ZZlUepYDqaqO6PTk28O772f9bL8jkKKKK7T3DvPj3/yVnxB/27/+k8dFO+PTsPix4gAYgf6P3/6d46KiW7O7Mf8AfK3+KX5sPgR/yV3Qfrc/+k8lcDXffAj/AJK7oP1uf/SeSuBqo7Cqf7nT/wAU/wAoBRRRTOIK2vCvhXU/GWtQaTpMHm3MvLM3CRIOrueyjP6gAEkA0tI0i+17UrbTdNtnub25bZHEnVj/ACAAySTwACTwK9r8U61D8G/D0Xg/w8ETxFeQJLq2pxyBnRiD8iHgqeu3IG1WBA3OWDSO7CYWM061Z2px37t9l5v8FqF9r3hv4K2+paP4WZ9S8XSKsNzqsyqY7c4+dEHqGGdnIyRuZim2vJNQvr/xDqVzqWpXMk93ctvklfqx9uwAGAAOAAAOBVWC3BAdunYVZeRYxlj+HrV26szxWNniLQS5YLaK2X+b8wSNYxhR/wDXoeRI/vMBVKS6d+B8o9utQVDqpbHOqXcvG8jBx8x9wKZ9t/6Z/rVSiodWRXs4lv7b/wBM/wBaeLxDjIYVRoo9pIPZxNNJUf7rAn0pzKHGGAIrKqWO4ePjOV9DVqr3JdLsWUWayniubWWSOaJw6PGxV0YHIYEcgg9xXrWl/EHQ/iTptt4e+Iu9LtZ82mtW6pEYt3UOcYUHAXO0qQQSAV3V5TFMsoyDz3FRz24bLrwe49au3VG+FxlTDNpaxe6ez9V+u6NXx/4A1P4fa0bG+Hm20uWtbtFwlwg7j0YZGV7Z7ggnlK9t+G3i2z8XWEXw88XJ9p065+TT7xnCyWkgB2KGP5J1OTswytgeWeKvCup+Ddan0nVoPKuYuVZeUlQ9HQ91OP0IIBBAho2xeGhyLE4f4HpbrF9n+j6oxaKKKRwBWzo2upYwtZX9u95pbsZPJSURyRSYA3xuVYKSAAwKkMAMjKoy41FMcZOLujsPM8Jf9BfXP/BVF/8AJNHmeEv+gvrn/gqi/wDkmuPop8zNPaQ/59r/AMm/zOw8zwl/0F9c/wDBVF/8k0eZ4S/6C+uf+CqL/wCSa4+ijmYe0h/z7X/k3+Z2HmeEv+gvrn/gqi/+SaPM8Jf9BfXP/BVF/wDJNcfRRzMPaQ/59r/yb/M7DzPCX/QX1z/wVRf/ACTR5nhL/oL65/4Kov8A5Jrj6KOZh7SH/Ptf+Tf5nYeZ4S/6C+uf+CqL/wCSaPM8Jf8AQX1z/wAFUX/yTXH0UczD2kP+fa/8m/zOw8zwl/0F9c/8FUX/AMk0eZ4S/wCgvrn/AIKov/kmuPoo5mHtIf8APtf+Tf5nYeZ4S/6C+uf+CqL/AOSaPM8Jf9BfXP8AwVRf/JNcfRRzMPaQ/wCfa/8AJv8AM6ybXtL0hS2hfbZtQ/gv7tEhNv8A9c4lZ/nGOJC/G44UMFccnRRSbuROblpsuxqaXq62cbW13C1zYM2/ylk2Oj4+8jEHaTgA8EEAZGQpXU8/w7/0ENV/8F8f/wAfrl6KzlTjLVnJUwsZS5k2vS36pnUef4d/6CGq/wDgvj/+P0ef4d/6CGq/+C+P/wCP1y9FL2USPqf99/h/kdR5/h3/AKCGq/8Agvj/APj9Hn+Hf+ghqv8A4L4//j9cvRR7KIfU/wC+/wAP8jqPP8O/9BDVf/BfH/8AH6PP8O/9BDVf/BfH/wDH65eij2UQ+p/33+H+R1Hn+Hf+ghqv/gvj/wDj9Hn+Hf8AoIar/wCC+P8A+P1y9FHsoh9T/vv8P8jqPP8ADv8A0ENV/wDBfH/8fqhqWsQtA9npscsVq+POklYGS4weM44VcgNsBPPVmwuMaimqcU7lQwsYtSk27d7fol+IUUUVZ1HefHv/AJKz4g/7d/8A0njoo+Pf/JWfEH/bv/6Tx0VEt2d2Y/75W/xS/NknwJC/8Lb0Hk5zcdv+neSvP6774Ef8ld0H63P/AKTyVwNWthVP9zp/4p/lAKKK6f4feEJvHHizT9IQOIJG33MiZ/dwry5zggHHygkY3MoPWmctKnKrNU4K7eh6X4HttP8Ahb4C/wCE21C2gl8T6nuTSLe5LArGcKXC4yMgli2cFCgDLvOfIw0t7cS3VzI80srF3kkYs0jE5JJPJJPU12nxa8VReKvFrWunFF0TSl+xWUcOBEFXhnUAlcEjgrjKqnHFckqhFCjoKtI7MxrR5lh6XwQ09X1l83+FhJHEaFj/APrrNd2kYsx5qe8fLhAeB1+tVqxqSu7HJTjZXCiiiszQKKKKACiiigAooooAVWKkEHBFaMMolTPG7uKzamtX2SgZ4bitKcrOxnON0TXMP8aj617GBa/GX4dzeZGjeOvDsGIirs015bpjkjBLk/MMDJEmDlRJg+TEZGD0rV8DeKZvAvi2w1VDIbdG2XEa5zLC3DjGQCQOQCcblU9q2aOjL8RGnN06vwT0f+fqt0cZRXoPxh8IReF/Fj3GnhG0PV1+22MkODFtblkUgBcAngLnCMnPNefVBhiKEqFWVKe6Ciivdv2eP2cP+F92/iGX/hJv7F/sd4Fx9h+0+b5gc/8APRNuNnvnNJtJXZkeE0V6tH8Cdak+OZ+Ffn4vRfG3N75JwLcDf9o2Z6eV8+3PtnvW7+0T+zp/woNPDjf8JL/bX9sm4H/Hj9m8nyvL/wCmj7s+Z7Yx3zS5lewWPDKKK9e/Z9+Bv/C9vEWq6R/b39jfYLT7V5v2T7Rv+dV243pj72c5NNu2rA8hoqW5h+z3M0O7d5blM4xnBxUVABRRX0j8B/2T2+N3gi58SL4uGktDeyWYtjp3nhiqI27f5q4zvxjHak2lqwtc+bqK9X+FPwI1n4l/FC88DTTnSp9N8/8AtC5aHzvsvlHYfk3LuJcqvUdc9qPj/wDBb/hRni6w8P8A9uf2x9rsEvvP+yfZ9u6SRNu3e+f9XnOe/TijmV7BY8ooor2P4S/Aj/haXgfxz4m/t/8As7/hFrdrj7N9j877TiJ5MbvMXZ/q8Zw3Wm3bcDxyiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAO++PQX/hbHiDJOf8AR+3/AE7x0U349/8AJWfEH/bv/wCk8dFRLdndmP8Avlb/ABS/NjvgR/yV3Qfrc/8ApPJXA133wI/5K7oP1uf/AEnkrgaqOwqn+50/8U/ygFe5fCKRPCXw08a+Mkb/AE4YsbZlhVngfC7WBY8qXmjJGP8Alnn5uBXhte2fEAf2D8Gfh9of+u+27tS8/wC7syC+zbzn/j5xnP8AB054tG2WP2TqYn+SLt6v3V+Z5NaJks5HTgVbqOBdsS9OeakrRbHksgkgjeTLMQzdqT7HH6t+dR3rfMi9wM11Xwt1Tw7YePvD1x4xWV/DkF2kl15cSy8Dld6EHfHuC7wASU3AAnFYylFN3RrGMmlZn0L8Ef2QdL8ceC4PEni3UdWs/wC0v3lla2W2J1hBIDyGSNs7+GXaMbcHJ3YX0r/hhj4d/wDQZ8U/+BVv/wDGK+jtH1az1/SLDVtOm87T9QgjubeXaV3xuoZWwwBGQQcEA1drxJ4io5N3setGhBJK1z5k/wCGGPh3/wBBnxT/AOBVv/8AGKP+GGPh3/0GfFP/AIFW/wD8Yr6boqfb1O5XsYdj5k/4YY+Hf/QZ8U/+BVv/APGKP+GGPh3/ANBnxT/4FW//AMYr6boo9vU7h7GHY8a+Hv7Lnw68A/2jnTf7f+2+X/yMEFvd+Rs3f6v90Nu7dz67V9K7C7+FXw1srSe5l8AeGmjgjaRhDoUMrkAZO1FjLMeOAoJPQAmu2XAYZ6VJuT2/KumlWk46yXzOWtSipaJ/I/Mr9o/VPAHiTxxp938PYbGHRU02OKVbCwNnGZxLKWJQouTtKfNjpgZ4rx9baNZFwzbhzivqH9p34jfCPxh4Rtz4EOlyeJpdWW5u7i30h7aeSIxy72aVol3ZdkJBJJPPbNfLFo377nJLA16cXHRWOFqVm7l6q92mUDY5H8qsU113oy8cjvW7Mker6xInjL9nu0v5m/07wxdLbGV4Vy6ZVBGrA8Lsliye5j5B+9Xhle2/AQf2uPGXhf8A1X9saY3+k/e8rGY/ucbv9fnqPu+/HiVZs9bMH7WlRxHVx5X6xdvysFfZv7FMskHw6+MssTsksdnEyupwVIhuSCD618ZV6Z8Mfjj4h+E+h+J9I0Wz0u4tvEcSw3TXsUjugCuvyFXUA4kbqD0FZyV1ZHmI+xpfiD4eT4UP+0GnljxrNoA0AKAMC98zaW2+u75v+uYrjv2utK1HxPp3wE0zTj5mrakrwQGRvvSutoFJJ/2iMk18PV6v4/8A2hPFnxCXwYbuLTdPuPCB3adcadHIkgb91hmLuwJBhUjAHep5LO6Hc+2PDmqeJtD+JGjeDfH3xn07XdXv03S+GF8LIUnUoxx9oRQE4BbLAcDkc1g/A7wxpvg79rP4s6PpFtHa6dDYRSxQRjCR+Z5EhVR2ALnAHQcV84z/ALYvjy41jTNabSfCo1myAR79dMxcXUYz+7kk37ghJyVQoD9MisvRP2pvGOg/E3xH8QLbTdBfWdfgjt7mGWCY26KiooKKJQwOI16seppcjHdHsX7NGW+BXx+VeW+y3fA6/wDHrNUHwThkj/Yq+KzshVJLu6KEj7wEFuMj8QR+FeA/Cz46eKvhDf6vcaGLC4ttXUC8sb+Ey28uM4JAYEEbmHB5B5zXRXn7UvjG98EeIPBx0zw5Boes718m1sWgFmjBQUgVHCKuVLcqxJZiSc03F3Fc0Phr8AvBHjjwZp2u6x8Z/DvhvUboyCTSrxYPNg2yMozuuEPzBQwyo4Ydetez/AvXLvwZ+yL451nS5wbzSdakuIJR91ihtiOnY45Hoa+Gq9M8P/HHxD4b+FOt/De0s9LfQ9YleaeeWKQ3KlggO1g4UD92vVT1NOUWwTPtLxx4p8L+DfDB+IXhdvL1v4s3WmwLgjMUeFEuMdDt3Bv9th6VxP7TPh7xH4n/AGrPh3p/hO6htPEJ0qGe1up1DJA0U9zIZGBBBChCcEHOMY5r4i0vUJdJ1Oy1CFUaa0mSdFcEqWVgwzjHGRXqXi/9o/xn4v8AiRofj9hp2meINFtxbWzafC4jKBpCdyyO+ciV1POMHpS5GnoFz7e8AX1zq3j7VfAXjX4qad47vYbST7b4ek8LpCkJG3Leeo2HG4Aqc/e7EV5d8DdGtvDvg39pzR7NStnpsl9aQgnJCRx3Krz9AK8dg/bK8c2niY+ILXQ/CNtfSxlLryNNaP7acAK0ziTzHKgcDdtHpwMcroH7Rninw5b/ABCgtbDRnTx3LPNqBlhlJiMokDeViQbQPNbG7d0HXuuRjue0+Fst+wF4uC8kagM47f6Xb0/W4ZIf+CfugCRCpa+LAEYyDfTEH8RXhXwz/aB8U/C7w7qnhyxtdH1XQNSYyTafrFqbiHcQAxChl6hVyDkcdKueLv2kvF/jb4cjwLqtro39lLMJlmt7VopkCuXWNQr+WqLkKAEGFUD3p8rv8xXPHqKKK0EFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAHefHv/krPiD/ALd//SeOij49/wDJWfEH/bv/AOk8dFRLdndmP++Vv8UvzZJ8CXY/FvQRuOM3HGf+neSvP6774Ef8ld0H63P/AKTyVwNWthVP9zp/4p/lAK9t/aIH9na54e0O2+TS9O0xPs0HXy8uyH5j8x+WJByT09znxKvbv2lf+R60/wD7Bkf/AKNlqkbYb/ca784fm/8AI8uUbVAHQDFVL1vmVfQZq5VC7bMxHoMU6vwnmU/iIKKKK5joP1k8A3dv4R+EPg+TxDPFo8dhotjFdNqLi3Fu/kxptcvjadx24OOeOtdpZ3lvqFpBd2k8VxaXEaywzQuHSRGGVZWHBBBBBHWsnxdp+g61oN5pPiSG3udKvozHLbzZPmDI6Y+bIOCGXlSAQQQDXzja/D74seFphovw8+LFlL4eXm2h16HM9uPuJCrPDICqoqAbSgzuwi9/HUVO7vZnrqlV5eaMG13SPpfU/EejaLd2FpqWrWFld6jJ5VpDc3CRvcvkDbGrEFzllGBn7w9a068O8BfA/XG8S2vjD4o+Jv8AhKfEVn81jZopFjp0mQPNjTCqXKpGchEAYE4Zgrj3GpkktE7kRberQVmQeI9GudaudEh1awl1q1jEs+npcI1xEh24Zowdyj515I/iHqK068h+KHwWuPE+tReL/BmvS+F/HEEex72AHytQRcFIrhR94bkQbiG+UYZXAUKopN2bsOTaWh69WZofiPRvE9o93omrWGqWiSGJprG4SdFcAEqWQkA4YHHuPWvmu98HfHe/kGleJvi7pGn6bP8A66bSIM3UePmXb5cETDLBQf3i8E9RkH3X4aeGPC3gjw1b+H/Cyolpb5aQv/rp5CBulkJALMeOcYGAoAAAFSgore7KVOq1z8jUe9j8mbyzuNOu7izvLeW3u7eRopoJkKPG6nDKynkEEEEHpUNdp8YP+StePf8AsPX/AP6UPXF17Cd1c8hqzsT2jYmA9Rir9ZsDbZkPvitKumk9DCqtTuPgRez2XxP06CCTbFdxzwTDAO9BGzgc9PmRTx6ema4PxhYW+l+LdesbSPy7W1v54YkyTtRZGCjJ5OAB1rtfgl/yVbRPrcf+iJK5L4gf8j54p/7Cl1/6Nahnoy1y6DfScv8A0mJztFFbcHha9uPC1x4ijeA2dvcfZ5I9x80cL8+MY25dBnOcsOKR5hiUV0eq+CNX0ufSbbyftd3qdsLqK3tFaSRQSQVZcfeBU5AzismPR9Rm1A6dHYXT6gCVNqsLGXI6jZjOfwoApUVoQaDqt1eT2cGmXst5ACZYEgdpIwOu5QMj8avXvhiW38Vx+H4Z0knkmigSWRSi7n24yBkgAt70AYNFdOnhK3fW9N0qPxBp9zNeXkdm4tYpy0O5gpYiSNAQCegP+NY6aLqE8ka21ldTiaVoYjHCzea69VXA5IBBwPWgLlCitSLwzrc91NaxaPqEl1AwSSFLZy6MQSAVxkEgE8+hqOz0HVdQmlhtNMvbiaFxHIkMDOyNz8pAHB+VuP8AZPpQBn0VdbR9RXTl1FrC6Gns20XRhbyifTfjGfxqz/wjWqRTww3djdWZnieaM3FtIPMVELEgBSSMDqBgdSQMkAGTRRW34Y8LXviy7urWxeBZre3a42zMR5mCqhFwDliWAAOBz1oAxKK2x4Wvf+EVbxGXgWyFyLURlj5rEgkMBjG35WGc9QaNR8K3+maBpmtTGE2uoFgiKxMkeCcbxjjdgleTkA0BcxKK328I3q+JLvQTLb/bLVZmd9zeWRFG0jYOM9FOOOvpWeNInbRH1ffH9mS5W1K5O/cVLZxjGMKe9AFCiiikMKKKKACiiigAooooAKKKKACiiigAooooA7749Ow+LHiABiB/o/f/AKd46Kb8e/8AkrPiD/t3/wDSeOioluzuzH/fK3+KX5sd8CP+Su6D9bn/ANJ5K4GvQPgSF/4W3oPJzm47f9O8lef1a2FU/wBzp/4p/lAK9t+Oh/tbT/AviWb5b7VtMHnRpxGuAknyg8jmZupPAHvnxKva7w/8JT+z3p90PnuvDd8YJZrnl/LY4CRtyduJoRg4H7v/AGRmka4H36Fej3ipf+Au/wCVzzBCSik9SBWfO26ZyfXFW7VsxY7qaos25ix6k5pVXojz6a1YlFFdP8N9Ws9A+InhHVtRm8nT9P1a0ubiXaW2RpMjM2FBJwATgAmuduyNlufpv4x0+7XUZLtkd7VlUK4yQmABg+nPP4/WuftbSe9mEVvE8sh7KOnbJ9Bz1r1qzvLfUbS3vLO4iuLS4jWWGeFw6SIwyrKw4IIIII61NXi81j6yjm0qdJQ5b2IbOOSG0t45n3ypGqu2c7mA5OTU1FeY+IPCvxC0jWbzU/A/iaxuLW/ffLoviYSzW8EjfekhmQmRB8qgQ/cG5yMfKARV+p5MpO9z06ivJbTwr8UvFN1BH4y8TaPpOjQOry2nhMTxzX4zu2vcSEPCAVX/AFWCys4JHBr1qiSt1Enc8m1PT7uwunW7R97MT5hyRJ6kHv1/XmrvhrT7u51O2mgR1iikDPLyFAGMjPqQcY9/SvTKKOY9iWbylT5OXX+uh+Svxg/5K149/wCw9f8A/pQ9cXXqn7SPiLS/Ffxr8V6rot7FfabLJBHHcwnKSGOCONip/iG5GAYcHGQSCDXldezD4UfJz+Jiq21gw6g5rVrJrQkk/wBH3HGWX+ddFJ7mFVbHpX7POmxah8RPtMrOJLCzluI9pADMSseDx0xIx4xyB9K8q1jU5tb1e/1O4VFnvp5LiRYwQoZ2LEDJJxk+pr1/4YH/AIRr4Z+PfFLfLI8Q0+1mg4uIZCMZDcbV3TRHIOfkzjIGfE6pnoYr93g6FPq+aT+bsvyCu28PeLLLQ/D1rbTwC+ze3DXNixKCWF4o1Hz4IHzJkdeVHFcTRSPMselN4vsdX05be81L7Nf32mzQT3ZjcrDK1885VtoJ2shAJUHG4D1FQy+ItLubrULH+0mjWfSINOXVXifDvGyMSwAL7GCFOmcBcjqK87oouKx6VqHiHSdV0+40lNaNrJEtl/xMpIpcXfkI6sCFBcYLjbkdEGdvGMzU/EGn3PxSh1tLt5NNXUIJ2uHRgxRSm5iuM54PFcRRRcdj0a41u0j8VaJqU2t6Dc2dvqkVw407TGt5Y4xIGLORbxlgAOmWOe1RXHiWxvtYstTt9QisVMElnJYzwSNBAhQqduwZEbhiTj5wxJ5+8fPqKLhY9SU6Rc+HfEsNlrP2O0eTTo2nInaDzAs5KLkGTy+MjIJyB25rJ1/xVZ31n4ojtbuXdfz2CqWVla5SGKRXkb03NtbBOct7GuIW5mSCS3WWRYJWV3jDEKzLnaSOhI3HHpk+tRUXFY9PvfGOlTaZ59qdOhuJNOisHiaK7e5XaiqcDzBBt3LuB4P+znJLZPEGiLqCahNqUMt/cC9ad7SOdYmMls6qXSQcSF2A+T5QDXmVFFwsauh3f2Q6j/xMPsXm2csX+p8zz84/df7O7+92xV7wlrUeiDWpjcGC5lsTHbMASTKJonHQccITk8cVzlFA7Hf6n4u0/wARaTqdoyR6VFPd2X2e2XdIkMa/aDK2QvTfMWx1+bAziruteLvDOsQeIdPht761gmhiFlPNcCSLNsNsIESxAoWTcuSxwX59R5nRRcLHp17qehw+ObzxEmv2dxZXjTRmCGG4E6JNE0ZbDRKp27843duM1zWq3Onad4XTRrPUY9RnlvftcksEciRooTaq/Oqkk7mJ4wMDk1y1FFwsFFFFIYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB3nx7/5Kz4g/wC3f/0njop3x6C/8LY8QZJz/o/b/p3joqJbs7sx/wB8rf4pfmw+BH/JXdB+tz/6TyVwNd98CP8Akrug/W5/9J5K4GqjsKp/udP/ABT/ACgFe0fADWbe7n17wXfzTra6/ausRRz8jhGDhVwQGZCTuP8AzyA54rxerOn39xpd/a31pJ5d1ayrNE+AdrqQVODwcEDrVIjBYl4avGra6W67p6NfcXrq1uNHv7yxuk8q6tneGVNwO11JBGRkHkEcVQr2D4vaUvifTNI+Iuk2z/YtUgVL9V3MLeZfk5JwcZHl5Chcxg9XFeP1FTexpicN9WquC1W6fdPZ/cFFS28PnOQW2oqlmbGcAe1P8uz/AOf3/wAhGszBtI+oP2ZP2m7PwBp6eDvGL+V4ci8ySx1CKEu1ozEu0cioCzozFiGALKzYOVIKfeFneW+o2lveWdxFcWlxGssM8Lh0kRhlWVhwQQQQR1r8b/Ls/wDn9/8AIRr074afHrxb8KtkGjeIvtGkrn/iV6hC81qM7z8q5DR/M5Y+Wy7jjdnpXJWwvO+aO50UsSo6S2P1IorzL4Q/F1/i3oVlq1n4Yvbe1nklimuY7y1mgt3TPyt+8WYEjacGIH5wfukMfUDE4ONp/KuGVKcd0dcasJbMZRTvLc/wn8q4r4k+PpfhxoWpaxP4fvbzT7G0Nw92t1aw26vyFjYySh8lto+VHJ3gKGb5aUac5bIcqkI7s7Ovjb9pP9qfS7vRL7wb4Fu4r9r+OW11LVAmYo4jlHii3DDlhnMgyoUjaSW3J418Uv2mvFvxN+02X9s/2LoEu5P7O05HTzIzvG2WX70mUfaw4RtoOwGvF/Ls/wDn9/8AIRruo4TlfNM5KuKT0iV6KseXZ/8AP7/5CNNngWNY3jk8yKQHDYx0PPFdhzXTIameQtFGuegqGvUPgt4WW+1uTxNqiPH4f8PK15LcFGKmVBuVRtOSV++cA/dAI+YVdPc1o4aWJqRpR6v7l1fy3Nr4r3f/AAhvw48KeA1adL54lvr5DL9zJYmM7RtdTKzkcnHlL1yDXhtbXi3xJceLvEmpa1crtkvJS4TIPloBhEyAM7VCjOOcZPNYtaMMfiViKzlD4VZR9Fov8wooqxbW3m/vJMiIHGR1Y+g/x7fkCHEV6K0sW44FrGQO7M2T9cEUv7j/AJ9Iv++n/wDiqfKLmMyitP8Acf8APpF/30//AMVR+4/59Iv++n/+Ko5Q5jMorT/cf8+kX/fT/wDxVH7j/n0i/wC+n/8AiqOUOYzKK0/3H/PpF/30/wD8VR+4/wCfSL/vp/8A4qjlDmMyitP9x/z6Rf8AfT//ABVH7j/n0i/76f8A+Ko5Q5jMorT/AHH/AD6Rf99P/wDFUfuP+fSL/vp//iqOUOYzKK0/3H/PpF/30/8A8VR+4/59Iv8Avp//AIqjlDmMyitP9x/z6Rf99P8A/FUfuP8An0i/76f/AOKo5Q5jMorT/cf8+kX/AH0//wAVR+4/59Iv++n/APiqOUOYzKK0/wBx/wA+kX/fT/8AxVH7j/n0i/76f/4qjlDmMyitP9x/z6Rf99P/APFUfuP+fSL/AL6f/wCKo5Q5jMorT/cf8+kX/fT/APxVH7j/AJ9Iv++n/wDiqOUOYzKK0/3H/PpF/wB9P/8AFUfuP+fSL/vp/wD4qjlDmMyitP8Acf8APpF/30//AMVVa4tlVTJDuMY+8rHJX/Ee/wCHpkaC5VoooqSjvPj3/wAlZ8Qf9u//AKTx0UfHv/krPiD/ALd//SeOioluzuzH/fK3+KX5sd8CP+Su6D9bn/0nkrga9A+BLsfi3oI3HGbjjP8A07yV5/VrYVT/AHOn/in+UAooooOI3bXxVqcHhi68Nxz7dKublbt0HBLhcYJHVThSQc8opGOc5VRxd6nhiM0qRjOWOOBnFZy3OjnlKK5ne35EkzfZ7DYfv3BBx6KOh/E1nVav5hNcttx5cfyJg54HvVWoZkFFFFID6J/ZG+NX/CtfHS6JrWqfZvCGuZSb7RLtgtLnA8uc/KdudojY5UYYMxxGMfpfX4j1+lH7Ifxxk+JnhGTw7rd1NP4q0CNfMuLmZGkvrcsQkgHDEp8qOSDyUYsWcgDGj6Qr4H/ba+NX9taxB8PtA1Tfpmn5fWPs0uUmuQ3ywP8ALz5W3cQGI3PggNFx9MftIfGSL4OfD6e8t23eIdU32elxq8e6OUoc3BV87kj4J+VgWZFOA2R+V17e3OpXlxeXlxNc3lzI0s08zl5JXY5ZmY8kkkkk8kmhAyCiiigQVoWTefbS238YPmp7kDkflWfUttO1tPHKvVTnHqO4poCWtaDxVqdh4b1Lw/DPjTNSljlmjbnlDkbc8Lk7SSBk7FGcAg0LuIQzsqcxn5lPYg1Vl+6PrVx0Zqpyim4u3+T3IqKKK0OcK0hxaWoHAKFj7ncwz+QH5Vm1p/8ALraf9cz/AOhtVRJkMoq1pmnXGr6lZ6fZxmS7vJkgiQfxOxCqPzIr234i/Dyxt5NCmudJufDui6fqQ0C6vpLFoftMKhSl5yBvZ8TEtz0X2p3JPCKK9KuPCNjbW/iCe1tbu2tU0ZrmEz3FtfJIy3UMZKTom3GHOdoVlPBOCQdTwv4Q8N/274OuLe2u9Ws5L+wS8nF3BJAzSld0ckGwvEA5K/PuDhSBjIILgeQ0V6jo/gzQPEP9vaxFBcW2l2N1FaR2NxrdpbSPI4kYt9omRECgRnCBCxz1wCanfwF4R0s24vL7UNRW81uTS4JtNuoPLEQjgcSFgrqzKZ8FVOCRwy45LgeT0VrSeH7pvE7+H7Uefem9NjGAMeY+/YPzNe4+J/h9DaeIfBk48MSafp2n69BoE/2mxMSajErIUuGDKBJ5mJtx54Cj0ouB88UV6J8PrG0uPisbaeGyNqjX5CXUAlgTZBMVLRlWBCkA42np0Na+rLoOu6RqLWs+m3Wr6bo0s95eaXpq21tMxu4FjCxvEm1grtl0RCcgZI3ZLgeSUV6h4t8F+F9Im8Uwab/bDv4avo4Z2ubiLF1E0hRguI/3bAgAMdwPJ2jpVzxR4c0LUfij4ksdN8OXw0+wln+0Rx6vbWcMREgUOJHgEcUfIUIc8kYbsS4HkdFeqat8P/D3hmLxDeam+o3VtZHTWtIbO7gzIt1DJIVaZVdDt2YDoCGwcD5gRgfDKxspNYvtT1VIDpWlWck87zw+csTPiGF/K6SbZZYyVPBAOfSi4HFUV2HjfwvqmlFNW1GPTYI76Yx24sFCRXKqiEzxKo2+W29eRgbiRtGCB3mkeEtH8UeAvCVo9va2d5bxy6peXyRqsstmt1LHcbm6uUURsoPQBqLgeJ0V6z8TtF0q9h1PxFZWMWmlYtEMVlZoscCC6spJZPlA67o15z3Oc543vCnhvS9G13UtDnglvNMXxLoUTRTspMgcT8NlSCuW5GORkcZzRcDwiivQW0PTdZ0rxLLo1u9ksWo2VvDFqF1bsAXFxuJnaOMIuUHAKj+9uwCNbwPpaaP4f8Ztd3fhq1v7OexjS+1C2i1O3QP5xZUKRTqS2F5Ufw4JGKLgeUUV7VYaboH9h3+paxZJqhuNBuLsPpyQWSKy6p5W6L/R8rkYwWXKqWXABAXldN8E6bqOoeDYhJeJDrtjc3cw8xS0ZjmuUUKdvTbAmcjqT0yAC4zz+iuv8Z6NoXh+30m1sV1GTU7mws764mnmTyU86BZGjVAmTywIYtwOMH71chQIKKKKYBUkPPmg8gxPkeuFJH6gH8KjqWDrJ/1yk/8AQDQgMqiiiszQ7z49/wDJWfEH/bv/AOk8dFO+PTsPix4gAYgf6P3/AOneOioluzuzH/fK3+KX5sPgR/yV3Qfrc/8ApPJXA133wI/5K7oP1uf/AEnkrgaqOwqn+50/8U/ygFFFFM4iWL7p+tXIW+z201weuPLT13HvntgVRWTaMYrSurZZoreNLq2CxKc7pOdx6/hWbTvc05laxkUVe/s3/p7tP+/n/wBaj+zf+nu0/wC/n/1qnlZNyjRV7+zf+nu0/wC/n/1q2rD4e+ItUtI7ux0u6urWTOyaCCR0bBIOGC4OCCPwo5WXCEpu0Vc5euw+F/xF1b4V+NdM8S6TNMGtpFFzbxybBeW5YGSBiQRhgOpB2kBhyoIP+FW+Lf8AoA6j/wCAkv8A8TXPf2W3/Pza/wDfz/61HKxzpzh8aa9T0P4+fGS9+NHjq41bddw6DbfudLsLh1P2eLADMQvAdyu5vvEcLuYIteW1f/stv+fm1/7+f/Wrdt/hr4ou4Iri30a+lglUPHJHbSsrqRkEELggjvRysUISn8CucnRXWXHw18UWlvLcXGjX0MEKl5JJLaVVRQMkklcAAc5rB/s3/p7tP+/n/wBajlYThKGk1Yo0Ve/s3/p7tP8Av5/9aj+zf+nu0/7+f/Wo5WRckVvtFgjfx252tnqVPTn9MVVf7hq/ZWq28rF7q2MboUbbJzg+lZ8jbWdODgkZU5BqkmVzK1iKiiitDMK0/wDl1tP+uZ/9Dasyr9tKJ4kgP+tTIT/aB52/XOT75+gNRJZf0bWL3w/qdvqWnTeRfW5LRS7VYoSCMgEEZ54PY8jmrGj+JtV0CK6i067MEd2YzKuxWDFG3KfmBwQfTsSDwSDlMpUlWBBHBB7UlUSdHf8AjrXtRSaKa7iSCa2Nm0FvawwxCIyLIQqIoVSXRSSACccmlbx94gNpb2q3yxJBJFKJIbeKOV2jOYy8iqHk2nkbicVzdFIDpk8f67Ff3l6ktkr3qqLiEadbfZ5tvKs0Pl+WWBJO7bnk881TuPFusXXkebeFvs941/H+7T5ZmCAsOOmIkG3oNvA61i0UAatn4k1PT9e/t22ufL1bzXnFx5akiRs5YAjAPJI44PIxgU/Q/FOreG/N/sy78gSyQyuDGjgvFIJI2wwOCGGfoSDwSDj0UAaNhr2oaZqr6pa3Hl37iUGXYpz5isr8EY5V2HTjPFRWOq3emxX0VrN5cd/B9muBtB3x71fbyOPmRTkYPH1qnRQBsXvirV9Rl1mW5u/MfWpBLeny0HnMH3g8D5fm5+XFaR+I3iJr6S9e5tHuJoPs87Pp9uwuU3Bv3qmPErZVTucM2QOa5WigDf1jxtruvx3ceo33npdm3Mo8pF3eQjJF91RjarsOOuec4FU9D8Qaj4bvHutNuBDLJG0MgaNZEljPVHRwVZTgcMCOBWZRQBva74z1rxLaW9pqd1HNbWrl4Ikt4o1gyACqBFGxDgHYuFzzjPNZ13q15fWWn2VxNvttPR47dNoHlqzl2GQMnLMTznrVKigDpbbx/wCILSWSRLyJ/MtoLRkmtYZYzHAgSL5HQruRQAGxu6nOSajuPHXiG6vL28l1KRru9uoL2aYIoZpod3lvkDgjc3TGc85rnqKANvU/Fuq6tHfx3ElssV/JFLcR29pDAsjxhwjYjRQD+8fJHXPOeKo2+r3lrpl7pkU22yvXjknj2g72j3bDnGRje3Q855qlRQBv6d411vShaLb3URjtLZ7OOKa2iljMLyGRkZHUq4LsW+YHnHoKtaX8RvEmjWqW1jfRRRxmTyj9khZ4hJneqMULIjZOVUheTxXLUUAXNS1W71eaGa9m82SGCK2Q7QuI40CIvAHRVAz1OOc1ToopgFFFFABUsHWT/rlJ/wCgGoqdM/2RHVgRO6lQp6oD1J+oyMe+fTIMzaKKKzLO8+Pf/JWfEH/bv/6Tx0UfHv8A5Kz4g/7d/wD0njoqJbs7sx/3yt/il+bJPgSF/wCFt6Dyc5uO3/TvJXn9d98CP+Su6D9bn/0nkrgatbCqf7nT/wAU/wAoBRRRQcQUUUUAFFFFABVmw1C70u7ju7G6ntbqPOyaCQo65BBww5GQSPxqtRQCbTujvLD40eO9OtI7aHxDO0cecGeKOZzkk8u6lj17n26V1f8Aw014t/6B2h/9+Zf/AI7XjFFO7O+nmmMpq0asvvv+Z7P/AMNNeLf+gdof/fmX/wCO1zuofHTx3qH2pf7a+zw3G4eXb28aeWrZ4R9u8YB4O7cPXPNedUUXYTzXGzVpVZffb8i7qesajrdwtxqd/dX06qEWS6maVguScAsScZJOPc1SoopHDKTk7t3YUUUUCCiiigAooooAKKKKALC310ihVuZgoGAA5wBS/wBoXf8Az9T/APfw1Wop3YrFn+0Lv/n6n/7+Gj+0Lv8A5+p/+/hqtRRdhYs/2hd/8/U//fw0f2hd/wDP1P8A9/DVaii7CxZ/tC7/AOfqf/v4aP7Qu/8An6n/AO/hqtRRdhYs/wBoXf8Az9T/APfw0f2hd/8AP1P/AN/DVaii7CxZ/tC7/wCfqf8A7+Gj+0Lv/n6n/wC/hqtRRdhYs/2hd/8AP1P/AN/DR/aF3/z9T/8Afw1WoouwsWf7Qu/+fqf/AL+Gj+0Lv/n6n/7+Gq1FF2Fiz/aF3/z9T/8Afw0f2hd/8/U//fw1WoouwsWf7Qu/+fqf/v4aP7Qu/wDn6n/7+Gq1FF2Fiz/aF3/z9T/9/DR/aF3/AM/U/wD38NVqKLsLFn+0Lv8A5+p/+/ho/tC7/wCfqf8A7+Gq1FF2Fiz/AGhd/wDP1P8A9/DR/aF3/wA/U/8A38NVqKLsLFn+0Lv/AJ+p/wDv4arUUUXAKKKKQzvvj0F/4Wx4gyTn/R+3/TvHRTfj3/yVnxB/27/+k8dFRLdndmP++Vv8UvzZhfDzxGvhLx7o2rytGtvb3O2d5FZgkTgpI2F5JCMxGM8gcHpSeNfDreE/Fmr6MyuEtJ2WLzGVmaI/NGxK8ZKFT269B0rl5P8AWP8AU16JpXifQfFOg6Z4e8VtJp9zpqNHaeII1adkizuEEsXV0GWClT8vygADcS4voKk41aXsJOzTur7XejXley1emmu+nC0V6IPgp4nvf3mhvpWvWg+VrrS9QieJH7oSxU7gCD06MKX/AIUT8QP+gB/5OW//AMcq7C/s7F9KUn6Jv8jzqivRf+FE/ED/AKAH/k5b/wDxyj/hRPxA/wCgB/5OW/8A8cosw/s7Gf8APmX/AIC/8jzqivRf+FE/ED/oAf8Ak5b/APxyj/hRPxA/6AH/AJOW/wD8cosw/s7Gf8+Zf+Av/I86or0X/hRPxA/6AH/k5b//AByj/hRPxA/6AH/k5b//AByizD+zsZ/z5l/4C/8AI86or0X/AIUT8QP+gB/5OW//AMco/wCFE/ED/oAf+Tlv/wDHKLMP7Oxn/PmX/gL/AMjzqivRf+FE/ED/AKAH/k5b/wDxyj/hRPxA/wCgB/5OW/8A8cosw/s7Gf8APmX/AIC/8jzqivRf+FE/ED/oAf8Ak5b/APxyj/hRPxA/6AH/AJOW/wD8cosw/s7Gf8+Zf+Av/I86or0X/hRPxA/6AH/k5b//AByj/hRPxA/6AH/k5b//AByizD+zsZ/z5l/4C/8AI86or0X/AIUT8QP+gB/5OW//AMco/wCFE/ED/oAf+Tlv/wDHKLMP7Oxn/PmX/gL/AMjzqivRf+FE/ED/AKAH/k5b/wDxyj/hRPxA/wCgB/5OW/8A8cosw/s7Gf8APmX/AIC/8jzqivRf+FE/ED/oAf8Ak5b/APxyj/hRPxA/6AH/AJOW/wD8cosw/s7Gf8+Zf+Av/I86or0X/hRPxA/6AH/k5b//AByj/hRPxA/6AH/k5b//AByizD+zsZ/z5l/4C/8AI86or0X/AIUT8QP+gB/5OW//AMco/wCFE/ED/oAf+Tlv/wDHKLMP7Oxn/PmX/gL/AMjzqivRf+FE/ED/AKAH/k5b/wDxyj/hRPxA/wCgB/5OW/8A8cosw/s7Gf8APmX/AIC/8jzqivRf+FE/ED/oAf8Ak5b/APxyj/hRPxA/6AH/AJOW/wD8cosw/s7Gf8+Zf+Av/I86or0X/hRPxA/6AH/k5b//AByj/hRPxA/6AH/k5b//AByizD+zsZ/z5l/4C/8AI86or0X/AIUT8QP+gB/5OW//AMco/wCFE/ED/oAf+Tlv/wDHKLMP7Oxn/PmX/gL/AMjzqivRf+FE/ED/AKAH/k5b/wDxyj/hRPxA/wCgB/5OW/8A8cosw/s7Gf8APmX/AIC/8jzqivRf+FE/ED/oAf8Ak5b/APxyj/hRPxA/6AH/AJOW/wD8cosw/s7Gf8+Zf+Av/I86or0X/hRPxA/6AH/k5b//AByj/hRPxA/6AH/k5b//AByizD+zsZ/z5l/4C/8AI86or0X/AIUT8QP+gB/5OW//AMco/wCFE/ED/oAf+Tlv/wDHKLMP7Oxn/PmX/gL/AMjzqivRf+FE/ED/AKAH/k5b/wDxyj/hRPxA/wCgB/5OW/8A8cosw/s7Gf8APmX/AIC/8jzqivRf+FE/ED/oAf8Ak5b/APxyj/hRPxA/6AH/AJOW/wD8cosw/s7Gf8+Zf+Av/I86or0X/hRPxA/6AH/k5b//AByj/hRPxA/6AH/k5b//AByizD+zsZ/z5l/4C/8AI86or0X/AIUT8QP+gB/5OW//AMco/wCFE/ED/oAf+Tlv/wDHKLMP7Oxn/PmX/gL/AMjzqt7wV4dbxZ4s0jRlVyl3Oqy+WyqyxD5pGBbjIQMe/ToeldMfgp4nsv3muPpWg2h+VbrVNQiSJ37ICpY7iAT06Kaq6r4n0HwtoOp+HvCjSahc6kix3fiCRWgZ4s7jBFF1RDhQxY/N8wII2kJ6blwwcqUlPFLliuj0b8kt9e9rL8Hg/EfxGvi3xzrmrxNG1vcXBWB41ZQ8SAJG2G5BKKpOcck8DpRXL0VmctWpKrOVSW7d/vJJJHDsAzdT3pvmP/fb86KKDMPMf++3504SPsY7m6jv9aKKAG+Y/wDfb86PMf8Avt+dFFAB5j/32/OnSSOHYBm6nvRRQA3zH/vt+dHmP/fb86KKAHCR9jHc3Ud/rTfMf++350UUAHmP/fb86PMf++350UUAOkkcOwDN1Pem+Y/99vzoooAPMf8Avt+dOEj7GO5uo7/WiigBvmP/AH2/OjzH/vt+dFFAB5j/AN9vzp0kjh2AZup70UUAN8x/77fnR5j/AN9vzoooAcJH2MdzdR3+tN8x/wC+350UUAHmP/fb86PMf++350UUAOkkcOwDN1Pem+Y/99vzoooAPMf++3504SPsY7m6jv8AWiigBvmP/fb86PMf++350UUAHmP/AH2/OnSSOHYBm6nvRRQA3zH/AL7fnR5j/wB9vzoooAcJH2MdzdR3+tN8x/77fnRRQAeY/wDfb86PMf8Avt+dFFADpJHDsAzdT3pvmP8A32/OiigA8x/77fnThI+xjubqO/1oooAb5j/32/OjzH/vt+dFFAB5j/32/OnSSOHYBm6nvRRQA3zH/vt+dHmP/fb86KKAHCR9jHc3Ud/rTfMf++350UUAHmP/AH2/OiiigD//2Q==",
	"kaget": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4lkkcOwDN1Pem+Y/99vzok/1j/U167dXUHwatrOwsLOMfEUJ5l/qMmJl09ZAGWGJWGwuU27nw2N7gMd3y3XruDUILmlLZbbbtvolpd2e60ZVGippzm7RW7/Rd2+iutnqYGlfBj4g6zbtPbeHL1EVyhF26WzZwDwsrKSOeoGOvoavj4B/Ejaf+JA2cj/l+t/8A45XFaprOpa5cLcapqF3fXCoI1lupmlYKCTtBYk4ySce5qjWfssa9faRX/brf486/I158GtOST/7eS/Dkf5noX/CgviT/ANABv/A63/8AjlH/AAoL4k/9ABv/AAOt/wD45XntFHssb/z8j/4A/wD5MPaYP/n3L/wNf/IHoX/CgviT/wBABv8AwOt//jlK/wAA/iQWbGgNjPH+nW//AMcrzyij2WN/5+R/8Af/AMmHtMH/AM+5f+Br/wCQPQv+FBfEn/oAN/4HW/8A8co/4UF8Sf8AoAN/4HW//wAcrz2ij2WN/wCfkf8AwB//ACYe0wf/AD7l/wCBr/5A9DHwD+JG0/8AEgbOR/y/W/8A8cpP+FBfEn/oAN/4HW//AMcrz2ij2WN/5+R/8Af/AMmHtMH/AM+5f+Br/wCQPQv+FBfEn/oAN/4HW/8A8co/4UF8Sf8AoAN/4HW//wAcrz2ij2WN/wCfkf8AwB//ACYe0wf/AD7l/wCBr/5A9Df4B/Egs2NAbGeP9Ot//jlJ/wAKC+JP/QAb/wADrf8A+OV57RR7LG/8/I/+AP8A+TD2mD/59y/8DX/yB6F/woL4k/8AQAb/AMDrf/45Sj4B/Ejaf+JA2cj/AJfrf/45XnlFHssb/wA/I/8AgD/+TD2mD/59y/8AA1/8gehf8KC+JP8A0AG/8Drf/wCOUf8ACgviT/0AG/8AA63/APjlee0Ueyxv/PyP/gD/APkw9pg/+fcv/A1/8gehf8KC+JP/AEAG/wDA63/+OUr/AAD+JBZsaA2M8f6db/8AxyvPKKPZY3/n5H/wB/8AyYe0wf8Az7l/4Gv/AJA9C/4UF8Sf+gA3/gdb/wDxyj/hQXxJ/wCgA3/gdb//AByvPaKPZY3/AJ+R/wDAH/8AJh7TB/8APuX/AIGv/kD0MfAP4kbT/wASBs5H/L9b/wDxyk/4UF8Sf+gA3/gdb/8AxyvPaKPZY3/n5H/wB/8AyYe0wf8Az7l/4Gv/AJA9C/4UF8Sf+gA3/gdb/wDxyj/hQXxJ/wCgA3/gdb//AByvPaKPZY3/AJ+R/wDAH/8AJh7TB/8APuX/AIGv/kD0N/gH8SCzY0BsZ4/063/+OUn/AAoL4k/9ABv/AAOt/wD45XntFHssb/z8j/4A/wD5MPaYP/n3L/wNf/IHoX/CgviT/wBABv8AwOt//jlKPgH8SNp/4kDZyP8Al+t//jleeUUeyxv/AD8j/wCAP/5MPaYP/n3L/wADX/yB6F/woL4k/wDQAb/wOt//AI5R/wAKC+JP/QAb/wADrf8A+OV57RR7LG/8/I/+AP8A+TD2mD/59y/8DX/yB6F/woL4k/8AQAb/AMDrf/45Sv8AAP4kFmxoDYzx/p1v/wDHK88oo9ljf+fkf/AH/wDJh7TB/wDPuX/ga/8AkD0L/hQXxJ/6ADf+B1v/APHKP+FBfEn/AKADf+B1v/8AHK89oo9ljf8An5H/AMAf/wAmHtMH/wA+5f8Aga/+QPQx8A/iRtP/ABIGzkf8v1v/APHKT/hQXxJ/6ADf+B1v/wDHK89oo9ljf+fkf/AH/wDJh7TB/wDPuX/ga/8AkD0L/hQXxJ/6ADf+B1v/APHKP+FBfEn/AKADf+B1v/8AHK89oo9ljf8An5H/AMAf/wAmHtMH/wA+5f8Aga/+QPQ3+AfxILNjQGxnj/Trf/45Sf8ACgviT/0AG/8AA63/APjlee0Ueyxv/PyP/gD/APkw9pg/+fcv/A1/8gehf8KC+JP/AEAG/wDA63/+OUo+AfxI2n/iQNnI/wCX63/+OV55RR7LG/8APyP/AIA//kw9pg/+fcv/AANf/IHoX/CgviT/ANABv/A63/8AjlH/AAoL4k/9ABv/AAOt/wD45XntFHssb/z8j/4A/wD5MPaYP/n3L/wNf/IHoX/CgviT/wBABv8AwOt//jlK/wAA/iQWbGgNjPH+nW//AMcrzyij2WN/5+R/8Af/AMmHtMH/AM+5f+Br/wCQPQv+FBfEn/oAN/4HW/8A8co/4UF8Sf8AoAN/4HW//wAcrz2ij2WN/wCfkf8AwB//ACYe0wf/AD7l/wCBr/5A7XVfgz8QNGtBPc+HL2RWkCAWrpcvnBPKxMxA46kY6eorgPMf++351saXrOpaHcNcaXqF3Y3DIY2ltZmiYqSDtJUg4yAcewr0W1uoPjLbXlhf2cZ+IpTzLDUY8QrqCxgs0MqqNgcJu2vhc7EBYbfmmVXEYdc1e0o9Wrq3m029F1d9O3ZxpUK75aN4y6J638k0lr2Vte/fyLzH/vt+dFNortOI9A+DGlQ6z8V/DltO0ipHctcgxkA7okaVRyDwWQA+2enWuZ1nVJtc1jUNUuFjW4vriS5kWMEKGdixABJOMn1Ndr8Awv8AwuDQOTnNz2/6d5a88rkpa42pfpGP4ud/yR2T0wcPOUvwULfmz6j/AGfPFvgvRvB0ltNfWGl60JSb17yVYjcfM3llWY/MoXjA6HccDdlvW/8AhYfhD/oa9C/8GEP/AMVXwDRXjYzhelia8q7qNOTv3/ryPXwvElXD0Y0VTXuq3Y+/v+Fh+EP+hr0L/wAGEP8A8VR/wsPwh/0Nehf+DCH/AOKr4Borm/1Oof8AP1/cjo/1srf8+197Pv7/AIWH4Q/6GvQv/BhD/wDFUf8ACw/CH/Q16F/4MIf/AIqvgGij/U6h/wA/X9yD/Wyt/wA+197Pv7/hYfhD/oa9C/8ABhD/APFUf8LD8If9DXoX/gwh/wDiq+AaKP8AU6h/z9f3IP8AWyt/z7X3s+/v+Fh+EP8Aoa9C/wDBhD/8VR/wsPwh/wBDXoX/AIMIf/iq+AaKP9TqH/P1/cg/1srf8+197Pv7/hYfhD/oa9C/8GEP/wAVR/wsPwh/0Nehf+DCH/4qvgGij/U6h/z9f3IP9bK3/Ptfez7+/wCFh+EP+hr0L/wYQ/8AxVH/AAsPwh/0Nehf+DCH/wCKr4Boo/1Oof8AP1/cg/1srf8APtfez7+/4WH4Q/6GvQv/AAYQ/wDxVH/Cw/CH/Q16F/4MIf8A4qvgGij/AFOof8/X9yD/AFsrf8+197Pv7/hYfhD/AKGvQv8AwYQ//FUf8LD8If8AQ16F/wCDCH/4qvgGij/U6h/z9f3IP9bK3/Ptfez7+/4WH4Q/6GvQv/BhD/8AFUf8LD8If9DXoX/gwh/+Kr4Boo/1Oof8/X9yD/Wyt/z7X3s+/v8AhYfhD/oa9C/8GEP/AMVR/wALD8If9DXoX/gwh/8Aiq+AaKP9TqH/AD9f3IP9bK3/AD7X3s+/v+Fh+EP+hr0L/wAGEP8A8VR/wsPwh/0Nehf+DCH/AOKr4Boo/wBTqH/P1/cg/wBbK3/Ptfez7+/4WH4Q/wChr0L/AMGEP/xVH/Cw/CH/AENehf8Agwh/+Kr4Boo/1Oof8/X9yD/Wyt/z7X3s+/v+Fh+EP+hr0L/wYQ//ABVH/Cw/CH/Q16F/4MIf/iq+AaKP9TqH/P1/cg/1srf8+197Pv7/AIWH4Q/6GvQv/BhD/wDFUf8ACw/CH/Q16F/4MIf/AIqvgGij/U6h/wA/X9yD/Wyt/wA+197Pv7/hYfhD/oa9C/8ABhD/APFUf8LD8If9DXoX/gwh/wDiq+AaKP8AU6h/z9f3IP8AWyt/z7X3s+/v+Fh+EP8Aoa9C/wDBhD/8VR/wsPwh/wBDXoX/AIMIf/iq+AaKP9TqH/P1/cg/1srf8+197Pv7/hYfhD/oa9C/8GEP/wAVR/wsPwh/0Nehf+DCH/4qvgGij/U6h/z9f3IP9bK3/Ptfez7+/wCFh+EP+hr0L/wYQ/8AxVH/AAsPwh/0Nehf+DCH/wCKr4Boo/1Oof8AP1/cg/1srf8APtfez7+/4WH4Q/6GvQv/AAYQ/wDxVH/Cw/CH/Q16F/4MIf8A4qvgGij/AFOof8/X9yD/AFsrf8+197Pv7/hYfhD/AKGvQv8AwYQ//FUf8LD8If8AQ16F/wCDCH/4qvgGij/U6h/z9f3IP9bK3/Ptfez7+/4WH4Q/6GvQv/BhD/8AFUf8LD8If9DXoX/gwh/+Kr4Boo/1Oof8/X9yD/Wyt/z7X3s+/v8AhYfhD/oa9C/8GEP/AMVR/wALD8If9DXoX/gwh/8Aiq+AaKP9TqH/AD9f3IP9bK3/AD7X3s+/v+Fh+EP+hr0L/wAGEP8A8VR/wsPwh/0Nehf+DCH/AOKr4Boo/wBTqH/P1/cg/wBbK3/Ptfez7+/4WH4Q/wChr0L/AMGEP/xVH/Cw/CH/AENehf8Agwh/+Kr4Boo/1Oof8/X9yD/Wyt/z7X3s+w/jD428C6j4B1S2uNT03VbiRCLOG0nSaRLjadkg2tlQp5J4GMjndtPyVo2qTaHrGn6pbrG1xY3EdzGsgJUsjBgCAQcZHqKo0V7uW5VTwFGVFSck+54uY5nPG1Y1nFRa7HY/GvSodG+Kfia2gaRke4FyTIQTulRZWHAHAZyB7Y69aK0P2gAv/C3PEWSc/wCj9v8Ap3jorTLm5YSjJ7uMfyRjmCUcXVS2UpfmxfgF/wAlh0D63P8A6Ty157XoXwC/5LDoH1uf/SeWvPadH/fan+GH5zHU/wBzp/4p/lAKKKK7ziCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiuh0XRbU2P8Aa2ree2nNK1vDBbSBJbiRQpYbyrBFUOhJKkksoA5Zkmc1Ff1qVGLkznqK7b+1tH/6E7Rf+/17/wDJFH9raP8A9Cdov/f69/8Akio9pP8A59v/AMl/zL9nD+dfj/kcTRXbf2to/wD0J2i/9/r3/wCSKP7W0f8A6E7Rf+/17/8AJFHtJ/8APt/+S/5h7OH86/H/ACOJortv7W0f/oTtF/7/AF7/APJFH9raP/0J2i/9/r3/AOSKPaT/AOfb/wDJf8w9nD+dfj/kcTRXbf2to/8A0J2i/wDf69/+SKP7W0f/AKE7Rf8Av9e//JFHtJ/8+3/5L/mHs4fzr8f8jiaK7b+1tH/6E7Rf+/17/wDJFH9raP8A9Cdov/f69/8Akij2k/8An2//ACX/ADD2cP51+P8AkcTRXbf2to//AEJ2i/8Af69/+SKP7W0f/oTtF/7/AF7/APJFHtJ/8+3/AOS/5h7OH86/H/I4miu2/tbR/wDoTtF/7/Xv/wAkUf2to/8A0J2i/wDf69/+SKPaT/59v/yX/MPZw/nX4/5HE0V2o03S/FMsdlp+mJpesTMI7ZLeZ2tp2JwsbCQsyOxOA+/bkKCqgs44qqhPmbTVmun/AA1yZw5UmndBRWzpWlQPa/2hqHmmyMjQxxQOFkmcAFvmIIUKGUkkHOQAOpXT+2aZ/wBC5pv/AH9uf/j1Eqii7HDPFqMrRi5elv1a/rzOTorrPtmmf9C5pv8A39uf/j1H2zTP+hc03/v7c/8Ax6p9tEj65/07l/5L/wDJHJ0V1n2zTP8AoXNN/wC/tz/8eo+2aZ/0Lmm/9/bn/wCPUe2iH1z/AKdy/wDJf/kjk6K6z7Zpn/Quab/39uf/AI9R9s0z/oXNN/7+3P8A8eo9tEPrn/TuX/kv/wAkcnRXWfbNM/6FzTf+/tz/APHqPtmmf9C5pv8A39uf/j1Htoh9c/6dy/8AJf8A5I5Oius+2aZ/0Lmm/wDf25/+PVS1HS7W6tZ77To3h+zgPc2zvuCqWCh0YjO3cwXacsMg5bLFXGrFuxUMWm0pRav3t+jZgUUUVodh3/7QP/JXfEX/AG7/APpPFRR+0D/yV3xF/wBu/wD6TxUV5uWf7lR/wx/JHdmP++Vv8UvzY/4Bf8lh0D63P/pPLXnteh/AN2Pxg0AbjjNzxn/p3lrzyrpf77U/ww/OYqn+50/8U/ygFFFFd5xBRRRQAUVLb2815cRW9vFJNcTOI44o1LM7E4CgDkknjFe02/wd0PwJYW2sfEjV/K83LQ6RYZaWdlCsUZx/wJG24UEqfMGRXLisbSw1lN3k9ktW/Rf0jpw2Dq4i7hst29EvVnkeheH9U8TaglhpFhPe3b4PlwpnaCQNzHoq5YZY4Azya9S0/wDZz12O0j1DxJq+k6Bpwz57zzB3g5KrnGIzuO3/AJafxevFO1L443WmW6aX4E0q08O6TE4KlYklnnIBUM+4FclQmchmyv3zXm2o3+q67cLcapf3V5OqBFlu5mlcLknALEnGSTj3rltmGId1alH/AMCl/wDIr8Tq/wBgoKzvUl/4DH/5J/gepDwJ8INJ/wBD1Xx3f3V/F/rJrCPMDZ5G3bFIOhAPznkHp0C/8JB8Dv8AoTdc/wC/z/8AyRXkos1xyxJ9qeLaPH3f1qv7JlLWpXm3/i5fwil+tif7TUdKdGCX+G//AKU2er/8JB8Dv+hN1z/v8/8A8kUh8LfBfWebPxVq2mXd7/qYLhCYrV3+6rkx42qSASZOg+//ABV5T9mi/u/qaYbRccMwPvR/ZDjrCvUT/wAV/wD0pMP7UT+OjB/9u2/Kx6nc/s639/by3fhXxLo2vWcSEM0cmxmlAz5Y2l0zgryzD73OByfMfEvg/XfB12trrmmT2Ur/AHGcApJgAna4yrY3DOCcZweaSzmvtJu47vT7ua2uo87JreQxyLkEHDA5HBI6969D0P46a9awHTvElra+JNHZER7W/jXcQo+X59p3HdtJLhydvYnNS4Zjh3dNVY9vhl8n8L+dvkVzYCurWdN/+BR+a+L8zyKivc0+GHg34nJNP8PtVk03Uok3y6PqYYhV3Bch/mIHBYkGTl1B2ZxXjWsaPfaBqdzpmp20lrfWr7JYpOqn+RBGCCOCCCMg10YbHUsQ3CN1Jbxas18v1V15nPicFVw6U3Zxe0k7p/12dmUaKKK7DkCiiigArttW/wCRf8Hf9gyT/wBLbmuJrtdTIl8N+EZEO6NLGWBmXkLILudyhPZgskbY64dT0IrKp8dP1/8AbWa0/gn6f+3Ip6Np/wDa2r6fp/meV9ruI4PM27tm5guccZxmu9ufhVBLrmr6BpOtvda5pqGQ209p5KzgAEiNw7ZPI4IFcNoF/HpWu6XfzK7Q2l1FM4QAsVVwTjPfAr0qT4laBpvi7WvFmlw6lcateoyW8N1FHFFbllALEq7Fzx0wOv41yY+eLjUth725XbRWcrq129la99V9514KGFdO9e3xa6u/LZ3t3d7d/uOUtvBMFv4Zstf1zU3sLPUJWitY4bbz5ZNpwzkFlAUH3J9q27L4QTzeKH0i51VI7VtOOp297DD5gniyMYUsuDz3Pb3zWf8A8JdpOueD9K0DXVvoJNJldre7s40lLo5yyMrMuD0wQe3SulsPi5pieLFvZ7K8h0a10g6VaxRBZJQuVwzZZRnjsfT61y16mYpS9ne/vdFZK/u201bW979dtDoo08A3Hntb3ervt71+yT226b6nHXfghJfDEniLRNQbULCCZbe4jlt/JmhZsbSVDMCCSBkN1P1xrP8AC+3tNcsvDt9ry2/iK7jVhAtsXgjdhlY3l3ZDHjopHPWqr+MtO0XwddeHdAS8ka+uEnur28RYydhBVVjVmwMqDkse/rxsXXxB8O6r4tsPF99aakmrWyxvJZQqhgllQYVhIW3KOBxtPTrVTqY/W1+X3rOyu9Fy3VtFfm6LpexMIYLS9r+7dXdlq+azvq7W6vra5kWHwyuzper6jqctzBFpl6bCWKytftUvmAZY7dygIMj5s96ZoPgXTtch8S3ia3MunaJCkxlSxzJMGByNjSLtIII6n61b0f4htb6pqWrvrOsaXqN9dtcSR2MEc8DocEAo7ryORk54x71vxfFzS5dZ8Z3vlajph1yGGK3msUVpYSgIMjfOnzHIPB/HvU1auYrmSXbZbaxutYu+nNZpv0vYunTwD5W33366Ss9Gra20aXruc3d/Cu9OveHtM028S6XXbZbqCSWMxNGhGSZFy2MD0Jz2qJfh/aalb62dC1s393oyNLPBJa+SJI1OGaJt7bgPcKa3Ln4twWviHwvqllbXN5No9u1vc3V7tSe9Vhg7sFsY5IyTyeffOsfGegeGIvEU2gw6jLfaxC9sgu0REtY3OWwVZi56YOF6URqZjyq6d7K2i1fM783Zctn069dBSp4DmdmrXd9XouVWt396669OmpBa+B9Cu/Cd74lTXtSFjZ3C20kZ0tPMLNjBA+0Yx8w7iuJS1N3fra2QkmMsojh3KFZ8nC5AJwTxxk/Wuq0/xbZWnw21bw08Vwb68vUuUkVV8sKoXIJznPyntVTwBrel+G/FFnq2rQXE8FnukjigVSWlx8mckYAPOfYcV20pYmnCtKd5NN8q01VlbZLd3OOpHDzlSjC0U0uZ66O7vu30Nj4ifDCTwHa2VymppqMM8jQTNHFsEEqgHYfmOcgn06dKyPHvg7/hB9cTTPtv2zdbpP5nleXjdnjGT6dc10Nx8S7PXPDHiLSdX0tIJtQmF9by2O9gLrOWZ/NlOAQAPl6Anisj4m+LbLxn4ij1GwiuI4FtY4Stwqq25c56EjHPrWGCnjueEMR05ruy1+Fx29WtO2pvi4YLknOh15bK703T39E9e+hxtWPiH/yP/iv/ALCt1/6Oao7e3lu54oIInlnlYJHHGpZnYnAAA5JJ7UeO7iG88b+Jbi3ljmt5tSuZI5Y2DK6mViGBHBBHOa9Cp/Hj6P8AOJwQ/gy9V+TLl5/yBvDn/Xk//pTPVKGGS5mjhhRpJZGCIijJYk4AFXLkh9D8Pup3IlrJEzDkBxcSsVPvtdDj0YHuKf4f1T+w9d03UjH5gs7hJin94KwOK55/Ezw02ozcVd3l+bO+uPgN4og0k3gazkuFXebNJCZPoDjaT7Z/GvOdO0+41TULawtk3XNzIsUanjLE4H0r6ouPjJ4Rh0o3yakJX2ZW1VGEpb+7jHH16e9fMVjr0+n+I4dbiRPPiuftIT+HO7dt+naoR5GVYvHV41PrELNbXVtddDq0+GsF1rd34fs9cWfX7ZGYwG2KwyOoyyLJuySOeqgcVCnw0uZvAX/CUQXe+VC5ksTFhlRHKswbPOOCRgYB9q07fx54f03xXe+LLO11BtUnV2js5VQQxSuMMxkDZYcnjaOvWodO+JcemaH4cto4Z5LvT7qeW8V1Xyp4pS25BzzkN3HWjUpzx9o8n9290uz5l6Xsr+e7FX4UbvEzaL/a/wB3TP7R877N9Pk27/frn8K5zwT4S/4THU7qy+2fZfItZLnf5e/dtx8uMjrnrXdP8UdCPjqfWUtdQTTn0o6eqeWhkVs9cb8Yx75rnfBviTQPBusXF5HPqd5FcWU1uwazjiZWYrtI/etkcHPTHHXsDhVxvspcyfNyq2i31v0t23+RFF8N7i68AL4qtr0SuC7PZeVhljRyrOG3c44J46GtGL4UK/ik6I2sFVGmjUTOLXJxx8m3f79c/hUWk/EeDRvD3hmxt4J3uNMuZnukdV8qeGQncg5ycg9x1rd/4Wpoa+PJdcit9RisDpf2FFWNPNRsjBxvxgAeuaNSKlTME5qK0962i7+6vu1Xe+ux5ZqUWmRGP+zru7uAc7zc2qw7fTG2R89/SpdC/wCPq6/68Lz/ANJpKs+JNTXU3t3Gt6tqrICC2pR7TGOMBf3r5zznp071W0QhJr2VjtjSwu9zngLugdFye2WZVHqWA6mqjuj05NvDu+9n/Wy/I5Ciiiu09w7/APaB/wCSu+Iv+3f/ANJ4qKd+0A7D4ueIgGIH+j9/+neOivNyz/cqP+GP5I7sx/3yt/il+bF+AX/JYdA+tz/6Ty157XoXwC/5LDoH1uf/AEnlrz2ro/77U/ww/OYqn+50/wDFP8oBRRRXecQVt+E/CeqeNdbg0jSIPNuZfmZm4SFB1dz2UZH5gAEkA0tH0e+1/U7bTNMtpLq+un2RRR9WP8gAMkk8AAk4Ar3DxXrcPwW8OQ+DPDgjTxJe26TavqkUgZ0Yg/Ih4KnrtyBtVgQCzlhwYzFzpyjQoK9SW3ZLrJ+S/F6HdhMLGadas7U4792+y83+C1C+8QeGfghb6no3hRpNT8YyosN1q06qY7Y4+dEHqGGdnIBI3MxTbXj2pX9/4i1K51PU7mS4vLl98k0nVj7dgAMAAcAAADAqrBbggO3TsKsvIsYyx/D1rXB4CGGvUk+ab3k93/kvJaGeKxs8RaCXLBbRWy/zfmCRrGMKP/r0PIkf3mAqlJdO/A+Ue3WoK63VS2OdUu5eN5GDj5j7gUz7b/0z/WqlFQ6sivZxLf23/pn+tPF4hxkMKo0Ue0kHs4mmkqP91gT6U5lDjDAEVlVLHcPHxnK+hq1V7kul2LKCexniubSWSOeFw8ckbFXRgchgRyCDzkV7BpXxE0L4maZbeHPiR5iXi3GbTXLdUiMW7qHOMIDgKTtKkEFgpXfXkcUyyjIPPcVHPbhsuvB7j1rmxeBpYpJvSS2kt16P81szfC4yphm0tYvdPZ+q/XdGv8Qvh7qnw61s2F+PNtpcta3iLhLhB3HowyNy9s9wQTyVe5fDLxfZ+MdPi+HPjFPtOm3PyadeM4WW0kAOxQx/JOpydmGVsDyjxZ4T1TwVrc+kavB5VzF8ysvKTIejoe6nB/IggEEDmweKqc7wuJ/iR1v0ku6/VdH5G2Lw0ORYnD/A9LdYvs/0fVGJRRRXonAFbei68ljC9jqFs97pTsZPISURSRSYA3xuVYKSAAwKkMAMjKoy4lFTKCkrMcZOLujsvM8If9BjXf8AwUQ//JVHmeEP+gxrv/goh/8AkquNoqPZ1P8An4//ACX/AORNPaQ/59r/AMm/zOy8zwh/0GNd/wDBRD/8lUeZ4Q/6DGu/+CiH/wCSq42ij2dT/n4//Jf/AJEPaQ/59r/yb/M7LzPCH/QY13/wUQ//ACVR5nhD/oMa7/4KIf8A5KrjaKPZ1P8An4//ACX/AORD2kP+fa/8m/zOy8zwh/0GNd/8FEP/AMlUeZ4Q/wCgxrv/AIKIf/kquNoo9nU/5+P/AMl/+RD2kP8An2v/ACb/ADOy8zwh/wBBjXf/AAUQ/wDyVR5nhD/oMa7/AOCiH/5KrjaKPZ1P+fj/APJf/kQ9pD/n2v8Ayb/M7LzPCH/QY13/AMFEP/yVR5nhD/oMa7/4KIf/AJKrjaKPZ1P+fj/8l/8AkQ9pD/n2v/Jv8zsvM8If9BjXf/BRD/8AJVHmeEP+gxrv/goh/wDkquNoo9nU/wCfj/8AJf8A5EPaQ/59r/yb/M62bX9K0dS2g/bp9R/g1C8RITb/APXOJWf94McSF+NxwoZVcclRRVQgo63u+5E5uWmy7GpperrZxtbXcLXNgzb/AClk2Oj4+8jEHaTgA8EEAZGQpXU8/wAO/wDQQ1X/AMF8f/x+uXoolTjLVnJUwsZS5k2vS36pnUef4d/6CGq/+C+P/wCP0ef4d/6CGq/+C+P/AOP1y9FL2USPqf8Aff4f5HUef4d/6CGq/wDgvj/+P0ef4d/6CGq/+C+P/wCP1y9FHsoh9T/vv8P8jqPP8O/9BDVf/BfH/wDH6PP8O/8AQQ1X/wAF8f8A8frl6KPZRD6n/ff4f5HUef4d/wCghqv/AIL4/wD4/R5/h3/oIar/AOC+P/4/XL0UeyiH1P8Avv8AD/I6jz/Dv/QQ1X/wXx//AB+qGpaxC0D2emxyxWr486SVgZLjB4zjhVyA2wE89WbC4xqKapxTuVDCxi1KTbt3t+iX4hRRRVnUd/8AtA/8ld8Rf9u//pPFRR+0D/yV3xF/27/+k8VFebln+5Uf8MfyR3Zj/vlb/FL82SfAML/wuDQOTnNz2/6d5a88r0L4Bf8AJYdA+tz/AOk8tee1dL/fan+GH5zFU/3On/in+UAoorqfh34Om8deLtO0ZBILeR/MupUz+6hXl2zggHHygkY3MoPWuurVjRhKpN2SV2ctKnKrNU4K7eh6f4EttP8AhT8P/wDhOdRtoJfFOp7k0e2uSwKxnClwu0EZBLFs4KFAGXec+O7pr65lurqSSaWVy7ySMWaRyckknkknkmu3+L/iyLxZ4va104xpoWkL9hsY4cCIKvDOoBK4JHBXGUVOOK49VCKFHQVyZXQlyvE1vjqavyXSPyX4tnZmNaPMsPS+CGnq+svm/wALCSOI0LH/APXWa7tIxZjzU94+XCA8Dr9arV21JXdjkpxsrhRRRWZoFFFFABRRRQAUUUUAKrFSCDgitGGUSpnjd3FZtTWr7JQM8NxWlOVnYznG6JrmH+NR9a9pAtPjV8N5vMjjbx74bt8RFXdpr23THLDBLlssMDJEmDlRJg+QEZGD0rX8B+K5vAXjCw1ZDI1vG2y5jTOZYG4cYyASByATjcqk9K5czwsqtNVKXxw1j/l6PZnRl+IjTm6dX4J6P/P1W6OKor0T4zeDofCvi6S404RtoWsJ9usZIcGLa3LIpUBcAnIC5wjJzzXndbYavHEUo1obNf19xhiKEqFWVKe6Ciivavgb+z9/wujQ/F2p/wDCRf2T/wAI9HHJ5f2Lz/P3LI2M+Yu3Hl46Hr7Vs3bVmR4rRXuvw2/ZsufFfgPUvHnizxFF4Q8JWqb4Ly5tDO91zglI96HGeAckseADXiN4lvHdzpZzSzWiuwilljEbumeCyhmCkjtk49TQmmBBRRRQAUUUUAFFegfCD4Qa58avEt1oGgXWnW15bWb3zvqEjpGUV0QgFEY5zIvbGAea4rVNPl0nU73T5mRprSZ4HZCSpZWKnGccZFF+gFSit3wZ4T1Dx34q0nw3pQj/ALQ1SdYIjK21FJ6sx9AMk4BPHQ1618SfgB4a+HZ1bTJfinpU/i3SrcTz6PNp80G7MYcJHMSVZypGBxnI6Um0tAPCKKK7f4d+GPBniRtRHi/x5/wiawCP7Mf7Imv/ALTndu/1ZGzbhevXd7U3oBxFFfU/ij9lPwP4L8LaL4n1z4x/ZND1tY2sbn/hGZ5PODx+YvypKWXK8/MB+dfN3iaw0vS9ev7PRdY/tnSoZNtvqH2Zrf7QuPveW3zL9D6UlJPYLGTRRVnT7T7ff2tpv2faJUi3Yzt3EDOPxpgVqK9a/aB+CX/Ci/FOm6H/AG7/AGz9tsheef8AZPs+zMjpt273z9zOc9+leS0J31QBRRXpWlfDXw/qHwj1XxnP490u116ym8qLw1II/tNyu5F3rmUNjDseEP3D+A3YDzWiiigAor0v4x/BDxB8EdS0yw8QXml3U2owtPE2nyyOqqrbTu3onOfTNeaUJ32AKKKKACiiigAooooA9B/aAC/8Lc8RZJz/AKP2/wCneOim/tA/8ld8Rf8Abv8A+k8VFebln+5Uf8MfyR3Zj/vlb/FL82P+AX/JYdA+tz/6Ty157XoXwC/5LDoH1uf/AEnlrz2ro/77U/ww/OYqn+50/wDFP8oBXu/wdkj8IfDDxx40Rv8ATxiwtmSBWeB8LtYFjypeaMlcf8swfm4FeEV7j8Qx/wAI/wDBT4d6D/r/ALdu1Lz/ALuzKl9m3nP/AB84zkfc6c8Y5qvaqlhf55K/ovef5f1sbZY/ZOpif5Iu3q/dX5nkNomSzkdOBVuo4F2xL055qSvbWx5LIJII3kyzEM3ak+xx+rfnUd63zIvcDNdV8LdU8O2Hj7w9ceMVlfw5BdpJdeXEsvA5XehB3x7gu8AElNwAJxWMpRTd0axjJpWZ9C/BH9kHS/HHguDxJ4t1HVrP+0v3lla2W2J1hBIDyGSNs7+GXaMbcHJ3YX0r/hhj4d/9BnxT/wCBVv8A/GK+jtH1az1/SLDVtOm87T9QgjubeXaV3xuoZWwwBGQQcEA1drxJ4io5N3setGhBJK1z5k/4YY+Hf/QZ8U/+BVv/APGKP+GGPh3/ANBnxT/4FW//AMYr6boqfb1O5XsYdj5k/wCGGPh3/wBBnxT/AOBVv/8AGKP+GGPh3/0GfFP/AIFW/wD8Yr6boo9vU7h7GHY8a+Hv7Lnw68A/2jnTf7f+2+X/AMjBBb3fkbN3+r/dDbu3c+u1fSuwu/hV8NbK0nuZfAHhpo4I2kYQ6FDK5AGTtRYyzHjgKCT0AJrtlwGGelSbk9vyrppVpOOsl8zlrUoqWifyPzK/aP1TwB4k8cafd/D2Gxh0VNNjilWwsDZxmcSyliUKLk7SnzY6YGeK8fW2jWRcM24c4r6h/ad+I3wj8YeEbc+BDpcniaXVlubu4t9Ie2nkiMcu9mlaJd2XZCQSSTz2zXyxaN++5ySwNenFx0VjhalZu5eqvdplA2OR/KrFNdd6MvHI71uzJHrmsyR+NP2dLO/nb/T/AAtdLbGV4Fy6ZVBGrA8Lsliye5i5B4avB69y/Z+H9sjxp4V/1X9s6W3+lfe8nGY/ucbv9fnqPu478eG14mXL2Navhlspcy9JK9vvuetmD9rSo4jq48r9Yu35WCvuH9gWW3t/DfxPlvE8y0jFq0yYzuQJOWGO/Ga+Hq9Q+FPx38R/B/SvEem6HZaVcQa+iJctfRSOyBVdRs2SKBxIeoPQV6c1dWPMWjPpH9r7RNc+IPgfw7408GapHqnw0tLYMdPsU2rakZHnFR1AHyEEAx4IwMtjgv2YNB8eWHgvxZ4v0b4gWfgnwhbyql/eTabHfPK8S7uI3UkBRKOhGS2MHHHl/wAJP2gvF/wag1G00U2N7pV+P3unapG8tvu6FwqspDEcHnBHUHAxd8GftH+JvAf/AAkNppGj+Hf+Ee12Vp7jQbm0eWxR2UK2xGk3AEAAqWIwAMYAqeVpWHfqfSvxxsNF8ffstS+MZtdtPFerabdR/Z/EiaOdOkmBuVhZTGedoDkHHBKg4yKh/aS8UzfAXQ/AXgfwbo+lt4avbdzewXFlHOuphSilGJB5bcSWHzZYYIr518S/tM+L/FXw41DwHfWOhR6JeSK4NrZtC9uqyrIscSq4jVAUAxs6ZySTmvbfA/jXV/EfgHwxp9/8Uvhh9isYYyt3r8H/ABOdJYAAiFZPkZ0Awr9TgHNLla3Hc9M+O/g7R/HH7Q/wZ0HW4g+lTW97JLbueJfKTzFjPsSgB9RmpvE/xS8CeDPiJqnh/wAT/ELSIfClon2WXwU3g6UxxAxjaRcKp3HkNwCpBwAOo+c/2qfjrp3jP4l+Hb/wNqUxTwxFiDVIsoXnL7iyZ5Kjaoyepz1GCcG//a08V6uYrnVfC3gbUtZiQIur3miLJdjHQ7i20evC49qSg2kFz3D9kfxPZRfHLx94V8H6kZ/h3Lb3Gq2MBg2/P5tuitl1EgCo7JgnHGSM818yfGz4r+L/AIjeI7iw8Tav9vtdFvbqOyj+zQxeSpcAjKIpbhF+9np9aoeDfjP4r8DfEK98dabcWza3ftM12JoB5M4lbe6lFxgbgDhcYwMVF8TvijcfFG+tb268M+GdFuYTI0smh2BtjdM5BLTEsxdsjgn+8fWrUbSuK+h61+xd8PtN8V+PtR8Rak1xIPCcCX9va27lXmnLHYeDkgbT8vclQeMg+s634U8MftpaHp/ivw+IdF8baXcRWur2U0md1sX6sQAThcsjY5wyHoCPjz4d/EnxH8LPESa74Zvvst6EMUisoeOaMkEo6ngjIB9QQCCDXrVv+2N43028kvNG0Dwbo11cSrLeS6dpHlvekHJErFyWzzkgg88EUpRd7oE0ct+0rofgzwv8V9S0HwNYpaaVpcUdvOqXEk4a5GTJ80jMcjcEIzgFD715FXXfEjx/P8TPE9x4ivNG0jS7+6GbhdKikjjnfvIyu7/Me5GM4yRnJPI1a2Efa/7Tyhv2X/gspYKDBYAk9v8AQa9V8fT+FvgHpfhHQdG8d6d4EsDEXkD+GH1NtXC7QxklXp15/i+YYIGK+I/Hnx38R/EPwF4Y8GapZaVDpfhxIUtZbWKRZnEcXlLvLSMp+Xk4Uc/lW7ov7UXjCw8MWPh3WdK8M+KtN08BbQeItNF00AAwu07hnA4BOT71nyOw7n0T4N1r4aeJv2tfDGtfDa5hkgvNNu/7Qjt7OW2jE4jbDhXReWUjO0YyuepOfHfjZ8YPEV58UfE/gezNnp/hQeINs1lbWcQa4lS4DGV5SvmFmdd33sdsY4rh9O/aL8V6b8RtN8cxWOhDUNMtHsbWySx8m0hhbflRHGynrIxyWzzXB+IfF994l8Z6h4ru4rdNRvr5r+SOJWEQkZ95ABJO3PuT71SjrqFz9RviR4N0s+Lbv4gWmlJ4k8ceHdFUaXobSKu0+ZKRNjqWJLBf9w4+YjHzp+yyB8YfH3j/AMfePjHqfiHR4oRaxXduZY7Pf5pJSD/Y8sAKOeT/ABHNeI67+1R481v4j6P48QaZp+saZaiyENlFItvcQ72cpKjSMWBLHOCOgIwQDVF/2j/F1t8R5vHmi2uj6FrV3H5d7HpsDi3vuckyxyO4LHAyRg5GeuSZUHaw7n0ZrfxX+Ffi3wL4m0Px58ULDxdd3UTNpU6eE7iwl0+Ta20Iyo2Ru24zjgEEsDxzXgf/AJML8c/9hE/+j7avIfEP7S3iDXLDU7a38K+CdHn1SGSC7vdL0VI7mZJFKvmRmY5YE8jmvVdZ13wx8Mv2S9T8BnxfoWveJtdulnSDRboXCQgyxOd7D7uFj5yB8xwM9aOWwrl39tGN5/AfwSWJS5ewmVQozkmK1wB9a1v22vFOseBviP8ADnXtDu/ser2FlO0E/lpJsYsFPyuCp4JHINeFW/7UnjiHwVpfhea20K8XSUVNP1O808TXlntG1GjdjtVlGAG27uOua5/4xfHDxD8bb/SrzxBZ6XbS6bC0MQ0+ORAwYgktvd8njtimotWuFz6v/bd+K/i/wRf6R4e0HV/sej65plxHfW/2aGTzlY7CNzoWX5SR8pFfAte3eKP2oPE/jfwmNB8S+HfCWrypaNaRateaaXvoAy4Lxyb8I/AOQo5AOK8RqoKysDdwoooqhBRRRQAUUUUAd/8AtA/8ld8Rf9u//pPFRR+0D/yV3xF/27/+k8VFebln+5Uf8MfyR3Zj/vlb/FL82SfAN2Pxg0AbjjNzxn/p3lrzyvQvgF/yWHQPrc/+k8tee1dL/fan+GH5zFU/3On/AIp/lAK9z/aPH9na94c0G2/d6Tpulp9mg6+Xl2Q/MfmPyxIOSfu+5z4ZXuf7Tn/I+6d/2C4//RstZYnXMMOvKf5R/wA2bYb/AHGu/OH5v/I8pUbVAHQDFVL1vmVfQZq5VC7bMxHoMV69X4TzKfxEFFFFcx0H64/CuzuNO+GHgqzvLeW3u7fRbKKaCZCjxusCBlZTyCCCCD0r5h8G2Vz+178S9fj13xPdad4P0oefaaLbyrHPJHl0idYzuTcu7Mkh3EF1QYDLt+y6+B/iT8AvHfwy8aXGs+BrTVJtKedm0+60NpDc2iyB/wByQrGUbVypflWBGSCxUefhJR5nfR9DtxEZcqSNr4X+Ltb+CPxvPw2uPEI13w018NL227GSKOSRv3bRqWxC4kkxKoJAPmA72VTX29XxH+zr+zr4ik8XaX4q8VaXLpmk6Y4ure2uwY57idSQnyAhowjqHy4G7CgBlYkfblTi3Bz935lYdSUfeCvlH43+Ltb+IXxj0r4QaT4hHh3S5ikF/dSsYxcSSxFyhIbMimN1RYztDyPtOflI+rq+Tf2oPgBrfifXT408KWX26aWALqNlGx85mjQ7ZkDN8+UVU2IA2VXAYs2JwriqnvDrqTh7pxHxV8Maj+yb8QNJuPBPiqWex1KMXLabdTBpCI/lK3MabVeNiz7HwpHzgYZN5+1/D2t2/iXQNK1q0SVLXU7WK7iSYAOqSIHUMASAcEZwT9a/Pvw18DPid8VPFJm12y1m08x4xfaxryyCRU2kAgSkPMQqbQFzj5QSoOa/QrSdLtND0qx0uwi8mxsYEtoItxbZGihVXJJJwABkkmtcY4u1ndmeGUknfY/HO8s7jTru4s7y3lt7u3kaKaCZCjxupwysp5BBBBB6VDXafGD/AJK149/7D1//AOlD1xddyd1c42rOxPaNiYD1GKv1mwNtmQ++K0q6aT0MKq1O8+AN9cWPxT02CCTbFdxzwTDAO9BGzgc9PmjU8enpmuA8Zafb6T4v8QWFnH5VpaahcQQx7i21FkYKMnk4AHWu3+Bn/JW9C+tx/wCiJK5H4h/8j/4r/wCwrdf+jmryY6ZnNLrCP/pUj0Za5dBvpOX/AKTE5uiituDwte3Hha48RRvAbO3uPs8ke4+aOF+fGMbcugznOWHFeqeYYlFdHqvgjV9Ln0m28n7Xd6nbC6it7RWkkUEkFWXH3gVOQM4rJj0fUZtQOnR2F0+oAlTarCxlyOo2Yzn8KAKVFaEGg6rdXk9nBpl7LeQAmWBIHaSMDruUDI/Gr174Ylt/Fcfh+GdJJ5JooElkUou59uMgZIALe9AGDRXTp4St31vTdKj8QafczXl5HZuLWKctDuYKWIkjQEAnoD/jWOmi6hPJGttZXU4mlaGIxws3muvVVwOSAQcD1oC5QorUi8M63PdTWsWj6hJdQMEkhS2cujEEgFcZBIBPPoajs9B1XUJpYbTTL24mhcRyJDAzsjc/KQBwflbj/ZPpQBn0VdbR9RXTl1FrC6Gns20XRhbyifTfjGfxqz/wjWqRTww3djdWZnieaM3FtIPMVELEgBSSMDqBgdSQMkAGTRRWjpWjXOsLfm2KZsrc3Lq2csoZVwuAcnLikBnUVvv4Qvk1zT9FMtt/ad2yq8Ic/wCjMx+7KcYUgckDOB1wQRSjwdqB16+0gvbq9iGknuWkxAkQx+83EZ2nK44ydw4ycUwuc/RXSW3hA3+qWljZ6zpVyLgSt9ojeUJGI0LtuUxhxwDjCnPaoDoOni6WH/hKNIMZQsZxFd7FIIG0jyN2Tknpjg5I4yBcwqK3fE/hoeF72Wyl1WwvLyGRoporUTZiYepeNQfwJrCoAKKKKQwooooAKKKKACiiigAooooAKKKKAPQf2gHYfFzxEAxA/wBH7/8ATvHRTf2gf+Su+Iv+3f8A9J4qK83LP9yo/wCGP5I7sx/3yt/il+bH/AL/AJLDoH1uf/SeWvPa9D+AYX/hcGgcnObnt/07y155V0v99qf4YfnMVT/c6f8Ain+UAr3L49H+19O8BeJ5/lv9X0sefGnES4CSDaDkjmdupPAHvnw2vcL0/wDCV/s6addj57vwzfmCaa55fy2OAkbcnbiaAYOB+7/2Vzlj/wB3iMPW7Scf/Alb80jXA+/Qr0e8VL/wF3/K55WhJRSepArPnbdM5Prirdq2Ysd1NUWbcxY9Sc16tV6I8+mtWJRRXT/DfVrPQPiJ4R1bUZvJ0/T9WtLm4l2ltkaTIzNhQScAE4AJrnbsjZbn670VDZ3lvqNpb3lncRXFpcRrLDPC4dJEYZVlYcEEEEEdamrwz1grm/FXjrRvB6oNQndrmRd6W0K7pGXOM9gB16kZwcZIrpK+cvjTYXtv4ye5uGd7W6hQ2xJYqqqAGQZ4BDZYgf3we9Jux6GWYWGKr+zqOytf18j1/wALfEjQvFlx9ltJZYL07itvcoFZwACSpBIPU8ZzwTjAzXXV8sfDawvb/wAa6QLJnRoZhNK6lgFiXl8kdAR8vPBLAHrX1PQncvNcHTwtVRpvRq/oFFFFM8w/JX4wf8la8e/9h6//APSh64uvVP2kfEWl+K/jX4r1XRb2K+02WSCOO5hOUkMcEcbFT/ENyMAw4OMgkEGvK69uHwo8qfxMVW2sGHUHNatZNaEkn+j7jjLL/Ouik9zCqtj079nLTYtR+JH2mVpBJp9nNcxhSAGYlYyG46bZWPGOQPpXk+s6pNrmsahqlwsa3F9cSXMixghQzsWIAJJxk+pr2P4WH/hGPhf8QPFjfLK8Q061mt+LiGRhjIbjau6aE5Bz8mcZAz4dXl4X95ja9XouWK+Su/8A0o9DFfu8HQp9XzSfzdl+QV23h7xZZaH4etbaeAX2b24a5sWJQSwvFGo+fBA+ZMjryo4riaK9U8yx6U3i+x1fTlt7zUvs1/fabNBPdmNysMrXzzlW2gnayEAlQcbgPUVDL4i0u5utQsf7SaNZ9Ig05dVeJ8O8bIxLAAvsYIU6ZwFyOorzuii4rHpWoeIdJ1XT7jSU1o2skS2X/Eykilxd+QjqwIUFxguNuR0QZ28YzNT8Qafc/FKHW0u3k01dQgna4dGDFFKbmK4zng8VxFFFx2PRrjW7SPxVompTa3oNzZ2+qRXDjTtMa3ljjEgYs5FvGWAA6ZY57VFceJbG+1iy1O31CKxUwSWcljPBI0ECFCp27BkRuGJOPnDEnn7x8+oouFj1JTpFz4d8Sw2Ws/Y7R5NOjacidoPMCzkouQZPL4yMgnIHbmsnX/FVnfWfiiO1u5d1/PYKpZWVrlIYpFeRvTc21sE5y3sa4hbmZIJLdZZFglZXeMMQrMudpI6EjccemT61FRcVj0+98Y6VNpnn2p06G4k06KweJort7ldqKpwPMEG3cu4Hg/7Ocktk8QaIuoJqE2pQy39wL1p3tI51iYyWzqpdJBxIXYD5PlANeZUUXCxq6Hd/ZDqP/Ew+xebZyxf6nzPPzj91/s7v73bFbPw/8Ur4RvtU1BZES6NiyW4dCyvJ5sbbTjpwrc8Y9QcVyNFA7HoGm6n4W0e81DWoZbmU3Nm8cOmh2Se3ll+ST98UZSFQuVbBJ3DIBzVufxR4d1K1MO+5sV1HS1024Mp8+SBoJEaGRmVFDqyoqEKMjb0PGfNKKLhY9Q0TX9D0a50GGXUdLmuLR7oPqFvppSNY3t9kayfug8h35Jyrfe6muP8AFM4uJbZv7T0a+IUjOl2H2UJ0+8PJi3E9jz07Vz9FFwsb/jfUrXWPF+tX9lL5tpc3TyRSbSu5SeDggEfjWBRRQAUUUUhhRRRQAUUUUAFFFFABRRRQAUUUUAd/+0D/AMld8Rf9u/8A6TxUU79oAL/wtzxFknP+j9v+neOivNyz/cqP+GP5I7sx/wB8rf4pfmxfgF/yWHQPrc/+k8tee16F8Av+Sw6B9bn/ANJ5a89q6P8AvtT/AAw/OYqn+50/8U/ygFe2/s9a1b3c+v8AgjUJp1tPENq6xFJD8jhGDhVwQGaMk7j/AM8gOeK8Sqzp2oXGk6haX9nJ5V3aSpPDJtDbXUgqcHg4IHWtMfhVisPKjezez7Nap/eRgsS8NXjVtdLdd09GvuL11aXOjahe2F2nlXVrI8MqbgdkiEgjIyDggjjiqFey/GPSU8U6Xo/xJ0i2k+w6tbqmoKu5hbTphPmJwcZHl5Chcxg9XGfGqnC4r61RjN6PZrtJaNff+BpicN9WquC1W6fdPZ/cFFS28PnOQW2oqlmbGcAe1P8ALs/+f3/yEa3MG0j6g/Zk/abs/AGnp4O8Yv5XhyLzJLHUIoS7WjMS7RyKgLOjMWIYAsrNg5Ugp94Wd5b6jaW95Z3EVxaXEaywzwuHSRGGVZWHBBBBBHWvxv8ALs/+f3/yEa9O+Gnx68W/CrZBo3iL7RpK5/4leoQvNajO8/KuQ0fzOWPlsu443Z6VyVsLzvmjudFLEqOktj9SKgu7O21C3e3u7eK4t3xuimQOrYORkHg8gGvOfhD8XX+LehWWrWfhi9t7WeSWKa5jvLWaC3dM/K37xZgSNpwYgfnB+6Qx9QMTg42n8q4ZUpx3R2QrResWUrDTbLS4WhsbO3tYWbeUgjVFLYAzgDrwPyq1TvLc/wAJ/KuK+JPj6X4caFqWsT+H7280+xtDcPdrdWsNur8hY2MkofJbaPlRyd4Chm+WlGlOWyHOrHeTOzr42/aT/an0u70S+8G+BbuK/a/jltdS1QJmKOI5R4otww5YZzIMqFI2kltyeNfFL9prxb8TftNl/bP9i6BLuT+ztOR08yM7xtll+9JlH2sOEbaDsBrxfy7P/n9/8hGu6jhOV80zjq4pPSJXoqx5dn/z+/8AkI02eBY1jeOTzIpAcNjHQ88V2HNdMhqZ5C0Ua56Coa9U+CPhNL/XJfFGqpJF4e8Oo15LcFGKmWMblUbTklf9YcBvugEfMKyr4qOFpSrT6L730S83sa0cNLE1I0o9X9y6v5bm38W7v/hC/hr4R8AI08d+8S31+hl+5ksTGdo2uplZyOTjyl65Brwitvxh4luPGPibU9cul2S3spcR5B8tAAETIAztUKucc4yeaxKjLsM8PQUZ/E7yl/ier/yDH4lYis5Q+FWUfRaL/MKKKsW1t5v7yTIiBxkdWPoP8e35A95xFeitLFuOBaxkDuzNk/XBFL+4/wCfSL/vp/8A4qnyi5jMorT/AHH/AD6Rf99P/wDFUfuP+fSL/vp//iqOUOYzKK0/3H/PpF/30/8A8VR+4/59Iv8Avp//AIqjlDmMyitP9x/z6Rf99P8A/FUfuP8An0i/76f/AOKo5Q5jMorT/cf8+kX/AH0//wAVR+4/59Iv++n/APiqOUOYzKK0/wBx/wA+kX/fT/8AxVH7j/n0i/76f/4qjlDmMyitP9x/z6Rf99P/APFUfuP+fSL/AL6f/wCKo5Q5jMorT/cf8+kX/fT/APxVH7j/AJ9Iv++n/wDiqOUOYzKK0/3H/PpF/wB9P/8AFUfuP+fSL/vp/wD4qjlDmMyitP8Acf8APpF/30//AMVR+4/59Iv++n/+Ko5Q5jMorT/cf8+kX/fT/wDxVH7j/n0i/wC+n/8AiqOUOYzKK0/3H/PpF/30/wD8VR+4/wCfSL/vp/8A4qjlDmMyitP9x/z6Rf8AfT//ABVH7j/n0i/76f8A+Ko5Q5jMorT/AHH/AD6Rf99P/wDFVWuLZVUyQ7jGPvKxyV/xHv8Ah6ZGguVaKKKko7/9oH/krviL/t3/APSeKij9oH/krviL/t3/APSeKivNyz/cqP8Ahj+SO7Mf98rf4pfmx/wC/wCSw6B9bn/0nlrz2vQ/gG7H4waANxxm54z/ANO8teeVdL/fan+GH5zFU/3On/in+UAooorvOI3rTxZqlv4WuvDMc+3Sbm6W8eMcEuF24JHVThCQc8opGOc5NRxd6nhiM0qRjOWOOBnFYezjFvlVr6v1OjnlKK5ne35EkzfZ7DYfv3BBx6KOh/E1nVav5hNcttx5cfyJg54HvVWhmQUUUUgPon9kb41f8K18dLomtap9m8Ia5lJvtEu2C0ucDy5z8p252iNjlRhgzHEYx+l9fiPX6Ufsh/HGT4meEZPDut3U0/irQI18y4uZkaS+tyxCSAcMSnyo5IPJRixZyAMaPpCvgf8Aba+NX9taxB8PtA1Tfpmn5fWPs0uUmuQ3ywP8vPlbdxAYjc+CA0XH0x+0h8ZIvg58Pp7y3bd4h1TfZ6XGrx7o5ShzcFXzuSPgn5WBZkU4DZH5XXt7c6leXF5eXE1zeXMjSzTzOXkldjlmZjySSSSTySaEDIKKKKBBWhZN59tLbfxg+anuQOR+VZ9S207W08cq9VOceo7imgJa17fxZqmn+GdT8OwT40vU5Ypp4255Q5G3PC5O0kgZPlqM4BBz7uIQzsqcxn5lPYg1Vl+6PrQ6cZ2U1fW/zWqNVOUU3F2/ye5FRRRW5zhWkOLS1A4BQsfc7mGfyA/Ks2tP/l1tP+uZ/wDQ2qokyGUVa0zTrjV9Ss9Ps4zJd3kyQRIP4nYhVH5kV7b8Rfh5Y28mhTXOk3Ph3RdP1IaBdX0li0P2mFQpS85A3s+JiW56L7U7knhFFelXHhGxtrfxBPa2t3bWqaM1zCZ7i2vkkZbqGMlJ0TbjDnO0KyngnBIOp4X8IeG/7d8HXFvbXerWcl/YJeTi7gkgZpSu6OSDYXiAclfn3BwpAxkEFwPIaK9R0fwZoHiH+3tYiguLbS7G6itI7G41u0tpHkcSMW+0TIiBQIzhAhY564BNTv4C8I6WbcXl9qGorea3JpcE2m3UHliIRwOJCwV1ZlM+CqnBI4ZcclwPJ6K1pPD903id/D9qPPvTemxjAGPMffsH5mvcfE/w+htPEPgyceGJNP07T9eg0Cf7TYmJNRiVkKXDBlAk8zE2488BR6UXA+eKK9E+H1jaXHxWNtPDZG1Rr8hLqASwJsgmKloyrAhSAcbT06GtfVl0HXdI1FrWfTbrV9N0aWe8vNL01ba2mY3cCxhY3iTawV2y6IhOQMkbslwPJKK9Q8W+C/C+kTeKYNN/th38NX0cM7XNxFi6iaQowXEf7tgQAGO4Hk7R0q54o8OaFqPxR8SWOm+HL4afYSz/AGiOPV7azhiIkChxI8Ajij5ChDnkjDdiXA8jor1TVvh/4e8MxeIbzU31G6trI6a1pDZ3cGZFuoZJCrTKroduzAdAQ2DgfMCMD4ZWNlJrF9qeqpAdK0qzknneeHzliZ8Qwv5XSTbLLGSp4IBz6UXA4qiuw8b+F9U0opq2ox6bBHfTGO3FgoSK5VUQmeJVG3y23ryMDcSNowQO80jwlo/ijwF4StHt7WzvLeOXVLy+SNVlls1upY7jc3VyiiNlB6ANRcDxOivWfidoulXsOp+IrKxi00rFohisrNFjgQXVlJLJ8oHXdGvOe5znPG94U8N6Xo2u6loc8Et5pi+JdCiaKdlJkDifhsqQVy3IxyMjjOaLgeEUV6C2h6brOleJZdGt3sli1Gyt4YtQurdgC4uNxM7RxhFyg4BUf3t2ARreB9LTR/D/AIza7u/DVrf2c9jGl9qFtFqdugfziyoUinUlsLyo/hwSMUXA8oor2qw03QP7Dv8AUtYsk1Q3Gg3F2H05ILJFZdU8rdF/o+VyMYLLlVLLgAgLyum+CdN1HUPBsQkvEh12xubuYeYpaMxzXKKFO3ptgTOR1J6ZABcZ5/RXX+M9G0Lw/b6Ta2K6jJqdzYWd9cTTzJ5KedAsjRqgTJ5YEMW4HGD96uQoEFFFFMAqSHnzQeQYnyPXCkj9QD+FR1LB1k/65Sf+gGhAZVFFFZmh3/7QP/JXfEX/AG7/APpPFRTv2gHYfFzxEAxA/wBH7/8ATvHRXm5Z/uVH/DH8kd2Y/wC+Vv8AFL82L8Av+Sw6B9bn/wBJ5a89r0L4Bf8AJYdA+tz/AOk8tee1dH/fan+GH5zFU/3On/in+UAooorvOIli+6frVyFvs9tNcHrjy09dx757YFUVk2jGK0rq2WaK3jS6tgsSnO6Tncev4Vm073NOZWsZFFXv7N/6e7T/AL+f/Wo/s3/p7tP+/n/1qnlZNyjRV7+zf+nu0/7+f/Wrb0/4d+JNWtI7yw0q7u7SXOye3t5JEbBIOGC4OCCPwqJyUFebt6lwhKbtFXOWrsPhf8RdW+FfjXTPEukzTBraRRc28cmwXluWBkgYkEYYDqQdpAYcqCHf8Kq8Yf8AQv6l/wCAc3/xFc5/Zbf8/Nr/AN/P/rUoTjU+Bp+g505w+NNep6H8fPjJe/Gjx1catuu4dBtv3Ol2Fw6n7PFgBmIXgO5Xc33iOF3MEWvLav8A9lt/z82v/fz/AOtW/b/DLxVd28Vxb6JfzQTIHjkjtZWV1IyCCFwQRzmnOUaes3b1FCEp/ArnI0V1tx8MvFVnby3Fxot/DbwoZJJZLWVVRQMliSuAAOc1gf2b/wBPdp/38/8ArUQnGprB39AnCUNJqxRoq9/Zv/T3af8Afz/61H9m/wDT3af9/P8A61Xysi5IrfaLBG/jtztbPUqenP6Yqq/3DV+ytVt5WL3VsY3Qo22TnB9Kz5G2s6cHBIypyDVJMrmVrEVFFFaGYVp/8utp/wBcz/6G1ZlX7aUTxJAf9amQn+0Dzt+ucn3z9AaiSy/o2sXvh/U7fUtOm8i+tyWil2qxQkEZAIIzzwex5HNWNH8TaroEV1Fp12YI7sxmVdisGKNuU/MDgg+nYkHgkHKZSpKsCCOCD2pKok6O/wDHWvaik0U13EkE1sbNoLe1hhiERkWQhURQqkuikkAE45NK3j7xAbS3tVvliSCSKUSQ28UcrtGcxl5FUPJtPI3E4rm6KQHTJ4/12K/vL1JbJXvVUXEI062+zzbeVZofL8ssCSd23PJ55qnceLdYuvI828LfZ7xr+P8Adp8szBAWHHTESDb0G3gdaxaKANWz8Sanp+vf27bXPl6t5rzi48tSRI2csARgHkkccHkYwKfofinVvDfm/wBmXfkCWSGVwY0cF4pBJG2GBwQwz9CQeCQceigDRsNe1DTNVfVLW48u/cSgy7FOfMVlfgjHKuw6cZ4qKx1W702K+itZvLjv4Ps1wNoO+Per7eRx8yKcjB4+tU6KANi98VavqMusy3N35j61IJb0+Wg85g+8HgfL83Py4rSPxG8RNfSXr3No9xNB9nnZ9Pt2Fym4N+9Ux4lbKqdzhmyBzXK0UAb+seNtd1+O7j1G+89Ls25lHlIu7yEZIvuqMbVdhx1zznAqnofiDUfDd491ptwIZZI2hkDRrIksZ6o6OCrKcDhgRwKzKKAN7XfGeteJbS3tNTuo5ra1cvBElvFGsGQAVQIo2IcA7FwuecZ5rOu9WvL6y0+yuJt9tp6PHbptA8tWcuwyBk5Ziec9apUUAdLbeP8AxBaSySJeRP5ltBaMk1rDLGY4ECRfI6FdyKAA2N3U5yTUdx468Q3V5e3kupSNd3t1BezTBFDNNDu8t8gcEbm6YznnNc9RQBt6n4t1XVo7+O4ktliv5IpbiO3tIYFkeMOEbEaKAf3j5I655zxVG31e8tdMvdMim22V68ck8e0He0e7Yc4yMb26HnPNUqKAN/TvGut6ULRbe6iMdpbPZxxTW0UsZheQyMjI6lXBdi3zA849BVrS/iN4k0a1S2sb6KKOMyeUfskLPEJM71RihZEbJyqkLyeK5aigC5qWq3erzQzXs3myQwRWyHaFxHGgRF4A6KoGepxzmqdFFMAooooAKlg6yf8AXKT/ANANRU6Z/siOrAid1KhT1QHqT9RkY98+mQZm0UUVmWd/+0D/AMld8Rf9u/8A6TxUUftA/wDJXfEX/bv/AOk8VFebln+5Uf8ADH8kd2Y/75W/xS/NknwDC/8AC4NA5Oc3Pb/p3lrzyvQvgF/yWHQPrc/+k8tee1dL/fan+GH5zFU/3On/AIp/lAKKKK7ziCiiigAooooAKs6fqN5pN3HeWF3PaXcWdk9vIY3XIIOGByMgkfjVaihpNWYJtO6O/wBP+N3j7TbSO1h8RzvFHnDXEUUznJJ5d1LHr3PHTpXXf8NReL/+gboX/fib/wCO14lRXn1MpwNV3lRj91vyO+nmmMpq0asvvv8Ame2/8NReL/8AoG6F/wB+Jv8A47XNaj8evH2ofa1/tz7PDcbx5dvbxJ5atnhH27xgHg7tw65zzXm9FKnlGBpu8aMfuv8AmE81xs1aVWX32/IvaprOpa5cLcapqF3fXCoI1lupmlYKCTtBYk4ySce5qjRRXoRioq0VZHDKTk7t3YUUUUxBRRRQAUUUUAFFFFAFhb66RQq3MwUDAAc4Apf7Qu/+fqf/AL+Gq1FO7FYs/wBoXf8Az9T/APfw0f2hd/8AP1P/AN/DVaii7CxZ/tC7/wCfqf8A7+Gj+0Lv/n6n/wC/hqtRRdhYs/2hd/8AP1P/AN/DR/aF3/z9T/8Afw1WoouwsWf7Qu/+fqf/AL+Gj+0Lv/n6n/7+Gq1FF2Fiz/aF3/z9T/8Afw0f2hd/8/U//fw1WoouwsWf7Qu/+fqf/v4aP7Qu/wDn6n/7+Gq1FF2Fiz/aF3/z9T/9/DR/aF3/AM/U/wD38NVqKLsLFn+0Lv8A5+p/+/ho/tC7/wCfqf8A7+Gq1FF2Fiz/AGhd/wDP1P8A9/DR/aF3/wA/U/8A38NVqKLsLFn+0Lv/AJ+p/wDv4aP7Qu/+fqf/AL+Gq1FF2Fiz/aF3/wA/U/8A38NH9oXf/P1P/wB/DVaii7CxZ/tC7/5+p/8Av4aP7Qu/+fqf/v4arUUXYWLP9oXf/P1P/wB/DVaiii4BRRRSGeg/tABf+FueIsk5/wBH7f8ATvHRTf2gf+Su+Iv+3f8A9J4qK83LP9yo/wCGP5I7sx/3yt/il+bMH4c+JU8IeP8ARNYlaNLe3uds7yIzBInBSRsLySEZiMZ5A4PSk8ceG28I+LtY0VlkCWdwyxeYyszRH5o2JXjJQqe3XoOlcrJ/rH+pr0fSvFPh/wAV6Bpfhzxa0mnXOmI0dn4ijVp2SLO4QSxdXQZYKVPy/IAANxNVeajW9vFNpq0rb2WqdutrvRa66bWapONWl7CTs07q+13o15XstXpprvpwVFekD4H+Kb395oT6T4gtB8rXWlajE8SP3Qlyp3AEHp0Yc0f8KD+If/Qvf+Tlv/8AHKr+08H1rRXq0vwYv7OxfSlJ+ib/ACPN6K9I/wCFB/EP/oXv/Jy3/wDjlH/Cg/iH/wBC9/5OW/8A8co/tPBf8/of+BL/ADD+zsZ/z5l/4C/8jzeivSP+FB/EP/oXv/Jy3/8AjlH/AAoP4h/9C9/5OW//AMco/tPBf8/of+BL/MP7Oxn/AD5l/wCAv/I83or0j/hQfxD/AOhe/wDJy3/+OUf8KD+If/Qvf+Tlv/8AHKP7TwX/AD+h/wCBL/MP7Oxn/PmX/gL/AMjzeivSP+FB/EP/AKF7/wAnLf8A+OUf8KD+If8A0L3/AJOW/wD8co/tPBf8/of+BL/MP7Oxn/PmX/gL/wAjzeivSP8AhQfxD/6F7/yct/8A45R/woP4h/8AQvf+Tlv/APHKP7TwX/P6H/gS/wAw/s7Gf8+Zf+Av/I83or0j/hQfxD/6F7/yct//AI5R/wAKD+If/Qvf+Tlv/wDHKP7TwX/P6H/gS/zD+zsZ/wA+Zf8AgL/yPN6K9I/4UH8Q/wDoXv8Ayct//jlH/Cg/iH/0L3/k5b//AByj+08F/wA/of8AgS/zD+zsZ/z5l/4C/wDI83or0j/hQfxD/wChe/8AJy3/APjlH/Cg/iH/ANC9/wCTlv8A/HKP7TwX/P6H/gS/zD+zsZ/z5l/4C/8AI83or0j/AIUH8Q/+he/8nLf/AOOUf8KD+If/AEL3/k5b/wDxyj+08F/z+h/4Ev8AMP7Oxn/PmX/gL/yPN6K9I/4UH8Q/+he/8nLf/wCOUf8ACg/iH/0L3/k5b/8Axyj+08F/z+h/4Ev8w/s7Gf8APmX/AIC/8jzeivSP+FB/EP8A6F7/AMnLf/45R/woP4h/9C9/5OW//wAco/tPBf8AP6H/AIEv8w/s7Gf8+Zf+Av8AyPN6K9I/4UH8Q/8AoXv/ACct/wD45R/woP4h/wDQvf8Ak5b/APxyj+08F/z+h/4Ev8w/s7Gf8+Zf+Av/ACPN6K9I/wCFB/EP/oXv/Jy3/wDjlH/Cg/iH/wBC9/5OW/8A8co/tPBf8/of+BL/ADD+zsZ/z5l/4C/8jzeivSP+FB/EP/oXv/Jy3/8AjlH/AAoP4h/9C9/5OW//AMco/tPBf8/of+BL/MP7Oxn/AD5l/wCAv/I83or0j/hQfxD/AOhe/wDJy3/+OUf8KD+If/Qvf+Tlv/8AHKP7TwX/AD+h/wCBL/MP7Oxn/PmX/gL/AMjzeivSP+FB/EP/AKF7/wAnLf8A+OUf8KD+If8A0L3/AJOW/wD8co/tPBf8/of+BL/MP7Oxn/PmX/gL/wAjzeivSP8AhQfxD/6F7/yct/8A45R/woP4h/8AQvf+Tlv/APHKP7TwX/P6H/gS/wAw/s7Gf8+Zf+Av/I83or0j/hQfxD/6F7/yct//AI5R/wAKD+If/Qvf+Tlv/wDHKP7TwX/P6H/gS/zD+zsZ/wA+Zf8AgL/yPN6K9I/4UH8Q/wDoXv8Ayct//jlH/Cg/iH/0L3/k5b//AByj+08F/wA/of8AgS/zD+zsZ/z5l/4C/wDI83or0j/hQfxD/wChe/8AJy3/APjlH/Cg/iH/ANC9/wCTlv8A/HKP7TwX/P6H/gS/zD+zsZ/z5l/4C/8AI83or0j/AIUH8Q/+he/8nLf/AOOUf8KD+If/AEL3/k5b/wDxyj+08F/z+h/4Ev8AMP7Oxn/PmX/gL/yPN6K9I/4UH8Q/+he/8nLf/wCOUf8ACg/iH/0L3/k5b/8Axyj+08F/z+h/4Ev8w/s7Gf8APmX/AIC/8jzeivSP+FB/EP8A6F7/AMnLf/45R/woP4h/9C9/5OW//wAco/tPBf8AP6H/AIEv8w/s7Gf8+Zf+Av8AyPN6K9I/4UH8Q/8AoXv/ACct/wD45R/woP4h/wDQvf8Ak5b/APxyj+08F/z+h/4Ev8w/s7Gf8+Zf+Av/ACPN66DwP4bbxd4u0fRVWQpeXCrL5bKrLEPmkYFuMhAx79Oh6V1B+B/imy/ea6+k+H7Q/Kt1quoxJE79kBQsdxAJ6dFPNVNV8U+H/Cmgap4c8JNJqNzqaLHeeIpFaBnizuMEUXVEOFDFj83zggjaRFTHQrRcMI+aT6rVLzb207Xu+nVq4YOVKSnilyxXR6N+SW+ve1l+DwPiX4lTxf4813WImje3uLgrA8aMoeJAEjbDcglFUnOOSeB0orlaK6aVONKnGnHZJJfI5atSVWcqkt27/eSSSOHYBm6nvTfMf++350UVoZh5j/32/OnCR9jHc3Ud/rRRQA3zH/vt+dHmP/fb86KKADzH/vt+dOkkcOwDN1PeiigBvmP/AH2/OjzH/vt+dFFADhI+xjubqO/1pvmP/fb86KKADzH/AL7fnR5j/wB9vzoooAdJI4dgGbqe9N8x/wC+350UUAHmP/fb86cJH2MdzdR3+tFFADfMf++350eY/wDfb86KKADzH/vt+dOkkcOwDN1PeiigBvmP/fb86PMf++350UUAOEj7GO5uo7/Wm+Y/99vzoooAPMf++350eY/99vzoooAdJI4dgGbqe9N8x/77fnRRQAeY/wDfb86cJH2MdzdR3+tFFADfMf8Avt+dHmP/AH2/OiigA8x/77fnTpJHDsAzdT3oooAb5j/32/OjzH/vt+dFFADhI+xjubqO/wBab5j/AN9vzoooAPMf++350eY/99vzoooAdJI4dgGbqe9N8x/77fnRRQAeY/8Afb86cJH2MdzdR3+tFFADfMf++350eY/99vzoooAPMf8Avt+dOkkcOwDN1PeiigBvmP8A32/OjzH/AL7fnRRQA4SPsY7m6jv9ab5j/wB9vzoooAPMf++350UUUAf/2Q==",
	"bosan": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4lkkcOwDN1Pem+Y/99vzok/1j/U16xc3MPwft7SxsbSMfEEJ5l9qEmJVsFcBlhiUjYXKbdz4bG5gGO75etK5i3YwtL+Dvj7WLdp7fw9eoiuUIunW3bOAeFkZSRz1xjr6Gr4+BPxF2n/iQtnI/5fbf/wCOVxmp6xqOt3C3Gp391fTqoRZLqZpWC5JwCxJxkk49zVKrshanff8ACiPiL/0AW/8AA23/APjlH/CiPiL/ANAFv/A23/8AjlcDRRZBqd9/woj4i/8AQBb/AMDbf/45Tn+BPxFLNjQWxnj/AE23/wDjlef0UWQanff8KI+Iv/QBb/wNt/8A45R/woj4i/8AQBb/AMDbf/45XA0UWQanoA+BPxF2n/iQtnI/5fbf/wCOU3/hRHxF/wCgC3/gbb//AByuBoosg1O+/wCFEfEX/oAt/wCBtv8A/HKP+FEfEX/oAt/4G2//AMcrgaKLINT0B/gT8RSzY0FsZ4/023/+OU3/AIUR8Rf+gC3/AIG2/wD8crgaKLINTvv+FEfEX/oAt/4G2/8A8cpw+BPxF2n/AIkLZyP+X23/APjlef0UWQanff8ACiPiL/0AW/8AA23/APjlH/CiPiL/ANAFv/A23/8AjlcDRRZBqd9/woj4i/8AQBb/AMDbf/45Tn+BPxFLNjQWxnj/AE23/wDjlef0UWQanff8KI+Iv/QBb/wNt/8A45R/woj4i/8AQBb/AMDbf/45XA0UWQanoA+BPxF2n/iQtnI/5fbf/wCOU3/hRHxF/wCgC3/gbb//AByuBoosg1O+/wCFEfEX/oAt/wCBtv8A/HKP+FEfEX/oAt/4G2//AMcrgaKLINT0B/gT8RSzY0FsZ4/023/+OU3/AIUR8Rf+gC3/AIG2/wD8crgaKLINTvv+FEfEX/oAt/4G2/8A8cpw+BPxF2n/AIkLZyP+X23/APjlef0UWQanff8ACiPiL/0AW/8AA23/APjlH/CiPiL/ANAFv/A23/8AjlcDRRZBqd9/woj4i/8AQBb/AMDbf/45Tn+BPxFLNjQWxnj/AE23/wDjlef0UWQanff8KI+Iv/QBb/wNt/8A45R/woj4i/8AQBb/AMDbf/45XA0UWQanoA+BPxF2n/iQtnI/5fbf/wCOU3/hRHxF/wCgC3/gbb//AByuBoosg1O+/wCFEfEX/oAt/wCBtv8A/HKP+FEfEX/oAt/4G2//AMcrgaKLINT0B/gT8RSzY0FsZ4/023/+OU3/AIUR8Rf+gC3/AIG2/wD8crgaKLINTvv+FEfEX/oAt/4G2/8A8cpw+BPxF2n/AIkLZyP+X23/APjlef0UWQanff8ACiPiL/0AW/8AA23/APjlH/CiPiL/ANAFv/A23/8AjlcDRRZBqd9/woj4i/8AQBb/AMDbf/45Tn+BPxFLNjQWxnj/AE23/wDjlef0UWQanff8KI+Iv/QBb/wNt/8A45R/woj4i/8AQBb/AMDbf/45XA0UWQanZap8HvHuj2onuPDt46s4QC1Zbh84J+7GzEDjrjHT1FcH5j/32/OtfTNY1HRLhrjTL+6sZ2Uo0lrM0TFcg4JUg4yAcewr0G2uYfjBb3djfWkZ+IJTzLHUI8RLfqgLNDKoGwOE3bXwudqgsNvzJx7Be255P5j/AN9vzoptFQUd78HdLh1j4p+HredpFRLlrkGMgHdErSqOQeCyAH2z061zesanNrer3+p3Cos99PJcSLGCFDOxYgZJOMn1Ndn8CQv/AAtvQeTnNx2/6d5K8/rRbE9T6b+Afivwbo/hCS3mvbHTNZEpN695KsRuPmbyyrMfmULxgdDk4G7Ler/8LA8Jf9DTof8A4Hxf/FV8G0ValYlwufeX/CwPCX/Q06H/AOB8X/xVH/CwPCX/AENOh/8AgfF/8VXwbRRzi5D7y/4WB4S/6GnQ/wDwPi/+Ko/4WB4S/wChp0P/AMD4v/iq+DaKOcOQ+8v+FgeEv+hp0P8A8D4v/iqP+FgeEv8AoadD/wDA+L/4qvg2ijnDkPvL/hYHhL/oadD/APA+L/4qj/hYHhL/AKGnQ/8AwPi/+Kr4Noo5w5D7y/4WB4S/6GnQ/wDwPi/+Ko/4WB4S/wChp0P/AMD4v/iq+DaKOcOQ+8v+FgeEv+hp0P8A8D4v/iqP+FgeEv8AoadD/wDA+L/4qvg2ijnDkPvL/hYHhL/oadD/APA+L/4qj/hYHhL/AKGnQ/8AwPi/+Kr4Noo5w5D7y/4WB4S/6GnQ/wDwPi/+Ko/4WB4S/wChp0P/AMD4v/iq+DaKOcOQ+8v+FgeEv+hp0P8A8D4v/iqP+FgeEv8AoadD/wDA+L/4qvg2ijnDkPvL/hYHhL/oadD/APA+L/4qj/hYHhL/AKGnQ/8AwPi/+Kr4Noo5w5D7y/4WB4S/6GnQ/wDwPi/+Ko/4WB4S/wChp0P/AMD4v/iq+DaKOcOQ+8v+FgeEv+hp0P8A8D4v/iqP+FgeEv8AoadD/wDA+L/4qvg2ijnDkPvL/hYHhL/oadD/APA+L/4qj/hYHhL/AKGnQ/8AwPi/+Kr4Noo5w5D7y/4WB4S/6GnQ/wDwPi/+Ko/4WB4S/wChp0P/AMD4v/iq+DaKOcOQ+8v+FgeEv+hp0P8A8D4v/iqP+FgeEv8AoadD/wDA+L/4qvg2ijnDkPvL/hYHhL/oadD/APA+L/4qj/hYHhL/AKGnQ/8AwPi/+Kr4Noo5w5D7y/4WB4S/6GnQ/wDwPi/+Ko/4WB4S/wChp0P/AMD4v/iq+DaKOcOQ+8v+FgeEv+hp0P8A8D4v/iqP+FgeEv8AoadD/wDA+L/4qvg2ijnDkPvL/hYHhL/oadD/APA+L/4qj/hYHhL/AKGnQ/8AwPi/+Kr4Noo5w5D7y/4WB4S/6GnQ/wDwPi/+Ko/4WB4S/wChp0P/AMD4v/iq+DaKOcOQ+8v+FgeEv+hp0P8A8D4v/iqP+FgeEv8AoadD/wDA+L/4qvg2ijnDkPvL/hYHhL/oadD/APA+L/4qj/hYHhL/AKGnQ/8AwPi/+Kr4Noo5w5D7y/4WB4S/6GnQ/wDwPi/+Ko/4WB4S/wChp0P/AMD4v/iq+DaKOcOQ+8v+FgeEv+hp0P8A8D4v/iqP+FgeEv8AoadD/wDA+L/4qvg2ijnDkPrn4ueM/BGoeBNTtrjUtO1SeRSLSG0nSaRLjB2SDa2VCnkngYyOd20/Kej6nNomr2Gp26o09jPHcRrICVLIwYA4IOMj1FUqKTdykrHXfGbS4dH+J/iS3gaRke4FyTIQTulRZWHAHAZyB7Y69aK0Pj0F/wCFseIMk5/0ft/07x0VlJasqOwfAj/krug/W5/9J5K4Gu++BH/JXdB+tz/6TyVwNXHYXUKKKKBhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRXQaNo1q1l/auq+edPMrQRQ20gSWeRQpYbirBFUOhJIJJZQByzI0riOfortP7V0j/oUdG/7/Xn/AMkUf2rpH/Qo6N/3+vP/AJIp8rFzHF0V2n9q6R/0KOjf9/rz/wCSKP7V0j/oUdG/7/Xn/wAkUcrDmOLortP7V0j/AKFHRv8Av9ef/JFH9q6R/wBCjo3/AH+vP/kijlYcxxdFdp/aukf9Cjo3/f68/wDkij+1dI/6FHRv+/15/wDJFHKw5ji6K7T+1dI/6FHRv+/15/8AJFH9q6R/0KOjf9/rz/5Io5WHMcXRXaf2rpH/AEKOjf8Af68/+SKP7V0j/oUdG/7/AF5/8kUcrDmOLortP7V0j/oUdG/7/Xn/AMkUf2rpH/Qo6N/3+vP/AJIo5WHMcXRXZjTdM8Tyx2dhpqaZq8zCO2SCZ2t52J+WNhIWZXYnAfftyFBVQWccZSasNO4UVs6VpUD2v9oah5psjI0McUDhZJnABb5iCFChlJJBzkADqV0/tmmf9C5pv/f25/8Aj1ZyqKLscs8WoytGLl6W/Vr+vM5Oius+2aZ/0Lmm/wDf25/+PUfbNM/6FzTf+/tz/wDHqn20SPrn/TuX/kv/AMkcnRXWfbNM/wChc03/AL+3P/x6j7Zpn/Quab/39uf/AI9R7aIfXP8Ap3L/AMl/+SOTorrPtmmf9C5pv/f25/8Aj1H2zTP+hc03/v7c/wDx6j20Q+uf9O5f+S//ACRydFdZ9s0z/oXNN/7+3P8A8eo+2aZ/0Lmm/wDf25/+PUe2iH1z/p3L/wAl/wDkjk6K6z7Zpn/Quab/AN/bn/49VLUdLtbq1nvtOjeH7OA9zbO+4KpYKHRiM7dzBdpywyDlssVcasW7FQxabSlFq/e36NmBRRRWh2HefHv/AJKz4g/7d/8A0njoo+Pf/JWfEH/bv/6Tx0VEt2EdkO+BH/JXdB+tz/6TyVwNegfAl2Pxb0EbjjNxxn/p3krz+rWwuoUUUUDCiiigAoqS3t5ru4it7eJ5p5mCRxxqWZ2JwAAOSSeMV7Lb/CHRfA9jb6v8RNW8rzctDpNjlpJmAVijOPxQ7cKCVPmDIppXE3Y8n0TQNT8SX6WOk2M95dNg7IVztBIG5j0VckZY4Azya9OsP2etcjtY7/xFqul6Fp4z57zzB3h5IXOMIcnb/H/F68U7UfjXdabAmmeB9LtfD+lROCpWJZJ5iAVDPuBXJUJnIZsr98153qF9qmuTrcanfXN3MqhBJdTNI4XJOAWJOMk8e9Ukhanpo8DfCTSv9E1TxxfXN/H/AKyaxjzC2eRt2xyDoQD855B6dAv9v/BT/oUNb/7/ADf/ACRXlQs1xyxJ9qeLaPH3f1p2F8z1L+3/AIKf9Chrf/f5v/kikPhf4OaxzaeKNV026vP9VDcITFau/wB1WJjxtUkAkydB97vXl32aL+7+pphtFxwzA+9FgPTrn9ny+voJbrwv4k0fXbSJCGaOTYzSgZ8sbS65wV5LD73OBzXmviTwlrfhG7W21rTZ7ORvuFwCkmACdrjKtjcM4JxnB5pLOW+0q6ju9Pupre6jzsmgkMbrkEHBByOCR1716Bovxu121gOn+Ira18RaQyoj2t/Gu4hR8vz7Tk52klwxO3sTmk0PU8mor25Php4P+JSTT+AtUfTtRiXfJpGpBiFXcFyH+YgcFiQZOXUHZnFePavpF9oOpXOm6lbPbXts2ySJ+qn+RBGCCOCCCODUtWGncpUUUUhhRRRQAV2mq/8AIA8I/wDYNk/9LLmuLrtNRIk8OeFJEO6NLKWFmXkLILqdyhPZgsiNjrh1PcVUdyZFTSLD+1dWsLDzPL+1zxweZtzt3MBnHfGa7m4+F0Mut6toWl6011rWnIZDbz2nkrOAASEYO2TyOCBXE6FfR6XrmmX0yu0VrcxTOEGWKqwJxnvxXo0nxG0LTvFmseKtMh1G41W9Rkt4rmJIorckAFiVdi/TpgdfxrQh3OWt/BkFv4bs9e1rUmsbS/laO1jht/Plk28MxBZQFB98+1bVn8JZ5vEz6TcaoiWraedSgvIYfME0WRjCllwefXt75qh/wlela14S0vQtcW9hk0qR2t7qzjSXejnJVlZlwfQg9uldHY/FfTU8VLeT2d3DpFtpJ0u1jiCySgZGGbJUZ47H0+tAanIXfgtJfDT+INGv2v7GCYQXEcsHkzQs2NpKhmBBJAyD3+uNZ/hnb2mt2fh6+11YPEF2isIBbF4Y3YZVGk3ZBPspHPWqr+L9P0bwhc+H9CW7ka9uEnuby7RYydhBVVRWbHKg5LHv68a9z4+8Pap4rsPFt7aaimq2yo0lnCqGGWVBhWEhbKjgcbT060BqZNj8Nro6Zq2oalLcwxabeGxkis7X7TL5gGWO3coCjI+bPemaH4I0/WovEd2utTLp+iwpMZFssyShgcjYXXaQQR1NW9I+IDW+p6jqz6xq+mahfXbTyR2UEc0DqcEAo7ryORk54xW7F8V9Ml1jxhe+VqGm/wBtQxRW81kitJEUBBdvnT5jnPB/GgNTnbr4X3p1zQNN067S6XW7ZbqCSWMxNGhGSXXJxgehOe1RL4CtdRt9aOh6yb+70dGlnhktvKEkanDNG25twHuFNbdx8VoLbX/DOp2dtcXk2kQNBc3V7tSa9Vhg7sFsY5IyTyeffOsvGGheGovEE2hw6hLe6vC9ugu0REtY3OWwVZi56YOF6UBqQ23gnQ7rwreeI013URZWk627xnTE8wscYIHn4x8w71xiWpur5bazEkxllEcO5QrPk4XIycE8cZP1rp7DxVZ2vw61Xw48Vwb67vEuEdVHlhQFyCc5z8p7VV8B61pnh3xNaarqsE88NpukjihVSWlx8uckYAPOfYUDNf4gfDSTwNa2VympJqEM0jQSskWwQygA7D8xzkZ9OlZPjrwj/wAIVrSab9s+17oEn8zyvLxuzxjJ9PWt+4+I9prfhrxDpWraYkMt/ML23ksg7AXOcszeZIcAgAfL0BPFZXxJ8V2fjHxBHqFjFcRwrbRwlZ1Abcuc9CeOaBK5x9TfED/kfPFP/YUuv/RrU2CCW6niggieWeVgiRxqWZ2JwAAOSSe1N8cXEN3418SXFvKk0E2o3LxyRsGV1MrEEEcEEc5qJFLcvXn/ACBvDn/Xk/8A6Uz1ShhkuZo4YUaSWRgiIoyWJOABVy5IfQ/D7qdyJayRMw5AcXErFT77XQ49GB7in+H9U/sPXdN1Ix+YLO4SYp/eCsDiuCfxM8pNqM3FXd5fmzvrj4DeKINJN4Gs5LhV3mzSQmT6A42k+2fxrznTtPuNU1C2sLZN1zcyLFGp4yxOB9K+qLj4yeEYdKN8mpCV9mVtVRhKW/u4xx9envXzFY69Pp/iOHW4kTz4rn7SE/hzu3bfp2qEeRlWLx1eNT6xCzW11bXXQ6tPhrBda3d+H7PXFn1+2RmMBtisMjqMsiybskjnqoHFQp8NLmbwF/wlEF3vlQuZLExYZURyrMGzzjgkYGAfatO38eeH9N8V3viyztdQbVJ1do7OVUEMUrjDMZA2WHJ42jr1qHTviXHpmh+HLaOGeS70+6nlvFdV8qeKUtuQc85Ddx1o1Kc8faPJ/dvdLs+Zel7K/nuxV+FG7xM2i/2v93TP7R877N9Pk27/AH65/Cuc8E+Ev+Ex1O6svtn2XyLWS53+Xv3bcfLjI65613T/ABR0I+Op9ZS11BNOfSjp6p5aGRWz1xvxjHvmud8G+JNA8G6xcXkc+p3kVxZTW7BrOOJlZiu0j962Rwc9McdewOFXG+ylzJ83KraLfW/S3bf5EUXw3uLrwAviq2vRK4Ls9l5WGWNHKs4bdzjgnjoa0YvhQr+KTojawVUaaNRM4tcnHHybd/v1z+FRaT8R4NG8PeGbG3gne40y5me6R1Xyp4ZCdyDnJyD3HWt3/hamhr48l1yK31GKwOl/YUVY081GyMHG/GAB65o1IqVMwTmorT3raLv7q+7Vd767HlmpRaZEY/7Ou7u4BzvNzarDt9MbZHz39Kl0L/j6uv8ArwvP/SaSrPiTU11N7dxreraqyAgtqUe0xjjAX96+c856dO9VtEISa9lY7Y0sLvc54C7oHRcntlmVR6lgOpqo7o9OTbw7vvZ/1svyOQooortPcO8+Pf8AyVnxB/27/wDpPHRTvj07D4seIAGIH+j9/wDp3joqJbsI7IPgR/yV3Qfrc/8ApPJXA133wI/5K7oP1uf/AEnkrgauOwuoUUUUDCtrwr4V1PxlrUGk6TB5tzLyzNwkSDq7nsoz+oABJANLSNIvte1K203TbZ7m9uW2RxJ1Y/yAAySTwACTwK9r8U61D8G/D0Xg/wAPBE8RXkCS6tqccgZ0Yg/Ih4KnrtyBtVgQNzlg0iW+iC+17w38FbfUtH8LM+peLpFWG51WZVMducfOiD1DDOzkZI3MxTbXkmoX1/4h1K51LUrmSe7uW3ySv1Y+3YADAAHAAAHAqrBbggO3TsKsvIsYyx/D1q7dWHoCRrGMKP8A69DyJH95gKpSXTvwPlHt1qCodVLY0VLuXjeRg4+Y+4FM+2/9M/1qpRUOrIr2cS39t/6Z/rTxeIcZDCqNFHtJB7OJppKj/dYE+lOZQ4wwBFZVSx3Dx8ZyvoatVe5LpdiyizWU8VzayyRzROHR42KujA5DAjkEHuK9a0v4g6H8SdNtvD3xF3pdrPm01q3VIjFu6hzjCg4C52lSCCQCu6vKYpllGQee4qOe3DZdeD3HrV+aM2ujNXx/4A1P4fa0bG+Hm20uWtbtFwlwg7j0YZGV7Z7ggnlK9t+G3i2z8XWEXw88XJ9p065+TT7xnCyWkgB2KGP5J1OTswytgeWeKvCup+Ddan0nVoPKuYuVZeUlQ9HQ91OP0IIBBAloE+jMWiiipKCtnRtdSxhayv7d7zS3YyeSkojkikwBvjcqwUkABgVIYAZGVRlxqKYjsPM8Jf8AQX1z/wAFUX/yTR5nhL/oL65/4Kov/kmuPop8zFY7DzPCX/QX1z/wVRf/ACTR5nhL/oL65/4Kov8A5Jrj6KOZhY7DzPCX/QX1z/wVRf8AyTR5nhL/AKC+uf8Agqi/+Sa4+ijmYWOw8zwl/wBBfXP/AAVRf/JNHmeEv+gvrn/gqi/+Sa4+ijmYWOw8zwl/0F9c/wDBVF/8k0eZ4S/6C+uf+CqL/wCSa4+ijmYWOw8zwl/0F9c/8FUX/wAk0eZ4S/6C+uf+CqL/AOSa4+ijmYWOw8zwl/0F9c/8FUX/AMk0eZ4S/wCgvrn/AIKov/kmuPoo5mFjrJte0vSFLaF9tm1D+C/u0SE2/wD1ziVn+cY4kL8bjhQwVxydFFJu40rGpperrZxtbXcLXNgzb/KWTY6Pj7yMQdpOADwQQBkZCldTz/Dv/QQ1X/wXx/8Ax+uXorOVOMtWc9TCxlLmTa9LfqmdR5/h3/oIar/4L4//AI/R5/h3/oIar/4L4/8A4/XL0UvZRI+p/wB9/h/kdR5/h3/oIar/AOC+P/4/R5/h3/oIar/4L4//AI/XL0UeyiH1P++/w/yOo8/w7/0ENV/8F8f/AMfo8/w7/wBBDVf/AAXx/wDx+uXoo9lEPqf99/h/kdR5/h3/AKCGq/8Agvj/APj9Hn+Hf+ghqv8A4L4//j9cvRR7KIfU/wC+/wAP8jqPP8O/9BDVf/BfH/8AH6oalrELQPZ6bHLFavjzpJWBkuMHjOOFXIDbATz1ZsLjGopqnFO5UMLGLUpNu3e36JfiFFFFWdR3nx7/AOSs+IP+3f8A9J46KPj3/wAlZ8Qf9u//AKTx0VEt2EdkSfAkL/wtvQeTnNx2/wCneSvP6774Ef8AJXdB+tz/AOk8lcDVrYXUKKK6f4feEJvHHizT9IQOIJG33MiZ/dwry5zggHHygkY3MoPWmB6X4HttP+FvgL/hNtQtoJfE+p7k0i3uSwKxnClwuMjIJYtnBQoAy7znyMNLe3Et1cyPNLKxd5JGLNIxOSSTyST1Ndp8WvFUXirxa1rpxRdE0pfsVlHDgRBV4Z1AJXBI4K4yqpxxXJKoRQo6CrSJEkcRoWP/AOus13aRizHmp7x8uEB4HX61WrGpK7sb042VwooorM0CiiigAooooAKKKKAFVipBBwRWjDKJUzxu7is2prV9koGeG4rSnKzsZzjdE1zD/Go+texgWvxl+Hc3mRo3jrw7BiIq7NNeW6Y5IwS5PzDAyRJg5USYPkxGRg9K1fA3imbwL4tsNVQyG3RtlxGucywtw4xkAkDkAnG5VPat2jDc4yivQfjD4Qi8L+LHuNPCNoerr9tsZIcGLa3LIpAC4BPAXOEZOea8+rNlJ3CiivcPgF+z1F8bdN8T38/ij+woNAETSH7AbrzFdZCTxIhGBH75zSbtqxnh9FfRF1+zHp2ufD/XPGXw9+IVn4rstEV3u4H02WxlUIm9tquxJO3kZABxwc8V870k09gCiiimAUUUUAFFFFABRRXveg/s32a/DPS/Hvjfx3ZeFdI1iQR2KmwlvHkLbiu4IRtyEY8Z4646UNpAeCUVseKtFt/Duv3um2mr2WsWsDL5d/ZEmGdSoYEZAIPOCD0II7Vl28X2i4iizt8xwucZxk4oAjor6o8efsneDfhtqGnad4l+MkGm3upKz2y3GgS+W4BAJMiysqDJH3iK8n+MfwJ8R/Bm7sW1KS11DRtSG6y1SxYtDNxnBz91sEHHQjoTg4SkmFjy+iiur+G3gDU/ij400zwno89pBqOo+b5Ul47LEvlxPIdxVWPRDjAPOPrTA5Siug8ceD77wB4t1bwzqUttLf6XMYJpLZmaNmAB+UsASOe4Fc/QAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB33x6C/8LY8QZJz/AKP2/wCneOim/Hv/AJKz4g/7d/8A0njoqJbsI7Id8CP+Su6D9bn/ANJ5K4Gu++BH/JXdB+tz/wCk8lcDVx2F1CvcvhFInhL4aeNfGSN/pwxY2zLCrPA+F2sCx5UvNGSMf8s8/NwK8Nr2z4gD+wfgz8PtD/1323dqXn/d2ZBfZt5z/wAfOM5/g6c8VEUux5NaJks5HTgVbqOBdsS9OeakrRbCZBJBG8mWYhm7Un2OP1b86jvW+ZF7gZrqvhbqnh2w8feHrjxisr+HILtJLry4ll4HK70IO+PcF3gAkpuABOKxlKKbujWMZNKzPoX4I/sg6X448FweJPFuo6tZ/wBpfvLK1stsTrCCQHkMkbZ38Mu0Y24OTuwvpX/DDHw7/wCgz4p/8Crf/wCMV9HaPq1nr+kWGradN52n6hBHc28u0rvjdQythgCMgg4IBq7XiTxFRybvY9aNCCSVrnzJ/wAMMfDv/oM+Kf8AwKt//jFH/DDHw7/6DPin/wACrf8A+MV9N0VPt6ncr2MOx8yf8MMfDv8A6DPin/wKt/8A4xR/wwx8O/8AoM+Kf/Aq3/8AjFfTdFHt6ncPYw7HjXw9/Zc+HXgH+0c6b/b/ANt8v/kYILe78jZu/wBX+6G3du59dq+ldhd/Cr4a2VpPcy+APDTRwRtIwh0KGVyAMnaixlmPHAUEnoATXbLgMM9Kk3J7flXTSrScdZL5nLWpRUtE/kfmV+0fqngDxJ440+7+HsNjDoqabHFKthYGzjM4llLEoUXJ2lPmx0wM8V4+ttGsi4Ztw5xX1D+078RvhH4w8I258CHS5PE0urLc3dxb6Q9tPJEY5d7NK0S7suyEgkknntmvli0b99zklga9OLjorHC1Kzdy9Ve7TKBscj+VWKa670ZeOR3rdmSPV9YkTxl+z3aX8zf6d4YultjK8K5dMqgjVgeF2SxZPcx8g/erwyvbfgIP7XHjLwv/AKr+2NMb/SfveVjMf3ON3+vz1H3ffjxKs2NdUFfbf7CEkUPhH4qyTw+fAkVs0kW4r5iiO4yuRyMjjNfElerfB/4/eI/graa5a6Hpui30GteX9pXVIJJRhA4AASRRghznOe1ZzV1ZFLc+pvgnrHh34q/Bj4meFvh54cfwFcpDmZheNfrP50bjBlkAYArEyn+6GyOa5XwD5Hwf/ZDb4j+F7KzfxlqdwUk1OaBZntF+0mEAbgcAKo46bnyc8V5Bqf7VXi6bwxqHh3QdE8KeE9O1BWS5/wCEd0z7K0gYYbkuwBI4yAD6EVznw2+Pniz4ZaPfaFYppmqeHb5i02kaza/abZmOMnbkEZwMjODjpU8rHc9++K8Nr8U/2TNF+JviCws4PGlvcCM38ECwveL9paEhgAMgqN+OxU4wCRXp2n+LtG8f6V4b0r4RfEvwz4YiFosJ8LX+kwu1xLjJVvMwxIHB2Bs4Jya+L/ib8d/FnxT0/T9J1P8As/T9B04hrbSdJt/s9rGwGAduSTgEgZOBk4xk11ek/tW+KNKmhvT4V8D3WuQDEeszaIovFOMbhIjKM49qOR2C56J8K/hx8UrL4z/EmXS/EGieDLvSB/xOb21so5rVI5j5yiGF1ICkJv8A4cAYPXFer6qujfFn9nf4h3mp+MrPx/daLb3E9vrA0D+zZLSaKHzAi8fN0GSuMhsHNfJHhD9pHx74P8Za/wCKYb62vr7xAQdShv4N8FztyEyqlcbQSBtIwDjpWy37VvjH/hFvEvhmHR/C9pomvQS2zWtnp7W8dokiFH8lUcKCdxOWDEnqSABQ4u4XR7rq/jG68C/sW/D3WNPtrOXVI7tEtJrq3SdbWQvcHzVRwVLBQwGQcbs9QK579rJYPFPwU+E/ju9tLZfEmpwQi6uYYghl8y3EjA47BlyB2ycda8B1343eIPEHwo0X4bXNnpaaFpEyzwTxRSC5Zh5nDMXKkfvW6KOgpfGvxw8Q+O/h/wCF/BOo2elxaV4bWNbWW2ikWZwkfljeWcqePRRzQotO4XOH8O6Qdf8AEGk6SJlgOoXcVr5rdE3uF3H2Gc1+iviO5+HWh32l/s36/p91BoV5pUbafqt1Pub7U0j7cMR8rbgSrfd3HZtxgV+bCsyMGUlWU5BBwQa97t/2ufG7WOmw6xpHhXxBfaYB9k1PWNL8+7hI6MrhgA3A+bGTjJJNOcWwTOs+MHwF8MfA74KuNdS2vvH+pas8Wn3sNxKpFqrA7vK3bPuLzkHBlAzwK+YNO/5CFp/11T+Yr1r4i/tJ+Kfit4Uh0HxXpXh+/kt5DLBqYtXju4GJydrLIEAx8pGwggDOSAa8fhlME0cqgFo2DDPTINVFO2omfZP/AAUK/wCRo8E/9eVx/wCjFrT+M8cml/sWfD7TNdVl1qWS0+ywy/6xflkK8HkYiIU+mQK8v1v9s3xX4iu7W91TwV4AvL+zz9murnSZJpbfnPyM8x28gHivJPiR8VvFfxY1iPU/FOqNdywgrBCiiOG3U9QiDgZwMnqcDJOKhReifQbZ9taLJ44+Fb+BtA8efGvT7CW8W3trXw3H4ZS9E0YKxiEzRqGHZN5785OKm2f8K6/bV0fQvDKw6bovi/Szd6pZwQRhJpI4rsqR8uU+aJWO3GTnOcmvmS5/a48e31hpEd7aeHbzVNK2i31m404PfIBjIEhbC7gMEoFY+oPNYXir9ozxj4q+J2ifER49MsPEGjwLb2/2KFxCUBkJDK7sTkSup5HB7daXIx3PQf2iPH/j74gfGPUPhmmqrcaXHr0MWmWLW8KCOY4SMmQJvIHmH7xI59q+kvDmqeJtD+JGjeDfH3xn07XdXv03S+GF8LIUnUoxx9oRQE4BbLAcDkc18V/EH9oPXfiFe6fqk3h7wtpGv2N7HfrrOj6eYb2SWMYTfKzsWAODg91HpXUT/ti+PLjWNM1ptJ8KjWbIBHv10zFxdRjP7uSTfuCEnJVCgP0yKbi7WFc+jvgd4Y03wd+1n8WdH0i2jtdOhsIpYoIxhI/M8iQqo7AFzgDoOK+N/iX8YPEXjmBvD05s7Pwtp9401jpVnZxRR22Nyr8yrvY7WOSzHJOetdNon7U3jHQfib4j+IFtpugvrOvwR29zDLBMbdFRUUFFEoYHEa9WPU14pPK1xNJKwAaRixA6ZJzTjGzuwbI6KKKsQUUUUAFFFFABRRRQAUUUUAd58e/+Ss+IP+3f/wBJ46KPj3/yVnxB/wBu/wD6Tx0VEt2EdkSfAl2Pxb0EbjjNxxn/AKd5K8/rvvgR/wAld0H63P8A6TyVwNWthdQr239ogf2drnh7Q7b5NL07TE+zQdfLy7IfmPzH5YkHJPT3OfEq9u/aV/5HrT/+wZH/AOjZapbMT3R5co2qAOgGKqXrfMq+gzVyqF22ZiPQYp1fhKp/EQUUUVzHQfrj8K7O4074YeCrO8t5be7t9FsopoJkKPG6wIGVlPIIIIIPSvmHwbZXP7XvxL1+PXfE91p3g/Sh59potvKsc8keXSJ1jO5Ny7sySHcQXVBgMu37Lr4H+JPwC8d/DLxpcaz4GtNUm0p52bT7rQ2kNzaLIH/ckKxlG1cqX5VgRkgsVHn4SUeZ30fQ7cRGXKkja+F/i7W/gj8bz8NrjxCNd8NNfDS9tuxkijkkb920alsQuJJMSqCQD5gO9lU19vV8R/s6/s6+IpPF2l+KvFWly6ZpOmOLq3trsGOe4nUkJ8gIaMI6h8uBuwoAZWJH25U4twc/d+ZWHUlH3gr5R+N/i7W/iF8Y9K+EGk+IR4d0uYpBf3UrGMXEksRcoSGzIpjdUWM7Q8j7Tn5SPq6vk39qD4Aa34n10+NPCll9umlgC6jZRsfOZo0O2ZAzfPlFVNiANlVwGLNicK4qp7w66k4e6cR8VfDGo/sm/EDSbjwT4qlnsdSjFy2m3UwaQiP5StzGm1XjYs+x8KR84GGTeftfw9rdv4l0DStatElS11O1iu4kmADqkiB1DAEgHBGcE/Wvz78NfAz4nfFTxSZtdstZtPMeMX2sa8sgkVNpAIEpDzEKm0Bc4+UEqDmv0K0nS7TQ9KsdLsIvJsbGBLaCLcW2RooVVySScAAZJJrXGOLtZ3ZnhlJJ32PxzvLO4067uLO8t5be7t5GimgmQo8bqcMrKeQQQQQelQ12nxg/5K149/7D1/8A+lD1xddyd1c42rOxPaNiYD1GKv1mwNtmQ++K0q6aT0MKq1O4+BF7PZfE/ToIJNsV3HPBMMA70EbOBz0+ZFPHp6Zrg/GFhb6X4t16xtI/LtbW/nhiTJO1FkYKMnk4AHWu1+CX/JVtE+tx/wCiJK5L4gf8j54p/wCwpdf+jWoexHU52iituDwte3Hha48RRvAbO3uPs8ke4+aOF+fGMbcugznOWHFIZiUV0eq+CNX0ufSbbyftd3qdsLqK3tFaSRQSQVZcfeBU5AzismPR9Rm1A6dHYXT6gCVNqsLGXI6jZjOfwoApUVoQaDqt1eT2cGmXst5ACZYEgdpIwOu5QMj8avXvhiW38Vx+H4Z0knkmigSWRSi7n24yBkgAt70AYNFdOnhK3fW9N0qPxBp9zNeXkdm4tYpy0O5gpYiSNAQCegP+NY6aLqE8ka21ldTiaVoYjHCzea69VXA5IBBwPWgLlCitSLwzrc91NaxaPqEl1AwSSFLZy6MQSAVxkEgE8+hqOz0HVdQmlhtNMvbiaFxHIkMDOyNz8pAHB+VuP9k+lAGfRV1tH1FdOXUWsLoaezbRdGFvKJ9N+MZ/GrP/AAjWqRTww3djdWZnieaM3FtIPMVELEgBSSMDqBgdSQMkAGTRRWtoGgvr0t4ovLWzis7c3Ms1zv2qgZV6IrMTlh2oAyaK6Y+CL86hHbx3NlJbSWn24XwkYQCDcVMhLKGA3ArgrnPGORUc3gy+M+mJYT2upQ6nP9mt57R22NLkDYd6qyn5lPzAcHNFguc7RWpq2jR6WEMWqaffqWKMbR3Owj1DqpI9xke9aV74F1PT9Q0Kyme2EutCLySHJWNnIGyTjhhuUkDOMigLnM0V0Go+DtQ0ufW4bh4N2jqjylWJEqOyqjIccg71YZxwfwrn6ACiiikMKKKKACiiigAooooAKKKKACiiigDvvj07D4seIAGIH+j9/wDp3jopvx7/AOSs+IP+3f8A9J46KiW7COyHfAj/AJK7oP1uf/SeSuBr0D4Ehf8Ahbeg8nObjt/07yV5/VrYXUK9t+Oh/tbT/AviWb5b7VtMHnRpxGuAknyg8jmZupPAHvnxKva7w/8ACU/s96fdD57rw3fGCWa55fy2OAkbcnbiaEYOB+7/ANkZpCe6PMEJKKT1IFZ87bpnJ9cVbtWzFjupqizbmLHqTmlVeiNKa1YlFFdP8N9Ws9A+InhHVtRm8nT9P1a0ubiXaW2RpMjM2FBJwATgAmuduyNlufrvRUNneW+o2lveWdxFcWlxGssM8Lh0kRhlWVhwQQQQR1qavDPWCub8VeOtG8Hqg1Cd2uZF3pbQrukZc4z2AHXqRnBxkiukr5y+NNhe2/jJ7m4Z3tbqFDbEliqqoAZBngENliB/fB70m7HoZZhYYqv7Oo7K1/XyPX/C3xI0LxZcfZbSWWC9O4rb3KBWcAAkqQSD1PGc8E4wM111fLHw2sL2/wDGukCyZ0aGYTSupYBYl5fJHQEfLzwSwB619T0J3LzXB08LVUab0av6BRRRTPMPyV+MH/JWvHv/AGHr/wD9KHri69U/aR8RaX4r+NfivVdFvYr7TZZII47mE5SQxwRxsVP8Q3IwDDg4yCQQa8rr24fCjyp/ExVbawYdQc1q1k1oSSf6PuOMsv8AOuik9zCqtj0r9nnTYtQ+In2mVnElhZy3Ee0gBmJWPB46YkY8Y5A+leVaxqc2t6vf6ncKiz308lxIsYIUM7FiBkk4yfU16/8ADA/8I18M/HvilvlkeIafazQcXEMhGMhuNq7pojkHPyZxkDPidUzNbsK7bw94sstD8PWttPAL7N7cNc2LEoJYXijUfPggfMmR15UcVxNFIdj0pvF9jq+nLb3mpfZr++02aCe7MblYZWvnnKttBO1kIBKg43AeoqGXxFpdzdahY/2k0az6RBpy6q8T4d42RiWABfYwQp0zgLkdRXndFFxWPStQ8Q6Tqun3GkprRtZIlsv+JlJFLi78hHVgQoLjBcbcjogzt4xman4g0+5+KUOtpdvJpq6hBO1w6MGKKU3MVxnPB4riKKLjsejXGt2kfirRNSm1vQbmzt9UiuHGnaY1vLHGJAxZyLeMsAB0yxz2qK48S2N9rFlqdvqEVipgks5LGeCRoIEKFTt2DIjcMScfOGJPP3j59RRcLHqSnSLnw74lhstZ+x2jyadG05E7QeYFnJRcgyeXxkZBOQO3NZOv+KrO+s/FEdrdy7r+ewVSysrXKQxSK8jem5trYJzlvY1xC3MyQSW6yyLBKyu8YYhWZc7SR0JG449Mn1qKi4rHp974x0qbTPPtTp0NxJp0Vg8TRXb3K7UVTgeYINu5dwPB/wBnOSWyeINEXUE1CbUoZb+4F6072kc6xMZLZ1Uukg4kLsB8nygGvMqKLhY1dDu/sh1H/iYfYvNs5Yv9T5nn5x+6/wBnd/e7YrY8A6rbaVdax9pvLSza6094IZby3M8O8yRkBkCPkYU9VIrkqKB2PTr/AMUaPetLp1zqEb/btKWyudQtLZo4I5UnEsZSLapCYVVYKo5JIXPXEm1LT9I0nTdIsNYaaZdQF/NqFrE6rAQoVBGHCsSOWJwOwHSuMoouFj0a51Dw7fPpS6zqNhe3IvhLcXlhYtD/AKMFJaNx5ab3ZsAHacc5bBq7F448P6tdRXVzFeWFxb63Fqwa5uPtIYM6iZFCRLtAVVbBz9zA56+WUUXFY9DuPFWl6h4P1y3uJ2XWPltrb5GIuLf7Qsq5OOCmHHOMhlA6V55RRQNKwUUUUhhRRRQAUUUUAFFFFABRRRQAUUUUAd58e/8AkrPiD/t3/wDSeOinfHoL/wALY8QZJz/o/b/p3joqJbsI7IPgR/yV3Qfrc/8ApPJXA133wI/5K7oP1uf/AEnkrgauOwuoV7R8ANZt7ufXvBd/NOtrr9q6xFHPyOEYOFXBAZkJO4/88gOeK8Xqzp9/caXf2t9aSeXdWsqzRPgHa6kFTg8HBA6007A1dF66tbjR7+8sbpPKurZ3hlTcDtdSQRkZB5BHFUK9g+L2lL4n0zSPiLpNs/2LVIFS/VdzC3mX5OScHGR5eQoXMYPVxXj9RU3saUtVcKKlt4fOcgttRVLM2M4A9qf5dn/z+/8AkI1maNpH1B+zJ+03Z+ANPTwd4xfyvDkXmSWOoRQl2tGYl2jkVAWdGYsQwBZWbBypBT7ws7y31G0t7yzuIri0uI1lhnhcOkiMMqysOCCCCCOtfjf5dn/z+/8AkI16d8NPj14t+FWyDRvEX2jSVz/xK9Qhea1Gd5+Vcho/mcsfLZdxxuz0rkrYXnfNHc6KWJUdJbH6kVBd2dtqFu9vd28VxbvjdFMgdWwcjIPB5ANec/CH4uv8W9CstWs/DF7b2s8ksU1zHeWs0Fu6Z+Vv3izAkbTgxA/OD90hj6gYnBxtP5VwypTjujshWi9YspWGm2WlwtDY2dvaws28pBGqKWwBnAHXgflVqneW5/hP5VxXxJ8fS/DjQtS1ifw/e3mn2Nobh7tbq1ht1fkLGxklD5LbR8qOTvAUM3y0o0py2Q51Y7yZ2dfG37Sf7U+l3eiX3g3wLdxX7X8ctrqWqBMxRxHKPFFuGHLDOZBlQpG0ktuTxr4pftNeLfib9psv7Z/sXQJdyf2dpyOnmRneNssv3pMo+1hwjbQdgNeL+XZ/8/v/AJCNd1HCcr5pnHVxSekSvRVjy7P/AJ/f/IRps8CxrG8cnmRSA4bGOh54rsOa6ZDUzyFoo1z0FQ16h8FvCy32tyeJtUR4/D/h5WvJbgoxUyoNyqNpySv3zgH7oBHzCtKe9iKm1za+K93/AMIb8OPCngNWnS+eJb6+Qy/cyWJjO0bXUys5HJx5S9cg14bW14t8SXHi7xJqWtXK7ZLyUuEyD5aAYRMgDO1QozjnGTzWLVt3MkrIKKKsW1t5v7yTIiBxkdWPoP8AHt+QIBXorSxbjgWsZA7szZP1wRS/uP8An0i/76f/AOKp8ouYzKK0/wBx/wA+kX/fT/8AxVH7j/n0i/76f/4qjlDmMyitP9x/z6Rf99P/APFUfuP+fSL/AL6f/wCKo5Q5jMorT/cf8+kX/fT/APxVH7j/AJ9Iv++n/wDiqOUOYzKK0/3H/PpF/wB9P/8AFUfuP+fSL/vp/wD4qjlDmMyitP8Acf8APpF/30//AMVR+4/59Iv++n/+Ko5Q5jMorT/cf8+kX/fT/wDxVH7j/n0i/wC+n/8AiqOUOYzKK0/3H/PpF/30/wD8VR+4/wCfSL/vp/8A4qjlDmMyitP9x/z6Rf8AfT//ABVH7j/n0i/76f8A+Ko5Q5jMorT/AHH/AD6Rf99P/wDFUfuP+fSL/vp//iqOUOYzKK0/3H/PpF/30/8A8VR+4/59Iv8Avp//AIqjlDmMyitP9x/z6Rf99P8A/FUfuP8An0i/76f/AOKo5Q5jMorT/cf8+kX/AH0//wAVR+4/59Iv++n/APiqOUOYzKK0/wBx/wA+kX/fT/8AxVVri2VVMkO4xj7ysclf8R7/AIemRoLlWiiipKO8+Pf/ACVnxB/27/8ApPHRR8e/+Ss+IP8At3/9J46KiW7COyHfAj/krug/W5/9J5K4GvQPgS7H4t6CNxxm44z/ANO8lef1a2F1CiiigZu2virU4PDF14bjn26Vc3K3boOCXC4wSOqnCkg55RSMc5yqji71PDEZpUjGcsccDOKzluaw0RJM32ew2H79wQceijofxNZ1Wr+YTXLbceXH8iYOeB71VqGSFFFFID6J/ZG+NX/CtfHS6JrWqfZvCGuZSb7RLtgtLnA8uc/KdudojY5UYYMxxGMfpfX4j1+lH7Ifxxk+JnhGTw7rd1NP4q0CNfMuLmZGkvrcsQkgHDEp8qOSDyUYsWcgDGj6Qr4H/ba+NX9taxB8PtA1Tfpmn5fWPs0uUmuQ3ywP8vPlbdxAYjc+CA0XH0x+0h8ZIvg58Pp7y3bd4h1TfZ6XGrx7o5ShzcFXzuSPgn5WBZkU4DZH5XXt7c6leXF5eXE1zeXMjSzTzOXkldjlmZjySSSSTySaEDIKKKKBBWhZN59tLbfxg+anuQOR+VZ9S207W08cq9VOceo7imgJa1oPFWp2HhvUvD8M+NM1KWOWaNueUORtzwuTtJIGTsUZwCDQu4hDOypzGfmU9iDVWX7o+tXHRlS1iRUUUVoZBWkOLS1A4BQsfc7mGfyA/Ks2tP8A5dbT/rmf/Q2qokyGUVa0zTrjV9Ss9Ps4zJd3kyQRIP4nYhVH5kV7b8Rfh5Y28mhTXOk3Ph3RdP1IaBdX0li0P2mFQpS85A3s+JiW56L7U7knhFFelXHhGxtrfxBPa2t3bWqaM1zCZ7i2vkkZbqGMlJ0TbjDnO0KyngnBIOp4X8IeG/7d8HXFvbXerWcl/YJeTi7gkgZpSu6OSDYXiAclfn3BwpAxkEFwPIaK9R0fwZoHiH+3tYiguLbS7G6itI7G41u0tpHkcSMW+0TIiBQIzhAhY564BNTv4C8I6WbcXl9qGorea3JpcE2m3UHliIRwOJCwV1ZlM+CqnBI4ZcclwPJ6K1pPD903id/D9qPPvTemxjAGPMffsH5mvcfE/wAPobTxD4MnHhiTT9O0/XoNAn+02JiTUYlZClwwZQJPMxNuPPAUelFwPniivRPh9Y2lx8VjbTw2RtUa/IS6gEsCbIJipaMqwIUgHG09OhrX1ZdB13SNRa1n0261fTdGlnvLzS9NW2tpmN3AsYWN4k2sFdsuiITkDJG7JcDySivUPFvgvwvpE3imDTf7Yd/DV9HDO1zcRYuomkKMFxH+7YEABjuB5O0dKueKPDmhaj8UfEljpvhy+Gn2Es/2iOPV7azhiIkChxI8Ajij5ChDnkjDdiXA8jor1TVvh/4e8MxeIbzU31G6trI6a1pDZ3cGZFuoZJCrTKroduzAdAQ2DgfMCMD4ZWNlJrF9qeqpAdK0qzknneeHzliZ8Qwv5XSTbLLGSp4IBz6UXA4qiuw8b+F9U0opq2ox6bBHfTGO3FgoSK5VUQmeJVG3y23ryMDcSNowQO80jwlo/ijwF4StHt7WzvLeOXVLy+SNVlls1upY7jc3VyiiNlB6ANRcDxOivWfidoulXsOp+IrKxi00rFohisrNFjgQXVlJLJ8oHXdGvOe5znPG94U8N6Xo2u6loc8Et5pi+JdCiaKdlJkDifhsqQVy3IxyMjjOaLgeEUV6C2h6brOleJZdGt3sli1Gyt4YtQurdgC4uNxM7RxhFyg4BUf3t2ARreB9LTR/D/jNru78NWt/Zz2MaX2oW0Wp26B/OLKhSKdSWwvKj+HBIxRcDyiivarDTdA/sO/1LWLJNUNxoNxdh9OSCyRWXVPK3Rf6PlcjGCy5VSy4AIC8rpvgnTdR1DwbEJLxIddsbm7mHmKWjMc1yihTt6bYEzkdSemQAXGef0V1/jPRtC8P2+k2tiuoyanc2FnfXE08yeSnnQLI0aoEyeWBDFuBxg/erkKBBRRRTAKkh580HkGJ8j1wpI/UA/hUdSwdZP8ArlJ/6AaEBlUUUVmaHefHv/krPiD/ALd//SeOinfHp2HxY8QAMQP9H7/9O8dFRLdhHZB8CP8Akrug/W5/9J5K4Gu++BH/ACV3Qfrc/wDpPJXA1cdhdQooooGSxfdP1q5C32e2muD1x5aeu4989sCqKybRjFaV1bLNFbxpdWwWJTndJzuPX8Kzad7mnMrWMiir39m/9Pdp/wB/P/rUf2b/ANPdp/38/wDrVPKyblGir39m/wDT3af9/P8A61bVh8PfEWqWkd3Y6XdXVrJnZNBBI6NgkHDBcHBBH4UcrC6OXrsPhf8AEXVvhX410zxLpM0wa2kUXNvHJsF5blgZIGJBGGA6kHaQGHKgg/4Vb4t/6AOo/wDgJL/8TXPf2W3/AD82v/fz/wCtRysLo9D+PnxkvfjR46uNW3XcOg237nS7C4dT9niwAzELwHcrub7xHC7mCLXltX/7Lb/n5tf+/n/1q3bf4a+KLuCK4t9GvpYJVDxyR20rK6kZBBC4II70cr7Bc5OiusuPhr4otLeW4uNGvoYIVLySSW0qqigZJJK4AA5zWD/Zv/T3af8Afz/61HKwuijRV7+zf+nu0/7+f/Wo/s3/AKe7T/v5/wDWo5WFyRW+0WCN/Hbna2epU9Of0xVV/uGr9larbysXurYxuhRtsnOD6VnyNtZ04OCRlTkGqSZXMrWIqKKK0MwrT/5dbT/rmf8A0NqzKv20oniSA/61MhP9oHnb9c5Pvn6A1Ell/RtYvfD+p2+padN5F9bktFLtVihIIyAQRnng9jyOasaP4m1XQIrqLTrswR3ZjMq7FYMUbcp+YHBB9OxIPBIOUylSVYEEcEHtSVRJ0d/4617UUmimu4kgmtjZtBb2sMMQiMiyEKiKFUl0UkgAnHJpW8feIDaW9qt8sSQSRSiSG3ijldozmMvIqh5Np5G4nFc3RSA6ZPH+uxX95epLZK96qi4hGnW32ebbyrND5fllgSTu255PPNU7jxbrF15Hm3hb7PeNfx/u0+WZggLDjpiJBt6DbwOtYtFAGrZ+JNT0/Xv7dtrny9W815xceWpIkbOWAIwDySOODyMYFP0PxTq3hvzf7Mu/IEskMrgxo4LxSCSNsMDghhn6Eg8Eg49FAGjYa9qGmaq+qWtx5d+4lBl2Kc+YrK/BGOVdh04zxUVjqt3psV9FazeXHfwfZrgbQd8e9X28jj5kU5GDx9ap0UAbF74q1fUZdZlubvzH1qQS3p8tB5zB94PA+X5uflxWkfiN4ia+kvXubR7iaD7POz6fbsLlNwb96pjxK2VU7nDNkDmuVooA39Y8ba7r8d3HqN956XZtzKPKRd3kIyRfdUY2q7DjrnnOBVPQ/EGo+G7x7rTbgQyyRtDIGjWRJYz1R0cFWU4HDAjgVmUUAb2u+M9a8S2lvaandRzW1q5eCJLeKNYMgAqgRRsQ4B2Lhc84zzWdd6teX1lp9lcTb7bT0eO3TaB5as5dhkDJyzE8561SooA6W28f+ILSWSRLyJ/MtoLRkmtYZYzHAgSL5HQruRQAGxu6nOSajuPHXiG6vL28l1KRru9uoL2aYIoZpod3lvkDgjc3TGc85rnqKANvU/Fuq6tHfx3ElssV/JFLcR29pDAsjxhwjYjRQD+8fJHXPOeKo2+r3lrpl7pkU22yvXjknj2g72j3bDnGRje3Q855qlRQBv6d411vShaLb3URjtLZ7OOKa2iljMLyGRkZHUq4LsW+YHnHoKtaX8RvEmjWqW1jfRRRxmTyj9khZ4hJneqMULIjZOVUheTxXLUUAXNS1W71eaGa9m82SGCK2Q7QuI40CIvAHRVAz1OOc1ToopgFFFFABUsHWT/rlJ/6Aaip0z/ZEdWBE7qVCnqgPUn6jIx759MgzNooorMs7z49/wDJWfEH/bv/AOk8dFHx7/5Kz4g/7d//AEnjoqJbsI7Ik+BIX/hbeg8nObjt/wBO8lef133wI/5K7oP1uf8A0nkrgatbC6hRRRQMKKKKACiiigAqzYahd6Xdx3djdT2t1HnZNBIUdcgg4YcjIJH41WooA7yw+NHjvTrSO2h8QztHHnBnijmc5JPLupY9e59uldX/AMNNeLf+gdof/fmX/wCO14xRTuyeVHs//DTXi3/oHaH/AN+Zf/jtc7qHx08d6h9qX+2vs8NxuHl29vGnlq2eEfbvGAeDu3D1zzXnVFF2HKi7qesajrdwtxqd/dX06qEWS6maVguScAsScZJOPc1SoopDCiiigYUUUUAFFFFABRRRQBYW+ukUKtzMFAwAHOAKX+0Lv/n6n/7+Gq1FO7FYs/2hd/8AP1P/AN/DR/aF3/z9T/8Afw1WoouwsWf7Qu/+fqf/AL+Gj+0Lv/n6n/7+Gq1FF2Fiz/aF3/z9T/8Afw0f2hd/8/U//fw1WoouwsWf7Qu/+fqf/v4aP7Qu/wDn6n/7+Gq1FF2Fiz/aF3/z9T/9/DR/aF3/AM/U/wD38NVqKLsLFn+0Lv8A5+p/+/ho/tC7/wCfqf8A7+Gq1FF2Fiz/AGhd/wDP1P8A9/DR/aF3/wA/U/8A38NVqKLsLFn+0Lv/AJ+p/wDv4aP7Qu/+fqf/AL+Gq1FF2Fiz/aF3/wA/U/8A38NH9oXf/P1P/wB/DVaii7CxZ/tC7/5+p/8Av4aP7Qu/+fqf/v4arUUXYWLP9oXf/P1P/wB/DR/aF3/z9T/9/DVaii7CxZ/tC7/5+p/+/ho/tC7/AOfqf/v4arUUXYWLP9oXf/P1P/38NVqKKLgFFFFIZ33x6C/8LY8QZJz/AKP2/wCneOim/Hv/AJKz4g/7d/8A0njoqJbsI7Iwvh54jXwl490bV5WjW3t7nbO8iswSJwUkbC8khGYjGeQOD0pPGvh1vCfizV9GZXCWk7LF5jKzNEfmjYleMlCp7deg6Vy8n+sf6mvRNK8T6D4p0HTPD3itpNPudNRo7TxBGrTskWdwgli6ugywUqfl+UAAbiai+gn3OFor0QfBTxPe/vNDfStetB8rXWl6hE8SP3Qlip3AEHp0YUv/AAon4gf9AD/yct//AI5VWYXR51RXov8Awon4gf8AQA/8nLf/AOOUf8KJ+IH/AEAP/Jy3/wDjlFmF0edUV6L/AMKJ+IH/AEAP/Jy3/wDjlH/CifiB/wBAD/yct/8A45RZhdHnVFei/wDCifiB/wBAD/yct/8A45R/won4gf8AQA/8nLf/AOOUWYXR51RXov8Awon4gf8AQA/8nLf/AOOUf8KJ+IH/AEAP/Jy3/wDjlFmF0edUV6L/AMKJ+IH/AEAP/Jy3/wDjlH/CifiB/wBAD/yct/8A45RZhdHnVFei/wDCifiB/wBAD/yct/8A45R/won4gf8AQA/8nLf/AOOUWYXR51RXov8Awon4gf8AQA/8nLf/AOOUf8KJ+IH/AEAP/Jy3/wDjlFmF0edUV6L/AMKJ+IH/AEAP/Jy3/wDjlH/CifiB/wBAD/yct/8A45RZhdHnVFei/wDCifiB/wBAD/yct/8A45R/won4gf8AQA/8nLf/AOOUWYXR51RXov8Awon4gf8AQA/8nLf/AOOUf8KJ+IH/AEAP/Jy3/wDjlFmF0edUV6L/AMKJ+IH/AEAP/Jy3/wDjlH/CifiB/wBAD/yct/8A45RZhdHnVFei/wDCifiB/wBAD/yct/8A45R/won4gf8AQA/8nLf/AOOUWYXR51RXov8Awon4gf8AQA/8nLf/AOOUf8KJ+IH/AEAP/Jy3/wDjlFmF0edUV6L/AMKJ+IH/AEAP/Jy3/wDjlH/CifiB/wBAD/yct/8A45RZhdHnVFei/wDCifiB/wBAD/yct/8A45R/won4gf8AQA/8nLf/AOOUWYXR51RXov8Awon4gf8AQA/8nLf/AOOUf8KJ+IH/AEAP/Jy3/wDjlFmF0edUV6L/AMKJ+IH/AEAP/Jy3/wDjlH/CifiB/wBAD/yct/8A45RZhdHnVFei/wDCifiB/wBAD/yct/8A45R/won4gf8AQA/8nLf/AOOUWYXR51RXov8Awon4gf8AQA/8nLf/AOOUf8KJ+IH/AEAP/Jy3/wDjlFmF0edUV6L/AMKJ+IH/AEAP/Jy3/wDjlH/CifiB/wBAD/yct/8A45RZhdHnVFei/wDCifiB/wBAD/yct/8A45R/won4gf8AQA/8nLf/AOOUWYXR51RXov8Awon4gf8AQA/8nLf/AOOUf8KJ+IH/AEAP/Jy3/wDjlFmF0edUV6L/AMKJ+IH/AEAP/Jy3/wDjlH/CifiB/wBAD/yct/8A45RZhdHnVFei/wDCifiB/wBAD/yct/8A45R/won4gf8AQA/8nLf/AOOUWYXR51W94K8Ot4s8WaRoyq5S7nVZfLZVZYh80jAtxkIGPfp0PSumPwU8T2X7zXH0rQbQ/Kt1qmoRJE79kBUsdxAJ6dFNVdV8T6D4W0HU/D3hRpNQudSRY7vxBIrQM8Wdxgii6ohwoYsfm+YEEbSDbcL32MH4j+I18W+Odc1eJo2t7i4KwPGrKHiQBI2w3IJRVJzjkngdKK5eisnqUSSSOHYBm6nvTfMf++350UUAHmP/AH2/OnCR9jHc3Ud/rRRQA3zH/vt+dHmP/fb86KKADzH/AL7fnTpJHDsAzdT3oooAb5j/AN9vzo8x/wC+350UUAOEj7GO5uo7/Wm+Y/8Afb86KKADzH/vt+dHmP8A32/OiigB0kjh2AZup703zH/vt+dFFAB5j/32/OnCR9jHc3Ud/rRRQA3zH/vt+dHmP/fb86KKADzH/vt+dOkkcOwDN1PeiigBvmP/AH2/OjzH/vt+dFFADhI+xjubqO/1pvmP/fb86KKADzH/AL7fnR5j/wB9vzoooAdJI4dgGbqe9N8x/wC+350UUAHmP/fb86cJH2MdzdR3+tFFADfMf++350eY/wDfb86KKADzH/vt+dOkkcOwDN1PeiigBvmP/fb86PMf++350UUAOEj7GO5uo7/Wm+Y/99vzoooAPMf++350eY/99vzoooAdJI4dgGbqe9N8x/77fnRRQAeY/wDfb86cJH2MdzdR3+tFFADfMf8Avt+dHmP/AH2/OiigA8x/77fnTpJHDsAzdT3oooAb5j/32/OjzH/vt+dFFADhI+xjubqO/wBab5j/AN9vzoooAPMf++350UUUAf/Z",
	"keren": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4lkkcOwDN1Pem+Y/99vzok/1j/U16RNNF8MoLa0tLZB41C77u9fEi2auARFGpG0sUxubBxuYAnPy99Onz3bdkv6+88/E4l0nGEI805bLbbdt9EtLuz3SSbZjaf8MfGepwtNBot2iK20i4ZYGzgH7shBI564x+VXR8IPHG0/8AEnbOR/y9w/8Axdcvf6ne6rMs1/eXF3Mq7BJcStIwXJOMk9Mk/nVWtf3C+y/vX+RhyZg9faQX/bkn+POvyR2H/CoPHP8A0CG/8C4f/i6P+FQeOf8AoEN/4Fw//F1x9FH7j+V/+BL/AORD2eYf8/Yf+C5f/LDsP+FQeOf+gQ3/AIFw/wDxdOf4QeOCzY0dsZ4/0uH/AOLrjaKP3H8r/wDAl/8AIh7PMP8An7D/AMFy/wDlh2H/AAqDxz/0CG/8C4f/AIuj/hUHjn/oEN/4Fw//ABdcfRR+4/lf/gS/+RD2eYf8/Yf+C5f/ACw7IfCDxxtP/EnbOR/y9w//ABdN/wCFQeOf+gQ3/gXD/wDF1x9FH7j+V/8AgS/+RD2eYf8AP2H/AILl/wDLDsP+FQeOf+gQ3/gXD/8AF0f8Kg8c/wDQIb/wLh/+Lrj6KP3H8r/8CX/yIezzD/n7D/wXL/5Ydk/wg8cFmxo7Yzx/pcP/AMXTf+FQeOf+gQ3/AIFw/wDxdcfRR+4/lf8A4Ev/AJEPZ5h/z9h/4Ll/8sOw/wCFQeOf+gQ3/gXD/wDF04fCDxxtP/EnbOR/y9w//F1xtFH7j+V/+BL/AORD2eYf8/Yf+C5f/LDsP+FQeOf+gQ3/AIFw/wDxdH/CoPHP/QIb/wAC4f8A4uuPoo/cfyv/AMCX/wAiHs8w/wCfsP8AwXL/AOWHYf8ACoPHP/QIb/wLh/8Ai6c/wg8cFmxo7Yzx/pcP/wAXXG0UfuP5X/4Ev/kQ9nmH/P2H/guX/wAsOw/4VB45/wCgQ3/gXD/8XR/wqDxz/wBAhv8AwLh/+Lrj6KP3H8r/APAl/wDIh7PMP+fsP/Bcv/lh2Q+EHjjaf+JO2cj/AJe4f/i6b/wqDxz/ANAhv/AuH/4uuPoo/cfyv/wJf/Ih7PMP+fsP/Bcv/lh2H/CoPHP/AECG/wDAuH/4uj/hUHjn/oEN/wCBcP8A8XXH0UfuP5X/AOBL/wCRD2eYf8/Yf+C5f/LDsn+EHjgs2NHbGeP9Lh/+Lpv/AAqDxz/0CG/8C4f/AIuuPoo/cfyv/wACX/yIezzD/n7D/wAFy/8Alh2H/CoPHP8A0CG/8C4f/i6cPhB442n/AIk7ZyP+XuH/AOLrjaKP3H8r/wDAl/8AIh7PMP8An7D/AMFy/wDlh2H/AAqDxz/0CG/8C4f/AIuj/hUHjn/oEN/4Fw//ABdcfRR+4/lf/gS/+RD2eYf8/Yf+C5f/ACw7D/hUHjn/AKBDf+BcP/xdOf4QeOCzY0dsZ4/0uH/4uuNoo/cfyv8A8CX/AMiHs8w/5+w/8Fy/+WHYf8Kg8c/9Ahv/AALh/wDi6P8AhUHjn/oEN/4Fw/8AxdcfRR+4/lf/AIEv/kQ9nmH/AD9h/wCC5f8Ayw7IfCDxxtP/ABJ2zkf8vcP/AMXTf+FQeOf+gQ3/AIFw/wDxdcfRR+4/lf8A4Ev/AJEPZ5h/z9h/4Ll/8sOw/wCFQeOf+gQ3/gXD/wDF0f8ACoPHP/QIb/wLh/8Ai64+ij9x/K//AAJf/Ih7PMP+fsP/AAXL/wCWHZP8IPHBZsaO2M8f6XD/APF03/hUHjn/AKBDf+BcP/xdcfRR+4/lf/gS/wDkQ9nmH/P2H/guX/yw7D/hUHjn/oEN/wCBcP8A8XTh8IPHG0/8Sds5H/L3D/8AF1xtFH7j+V/+BL/5EPZ5h/z9h/4Ll/8ALDsP+FQeOf8AoEN/4Fw//F0f8Kg8c/8AQIb/AMC4f/i64+ij9x/K/wDwJf8AyIezzD/n7D/wXL/5Ydh/wqDxz/0CG/8AAuH/AOLpz/CDxwWbGjtjPH+lw/8AxdcbRR+4/lf/AIEv/kQ9nmH/AD9h/wCC5f8Ayw7D/hUHjn/oEN/4Fw//ABdH/CoPHP8A0CG/8C4f/i64+ij9x/K//Al/8iHs8w/5+w/8Fy/+WHT6h8MvGWmWwln0S6cM4UC3ZZ26E/djJIHHXGOlcd5j/wB9vzrUsNTvdKmaawvLi0mZdhkt5WjYrkHGQemQPyrtIZovibBc2l3bIfGpXfaXqYjW8VASYpFA2hgmdrYGdqgkY+Y9nCppTun2et/npr8iZYjE4Vc+JtKHVxTVvNpt6Lq+bTe1r2838x/77fnRTaK5T1Dsfhjp8Wp/ETRYJmdUS4acFCAd0atIo57ZQZ9s1ianfy6rqV5fzKizXczzuEBChmYk4z2ya6j4Qhf+FlaPyc5n7f8ATGSuNrq2oR9X+UTzYa5hUv0hD8ZTv+S+498+DniLwvpnhp4Jbq0sNUEhN09zIsZm5OwqzHkBeMDoc8c5Pon/AAmfhv8A6GDSf/AyP/4qvj+iu+jms6UFBRWh89juDaGMxE8RKrJOTv0f9Lt2Wh9gf8Jn4b/6GDSf/AyP/wCKo/4TPw3/ANDBpP8A4GR//FV8f0Vr/bM/5Ucn+oeH/wCf0vuR9gf8Jn4b/wChg0n/AMDI/wD4qj/hM/Df/QwaT/4GR/8AxVfH9FH9sz/lQf6h4f8A5/S+5H2B/wAJn4b/AOhg0n/wMj/+Ko/4TPw3/wBDBpP/AIGR/wDxVfH9FH9sz/lQf6h4f/n9L7kfYH/CZ+G/+hg0n/wMj/8AiqP+Ez8N/wDQwaT/AOBkf/xVfH9FH9sz/lQf6h4f/n9L7kfYH/CZ+G/+hg0n/wADI/8A4qj/AITPw3/0MGk/+Bkf/wAVXx/RR/bM/wCVB/qHh/8An9L7kfYH/CZ+G/8AoYNJ/wDAyP8A+Ko/4TPw3/0MGk/+Bkf/AMVXx/RR/bM/5UH+oeH/AOf0vuR9gf8ACZ+G/wDoYNJ/8DI//iqP+Ez8N/8AQwaT/wCBkf8A8VXx/RR/bM/5UH+oeH/5/S+5H2B/wmfhv/oYNJ/8DI//AIqj/hM/Df8A0MGk/wDgZH/8VXx/RR/bM/5UH+oeH/5/S+5H2B/wmfhv/oYNJ/8AAyP/AOKo/wCEz8N/9DBpP/gZH/8AFV8f0Uf2zP8AlQf6h4f/AJ/S+5H2B/wmfhv/AKGDSf8AwMj/APiqP+Ez8N/9DBpP/gZH/wDFV8f0Uf2zP+VB/qHh/wDn9L7kfYH/AAmfhv8A6GDSf/AyP/4qj/hM/Df/AEMGk/8AgZH/APFV8f0Uf2zP+VB/qHh/+f0vuR9gf8Jn4b/6GDSf/AyP/wCKo/4TPw3/ANDBpP8A4GR//FV8f0Uf2zP+VB/qHh/+f0vuR9gf8Jn4b/6GDSf/AAMj/wDiqP8AhM/Df/QwaT/4GR//ABVfH9FH9sz/AJUH+oeH/wCf0vuR9gf8Jn4b/wChg0n/AMDI/wD4qj/hM/Df/QwaT/4GR/8AxVfH9FH9sz/lQf6h4f8A5/S+5H2B/wAJn4b/AOhg0n/wMj/+Ko/4TPw3/wBDBpP/AIGR/wDxVfH9FH9sz/lQf6h4f/n9L7kfYH/CZ+G/+hg0n/wMj/8AiqP+Ez8N/wDQwaT/AOBkf/xVfH9FH9sz/lQf6h4f/n9L7kfYH/CZ+G/+hg0n/wADI/8A4qj/AITPw3/0MGk/+Bkf/wAVXx/RR/bM/wCVB/qHh/8An9L7kfYH/CZ+G/8AoYNJ/wDAyP8A+Ko/4TPw3/0MGk/+Bkf/AMVXx/RR/bM/5UH+oeH/AOf0vuR9gf8ACZ+G/wDoYNJ/8DI//iqP+Ez8N/8AQwaT/wCBkf8A8VXx/RR/bM/5UH+oeH/5/S+5H2B/wmfhv/oYNJ/8DI//AIqj/hM/Df8A0MGk/wDgZH/8VXx/RR/bM/5UH+oeH/5/S+5H2B/wmfhv/oYNJ/8AAyP/AOKo/wCEz8N/9DBpP/gZH/8AFV8f0Uf2zP8AlQf6h4f/AJ/S+5H2B/wmfhv/AKGDSf8AwMj/APiqP+Ez8N/9DBpP/gZH/wDFV8f0Uf2zP+VB/qHh/wDn9L7kfYH/AAmfhv8A6GDSf/AyP/4qj/hM/Df/AEMGk/8AgZH/APFV8f0Uf2zP+VB/qHh/+f0vuR9gf8Jn4b/6GDSf/AyP/wCKo/4TPw3/ANDBpP8A4GR//FV8f0Uf2zP+VB/qHh/+f0vuR9KfEnxT4TvfCF/BNf2OoTOpFtFbTLK6zYOxxtPygHkn0yOc4Pzrpl/LpWpWd/CqNNaTJOgcEqWVgRnHbIqrRXBicXLETU2rWPpMoyanltCWHjJyUnd3+7Y6P4pafFpnxA12CFnZHmE5LkE7pFEjDjtlzj2xRV34xBf+Fj61knP7nt/0xSiufFK1eaXd/mdWUycsBQlLdwj/AOkoPhB/yUvSPrP/AOiZK4+uw+EH/JS9I+s//omSuPq/+XEfWX5RJp/8jCr/AIKf/pVQKKKKxPRCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiitrSdJt3tf7R1HzTZGRoY4oHCyTOApb5iCFCh1JJBzkADqVqMXJ2RnUqKCu/wDh/wCv+C9DForrftumf9C3pn/f26/+PUfbdM/6FvTP+/t1/wDHq09kv5l+P+Rj9Yn/AM+pf+S//JHJUV1v23TP+hb0z/v7df8Ax6j7bpn/AELemf8Af26/+PUeyX8y/H/IPrE/+fUv/Jf/AJI5Kiut+26Z/wBC3pn/AH9uv/j1H23TP+hb0z/v7df/AB6j2S/mX4/5B9Yn/wA+pf8Akv8A8kclRXW/bdM/6FvTP+/t1/8AHqPtumf9C3pn/f26/wDj1Hsl/Mvx/wAg+sT/AOfUv/Jf/kjkqK637bpn/Qt6Z/39uv8A49R9t0z/AKFvTP8Av7df/HqPZL+Zfj/kH1if/PqX/kv/AMkclRXW/bdM/wChb0z/AL+3X/x6j7bpn/Qt6Z/39uv/AI9R7JfzL8f8g+sT/wCfUv8AyX/5I5Kiut+26Z/0Lemf9/br/wCPUfbdM/6FvTP+/t1/8eo9kv5l+P8AkH1if/PqX/kv/wAkclRXVnTrDXnS2srFbDUpCEgWGV2gmbshDlmVmJwG3beACACXHKVEocppTqqd01Zro/8AgXCitnStKge1/tDUPNNkZGhjigcLJM4ALfMQQoUMpJIOcgAdSun9s0z/AKFzTf8Av7c//HqxlUUXYyni1GVoxcvS36tf15nJ0V1n2zTP+hc03/v7c/8Ax6j7Zpn/AELmm/8Af25/+PVPtokfXP8Ap3L/AMl/+SOTorrPtmmf9C5pv/f25/8Aj1H2zTP+hc03/v7c/wDx6j20Q+uf9O5f+S//ACRydFdZ9s0z/oXNN/7+3P8A8eo+2aZ/0Lmm/wDf25/+PUe2iH1z/p3L/wAl/wDkjk6K6z7Zpn/Quab/AN/bn/49R9s0z/oXNN/7+3P/AMeo9tEPrn/TuX/kv/yRydFdZ9s0z/oXNN/7+3P/AMeqlqOl2t1az32nRvD9nAe5tnfcFUsFDoxGdu5gu05YZBy2WKuNWLdioYtNpSi1fvb9GzAooorQ7DrvjH/yUfWv+2P/AKJSij4x/wDJR9a/7Y/+iUoq8X/Hqer/ADPPyf8A5F+H/wAEf/SUO+EH/JS9I+s//omSuPrsvhC7H4laONxxmfjP/TGSuNq/+XEfWX5RFT/5GFX/AAU//SqgUUUVieiFFFFABRT4YZbmaOGGN5JpGCJGilmZicAADqSa9Rg+GmleE7SDUvG2o+X5nMWm2nzPKQA20t+anGAMj5xmtqVCdW7jst30Rw4zMKOE5Y1HeUtopXk/Rf0jznSdHv8AXbxbPTbSa6uGx8kS52jIGSeijJHJwBmu+s/grqyW6Xmt6jp+kWQz5rTS7ni5wueicnH8ff14p978VLixhWw8J6fb6Lp0bAgrGryy4G3LZBGSAuepyv3jXFXlzqGrTLNf3c9zKqhRJcStIwXJOASTxyePet0sPT7zf3L/AD/I4W8zxTunGjH/AMCn/wDIr/yY7seEfhvp/wDo2oeLLue8T78lomYmzyNuEcdCAfmPOenQL/a/wq/6FnVf+/rf/Hq8/FmuOWJPtTxbR4+7+tP6xb4acV8r/ncf9kOWtXEVG/KXKvuil+tuh3v9r/Cr/oWdV/7+t/8AHqQ+H/hjqfNtr+o2Nxc/6uKZCY7dm6KxKYwpODl+g+93rg/s0X939TTDaLjhmB96PrF/ihF/K35WD+x+XWniKif+K/4STO6n+C13dwyXHh/XNM1e2jUgsj7WMgGdgwWXONvVh15wOa4TXPDereGrgQarYzWrt90sMo/AJ2sMq2MjOCcZ5p9s15p1wlzZXEsM6Z2ywuUdcjBwR04JH412Ol/FfV7eI2WuW9vremlVVre8Rd2FHHzYOTnaSWDE47Hmk/q89GnB/ev8/wAxcuaYZ3Uo1o9muSXya91/NL5Hm1FesL4D8M+Ollm8Hag9jfRrvfTb/OFXIXIbkgcEnBfllHy15jqWm3ej309jfQPBdwNtkjfqD/UEcgjgg5FY1aE6aUnqn1Wx24PMqOKk6cbxnHeMlaS+XVeauvMq0UUVgd4UUUUAFdbe/wDIF8N/9eL/APpVPXJV1t2Q+heHXU7kS1kiZhyA4uJWKn3Cuhx6MD3FbUtpen6o5cR8dL/F/wC2yINNs/7Q1G0s9+z7RMkW/Gdu5gM479a6ybwDFJquo6Rp+qNcapZKXMMtv5YlAAJCMGbnkcECuV0i7Sw1Wxu5Axjt50lYL1IVgTj34rtn8baTZeItT8QWEd7NqF0pWGOeNI44SQBkkMxbp7V00FScf3nf8DzMxnjY1bYa9uV20VnK6sm2tFa99V95gQ+GIodDtdX1S+a0t7uQpbpFD5sj44LEblAA+ufatS2+HMsmutp01+qW7WZvobqKLeJY+MfKSMHn1qn/AMJDp+q+HNP0jVRdRPp7sYbi2RZNysclWVmXn3z+Fbdp8Q7FfEAupba5i02DTjp9ukYV5AOMM2SB29fStIRw+nN5f8G5y4irmaU/Z3v7/RWSv7nLpq2t7363S0ObuPC6yaG+s6XeG8tIpRFMkkPlSxMcYyuWBByOQe9aL+BYbfVbXRrvVlh1m4QERCAtEjMMqjPuzk+ykc1XbxJZaZ4bn0bSVuXa6mWWe6uUVD8pBVVQFscgck+taU/jDRr/AMQ2niO6t71dQgCM9tGFMUkijCneTlRwONp6UlGhpffS+9ut7fgVOpmOtr8vvWdlzPRct1ayTfN0WyvYzrTwNcGx1G8vpJ4o7G5No8dtb+fJvHJONygKMjnPemaT4Us9Uj1u4XVJRZ6XGkpdbXLyAg5G0uMEYx1qzpvjFob691FtT1KxvLu4aZ0tYklhZT0BVmHI5GeeMVrR/EOwk1LxLdeXeWJ1SKOOGS1VWeMqCN5+Zeeexqoxw7tfz/J26+hFarmkedJX2tZLTWN1Zxd9OazTfpexi3HgG6OraPY2Vys41WAXETyJ5ZRMZO9cnGB6E1GPCFvew6odK1M3dxpimSWJ4PLDoOrIdxzj3ArVm+IUUGsaDf2sE1zLp0LQz3F1hZboEY5wTjHOOT1qna+JdI0KPWZdJjvZLrUomgX7QiqtujHJ5DHcemOB0pOOHu7bf8Dp8/UcauacquneytorN8zvzaaLls1t166EUHhbSbjw9da2urXotbaYQuhsE3ljjoPOxjn1rl1gNxdrBbb5TI+yLK4ZsnA4ycE+mTW/Z+IbW38E6hojRzG7ubpZlcAbAo29TnOePSq3hHVLHRNettQ1CKaWK2y6JEASZMfLnJHAPP4VjJU5OCWl9zvpSxVOFec7yab5VZaqytslu7o0/GXgV/CcFrOt8t5FK7RSMke0RSAA7epzxn06Vm+LfDf/AAi2qLY/aftO6FJd/l7PvZ4xk+lbE3je21XQtZ0/UbBYpLyX7VC9ruYCfPJbe5wCMD5enPFZ/jjxDa+JtZS9tI5kiWBIsTABsjOehPFaVlR5XKn5W387/oc2AnmPtIU8T05uZ2WvwuL09WtO2pzVJ4z/AORw8Qf9hC4/9GNUkMMlxLHFFG0ksjBURBlmJ4AAHU1B4tmiufFWuTQyJJDJfTukiMGVlMjEEEdQRXI/gfqv1PWf+8R/wy/OJqXn/IG8Of8AXk//AKUz1ShhkuZo4YUaSWRgiIoyWJOABVy5IfQ/D7qdyJayRMw5AcXErFT77XQ49GB7in+H9U/sPXdN1Ix+YLO4SYp/eCsDivNn8TOJNqM3FXd5fmzvrj4DeKINJN4Gs5LhV3mzSQmT6A42k+2fxrznTtPuNU1C2sLZN1zcyLFGp4yxOB9K+qLj4yeEYdKN8mpCV9mVtVRhKW/u4xx9envXzFY69Pp/iOHW4kTz4rn7SE/hzu3bfp2qEeRlWLx1eNT6xCzW11bXXQ6tPhrBda3d+H7PXFn1+2RmMBtisMjqMsiybskjnqoHFQp8NLmbwF/wlEF3vlQuZLExYZURyrMGzzjgkYGAfatO38eeH9N8V3viyztdQbVJ1do7OVUEMUrjDMZA2WHJ42jr1qHTviXHpmh+HLaOGeS70+6nlvFdV8qeKUtuQc85Ddx1o1Kc8faPJ/dvdLs+Zel7K/nuxV+FG7xM2i/2v93TP7R877N9Pk27/frn8K5zwT4S/wCEx1O6svtn2XyLWS53+Xv3bcfLjI65613T/FHQj46n1lLXUE059KOnqnloZFbPXG/GMe+a53wb4k0DwbrFxeRz6neRXFlNbsGs44mVmK7SP3rZHBz0xx17A4Vcb7KXMnzcqtot9b9Ldt/kRRfDe4uvAC+Kra9Erguz2XlYZY0cqzht3OOCeOhrRi+FCv4pOiNrBVRpo1Ezi1yccfJt3+/XP4VFpPxHg0bw94ZsbeCd7jTLmZ7pHVfKnhkJ3IOcnIPcda3f+FqaGvjyXXIrfUYrA6X9hRVjTzUbIwcb8YAHrmjUipUzBOaitPetou/ur7tV3vrseWalFpkRj/s67u7gHO83NqsO30xtkfPf0qXQv+Pq6/68Lz/0mkqz4k1NdTe3ca3q2qsgILalHtMY4wF/evnPOenTvVbRCEmvZWO2NLC73OeAu6B0XJ7ZZlUepYDqaqO6PTk28O772f8AWy/I5Ciiiu09w674x/8AJR9a/wC2P/olKKd8YnYfEfWgGIH7nv8A9MUorTF/x6nq/wAzz8n/AORfh/8ABH/0lB8IP+Sl6R9Z/wD0TJXH12Hwg/5KXpH1n/8ARMlcfVf8uI+svyiKn/yMKv8Agp/+lVAooorE9EK1fD3h6/8AFGqRadp0XmTycsx4SNe7sewGf5AZJAqppum3esX0FjYwPPdzttjjTqT/AEAHJJ4AGTXq/iDVIvhhosfhnRQi63dQpJqV/G4ZlYj7qngg9cZA2qQR8zbh00KKknUqaRX4+SPLzDGzpSjhsMk6s9k9kuspeS/F6ILrV9D+FcN9pnh4vfeJZFWKfUZVUpAcfMqj1BGdvIyRuLbdtecXlzea3fT39/O8txO255H6sfb0GOABwBgCoILcEB26dhVl5FjGWP4etOrWdRW2itl0/rzKwWXwwrc789SW8nu/8l2S0QJGsYwo/wDr0PIkf3mAqlJdO/A+Ue3WoK5nVS2PUVLuXjeRg4+Y+4FM+2/9M/1qpRUOrIr2cS39t/6Z/rTxeIcZDCqNFHtJB7OJppKj/dYE+lOZQ4wwBFZVSx3Dx8ZyvoatVe5LpdiwEltJY57aR0ljYMjocMjDkEEd816NYeM9J8dWMGi+Nt63Imzb6rCEjMeeoY4wo4AzggggkArurz6KZZRkHnuKjntw2XXg9x610Uqsqfw6p7rozzsbgKWLS59JR+GS0lF+T/NbPqXPGXg2/wDBeqGzvB5kEmWt7lRhJl9fYjjK9vcEE87XrHgbxHbeJbOPwV4lXz7Kf5bK5LASW7gHaoY/kvXrtwVOB554h8PX/hfVJdO1GLy54+VYcpIvZ1PcHH8wcEEU61KNlVpfC/wfb/IwwGMq+0eDxdvaxV7racf5kun95dH5MyqKKK5T1grV0rWFs42tbuBrrT2bf5SybHR8feRiDtJwAeCCAMjIUrlUVUZOLuiJ04zXLI6nz/Df/QR1b/wXR/8Ax+jz/Df/AEEdW/8ABdH/APH65air9ov5V+P+Zh9Xn/z8l/5L/wDInU+f4b/6COrf+C6P/wCP0ef4b/6COrf+C6P/AOP1y1FHtF/Kvx/zD6vP/n5L/wAl/wDkTqfP8N/9BHVv/BdH/wDH6PP8N/8AQR1b/wAF0f8A8frlqKPaL+Vfj/mH1ef/AD8l/wCS/wDyJ1Pn+G/+gjq3/guj/wDj9Hn+G/8AoI6t/wCC6P8A+P1y1FHtF/Kvx/zD6vP/AJ+S/wDJf/kTqfP8N/8AQR1b/wAF0f8A8fo8/wAN/wDQR1b/AMF0f/x+uWoo9ov5V+P+YfV5/wDPyX/kv/yJ1Pn+G/8AoI6t/wCC6P8A+P0ef4b/AOgjq3/guj/+P1y1FHtF/Kvx/wAw+rz/AOfkv/Jf/kTqfP8ADf8A0EdW/wDBdH/8fo8/w3/0EdW/8F0f/wAfrlqKPaL+Vfj/AJh9Xn/z8l/5L/8AInSza3YacpOkfa5Lw/dvLlViMP8AuRqW+cdnLcZOFDAMOaooqZScjWnSVO73b6vf+vJaGpperrZxtbXcLXNgzb/KWTY6Pj7yMQdpOADwQQBkZCldTz/Dv/QQ1X/wXx//AB+uXorGVOMtWZ1MLGUuZNr0t+qZ1Hn+Hf8AoIar/wCC+P8A+P0ef4d/6CGq/wDgvj/+P1y9FL2USPqf99/h/kdR5/h3/oIar/4L4/8A4/R5/h3/AKCGq/8Agvj/APj9cvRR7KIfU/77/D/I6jz/AA7/ANBDVf8AwXx//H6PP8O/9BDVf/BfH/8AH65eij2UQ+p/33+H+R1Hn+Hf+ghqv/gvj/8Aj9Hn+Hf+ghqv/gvj/wDj9cvRR7KIfU/77/D/ACOo8/w7/wBBDVf/AAXx/wDx+qGpaxC0D2emxyxWr486SVgZLjB4zjhVyA2wE89WbC4xqKapxTuVDCxi1KTbt3t+iX4hRRRVnUdd8Y/+Sj61/wBsf/RKUUfGP/ko+tf9sf8A0SlFXi/49T1f5nn5P/yL8P8A4I/+kok+EIX/AIWVo/Jzmft/0xkrja7D4Qf8lL0j6z/+iZK4+r/5cR9ZflEVP/kYVf8ABT/9KqBRRW/4L8NS+LPEdlpiBxC7b55Fz+7iHLHODg44GRjJA71nCDnJRjuzsr1oUKcqtR2jFXfyO88JQWfw+8H/APCV3sEUmv3+5dNgnJGE4G4LjI4JYnupUAjfz5yvmXc8lxcO8ryMXZ3YlnYnJJJ611HxG8Qx+IfEht7Ioulacv2W1SLAjCrwzKASuCRwRjKhfSufVQihR0FddeSuqcPhj+L6s8zKqE1CWLrfxKur/ur7MV6LfzbEkcRoWP8A+us13aRizHmp7x8uEB4HX61WrgqSu7HuU42VwooorM0CiiigAooooAKKKKAFVipBBwRWjDKJUzxu7is2prV9koGeG4rSnKzsZzjdE1zD/Go+temYt/ih4Jl3ojeLtEh/dlWYy3UK45IwS5PIxz8+DlQ+D56RkYPSrvhPX5PCHiW01BC5hRtsyL/y0iPDDGRk9xnjIBruozUJcsvhlo/8/keNmeFnWpqrR0qU9Y/rF+UlozlKK7T4m+Go/D/iN5rII2k6kv2q0eLBj2tyVUgBcAngDOFK+tcXXPVpunNwl0O3CYmGKoxr09pK/wDwPlsFFFer/Br4F6h8XItd1J9XtND8N6DD52oapdqXWMbWbCqCNxCqSeQAPqKzbtudB5RRXsvin4P+C7LwXrXiPwp8VtN8RvpHlGXT206SyuHV5Uj3KsjEsAXBJAx78141QncAooooAKK6v4beANT+KPjTTPCejz2kGo6j5vlSXjssS+XE8h3FVY9EOMA84+tVPHHg++8AeLdW8M6lLbS3+lzGCaS2ZmjZgAflLAEjnuBRfWwHP0UV6N8HvhzoHxJ1nULHxB460zwfb21v50d1qAjKTNuA2DfLGM4JPU9OlDdgPOaKknjWKaSNXDqjFQ46MAetemfA74I6t8cPEd3pen31vp9rYwie7vJ1LiNScAKg+8xOeMgYB56ZG7ageX0V6J8QvAXhTwxYQX3hf4iad4piaf7PLClnLaXERwTv8t87k+XG4HqR6153QncAor2rwZ+z9/wl/wAEfE3xL/4SL7L/AGJJNH/Zv2Lf53lojZ83zBtz5mPunpWjYfs0nSvhXJ8QPH3if/hFbSbBsNPNh9purwEZUBTIm1m7DnjLHaKXMgseCUUHGTjpRTAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAOw+MQX/hY+tZJz+57f8ATFKKb8Y/+Sj61/2x/wDRKUVpi/49T1f5nn5P/wAi/D/4I/8ApKHfCD/kpekfWf8A9EyVx9dh8IP+Sl6R9Z//AETJXH1X/LiPrL8oip/8jCr/AIKf/pVQK9b+Gjp4b8CeKvE6t/pY/wBEgZYlZ4mwMHJ7FpUJH+x36V5JXq/jIf2P8LvBek/637VuvvN+7tyC23HOf9fjOf4enPG2E9xyq/yr8XovzOXOl7ZUcH/z8mr/AOGPvP8AK3z67HndomSzkdOBVuo4F2xL055qSsVsewyCSCN5MsxDN2pPscfq351Het8yL3AzXVfC3VPDth4+8PXHjFZX8OQXaSXXlxLLwOV3oQd8e4LvABJTcACcVjKUU3dGsYyaVmfQvwR/ZB0vxx4Lg8SeLdR1az/tL95ZWtltidYQSA8hkjbO/hl2jG3Byd2F9K/4YY+Hf/QZ8U/+BVv/APGK+jtH1az1/SLDVtOm87T9QgjubeXaV3xuoZWwwBGQQcEA1drxJ4io5N3setGhBJK1z5k/4YY+Hf8A0GfFP/gVb/8Axij/AIYY+Hf/AEGfFP8A4FW//wAYr6boqfb1O5XsYdj5k/4YY+Hf/QZ8U/8AgVb/APxij/hhj4d/9BnxT/4FW/8A8Yr6boo9vU7h7GHY8a+Hv7Lnw68A/wBo503+3/tvl/8AIwQW935Gzd/q/wB0Nu7dz67V9K7C7+FXw1srSe5l8AeGmjgjaRhDoUMrkAZO1FjLMeOAoJPQAmu2XAYZ6VJuT2/KumlWk46yXzOWtSipaJ/I/Mr9o/VPAHiTxxp938PYbGHRU02OKVbCwNnGZxLKWJQouTtKfNjpgZ4rx9baNZFwzbhzivqH9p34jfCPxh4Rtz4EOlyeJpdWW5u7i30h7aeSIxy72aVol3ZdkJBJJPPbNfLFo377nJLA16cXHRWOFqVm7l6q92mUDY5H8qsU113oy8cjvW7Mkegao6eKPgtbXkrf6XoFwsHmNEuWXIUIpHQbZI8nuY+R3ryOvWPg8P7THifw/wD6v+07A/v+vl4yn3e/+tz1H3ffjyetsT78KdTurfd/wLHj5UvYV8ThFtGXMvSavb5SUv6sFe+fs8/HWD4SaZ4h0vxD4bm1rwZr5EN0IwPkfYQy/N8r7kbBUkdAc9c+B16R8Nfjb4h+F+m6ppWnWWjajpOqOsl1ZatZC4ikZRgEjIPf1rikro9tH0D4m+Dfwe+KHwf8TfEH4ZJqWi3GhRyyzWly7FC0aCRo2V2bBKngo+Mn8K1vAv8AwnXwp+EfhHUfEvxosfBvhq/iEmmaaPDsepOY5MygMQofJD7jycbgMjpXgfjD9pTxb4q8ITeErTTvD3hvw7cnNxZeH7D7Kk3IJDfM3BIGcYzjByOKm0v9p/xpp/gjTvClxZ+H9UtNLVV0+61TTluLiy2jCGMsduVHAJUkCo5Xaw7o9j/bM8J6PpHjf4aa7p1nbwXutbhdyW8Hki4MbwlXKdmPmnrzgAHpXqHx5+KOq+B/2h/htpWj21hGdWW1gv7mW1SSaa3kumTyQ7AlFGXb5cElhnOAK+OPij+0B4o+Lc3hebXrXS45fDm/7O9rHIplLeWSZN0jZP7pemOp/A8f/H/xL8RvH3h3xpqtjpEOqaB5P2aK0ikWF/KmMq7w0jMfmODhhx6daOR6XC59cxXMvgb9t+10Lw/5Vho/iuwFxqlrDAgWd47a4ZSOMqdyBjtIyc5zk14d+0R4/wDH3xA+MeofDNNVW40uPXoYtMsWt4UEcxwkZMgTeQPMP3iRz7V5x4k/aE8XeJPilpnxHKadYeItNjSKEWcLCEqoYEFXdidwdgeeh7VL8Qf2g9d+IV7p+qTeHvC2ka/Y3sd+us6Pp5hvZJYxhN8rOxYA4OD3UelCi07hc+1PDmqeJtD+JGjeDfH3xn07XdXv03S+GF8LIUnUoxx9oRQE4BbLAcDkc1g/A7wxpvg79rP4s6PpFtHa6dDYRSxQRjCR+Z5EhVR2ALnAHQcV84z/ALYvjy41jTNabSfCo1myAR79dMxcXUYz+7kk37ghJyVQoD9MisvRP2pvGOg/E3xH8QLbTdBfWdfgjt7mGWCY26KiooKKJQwOI16seppcjHdHjWpf8hG7/wCuz/8AoRr7I/Z0Ol/BD4Fav8ZZLK61bU7y4Wxa1hmKJDb+eiHI5G7OWyQf4QMZJPxjPK1xNJKwAaRixA6ZJzXpfwx+PXi34Vadf6Tpn9n6hoOoEtcaTq1v59tIxGCduQRkAA4ODgZBwKuSurEo+sV/Zx+G/j/xna/FOzuLOb4X6lY3GoajZNM8AhnA5IKEFACWZlyNrIR0IA+D9em0+41zU5tJtzbaXJcytawFixihLkouWJJwuBkkniveLD9srxxpkD2FpoHg6HQHgeA6JFpRjsiH+8diuG5GRjdggnINeA6jdx39/c3UVnb2Uc0jOttbbvKiBOdq72ZsDtkk+9KKa3Gz79/Y+1bRdC/Zu8Q6l4iRG0S01eeW68yLzFCCODkrzkDrjB6V5n+2z4T8XajrWn+OBqf9teAbmFFsJLXmGx3AcHBIIc8iTvwOMKD4p4Y+O/iPwp8LNc+HVlZaVJomsvK8880UhuFMiop2sJAo4QYyp71ofD39pDxd8PvB9/4QS10jXPDd4GU2GtwSTRxK2d6ptdSFbOSDkZ5GCTlcrT5gv0PpD4H6L4b+H37McPjqPXLPw3ruqzuLjxJNpB1OSzAuGiWNYhyAQg68ZfJB4rkfjR46+F3j3wn4Wez8VWfiD4k6fqFusmp22hz6e19EZMMHVk2jAKn73VTjAYivEvh7+0D4r+G1jqek6ZDpV34b1GRpJdE1O3NzaAt1ADNuxgAYLHOBnJ5qDxj8cta8YWNlpw0Pwxoul2l3HfLZ6JpaWsbyoGCliCWOAzDGcc0crvcLn1L+2R8YPEXw08d6La+FjZ2GoXmk7rnUWs4pp3iMsgWIGRWCqCGPABJbrwK2tJs/DXwa+AHgTUdL8YWXgi912C3ubrXm8Ptqst3LJD5jRcfdHJAz2XAwcmvjX4wfGTXfjZr9lrWv2mm211Z2otETT43RCgdnyQ7sc5c9/TitzwT+0f4u8GeFB4UmtND8Q+GkOYtO8QWP2qKLnOFG5TjJzgkgdsUcjskF9T0b9oXxX8L/ABxqvgbV/B2rWl/4qS5jg1ea00yayS6Hy4lKOoAO4NgZY4bBJwK93+PPxR1XwP8AtD/DbStHtrCM6strBf3Mtqkk01vJdMnkh2BKKMu3y4JLDOcAV8R+N/i/rXjq60Z7rTtD0600aRprSx0mwS1gRmKliQvJz5a9T24xWr4/+P8A4l+I3j7w7401Wx0iHVNA8n7NFaRSLC/lTGVd4aRmPzHBww49OtHJsFzr/wBtDw7pvh744Xq6ZaRWsd9ZQXcscKhVMjblZgBwCdgJ9SSe9fPddz8WPirrPxi8VDxHrttYW18LdLbZYRuke1SSDh3Y5+Y964arirKzEwooopgFFFFABRRRQAUUUUAdd8Y/+Sj61/2x/wDRKUUfGP8A5KPrX/bH/wBEpRV4v+PU9X+Z5+T/APIvw/8Agj/6SiT4Qux+JWjjccZn4z/0xkrja7D4Qf8AJS9I+s//AKJkrj6v/lxH1l+URU/+RhV/wU//AEqoFesfGsfYtW0XSIPk0+xsF8iLrsyzKeTyeI0HJPT3NeT16z8df+Rusv8ArwT/ANGSVtR/3ep/27+pzYzXM8Kn2qP52j/m/vODUbVAHQDFVL1vmVfQZq5VC7bMxHoMVzVfhPap/EQUUUVzHQfRf7Qnjnxz4AHws0bSvEniPw+sfgfTTcWNpfT2gWcNMrb41YYcbApyM/KB2rxr/hd/xO/6KN4w/wDB3c//ABdfav7TP7M3ir41eN9J17QdW0G0tLTSo7F49RmnSQyLPM5ICRONuJV75yDxXi//AAwN8RP+hi8H/wDgTdf/ACPXLCpDlV2XOnLmdkeJf8Lv+J3/AEUbxh/4O7n/AOLr239n34q/H/WIfEg8KRt41SJrX7SfEepPN9jJE2zyvMuExvw+7GfuLnHGT/hgb4if9DF4P/8AAm6/+R6+if2XPgL4h+B0Hi5df1LR7xtZazMA02SV9vlCfdu8yNMf61cYz0PSlUqQ5XZpjp05cyumjxH47fE79ovSPBdrN4n0m18Haa2oxIuo+H9QMVxJL5UpWJjHcudhUOxGMZReegPzv/wu/wCJ3/RRvGH/AIO7n/4uv0Y/aU+EmsfGj4fWXh7Q73TbS9t9VhvmfUXkSMxrDOhAKI53ZlXtjGea+VP+GBviJ/0MXg//AMCbr/5HpUqkeRXsh1acud2TZ4l/wu/4nf8ARRvGH/g7uf8A4uvY/wBlb4p+O/Efx48LaZrPjXxJqWmzpe+baXuqTzQybbOdhuRmIOGAIyOoBq1/wwN8RP8AoYvB/wD4E3X/AMj16P8AAf8AZH8ZfC34q6F4s1fWvDdxp+nrciSKynuGmbzLaWJdoaFR96QZyRxn6VUqkLPVERpzutGfFd5Z3GnXdxZ3lvLb3dvI0U0EyFHjdThlZTyCCCCD0qGu0+MH/JWvHv8A2Hr/AP8ASh64uulO6uS1Z2J7RsTAeoxV+s2BtsyH3xWlXTSehhVWp1PwhuprTx/ZQxPtjuEmilGAdyhCwHt8yKePSuN8TWcOn+JNYs7ZNlvb3k0UaZJ2qrkAZPJ4Heus+FX/ACUXSvrN/wCinrmfGf8AyOHiD/sIXH/oxq6pa4Zf4n+SPEp6ZvNLrTi3680jEoorbg8LXtx4WuPEUbwGzt7j7PJHuPmjhfnxjG3LoM5zlhxXIeyYlFdHqvgjV9Ln0m28n7Xd6nbC6it7RWkkUEkFWXH3gVOQM4rJj0fUZtQOnR2F0+oAlTarCxlyOo2Yzn8KAKVFaEGg6rdXk9nBpl7LeQAmWBIHaSMDruUDI/Gr174Ylt/Fcfh+GdJJ5JooElkUou59uMgZIALe9AGDRXTp4St31vTdKj8QafczXl5HZuLWKctDuYKWIkjQEAnoD/jWOmi6hPJGttZXU4mlaGIxws3muvVVwOSAQcD1oC5QorUi8M63PdTWsWj6hJdQMEkhS2cujEEgFcZBIBPPoajs9B1XUJpYbTTL24mhcRyJDAzsjc/KQBwflbj/AGT6UAZ9FXW0fUV05dRawuhp7NtF0YW8on034xn8as/8I1qkU8MN3Y3VmZ4nmjNxbSDzFRCxIAUkjA6gYHUkDJABk0UVo6Vo1zrC35timbK3Ny6tnLKGVcLgHJy4pAZ1FdTF4GuvttxaXOo6faTWlobu6EzSN9mAZV2PsRjv+YfKM46HBBFQWXhRNQvryC31zTHtrS1N1LebbgRKoZVIwYt5OWHRce9OwXOdorqk8C3RvpoJNS0+K2jsRqIvWMrQvAWChgFQvnJxgqDwaZpPgmfX9UudP0jU9PvpILVrnzI/NRZMEL5a741JclgACADnrRYLnMUVfudIntdLsdRdo/JvJJY0UE7gY9u7Ix/tjHPrVCkAUUUUDCiiigAooooAKKKKACiiigAooooA7D4xOw+I+tAMQP3Pf/pilFN+Mf8AyUfWv+2P/olKK0xf8ep6v8zz8n/5F+H/AMEf/SUO+EH/ACUvSPrP/wCiZK4+uy+EIX/hZWj8nOZ+3/TGSuNqv+XEfWX5RFT/AORhV/wU/wD0qoFesfFs/wBo2XhHXZflu9SsB5qJxGuAr/KOvWVupPAH4+T16tcn/hIfgtZXH37jQrswySz8tsJwFQ8nGJIhg4+57CtsP71OpDyv9z/yuc2Z/u8ThcR0UnF/9vppfikcKhJRSepArPnbdM5Prirdq2Ysd1NUWbcxY9Sc1yVXoj3Ka1YlFFdP8N9Ws9A+InhHVtRm8nT9P1a0ubiXaW2RpMjM2FBJwATgAmuduyNlufrvRUNneW+o2lveWdxFcWlxGssM8Lh0kRhlWVhwQQQQR1qavDPWCiivKdej+LPhnxJqWp6HJpfi7wzPtkj0W8dLK+t2JYGOGZUEZQFlbdLltq7R83zNUVcTdj1aivF7vxL8bPE1pPYaX4F0bwldNGxGp6trCXqKMYwkcKEiTLBgWBT5CCDkV3vw/wDA1v4C0W4tEu5b7UdQu5dR1K/lUIbu7lwZJdg+WMHAAReAAOpyS3Gy1YlK70R1dFFFQUfkr8YP+StePf8AsPX/AP6UPXF16p+0j4i0vxX8a/Feq6LexX2myyQRx3MJykhjgjjYqf4huRgGHBxkEgg15XXtw+FHlT+Jiq21gw6g5rVrJrQkk/0fccZZf510UnuYVVsdx8FbGO98befIzh7S2knTaRgscJz7YkP44rznU7+XVdSvL+ZUWa7medwgIUMzEnGe2TXpvgI/2F4C8Y+IT8rtGLK3lh4micjGQeMDdJGeDn5enAryiuyt7tGnDvd/ovyPDwX73MMTW6R5YL5Lmf4yQV23h7xZZaH4etbaeAX2b24a5sWJQSwvFGo+fBA+ZMjryo4riaK5D2bHpTeL7HV9OW3vNS+zX99ps0E92Y3KwytfPOVbaCdrIQCVBxuA9RUMviLS7m61Cx/tJo1n0iDTl1V4nw7xsjEsAC+xghTpnAXI6ivO6KLiselah4h0nVdPuNJTWjayRLZf8TKSKXF35COrAhQXGC425HRBnbxjM1PxBp9z8UodbS7eTTV1CCdrh0YMUUpuYrjOeDxXEUUXHY9GuNbtI/FWialNreg3Nnb6pFcONO0xreWOMSBizkW8ZYADpljntUVx4lsb7WLLU7fUIrFTBJZyWM8EjQQIUKnbsGRG4Yk4+cMSefvHz6ii4WPUlOkXPh3xLDZaz9jtHk06NpyJ2g8wLOSi5Bk8vjIyCcgduaydf8VWd9Z+KI7W7l3X89gqllZWuUhikV5G9NzbWwTnLexriFuZkgkt1lkWCVld4wxCsy52kjoSNxx6ZPrUVFxWPT73xjpU2mefanTobiTTorB4miu3uV2oqnA8wQbdy7geD/s5yS2TxBoi6gmoTalDLf3AvWne0jnWJjJbOql0kHEhdgPk+UA15lRRcLGrod39kOo/8TD7F5tnLF/qfM8/OP3X+zu/vdsVs/D/AMUr4RvtU1BZES6NiyW4dCyvJ5sbbTjpwrc8Y9QcVyNFA7Houh6noGnapql3Y6nb2keqadIiQ6lbPcLazGSMmN/3biRcKxDYPGMgGq9j4hh0bUtcuX1DR7ua40swwtZ6aFt2kMiEIYmhRc4UnJTHTnNcFRRcLHqVh4u028u5NRm1Gysr+80Y2MkV1ZtLbQzJIm3EYjddjIudoUgNu4HFYsOtw6be65M2q6dNcXGm+VbzaXZtbx+aJo2ChRFHhgEJztx05zXD0UXCx2/jnX9K1zSdDewfbeM9xc3tsIyohmk8vdg4wVZkZhjoCB2riKKKAQUUUUhhRRRQAUUUUAFFFFABRRRQAUUUUAdd8Y/+Sj61/wBsf/RKUU74xBf+Fj61knP7nt/0xSitMX/Hqer/ADPPyf8A5F+H/wAEf/SUHwg/5KXpH1n/APRMlcfXYfCD/kpekfWf/wBEyVx9V/y4j6y/KIqf/Iwq/wCCn/6VUCvU/g1qkNxNrHhW8klW31m3YRlXPysFYOFGCAShJ3H/AJ5gc8V5ZU9leTafeW95bPsuLeRZY3wDtZTkHB4PI70Yer7Kop/1bqXmWDWNw06F7N7Ps1qn8mXpoJ9MvLq0uF8u4gZopFyDtdSQRkcHkVSr0z4laeuv6fpvjfToH+y6hCq3gXLCGVfk5JxxkbMgAZQf3hXmdRiqfs58vTp5p7GuV4tYvDqq1aW0l2ktGvk/w1CipbeHznILbUVSzNjOAPan+XZ/8/v/AJCNcx6DaR9QfsyftN2fgDT08HeMX8rw5F5kljqEUJdrRmJdo5FQFnRmLEMAWVmwcqQU+8LO8t9RtLe8s7iK4tLiNZYZ4XDpIjDKsrDgggggjrX43+XZ/wDP7/5CNenfDT49eLfhVsg0bxF9o0lc/wDEr1CF5rUZ3n5VyGj+Zyx8tl3HG7PSuSthed80dzopYlR0lsfqRRXmXwh+Lr/FvQrLVrPwxe29rPJLFNcx3lrNBbumflb94swJG04MQPzg/dIY+oGJwcbT+VcMqU47o641YS2YyineW5/hP5VxXxJ8fS/DjQtS1ifw/e3mn2Nobh7tbq1ht1fkLGxklD5LbR8qOTvAUM3y0o05y2Q5VIR3Z2dfG37Sf7U+l3eiX3g3wLdxX7X8ctrqWqBMxRxHKPFFuGHLDOZBlQpG0ktuTxr4pftNeLfib9psv7Z/sXQJdyf2dpyOnmRneNssv3pMo+1hwjbQdgNeL+XZ/wDP7/5CNd1HCcr5pnJVxSekSvRVjy7P/n9/8hGmzwLGsbxyeZFIDhsY6Hniuw5rpkNTPIWijXPQVDXf/Czw8t3qr69qCumjaKrXMkxUlTIg3ADBySPvnAP3QCPmFb4am6lRQXU4sxxUMJh5V5/Z6d30S829EanxGuf+EY8D+HfCCmVLtoxd3amT7uSxKHA2sDIzY548sdcg15JWr4k1ybxLrt9qs42vdSbgnB2KOFXIAzhQBnHOM1lVviaqqVLx2Wi9EceVYOWFw6jU+OTcpf4pav7tl5IKKKsW1t5v7yTIiBxkdWPoP8e35A4HoleitLFuOBaxkDuzNk/XBFL+4/59Iv8Avp//AIqnyi5jMorT/cf8+kX/AH0//wAVR+4/59Iv++n/APiqOUOYzKK0/wBx/wA+kX/fT/8AxVH7j/n0i/76f/4qjlDmMyitP9x/z6Rf99P/APFUfuP+fSL/AL6f/wCKo5Q5jMorT/cf8+kX/fT/APxVH7j/AJ9Iv++n/wDiqOUOYzKK0/3H/PpF/wB9P/8AFUfuP+fSL/vp/wD4qjlDmMyitP8Acf8APpF/30//AMVR+4/59Iv++n/+Ko5Q5jMorT/cf8+kX/fT/wDxVH7j/n0i/wC+n/8AiqOUOYzKK0/3H/PpF/30/wD8VR+4/wCfSL/vp/8A4qjlDmMyitP9x/z6Rf8AfT//ABVH7j/n0i/76f8A+Ko5Q5jMorT/AHH/AD6Rf99P/wDFUfuP+fSL/vp//iqOUOYzKK0/3H/PpF/30/8A8VR+4/59Iv8Avp//AIqjlDmMyitP9x/z6Rf99P8A/FUfuP8An0i/76f/AOKo5Q5jMorT/cf8+kX/AH0//wAVVa4tlVTJDuMY+8rHJX/Ee/4emRoLlWiiipKOu+Mf/JR9a/7Y/wDolKKPjH/yUfWv+2P/AKJSirxf8ep6v8zz8n/5F+H/AMEf/SUO+EH/ACUvSPrP/wCiZK4+uy+ELsfiVo43HGZ+M/8ATGSuNq/+XEfWX5RFT/5GFX/BT/8ASqgUUUVieia9t4hv4dAuNCSXGnTzrcug4JYDGMjqD8pwc8opGOc0Kji71PDEZpUjGcsccDOKicnJ69CqNOFNNxVru79e5JM32ew2H79wQceijofxNZ1Wr+YTXLbceXH8iYOeB71VrNjCiiikB9E/sjfGr/hWvjpdE1rVPs3hDXMpN9ol2wWlzgeXOflO3O0RscqMMGY4jGP0vr8R6/Sj9kP44yfEzwjJ4d1u6mn8VaBGvmXFzMjSX1uWISQDhiU+VHJB5KMWLOQBjR9IV8D/ALbXxq/trWIPh9oGqb9M0/L6x9mlyk1yG+WB/l58rbuIDEbnwQGi4+mP2kPjJF8HPh9PeW7bvEOqb7PS41ePdHKUObgq+dyR8E/KwLMinAbI/K69vbnUry4vLy4muby5kaWaeZy8krscszMeSSSSSeSTQgZBRRRQIK0LJvPtpbb+MHzU9yByPyrPqW2na2njlXqpzj1HcU0BLWhF4hv7PQr7RYpcWF9IkkqHnlOeOwydpJHJ2Lzjg1ruIQzsqcxn5lPYg1Vl+6PrWkJOL0FWpwqxtNXs0/mndP5MioooqyQrSHFpagcAoWPudzDP5AflWbWn/wAutp/1zP8A6G1VEmQyirWmadcavqVnp9nGZLu8mSCJB/E7EKo/MivbfiL8PLG3k0Ka50m58O6Lp+pDQLq+ksWh+0wqFKXnIG9nxMS3PRfanck8Ior0q48I2Ntb+IJ7W1u7a1TRmuYTPcW18kjLdQxkpOibcYc52hWU8E4JB1PC/hDw3/bvg64t7a71azkv7BLycXcEkDNKV3RyQbC8QDkr8+4OFIGMgguB5DRXqOj+DNA8Q/29rEUFxbaXY3UVpHY3Gt2ltI8jiRi32iZEQKBGcIELHPXAJqd/AXhHSzbi8vtQ1FbzW5NLgm026g8sRCOBxIWCurMpnwVU4JHDLjkuB5PRWtJ4fum8Tv4ftR596b02MYAx5j79g/M17j4n+H0Np4h8GTjwxJp+nafr0GgT/abExJqMSshS4YMoEnmYm3HngKPSi4HzxRXonw+sbS4+Kxtp4bI2qNfkJdQCWBNkExUtGVYEKQDjaenQ1r6sug67pGotaz6bdavpujSz3l5pemrbW0zG7gWMLG8SbWCu2XREJyBkjdkuB5JRXqHi3wX4X0ibxTBpv9sO/hq+jhna5uIsXUTSFGC4j/dsCAAx3A8naOlXPFHhzQtR+KPiSx03w5fDT7CWf7RHHq9tZwxESBQ4keARxR8hQhzyRhuxLgeR0V6pq3w/8PeGYvEN5qb6jdW1kdNa0hs7uDMi3UMkhVplV0O3ZgOgIbBwPmBGB8MrGyk1i+1PVUgOlaVZyTzvPD5yxM+IYX8rpJtlljJU8EA59KLgcVRXYeN/C+qaUU1bUY9NgjvpjHbiwUJFcqqITPEqjb5bb15GBuJG0YIHeaR4S0fxR4C8JWj29rZ3lvHLql5fJGqyy2a3Usdxubq5RRGyg9AGouB4nRXrPxO0XSr2HU/EVlYxaaVi0QxWVmixwILqyklk+UDrujXnPc5znje8KeG9L0bXdS0OeCW80xfEuhRNFOykyBxPw2VIK5bkY5GRxnNFwPCKK9BbQ9N1nSvEsujW72SxajZW8MWoXVuwBcXG4mdo4wi5QcAqP727AI1vA+lpo/h/xm13d+GrW/s57GNL7ULaLU7dA/nFlQpFOpLYXlR/DgkYouB5RRXtVhpugf2Hf6lrFkmqG40G4uw+nJBZIrLqnlbov9HyuRjBZcqpZcAEBeV03wTpuo6h4NiEl4kOu2NzdzDzFLRmOa5RQp29NsCZyOpPTIALjPP6K6/xno2heH7fSbWxXUZNTubCzvriaeZPJTzoFkaNUCZPLAhi3A4wfvVyFAgooopgFSQ8+aDyDE+R64UkfqAfwqOpYOsn/XKT/wBANCAyqKKKzNDrvjH/AMlH1r/tj/6JSinfGJ2HxH1oBiB+57/9MUorTF/x6nq/zPPyf/kX4f8AwR/9JQfCD/kpekfWf/0TJXH12Hwg/wCSl6R9Z/8A0TJXH1X/AC4j6y/KIqf/ACMKv+Cn/wClVAooorE9Eli+6frVyFvs9tNcHrjy09dx757YFUVk2jGK0rq2WaK3jS6tgsSnO6Tncev4Vm073NOZWsZFFXv7N/6e7T/v5/8AWo/s3/p7tP8Av5/9ap5WTco0Ve/s3/p7tP8Av5/9atSz8D63qFulzZ2U1xbvnbLDE7o2Dg4IXB5BFONOUtErkVKsKavOSS89Dna7D4X/ABF1b4V+NdM8S6TNMGtpFFzbxybBeW5YGSBiQRhgOpB2kBhyoIg/4V14k/6BV3/4Dyf/ABNYv9lt/wA/Nr/38/8ArU5U5x+JWFTr06n8OSduzueh/Hz4yXvxo8dXGrbruHQbb9zpdhcOp+zxYAZiF4DuV3N94jhdzBFry2r/APZbf8/Nr/38/wDrVrw+APEFxDHNDptzJDIodHSCQqykZBBC8g0o05S+FDqVqdPWpJL1djmaK6abwB4gtoZJptOuY4Y1LvI8EiqqgZJJK8ACsf8As3/p7tP+/n/1qJU5R3Vgp1qdTWnJP0dyjRV7+zf+nu0/7+f/AFqP7N/6e7T/AL+f/WpcrLuSK32iwRv47c7Wz1Knpz+mKqv9w1fsrVbeVi91bGN0KNtk5wfSs+RtrOnBwSMqcg1STK5laxFRRRWhmFaf/Lraf9cz/wChtWZV+2lE8SQH/WpkJ/tA87frnJ98/QGoksv6NrF74f1O31LTpvIvrclopdqsUJBGQCCM88HseRzVjR/E2q6BFdRaddmCO7MZlXYrBijblPzA4IPp2JB4JBymUqSrAgjgg9qSqJOjv/HWvaik0U13EkE1sbNoLe1hhiERkWQhURQqkuikkAE45NK3j7xAbS3tVvliSCSKUSQ28UcrtGcxl5FUPJtPI3E4rm6KQHTJ4/12K/vL1JbJXvVUXEI062+zzbeVZofL8ssCSd23PJ55qnceLdYuvI828LfZ7xr+P92nyzMEBYcdMRINvQbeB1rFooA1bPxJqen69/bttc+Xq3mvOLjy1JEjZywBGAeSRxweRjAp+h+KdW8N+b/Zl35AlkhlcGNHBeKQSRthgcEMM/QkHgkHHooA0bDXtQ0zVX1S1uPLv3EoMuxTnzFZX4IxyrsOnGeKisdVu9NivorWby47+D7NcDaDvj3q+3kcfMinIwePrVOigDYvfFWr6jLrMtzd+Y+tSCW9PloPOYPvB4Hy/Nz8uK0j8RvETX0l69zaPcTQfZ52fT7dhcpuDfvVMeJWyqnc4Zsgc1ytFAG/rHjbXdfju49RvvPS7NuZR5SLu8hGSL7qjG1XYcdc85wKp6H4g1Hw3ePdabcCGWSNoZA0ayJLGeqOjgqynA4YEcCsyigDe13xnrXiW0t7TU7qOa2tXLwRJbxRrBkAFUCKNiHAOxcLnnGeazrvVry+stPsribfbaejx26bQPLVnLsMgZOWYnnPWqVFAHS23j/xBaSySJeRP5ltBaMk1rDLGY4ECRfI6FdyKAA2N3U5yTUdx468Q3V5e3kupSNd3t1BezTBFDNNDu8t8gcEbm6YznnNc9RQBt6n4t1XVo7+O4ktliv5IpbiO3tIYFkeMOEbEaKAf3j5I655zxVG31e8tdMvdMim22V68ck8e0He0e7Yc4yMb26HnPNUqKAN/TvGut6ULRbe6iMdpbPZxxTW0UsZheQyMjI6lXBdi3zA849BVrS/iN4k0a1S2sb6KKOMyeUfskLPEJM71RihZEbJyqkLyeK5aigC5qWq3erzQzXs3myQwRWyHaFxHGgRF4A6KoGepxzmqdFFMAooooAKlg6yf9cpP/QDUVOmf7IjqwIndSoU9UB6k/UZGPfPpkGZtFFFZlnXfGP/AJKPrX/bH/0SlFHxj/5KPrX/AGx/9EpRV4v+PU9X+Z5+T/8AIvw/+CP/AKSiT4Qhf+FlaPyc5n7f9MZK42uw+EH/ACUvSPrP/wCiZK4+r/5cR9ZflEVP/kYVf8FP/wBKqBRRRWJ6IUUUUAFFFFABU9ne3On3CXNncTW9wmdssLlHXIwcEcjgkVBRTTtqhSipKz2Ows/in4vsbdIItbmZEzgzRpK/JzyzqWPXua6L/hffiT/ny0n/AL9Sf/HK8toroji68dFN/eeXVyTLqzvOhG/ol+W56l/wvvxJ/wA+Wk/9+pP/AI5WJe/FzxfefaF/tXyYptw2QwouwHsrY3DHY5z755riKKJYyvLRzYqWRZdSd40I/NX/ADLV/qd7qsyzX95cXcyrsElxK0jBck4yT0yT+dVaKK5223dnqRjGK5YqyCiiikUFFFFABRRRQAUUUUAWFvrpFCrczBQMABzgCl/tC7/5+p/+/hqtRTuxWLP9oXf/AD9T/wDfw0f2hd/8/U//AH8NVqKLsLFn+0Lv/n6n/wC/ho/tC7/5+p/+/hqtRRdhYs/2hd/8/U//AH8NH9oXf/P1P/38NVqKLsLFn+0Lv/n6n/7+Gj+0Lv8A5+p/+/hqtRRdhYs/2hd/8/U//fw0f2hd/wDP1P8A9/DVaii7CxZ/tC7/AOfqf/v4aP7Qu/8An6n/AO/hqtRRdhYs/wBoXf8Az9T/APfw0f2hd/8AP1P/AN/DVaii7CxZ/tC7/wCfqf8A7+Gj+0Lv/n6n/wC/hqtRRdhYs/2hd/8AP1P/AN/DR/aF3/z9T/8Afw1WoouwsWf7Qu/+fqf/AL+Gj+0Lv/n6n/7+Gq1FF2Fiz/aF3/z9T/8Afw0f2hd/8/U//fw1WoouwsWf7Qu/+fqf/v4aP7Qu/wDn6n/7+Gq1FF2Fiz/aF3/z9T/9/DVaiii4BRRRSGdh8Ygv/Cx9ayTn9z2/6YpRTfjH/wAlH1r/ALY/+iUorTF/x6nq/wAzz8n/AORfh/8ABH/0lGR4K11fDfjLS9TkZFhhuNsrOpYLG2Uc4HJIViR7gcHpS+K9Ebw54j1LSyHC20xWPewZjGeUJI4yVKn8egrnZP8AWP8AU12+neINH8QaPYaJ4iL2U9irJba0itMyR5yIpI+rLywUg/L8oAA3EulJSg6bdtbr9V+X3BiIyoV1ioxck1yyS1dldppbu12mldu+m1nyVFdsPhVr918+ktp2sWw4a40+9jeNW7oSxU5xg9OhFL/wqHxn/wBAb/yZh/8Ai6v6rW6Qf3E/2vgOteK9ZJP7m7nEUV2//CofGf8A0Bv/ACZh/wDi6P8AhUPjP/oDf+TMP/xdH1Wv/I/uYf2xl/8A0EQ/8Cj/AJnEUV2//CofGf8A0Bv/ACZh/wDi6P8AhUPjP/oDf+TMP/xdH1Wv/I/uYf2xl/8A0EQ/8Cj/AJnEUV2//CofGf8A0Bv/ACZh/wDi6P8AhUPjP/oDf+TMP/xdH1Wv/I/uYf2xl/8A0EQ/8Cj/AJnEUV2//CofGf8A0Bv/ACZh/wDi6P8AhUPjP/oDf+TMP/xdH1Wv/I/uYf2xl/8A0EQ/8Cj/AJnEUV2//CofGf8A0Bv/ACZh/wDi6P8AhUPjP/oDf+TMP/xdH1Wv/I/uYf2xl/8A0EQ/8Cj/AJnEUV2//CofGf8A0Bv/ACZh/wDi6P8AhUPjP/oDf+TMP/xdH1Wv/I/uYf2xl/8A0EQ/8Cj/AJnEUV2//CofGf8A0Bv/ACZh/wDi6P8AhUPjP/oDf+TMP/xdH1Wv/I/uYf2xl/8A0EQ/8Cj/AJnEUV2//CofGf8A0Bv/ACZh/wDi6P8AhUPjP/oDf+TMP/xdH1Wv/I/uYf2xl/8A0EQ/8Cj/AJnEUV2//CofGf8A0Bv/ACZh/wDi6P8AhUPjP/oDf+TMP/xdH1Wv/I/uYf2xl/8A0EQ/8Cj/AJnEUV2//CofGf8A0Bv/ACZh/wDi6P8AhUPjP/oDf+TMP/xdH1Wv/I/uYf2xl/8A0EQ/8Cj/AJnEUV2//CofGf8A0Bv/ACZh/wDi6P8AhUPjP/oDf+TMP/xdH1Wv/I/uYf2xl/8A0EQ/8Cj/AJnEUV2//CofGf8A0Bv/ACZh/wDi6P8AhUPjP/oDf+TMP/xdH1Wv/I/uYf2xl/8A0EQ/8Cj/AJnEUV2//CofGf8A0Bv/ACZh/wDi6P8AhUPjP/oDf+TMP/xdH1Wv/I/uYf2xl/8A0EQ/8Cj/AJnEUV2//CofGf8A0Bv/ACZh/wDi6P8AhUPjP/oDf+TMP/xdH1Wv/I/uYf2xl/8A0EQ/8Cj/AJnEUV2//CofGf8A0Bv/ACZh/wDi6P8AhUPjP/oDf+TMP/xdH1Wv/I/uYf2xl/8A0EQ/8Cj/AJnEUV2//CofGf8A0Bv/ACZh/wDi6P8AhUPjP/oDf+TMP/xdH1Wv/I/uYf2xl/8A0EQ/8Cj/AJnEUV2//CofGf8A0Bv/ACZh/wDi6P8AhUPjP/oDf+TMP/xdH1Wv/I/uYf2xl/8A0EQ/8Cj/AJnEUV2//CofGf8A0Bv/ACZh/wDi6P8AhUPjP/oDf+TMP/xdH1Wv/I/uYf2xl/8A0EQ/8Cj/AJnEUV2//CofGf8A0Bv/ACZh/wDi6P8AhUPjP/oDf+TMP/xdH1Wv/I/uYf2xl/8A0EQ/8Cj/AJnEUV2//CofGf8A0Bv/ACZh/wDi6P8AhUPjP/oDf+TMP/xdH1Wv/I/uYf2xl/8A0EQ/8Cj/AJnEUV2//CofGf8A0Bv/ACZh/wDi6P8AhUPjP/oDf+TMP/xdH1Wv/I/uYf2xl/8A0EQ/8Cj/AJnEUV2//CofGf8A0Bv/ACZh/wDi6P8AhUPjP/oDf+TMP/xdH1Wv/I/uYf2xl/8A0EQ/8Cj/AJnEUV2//CofGf8A0Bv/ACZh/wDi6P8AhUPjP/oDf+TMP/xdH1Wv/I/uYf2xl/8A0EQ/8Cj/AJnEUV2//CofGf8A0Bv/ACZh/wDi6P8AhUPjP/oDf+TMP/xdH1Wv/I/uYf2xl/8A0EQ/8Cj/AJnEVseFNEbxH4j03SwHK3MwWTYwVhGOXIJ4yFDH8OhrePwq1+1+fVm07R7Y8LcahexpGzdkBUsc4yenQGq2o+INH8P6Pf6J4dL3s98qpc606tCzx5yYo4+qrwoYk/N8wII2kCoum+asrLs935W/XYipmEMRF08FLnk9LrWMfNvbTe17vZdWsfxzrq+JPF2r6nGyNDNMViZFKho1ARDg8glVBPuTwOlFc9RXLObnJye7PRoUY0KUaUNopJei0JJJHDsAzdT3pvmP/fb86KKk1DzH/vt+dOEj7GO5uo7/AFoooAb5j/32/OjzH/vt+dFFAB5j/wB9vzp0kjh2AZup70UUAN8x/wC+350eY/8Afb86KKAHCR9jHc3Ud/rTfMf++350UUAHmP8A32/OjzH/AL7fnRRQA6SRw7AM3U96b5j/AN9vzoooAPMf++3504SPsY7m6jv9aKKAG+Y/99vzo8x/77fnRRQAeY/99vzp0kjh2AZup70UUAN8x/77fnR5j/32/OiigBwkfYx3N1Hf603zH/vt+dFFAB5j/wB9vzo8x/77fnRRQA6SRw7AM3U96b5j/wB9vzoooAPMf++3504SPsY7m6jv9aKKAG+Y/wDfb86PMf8Avt+dFFAB5j/32/OnSSOHYBm6nvRRQA3zH/vt+dHmP/fb86KKAHCR9jHc3Ud/rTfMf++350UUAHmP/fb86PMf++350UUAOkkcOwDN1Pem+Y/99vzoooAPMf8Avt+dOEj7GO5uo7/WiigBvmP/AH2/OjzH/vt+dFFAB5j/AN9vzp0kjh2AZup70UUAN8x/77fnR5j/AN9vzoooAcJH2MdzdR3+tN8x/wC+350UUAHmP/fb86KKKAP/2Q==",
	"nangis": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4lkkcOwDN1Pem+Y/99vzok/1j/U16DLLF8Oobe1tbdB4vC77q8f8AeLaK2CI4wRtLbcZbBxuYAnPHpUKHtLyk7RW7/Rd2+iutnqctSpyWjFXb/q78jJsPhz4u1GFpYdHulVW2kTssLZwP4XIOOeuMVbHwq8Z7T/xKmzkf8vUX/wAXXOX2o3mpyrNfXc91Kq7Q88hdgOuMk9OT+dVq3vg19iT/AO3kvw5H+ZnbEP7Ufuf/AMkjq/8AhVPjP/oFN/4FRf8AxdH/AAqnxn/0Cm/8Cov/AIuuUoo5sH/JL/wNf/IBy4j+aP8A4C//AJI6v/hVPjP/AKBTf+BUX/xdK/wq8ZlmxpTYzx/pUX/xdcnRRzYP+SX/AIGv/kA5cR/NH/wF/wDyR1f/AAqnxn/0Cm/8Cov/AIuj/hVPjP8A6BTf+BUX/wAXXKUUc2D/AJJf+Br/AOQDlxH80f8AwF//ACR1g+FXjPaf+JU2cj/l6i/+LpP+FU+M/wDoFN/4FRf/ABdcpRRzYP8Akl/4Gv8A5AOXEfzR/wDAX/8AJHV/8Kp8Z/8AQKb/AMCov/i6P+FU+M/+gU3/AIFRf/F1ylFHNg/5Jf8Aga/+QDlxH80f/AX/APJHWP8ACrxmWbGlNjPH+lRf/F0n/CqfGf8A0Cm/8Cov/i65Sijmwf8AJL/wNf8AyAcuI/mj/wCAv/5I6v8A4VT4z/6BTf8AgVF/8XSj4VeM9p/4lTZyP+XqL/4uuToo5sH/ACS/8DX/AMgHLiP5o/8AgL/+SOr/AOFU+M/+gU3/AIFRf/F0f8Kp8Z/9Apv/AAKi/wDi65Sijmwf8kv/AANf/IBy4j+aP/gL/wDkjq/+FU+M/wDoFN/4FRf/ABdK/wAKvGZZsaU2M8f6VF/8XXJ0Uc2D/kl/4Gv/AJAOXEfzR/8AAX/8kdX/AMKp8Z/9Apv/AAKi/wDi6P8AhVPjP/oFN/4FRf8AxdcpRRzYP+SX/ga/+QDlxH80f/AX/wDJHWD4VeM9p/4lTZyP+XqL/wCLpP8AhVPjP/oFN/4FRf8AxdcpRRzYP+SX/ga/+QDlxH80f/AX/wDJHV/8Kp8Z/wDQKb/wKi/+Lo/4VT4z/wCgU3/gVF/8XXKUUc2D/kl/4Gv/AJAOXEfzR/8AAX/8kdY/wq8ZlmxpTYzx/pUX/wAXSf8ACqfGf/QKb/wKi/8Ai65Sijmwf8kv/A1/8gHLiP5o/wDgL/8Akjq/+FU+M/8AoFN/4FRf/F0o+FXjPaf+JU2cj/l6i/8Ai65Oijmwf8kv/A1/8gHLiP5o/wDgL/8Akjq/+FU+M/8AoFN/4FRf/F0f8Kp8Z/8AQKb/AMCov/i65Sijmwf8kv8AwNf/ACAcuI/mj/4C/wD5I6v/AIVT4z/6BTf+BUX/AMXSv8KvGZZsaU2M8f6VF/8AF1ydFHNg/wCSX/ga/wDkA5cR/NH/AMBf/wAkdX/wqnxn/wBApv8AwKi/+Lo/4VT4z/6BTf8AgVF/8XXKUUc2D/kl/wCBr/5AOXEfzR/8Bf8A8kdYPhV4z2n/AIlTZyP+XqL/AOLpP+FU+M/+gU3/AIFRf/F1ylFHNg/5Jf8Aga/+QDlxH80f/AX/APJHV/8ACqfGf/QKb/wKi/8Ai6P+FU+M/wDoFN/4FRf/ABdcpRRzYP8Akl/4Gv8A5AOXEfzR/wDAX/8AJHWP8KvGZZsaU2M8f6VF/wDF0n/CqfGf/QKb/wACov8A4uuUoo5sH/JL/wADX/yAcuI/mj/4C/8A5I6v/hVPjP8A6BTf+BUX/wAXSj4VeM9p/wCJU2cj/l6i/wDi65Oijmwf8kv/AANf/IBy4j+aP/gL/wDkjq/+FU+M/wDoFN/4FRf/ABdH/CqfGf8A0Cm/8Cov/i65Sijmwf8AJL/wNf8AyAcuI/mj/wCAv/5I6v8A4VT4z/6BTf8AgVF/8XSv8KvGZZsaU2M8f6VF/wDF1ydFHNg/5Jf+Br/5AOXEfzR/8Bf/AMkdX/wqnxn/ANApv/AqL/4uj/hVPjP/AKBTf+BUX/xdcpRRzYP+SX/ga/8AkA5cR/NH/wABf/yR0V98OfFunW4lm0e5YM4UCBlmboeyEkDjr0rk/Mf++351p2Oo3mmStNY3c9rKy7S8EhRiOuMg9OB+VddFLF8RYbi1urdD4vK77W8T92t2q5JjkAG0NtzhsDO1QSMctUKNf3aF1LonrfyTSWvZW17906lSlrUs13Wlvk29O+vyPPvMf++350U2ivPOo634c2Eeo+PtHhlZ1VZzMChAO6NS4/DKjPtWPqN9JqeoXd9MqrLdSvM4QYUFiScZ7c10fwqC/wDCw9K5Oczdv+mT1ydd70wcPOUvwULfmzmWuIl/hX5y/wAj2/4Ta/4b07w68Mlza2WpCQm5a5kWMzcnYQWPIC8YHQ545ye+/wCEu8P/APQd0v8A8C4/8a+UqK9jC8R1cPRjRVNe6rdjz6+TwrVHUcnqfVv/AAl3h/8A6Dul/wDgXH/jR/wl3h//AKDul/8AgXH/AI18pUV0f611v+fa+9mX9hU/52fVv/CXeH/+g7pf/gXH/jR/wl3h/wD6Dul/+Bcf+NfKVFH+tdb/AJ9r72H9hU/52fVv/CXeH/8AoO6X/wCBcf8AjR/wl3h//oO6X/4Fx/418pUUf611v+fa+9h/YVP+dn1b/wAJd4f/AOg7pf8A4Fx/40f8Jd4f/wCg7pf/AIFx/wCNfKVFH+tdb/n2vvYf2FT/AJ2fVv8Awl3h/wD6Dul/+Bcf+NH/AAl3h/8A6Dul/wDgXH/jXylRR/rXW/59r72H9hU/52fVv/CXeH/+g7pf/gXH/jR/wl3h/wD6Dul/+Bcf+NfKVFH+tdb/AJ9r72H9hU/52fVv/CXeH/8AoO6X/wCBcf8AjR/wl3h//oO6X/4Fx/418pUUf611v+fa+9h/YVP+dn1b/wAJd4f/AOg7pf8A4Fx/40f8Jd4f/wCg7pf/AIFx/wCNfKVFH+tdb/n2vvYf2FT/AJ2fVv8Awl3h/wD6Dul/+Bcf+NH/AAl3h/8A6Dul/wDgXH/jXylRR/rXW/59r72H9hU/52fVv/CXeH/+g7pf/gXH/jR/wl3h/wD6Dul/+Bcf+NfKVFH+tdb/AJ9r72H9hU/52fVv/CXeH/8AoO6X/wCBcf8AjR/wl3h//oO6X/4Fx/418pUUf611v+fa+9h/YVP+dn1b/wAJd4f/AOg7pf8A4Fx/40f8Jd4f/wCg7pf/AIFx/wCNfKVFH+tdb/n2vvYf2FT/AJ2fVv8Awl3h/wD6Dul/+Bcf+NH/AAl3h/8A6Dul/wDgXH/jXylRR/rXW/59r72H9hU/52fVv/CXeH/+g7pf/gXH/jR/wl3h/wD6Dul/+Bcf+NfKVFH+tdb/AJ9r72H9hU/52fVv/CXeH/8AoO6X/wCBcf8AjR/wl3h//oO6X/4Fx/418pUUf611v+fa+9h/YVP+dn1b/wAJd4f/AOg7pf8A4Fx/40f8Jd4f/wCg7pf/AIFx/wCNfKVFH+tdb/n2vvYf2FT/AJ2fVv8Awl3h/wD6Dul/+Bcf+NH/AAl3h/8A6Dul/wDgXH/jXylRR/rXW/59r72H9hU/52fVv/CXeH/+g7pf/gXH/jR/wl3h/wD6Dul/+Bcf+NfKVFH+tdb/AJ9r72H9hU/52fVv/CXeH/8AoO6X/wCBcf8AjR/wl3h//oO6X/4Fx/418pUUf611v+fa+9h/YVP+dn1b/wAJd4f/AOg7pf8A4Fx/40f8Jd4f/wCg7pf/AIFx/wCNfKVFH+tdb/n2vvYf2FT/AJ2fVv8Awl3h/wD6Dul/+Bcf+NH/AAl3h/8A6Dul/wDgXH/jXylRR/rXW/59r72H9hU/52fVv/CXeH/+g7pf/gXH/jR/wl3h/wD6Dul/+Bcf+NfKVFH+tdb/AJ9r72H9hU/52fVv/CXeH/8AoO6X/wCBcf8AjR/wl3h//oO6X/4Fx/418pUUf611v+fa+9h/YVP+dn1b/wAJd4f/AOg7pf8A4Fx/40f8Jd4f/wCg7pf/AIFx/wCNfKVFH+tdb/n2vvYf2FT/AJ2fQvxC8S+F7zwrewzXtnfSupFvHbyrI6zYO1/lPygdz6ZHOcHwPTr6TTNQtL6FVaW1lSZA4ypKkEZx24qtRXjZhmU8bVVVxUWux6OEwccNTdNO6Zv/ABKsI9O8da1DEzsrTCYlyCd0ihz+GWOPairfxZC/8LA1fJOf3Pb/AKYpRXJmEVHF1UtlKX5s1wjboQb7L8hfhT/yUXSvrN/6KeuUrq/hT/yUXSvrN/6KeuUrSX+5w/xT/KAo/wC8S/wx/OQUUUVyHQFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFbGl6XA9t9vv/NNmXaKOOFgryuAC3zEEKFDKSSDnIAHUrcIObsiZSUUY9FdV9q03/oXtO/7+3P8A8do+1ab/ANC9p3/f25/+O1r7CP8AOvx/yM/aP+V/h/mcrRXVfatN/wChe07/AL+3P/x2j7Vpv/Qvad/39uf/AI7R7CP86/H/ACD2j/lf4f5nK0V1X2rTf+he07/v7c//AB2j7Vpv/Qvad/39uf8A47R7CP8AOvx/yD2j/lf4f5nK0V1X2rTf+he07/v7c/8Ax2j7Vpv/AEL2nf8Af25/+O0ewj/Ovx/yD2j/AJX+H+ZytFdV9q03/oXtO/7+3P8A8do+1ab/ANC9p3/f25/+O0ewj/Ovx/yD2j/lf4f5nK0V1X2rTf8AoXtO/wC/tz/8do+1ab/0L2nf9/bn/wCO0ewj/Ovx/wAg9o/5X+H+ZytFdV9q03/oXtO/7+3P/wAdo+1ab/0L2nf9/bn/AOO0ewj/ADr8f8g9o/5X+H+ZytFdQdOstbdLezs1stRkISFYpGaGVuyEOWZWJOA27b0BAyWHL1nOm4a3ui4z5vIKK2dK0qB7X+0NQ802RkaGOKBwskzgAt8xBChQykkg5yAB1K6f2zTP+hc03/v7c/8Ax6sJVFF2OeeLUZWjFy9Lfq1/XmcnRXWfbNM/6FzTf+/tz/8AHqPtmmf9C5pv/f25/wDj1T7aJH1z/p3L/wAl/wDkjk6K6z7Zpn/Quab/AN/bn/49R9s0z/oXNN/7+3P/AMeo9tEPrn/TuX/kv/yRydFdZ9s0z/oXNN/7+3P/AMeo+2aZ/wBC5pv/AH9uf/j1Htoh9c/6dy/8l/8Akjk6K6z7Zpn/AELmm/8Af25/+PUfbNM/6FzTf+/tz/8AHqPbRD65/wBO5f8Akv8A8kcnRXWfbNM/6FzTf+/tz/8AHqpajpdrdWs99p0bw/ZwHubZ33BVLBQ6MRnbuYLtOWGQctlirjVi3YqGLTaUotX72/RswKKKK0Ow6j4tf8lB1j/tj/6JSij4tf8AJQdY/wC2P/olKK6My/3yt/il+bMMH/u9P/CvyH/Cn/koulfWb/0U9cpXWfCp2PxD0objjM3Gf+mT1ydXL/c4f4p/lAUf94l/hj+cgooorkOgKKKKACinwwyXEscMMbSSyMFREGWYngAAdTXpEPw70zwxaw6h4x1DZv5j0+1+Z5CAG2lvzU4wBkfOM11YfCVcRdw2W7eiXqzCtiIUrKW72S3ZwGl6Tfa1dra6fay3M7Y+WNc4GQMk9AMkcngZruLT4QaokCXWs39hpVoM+a0sm5oucDPReTj+Lv68U+8+Jc9lEtj4XsYNIsEbIKxq8suOMtkEZIC56nI+8a5G6nv9UlWa+up7iQKFDzyF2C9cZP1PHvXUlgaOjvUl/wCAx/zf4GP+01O0F97/AMl+J2Y8K/D6w/0e+8UXU90n35LVP3ZzyMYRx0I/iPOenSnf2p8M/wDoXdT/AO/jf/Hq4cWa45Yk+1PFtHj7v60/r6jpCjBL0v8Am2L6rf4qkn87flY7X+1Phn/0Lup/9/G/+PUh0H4c6jzb65f2U9z/AKuOVSUgZugYlOik4Pz9vvd64v7NF/d/U0w2i44Zgfej6/f46MH/ANu2/KwfVLfDUkvnf87nZTfCG6uopJ9C1nTtVt41OSj7WLjnYMblzjHVh15x1rita8Pap4euBBqdlLbO33Swyr8Anaw4bGRnB4zUlv8Aa7CdLi0nkinTO2SJyjrkYOCOnBIrq9N+J2qwRGz1mCDWNPKqrQXaDdhenzY5OcElgx47Hmh/Uays06b/APAo/wCf5hbE09U1Nfc/8vyPPaK9PHgjw740WSXwnfNZ3iLufT73OAMhchuSBwScF+WA+WvOdQ0+60q9msr2FoLqBtrxt1B/qO4I4I5rlxGCq0Epuzi9mtU/67OzNqOIhVbitGt09GVqKKK5DoCiiigArqrr/kD+Hv8Arzf/ANKZq5WuquCH0XQXU7lW2kiYjkBxPKxU++11OPRge4roofDP0/VGVTePr+jItPtft1/a2u/Z58qx7sZ27iBnH41083giN9Sv9LsdSafUrNS5hlg8sSgAE7WDNzz3xXNaXdJZanZXMgYxwTJIwXqQGBOPyrsH8YaXZ69qOu2Ud5LfXKlYo5o1RIiQBkkMS3T2ruwccM4fvrb66u/LZ3t53t3OXESrKX7vt+N+phw+HIodGt9U1K8a1gunKQJHD5jvjqxG4AD8c+1aVv4Blk1prCa9VYGtDeRXMce8SJxjgkYPPrVT+3rHUtAsdL1MXMb2LsYp7dFfcrHJUqSPzz+FbFr48s110XMtvcR6fDYGxgRAHcDjDHJA7fyropQwTcee1vd6u/8Aev2V9tum+plUlibPl317fKxz8/htZNGbVtOujdWsUgilR4vLkjJxjIyQQcjoe9X28FxQalbaTc6osWrTqCIhDujRiOFZ85yfZSKgbxBaad4fm0nS1uHa5lWWa5uFVD8pBCqoJxyBzmtCbxVpN9r1rr9zBeLfQhWe3jCmOSRRwd5OQOBxg9KmMMHpe1/dvq7bvms/S3V9bXG5YjW17a20V+lr/j+BQtfBs5sr+7vHmjSzuDaulvB5z7x1OMgBRkc5pumeGbTUo9YnXUpBaabGshdbbLSAg5G0sMEYx1qfT/FZivby/bUNQsru5naV0to0kiZT0BVmHI5GeeMVqJ48sn1DxDc+Xd2f9pRxxxSWyqzxlQRuPzLzz2NVTp4F8rfnv10dno9NbaWXruTOWJV7eXy1V+nr39DIn8EXJ1PSrOzuFnGpwieJ3Xyyi4ydy5OMD3NMHhWC8i1L+zNRN1Ppyl5Y3g8veo6sh3HOPcCtKbx3FDq2i3ttDNcSWERimnucLJcgjHOCcY5xyetVLbxDpejJq0mmR3b3OoRtCvnqqrAjHnkE7j+A6UShguZ22u76vRcqtbv71+/3ajUsTZX3+XfW/wArdvvIofDWmT6Fc6wuqXgtreUQspsl3knHQebjHPrXOLAZ7oQ2+6QyPsjyuGbJwOMnB/Gtu1123g8IX2jskpubi4WZWAGwAY6nOc8elQeFtSstI1q3vr6OWWO3y6JGASXx8uckcA8/hXJUjQnKlGNoppcz10d3fdvobwdWKm5a2227Gh4s8Fv4YgtplvFu45HMUjKm3y3AB29Tnv8AlVDxR4f/AOEb1JbP7R9o3RLLv2bOueMZPpWrL4xt9S0bVrG/sljkupPtMT225sTZ5Lb3OAeBx78VR8Za7beIdWS7tUlSNYUjxKADkZ9Ca2xUcJySnR62srvTe+/yfzM6EsRzRjU87vTXa36nPUzxd/yNeu/9f0//AKMapoonnlSKJGeV2CqijJYnoAO5qt4omjuPE2tTQyLJFJeTMjocqwLkggjqK89/wX6r8mdf/Lxej/Q1rz/kDeHP+vJ//SmeqUMMlzNHDCjSSyMERFGSxJwAKuXJD6H4fdTuRLWSJmHIDi4lYqffa6HHowPcU/w/qn9h67pupGPzBZ3CTFP7wVgcV5U/iZ5qbUZuKu7y/NnfXHwG8UQaSbwNZyXCrvNmkhMn0BxtJ9s/jXnOnafcapqFtYWybrm5kWKNTxlicD6V9UXHxk8Iw6Ub5NSEr7MraqjCUt/dxjj69PevmKx16fT/ABHDrcSJ58Vz9pCfw53btv07VCPIyrF46vGp9YhZra6trrodWnw1gutbu/D9nriz6/bIzGA2xWGR1GWRZN2SRz1UDioU+GlzN4C/4SiC73yoXMliYsMqI5VmDZ5xwSMDAPtWnb+PPD+m+K73xZZ2uoNqk6u0dnKqCGKVxhmMgbLDk8bR161Dp3xLj0zQ/DltHDPJd6fdTy3iuq+VPFKW3IOechu460alOePtHk/u3ul2fMvS9lfz3Yq/Cjd4mbRf7X+7pn9o+d9m+nybd/v1z+Fc54J8Jf8ACY6ndWX2z7L5FrJc7/L37tuPlxkdc9a7p/ijoR8dT6ylrqCac+lHT1Ty0MitnrjfjGPfNc74N8SaB4N1i4vI59TvIriymt2DWccTKzFdpH71sjg56Y469gcKuN9lLmT5uVW0W+t+lu2/yIovhvcXXgBfFVteiVwXZ7LysMsaOVZw27nHBPHQ1oxfChX8UnRG1gqo00aiZxa5OOPk27/frn8Ki0n4jwaN4e8M2NvBO9xplzM90jqvlTwyE7kHOTkHuOtbv/C1NDXx5LrkVvqMVgdL+woqxp5qNkYON+MAD1zRqRUqZgnNRWnvW0Xf3V92q7312PLNSi0yIx/2dd3dwDnebm1WHb6Y2yPnv6VLoX/H1df9eF5/6TSVZ8SamupvbuNb1bVWQEFtSj2mMcYC/vXznnPTp3qtohCTXsrHbGlhd7nPAXdA6Lk9ssyqPUsB1NVHdHpybeHd97P+tl+RyFFFFdp7h1Hxa/5KDrH/AGx/9EpRTviy7D4gauAxA/c9/wDpilFdOZf75W/xS/NmGD/3en6L8hfhT/yUXSvrN/6KeuUrq/hT/wAlF0r6zf8Aop65Sql/ucP8U/ygKP8AvEv8MfzkFFFFch0BWnoOg33iTUotP0+LfM/JY8LGvdmPYD/ADJIFVdP0+61W9hsrKFp7qdtqRr1J/oO5J4A5r0/XNRj+HGjx+HdH2rrFzEsmoXyPuZWI+6p4IPXGQMKQRy2R3YTCxqJ1qztTjv3b7Lzf4LU5a9Zxap09ZP8ADzfl+Ylzqmi/DSK907Qi174hdRHNfyqpSE/xKo9QRnbyMkbiduK4G6nu9YvJr29meWeZtzyN1b/AY4HYdBUMFuCA7dOwqy8ixjLH8PWnicXKulG3LBbRWy/zfnuOjQjT13k931/4byBI1jGFH/16HkSP7zAVSkunfgfKPbrUFcLqpbHWqXcvG8jBx8x9wKZ9t/6Z/rVSiodWRXs4lv7b/wBM/wBaeLxDjIYVRoo9pIPZxNNJUf7rAn0pzKHGGAIrKqWO4ePjOV9DVqr3JdLsWPLltZUmt5HWSNgyshwykdCCO+a72x8W6X40sodI8Y7luBLm31OEKhjz1DcYUcAZwQRgkDburh4pllGQee4qOe3DZdeD3HrXbhsVOhfk1i909n6r9d0ctahGrbm0a2fVFnxb4SvvCGpG1uhvhfLQXCjCyr/QjjI7e4IJwK9Q8Ga/b+IbRPCHiFfOs5vls7gsA9u4B2qCfyX67cEHA4LXtBvvDepS6fqEWyZOQw5WRezKe4P+IOCCKrF4aCgsRh/gfTrF9n+j6oihWlzOjV+Jfiu/+ZmUUUV551hWnpmrLZxtbXULXNizb/KV9jI+PvIxB2k4APBBAGRkKRmUVUZuDuiZRUlZnT/aPD//AD/6p/4AR/8Ax6j7R4f/AOf/AFT/AMAI/wD49XMUVt7aP8i/H/Mj2b/mf4f5HT/aPD//AD/6p/4AR/8Ax6j7R4f/AOf/AFT/AMAI/wD49XMUUe2j/Ivx/wAw9m/5n+H+R0/2jw//AM/+qf8AgBH/APHqPtHh/wD5/wDVP/ACP/49XMUUe2j/ACL8f8w9m/5n+H+R0/2jw/8A8/8Aqn/gBH/8eo+0eH/+f/VP/ACP/wCPVzFFHto/yL8f8w9m/wCZ/h/kdP8AaPD/APz/AOqf+AEf/wAeo+0eH/8An/1T/wAAI/8A49XMUUe2j/Ivx/zD2b/mf4f5HT/aPD//AD/6p/4AR/8Ax6j7R4f/AOf/AFT/AMAI/wD49XMUUe2j/Ivx/wAw9m/5n+H+R0/2jw//AM/+qf8AgBH/APHqPtHh/wD5/wDVP/ACP/49XMUUe2j/ACL8f8w9m/5n+H+R0U2s2NgpOlfapLs/du7hVjMX+4gLfN6Pu4ycKCA1c7RRWc6jn5IqMFE1NL1dbONra7ha5sGbf5SybHR8feRiDtJwAeCCAMjIUrqef4d/6CGq/wDgvj/+P1y9FYSpxlqzGphYylzJtelv1TOo8/w7/wBBDVf/AAXx/wDx+jz/AA7/ANBDVf8AwXx//H65eil7KJH1P++/w/yOo8/w7/0ENV/8F8f/AMfo8/w7/wBBDVf/AAXx/wDx+uXoo9lEPqf99/h/kdR5/h3/AKCGq/8Agvj/APj9Hn+Hf+ghqv8A4L4//j9cvRR7KIfU/wC+/wAP8jqPP8O/9BDVf/BfH/8AH6PP8O/9BDVf/BfH/wDH65eij2UQ+p/33+H+R1Hn+Hf+ghqv/gvj/wDj9UNS1iFoHs9NjlitXx50krAyXGDxnHCrkBtgJ56s2FxjUU1TincqGFjFqUm3bvb9EvxCiiirOo6j4tf8lB1j/tj/AOiUoo+LX/JQdY/7Y/8AolKK6My/3yt/il+bMMH/ALvT/wAK/Ik+FQX/AIWHpXJzmbt/0yeuTrq/hT/yUXSvrN/6KeuUq5f7nD/FP8oCj/vEv8MfzkFFFbnhHw9J4o1+005Qwidt07r/AARjljnBwewzxkj1rClTlVmqcFdvQ1nNQi5y2R23haC08C+FP+EnvIYn1y9yunwzEjCcDcFxkcEsT3XaARu54FBJdTPcTs0juxZnc5LsTyST1rpPH2upr3iA29mVXTLAfZrZI8BAq9WUAkYJHBGMqF9KxFUIoUdBXfjakXJUKXwQ09X1fz/KxzYaDSdWfxS19F0Xy/MSRxGhY/8A66zXdpGLMeanvHy4QHgdfrVavKqSu7HoU42VwooorM0CiiigAooooAKKKKAFVipBBwRWjDKJUzxu7is2prV9koGeG4rSnKzsZzjdE1zD/Go+tehEQfEjwdJvRT4q0eL5CrMZLmJcdRglieRjn58HIDYPDkZGD0q14Y1yTwr4htb5S5hVtsyL/HEeGGMjJ7jPGQDXp4OtGlNwqfBPSX+fqtzgxNJzjzQ+KOq/y+Zy9Fdf8RvDseheIGltAp0vUF+02rx/cw3JVSAFwD0AzhSvrXIVyYijKhVlSnujelUVWCnHZhRRXu37PH7OH/C+7fxDL/wk39i/2O8C4+w/afN8wOf+eibcbPfOaxbSV2aHhNFe1eAP2dtQ8W/GXWPhpquq/wBjX2lpM73ItfPDhCu0hN6/KysGBz0Iry/xhoH/AAini3XtA+0faf7Jv57Lz9mzzfKkZN23JxnbnGTjPU0rp6AYtFFFMAooooAKK3PBuh2fiXxVpGkahq8Gj2N9cJDNqNxjy7ZSeXbcyjA92H1rS+JvhHS/A3jK+0PRvE1n4m0+3WNo9UsgoimLIrEDa7j5SSp+Y8jt0ov0A5GiiigAor3jx/8AszX/AIR8GeAdc0vV5tc1Hxj5CwaZDYeW8bSQiQKG8xt+M4zhfXiqvxf+ANh8GPDmlPrnjOGfxlfxrJ/YFpZbxCpPzM8/m8KOQDs+YggDAJC5kwseI0UV6N8HvhzoHxJ1nULHxB460zwfb21v50d1qAjKTNuA2DfLGM4JPU9OlNuwHnNFSTxrFNJGrh1RiocdGAPWo6ACiiigAooooAKKKKACiiigAooooAKKKKACiiigDqviyF/4WBq+Sc/ue3/TFKKb8Wv+Sg6x/wBsf/RKUV05l/vlb/FL82YYP/d6fovyH/Cn/koulfWb/wBFPXKV1fwp/wCSi6V9Zv8A0U9cpVS/3OH+Kf5QFH/eJf4Y/nIK9S+Hbr4f8FeJvEat/pQ/0WFljUtE2Bg5PYtIhI/2O/SvLa9P8WD+yfht4R0v/W/ac3vm/d25Bbbjv/rsZz/D0546csfs3UxH8kXb1fur8zLG++oUf5n+C1f5HB2iZLOR04FW6jgXbEvTnmpK4VsdTIJII3kyzEM3ak+xx+rfnUd63zIvcDNdV8LdU8O2Hj7w9ceMVlfw5BdpJdeXEsvA5XehB3x7gu8AElNwAJxWMpRTd0axjJpWZ9C/BH9kHS/HHguDxJ4t1HVrP+0v3lla2W2J1hBIDyGSNs7+GXaMbcHJ3YX0r/hhj4d/9BnxT/4FW/8A8Yr6O0fVrPX9IsNW06bztP1CCO5t5dpXfG6hlbDAEZBBwQDV2vEniKjk3ex60aEEkrXPmT/hhj4d/wDQZ8U/+BVv/wDGKP8Ahhj4d/8AQZ8U/wDgVb//ABivpuip9vU7lexh2PmT/hhj4d/9BnxT/wCBVv8A/GKP+GGPh3/0GfFP/gVb/wDxivpuij29TuHsYdjxr4e/sufDrwD/AGjnTf7f+2+X/wAjBBb3fkbN3+r/AHQ27t3PrtX0rsLv4VfDWytJ7mXwB4aaOCNpGEOhQyuQBk7UWMsx44Cgk9ACa7ZcBhnpUm5Pb8q6aVaTjrJfM5a1KKlon8j8yv2j9U8AeJPHGn3fw9hsYdFTTY4pVsLA2cZnEspYlCi5O0p82OmBnivH1to1kXDNuHOK+of2nfiN8I/GHhG3PgQ6XJ4ml1Zbm7uLfSHtp5IjHLvZpWiXdl2QkEkk89s18sWjfvucksDXpxcdFY4WpWbuXqr3aZQNjkfyqxTXXejLxyO9bsyR2+pOviP4Q291K3+laHOsO9o1yy5ChFI6Da8eT3Kc+teWV6h8KR/aI8R6F/q/7RsT+/6+XjKfd7/63PUdPfjy+u7Hv2tKjiOrVn6xdvyscuFXJOpS7O69Hr+dwr7Q/YkuprL4ffGK5t5GiuILSGSORTgowhuSCPcEV8X16Z8Mfjj4h+E+h+J9I0Wz0u4tvEcSw3TXsUjugCuvyFXUA4kbqD0FeTJXVjtR92/B1bH4teIPCHxmsBDHqjaVPouvQJgYuF2FWx+B99rx+leAfC7wr471f47/ABg1fwb4qtPC1rpupXqalqdxax3OInuZHCrG6kH/AFRYnIwF684Pjnwb/aE8W/BBNVi8PxaddWupFGlt9RjkkjV1yA6hHUgkHB55AHoKTwV+0N4x8BeM/EvibSf7PMviSeS41CwngZ7WVndnxt3bgFLsB82cEgk1PI1ew7n15qq6N8Wf2d/iHean4ys/H91otvcT2+sDQP7NktJoofMCLx83QZK4yGwc1y2r+MbrwL+xb8PdY0+2s5dUju0S0murdJ1tZC9wfNVHBUsFDAZBxuz1Arwpv2rfGP8Awi3iXwzDo/he00TXoJbZrWz09reO0SRCj+SqOFBO4nLBiT1JAArldd+N3iDxB8KNF+G1zZ6WmhaRMs8E8UUguWYeZwzFypH71uijoKSgwufUfxv0HTfif4T/AGffEOuW9vFqviW9sLPUbuBBGZI7hEMmSOwOSP7uTjqa1fir8QdQ8H/tA/Dv4ZaToelx+CxLp5GnfYYyGZ58CVGxuQx7QQVI5Q5zXyX4w+OviTxp4E8KeDry20220/wx5X2O4tEkS4Jjj2KXYuRnHPAHNfV/h/4g3GrX3hrV/EfxX+FlxpmktHI2rCDy9ekiUhmh2P8A6vfgqxQA4Joaa3Hcw/jH/wAnw+Avrp//AKG9O8VeKfBng/8Abb1zUvHCQf2YLCCO3nuITLHbXBt4dkjKAewdc44LA8YyPF/jN8dYNe/aCh8f+FIo57bRXgWxa8jYJceVzuZAVYKWJwMg4x0PFczqP7QHijU/iZqPj6Wy0T+1NStltLqzay820liVUXaY5GY8+WpJznPTHSmov8BXPpT4v6P4x8cfDHxbq+lfETwh4+8N2cZmmRNMgiutPjUh/wB08ecMqj+Iglc9zivhavaPEX7TPirWvCOo+FtN0Xwt4a0jUwVvU8P6YLU3IPBDHceo4OACRx0rxeqgmlqJn63eD/EXh/QvAPwng1e4trTU9T0m2tdLuLiMELObVPlDHozDgcjd93OSAfgrx98KvFNn+0NpOh/EW9mvP+Ej1e3Q6x0S8gklVCyHopCnbs/g4HTBPL+P/jz4k+I3gzwx4U1Oz0u30/w2sa2stnHIkzbIhGC5aRgTgZ4A5rV8SftMeLvGXgGz8I+IrDRdVSyCm21a5hl/tCF1+7IsqygbwOM7eR97PNTGLQ2z7K8feNPB/wAIvGmj+HpPHeleFPDNpbRPP4VXwlJdJewkkFjcKDgkAgEdCMsG5Fct+zrceBb79o/x5ffDuaOTw3eaNHMqRW8kEcUplTzFVHVSFyM4xgbsDgV84N+1j4w1DT7K28Q6B4O8TXVkmyC/1vSBcXCD2bcBn3xz3r139nb4jaToN/4s+Lnjzxj4ahu9UshaR6LZOiXgERUKBbKBtBWNQuM5zkkVLi0h3LP7K/hbw3pnwz+IXxBvZ7O01yxvbi2j1S5sDff2ZEkaP5qwjknMhJx1Cjtms74rfEj4W+Ofg/qum654/s/Fvj22Jn0vVovDc+nTEgqREcJtwRuBJIBBHGVzXzx8Nvjd4t+FGpalc+HrmD7LqR/0vT7yLzrefrjcvByMkZBBwcdK0PGHx81nxZ4fvtCg8NeENA07UNoul0PSEt3mCuHALks33lB4IquV3uK+h9Lap40uvAP7F3w+1nTrWzl1RLpEtJruBZltZC9x+9VGBUsFDAZBxuz1Ar4s8WeK9X8ceIb3X9eu/tmrXxVp5/KSPeVUKPlQBRwoHAHSux1343eIPEHwo0X4bXNnpaaFpEyzwTxRSC5Zh5nDMXKkfvW6KOgrzWqjGwmwoooqgCiiigAooooAKKKKACiiigAooooA6j4tf8lB1j/tj/6JSij4tf8AJQdY/wC2P/olKK6My/3yt/il+bMMH/u9P/CvyJPhU7H4h6UNxxmbjP8A0yeuTrq/hT/yUXSvrN/6KeuUq5f7nD/FP8oCj/vEv8MfzkFeofGAfY9U0jS4fksLOxXyYuuzLFep5PCKOT2+teX16h8af+RptP8AryT/ANGSV0Yb/cq784fqZVv95pekv0OMUbVAHQDFVL1vmVfQZq5VC7bMxHoMV59X4Ttp/EQUUUVzHQfqjoXia0+F3wG8Oax4liurWHRtCsVuYPJPnrJ5UaCLYcYcuQuGwATyQASPItH1v9ov4tRDxFoFxo3g7w/cRh7G3vI0c3ETM5V8tFI5O3b8xEasNrKuCTX07qukafr1hNp+q2Frf2E2PMtruFZYnwQwyrAg4IB57gVj3OtW/h3UNL0G006KO0McUUKwkRpCmdiqqAYAAAwBj0rzcPTnWk40o3lq/kvU7MTWp0IqVWVo6Lru/Q8U8EfGDx34I8b6Z4F+L+nxeZq8hg0nXrOMFLuXzSoDhPlw25AMKjJlC64csPpCszU/Dmja1d2F3qWk2F7d6dJ5tpNc26SPbPkHdGzAlDlVORj7o9K0655yUtUrHRFNaNhXgPxb+M/iiPxc3w5+F+jf2n4xWBpr24mQCKxjMe5Spcqm/Do25zsBKrh2YhffqzIPDmjW2tXOtw6TYRa1dRiKfUEt0W4lQbcK0gG5h8i8E/wj0FEGou7Vwkm1ZM+b9Stf2n/BUI1ltY0HxXDbbjLpdtboWddjHdtEULtggYWNtxbaNrDIr2r4TfFDS/i54Pg8QaZFLbsJDb3VrLybedVUsm7ADjDKQw6hhkA5UbWqeJf7N1uy037L5n2nZ+88zG3cxXpjnp61c0Pw5o3hi0e00TSbDS7R5DK0NjbpAjOQAWKoACcKBn2HpW9elOEIyqRtzaq1tUc9CtTqTlCnK/K7PfRn49Xlncadd3FneW8tvd28jRTQTIUeN1OGVlPIIIIIPSoa7T4wf8la8e/9h6//APSh64uvSTurnG1Z2J7RsTAeoxV+s2BtsyH3xWlXTSehhVWp0XwruZbXxxaRRPtSdZYpBgHcoQtj25VTx6VyXiK0hsPEGrWtumyCC7lijXJO1VcgDJ56Cuo+Gf8AyP2m/Wb/ANFPXO+Lv+Rr13/r+n/9GNXoz1y+LfScvyicMdMXL/CvzZjUUVtweFr248LXHiKN4DZ29x9nkj3HzRwvz4xjbl0Gc5yw4rzTsMSiuj1XwRq+lz6TbeT9ru9TthdRW9orSSKCSCrLj7wKnIGcVkx6PqM2oHTo7C6fUASptVhYy5HUbMZz+FAFKitCDQdVuryezg0y9lvIATLAkDtJGB13KBkfjV698MS2/iuPw/DOkk8k0UCSyKUXc+3GQMkAFvegDBorp08JW763pulR+INPuZry8js3FrFOWh3MFLESRoCAT0B/xrHTRdQnkjW2srqcTStDEY4WbzXXqq4HJAIOB60BcoUVqReGdbnuprWLR9QkuoGCSQpbOXRiCQCuMgkAnn0NR2eg6rqE0sNppl7cTQuI5EhgZ2RuflIA4Pytx/sn0oAz6Kuto+orpy6i1hdDT2baLowt5RPpvxjP41Z/4RrVIp4YbuxurMzxPNGbi2kHmKiFiQApJGB1AwOpIGSADJoorc8L+Fb7xdd3Vpp7QCeC3a42ysV8zBUBFwDliWAAOBk9aAMOitKTRLqPT9OvBtddQlkhijTJfchUEEY77xityT4d6nF4vh8Mvc2C3cyF1uTKfs+0IWJ3bc4G1geOoP1osFzkaK3P+ES1TZN+5H2mK/XTTbc+aZ2DYAGMdVI69cU7VfDI0qKcnWdKuLm3OJbaCVy6HOCASoR8H+4zUBcwaK6dfA92kJubu/sLOyENvMbidn25nQvGmFQsWwrZwMDB5rnru3NpcywGSKXYcb4m3I3uD6UAQ0UUUhhRRRQAUUUUAFFFFABRRRQAUUUUAdV8WXYfEDVwGIH7nv8A9MUopvxa/wCSg6x/2x/9EpRXTmX++Vv8UvzZhg/93p+i/If8Kf8AkoulfWb/ANFPXKV1nwqC/wDCw9K5Oczdv+mT1ydVL/c4f4p/lAUf94l/hj+cgr1D4pH+0LPwtrUvF1qFiPMRfuDAV+B16yN1J6CvL69OnP8Abvwhs5/vT6LdGKSSblthOAqHk4xJGMcfc9hXRgffo16XeN//AAF3/K5lifdqUqnnb71/nY41CSik9SBWfO26ZyfXFW7VsxY7qaos25ix6k5rzar0R301qxKKK6f4b6tZ6B8RPCOrajN5On6fq1pc3Eu0tsjSZGZsKCTgAnABNc7dkbLc/XeuBtf9N+I80sHzxwbt56YxHsPX/aOK7izvLfUbS3vLO4iuLS4jWWGeFw6SIwyrKw4IIIII61w/gr/TvEWsajHxA27Ct97533D26Ke9Z5Z7lHE1e0Lf+BO3/DGObfvK+Fo9583/AICr/rqd9XmPiD42aRpdxLbafay6jLFJsMgcRwsMclW5J546YPJBxjPb+J9Gk8Q6De6ZFePZtcqEMyKWIXcCRjIyCAQeehry7/hQP/Uw/wDkl/8AbK8Z36H1+XwwTvLFy9Fr990aGk/HXTLmbZqWm3FmrMoWSJxMoBPJbhSAOOgYnn8fVYZo7iGOaGRJIZFDo6EFWUjIII6g141/woH/AKmH/wAkv/tleieCPC0ng/Rm019Qe9XzmkRmQoI1IHygbjxkE/VjSV+peYQwHLzYSWvbX9TJ+JUEjQadOF/dIzozZ6EgED/x0/lXbQTx3MEU8TbopVDq2MZBGQa5rx/bPPoBkUqBBMsjZ7jlePxYVqeGblLrQNOkQMAIVj+b1X5T+or2sR+8y2jL+WUl9+p8bhv3ea14fzxjL7vd0Pyq+MH/ACVrx7/2Hr//ANKHri69U/aR8RaX4r+NfivVdFvYr7TZZII47mE5SQxwRxsVP8Q3IwDDg4yCQQa8rq4fCjefxMVW2sGHUHNatZNaEkn+j7jjLL/Ouik9zCqtjsPhBZpeeMPOkZg9rbyTJtxgscJz7Yc/jiuA1G+k1PULu+mVVlupXmcIMKCxJOM9ua9G8EH+xfBHizXT8rtGLSCSLiWNyMZB4wN0kZ4P8PTgV5hXp4r3MJRp9XzSfzdl+RwUfexFSfay/V/mFdt4e8WWWh+HrW2ngF9m9uGubFiUEsLxRqPnwQPmTI68qOK4mivNOyx6U3i+x1fTlt7zUvs1/fabNBPdmNysMrXzzlW2gnayEAlQcbgPUVDL4i0u5utQsf7SaNZ9Ig05dVeJ8O8bIxLAAvsYIU6ZwFyOorzuii4rHpWoeIdJ1XT7jSU1o2skS2X/ABMpIpcXfkI6sCFBcYLjbkdEGdvGMzU/EGn3PxSh1tLt5NNXUIJ2uHRgxRSm5iuM54PFcRRRcdj0a41u0j8VaJqU2t6Dc2dvqkVw407TGt5Y4xIGLORbxlgAOmWOe1RXHiWxvtYstTt9QisVMElnJYzwSNBAhQqduwZEbhiTj5wxJ5+8fPqKLhY9SU6Rc+HfEsNlrP2O0eTTo2nInaDzAs5KLkGTy+MjIJyB25rJ1/xVZ31n4ojtbuXdfz2CqWVla5SGKRXkb03NtbBOct7GuIW5mSCS3WWRYJWV3jDEKzLnaSOhI3HHpk+tRUXFY9PvfGOlTaZ59qdOhuJNOisHiaK7e5XaiqcDzBBt3LuB4P8As5yS2TxBoi6gmoTalDLf3AvWne0jnWJjJbOql0kHEhdgPk+UA15lRRcLGrod39kOo/8AEw+xebZyxf6nzPPzj91/s7v73bFXPCurxaRHrjvcNBPPYGK3ZQcmXzYmGCOnCk5PpXPUUDsest4v8MyXfhzV3c+fZG61G4sUjZf9LYR7UVtpUBpELg8hRwfQ0rLxX4dlj0efN3ZXGmreWxW7l+0vLFNDIVO9I1HErEYIz+8z0zjzOii4rHqFr4+0220rQtSYtJrtrqdtPeW20jzkhR1EobGMsrKDzncpPescTaDpOj65bxanY6lDeREWcbacRdQyF0IZpHT5cKrAhHIyelcPRRcdj0T/AISK3mntxaa/a2cY06zgmivrJp7eVo48MGXY+WU5AO3HJww78n4pn0y61+9l0eMR6exXy1ClQTtG4hSflUtuIHYECseii4WCiiikMKKKKACiiigAooooAKKKKACiiigDqPi1/wAlB1j/ALY/+iUop3xZC/8ACwNXyTn9z2/6YpRXTmX++Vv8UvzZhg/93p+i/IX4U/8AJRdK+s3/AKKeuUrq/hT/AMlF0r6zf+inrlKqX+5w/wAU/wAoCj/vEv8ADH85BXpfwk1KGeXVfDV3JKsGrQMIyrH5WCkNgYIBKknJ/uAc8V5pU1pdzWF3BdW77J4JFljbAO1lOQcHjqKWCxLw1eNW10t13T0a+4eJo+2puH9X6F6WGbTbu5tZ12Tws0brkHa6kgjI4PIqnXonxCsV1yx0/wAY6fC32a/iVbsLkiGVfl5J7ZGzIAGUH94V53UY/D/V6zp3ut0+6ez+41wlX2tPn2ezXZrdBRUtvD5zkFtqKpZmxnAHtT/Ls/8An9/8hGuI6W0j6f8A2Zv2lk8D6aPBPiVoo9HUSNpd+VwLWViX8uXHWNnYkP1Uscnacx/YXw0gRtGk1GNi8d8UeKQHKSxbQyOh7g7zyMg8Yr8nvLs/+f3/AMhGvTvhp8evFvwq2QaN4i+0aSuf+JXqELzWozvPyrkNH8zlj5bLuON2elKTaoTo00vfab+RnyRliKdeb+BNJep+pFFeZfCH4uv8W9CstWs/DF7b2s8ksU1zHeWs0Fu6Z+Vv3izAkbTgxA/OD90hj6gYnBxtP5V48qU47o9eNWEtmMop3luf4T+VcV8SfH0vw40LUtYn8P3t5p9jaG4e7W6tYbdX5CxsZJQ+S20fKjk7wFDN8tKNOctkOVSEd2dB4is/t+h30ADsxjLKqDJLL8wH4kCvjT43ftIpY+CG8DeFprO7k1OCRLzUoJEmjjtpMholwSPMb5wScbVIwCzBk8v+KX7TXi34m/abL+2f7F0CXcn9nacjp5kZ3jbLL96TKPtYcI20HYDXi/l2f/P7/wCQjXsUOaGHdCaTV+b0drHkVowliliYOzUeX1V7leirHl2f/P7/AOQjTZ4FjWN45PMikBw2MdDzxVF3TIameQtFGuegqGu5+GuhLdam+t3ysmkaQrXEkpUlS6jcAMHJI+9xnoAR8wrqwVCWIrKlHr+Hd/IwxVWNKm6kun9WNHx/cf8ACOeDdA8KqZVumQXV0pf7uSTsOBhhvLY548sdeDXltafiHWpvEOtXupzja9zJuC8HYo4VcgDOFAGcc4rMrpx+IVes5Q+FWS9Fov8AM5sLRdKnaW71fq9wooqxbW3m/vJMiIHGR1Y+g/x7fkDxnQV6K0sW44FrGQO7M2T9cEUv7j/n0i/76f8A+Kp8ouYzKK0/3H/PpF/30/8A8VR+4/59Iv8Avp//AIqjlDmMyitP9x/z6Rf99P8A/FUfuP8An0i/76f/AOKo5Q5jMorT/cf8+kX/AH0//wAVR+4/59Iv++n/APiqOUOYzKK0/wBx/wA+kX/fT/8AxVH7j/n0i/76f/4qjlDmMyitP9x/z6Rf99P/APFUfuP+fSL/AL6f/wCKo5Q5jMorT/cf8+kX/fT/APxVH7j/AJ9Iv++n/wDiqOUOYzKK0/3H/PpF/wB9P/8AFUfuP+fSL/vp/wD4qjlDmMyitP8Acf8APpF/30//AMVR+4/59Iv++n/+Ko5Q5jMorT/cf8+kX/fT/wDxVH7j/n0i/wC+n/8AiqOUOYzKK0/3H/PpF/30/wD8VR+4/wCfSL/vp/8A4qjlDmMyitP9x/z6Rf8AfT//ABVH7j/n0i/76f8A+Ko5Q5jMorT/AHH/AD6Rf99P/wDFUfuP+fSL/vp//iqOUOYzKK0/3H/PpF/30/8A8VVa4tlVTJDuMY+8rHJX/Ee/4emRoLlWiiipKOo+LX/JQdY/7Y/+iUoo+LX/ACUHWP8Atj/6JSiujMv98rf4pfmzDB/7vT/wr8h/wp/5KLpX1m/9FPXKV1nwqdj8Q9KG44zNxn/pk9cnVy/3OH+Kf5QFH/eJf4Y/nIKKKK5DoNW216+i0SfRUlxYTTrcMo4JYDGMjqD8pwc8qCMc5pVHF3qeGIzSpGM5Y44GcVNScptKTvbQ0pxUU2luSTN9nsNh+/cEHHoo6H8TWdVq/mE1y23Hlx/ImDnge9VayYgooopAfRP7I3xq/wCFa+Ol0TWtU+zeENcyk32iXbBaXOB5c5+U7c7RGxyowwZjiMY/S+vxHr9KP2Q/jjJ8TPCMnh3W7qafxVoEa+ZcXMyNJfW5YhJAOGJT5UckHkoxYs5AGNH0hXwP+218av7a1iD4faBqm/TNPy+sfZpcpNchvlgf5efK27iAxG58EBouPpj9pD4yRfBz4fT3lu27xDqm+z0uNXj3RylDm4KvnckfBPysCzIpwGyPyuvb251K8uLy8uJrm8uZGlmnmcvJK7HLMzHkkkkknkk0IGQUUUUCCtCybz7aW2/jB81Pcgcj8qz6ltp2tp45V6qc49R3FNAS1ej16+tNFvNIilxZXrpJKh55XnjsMnbkjk7V5xwYLuIQzsqcxn5lPYg1Vl+6PrWtOcoSvF23X36MdSKlHVEVFFFUZhWkOLS1A4BQsfc7mGfyA/Ks2tP/AJdbT/rmf/Q2qokyGUVa0zTrjV9Ss9Ps4zJd3kyQRIP4nYhVH5kV7b8Rfh5Y28mhTXOk3Ph3RdP1IaBdX0li0P2mFQpS85A3s+JiW56L7U7knhFFelXHhGxtrfxBPa2t3bWqaM1zCZ7i2vkkZbqGMlJ0TbjDnO0KyngnBIOp4X8IeG/7d8HXFvbXerWcl/YJeTi7gkgZpSu6OSDYXiAclfn3BwpAxkEFwPIaK9R0fwZoHiH+3tYiguLbS7G6itI7G41u0tpHkcSMW+0TIiBQIzhAhY564BNTv4C8I6WbcXl9qGorea3JpcE2m3UHliIRwOJCwV1ZlM+CqnBI4ZcclwPJ6K1pPD903id/D9qPPvTemxjAGPMffsH5mvcfE/w+htPEPgyceGJNP07T9eg0Cf7TYmJNRiVkKXDBlAk8zE2488BR6UXA+eKK9E+H1jaXHxWNtPDZG1Rr8hLqASwJsgmKloyrAhSAcbT06GtfVl0HXdI1FrWfTbrV9N0aWe8vNL01ba2mY3cCxhY3iTawV2y6IhOQMkbslwPJKK9Q8W+C/C+kTeKYNN/th38NX0cM7XNxFi6iaQowXEf7tgQAGO4Hk7R0q54o8OaFqPxR8SWOm+HL4afYSz/aI49XtrOGIiQKHEjwCOKPkKEOeSMN2JcDyOivVNW+H/h7wzF4hvNTfUbq2sjprWkNndwZkW6hkkKtMquh27MB0BDYOB8wIwPhlY2UmsX2p6qkB0rSrOSed54fOWJnxDC/ldJNsssZKnggHPpRcDiqK7Dxv4X1TSimrajHpsEd9MY7cWChIrlVRCZ4lUbfLbevIwNxI2jBA7zSPCWj+KPAXhK0e3tbO8t45dUvL5I1WWWzW6ljuNzdXKKI2UHoA1FwPE6K9Z+J2i6Vew6n4isrGLTSsWiGKys0WOBBdWUksnygdd0a857nOc8b3hTw3peja7qWhzwS3mmL4l0KJop2UmQOJ+GypBXLcjHIyOM5ouB4RRXoLaHpus6V4ll0a3eyWLUbK3hi1C6t2ALi43EztHGEXKDgFR/e3YBGt4H0tNH8P+M2u7vw1a39nPYxpfahbRanboH84sqFIp1JbC8qP4cEjFFwPKKK9qsNN0D+w7/UtYsk1Q3Gg3F2H05ILJFZdU8rdF/o+VyMYLLlVLLgAgLyum+CdN1HUPBsQkvEh12xubuYeYpaMxzXKKFO3ptgTOR1J6ZABcZ5/RXX+M9G0Lw/b6Ta2K6jJqdzYWd9cTTzJ5KedAsjRqgTJ5YEMW4HGD96uQoEFFFFMAqSHnzQeQYnyPXCkj9QD+FR1LB1k/65Sf8AoBoQGVRRRWZodR8Wv+Sg6x/2x/8ARKUU74suw+IGrgMQP3Pf/pilFdOZf75W/wAUvzZhg/8Ad6fovyF+FP8AyUXSvrN/6KeuUrq/hT/yUXSvrN/6KeuUqpf7nD/FP8oCj/vEv8MfzkFFFFch0EsX3T9auQt9ntprg9ceWnruPfPbAqism0YxWldWyzRW8aXVsFiU53Sc7j1/Cs2ne5pzK1jIoq9/Zv8A092n/fz/AOtR/Zv/AE92n/fz/wCtU8rJuUaKvf2b/wBPdp/38/8ArVpWngvWb+3S4tbSSeB87ZIo3ZWwcHBC46giqhSnN2irilOMdZOxz9dh8L/iLq3wr8a6Z4l0maYNbSKLm3jk2C8tywMkDEgjDAdSDtIDDlQRV/4V/wCIf+gbc/8AfiT/AOJrI/stv+fm1/7+f/Wpzo1IfHFoUZxl8Lueh/Hz4yXvxo8dXGrbruHQbb9zpdhcOp+zxYAZiF4DuV3N94jhdzBFry2r/wDZbf8APza/9/P/AK1asXgXXbiJJYrCeSKRQyOkLlWB5BB28ilCjOekItjlOMfidjm6K6ObwLrtvFJNNYTxxRqWd3hcKoHJJJXgVlf2b/092n/fz/61E6U4aSi0EZxl8LuUaKvf2b/092n/AH8/+tR/Zv8A092n/fz/AOtU8rHckVvtFgjfx252tnqVPTn9MVVf7hq/ZWq28rF7q2MboUbbJzg+lZ8jbWdODgkZU5BqkmVzK1iKiiitDMK0/wDl1tP+uZ/9Dasyr9tKJ4kgP+tTIT/aB52/XOT75+gNRJZf0bWL3w/qdvqWnTeRfW5LRS7VYoSCMgEEZ54PY8jmrGj+JtV0CK6i067MEd2YzKuxWDFG3KfmBwQfTsSDwSDlMpUlWBBHBB7UlUSdHf8AjrXtRSaKa7iSCa2Nm0FvawwxCIyLIQqIoVSXRSSACccmlbx94gNpb2q3yxJBJFKJIbeKOV2jOYy8iqHk2nkbicVzdFIDpk8f67Ff3l6ktkr3qqLiEadbfZ5tvKs0Pl+WWBJO7bnk881TuPFusXXkebeFvs941/H+7T5ZmCAsOOmIkG3oNvA61i0UAatn4k1PT9e/t22ufL1bzXnFx5akiRs5YAjAPJI44PIxgU/Q/FOreG/N/sy78gSyQyuDGjgvFIJI2wwOCGGfoSDwSDj0UAaNhr2oaZqr6pa3Hl37iUGXYpz5isr8EY5V2HTjPFRWOq3emxX0VrN5cd/B9muBtB3x71fbyOPmRTkYPH1qnRQBsXvirV9Rl1mW5u/MfWpBLeny0HnMH3g8D5fm5+XFaR+I3iJr6S9e5tHuJoPs87Pp9uwuU3Bv3qmPErZVTucM2QOa5WigDf1jxtruvx3ceo33npdm3Mo8pF3eQjJF91RjarsOOuec4FU9D8Qaj4bvHutNuBDLJG0MgaNZEljPVHRwVZTgcMCOBWZRQBva74z1rxLaW9pqd1HNbWrl4Ikt4o1gyACqBFGxDgHYuFzzjPNZ13q15fWWn2VxNvttPR47dNoHlqzl2GQMnLMTznrVKigDpbbx/wCILSWSRLyJ/MtoLRkmtYZYzHAgSL5HQruRQAGxu6nOSajuPHXiG6vL28l1KRru9uoL2aYIoZpod3lvkDgjc3TGc85rnqKANvU/Fuq6tHfx3ElssV/JFLcR29pDAsjxhwjYjRQD+8fJHXPOeKo2+r3lrpl7pkU22yvXjknj2g72j3bDnGRje3Q855qlRQBv6d411vShaLb3URjtLZ7OOKa2iljMLyGRkZHUq4LsW+YHnHoKtaX8RvEmjWqW1jfRRRxmTyj9khZ4hJneqMULIjZOVUheTxXLUUAXNS1W71eaGa9m82SGCK2Q7QuI40CIvAHRVAz1OOc1ToopgFFFFABUsHWT/rlJ/wCgGoqdM/2RHVgRO6lQp6oD1J+oyMe+fTIMzaKKKzLOo+LX/JQdY/7Y/wDolKKPi1/yUHWP+2P/AKJSiujMv98rf4pfmzDB/wC70/8ACvyJPhUF/wCFh6Vyc5m7f9Mnrk66v4U/8lF0r6zf+inrlKuX+5w/xT/KAo/7xL/DH85BRRRXIdAUUUUAFFFFABU1pd3FhcJcWs8sE6Z2yROVZcjBwRz0JFQ0U02ndCavozq7T4l+KrO3SCPWJWRM4MsaSNyc8sykn8TW/wD8Lv8AEH/Pnpf/AH6k/wDi681orup5njKatGq/vv8Amc08Fh56uC+49K/4Xf4g/wCfPS/+/Un/AMXWNd/FPxVd+ev9p+THNuGyGFF2A9lbG4Y7HOffNcdRTnmmMmrSqy++35CjgcPHVQX3Fm+1G81OVZr67nupVXaHnkLsB1xknpyfzqtRRXC5OTu2dSSSsgoooqRhRRRQAUUUUAFFFFAFhb66RQq3MwUDAAc4Apf7Qu/+fqf/AL+Gq1FO7FYs/wBoXf8Az9T/APfw0f2hd/8AP1P/AN/DVaii7CxZ/tC7/wCfqf8A7+Gj+0Lv/n6n/wC/hqtRRdhYs/2hd/8AP1P/AN/DR/aF3/z9T/8Afw1WoouwsWf7Qu/+fqf/AL+Gj+0Lv/n6n/7+Gq1FF2Fiz/aF3/z9T/8Afw0f2hd/8/U//fw1WoouwsWf7Qu/+fqf/v4aP7Qu/wDn6n/7+Gq1FF2Fiz/aF3/z9T/9/DR/aF3/AM/U/wD38NVqKLsLFn+0Lv8A5+p/+/ho/tC7/wCfqf8A7+Gq1FF2Fiz/AGhd/wDP1P8A9/DR/aF3/wA/U/8A38NVqKLsLFn+0Lv/AJ+p/wDv4aP7Qu/+fqf/AL+Gq1FF2Fiz/aF3/wA/U/8A38NH9oXf/P1P/wB/DVaii7CxZ/tC7/5+p/8Av4aP7Qu/+fqf/v4arUUXYWLP9oXf/P1P/wB/DVaiii4BRRRSGdV8WQv/AAsDV8k5/c9v+mKUU34tf8lB1j/tj/6JSiunMv8AfK3+KX5swwf+70/RfkZfg/Wl8PeLdN1FyiwxT4lZ1LBY2yrnA5yFYke/r0p3ibR28P6/qOmkMFt5SI97AsYzyhJHGSpB/HtXPyf6x/qa7LT9e0nXdKsdH18vZzWSslvq6K0rLHnIikTqy8sAQfl+UAY3ZdCUalJ0JOzTur7XejXley1emmu+iqJwmqqV1az/AEfy108zl6K7EfDPXLn59Law1a3HDT2N2jIrf3SWIOcYPTuKP+FVeLv+gT/5Mxf/ABdX/Z2L6UpP0Tf5C+t0Os196OOorsf+FVeLv+gT/wCTMX/xdH/CqvF3/QJ/8mYv/i6P7Oxf/PmX/gL/AMg+t4f/AJ+L70cdRXY/8Kq8Xf8AQJ/8mYv/AIuj/hVXi7/oE/8AkzF/8XR/Z2L/AOfMv/AX/kH1vD/8/F96OOorsf8AhVXi7/oE/wDkzF/8XR/wqrxd/wBAn/yZi/8Ai6P7Oxf/AD5l/wCAv/IPreH/AOfi+9HHUV2P/CqvF3/QJ/8AJmL/AOLo/wCFVeLv+gT/AOTMX/xdH9nYv/nzL/wF/wCQfW8P/wA/F96OOorsf+FVeLv+gT/5Mxf/ABdH/CqvF3/QJ/8AJmL/AOLo/s7F/wDPmX/gL/yD63h/+fi+9HHUV2P/AAqrxd/0Cf8AyZi/+Lo/4VV4u/6BP/kzF/8AF0f2di/+fMv/AAF/5B9bw/8Az8X3o46iux/4VV4u/wCgT/5Mxf8AxdH/AAqrxd/0Cf8AyZi/+Lo/s7F/8+Zf+Av/ACD63h/+fi+9HHUV2P8Awqrxd/0Cf/JmL/4uj/hVXi7/AKBP/kzF/wDF0f2di/8AnzL/AMBf+QfW8P8A8/F96OOorsf+FVeLv+gT/wCTMX/xdH/CqvF3/QJ/8mYv/i6P7Oxf/PmX/gL/AMg+t4f/AJ+L70cdRXY/8Kq8Xf8AQJ/8mYv/AIuj/hVXi7/oE/8AkzF/8XR/Z2L/AOfMv/AX/kH1vD/8/F96OOorsf8AhVXi7/oE/wDkzF/8XR/wqrxd/wBAn/yZi/8Ai6P7Oxf/AD5l/wCAv/IPreH/AOfi+9HHUV2P/CqvF3/QJ/8AJmL/AOLo/wCFVeLv+gT/AOTMX/xdH9nYv/nzL/wF/wCQfW8P/wA/F96OOorsf+FVeLv+gT/5Mxf/ABdH/CqvF3/QJ/8AJmL/AOLo/s7F/wDPmX/gL/yD63h/+fi+9HHUV2P/AAqrxd/0Cf8AyZi/+Lo/4VV4u/6BP/kzF/8AF0f2di/+fMv/AAF/5B9bw/8Az8X3o46iux/4VV4u/wCgT/5Mxf8AxdH/AAqrxd/0Cf8AyZi/+Lo/s7F/8+Zf+Av/ACD63h/+fi+9HHUV2P8Awqrxd/0Cf/JmL/4uj/hVXi7/AKBP/kzF/wDF0f2di/8AnzL/AMBf+QfW8P8A8/F96OOorsf+FVeLv+gT/wCTMX/xdH/CqvF3/QJ/8mYv/i6P7Oxf/PmX/gL/AMg+t4f/AJ+L70cdRXY/8Kq8Xf8AQJ/8mYv/AIuj/hVXi7/oE/8AkzF/8XR/Z2L/AOfMv/AX/kH1vD/8/F96OOorsf8AhVXi7/oE/wDkzF/8XR/wqrxd/wBAn/yZi/8Ai6P7Oxf/AD5l/wCAv/IPreH/AOfi+9HHUV2P/CqvF3/QJ/8AJmL/AOLo/wCFVeLv+gT/AOTMX/xdH9nYv/nzL/wF/wCQfW8P/wA/F96OOorsf+FVeLv+gT/5Mxf/ABdH/CqvF3/QJ/8AJmL/AOLo/s7F/wDPmX/gL/yD63h/+fi+9HHUV2P/AAqrxd/0Cf8AyZi/+Lo/4VV4u/6BP/kzF/8AF0f2di/+fMv/AAF/5B9bw/8Az8X3o46iux/4VV4u/wCgT/5Mxf8AxdH/AAqrxd/0Cf8AyZi/+Lo/s7F/8+Zf+Av/ACD63h/+fi+9HHUV2P8Awqrxd/0Cf/JmL/4uj/hVXi7/AKBP/kzF/wDF0f2di/8AnzL/AMBf+QfW8P8A8/F96OOrW8M6O3iDX9P00BitxKBJsYBhGOXIJ4yFBP4d62z8M9ctvn1RrDSbc8LPfXaKjN/dBUk5xk9OxqtqGvaToWlX2j6AXvJr1VS41d1aJmjzkxRp1VeFBJPzfMCMbcOOFlRkp4pcqXR6N+SW+ve1l+DUq6qLlou7fVbLzv8ApuzJ8aa0viHxTqmooUaGWYiJkUqGjUBUODzkqoJ9/TpRWDRXBVqSqzlUlu23950wgoRUI7LQkkkcOwDN1Pem+Y/99vzooqCg8x/77fnThI+xjubqO/1oooAb5j/32/OjzH/vt+dFFAB5j/32/OnSSOHYBm6nvRRQA3zH/vt+dHmP/fb86KKAHCR9jHc3Ud/rTfMf++350UUAHmP/AH2/OjzH/vt+dFFADpJHDsAzdT3pvmP/AH2/OiigA8x/77fnThI+xjubqO/1oooAb5j/AN9vzo8x/wC+350UUAHmP/fb86dJI4dgGbqe9FFADfMf++350eY/99vzoooAcJH2MdzdR3+tN8x/77fnRRQAeY/99vzo8x/77fnRRQA6SRw7AM3U96b5j/32/OiigA8x/wC+3504SPsY7m6jv9aKKAG+Y/8Afb86PMf++350UUAHmP8A32/OnSSOHYBm6nvRRQA3zH/vt+dHmP8A32/OiigBwkfYx3N1Hf603zH/AL7fnRRQAeY/99vzo8x/77fnRRQA6SRw7AM3U96b5j/32/OiigA8x/77fnThI+xjubqO/wBaKKAG+Y/99vzo8x/77fnRRQAeY/8Afb86dJI4dgGbqe9FFADfMf8Avt+dHmP/AH2/OiigBwkfYx3N1Hf603zH/vt+dFFAB5j/AN9vzooooA//2Q==",
	"ngantuk": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4lkkcOwDN1Pem+Y/99vzok/1j/U16xc3MPwgt7SxsbSMfEEJ5l9qEmJVsFcBlhiUjYXKbdz4bG5gGOfl9ClS57yk7Jbv9F5maRg6X8HvH2r27T2/h69RFcoRdOtu2cA8LIykjnrjHX0NXx8CfiJtP/EhbOR/y+wf/AByuN1PWNR1udbjU7+6vZ1UIsl1M0rBck4BYk4yTx7mqVa/7Ovsy+9f/ACLC8ex33/CifiL/ANAFv/A2D/45R/won4i/9AFv/A2D/wCOVwNFF8P/ACy/8CX/AMiF49jvv+FE/EX/AKALf+BsH/xylf4E/EQs2NBbGeP9Ng/+OVwFFF8P/LL/AMCX/wAiF49jvv8AhRPxF/6ALf8AgbB/8co/4UT8Rf8AoAt/4Gwf/HK4Gii+H/ll/wCBL/5ELx7Hfj4E/ETaf+JC2cj/AJfYP/jlJ/won4i/9AFv/A2D/wCOVwNFF8P/ACy/8CX/AMiF49jvv+FE/EX/AKALf+BsH/xyj/hRPxF/6ALf+BsH/wAcrgaKL4f+WX/gS/8AkQvHsd+/wJ+IhZsaC2M8f6bB/wDHKT/hRPxF/wCgC3/gbB/8crgaKL4f+WX/AIEv/kQvHsd9/wAKJ+Iv/QBb/wADYP8A45Sj4E/ETaf+JC2cj/l9g/8AjlcBRRfD/wAsv/Al/wDIhePY77/hRPxF/wCgC3/gbB/8co/4UT8Rf+gC3/gbB/8AHK4Gii+H/ll/4Ev/AJELx7Hff8KJ+Iv/AEAW/wDA2D/45Sv8CfiIWbGgtjPH+mwf/HK4Cii+H/ll/wCBL/5ELx7Hff8ACifiL/0AW/8AA2D/AOOUf8KJ+Iv/AEAW/wDA2D/45XA0UXw/8sv/AAJf/IhePY78fAn4ibT/AMSFs5H/AC+wf/HKT/hRPxF/6ALf+BsH/wAcrgaKL4f+WX/gS/8AkQvHsd9/won4i/8AQBb/AMDYP/jlH/CifiL/ANAFv/A2D/45XA0UXw/8sv8AwJf/ACIXj2O/f4E/EQs2NBbGeP8ATYP/AI5Sf8KJ+Iv/AEAW/wDA2D/45XA0UXw/8sv/AAJf/IhePY77/hRPxF/6ALf+BsH/AMcpR8CfiJtP/EhbOR/y+wf/AByuAoovh/5Zf+BL/wCRC8ex33/CifiL/wBAFv8AwNg/+OUf8KJ+Iv8A0AW/8DYP/jlcDRRfD/yy/wDAl/8AIhePY77/AIUT8Rf+gC3/AIGwf/HKV/gT8RCzY0FsZ4/02D/45XAUUXw/8sv/AAJf/IhePY77/hRPxF/6ALf+BsH/AMco/wCFE/EX/oAt/wCBsH/xyuBoovh/5Zf+BL/5ELx7Hfj4E/ETaf8AiQtnI/5fYP8A45Sf8KJ+Iv8A0AW/8DYP/jlcDRRfD/yy/wDAl/8AIhePY77/AIUT8Rf+gC3/AIGwf/HKP+FE/EX/AKALf+BsH/xyuBoovh/5Zf8AgS/+RC8ex37/AAJ+IhZsaC2M8f6bB/8AHKT/AIUT8Rf+gC3/AIGwf/HK4Gii+H/ll/4Ev/kQvHsd9/won4i/9AFv/A2D/wCOUo+BPxE2n/iQtnI/5fYP/jlcBRRfD/yy/wDAl/8AIhePY77/AIUT8Rf+gC3/AIGwf/HKP+FE/EX/AKALf+BsH/xyuBoovh/5Zf8AgS/+RC8ex33/AAon4i/9AFv/AANg/wDjlK/wJ+IhZsaC2M8f6bB/8crgKKL4f+WX/gS/+RC8ex33/CifiL/0AW/8DYP/AI5R/wAKJ+Iv/QBb/wADYP8A45XA0UXw/wDLL/wJf/IhePY7LU/g9490e1E1x4evHVnCAWrLcNnBP3Y2YgcdcY6eorg/Mf8Avt+da+maxqOiTtcaZf3VlOylGktZmiYrkHBKkHGQOPYV6DbXMPxft7uxvrSM/EEp5ljqEeIlv1QFmhlUDYHCbtr4XO1QWGPmPZU6ulK6fZ639Gkteyt8wVnseT+Y/wDfb86KbRXII7z4PaXDq/xS8PW87SKiXLXIMZAO6JWlUcg8FkAPtnp1rnNY1ObW9Wv9TuFRZ72eS4kWMEKGdixAyScZPrXZfAkL/wALb0Hk5zcdv+mElcBXXth4/wCJ/lH/ADG/hR9NfAPxX4O0jwhJbzXtjpmsiUm9e8lWI3HLeWVZj8yheMDocnA3Zb1b/hP/AAl/0NGif+B8X/xVfB9FelQzidGnGmoLQuNVpWsfeH/Cf+Ev+ho0T/wPi/8AiqP+E/8ACX/Q0aJ/4Hxf/FV8H0Vr/btT+RD9s+x94f8ACf8AhL/oaNE/8D4v/iqP+E/8Jf8AQ0aJ/wCB8X/xVfB9FH9u1P5EHtn2PvD/AIT/AMJf9DRon/gfF/8AFUf8J/4S/wCho0T/AMD4v/iq+D6KP7dqfyIPbPsfeH/Cf+Ev+ho0T/wPi/8AiqP+E/8ACX/Q0aJ/4Hxf/FV8H0Uf27U/kQe2fY+8P+E/8Jf9DRon/gfF/wDFUf8ACf8AhL/oaNE/8D4v/iq+D6KP7dqfyIPbPsfeH/Cf+Ev+ho0T/wAD4v8A4qj/AIT/AMJf9DRon/gfF/8AFV8H0Uf27U/kQe2fY+8P+E/8Jf8AQ0aJ/wCB8X/xVH/Cf+Ev+ho0T/wPi/8Aiq+D6KP7dqfyIPbPsfeH/Cf+Ev8AoaNE/wDA+L/4qj/hP/CX/Q0aJ/4Hxf8AxVfB9FH9u1P5EHtn2PvD/hP/AAl/0NGif+B8X/xVH/Cf+Ev+ho0T/wAD4v8A4qvg+ij+3an8iD2z7H3h/wAJ/wCEv+ho0T/wPi/+Ko/4T/wl/wBDRon/AIHxf/FV8H0Uf27U/kQe2fY+8P8AhP8Awl/0NGif+B8X/wAVR/wn/hL/AKGjRP8AwPi/+Kr4Poo/t2p/Ig9s+x94f8J/4S/6GjRP/A+L/wCKo/4T/wAJf9DRon/gfF/8VXwfRR/btT+RB7Z9j7w/4T/wl/0NGif+B8X/AMVR/wAJ/wCEv+ho0T/wPi/+Kr4Poo/t2p/Ig9s+x94f8J/4S/6GjRP/AAPi/wDiqP8AhP8Awl/0NGif+B8X/wAVXwfRR/btT+RB7Z9j7w/4T/wl/wBDRon/AIHxf/FUf8J/4S/6GjRP/A+L/wCKr4Poo/t2p/Ig9s+x94f8J/4S/wCho0T/AMD4v/iqP+E/8Jf9DRon/gfF/wDFV8H0Uf27U/kQe2fY+8P+E/8ACX/Q0aJ/4Hxf/FUf8J/4S/6GjRP/AAPi/wDiq+D6KP7dqfyIPbPsfeH/AAn/AIS/6GjRP/A+L/4qj/hP/CX/AENGif8AgfF/8VXwfRR/btT+RB7Z9j7w/wCE/wDCX/Q0aJ/4Hxf/ABVH/Cf+Ev8AoaNE/wDA+L/4qvg+ij+3an8iD2z7H3h/wn/hL/oaNE/8D4v/AIqj/hP/AAl/0NGif+B8X/xVfB9FH9u1P5EHtn2PvD/hP/CX/Q0aJ/4Hxf8AxVH/AAn/AIS/6GjRP/A+L/4qvg+ij+3an8iD2z7H3h/wn/hL/oaNE/8AA+L/AOKo/wCE/wDCX/Q0aJ/4Hxf/ABVfB9FH9u1P5EHtn2PvD/hP/CX/AENGif8AgfF/8VR/wn/hL/oaNE/8D4v/AIqvg+ij+3an8iD2z7H3h/wn/hL/AKGjRP8AwPi/+Ko/4T/wl/0NGif+B8X/AMVXwfRR/btT+RB7Z9j64+LfjPwRqHgXU7a41LTtUnkUi0htJ0mkS4wdjja2VCnkngYyOd20/Kmj6nNomrWGp26o09lPHcRrICVLIwYA4IOMj1qlRXm4vGSxNRVGrNGcpuTudd8ZdLh0j4neJLeBpGR7gXJMhBO6VFlYcAcBnIHtjr1oq/8AHkL/AMLX8QZJz/o/b/p3jornxaSxFRLu/wAxy3YvwJ/5K5oP1uP/AERJXA133wJ/5K5oP1uP/RElcDVv/d4/4pflET+FBRRRWBIUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUVv6No1q1l/auq+edPMrQRQ2zhJZ5FClhuKsEVQ6EkgkllAHLMlRi5OyAwKK7T+1NI/6FHRv+/15/wDJFH9qaR/0KOjf9/rz/wCSK09kv5l+P+QtO5xdFdp/amkf9Cjo3/f68/8Akij+1NI/6FHRv+/15/8AJFHsl/Mvx/yDTucXRXaf2ppH/Qo6N/3+vP8A5Io/tTSP+hR0b/v9ef8AyRR7JfzL8f8AINO5xdFdp/amkf8AQo6N/wB/rz/5Io/tTSP+hR0b/v8AXn/yRR7JfzL8f8g07nF0V2n9qaR/0KOjf9/rz/5Io/tTSP8AoUdG/wC/15/8kUeyX8y/H/INO5xdFdp/amkf9Cjo3/f68/8Akij+1NI/6FHRv+/15/8AJFHsl/Mvx/yDTucXRXaf2ppH/Qo6N/3+vP8A5Io/tTSP+hR0b/v9ef8AyRR7JfzL8f8AINO5xdFdmNN03xPLHZ2GmppmrzMI7ZIJna3nYn5Y2EhZldicB9+3IUFVBZxxlRODj5jCitnStKge1/tDUPNNkZGhjigcLJM4ALfMQQoUMpJIOcgAdSun9s0z/oXNN/7+3P8A8erGVRRdjkni1GVoxcvS36tf15nJ0V1n2zTP+hc03/v7c/8Ax6j7Zpn/AELmm/8Af25/+PVPtokfXP8Ap3L/AMl/+SOTorrPtmmf9C5pv/f25/8Aj1H2zTP+hc03/v7c/wDx6j20Q+uf9O5f+S//ACRydFdZ9s0z/oXNN/7+3P8A8eo+2aZ/0Lmm/wDf25/+PUe2iH1z/p3L/wAl/wDkjk6K6z7Zpn/Quab/AN/bn/49R9s0z/oXNN/7+3P/AMeo9tEPrn/TuX/kv/yRydFdZ9s0z/oXNN/7+3P/AMeqlqOl2t1az32nRvD9nAe5tnfcFUsFDoxGdu5gu05YZBy2WKuNWLdioYtNpSi1fvb9GzAooorQ7Du/j1/yVjxB/wBu/wD6Tx0UfHr/AJKx4g/7d/8A0njorXG/7xU/xP8AMuXxMf8AAn/krmg/W4/9ESVwNd/8CXY/FvQRuOM3HGf+mElcBVP/AHeP+KX5RE/hQUUUVgSFFFFABRUlvbzXc8VvbxPNPMwSOONSzOxOAAByST2r2S3+EWi+CLG31b4iat5Xm5aHSbHLSTMArFGcfih24AJU+YMit6OHnWu47LdvZDUWzyjRNB1PxJfpY6TYz3l02DshXO0EgbmPRVyRljgDPJr02w/Z71uO1jv/ABFqul6Fp4z57zzB3h5IXOMIcnb/AB/xevFO1H41XWmwLpngfS7Xw/pUTgqViWSeYgFQz7gVyVCZyGbK/fNeeahe6prk63Gp31zdzKoQSXUzSMFyTgFiTjJPHvXQlhqe95v7l/m/wH7q8z0weB/hLpX+iap43vrm+j/1k1jHmFs8jbtjkHQgH5zyD06Bf7e+Cv8A0KGtf9/m/wDkivKxZrjliT7U8W0ePu/rT+s2+GnFfK/53F7RdEeo/wBvfBX/AKFDWv8Av83/AMkUh8MfB3V+bTxPqum3V5/qobhCY7V2+6rEx42qSASZOg+93ry/7NF/d/U0w2i44Zgfej61f4qcX8rflYPaeR6bc/s+319BLdeF/Eej67aRIQzRybGMoGfLG0uucFeSw+9zgc15t4j8Ja34Ru1tta02ezkb7hcApJgAna4yrY3DOCcZweaSzlvtKuo7uwupre5jzsmgkMbrkEHBByOCR1716Bovxu121gOn+Ira18RaSyoj2t/Gu4hR8vz7Tk52klwxO3sTmk/qtTRpwf3r/P8AMd4vyPJqK9tT4a+EPiSk0/gLVH07UY13yaRqQYhV3BchvmIHBYkGTl1B2ZxXj+r6RfaDqVzpupWz217bNskifqp/kQRggjgggjg1hWw06SUnqns1qhOLRSooornEFFFFABXaap/yAPCP/YNk/wDSy5ri67PUSJPDvhSRDujSylhZl5CyC6mcoT2YLIjY64dT3FbUtpen6oOjKmkWH9q6tYWHmeX9rnjh37c7dzAZx3xmu5uPhfDLrWraFpetNda1pyGQ289p5KzgAEhGDtk8jggVxWhX0ema3pt9MrtFa3MczhBliFYE4z34r0WT4jaFp3ivWPFOmQ6jcareoyW8VzEkUVuSACxKuxfp0wOv4114eNFx/ed/wt0CPLbU5e38GwW/hyz17WtSaxtL+Vo7WOG386WTbwzEFlAUH3z7VtWfwmnm8TNpNxqaJatp51KC8hh8wTRZGMKWXB59e3vms/8A4SvS9a8JaXoWtrewyaVI7QXVpGspdHOSrKzLg+hB7dK6Ox+K+mp4pW8ns7uHSLbSTpdrHEFklAyMM2Sozx2Pp9a1pxw11zbad/ncaUepyN34MSXw2/iDRr9r+xgmEFxHLB5M0LNjaSoZgQSQMg9/rjVf4aW9prVn4fvtcWDxBdIrCAWxeGN2GVRpN2QT7KRz1qq/i/T9H8I3Ph/Qlu5GvbhJ7m8u0WMnYQVVUVmxyoOSx7+vGvc+PfD+qeK7HxZe2mopqtuqNJZwqhhllQYVhIWyo4HG09OtJRw+l7X0vvbre34fiFomTY/Da6Om6rqGoyXMMWm3hsZIrO1+0y+YBljt3KAoyPmz3pmh+CNP1qLxHdrrMy6fosKTGRbLMkoYHI2F12kEEdTVvSPH7W+p6jqz6xq+m6hfXTTyR2UMc0DqcEAo7ryORk54xW7H8VtMl1fxheeVqGm/21DFFbzWSK0kRQEF2+dPmOc8H8acIYZ2v5/PR26+nb1BKBzt18ML065oGm6ddpcrrdsLqCSWMxNGhGSXXJxgehOe1RL4DtdRg1o6JrJvrrR0aWeGS28oSRqcM0bbm3Ae4U1t3HxVgttf8M6nZ21xdzaTA0FzdXmEmvVYYO7BbGOSMk8nn3z7LxhoXhqLxBNocWoS3urwvboLtERLWNzlsFWYuemDhelDjhru23z7dPnfv9wWiQ23grQ7rwreeI013URZWk627xnTE8wsccgefjHzDvXGJbG6vltrMSTGWXy4dyhWfJwuRk4J44yfrXT2Hiqztfh1qvhx4rg3t3eJcI4UeWFAXIJznPyntVTwHrWmeHfE1pquqQzzw2m6SOOFVJaXHy5yRgA859hWElSk4KNlfffuS7O1jY+IHw0k8D21lcpqSahDNI0ErJFsEMoAOw/Mc5GfTpWT468I/wDCF60mm/bPte6BJ/M8ry8bs8YyfT1reuPiPaa34a8QaVq2mJDLfzC9t5LIOwFzn5mbzJDgEAD5egJ4rK+JHiqz8YeII9QsYriOFbaOErOoDblznoTxzWleOH5ZSp+Vlrpvf9By5bXRyFTeP/8AkfPFH/YUuv8A0a1Ngglup4oIInlnlYIkcalmdicAADqSe1N8b3EN3408R3FvKk0E2o3LxyRsGV1MrEEEcEEd643/AA36r9RR2L15/wAgbw5/15P/AOlM9UoYZLmaOGFGklkYIiKMliTgAVcuSH0Pw+6nciWskTMOQHFxKxU++10OPRge4p/h/VP7D13TdSMfmCzuEmKf3grA4rzJ/EzyE2ozcVd3l+bO+uPgN4og0k3gazkuFXebNJCZPoDjaT7Z/GvOdO0+41TULawtk3XNzIsUanjLE4H0r6ouPjJ4Rh0o3yakJX2ZW1VGEpb+7jHH16e9fMVjr0+n+I4dbiRPPiuftIT+HO7dt+naoR5GVYvHV41PrELNbXVtddDq0+GsF1rd34fs9cWfX7ZGYwG2KwyOoyyLJuySOeqgcVCnw0uZvAX/AAlEF3vlQuZLExYZURyrMGzzjgkYGAfatO38eeH9N8V3viyztdQbVJ1do7OVUEMUrjDMZA2WHJ42jr1qHTviXHpmh+HLaOGeS70+6nlvFdV8qeKUtuQc85Ddx1o1Kc8faPJ/dvdLs+Zel7K/nuxV+FG7xM2i/wBr/d0z+0fO+zfT5Nu/365/Cuc8E+Ev+Ex1O6svtn2XyLWS53+Xv3bcfLjI65613T/FHQj46n1lLXUE059KOnqnloZFbPXG/GMe+a53wb4k0DwbrFxeRz6neRXFlNbsGs44mVmK7SP3rZHBz0xx17A4Vcb7KXMnzcqtot9b9Ldt/kRRfDe4uvAC+Kra9Erguz2XlYZY0cqzht3OOCeOhrRi+FCv4pOiNrBVRpo1Ezi1yccfJt3+/XP4VFpPxHg0bw94ZsbeCd7jTLmZ7pHVfKnhkJ3IOcnIPcda3f8Ahamhr48l1yK31GKwOl/YUVY081GyMHG/GAB65o1IqVMwTmorT3raLv7q+7Vd767HlmpRaZEY/wCzru7uAc7zc2qw7fTG2R89/SpdC/4+rr/rwvP/AEmkqz4k1NdTe3ca3q2qsgILalHtMY4wF/evnPOenTvVbRCEmvZWO2NLC73OeAu6B0XJ7ZZlUepYDqaqO6PTk28O772f9bL8jkKKKK7T3Du/j1/yVjxB/wBu/wD6Tx0U748uw+K/iABiB/o/f/p3jorXGf7xU/xP8y5fExfgT/yVzQfrcf8AoiSuBrvvgT/yVzQfrcf+iJK4Gqf+7x/xS/KIn8KCiiisCQra8K+FdT8ZazBpWlQeZcycszcJEg6u57KM/qAMkgGlpGkX2valbabpts9ze3LbI4k6sf5AAZJJ4ABJ4Fe1+KdZh+Dnh6Lwf4eCJ4ivIEl1bU45AzoxB+RDwQeu3IG1WBA3OWHVh6CknUqaRX4+S8/yKir6vYS917w58FoNS0fwsz6l4ukVYbnVZlUx25x86IPUMM7ORkjczFNteS6hfX3iDUbnUtSuZJ7u5bfJK/Vj7dgAMAAcAAAcCqsFuCA7dOwqy8ixjLH8PWnWruorbRWy6f8AD+ZMpN6IEjWMYUf/AF6HkSP7zAVSkunfgfKPbrUFcrqpbFKl3LxvIwcfMfcCmfbf+mf61UoqHVkV7OJb+2/9M/1p4vEOMhhVGij2kg9nE00lR/usCfSnMocYYAisqpY7h4+M5X0NWqvcl0uxZRZrKeK5tZZI5onDo8bFXRgchgRyCD3FetaX8QND+JGm23h74ib0u1nzaa1bqkRi3dQ5xhQcBc7SpBBIBXdXlMUyyjIPPcVHPbhsuvB7j1rpo15Uvh1T3XRkxk46M1fH3gHU/h9rJsb4eZbSZa1u0XCXCDuPRhkZXtnuCCeUr2z4beLLTxdYRfD3xcn2nTrn5NPu2cLJayAHYoY/knU5OzDK2B5b4q8K6n4N1mfStVg8u5j5Vl5SVD0dD3U4/Qg4IIDr0Y8qrUvhf4Pt/kVJdUYtFFFchIVs6NriWMLWV/bveaW7GTyUlEckcmAN8blW2kgAMCpDADIyqMuNRVRk4u6A7DzPCX/QW1v/AMFUX/yTR5nhL/oLa3/4Kov/AJJrj6K09qv5V+P+YadjsPM8Jf8AQW1v/wAFUX/yTR5nhL/oLa3/AOCqL/5Jrj6KPar+Vfj/AJhp2Ow8zwl/0Ftb/wDBVF/8k0eZ4S/6C2t/+CqL/wCSa4+ij2q/lX4/5hp2Ow8zwl/0Ftb/APBVF/8AJNHmeEv+gtrf/gqi/wDkmuPoo9qv5V+P+YadjsPM8Jf9BbW//BVF/wDJNHmeEv8AoLa3/wCCqL/5Jrj6KPar+Vfj/mGnY7DzPCX/AEFtb/8ABVF/8k0eZ4S/6C2t/wDgqi/+Sa4+ij2q/lX4/wCYadjsPM8Jf9BbW/8AwVRf/JNHmeEv+gtrf/gqi/8AkmuPoo9qv5V+P+Yadjq5te0vSFLaF9tm1D+C/u0SE2//AFziVn+cY4kL8bjhQwVxylFFRKbkBqaXq62cbW13C1zYM2/ylk2Oj4+8jEHaTgA8EEAZGQpXU8/w7/0ENV/8F8f/AMfrl6KxlTjLVnNUwsZS5k2vS36pnUef4d/6CGq/+C+P/wCP0ef4d/6CGq/+C+P/AOP1y9FL2USPqf8Aff4f5HUef4d/6CGq/wDgvj/+P0ef4d/6CGq/+C+P/wCP1y9FHsoh9T/vv8P8jqPP8O/9BDVf/BfH/wDH6PP8O/8AQQ1X/wAF8f8A8frl6KPZRD6n/ff4f5HUef4d/wCghqv/AIL4/wD4/R5/h3/oIar/AOC+P/4/XL0UeyiH1P8Avv8AD/I6jz/Dv/QQ1X/wXx//AB+qGpaxC0D2emxyxWr486SVgZLjB4zjhVyA2wE89WbC4xqKapxTuVDCxi1KTbt3t+iX4hRRRVnUd38ev+SseIP+3f8A9J46KPj1/wAlY8Qf9u//AKTx0Vrjf94qf4n+ZcviZJ8CQv8AwtvQeTnNx2/6YSVwFd98Cf8Akrmg/W4/9ESVwNU/93j/AIpflET+FBRRXT/D/wAIzeN/Fmn6QgcQSNvuZEz+7hXlznBAOOASMbmUHrWcIOclCO7JSvoeleB7bT/hb4D/AOE21C3gl8T6luTSLe5LArGcKXC4yMgli2cFCgDLvOfJA0t7cS3VzI80srF3kkYs0jE5JJPJJPeu0+LPiqLxT4sa104ouiaUv2KyjhwIgq8M6gErgkcFcZVU44rklUIoUdBXXiZptUofDH8X1fz/ACHN9EJI4jQsf/11mu7SMWY81PePlwgPA6/Wq1efUld2LpxsrhRRRWZoFFFFABRRRQAUUUUAKrFSCDgitGGUSpnjd3FZtTWr7JQM8NxWlOVnYznG6JrmH+NR9a9jAtfjJ8O5vMjRvHXh2DERV2aa8t0xyRglyfmGBkiTByofB8mIyMHpWr4H8UzeBfFtjqqGQ26NsuI1zmWFuHGMgEgcgE43Kp7V34eooS5Z/DLR/wCfyM4StozjKK9A+MHhGLwv4sefTwjaHq6/bbKSHBi2tyyKQAuATwFzhWTnmvP65qtN0puEt0DVnYKKK92/Z4/Zw/4X3b+IZf8AhJv7F/sd4Fx9h+0+b5gc/wDPRNuNnvnNZtpK7A8Jor2rwB+ztqHi34y6x8NNV1X+xr7S0md7kWvnhwhXaQm9flZWDA56EV5f4w0D/hFPFuvaB9o+0/2Tfz2Xn7Nnm+VIybtuTjO3OMnGeppXT0AxaKKKYBRRRQAUVq+GPD9z4s8S6NoFk8Md5q15DYwvOSI1eVwiliASBlhnAJx2NdB8VPhhq/wh8WyeGtbubG4v44Y5zJYu7x7XGRy6qc8elF+gHFUUV0vw98Jf8J5440Dwz9s+xf2tdx2v2nyvM8rccbtuRnHpkUAc1RXffGb4a/8ACoviFqfhL+1P7T+wpC/2vyPI3+ZGr/c3NjG7HU9K4GhO+oBRXv3wo/Zw034g/C3V/iBrHjj/AIR7S9KuZYbhf7Ka72oiIxfKyKx+/jAU9Ki8cfs2x6N8MT8RvCPjOz8VeF4nCzSrZvaSxgyCPPluSeGIBBwec4xS5lewWPBqKKKYBRRRQAUVq+GPD9z4s8S6NoFk8Md5q15DYwvOSI1eVwiliASBlhnAJx2NdB8VPhhq/wAIfFsnhrW7mxuL+OGOcyWLu8e1xkcuqnPHpRfoBxVFFFABRRRQAUUUUAFFFFABRRRQB3vx5C/8LX8QZJz/AKP2/wCneOim/Hr/AJKx4g/7d/8A0njorXGf7xU/xP8AMuXxMf8AAn/krmg/W4/9ESVwNd98Cf8Akrmg/W4/9ESVwNU/93j/AIpflET+FBXuPwjkTwl8NfGnjFG/04YsbdlhVngfC7WBY8qXmjJGP+WeeeBXh1e1+Px/YPwa+H2h/wCu+27tR8/7uzIL7NvOf+PnGc/wdOeN8F7jnW/lX4vRfmENLs8ntEyWcjpwKt1HAu2JenPNSVzrYyZBJBG8mWYhm7Un2OP1b86jvW+ZF7gZrqvhbqnh2w8feHrjxisr+HILtJLry4ll4HK70IO+PcF3gAkpuABOKxlKKbujWMZNKzPoX4I/sg6X448FweJPFuo6tZ/2l+8srWy2xOsIJAeQyRtnfwy7Rjbg5O7C+lf8MMfDv/oM+Kf/AAKt/wD4xX0do+rWev6RYatp03nafqEEdzby7Su+N1DK2GAIyCDggGrteJPEVHJu9j1o0IJJWufMn/DDHw7/AOgz4p/8Crf/AOMUf8MMfDv/AKDPin/wKt//AIxX03RU+3qdyvYw7HzJ/wAMMfDv/oM+Kf8AwKt//jFH/DDHw7/6DPin/wACrf8A+MV9N0Ue3qdw9jDseNfD39lz4deAf7Rzpv8Ab/23y/8AkYILe78jZu/1f7obd27n12r6V2F38KvhrZWk9zL4A8NNHBG0jCHQoZXIAydqLGWY8cBQSegBNdsuAwz0qTcnt+VdNKtJx1kvmctalFS0T+R+ZX7R+qeAPEnjjT7v4ew2MOippscUq2FgbOMziWUsShRcnaU+bHTAzxXj620ayLhm3DnFfUP7TvxG+EfjDwjbnwIdLk8TS6stzd3FvpD208kRjl3s0rRLuy7ISCSSee2a+WLRv33OSWBr04uOiscLUrN3L1V7tMoGxyP5VYprrvRl45Het2ZI9W1iRPGX7PlpfTN/p3hi6W3Mjwrl0yqBFYHhdksWT3MfIP3q8Nr2z4Cj+1x4x8L/AOq/tjTG/wBJ+95WMx/d43f6/PUfd9+PE66MX78KdXurP1Wn5WNZapMK+0P2JLqay+H3xiubeRoriC0hkjkU4KMIbkgj3BFfF9emfDH44+IfhPofifSNFs9LuLbxHEsN017FI7oArr8hV1AOJG6g9BXnyV1YlH3b8HVsfi14g8IfGawEMeqNpU+i69AmBi4XYVbH4H32vH6V5h+zz4V0fUPjb8dPE97YQ6hqvh7UrlrCCVQ21nnuCzKD/F+6VQe24+tfNnwb/aE8W/BBNVi8PxaddWupFGlt9RjkkjV1yA6hHUgkHB55AHoK2Pgx8Stcg+L+s+JbfxZo3hbUNaNxczNqUTtp9xJJKHML4JKLliQ2cjbjPNQ4NXHc+l/2XPihrnxV0j4qap4itrF9ShtolF/bWiQNJGyTkRNtA3BMEqTlvnOSeK86+Bdh488E/BceLZvirZ+BfAt1ePJCraLHqMsshbyi20ruGTHgAE8KTgda9Cj+Muh/DDwV4zvNb8V+BtS1vWYSlhofgeMfZVlKuDI7Dks5dSzOeBGMZJxXy14I/aN8WeCfBMngwWOg634dLl4rPW7H7SkBLbjtG4A/MS2GDAE0JN3sO571+1/oei6r8HPAPjmCe11LWLu4it31qCwNkdQikgkfe0R5GTGCAem444NdF+0H8TNV+GHw1+DOpaDBYrrMlivl3t1apO0MawQF0QOCF35XLD5sLgEZNfL/AMRf2iPFvxR8D6T4T1+DSjZ6ZcLdR3NvA8c8jqjoA3zlAuJDwqqBgYwBis/4lfG7xB8U/D/hbRNYs9LgtfDUJgtXs4pFd1KImXLOwJxGvQDqaag9LiufX/xpvZfA/wC0p8Itb8OCHTb7xS8Onao0UCH7TA91CGDZB+Yq+Nww2AOeK5D9qn4seL7H4xQeA4dY2eEro6fLNYm2hO5vNV8+YU3j5kU8N2r57+JX7Qfiv4n614Y1jUIdM0/UPDZ3WUunROmGDKwZt7vkgoD2q98SP2j9e+KekPaa74Z8IjUWWJRrdtpzJqCBGDALMXO0E5yAMYJ6ZoUHpcLn0H+0vBLP+138IVjRmJ/swgAemoSE/kOaqfF//k+TwR/100//ANCavIbr9sDx/ff2HPdWXhubVtHZDFq0mnZvJFUgshk3fKr4w3lhCQTyM1yfiT49+JPFHxW0r4kXllpKa5prQtFBDFILZvKJK7lMhY9ecMPwoUWFz7w+KejQfD+4+IHxV8JaPF4j8fqkNsyuQ/8AZEQgQFxGOSduHPcqw6KGz+Z2va9qfijWLzWNYvZr3U72Qyz3EzZZ2P8AIdgBwAABxXrln+1P480/4n6n4/tRpkOoapDHBeaesUhsp1jQImUMm7IxkENnJPYkHyzxb4iHizxDfaz/AGTpulNeP5j2mmRvHbqx6lVdmK5POAcc8ADinCLW4N3Ps/8AZ1vtN0z9j/x5eaxpP9r6XDe3b3Gn/aGt/tCeTBlPMX5lz6ipbi+0r4pfsceJD4H0t/B2laHcStc6WZjdLciLZO6+c4DnO9Wz1yu08V86/DX9pHxH8MfBN74PstB8Narol7cPcTxaxaST+YXVVKkCRVK4QcEetHjP9pfxd4u8HyeELbT/AA/4c8NzH97Y+H7D7NHKM5wcs2ASASFxnvmlyu4XPqnSbPw18GvgB4E1HS/GFl4Ivddgt7m615vD7arLdyyQ+Y0XH3RyQM9lwMHJrxf9oXxX8L/HGq+BtX8HataX/ipLmODV5rTTJrJLofLiUo6gA7g2BljhsEnArznwT+0f4u8GeFB4UmtND8Q+GkOYtO8QWP2qKLnOFG5TjJzgkgdsVgeN/i/rXjq60Z7rTtD0600aRprSx0mwS1gRmKliQvJz5a9T24xQotO4XPrP9sj4weIvhp470W18LGzsNQvNJ3XOotZxTTvEZZAsQMisFUEMeACS3XgVl+Bf+E6+FPwj8I6j4l+NFj4N8NX8Qk0zTR4dj1JzHJmUBiFD5IfceTjcBkdK+Y/jB8ZNd+Nmv2Wta/aabbXVnai0RNPjdEKB2fJDuxzlz39OK6bS/wBp/wAaaf4I07wpcWfh/VLTS1VdPutU05bi4stowhjLHblRwCVJAo5HZIL6n1H8Y1Hw9+P3wY8QeFxb6ff+LbhNM1WWC0RBeQG4tg2UYHazCQjP3gABnivNP21viv4vsvHGreAoNX2eE7uytpJbH7NCdzZD58wpvHzKp4btXjHxI/aJ8X/E+98JX+ppp1pf+FnMllc2MciuZCYzvfe7gsDEp4x3qx8S/wBo3XPivoslj4g8L+EDfyLGn9swaay36qjBgFlLnaDyCAMYJ6ZoUWrXBs8dooorQQUUUUAFFFFABRRRQAUUUUAd38ev+SseIP8At3/9J46KPj1/yVjxB/27/wDpPHRWuN/3ip/if5ly+JknwJdj8W9BG44zccZ/6YSVwFd98Cf+SuaD9bj/ANESVwNU/wDd4/4pflET+FBXtv7Q4/s/XPD2h23yaXp2mJ9mg6+Xl2Q/MfmPyxIOSenuc+JV7b+0n/yPWn/9gyP/ANGy1vQ/3ar6x/UF8LPL1G1QB0AxVS9b5lX0GauVQu2zMR6DFclX4SafxEFFFFcx0H6yeAbu38I/CHwfJ4hni0eOw0Wxium1Fxbi3fyY02uXxtO47cHHPHWu0s7y31C0gu7SeK4tLiNZYZoXDpIjDKsrDgggggjrVLxD4e0vxXot7outWUV7pd7H5c9vKOGHUcjkEEAhhgggEEEA189/8Kd+Nfgn/iVeAfibayeGk5t4tcjDz2yj5ViUmGXKKioBtKLndhF7+Mkp3u7M9Ntx6XPoTU/EejaLd2FpqWrWFld6jJ5VpDc3CRvcvkDbGrEFzllGBn7w9a068O8BfA/XG8S2vjD4o+Jv+Ep8RWfzWNmikWOnSZA82NMKpcqkZyEQBgThmCuPcaUklonccW3q0FZkHiPRrnWrnRIdWsJdatYxLPp6XCNcRIduGaMHco+deSP4h6itOvIfih8FrjxPrUXi/wAGa9L4X8cQR7HvYAfK1BFwUiuFH3huRBuIb5RhlcBQqik3Zuw5NpaHr1Zmh+I9G8T2j3eiatYapaJIYmmsbhJ0VwASpZCQDhgce49a+e/+FZftD6//AMS7XvinpdjpU/8ArrjSocXKY+ZdhSGJuWABxIvBPXofcfAXgLQ/ht4atdA0C18iyg+Z3cgy3EhA3SyNgbnOBzwAAAAAABUoxit7smMm3sfkbeWdxp13cWd5by293byNFNBMhR43U4ZWU8ggggg9KhrtPjB/yVrx7/2Hr/8A9KHri69hO6ueY1Z2J7RsTAeoxV+s2BtsyH3xWlXTSehhVWp3HwIvZ7L4nafBBJtiu454JhgHegjZwOenzIp49PrXB+MLC30vxbr1jaR+Xa2t/PDEmSdqLIwUZPJwAOtdp8E/+SraJ9bj/wBESVyfj/8A5HzxR/2FLr/0a1dk9cJH/E/yQ/sHO0UVtweFr248LXHiKN4DZ29x9nkj3HzRwvz4xjbl0Gc5yw4riIMSiuj1XwRq+lz6TbeT9ru9TthdRW9orSSKCSCrLj7wKnIGcVkx6PqM2oHTo7C6fUASptVhYy5HUbMZz+FAFKitCDQdVuryezg0y9lvIATLAkDtJGB13KBkfjV698MS2/iuPw/DOkk8k0UCSyKUXc+3GQMkAFvegDBorp08JW763pulR+INPuZry8js3FrFOWh3MFLESRoCAT0B/wAax00XUJ5I1trK6nE0rQxGOFm8116quByQCDgetAXKFFakXhnW57qa1i0fUJLqBgkkKWzl0YgkArjIJAJ59DUdnoOq6hNLDaaZe3E0LiORIYGdkbn5SAOD8rcf7J9KAM+irraPqK6cuotYXQ09m2i6MLeUT6b8Yz+NWf8AhGtUinhhu7G6szPE80ZuLaQeYqIWJACkkYHUDA6kgZIAMmiitzwv4VvvF13dWmntAJ4LdrjbKxXzMFQEXAOWJYAA4GT1oAw6K3LLwnqOox6W1sInbUpJo40L7SnlBS7OTgKoDZznoDnFRapokWnQiWHWNNvwGCMtq77lOD2dFyOOq5HvyKAMiitvxD4Vv/DKac16YSL6BZ08pidmQCUbIGHAKkjnG4Voat8PtV0bWbnS7iS1MsFm975sbsY5I0Ultp25yCrLggcg/WiwXOUorqp/BlvBpA1QeJ9GktHkeFCiXeXkRVYqAYBg4deTgc9etVJvCN7BrWs6S0tubnSUmkmYM2xhEMttOMn2yB+FAXMCiujfwXfxQtcTTW0NmlpFdtcyMwjHmJuSP7uTIem0A9z0BNc5QAUUUUhhRRRQAUUUUAFFFFABRRRQB3vx5dh8V/EADED/AEfv/wBO8dFN+PX/ACVjxB/27/8ApPHRWuM/3ip/if5ly+Jj/gT/AMlc0H63H/oiSuBrv/gSF/4W3oPJzm47f9MJK4Cqf+7x/wAUvyiJ/Cgr2z45n+1dP8DeJZvlvtW0wedGnEa4CSfKDyOZm6k8Ae+fE69qvD/wlP7Pmn3Q+e68N3xglmueX8tjgJG3J24lhGDgfu/9kZ2wvvU6tPyv9z/yuEdmjzFCSik9SBWfO26ZyfXFW7VsxY7qaos25ix6k5rjqvRBTWrEoorp/hvq1noHxE8I6tqM3k6fp+rWlzcS7S2yNJkZmwoJOACcAE1zt2Rstz9d6Khs7y31G0t7yzuIri0uI1lhnhcOkiMMqysOCCCCCOtTV4Z6wUUV5j4g8K/ELSNZvNT8D+JrG4tb998ui+JhLNbwSN96SGZCZEHyqBD9wbnIx8oFRV+om7Hp1FeS2nhX4peKbqCPxl4m0fSdGgdXltPCYnjmvxndte4kIeEAqv8AqsFlZwSODXrVElbqCdwoooqRn5K/GD/krXj3/sPX/wD6UPXF16p+0j4i0vxX8a/Feq6LexX2myyQRx3MJykhjgjjYqf4huRgGHBxkEgg15XXtw+FHlT+Jiq21gw6g5rVrJrQkk/0fccZZf510UnuYVVsek/s9adFqHxE+0ys4ksLSW4j2kAMxKx88dMSMeMcgfSvK9Y1ObW9Wv8AU7hUWe9nkuJFjBChnYsQMknGT61698MT/wAI38M/HvilvlkeIafbTQcTwyEYyG42rumiPBz8mcZAz4pXbX93D04d7v79F+QPSKQV23h7xZZaH4etbaeAX2b24a5sWJQSwvFGo+fBA+ZMjryo4riaK4yLHpTeL7HV9OW3vNS+zX99ps0E92Y3KwytfPOVbaCdrIQCVBxuA9RUMviLS7m61Cx/tJo1n0iDTl1V4nw7xsjEsAC+xghTpnAXI6ivO6KLiselah4h0nVdPuNJTWjayRLZf8TKSKXF35COrAhQXGC425HRBnbxjM1PxBp9z8UodbS7eTTV1CCdrh0YMUUpuYrjOeDxXEUUXHY9GuNbtI/FWialNreg3Nnb6pFcONO0xreWOMSBizkW8ZYADpljntUVx4lsb7WLLU7fUIrFTBJZyWM8EjQQIUKnbsGRG4Yk4+cMSefvHz6ii4WPUlOkXPh3xLDZaz9jtHk06NpyJ2g8wLOSi5Bk8vjIyCcgduaydf8AFVnfWfiiO1u5d1/PYKpZWVrlIYpFeRvTc21sE5y3sa4hbmZIJLdZZFglZXeMMQrMudpI6EjccemT61FRcVj0+98Y6VNpnn2p06G4k06KweJort7ldqKpwPMEG3cu4Hg/7Ocktk8QaIuoJqE2pQy39wL1p3tI51iYyWzqpdJBxIXYD5PlANeZUUXCxq6Hd/ZDqP8AxMPsXm2csX+p8zz84/df7O7+92xVzwrq8WkR6473DQTz2Bit2UHJl82JhgjpwpOT6Vz1FA7Hqt1420Fzok6NIv2uK/TU4YoiDavcxrGzJnAI3BnAB6HbxWdps3hiysINM1LVNOvrc3sMwntdOZZY4V3tIrSNGrkvlVAywHqAK87oouKx33iPxZo3ifQ9UX7PeWeom/Oow/abkXAkaT5ZY12xJsGAh5z9zH12rjxtol/d+LVubptpS7fSp/Kc+Z50ZRoiMZAJ2sM4AIb+9Xk9FFwsb82pWr+CbLThLm8i1Ke4aPaeEaKFVOcY5KNxnPFdNqeu6M2p+JPEEOpLLPrNtLHHYCGQSxSTYDb2I2bVy2CrEnjgdvOqKLjseja14n0jxLpGmaJd3fkx6fYQ/ZbxY32xziJRJFIoGWUlQA4BIIHVennNFFAJWCiiikMKKKKACiiigAooooAKKKKAO7+PX/JWPEH/AG7/APpPHRTvjyF/4Wv4gyTn/R+3/TvHRWuM/wB4qf4n+ZcviYvwJ/5K5oP1uP8A0RJXA133wJ/5K5oP1uP/AERJXA1T/wB3j/il+URP4UFez/AHWbe7n13wXfyzra6/ausRRz8jhGDhVwQGZCTuP/PIDnivGKs6ff3Gl39rfWknl3VrKs0T4B2upBU4PBwQOtGGrexqqp/VuoouzuXrq1uNIv7yxuk8q6tneGVMg7XUkEZGQeQRxVCvX/i7pa+J9M0j4iaTbP8AYtUgVL9V3MLeZfk5JwcZHl5Chcxg9XFeQVGLpeyqcm63T7p7M0jG1woqW3h85yC21FUszYzgD2p/l2f/AD+/+QjXKU2kfUH7Mn7Tdn4A09PB3jF/K8OReZJY6hFCXa0ZiXaORUBZ0ZixDAFlZsHKkFPvCzvLfUbS3vLO4iuLS4jWWGeFw6SIwyrKw4IIIII61+N/l2f/AD+/+QjXp3w0+PXi34VbING8RfaNJXP/ABK9Qhea1Gd5+Vcho/mcsfLZdxxuz0rkrYXnfNHc6KWJUdJbH6kUV5l8Ifi6/wAW9CstWs/DF7b2s8ksU1zHeWs0Fu6Z+Vv3izAkbTgxA/OD90hj6gYnBxtP5VwypTjujrjVhLZjKKd5bn+E/lXFfEnx9L8ONC1LWJ/D97eafY2huHu1urWG3V+QsbGSUPkttHyo5O8BQzfLSjTnLZDlUhHdnZ18bftJ/tT6Xd6JfeDfAt3Fftfxy2upaoEzFHEco8UW4YcsM5kGVCkbSS25PGvil+014t+Jv2my/tn+xdAl3J/Z2nI6eZGd42yy/ekyj7WHCNtB2A14v5dn/wA/v/kI13UcJyvmmclXFJ6RK9FWPLs/+f3/AMhGmzwLGsbxyeZFIDhsY6Hniuw5rpkNTPIWijXPQVDXp/wX8LLfa3J4m1NHj8P+H1a8luCjFTKg3Ko2nJK/fOAfugEfMK6MLSdWoqcev9XFKPMbXxWu/wDhDvhz4U8CK06XzxLfXyGX7mSxMZ2ja6mVnI5OPKXrkGvDq2vFviO48XeJNS1q5XbJeSlwmQfLQDCJkAZ2qFGcc4yeaxa3xVZVal47LRei2MpO7CiirFtbeb+8kyIgcZHVj6D/AB7fkDzkleitLFuOBaxkDuzNk/XBFL+4/wCfSL/vp/8A4qnyi5jMorT/AHH/AD6Rf99P/wDFUfuP+fSL/vp//iqOUOYzKK0/3H/PpF/30/8A8VR+4/59Iv8Avp//AIqjlDmMyitP9x/z6Rf99P8A/FUfuP8An0i/76f/AOKo5Q5jMorT/cf8+kX/AH0//wAVR+4/59Iv++n/APiqOUOYzKK0/wBx/wA+kX/fT/8AxVH7j/n0i/76f/4qjlDmMyitP9x/z6Rf99P/APFUfuP+fSL/AL6f/wCKo5Q5jMorT/cf8+kX/fT/APxVH7j/AJ9Iv++n/wDiqOUOYzKK0/3H/PpF/wB9P/8AFUfuP+fSL/vp/wD4qjlDmMyitP8Acf8APpF/30//AMVR+4/59Iv++n/+Ko5Q5jMorT/cf8+kX/fT/wDxVH7j/n0i/wC+n/8AiqOUOYzKK0/3H/PpF/30/wD8VR+4/wCfSL/vp/8A4qjlDmMyitP9x/z6Rf8AfT//ABVH7j/n0i/76f8A+Ko5Q5jMorT/AHH/AD6Rf99P/wDFVWuLZVUyQ7jGPvKxyV/xHv8Ah6ZGguVaKKKko7v49f8AJWPEH/bv/wCk8dFHx6/5Kx4g/wC3f/0njorXG/7xU/xP8y5fEx/wJ/5K5oP1uP8A0RJXA13/AMCXY/FvQRuOM3HGf+mElcBVP/d4/wCKX5RE/hQUUUVgSbtr4p1ODwxdeG459ulXNyt26DglwuMEjqpwpIOeUUjHOcqo4u9TwxGaVIxnLHHAzipqScmrvY1jsSTN9nsNh+/cEHHoo6H8TWdVq/mE1y23Hlx/ImDnge9VayZIUUUUgPon9kb41f8ACtfHS6JrWqfZvCGuZSb7RLtgtLnA8uc/KdudojY5UYYMxxGMfpfX4j1+lH7Ifxxk+JnhGTw7rd1NP4q0CNfMuLmZGkvrcsQkgHDEp8qOSDyUYsWcgDGj6Qr4H/ba+NX9taxB8PtA1Tfpmn5fWPs0uUmuQ3ywP8vPlbdxAYjc+CA0XH0x+0h8ZIvg58Pp7y3bd4h1TfZ6XGrx7o5ShzcFXzuSPgn5WBZkU4DZH5XXt7c6leXF5eXE1zeXMjSzTzOXkldjlmZjySSSSTySaEDIKKKKBBWhZN59tLbfxg+anuQOR+VZ9S207W08cq9VOceo7imgJa1oPFOp2HhvUfD8M+NM1KWOWaNueUORtzwuTtJIGTsUZwCDQu4hDOypzGfmU9iDVWX7o+taQk4y0ZcnpoRUUUVZiFaQ4tLUDgFCx9zuYZ/ID8qza0/+XW0/65n/ANDaqiTIZRVrTNOuNX1Kz0+zjMl3eTJBEg/idiFUfmRXtvxF+HljbyaFNc6Tc+HdF0/UhoF1fSWLQ/aYVClLzkDez4mJbnovtTuSeEUV6VceEbG2t/EE9ra3dtapozXMJnuLa+SRluoYyUnRNuMOc7QrKeCcEg6nhfwh4b/t3wdcW9td6tZyX9gl5OLuCSBmlK7o5INheIByV+fcHCkDGQQXA8hor1HR/BmgeIf7e1iKC4ttLsbqK0jsbjW7S2keRxIxb7RMiIFAjOECFjnrgE1O/gLwjpZtxeX2oait5rcmlwTabdQeWIhHA4kLBXVmUz4KqcEjhlxyXA8norWk8P3TeJ38P2o8+9N6bGMAY8x9+wfma9x8T/D6G08Q+DJx4Yk0/TtP16DQJ/tNiYk1GJWQpcMGUCTzMTbjzwFHpRcD54or0T4fWNpcfFY208NkbVGvyEuoBLAmyCYqWjKsCFIBxtPToa19WXQdd0jUWtZ9NutX03RpZ7y80vTVtraZjdwLGFjeJNrBXbLoiE5AyRuyXA8kor1Dxb4L8L6RN4pg03+2Hfw1fRwztc3EWLqJpCjBcR/u2BAAY7geTtHSrnijw5oWo/FHxJY6b4cvhp9hLP8AaI49XtrOGIiQKHEjwCOKPkKEOeSMN2JcDyOivVNW+H/h7wzF4hvNTfUbq2sjprWkNndwZkW6hkkKtMquh27MB0BDYOB8wIwPhlY2UmsX2p6qkB0rSrOSed54fOWJnxDC/ldJNsssZKnggHPpRcDiqK7Dxv4X1TSimrajHpsEd9MY7cWChIrlVRCZ4lUbfLbevIwNxI2jBA7zSPCWj+KPAXhK0e3tbO8t45dUvL5I1WWWzW6ljuNzdXKKI2UHoA1FwPE6K9Z+J2i6Vew6n4isrGLTSsWiGKys0WOBBdWUksnygdd0a857nOc8b3hTw3peja7qWhzwS3mmL4l0KJop2UmQOJ+GypBXLcjHIyOM5ouB4RRXoLaHpus6V4ll0a3eyWLUbK3hi1C6t2ALi43EztHGEXKDgFR/e3YBGt4H0tNH8P8AjNru78NWt/Zz2MaX2oW0Wp26B/OLKhSKdSWwvKj+HBIxRcDyiivarDTdA/sO/wBS1iyTVDcaDcXYfTkgskVl1Tyt0X+j5XIxgsuVUsuACAvK6b4J03UdQ8GxCS8SHXbG5u5h5ilozHNcooU7em2BM5HUnpkAFxnn9Fdf4z0bQvD9vpNrYrqMmp3NhZ31xNPMnkp50CyNGqBMnlgQxbgcYP3q5CgQUUUUwCpIefNB5BifI9cKSP1AP4VHUsHWT/rlJ/6AaEBlUUUVmaHd/Hr/AJKx4g/7d/8A0njop3x5dh8V/EADED/R+/8A07x0VrjP94qf4n+ZcviYvwJ/5K5oP1uP/RElcDXffAn/AJK5oP1uP/RElcDVP/d4/wCKX5RE/hQUUUVgSSxfdP1q5C32e2muD1x5aeu4989sCqKybRjFaV1bLNFbxpdWwWJTndJzuPX8Kzad7mnMrWMiir39m/8AT3af9/P/AK1H9m/9Pdp/38/+tU8rJuUaKvf2b/092n/fz/61bNh8PfEWqWkd3Y6ZdXVrJnZNBBI6NgkHDBcHBBH4U405Sdoq4zmK7D4X/EXVvhX410zxLpM0wa2kUXNvHJsF5blgZIGJBGGA6kHaQGHKgg/4Vd4t/wCgFqP/AICS/wDxNc9/Zbf8/Nr/AN/P/rU5Upx+JWDY9D+PnxkvfjR46uNW3XcOg237nS7C4dT9niwAzELwHcrub7xHC7mCLXltX/7Lb/n5tf8Av5/9at23+Gvii7ging0a+lglUPHJHbSsrqRkEELggjvRGnOXwq4bnJ0V1lx8NfE9pBLcXGj3sMEKl5JJLaVVRQMkklcAAd6wf7N/6e7T/v5/9aiVOcfiVgKNFXv7N/6e7T/v5/8AWo/s3/p7tP8Av5/9ap5WK5IrfaLBG/jtztbPUqenP6Yqq/3DV+ytVt5WL3VsY3Qo22TnB9Kz5G2s6cHBIypyDVJMrmVrEVFFFaGYVp/8utp/1zP/AKG1ZlX7aUTxJAf9amQn+0Dzt+ucn3z9AaiSy/o2sXvh/U7fUtOm8i+tyWil2qxQkEZAIIzzwex5HNWNH8TaroEV1Fp12YI7sxmVdisGKNuU/MDgg+nYkHgkHKZSpKsCCOCD2pKok6O/8da9qKTRTXcSQTWxs2gt7WGGIRGRZCFRFCqS6KSQATjk0rePvEBtLe1W+WJIJIpRJDbxRyu0ZzGXkVQ8m08jcTiubopAdMnj/XYr+8vUlsle9VRcQjTrb7PNt5Vmh8vyywJJ3bc8nnmqdx4t1i68jzbwt9nvGv4/3afLMwQFhx0xEg29Bt4HWsWigDVs/Emp6fr39u21z5erea84uPLUkSNnLAEYB5JHHB5GMCn6H4p1bw35v9mXfkCWSGVwY0cF4pBJG2GBwQwz9CQeCQceigDRsNe1DTNVfVLW48u/cSgy7FOfMVlfgjHKuw6cZ4qKx1W702K+itZvLjv4Ps1wNoO+Per7eRx8yKcjB4+tU6KANi98VavqMusy3N35j61IJb0+Wg85g+8HgfL83Py4rSPxG8RNfSXr3No9xNB9nnZ9Pt2Fym4N+9Ux4lbKqdzhmyBzXK0UAb+seNtd1+O7j1G+89Ls25lHlIu7yEZIvuqMbVdhx1zznAqnofiDUfDd491ptwIZZI2hkDRrIksZ6o6OCrKcDhgRwKzKKAN7XfGeteJbS3tNTuo5ra1cvBElvFGsGQAVQIo2IcA7FwuecZ5rOu9WvL6y0+yuJt9tp6PHbptA8tWcuwyBk5Ziec9apUUAdLbeP/EFpLJIl5E/mW0FoyTWsMsZjgQJF8joV3IoADY3dTnJNR3HjrxDdXl7eS6lI13e3UF7NMEUM00O7y3yBwRubpjOec1z1FAG3qfi3VdWjv47iS2WK/kiluI7e0hgWR4w4RsRooB/ePkjrnnPFUbfV7y10y90yKbbZXrxyTx7Qd7R7thzjIxvboec81SooA39O8a63pQtFt7qIx2ls9nHFNbRSxmF5DIyMjqVcF2LfMDzj0FWtL+I3iTRrVLaxvooo4zJ5R+yQs8QkzvVGKFkRsnKqQvJ4rlqKALmpard6vNDNezebJDBFbIdoXEcaBEXgDoqgZ6nHOap0UUwCiiigAqWDrJ/1yk/9ANRU6Z/siOrAid1KhT1QHqT9RkY98+mQZm0UUVmWd38ev8AkrHiD/t3/wDSeOij49f8lY8Qf9u//pPHRWuN/wB4qf4n+ZcviZJ8CQv/AAtvQeTnNx2/6YSVwFd98Cf+SuaD9bj/ANESVwNU/wDd4/4pflET+FBRRRWBIUUUUAFFFFABVmw1C70u7ju7G6ntbqPOyaCQo65BBww5GQSPxqtRTTs7oDvLD40eO9OtI7aHxDO0cecGeKOZzkk8u6lj17n26V1f/DTPi3/oHaJ/35l/+O14xRXTDG4iGim/vKU5Lqez/wDDTPi3/oHaJ/35l/8Ajtc5qHxz8d6h9qX+2vs8NxuHl29vGnlq2eEbbvGAeDu3D1zzXndFOWOxMtHN/eHPLuXdT1jUdbnW41O/ur2dVCLJdTNKwXJOAWJOMk8e5qlRRXK227skKKKKQBRRRQAUUUUAFFFFAFhb66RQq3MwUDAAc4Apf7Qu/wDn6n/7+Gq1FO7FYs/2hd/8/U//AH8NH9oXf/P1P/38NVqKLsLFn+0Lv/n6n/7+Gj+0Lv8A5+p/+/hqtRRdhYs/2hd/8/U//fw0f2hd/wDP1P8A9/DVaii7CxZ/tC7/AOfqf/v4aP7Qu/8An6n/AO/hqtRRdhYs/wBoXf8Az9T/APfw0f2hd/8AP1P/AN/DVaii7CxZ/tC7/wCfqf8A7+Gj+0Lv/n6n/wC/hqtRRdhYs/2hd/8AP1P/AN/DR/aF3/z9T/8Afw1WoouwsWf7Qu/+fqf/AL+Gj+0Lv/n6n/7+Gq1FF2Fiz/aF3/z9T/8Afw0f2hd/8/U//fw1WoouwsWf7Qu/+fqf/v4aP7Qu/wDn6n/7+Gq1FF2Fiz/aF3/z9T/9/DR/aF3/AM/U/wD38NVqKLsLFn+0Lv8A5+p/+/ho/tC7/wCfqf8A7+Gq1FF2Fiz/AGhd/wDP1P8A9/DVaiii4BRRRSGd78eQv/C1/EGSc/6P2/6d46Kb8ev+SseIP+3f/wBJ46K1xn+8VP8AE/zLl8TML4e+I18JePNG1eVo1t4LnbM8iswSJwUkbC8khGYjGeQOD0o8a+HW8J+LNX0ZlcJaTssXmMrM0R+aNiV4yUKnt16DpXLyf6x/qa9E0vxPoPinQtM8PeKmk0+501GjtPEEatOyRZ3CCWLq6DLBSp+X5QABuJdKSnB0m7O91+q+emu2glqrHC0V6IPgr4nvf3miPpWvWg+VrrS9QieJH7oSxU7gCD06MKP+FFeP/wDoAf8Ak5B/8XV/VK/SD+5i5ZdjzuivRP8AhRXj/wD6AH/k5B/8XR/worx//wBAD/ycg/8Ai6PqeI/59y+5hyS7HndFeif8KK8f/wDQA/8AJyD/AOLo/wCFFeP/APoAf+TkH/xdH1PEf8+5fcw5JdjzuivRP+FFeP8A/oAf+TkH/wAXR/worx//ANAD/wAnIP8A4uj6niP+fcvuYckux53RXon/AAorx/8A9AD/AMnIP/i6P+FFeP8A/oAf+TkH/wAXR9TxH/PuX3MOSXY87or0T/hRXj//AKAH/k5B/wDF0f8ACivH/wD0AP8Aycg/+Lo+p4j/AJ9y+5hyS7HndFeif8KK8f8A/QA/8nIP/i6P+FFeP/8AoAf+TkH/AMXR9TxH/PuX3MOSXY87or0T/hRXj/8A6AH/AJOQf/F0f8KK8f8A/QA/8nIP/i6PqeI/59y+5hyS7HndFeif8KK8f/8AQA/8nIP/AIuj/hRXj/8A6AH/AJOQf/F0fU8R/wA+5fcw5JdjzuivRP8AhRXj/wD6AH/k5B/8XR/worx//wBAD/ycg/8Ai6PqeI/59y+5hyS7HndFeif8KK8f/wDQA/8AJyD/AOLo/wCFFeP/APoAf+TkH/xdH1PEf8+5fcw5JdjzuivRP+FFeP8A/oAf+TkH/wAXR/worx//ANAD/wAnIP8A4uj6niP+fcvuYckux53RXon/AAorx/8A9AD/AMnIP/i6P+FFeP8A/oAf+TkH/wAXR9TxH/PuX3MOSXY87or0T/hRXj//AKAH/k5B/wDF0f8ACivH/wD0AP8Aycg/+Lo+p4j/AJ9y+5hyS7HndFeif8KK8f8A/QA/8nIP/i6P+FFeP/8AoAf+TkH/AMXR9TxH/PuX3MOSXY87or0T/hRXj/8A6AH/AJOQf/F0f8KK8f8A/QA/8nIP/i6PqeI/59y+5hyS7HndFeif8KK8f/8AQA/8nIP/AIuj/hRXj/8A6AH/AJOQf/F0fU8R/wA+5fcw5JdjzuivRP8AhRXj/wD6AH/k5B/8XR/worx//wBAD/ycg/8Ai6PqeI/59y+5hyS7HndFeif8KK8f/wDQA/8AJyD/AOLo/wCFFeP/APoAf+TkH/xdH1PEf8+5fcw5JdjzuivRP+FFeP8A/oAf+TkH/wAXR/worx//ANAD/wAnIP8A4uj6niP+fcvuYckux53RXon/AAorx/8A9AD/AMnIP/i6P+FFeP8A/oAf+TkH/wAXR9TxH/PuX3MOSXY87or0T/hRXj//AKAH/k5B/wDF0f8ACivH/wD0AP8Aycg/+Lo+p4j/AJ9y+5hyS7HndFeif8KK8f8A/QA/8nIP/i6P+FFeP/8AoAf+TkH/AMXR9TxH/PuX3MOSXY87or0T/hRXj/8A6AH/AJOQf/F0f8KK8f8A/QA/8nIP/i6PqeI/59y+5hyS7HndFeif8KK8f/8AQA/8nIP/AIuj/hRXj/8A6AH/AJOQf/F0fU8R/wA+5fcw5Jdjzut7wV4dbxZ4s0jRlVyl3Oqy+WyqyxD5pGBbjIQMe/ToeldMfgr4nsv3mtvpWg2h+VbrVNQiSJ37ICpY7iAT06Kaq6p4n0HwtoWp+HvCrSahc6kix3fiCRWgZ4s7jBFF1RDhQxY/N8wII2kNUHTfNXVkuj3flbfXvshqNtzB+I/iNfFvjjXNXiaNree4KwvGrKHiQBI2w3IJRVJzjkngdKK5eiuOpNzk5y3eoN31JJJHDsAzdT3pvmP/AH2/OiipEHmP/fb86cJH2MdzdR3+tFFADfMf++350eY/99vzoooAPMf++3506SRw7AM3U96KKAG+Y/8Afb86PMf++350UUAOEj7GO5uo7/Wm+Y/99vzoooAPMf8Avt+dHmP/AH2/OiigB0kjh2AZup703zH/AL7fnRRQAeY/99vzpwkfYx3N1Hf60UUAN8x/77fnR5j/AN9vzoooAPMf++3506SRw7AM3U96KKAG+Y/99vzo8x/77fnRRQA4SPsY7m6jv9ab5j/32/OiigA8x/77fnR5j/32/OiigB0kjh2AZup703zH/vt+dFFAB5j/AN9vzpwkfYx3N1Hf60UUAN8x/wC+350eY/8Afb86KKADzH/vt+dOkkcOwDN1PeiigBvmP/fb86PMf++350UUAOEj7GO5uo7/AFpvmP8A32/OiigA8x/77fnR5j/32/OiigB0kjh2AZup703zH/vt+dFFAB5j/wB9vzpwkfYx3N1Hf60UUAN8x/77fnR5j/32/OiigA8x/wC+3506SRw7AM3U96KKAG+Y/wDfb86PMf8Avt+dFFADhI+xjubqO/1pvmP/AH2/OiigA8x/77fnRRRQB//Z",
	"panik": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4lkkcOwDN1Pem+Y/99vzok/1j/U16dPPD8K4LWzs7VB46C77y+kxKtkrgFYolI2FimNzYONzAMc/LVfEOm4wguaUtlttu2+iWl3Z7rRtmmHw6qKU5y5Yx3e++yS6t62V1s9UkYum/CnxvqsDTQaFdoitsIuWWBs4B+7IVJHPXGPyq6Pgv492n/iStnI/5fIP/AIuuT1HVb/V51n1G9ubyZV2CS4laRguScZYnjJPHvVSsvZY56+0gv+3G/wAedfkbe0wC09nN/wDb8V+HI/zZ23/Cl/H3/QFb/wADIP8A4uj/AIUv4+/6Arf+BkH/AMXXE0Uexx3/AD9h/wCAP/5YHtcB/wA+p/8Agcf/AJWdt/wpfx9/0BW/8DIP/i6V/gv49LNjRWxnj/TIP/i64iij2OO/5+w/8Af/AMsD2uA/59T/APA4/wDys7b/AIUv4+/6Arf+BkH/AMXR/wAKX8ff9AVv/AyD/wCLriaKPY47/n7D/wAAf/ywPa4D/n1P/wADj/8AKztx8F/Hu0/8SVs5H/L5B/8AF0n/AApfx9/0BW/8DIP/AIuuJoo9jjv+fsP/AAB//LA9rgP+fU//AAOP/wArO2/4Uv4+/wCgK3/gZB/8XR/wpfx9/wBAVv8AwMg/+LriaKPY47/n7D/wB/8AywPa4D/n1P8A8Dj/APKzt3+C/j0s2NFbGeP9Mg/+LpP+FL+Pv+gK3/gZB/8AF1xNFHscd/z9h/4A/wD5YHtcB/z6n/4HH/5Wdt/wpfx9/wBAVv8AwMg/+LpR8F/Hu0/8SVs5H/L5B/8AF1xFFHscd/z9h/4A/wD5YHtcB/z6n/4HH/5Wdt/wpfx9/wBAVv8AwMg/+Lo/4Uv4+/6Arf8AgZB/8XXE0Uexx3/P2H/gD/8Alge1wH/Pqf8A4HH/AOVnbf8ACl/H3/QFb/wMg/8Ai6V/gv49LNjRWxnj/TIP/i64iij2OO/5+w/8Af8A8sD2uA/59T/8Dj/8rO2/4Uv4+/6Arf8AgZB/8XR/wpfx9/0BW/8AAyD/AOLriaKPY47/AJ+w/wDAH/8ALA9rgP8An1P/AMDj/wDKztx8F/Hu0/8AElbOR/y+Qf8AxdJ/wpfx9/0BW/8AAyD/AOLriaKPY47/AJ+w/wDAH/8ALA9rgP8An1P/AMDj/wDKztv+FL+Pv+gK3/gZB/8AF0f8KX8ff9AVv/AyD/4uuJoo9jjv+fsP/AH/APLA9rgP+fU//A4//Kzt3+C/j0s2NFbGeP8ATIP/AIuk/wCFL+Pv+gK3/gZB/wDF1xNFHscd/wA/Yf8AgD/+WB7XAf8APqf/AIHH/wCVnbf8KX8ff9AVv/AyD/4ulHwX8e7T/wASVs5H/L5B/wDF1xFFHscd/wA/Yf8AgD/+WB7XAf8APqf/AIHH/wCVnbf8KX8ff9AVv/AyD/4uj/hS/j7/AKArf+BkH/xdcTRR7HHf8/Yf+AP/AOWB7XAf8+p/+Bx/+Vnbf8KX8ff9AVv/AAMg/wDi6V/gv49LNjRWxnj/AEyD/wCLriKKPY47/n7D/wAAf/ywPa4D/n1P/wADj/8AKztv+FL+Pv8AoCt/4GQf/F0f8KX8ff8AQFb/AMDIP/i64mij2OO/5+w/8Af/AMsD2uA/59T/APA4/wDys7cfBfx7tP8AxJWzkf8AL5B/8XSf8KX8ff8AQFb/AMDIP/i64mij2OO/5+w/8Af/AMsD2uA/59T/APA4/wDys7b/AIUv4+/6Arf+BkH/AMXR/wAKX8ff9AVv/AyD/wCLriaKPY47/n7D/wAAf/ywPa4D/n1P/wADj/8AKzt3+C/j0s2NFbGeP9Mg/wDi6T/hS/j7/oCt/wCBkH/xdcTRR7HHf8/Yf+AP/wCWB7XAf8+p/wDgcf8A5Wdt/wAKX8ff9AVv/AyD/wCLpR8F/Hu0/wDElbOR/wAvkH/xdcRRR7HHf8/Yf+AP/wCWB7XAf8+p/wDgcf8A5Wdt/wAKX8ff9AVv/AyD/wCLo/4Uv4+/6Arf+BkH/wAXXE0Uexx3/P2H/gD/APlge1wH/Pqf/gcf/lZ23/Cl/H3/AEBW/wDAyD/4ulf4L+PSzY0VsZ4/0yD/AOLriKKPY47/AJ+w/wDAH/8ALA9rgP8An1P/AMDj/wDKztv+FL+Pv+gK3/gZB/8AF0f8KX8ff9AVv/AyD/4uuJoo9jjv+fsP/AH/APLA9rgP+fU//A4//Kzq9R+FXjbSrYTT6FdurOFAtmWduhP3YyxA464x0rivMf8Avt+daunarf6RO0+nXtzZzMuwyW8rRsVyDjKkcZA49q7mCeH4qQXVneWqHx0V32d9HiJb1UBLRSqBsDBM7WwM7VBYY+aZ1cRhlz4i0o9XFNW82m3ourvpva21Ro4fEvkw94y6KTTv5JpLV9FbXa97X8x8x/77fnRTaK7zzjtvhTpsWq/ErQoJmdUS4a4BQgHdErSKOR0ygz7Z6VgarqMur6pe6jOqLNeTPO6xghQzMWIGSeMmus+C4X/haOi8nOZ+3/TCSuIripa46pfpCH4ud/yR31NMBTt1nP8ACMLfm/vPoj4JeJvCeleFnglvLPT9WEhN291IsRn5OwqzHlQvGB0OTj5sn0z/AITjwv8A9DJo/wD4HRf/ABVfFdFeJjeEqOLxE68qsk5O/f8Apduy0PdwXF1bCYeFCNKLUVbqv6ffu9T7U/4Tjwv/ANDJo/8A4HRf/FUf8Jx4X/6GTR//AAOi/wDiq+K6K5f9SaH/AD9f3I6v9d6//Ppfez7U/wCE48L/APQyaP8A+B0X/wAVR/wnHhf/AKGTR/8AwOi/+Kr4roo/1Jof8/X9yD/Xev8A8+l97PtT/hOPC/8A0Mmj/wDgdF/8VR/wnHhf/oZNH/8AA6L/AOKr4roo/wBSaH/P1/cg/wBd6/8Az6X3s+1P+E48L/8AQyaP/wCB0X/xVH/CceF/+hk0f/wOi/8Aiq+K6KP9SaH/AD9f3IP9d6//AD6X3s+1P+E48L/9DJo//gdF/wDFUf8ACceF/wDoZNH/APA6L/4qviuij/Umh/z9f3IP9d6//Ppfez7U/wCE48L/APQyaP8A+B0X/wAVR/wnHhf/AKGTR/8AwOi/+Kr4roo/1Jof8/X9yD/Xev8A8+l97PtT/hOPC/8A0Mmj/wDgdF/8VR/wnHhf/oZNH/8AA6L/AOKr4roo/wBSaH/P1/cg/wBd6/8Az6X3s+1P+E48L/8AQyaP/wCB0X/xVH/CceF/+hk0f/wOi/8Aiq+K6KP9SaH/AD9f3IP9d6//AD6X3s+1P+E48L/9DJo//gdF/wDFUf8ACceF/wDoZNH/APA6L/4qviuij/Umh/z9f3IP9d6//Ppfez7U/wCE48L/APQyaP8A+B0X/wAVR/wnHhf/AKGTR/8AwOi/+Kr4roo/1Jof8/X9yD/Xev8A8+l97PtT/hOPC/8A0Mmj/wDgdF/8VR/wnHhf/oZNH/8AA6L/AOKr4roo/wBSaH/P1/cg/wBd6/8Az6X3s+1P+E48L/8AQyaP/wCB0X/xVH/CceF/+hk0f/wOi/8Aiq+K6KP9SaH/AD9f3IP9d6//AD6X3s+1P+E48L/9DJo//gdF/wDFUf8ACceF/wDoZNH/APA6L/4qviuij/Umh/z9f3IP9d6//Ppfez7U/wCE48L/APQyaP8A+B0X/wAVR/wnHhf/AKGTR/8AwOi/+Kr4roo/1Jof8/X9yD/Xev8A8+l97PtT/hOPC/8A0Mmj/wDgdF/8VR/wnHhf/oZNH/8AA6L/AOKr4roo/wBSaH/P1/cg/wBd6/8Az6X3s+1P+E48L/8AQyaP/wCB0X/xVH/CceF/+hk0f/wOi/8Aiq+K6KP9SaH/AD9f3IP9d6//AD6X3s+1P+E48L/9DJo//gdF/wDFUf8ACceF/wDoZNH/APA6L/4qviuij/Umh/z9f3IP9d6//Ppfez7U/wCE48L/APQyaP8A+B0X/wAVR/wnHhf/AKGTR/8AwOi/+Kr4roo/1Jof8/X9yD/Xev8A8+l97PtT/hOPC/8A0Mmj/wDgdF/8VR/wnHhf/oZNH/8AA6L/AOKr4roo/wBSaH/P1/cg/wBd6/8Az6X3s+1P+E48L/8AQyaP/wCB0X/xVH/CceF/+hk0f/wOi/8Aiq+K6KP9SaH/AD9f3IP9d6//AD6X3s+1P+E48L/9DJo//gdF/wDFUf8ACceF/wDoZNH/APA6L/4qviuij/Umh/z9f3IP9d6//Ppfez7U/wCE48L/APQyaP8A+B0X/wAVR/wnHhf/AKGTR/8AwOi/+Kr4roo/1Jof8/X9yD/Xev8A8+l97PtT/hOPC/8A0Mmj/wDgdF/8VR/wnHhf/oZNH/8AA6L/AOKr4roo/wBSaH/P1/cg/wBd6/8Az6X3s+1P+E48L/8AQyaP/wCB0X/xVH/CceF/+hk0f/wOi/8Aiq+K6KP9SaH/AD9f3IP9d6//AD6X3s+o/ij4t8HX3gvULefULDUppFItYraZZZEnwdjjaflAPJPAxkc5wfmfStRl0jVLLUYFRprOZJ0WQEqWVgwBwRxkVUor6DKsop5dQlQjJyUn1+7Y+ezXN6mY1415RUXFdPv3Oo+LWmxaV8RvEEELOyPOLglyCd0qLIw4HTLnHtjrRV342Bf+Fna5knP7jt/0wjorTLJOWCoye7jH8kYZpFRxtaMdlOX5sX4L/wDJUtF+tx/6Ikria7b4L/8AJUtF+tx/6IkriadH/fqv+CH51B1f9wpf45/+k0wooor0TzwooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAoorc0jSLZrT+0tS842JkaGKK3cLJPIoUsNxDBFUOpJIOdwAH3mWZzUF/Wv9f8F6FQg5uy/wCG/r/gLUw6K7D+0NK/6FfSv+/t3/8AH6P7Q0r/AKFfSv8Av7d//H6z9pU/59v/AMl/+SNfZU/+fi/8m/8AkTj6K7D+0NK/6FfSv+/t3/8AH6P7Q0r/AKFfSv8Av7d//H6PaVP+fb/8l/8Akg9lT/5+L/yb/wCROPorsP7Q0r/oV9K/7+3f/wAfo/tDSv8AoV9K/wC/t3/8fo9pU/59v/yX/wCSD2VP/n4v/Jv/AJE4+iuw/tDSv+hX0r/v7d//AB+j+0NK/wChX0r/AL+3f/x+j2lT/n2//Jf/AJIPZU/+fi/8m/8AkTj6K7D+0NK/6FfSv+/t3/8AH6P7Q0r/AKFfSv8Av7d//H6PaVP+fb/8l/8Akg9lT/5+L/yb/wCROPorsP7Q0r/oV9K/7+3f/wAfo/tDSv8AoV9K/wC/t3/8fo9pU/59v/yX/wCSD2VP/n4v/Jv/AJE4+iuw/tDSv+hX0r/v7d//AB+j+0NK/wChX0r/AL+3f/x+j2lT/n2//Jf/AJIPZU/+fi/8m/8AkTj6K67+ztP8RSJa2Ngun6pKwS3SGV2gmYnhCJCzKzE4DbtvCgqAS45GrhU5m01Zro/+BcidPlSad0+q/wCDYKK2dK0qB7X+0NQ802RkaGOKBwskzgAt8xBChQykkg5yAB1K6f2zTP8AoXNN/wC/tz/8eolUUXY4J4tRlaMXL0t+rX9eZydFdZ9s0z/oXNN/7+3P/wAeo+2aZ/0Lmm/9/bn/AOPVPtokfXP+ncv/ACX/AOSOTorrPtmmf9C5pv8A39uf/j1H2zTP+hc03/v7c/8Ax6j20Q+uf9O5f+S//JHJ0V1n2zTP+hc03/v7c/8Ax6j7Zpn/AELmm/8Af25/+PUe2iH1z/p3L/yX/wCSOTorrPtmmf8AQuab/wB/bn/49R9s0z/oXNN/7+3P/wAeo9tEPrn/AE7l/wCS/wDyRydFdZ9s0z/oXNN/7+3P/wAeqlqOl2t1az32nRvD9nAe5tnfcFUsFDoxGdu5gu05YZBy2WKuNWLdioYtNpSi1fvb9GzAooorQ7Ds/jb/AMlO13/th/6Ijoo+Nv8AyU7Xf+2H/oiOivMyr/caH+CP5I9HNv8Af6/+OX/pTH/Bf/kqWi/W4/8ARElcTXb/AAXdj8UdFG44zPxn/phJXEVVH/fqv+CH51BVf9wpf45/+k0wooor0TzwooooAKKkgglup44II3lmlYIkcalmdicAADqSe1esQfC3SPB1lBqnjzU/L8zmLS7L5pJSAG2lvzU4wASvzjNceLx9HC2U3eUtkldv0X9I7MJgK2Ku6atGO7bsl6v+meZaPomo+IL1LLTLOa7uWx8kS52jIG5j0VckZJwBnk16JZfArWEto73XtT03RbEZ85ppd7w84XOMIcnb/H/F68U+/wDi7cafCuneDtOttD02NgVKxrJNNgFdz5BGSoXP3myv3jXCX13qWsTLPqN5cXUqqEElzK0jBck4BJJxyePeuS2ZYl3VqMf/AAKX/wAivxOz/hNwys71pf8AgMf/AJJ/gehDwb8MNN/0XUvGN5cXsf8ArJbKPMTZ5G3bG46EA/Mec9OgX+2vhD/0K2r/APf1v/j9ebizXHLEn2p4to8fd/Wr/saUtauIqN/4uX8IpfrYn+2Ix0pYeml/h5vxk3+l+p6L/bXwh/6FbV/+/rf/AB+kPhz4U6rza+I9S0+5uv8AVRToTHbs3RWJjxtUnBy/Qfe71539mi/u/qaYbRccMwPvR/YzjrTr1E/8V/8A0pMP7YUtKlCm1/ht/wCktHoNx8DL28hkufDmv6VrNrGpBZH2MZAM+WMFlzjb1YdecDmvP9f8L6x4WuRb6vp81pI33C4yj8Ana4yrY3DOCcZwaW1e80y5S5sbmWC4jzslhco65GDgjkcEj8a7fSPjBrNtCbHXre317S2VVa2vY13EKOPmwcnO0kuGJ29jzUOGZ4Z3Uo1Y9muWXyfwv52+RXPlmJVnGVGXdPmj80/eXyv8zzCivYF+HvhX4gJLN4J1F7C/jXfJpeobiFXIXIb5iBwScF+WUfLmvKtU0u80XULjT9Qt3t7y3bZJE/UH+oI5BHBBBHFdWEzCjiZOnG8ZreLVmvl281deZyYvL62GiqkrSg9pJ3i/n38nZ+RUooortOIKKKKACuw1D/kB+F/+vB//AEruK4+uvvSJNA8Muh3IlpLCzDkK4uZmKn/aCuhx1w6nuKxqfxKfr/7bI3pfw6np/wC3RK+l2X9panZWXmeX9pmSHfjO3cwGcd+tdlP8OYpdX1PRtN1ZrnV7BC5gmtvKWYAAkIwdsnkcECuQ0a8j07WNPvJQxitriOVggySFYE49+K7x/HujWHiXVfEmnRX8+pXaFYIriJI44CQBuJDsW6dMDrXFmE8ZGpbDXtyu2is5XVrtrRWvfVfeduXwwcqd8Ta/Mr6u6jZ3sk9Xe1tH9xzkHhOGDQLTWtX1BrO2vZGjt44oPOkfbwWILKAoPvn2rXtPhjNL4hbTJ9RRLZrE38N3FFvEseRjCkjB59e1Uf8AhJdN1fwxp2jawt5FJpsjNBc2qLJuRjkqysy4Pvnt0resviZYL4kW7mtLqLS7fTDptvHGFeQDIwzZIHbsfSuWvUzNKfs739/orJX9y2mra3vfre2h10KWWNw9pa3udXdu3v310Se1rdLX1OXufCSS+H31zSb1r2zhlEM6SQ+VLExxtJUMwIOQMg9603+H0Ftq9pod5rKw65copEIty0SMwyqNJuyCfZSOarP4psdK8L3Gh6Mt1I15Ok1xd3SKh+QgqqorNjkA5J9fw1Ljxroeo+JbLxPd21+upQKjPaxKhikkQYVg5bKjgcbT061U6mYa2vy+9Z2XM9Fy3VtE3zdF0vYiFPL9L25vdurvlWr5rO+rS5er62uZln4AuTp+p31/JcQx6fdGzkjtLb7RJvAyTjcoCjI5z3pmj+D7HV4teul1aVbHSYklMi2mXlBByNhcYIIx1q1pfjdoNQv9TfVdU0+9vLlpnSzhSWFlOMAq7LyORnnjFbMfxL06TVPFN35d9p51eKKOCW0VWkiKggufnXk5zwfxqKtXM486SvtayWmsbqzi76c1mm/S9i6NLLJcjbtve7eukrO6kra8t00vW1zCufh1dnWNE0+wukuF1iAXMMkieUUTGTvXJxgehNRDwXbX8GrHR9WN7c6Uhkmikt/KDov3mjO47se4FbE/xKht9b8PajaQT3UumQtDcXN3hZbsMMc4LYxyRyeTVG08U6N4fj1yXRor6S71SJoEFyiIlsjHJwQxLnpjgdKcauZ8quneytorN8zvzaaLls1t166BKllnM7NWu76u6XKrcuur5rrr06akNv4R0e58N3evLrN+LS1mWB0Onp5hY46DzsY5HeuTS3NzeLb2m+UySeXFldrPk4HGTgnjjJ+tdFZeJbS28B6loLxzm8urtJ0cKPLCjbwTnOeD2qt4L1bT9B8Q2upalDNNDa5kSOFQSZMfLnJGADzn2Fd1KWKpwrTneTTfKtNVZW2S3dzgqxwtSdGELRTS5nro7u+7eysanjf4fP4Ot7S4TUEvopXaGVkj2CKQAHaeTnjPp0rM8ZeF/wDhEdXSw+1/at0KTeZ5ez72eMZPpW3P4+tdX8P65pup6ekMt7L9rgktN7AXGfmZvMkOAQAPl6c8VmeP/Etp4q1xL6zjnjhW3SIiZQGyuc9CeOa58DPMPaQp4npzXdlr8Li9PVrTtqdGOhl/s51MN15bK70+JSWvonr30OWp3jj/AJHXxJ/2Ebn/ANGtSwwyXM0cMMbyTSMEREUlmYnAAA6kmovGM8V14u1+eCRJYZb+4dJI2DK6mRiCCOoI716VT+PH0l+cTzYfwJeq/KRpXn/IG8Of9eT/APpTPVKGGS5mjhhRpJZGCIijJYk4AFXLkh9D8Pup3IlrJEzDkBxcSsVPvtdDj0YHuKf4f1T+w9d03UjH5gs7hJin94KwOKwn8TPBTajNxV3eX5s764+A3iiDSTeBrOS4Vd5s0kJk+gONpPtn8a8507T7jVNQtrC2Tdc3MixRqeMsTgfSvqi4+MnhGHSjfJqQlfZlbVUYSlv7uMcfXp718xWOvT6f4jh1uJE8+K5+0hP4c7t236dqhHkZVi8dXjU+sQs1tdW110OrT4awXWt3fh+z1xZ9ftkZjAbYrDI6jLIsm7JI56qBxUKfDS5m8Bf8JRBd75ULmSxMWGVEcqzBs844JGBgH2rTt/Hnh/TfFd74ss7XUG1SdXaOzlVBDFK4wzGQNlhyeNo69ah074lx6Zofhy2jhnku9Pup5bxXVfKnilLbkHPOQ3cdaNSnPH2jyf3b3S7PmXpeyv57sVfhRu8TNov9r/d0z+0fO+zfT5Nu/wB+ufwrnPBPhL/hMdTurL7Z9l8i1kud/l7923Hy4yOuetd0/wAUdCPjqfWUtdQTTn0o6eqeWhkVs9cb8Yx75rnfBviTQPBusXF5HPqd5FcWU1uwazjiZWYrtI/etkcHPTHHXsDhVxvspcyfNyq2i31v0t23+RFF8N7i68AL4qtr0SuC7PZeVhljRyrOG3c44J46GtGL4UK/ik6I2sFVGmjUTOLXJxx8m3f79c/hUWk/EeDRvD3hmxt4J3uNMuZnukdV8qeGQncg5ycg9x1rd/4Wpoa+PJdcit9RisDpf2FFWNPNRsjBxvxgAeuaNSKlTME5qK0962i7+6vu1Xe+ux5ZqUWmRGP+zru7uAc7zc2qw7fTG2R89/SpdC/4+rr/AK8Lz/0mkqz4k1NdTe3ca3q2qsgILalHtMY4wF/evnPOenTvVbRCEmvZWO2NLC73OeAu6B0XJ7ZZlUepYDqaqO6PTk28O772f9bL8jkKKKK7T3Ds/jb/AMlO13/th/6Ijop3xsdh8TtcAYgfuO//AEwjorzMq/3Gh/gj+SPRzb/f6/8Ajl/6Uxfgv/yVLRfrcf8AoiSuJrtvgv8A8lS0X63H/oiSuJqqP+/Vf8EPzqCq/wC4Uv8AHP8A9JphRRRXonnhWv4a8Naj4s1eHTNMh8y4k5Zm4SJB1dj2UZ/kBkkCqel6Xea1qFvp+n273F5cNsjiTqT/AEAHJJ4ABJ4r1/xJq0Xwo0KLwroQRNeu4Ul1PUY3DMrEfcU8EHrjIG1SCPmYsPOx2MnTlHD4dJ1ZbX2S6yfkvxeh6OBwcKkZYjENqlHe27fSK83+C1C81rQPhHBqGleG2e/8USKsVxqUyqUgOPmVR6gjO3kZI3M2zbXmF9d3uu39xqGoXDzXVw2+SV+rH29ABwAOAAAKrwW4IDt07CrLyLGMsfw9a2wWXU8LepJ803vJ7v8AyXZLQzxuYVMTanFcsFtFbL/N929QSNYxhR/9eh5Ej+8wFUpLp34Hyj261BXY6qWxyKl3LxvIwcfMfcCmfbf+mf61UoqHVkV7OJb+2/8ATP8AWni8Q4yGFUaKPaSD2cTTSVH+6wJ9KcyhxhgCKyqljuHj4zlfQ1aq9yXS7FhUms5o7i2lkSWJg6OhIdGByCCO4Nenad440b4gafb6F483rdLNm21eAJGY89Q5xhQcBc4KkEEgFd1ebRTLKMg89xUc9uGy68HuPWuXGZfSxaUnpJbSW69H+a2fU6cHj6uEbS1i94vZ+q/J7roaHjfwRqPgbVzZXo8y3ky1tdKuEnQd/ZhkZXt7ggnma9g+H/ie18U2MfgXxQv2iwuPlsbpnCyW0gB2qGP5L1OTtwVOB5t4l8Naj4T1ebTNTh8u4j5Vl5SVD0dT3U4/mDggiuXBYupzvCYq3tIq9+kl/Ml0810fkzox2Ep8ixeFv7OTtbrF/wArf5PqvNGRRRRXpnmBWvpOtLZRNaXsD3enO3meSsnlvG+AN6OVbaSAAeCGAGRkKVyKKmcFNWZUJuDvE6zzvC//AEE9Y/8ABZF/8kUed4X/AOgnrH/gsi/+SK5Ois/ZVP8An4//ACX/AORNfa0/+fa/8m/+SOs87wv/ANBPWP8AwWRf/JFHneF/+gnrH/gsi/8AkiuToo9lU/5+P/yX/wCRD2tP/n2v/Jv/AJI6zzvC/wD0E9Y/8FkX/wAkUed4X/6Cesf+CyL/AOSK5Oij2VT/AJ+P/wAl/wDkQ9rT/wCfa/8AJv8A5I6zzvC//QT1j/wWRf8AyRR53hf/AKCesf8Agsi/+SK5Oij2VT/n4/8AyX/5EPa0/wDn2v8Ayb/5I6zzvC//AEE9Y/8ABZF/8kUed4X/AOgnrH/gsi/+SK5Oij2VT/n4/wDyX/5EPa0/+fa/8m/+SOs87wv/ANBPWP8AwWRf/JFHneF/+gnrH/gsi/8AkiuToo9lU/5+P/yX/wCRD2tP/n2v/Jv/AJI6zzvC/wD0E9Y/8FkX/wAkUed4X/6Cesf+CyL/AOSK5Oij2VT/AJ+P/wAl/wDkQ9rT/wCfa/8AJv8A5I6ebXNO0tS2i/bJb4/cvbpFiMH+5Gpb5xjhy/GThQwVhzFFFXCmo63u31f9fgtDOdRz0tZLov6/F6mpperrZxtbXcLXNgzb/KWTY6Pj7yMQdpOADwQQBkZCldTz/Dv/AEENV/8ABfH/APH65eiiVOMtWcdTCxlLmTa9LfqmdR5/h3/oIar/AOC+P/4/R5/h3/oIar/4L4//AI/XL0UvZRI+p/33+H+R1Hn+Hf8AoIar/wCC+P8A+P0ef4d/6CGq/wDgvj/+P1y9FHsoh9T/AL7/AA/yOo8/w7/0ENV/8F8f/wAfo8/w7/0ENV/8F8f/AMfrl6KPZRD6n/ff4f5HUef4d/6CGq/+C+P/AOP0ef4d/wCghqv/AIL4/wD4/XL0UeyiH1P++/w/yOo8/wAO/wDQQ1X/AMF8f/x+qGpaxC0D2emxyxWr486SVgZLjB4zjhVyA2wE89WbC4xqKapxTuVDCxi1KTbt3t+iX4hRRRVnUdn8bf8Akp2u/wDbD/0RHRR8bf8Akp2u/wDbD/0RHRXmZV/uND/BH8kejm3+/wBf/HL/ANKZJ8Fwv/C0dF5Ocz9v+mElcRXbfBf/AJKlov1uP/RElcTVUf8Afqv+CH51BVf9wpf45/8ApNMKKK6LwN4Wl8Y+JrHSkDiF233EiZ/dxLyxzg4OOASMbio7121qsKNOVWo7KKu/kcdGjOtUjSpq7k7L5noXg23sfhv4K/4S++ghk8RahuTS4LgsMR8DeFxkZBLFs4KlQGG858wUy3k8lzcu8skjF3eRizOxOSST1Oa634neJI/Evic21gUXR9MX7JZxxYEYVeGZQCVwSOCMZVU9K5pVCKFHQVxZTh5crxVb46mr8l9mPyW/m2d+a4iPNHC0fgp6Lzf2pfN7eSQkjiNCx/8A11mu7SMWY81PePlwgPA6/Wq1d9SV3Y4KcbK4UUUVmaBRRRQAUUUUAFFFFACqxUgg4IrRhlEqZ43dxWbU1q+yUDPDcVpTlZ2M5xuia5h/jUfWvVcW3xY8By70RvGegw/uyrM0t3AuOSMEuTyMckPg5UPg+aEZGD0rQ8HeI5fBniiy1JC5gRts6L/y0hbhhjIye4ycblB7Vx5phJVqaq0f4kNY+vVPyktGdmV4qFGo6Vb+HPSXp0a84vVHI0V3PxV8LReHPE7z2IRtH1RftdnJFgx7W5ZVIAXAJ4AzhWTnmuGrfC4iGJoxrQ2kr/8AA+RzYrDzw1aVGe8Xb/g/MKKK9w+AX7PUXxt03xPfz+KP7Cg0ARNIfsBuvMV1kJPEiEYEfvnNbt21ZgeH0V9Fj9l7T/FPgvWPEvw1+IVn4vTSAWurRtNlsZgAu7Cq7EkkAkZABwQDmvnSkmnsAUUUUwCiux+F/g7SvHfjC10TWvFFl4Y0+aOR21O9CGKMqpIU7nQckY+93716N8Kv2dbT4qfErxb4SsPGUCWWhCR4dWt7MXEd6iyhAyqJQAGB3Ahm/HrScktwseEUVLcw/Z7maHdu8tymcYzg4qKmAUV7d8OP2el8W/DrUfiF4l8WWnhfwlZy+T9pe0ku5HbcqZ8tCDjc4Uck5zxjmvN/HXhnTPCutLaaP4lsPEenywrNFfWSOgwSRtdHGUcbclTngj1pXT0A5miivpzU/wBlrwn4W8E+FvFHiz4rjRbbxFbwywI3h+WcK8kQk2bo5T0B+8QBx2obS3A+Y6K9f+Nv7P8Aq3wZXSL9tUtNa8PawubPUrVSoY4DAMpJxlTkYJBGeeK8gpp31QBRRRQAUV6Vrvw18P6T8KNF8Y23j3S77XdQmWKfw3EI/tNop8z52xKWwNi9UH3x+PmtCdwCiiigAooooAKKKKACiiigAooooAKKKKAO1+NgX/hZ2uZJz+47f9MI6Kb8bf8Akp2u/wDbD/0RHRXmZV/uND/BH8kejm3+/wBf/HL/ANKY/wCC/wDyVLRfrcf+iJK4mu2+C/8AyVLRfrcf+iJK4mqo/wC/Vf8ABD86gqv+4Uv8c/8A0mmFeyfC108MfD3xd4rVv9NGLOBliVnhbC7Wyeql5UJH/TPvwK8br1/xuP7F+E3gbRv9d9r3X/nfd25BfZt5z/x8Yzn+HpzxhnC9sqWE/wCfklf/AAx95/lb/PY6MnfsXVxf/PuLt/il7q/O/wDlueZ2iZLOR04FW6jgXbEvTnmpK95bHiMgkgjeTLMQzdqT7HH6t+dR3rfMi9wM11Xwt1Tw7YePvD1x4xWV/DkF2kl15cSy8Dld6EHfHuC7wASU3AAnFYylFN3RrGMmlZn0L8Ef2QdL8ceC4PEni3UdWs/7S/eWVrZbYnWEEgPIZI2zv4ZdoxtwcndhfSv+GGPh3/0GfFP/AIFW/wD8Yr6O0fVrPX9IsNW06bztP1CCO5t5dpXfG6hlbDAEZBBwQDV2vEniKjk3ex60aEEkrXPmT/hhj4d/9BnxT/4FW/8A8Yo/4YY+Hf8A0GfFP/gVb/8Axivpuip9vU7lexh2PmT/AIYY+Hf/AEGfFP8A4FW//wAYo/4YY+Hf/QZ8U/8AgVb/APxivpuij29TuHsYdjxr4e/sufDrwD/aOdN/t/7b5f8AyMEFvd+Rs3f6v90Nu7dz67V9K7C7+FXw1srSe5l8AeGmjgjaRhDoUMrkAZO1FjLMeOAoJPQAmu2XAYZ6VJuT2/KumlWk46yXzOWtSipaJ/I/Mr9o/VPAHiTxxp938PYbGHRU02OKVbCwNnGZxLKWJQouTtKfNjpgZ4rx9baNZFwzbhzivqH9p34jfCPxh4Rtz4EOlyeJpdWW5u7i30h7aeSIxy72aVol3ZdkJBJJPPbNfLFo377nJLA16cXHRWOFqVm7l6q92mUDY5H8qsU113oy8cjvW7Mkek6s6eLPgZa3szf6b4duVg8x4lyyZVAikdF2SR5Pcx8g9a8ar2D4KD+1R4r8Of6v+1dOb/SOvlYyn3e/+uz1H3ffjx+vByxexr4jCraMuZek1e33pnt5m/bUMPinvKPK/WDtf7nEK+2/2EI4pvCPxVjnm8iB4rZZJdpby1MdxlsDk4HOK+JK9Q+FPx38R/B/SvEem6HZaVcQa+iJctfRSOyBVdRs2SKBxIeoPQV601dWR460Z7l8P/in8LP2dfAniy38K+Lbzxn4k11VWMrpUtlDGVVxHuEvYGRiSCSeBgda3fAv/CdfCn4R+EdR8S/Gix8G+Gr+ISaZpo8Ox6k5jkzKAxCh8kPuPJxuAyOlfEFe06X+0/400/wRp3hS4s/D+qWmlqq6fdappy3FxZbRhDGWO3KjgEqSBScB3PY/2zPCej6R43+Gmu6dZ28F7rW4XclvB5IuDG8JVynZj5p684AB6V6h8efijqvgf9of4baVo9tYRnVltYL+5ltUkmmt5Lpk8kOwJRRl2+XBJYZzgCvjj4o/tAeKPi3N4Xm1610uOXw5v+zvaxyKZS3lkmTdI2T+6XpjqfwPH/x/8S/Ebx94d8aarY6RDqmgeT9mitIpFhfypjKu8NIzH5jg4YcenWlyPS4XPrKLw7pvh79u+yXTLSK1jvtIku5Y4VCqZGhkVmAHAJ2An1JJ71X/AGc/+TrvjV/11uv/AErFfNVx+094uufi1afEt9O0Ma7a2ZskgEEv2YoQwyV83dn5z/FjpxVTwX+0d4q8C/EHxR4307T9Gl1XxG0jXUVzDK0Cb5PMOwLIGHI7seKXI7Bc+gvjdLefs+fCXTNI+Gdof7F8Sgyal4vgcPLcO2cIGX7m4E7T0AyF53Gvh7rXrfgz9ojxT4O8Iax4Rey0fXPDWqMzPp+sQySxw7iSwj2SIVBPPU4IyMHJPkzsHdmChATkKucD2GeauKtuJn6LQ3/gT9n3wf4H+GPiOxlvvDfjS3mfU9UuJSYEmZYwTj+FCWH3SNgCtycmvMfHf7NPg74MfDb4i694kMOqyTSpB4WmNzIkqF1+XcqMFdgWJOQQRETgA4ryDw/+1D4w0jwrY+GtT0zw34n0vTwos08Q6d9qa2CjChTuHQcAnJA46Va8WftW+MfHfhPUfDPibSPDWqaddtviMtk6SWZAwphMci7SvJBIY8kEkHFQoyTHdHhVfoP8avD3hDxF8AvhHF4w8ZnwtZRWdm8U66ZLemdvsigptjOV45yeK/PivUPiD8d/EfxJ8FeGfCWq2WlQ6d4dSNLWS0ikWVwkQjG8tIwPyjsBz+VXJNtCR6/8aPjj4V8aL8M/Afgo3VzoPhy7tM6hdxmMymMLFGFU4OAu4kkDJI44ruP2l4JZ/wBrv4QrGjMT/ZhAA9NQkJ/Ic18Mo7RuroxV1OQwOCDXvt1+2B4/vv7DnurLw3Nq2jshi1aTTs3kiqQWQybvlV8YbywhIJ5GaXLbYdz3v4g+KfBng/8AbLTUvHCQf2YNDijt57iEyx21wfuSMoB7B1zjgsDxjIz/AIv6P4x8cfDHxbq+lfETwh4+8N2cZmmRNMgiutPjUh/3Tx5wyqP4iCVz3OK+dNa/aN8Wa58RpvHM9joQ1K4sl0+e0Nl5tpNACDtaOVmPJA5BHTtVrxF+0z4q1rwjqPhbTdF8LeGtI1MFb1PD+mC1NyDwQx3HqODgAkcdKXI9AuevfE3/AJMW+HP/AGEY/wCd1XaftB/EzVfhh8NfgzqWgwWK6zJYr5d7dWqTtDGsEBdEDghd+Vyw+bC4BGTXyfrvxu8QeIPhRovw2ubPS00LSJlngniikFyzDzOGYuVI/et0UdBR8Svjd4g+Kfh/wtomsWelwWvhqEwWr2cUiu6lETLlnYE4jXoB1NHI+oXPsH4x/Dbwx4p/aa+Eov8ATrZINctria/jCBVumgRpUDj+LJwpz1HHpRp/xS1rUf2w7bwFPpen/wDCN6S0sVjALJFksitmz+ckgG4bslcZ27XxjPNfLPi/9oHxR8UvGPgvVNWudN8P3OgTKlvqGmwS/wCjqzpmVlZ3L7ducDGRkYOa+q/DfxNt7HxVaeMPGfxK+FjWFlA6yTeHYidV1JdhVEmBBkVQSH2J3UDGKlppajufJn7UX/JffHP/AF+L/wCikryKu0+LnjOD4h/EvxN4mtYXhtNSu2khST7wjACpu9CVUEj1NcXWsdkSFFFFMAooooAKKKKACiiigDs/jb/yU7Xf+2H/AKIjoo+Nv/JTtd/7Yf8AoiOivMyr/caH+CP5I9HNv9/r/wCOX/pTJPgu7H4o6KNxxmfjP/TCSuIrtvgv/wAlS0X63H/oiSuJqqP+/Vf8EPzqCq/7hS/xz/8ASaYV7D8dh9g1nQtGt/k02w05fs8PXZlmU/MeT8saDknp7mvHq9h/aC/5HOx/7Byf+jJayxWuY4ZeVT8o/wCb+83wmmXYl+dP85f5L7jztRtUAdAMVUvW+ZV9BmrlULtszEegxXs1fhPIp/EQUUUVzHQfrj8K7O4074YeCrO8t5be7t9FsopoJkKPG6wIGVlPIIIIIPSvmHwbZXP7XvxL1+PXfE91p3g/Sh59potvKsc8keXSJ1jO5Ny7sySHcQXVBgMu37BvdRtdOjD3U6RKegPU/QdT1r8/vH/wj8UfD7xzPqngD+0p9OknZtOudFMwubUSbh5JAJlyq5XfyGBGTlio8/COPM29H0PRrUK0qalCLa9Drfhf4u1v4I/G8/Da48QjXfDTXw0vbbsZIo5JG/dtGpbELiSTEqgkA+YDvZVNfb1fEf7Ov7OviKTxdpfirxVpcumaTpji6t7a7BjnuJ1JCfICGjCOofLgbsKAGViR9uVOLcHP3fmTh1JR94K+Ufjf4u1v4hfGPSvhBpPiEeHdLmKQX91KxjFxJLEXKEhsyKY3VFjO0PI+05+Uj6ur5N/ag+AGt+J9dPjTwpZfbppYAuo2UbHzmaNDtmQM3z5RVTYgDZVcBizYnCuKqe8OupOHunEfFXwxqP7JvxA0m48E+KpZ7HUoxctpt1MGkIj+UrcxptV42LPsfCkfOBhk3n7X8Pa3b+JdA0rWrRJUtdTtYruJJgA6pIgdQwBIBwRnBP1r869H+E/j74h+LS3iZNWspJXjF9quupKZUTbgHEnzykKoUAf7IJUHI/Q3w22j2ulWel6M6LZafAltBBuYskaKFUfN8xAGBk5+ta4xxdrasMNQrKDm4vl720PyAvLO4067uLO8t5be7t5GimgmQo8bqcMrKeQQQQQelQ12nxg/5K149/7D1/8A+lD1xddyd1c89qzsT2jYmA9Rir9ZsDbZkPvitKumk9DCqtTr/gvdzWfxFsYYX2x3KTQyjAO5AjOB7fMinj0rifFVlBpvijW7K1Ty7a2vZoYkyTtRZCAMnk8DvXX/AAg/5KZpH1n/APRMlcv44/5HXxJ/2Ebn/wBGtXjx0zaaXWnH/wBKketPXKYN9Kkv/SYmDRRW3B4WvbjwtceIo3gNnb3H2eSPcfNHC/PjGNuXQZznLDivXPHMSiuj1XwRq+lz6TbeT9ru9TthdRW9orSSKCSCrLj7wKnIGcVkx6PqM2oHTo7C6fUASptVhYy5HUbMZz+FAFKitCDQdVuryezg0y9lvIATLAkDtJGB13KBkfjV698MS2/iuPw/DOkk8k0UCSyKUXc+3GQMkAFvegDBorp08JW763pulR+INPuZry8js3FrFOWh3MFLESRoCAT0B/xrHTRdQnkjW2srqcTStDEY4WbzXXqq4HJAIOB60BcoUVqReGdbnuprWLR9QkuoGCSQpbOXRiCQCuMgkAnn0NR2eg6rqE0sNppl7cTQuI5EhgZ2RuflIA4Pytx/sn0oAz6Kuto+orpy6i1hdDT2baLowt5RPpvxjP41Z/4RrVIp4YbuxurMzxPNGbi2kHmKiFiQApJGB1AwOpIGSADJoorW0DQX16W8UXlrZxWdubmWa537VQMq9EVmJyw7UAZNFdVbeAdRvPEFppENzZN9qt/tUV4ZGFuYcE7ySu4DgjBUHPGKrad4M1PU7PXbiIRK+iAG4gkYiRvvbgoxglQjE8jgHrRYLnPUVvDwlem2M/m2+wad/aeNzZ8rzPLx0+9nt0x3qXVPBd/oq6k97NbRRWMxtxIWbFzIMZWIbctgHJJAA7kEgEC5zlFFFIYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB2vxsdh8TtcAYgfuO//TCOim/G3/kp2u/9sP8A0RHRXmZV/uND/BH8kejm3+/1/wDHL/0pj/gv/wAlS0X63H/oiSuJrt/guF/4WjovJzmft/0wkriKqj/v1X/BD86gqv8AuFL/ABz/APSaYV7B8ZT/AGnY+DPEE3y3uqacPNROI1wEf5QeRzK3UngD8fH69euj/wAJJ8C7G5Hz3Ph+9MMstxy+wnAWM8nbiWIYOB8nsM45j+7xOGr9FJxf/byaX4pG+W/vMNiaHVxUl/2603+DZ56hJRSepArPnbdM5Prirdq2Ysd1NUWbcxY9Sc17FV6I8qmtWJRRXT/DfVrPQPiJ4R1bUZvJ0/T9WtLm4l2ltkaTIzNhQScAE4AJrnbsjZbn6b+MdPu11GS7ZHe1ZVCuMkJgAYPpzz+P1rn7W0nvZhFbxPLIeyjp2yfQc9a9as7y31G0t7yzuIri0uI1lhnhcOkiMMqysOCCCCCOtTV4vNY+so5tKnSUOW9iGzjkhtLeOZ98qRqrtnO5gOTk1g+KvHWjeD1QahO7XMi70toV3SMucZ7ADr1Izg4yRXSV85fGmwvbfxk9zcM72t1ChtiSxVVUAMgzwCGyxA/vg96huxll2Ghi8RyVHZav18j1/wALfEjQvFlx9ltJZYL07itvcoFZwACSpBIPU8ZzwTjAzXXV8sfDawvb/wAa6QLJnRoZhNK6lgFiXl8kdAR8vPBLAHrX1PQncrNcHTwtVRpvRq/oeTanp93YXTrdo+9mJ8w5Ik9SD36/rzV3w1p93c6nbTQI6xRSBnl5CgDGRn1IOMe/pXplFXzGks3lKnycuv8AXQ/JX4wf8la8e/8AYev/AP0oeuLr1T9pHxFpfiv41+K9V0W9ivtNlkgjjuYTlJDHBHGxU/xDcjAMODjIJBBryuvZh8KPk5/ExVbawYdQc1q1k1oSSf6PuOMsv866KT3MKq2O/wDgVYR33jv7RKzh7K1lnTaRgsSI+eOmJD0xzivM9V1GXV9UvdRnVFmvJnndYwQoZmLEDJPGTXqnw7P/AAj/AMPPG3iRvlkaIWNvLDxPFIRjIPG1d0sR4OfkzjgZ8gryMJ+9x+IrdFywXyXM/wAZI9XGfusBh6PV80383yr8IsK7bw94sstD8PWttPAL7N7cNc2LEoJYXijUfPggfMmR15UcVxNFewePY9KbxfY6vpy295qX2a/vtNmgnuzG5WGVr55yrbQTtZCASoONwHqKhl8RaXc3WoWP9pNGs+kQacuqvE+HeNkYlgAX2MEKdM4C5HUV53RRcVj0rUPEOk6rp9xpKa0bWSJbL/iZSRS4u/IR1YEKC4wXG3I6IM7eMZmp+INPufilDraXbyaauoQTtcOjBiilNzFcZzweK4iii47Ho1xrdpH4q0TUptb0G5s7fVIrhxp2mNbyxxiQMWci3jLAAdMsc9qiuPEtjfaxZanb6hFYqYJLOSxngkaCBChU7dgyI3DEnHzhiTz94+fUUXCx6kp0i58O+JYbLWfsdo8mnRtORO0HmBZyUXIMnl8ZGQTkDtzWTr/iqzvrPxRHa3cu6/nsFUsrK1ykMUivI3puba2Cc5b2NcQtzMkElussiwSsrvGGIVmXO0kdCRuOPTJ9aiouKx6fe+MdKm0zz7U6dDcSadFYPE0V29yu1FU4HmCDbuXcDwf9nOSWyeINEXUE1CbUoZb+4F6072kc6xMZLZ1Uukg4kLsB8nygGvMqKLhY1dDu/sh1H/iYfYvNs5Yv9T5nn5x+6/2d397titHwdrsOgnXJpHhE0+nPDAs0CzI8hkjOCrKVPCt94Y4+lczRQOx3eneL7JtL1i41trm91LUBFZJDZutqYLZDvO0+UyKpZUG1QOh6d9PUfG+mwzarq+kzNHf6hPY3v2WVWYiVBKJlZtoVgSQT0BEmMdQPMaKLhY9M1rxH4d828TS7p/scnh/7HCjxvuSVrgSeUTjkqpxu6HHWofHvifSPGt1fytd+Vc2BYWE4jfy7qAnPllcZRwSSGwAed3ODXnNFFwsFFFFIYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB2fxt/5Kdrv/AGw/9ER0U742Bf8AhZ2uZJz+47f9MI6K8zKv9xof4I/kj0c2/wB/r/45f+lMX4L/APJUtF+tx/6Ikria7b4L/wDJUtF+tx/6Ikriaqj/AL9V/wAEPzqCq/7hS/xz/wDSaYV638ENWguZta8I3ssy22t27rEUc/K4Rg4UYIDFCTuP/PMDnivJKsWN7Ppt7bXtq/l3NtIs0T4B2upyDg8Hkd61zDCLGYedG9m9n2a1T+8zy/FvB4mFe10t13T0a+4vXFvcaVe3dncp5dzbu8UiZB2upIIyODyCOKo16p8UtNXxHp2l+PNMt3+yalCq3oXLCCZfk5JxxkbMhQMoD/EK8rqMHjPrdCNRq0tpLtJaNfJ/hqaYzCfVK0qad47xfeL1T+a/HQKKlt4fOcgttRVLM2M4A9qf5dn/AM/v/kI10nM2kfUH7Mn7Tdn4A09PB3jF/K8OReZJY6hFCXa0ZiXaORUBZ0ZixDAFlZsHKkFPvCzvLfUbS3vLO4iuLS4jWWGeFw6SIwyrKw4IIIII61+N/l2f/P7/AOQjXp3w0+PXi34VbING8RfaNJXP/Er1CF5rUZ3n5VyGj+Zyx8tl3HG7PSuSthed80dzopYlR0lsfqRUF3Z22oW7293bxXFu+N0UyB1bByMg8HkA15z8Ifi6/wAW9CstWs/DF7b2s8ksU1zHeWs0Fu6Z+Vv3izAkbTgxA/OD90hj6gYnBxtP5VwypTjujshWi9YspWGm2WlwtDY2dvaws28pBGqKWwBnAHXgflVqneW5/hP5VxXxJ8fS/DjQtS1ifw/e3mn2Nobh7tbq1ht1fkLGxklD5LbR8qOTvAUM3y0o0py2Q51Y7yZ2dfG37Sf7U+l3eiX3g3wLdxX7X8ctrqWqBMxRxHKPFFuGHLDOZBlQpG0ktuTxr4pftNeLfib9psv7Z/sXQJdyf2dpyOnmRneNssv3pMo+1hwjbQdgNeL+XZ/8/v8A5CNd1HCcr5pnHVxSekSvRVjy7P8A5/f/ACEabPAsaxvHJ5kUgOGxjoeeK7DmumQ1M8haKNc9BUNejfCTw2t5q8niHUUePQ9CVrqScqSpkQblUYOSV++cA/dAI+YVjicXDCUZVp9Ft3fRLzb0RvhsJPF1o0YdXv2XVvyS1ZrfE26/4RTwD4Z8Fq0yXrRi8vEMn3cliUO0bWUyM2OTjyx1yDXjda/ijX5/FPiDUNXuBtku5CwTIOxBwq5AGcKAM45xmsioyzCSw2HUZ/HJuUv8T1f+XyHmeLjisQ5Q+CKUY/4Vov8AP5hRRVi2tvN/eSZEQOMjqx9B/j2/IH0DzyvRWli3HAtYyB3Zmyfrgil/cf8APpF/30//AMVT5RcxmUVp/uP+fSL/AL6f/wCKo/cf8+kX/fT/APxVHKHMZlFaf7j/AJ9Iv++n/wDiqP3H/PpF/wB9P/8AFUcocxmUVp/uP+fSL/vp/wD4qj9x/wA+kX/fT/8AxVHKHMZlFaf7j/n0i/76f/4qj9x/z6Rf99P/APFUcocxmUVp/uP+fSL/AL6f/wCKo/cf8+kX/fT/APxVHKHMZlFaf7j/AJ9Iv++n/wDiqP3H/PpF/wB9P/8AFUcocxmUVp/uP+fSL/vp/wD4qj9x/wA+kX/fT/8AxVHKHMZlFaf7j/n0i/76f/4qj9x/z6Rf99P/APFUcocxmUVp/uP+fSL/AL6f/wCKo/cf8+kX/fT/APxVHKHMZlFaf7j/AJ9Iv++n/wDiqP3H/PpF/wB9P/8AFUcocxmUVp/uP+fSL/vp/wD4qj9x/wA+kX/fT/8AxVHKHMZlFaf7j/n0i/76f/4qj9x/z6Rf99P/APFUcocxmUVp/uP+fSL/AL6f/wCKqtcWyqpkh3GMfeVjkr/iPf8AD0yNBcq0UUVJR2fxt/5Kdrv/AGw/9ER0UfG3/kp2u/8AbD/0RHRXmZV/uND/AAR/JHo5t/v9f/HL/wBKY/4L/wDJUtF+tx/6Ikria7f4Lux+KOijccZn4z/0wkriKqj/AL9V/wAEPzqCq/7hS/xz/wDSaYUUUV6J55tWviXUYfDtz4fSbbptxcLdOg4JcDGCR1U/KcHPKKRjnObUcXep4YjNKkYzljjgZxWCpxg3yq13d+p0e0lOK5ne2i9CSZvs9hsP37gg49FHQ/iazqtX8wmuW248uP5Ewc8D3qrQzIKKKKQH0T+yN8av+Fa+Ol0TWtU+zeENcyk32iXbBaXOB5c5+U7c7RGxyowwZjiMY/S+vxHr9KP2Q/jjJ8TPCMnh3W7qafxVoEa+ZcXMyNJfW5YhJAOGJT5UckHkoxYs5AGNH0hXwP8AttfGr+2tYg+H2gapv0zT8vrH2aXKTXIb5YH+Xnytu4gMRufBAaLj6Y/aQ+MkXwc+H095btu8Q6pvs9LjV490cpQ5uCr53JHwT8rAsyKcBsj8rr29udSvLi8vLia5vLmRpZp5nLySuxyzMx5JJJJJ5JNCBkFFFFAgrQsm8+2ltv4wfNT3IHI/Ks+pbadraeOVeqnOPUdxTQEtacPiXUbLw/f6HDNjT9QkjlmQ88ocjGeBk7SSBk7F5xkGndxCGdlTmM/Mp7EGqsv3R9aJU4zspq9mn81qvuZqqkoJuDtdW+T0a+aIqKKK3OcK0hxaWoHAKFj7ncwz+QH5Vm1p/wDLraf9cz/6G1VEmQyirWmadcavqVnp9nGZLu8mSCJB/E7EKo/MivbfiL8PLG3k0Ka50m58O6Lp+pDQLq+ksWh+0wqFKXnIG9nxMS3PRfanck8Ior0q48I2Ntb+IJ7W1u7a1TRmuYTPcW18kjLdQxkpOibcYc52hWU8E4JB1PC/hDw3/bvg64t7a71azkv7BLycXcEkDNKV3RyQbC8QDkr8+4OFIGMgguB5DRXqOj+DNA8Q/wBvaxFBcW2l2N1FaR2NxrdpbSPI4kYt9omRECgRnCBCxz1wCanfwF4R0s24vL7UNRW81uTS4JtNuoPLEQjgcSFgrqzKZ8FVOCRwy45LgeT0VrSeH7pvE7+H7Uefem9NjGAMeY+/YPzNe4+J/h9DaeIfBk48MSafp2n69BoE/wBpsTEmoxKyFLhgygSeZibceeAo9KLgfPFFeifD6xtLj4rG2nhsjao1+Ql1AJYE2QTFS0ZVgQpAONp6dDWvqy6Drukai1rPpt1q+m6NLPeXml6attbTMbuBYwsbxJtYK7ZdEQnIGSN2S4HklFeoeLfBfhfSJvFMGm/2w7+Gr6OGdrm4ixdRNIUYLiP92wIADHcDydo6Vc8UeHNC1H4o+JLHTfDl8NPsJZ/tEcer21nDERIFDiR4BHFHyFCHPJGG7EuB5HRXqmrfD/w94Zi8Q3mpvqN1bWR01rSGzu4MyLdQySFWmVXQ7dmA6AhsHA+YEYHwysbKTWL7U9VSA6VpVnJPO88PnLEz4hhfyukm2WWMlTwQDn0ouBxVFdh438L6ppRTVtRj02CO+mMduLBQkVyqohM8SqNvltvXkYG4kbRggd5pHhLR/FHgLwlaPb2tneW8cuqXl8karLLZrdSx3G5urlFEbKD0Aai4HidFes/E7RdKvYdT8RWVjFppWLRDFZWaLHAgurKSWT5QOu6Nec9znOeN7wp4b0vRtd1LQ54JbzTF8S6FE0U7KTIHE/DZUgrluRjkZHGc0XA8Ior0FtD03WdK8Sy6NbvZLFqNlbwxahdW7AFxcbiZ2jjCLlBwCo/vbsAjW8D6Wmj+H/GbXd34atb+znsY0vtQtotTt0D+cWVCkU6ktheVH8OCRii4HlFFe1WGm6B/Yd/qWsWSaobjQbi7D6ckFkisuqeVui/0fK5GMFlyqllwAQF5XTfBOm6jqHg2ISXiQ67Y3N3MPMUtGY5rlFCnb02wJnI6k9MgAuM8/orr/GejaF4ft9JtbFdRk1O5sLO+uJp5k8lPOgWRo1QJk8sCGLcDjB+9XIUCCiiimAVJDz5oPIMT5HrhSR+oB/Co6lg6yf8AXKT/ANANCAyqKKKzNDs/jb/yU7Xf+2H/AKIjop3xsdh8TtcAYgfuO/8A0wjorzMq/wBxof4I/kj0c2/3+v8A45f+lMX4L/8AJUtF+tx/6Ikria7b4L/8lS0X63H/AKIkriaqj/v1X/BD86gqv+4Uv8c//SaYUUUV6J55LF90/WrkLfZ7aa4PXHlp67j3z2wKorJtGMVpXVss0VvGl1bBYlOd0nO49fwrNp3uacytYyKKvf2b/wBPdp/38/8ArUf2b/092n/fz/61Tysm5Roq9/Zv/T3af9/P/rVrWXgPXtStkurLT7i5tpM7JYYZHRsHBwQuDyCPwqJyjTV5uy8y4U5VHaCu/I5uuw+F/wARdW+FfjXTPEukzTBraRRc28cmwXluWBkgYkEYYDqQdpAYcqCI/wDhWvij/oDX3/gNL/8AE1hf2W3/AD82v/fz/wCtSp1IVPgafo7jnSnTtzxa9VY9D+PnxkvfjR46uNW3XcOg237nS7C4dT9niwAzELwHcrub7xHC7mCLXltX/wCy2/5+bX/v5/8AWrZg+HniO5hjng0u7lhlUOkiW8jK6kZBBC8giic401ebS9QhTnUdoJv0OXorqJ/h54jtYJJ59Lu4oYlLvJJbyKqKBkkkrwAO9Yv9m/8AT3af9/P/AK1EJxqawafoE6c6ek016lGir39m/wDT3af9/P8A61H9m/8AT3af9/P/AK1acrM7kit9osEb+O3O1s9Sp6c/piqr/cNX7K1W3lYvdWxjdCjbZOcH0rPkbazpwcEjKnINUkyuZWsRUUUVoZhWn/y62n/XM/8AobVmVftpRPEkB/1qZCf7QPO365yffP0BqJLL+jaxe+H9Tt9S06byL63JaKXarFCQRkAgjPPB7Hkc1Y0fxNqugRXUWnXZgjuzGZV2KwYo25T8wOCD6diQeCQcplKkqwII4IPakqiTo7/x1r2opNFNdxJBNbGzaC3tYYYhEZFkIVEUKpLopJABOOTSt4+8QG0t7Vb5YkgkilEkNvFHK7RnMZeRVDybTyNxOK5uikB0yeP9div7y9SWyV71VFxCNOtvs823lWaHy/LLAkndtzyeeap3Hi3WLryPNvC32e8a/j/dp8szBAWHHTESDb0G3gdaxaKANWz8Sanp+vf27bXPl6t5rzi48tSRI2csARgHkkccHkYwKfofinVvDfm/2Zd+QJZIZXBjRwXikEkbYYHBDDP0JB4JBx6KANGw17UNM1V9Utbjy79xKDLsU58xWV+CMcq7DpxniorHVbvTYr6K1m8uO/g+zXA2g7496vt5HHzIpyMHj61TooA2L3xVq+oy6zLc3fmPrUglvT5aDzmD7weB8vzc/LitI/EbxE19Jevc2j3E0H2edn0+3YXKbg371THiVsqp3OGbIHNcrRQBv6x4213X47uPUb7z0uzbmUeUi7vIRki+6oxtV2HHXPOcCqeh+INR8N3j3Wm3AhlkjaGQNGsiSxnqjo4KspwOGBHArMooA3td8Z614ltLe01O6jmtrVy8ESW8UawZABVAijYhwDsXC55xnms671a8vrLT7K4m322no8dum0Dy1Zy7DIGTlmJ5z1qlRQB0tt4/8QWkskiXkT+ZbQWjJNawyxmOBAkXyOhXcigANjd1Ock1HceOvEN1eXt5LqUjXd7dQXs0wRQzTQ7vLfIHBG5umM55zXPUUAbep+LdV1aO/juJLZYr+SKW4jt7SGBZHjDhGxGigH94+SOuec8VRt9XvLXTL3TIpttlevHJPHtB3tHu2HOMjG9uh5zzVKigDf07xrrelC0W3uojHaWz2ccU1tFLGYXkMjIyOpVwXYt8wPOPQVa0v4jeJNGtUtrG+iijjMnlH7JCzxCTO9UYoWRGycqpC8niuWooAualqt3q80M17N5skMEVsh2hcRxoEReAOiqBnqcc5qnRRTAKKKKACpYOsn/XKT/0A1FTpn+yI6sCJ3UqFPVAepP1GRj3z6ZBmbRRRWZZ2fxt/wCSna7/ANsP/REdFHxt/wCSna7/ANsP/REdFeZlX+40P8EfyR6Obf7/AF/8cv8A0pknwXC/8LR0Xk5zP2/6YSVxFdt8F/8AkqWi/W4/9ESVxNVR/wB+q/4IfnUFV/3Cl/jn/wCk0wooor0TzwooooAKKKKACrFlfXWm3KXVlczW1zHnZLC5R1yMHBHI4JH41XopNKSs9hpuLutztbL4ueNLC2S3i12Zo0zgzRxyvyc8u6lj17n2rpv+Gh/FH/Pho/8A35l/+OV5JRXnVcmwFV3nRjf0S/I9GlnOPpK0K0rerf5nrf8Aw0P4o/58NH/78y//ABysC++MvjS++0r/AGv5EU+4eXBBGvlg9lbbuGM8HOffPNcHRSp5Ll9N3jRj91/zHUzrMKitKtL77fkW9R1W/wBXnWfUb25vJlXYJLiVpGC5JxlieMk8e9VKKK9KMVFcsVZHmyk5Pmk7sKKKKYgooooAKKKKACiiigCwt9dIoVbmYKBgAOcAUv8AaF3/AM/U/wD38NVqKd2KxZ/tC7/5+p/+/ho/tC7/AOfqf/v4arUUXYWLP9oXf/P1P/38NH9oXf8Az9T/APfw1WoouwsWf7Qu/wDn6n/7+Gj+0Lv/AJ+p/wDv4arUUXYWLP8AaF3/AM/U/wD38NH9oXf/AD9T/wDfw1WoouwsWf7Qu/8An6n/AO/ho/tC7/5+p/8Av4arUUXYWLP9oXf/AD9T/wDfw0f2hd/8/U//AH8NVqKLsLFn+0Lv/n6n/wC/ho/tC7/5+p/+/hqtRRdhYs/2hd/8/U//AH8NH9oXf/P1P/38NVqKLsLFn+0Lv/n6n/7+Gj+0Lv8A5+p/+/hqtRRdhYs/2hd/8/U//fw0f2hd/wDP1P8A9/DVaii7CxZ/tC7/AOfqf/v4aP7Qu/8An6n/AO/hqtRRdhYs/wBoXf8Az9T/APfw0f2hd/8AP1P/AN/DVaii7CxZ/tC7/wCfqf8A7+Gq1FFFwCiiikM7X42Bf+Fna5knP7jt/wBMI6Kb8bf+Sna7/wBsP/REdFeZlX+40P8ABH8kejm3+/1/8cv/AEpmN4E19fC/jbSdVkZFgguNszOpYLE+UdsLySFZiPcDg9KPF+gt4Y8TappJVwlrMyx+YwZmjPKMSOMlSp7deg6Vzcn+sf6mu80zxHoviTRdO0LxKXsbjT1ZLXXI1aZkjzkQyx9WUZYKQfl+UAAbiarc1CusRFNpq0rauyu07bu13dK7d9NrNUHGtQeGk0mneLeiu7JpvZXsmm7JW13uuNorvB8IvEV38+jvpmt2w4a506+jeNX7oSxU7gMHp0YUf8KY8cf9AT/yag/+Lqv7VwPWtFeskn9z1F/ZOO6UZP0i2vvSscHRXef8KY8cf9AT/wAmoP8A4uj/AIUx44/6An/k1B/8XR/a2A/5/wAP/Ao/5h/ZOP8A+fE//AZf5HB0V3n/AApjxx/0BP8Ayag/+Lo/4Ux44/6An/k1B/8AF0f2tgP+f8P/AAKP+Yf2Tj/+fE//AAGX+RwdFd5/wpjxx/0BP/JqD/4uj/hTHjj/AKAn/k1B/wDF0f2tgP8An/D/AMCj/mH9k4//AJ8T/wDAZf5HB0V3n/CmPHH/AEBP/JqD/wCLo/4Ux44/6An/AJNQf/F0f2tgP+f8P/Ao/wCYf2Tj/wDnxP8A8Bl/kcHRXef8KY8cf9AT/wAmoP8A4uj/AIUx44/6An/k1B/8XR/a2A/5/wAP/Ao/5h/ZOP8A+fE//AZf5HB0V3n/AApjxx/0BP8Ayag/+Lo/4Ux44/6An/k1B/8AF0f2tgP+f8P/AAKP+Yf2Tj/+fE//AAGX+RwdFd5/wpjxx/0BP/JqD/4uj/hTHjj/AKAn/k1B/wDF0f2tgP8An/D/AMCj/mH9k4//AJ8T/wDAZf5HB0V3n/CmPHH/AEBP/JqD/wCLo/4Ux44/6An/AJNQf/F0f2tgP+f8P/Ao/wCYf2Tj/wDnxP8A8Bl/kcHRXef8KY8cf9AT/wAmoP8A4uj/AIUx44/6An/k1B/8XR/a2A/5/wAP/Ao/5h/ZOP8A+fE//AZf5HB0V3n/AApjxx/0BP8Ayag/+Lo/4Ux44/6An/k1B/8AF0f2tgP+f8P/AAKP+Yf2Tj/+fE//AAGX+RwdFd5/wpjxx/0BP/JqD/4uj/hTHjj/AKAn/k1B/wDF0f2tgP8An/D/AMCj/mH9k4//AJ8T/wDAZf5HB0V3n/CmPHH/AEBP/JqD/wCLo/4Ux44/6An/AJNQf/F0f2tgP+f8P/Ao/wCYf2Tj/wDnxP8A8Bl/kcHRXef8KY8cf9AT/wAmoP8A4uj/AIUx44/6An/k1B/8XR/a2A/5/wAP/Ao/5h/ZOP8A+fE//AZf5HB0V3n/AApjxx/0BP8Ayag/+Lo/4Ux44/6An/k1B/8AF0f2tgP+f8P/AAKP+Yf2Tj/+fE//AAGX+RwdFd5/wpjxx/0BP/JqD/4uj/hTHjj/AKAn/k1B/wDF0f2tgP8An/D/AMCj/mH9k4//AJ8T/wDAZf5HB0V3n/CmPHH/AEBP/JqD/wCLo/4Ux44/6An/AJNQf/F0f2tgP+f8P/Ao/wCYf2Tj/wDnxP8A8Bl/kcHRXef8KY8cf9AT/wAmoP8A4uj/AIUx44/6An/k1B/8XR/a2A/5/wAP/Ao/5h/ZOP8A+fE//AZf5HB0V3n/AApjxx/0BP8Ayag/+Lo/4Ux44/6An/k1B/8AF0f2tgP+f8P/AAKP+Yf2Tj/+fE//AAGX+RwdFd5/wpjxx/0BP/JqD/4uj/hTHjj/AKAn/k1B/wDF0f2tgP8An/D/AMCj/mH9k4//AJ8T/wDAZf5HB0V3n/CmPHH/AEBP/JqD/wCLo/4Ux44/6An/AJNQf/F0f2tgP+f8P/Ao/wCYf2Tj/wDnxP8A8Bl/kcHRXef8KY8cf9AT/wAmoP8A4uj/AIUx44/6An/k1B/8XR/a2A/5/wAP/Ao/5h/ZOP8A+fE//AZf5HB0V3n/AApjxx/0BP8Ayag/+Lo/4Ux44/6An/k1B/8AF0f2tgP+f8P/AAKP+Yf2Tj/+fE//AAGX+RwdFd5/wpjxx/0BP/JqD/4uj/hTHjj/AKAn/k1B/wDF0f2tgP8An/D/AMCj/mH9k4//AJ8T/wDAZf5HB0V3n/CmPHH/AEBP/JqD/wCLo/4Ux44/6An/AJNQf/F0f2tgP+f8P/Ao/wCYf2Tj/wDnxP8A8Bl/kcHW14Q0FvE/ibS9JCuUuplWTy2CssY5dgTxkKGPfp0PSuiPwi8RWnz6w+maJbHhbnUb6NI2fsgKljuIyenRTVXU/Eei+G9F1HQvDRe+uNQVUutckVoWePOTDFH1VThQxJ+b5gQRtIzq4+FaLhg5c8npdapebe2m9r3fTq1pTwE6ElUxkeSK1s9G/JLfXa9rLr0TxfH+vr4o8ZazqsbI0E85WFkUqGiQBEbDcglVUn3J4HSiuborqo0o0acaUNopJfI4q1WVapKrPeTbfq9SSSRw7AM3U96b5j/32/OiitTIPMf++3504SPsY7m6jv8AWiigBvmP/fb86PMf++350UUAHmP/AH2/OnSSOHYBm6nvRRQA3zH/AL7fnR5j/wB9vzoooAcJH2MdzdR3+tN8x/77fnRRQAeY/wDfb86PMf8Avt+dFFADpJHDsAzdT3pvmP8A32/OiigA8x/77fnThI+xjubqO/1oooAb5j/32/OjzH/vt+dFFAB5j/32/OnSSOHYBm6nvRRQA3zH/vt+dHmP/fb86KKAHCR9jHc3Ud/rTfMf++350UUAHmP/AH2/OjzH/vt+dFFADpJHDsAzdT3pvmP/AH2/OiigA8x/77fnThI+xjubqO/1oooAb5j/AN9vzo8x/wC+350UUAHmP/fb86dJI4dgGbqe9FFADfMf++350eY/99vzoooAcJH2MdzdR3+tN8x/77fnRRQAeY/99vzo8x/77fnRRQA6SRw7AM3U96b5j/32/OiigA8x/wC+3504SPsY7m6jv9aKKAG+Y/8Afb86PMf++350UUAHmP8A32/OnSSOHYBm6nvRRQA3zH/vt+dHmP8A32/OiigBwkfYx3N1Hf603zH/AL7fnRRQAeY/99vzooooA//Z",
	"bangga": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4lkkcOwDN1Pem+Y/99vzok/1j/U17DdXUHwVtrPT9Ps4x8SAnmX+pS4mTTlkAZYIVYbC5j27nw2N7gMwb5VisVKlKNOnHmnK9le227b6RWl3Zu7SSbaQUqaknKTsl/Vl5nP6T8E/iJrVs1xbeGr6ONXKEXbpbPnAPCysrEc9QMdeeDWgP2fPiZtP/ABTzZyP+X63/APjlcNqut6nr1wtzquo3d/cIgjWW7maVwoJIUFiTjJJx7mqNYexzN6+1pry5JP8AH2iv9yL58P8Ayy/8CX/yLPRv+Ge/iZ/0Lzf+B9v/APHKP+Ge/iZ/0Lzf+B9v/wDHK85oo9hmf/P+n/4Ll/8ALQ58P/JL/wACX/yJ6N/wz38TP+heb/wPt/8A45Sv+z58TCzY8PNjPH+nW/8A8crziij2GZ/8/wCn/wCC5f8Ay0OfD/yS/wDAl/8AIno3/DPfxM/6F5v/AAPt/wD45R/wz38TP+heb/wPt/8A45XnNFHsMz/5/wBP/wAFy/8Aloc+H/kl/wCBL/5E9HH7PnxM2n/inmzkf8v1v/8AHKT/AIZ7+Jn/AELzf+B9v/8AHK85oo9hmf8Az/p/+C5f/LQ58P8AyS/8CX/yJ6N/wz38TP8AoXm/8D7f/wCOUf8ADPfxM/6F5v8AwPt//jlec0UewzP/AJ/0/wDwXL/5aHPh/wCSX/gS/wDkT0d/2fPiYWbHh5sZ4/063/8AjlJ/wz38TP8AoXm/8D7f/wCOV5zRR7DM/wDn/T/8Fy/+Whz4f+SX/gS/+RPRv+Ge/iZ/0Lzf+B9v/wDHKUfs+fEzaf8Ainmzkf8AL9b/APxyvOKKPYZn/wA/6f8A4Ll/8tDnw/8AJL/wJf8AyJ6N/wAM9/Ez/oXm/wDA+3/+OUf8M9/Ez/oXm/8AA+3/APjlec0UewzP/n/T/wDBcv8A5aHPh/5Jf+BL/wCRPRv+Ge/iZ/0Lzf8Agfb/APxylf8AZ8+JhZseHmxnj/Trf/45XnFFHsMz/wCf9P8A8Fy/+Whz4f8Akl/4Ev8A5E9G/wCGe/iZ/wBC83/gfb//AByj/hnv4mf9C83/AIH2/wD8crzmij2GZ/8AP+n/AOC5f/LQ58P/ACS/8CX/AMiejj9nz4mbT/xTzZyP+X63/wDjlJ/wz38TP+heb/wPt/8A45XnNFHsMz/5/wBP/wAFy/8Aloc+H/kl/wCBL/5E9G/4Z7+Jn/QvN/4H2/8A8co/4Z7+Jn/QvN/4H2//AMcrzmij2GZ/8/6f/guX/wAtDnw/8kv/AAJf/Ino7/s+fEws2PDzYzx/p1v/APHKT/hnv4mf9C83/gfb/wDxyvOaKPYZn/z/AKf/AILl/wDLQ58P/JL/AMCX/wAiejf8M9/Ez/oXm/8AA+3/APjlKP2fPiZtP/FPNnI/5frf/wCOV5xRR7DM/wDn/T/8Fy/+Whz4f+SX/gS/+RPRv+Ge/iZ/0Lzf+B9v/wDHKP8Ahnv4mf8AQvN/4H2//wAcrzmij2GZ/wDP+n/4Ll/8tDnw/wDJL/wJf/Ino3/DPfxM/wCheb/wPt//AI5Sv+z58TCzY8PNjPH+nW//AMcrziij2GZ/8/6f/guX/wAtDnw/8kv/AAJf/Ino3/DPfxM/6F5v/A+3/wDjlH/DPfxM/wCheb/wPt//AI5XnNFHsMz/AOf9P/wXL/5aHPh/5Jf+BL/5E9HH7PnxM2n/AIp5s5H/AC/W/wD8cpP+Ge/iZ/0Lzf8Agfb/APxyvOaKPYZn/wA/6f8A4Ll/8tDnw/8AJL/wJf8AyJ6N/wAM9/Ez/oXm/wDA+3/+OUf8M9/Ez/oXm/8AA+3/APjlec0UewzP/n/T/wDBcv8A5aHPh/5Jf+BL/wCRPR3/AGfPiYWbHh5sZ4/063/+OUn/AAz38TP+heb/AMD7f/45XnNFHsMz/wCf9P8A8Fy/+Whz4f8Akl/4Ev8A5E9G/wCGe/iZ/wBC83/gfb//ABylH7PnxM2n/inmzkf8v1v/APHK84oo9hmf/P8Ap/8AguX/AMtDnw/8kv8AwJf/ACJ6N/wz38TP+heb/wAD7f8A+OUf8M9/Ez/oXm/8D7f/AOOV5zRR7DM/+f8AT/8ABcv/AJaHPh/5Jf8AgS/+RPRv+Ge/iZ/0Lzf+B9v/APHKV/2fPiYWbHh5sZ4/063/APjlecUUewzP/n/T/wDBcv8A5aHPh/5Jf+BL/wCRPRv+Ge/iZ/0Lzf8Agfb/APxyj/hnv4mf9C83/gfb/wDxyvOaKPYZn/z/AKf/AILl/wDLQ58P/JL/AMCX/wAidxq3wT+Iei2gnufDV9IrSBALR0uXzgnlYmZgOOpGOnqK898x/wC+351saVrep6DcNc6VqN3YXDoY2ltJmicqSCVJUg4yAcewr0m1uoPjVbXmn6hZxn4kFPMsNSixCmorGCzQTKo2BxHu2vhc7EBZQvzTOvi8GvaYrlnDrKKceXzcW5e6urUrpa2avZqFKq+WldPs9b+jSWvZW+Z495j/AN9vzoptFeocx6H8E9Jg1r4t+Gra4aRY47proGMgHdCjSqOQeCyAH2z061y2t6rNr2s6jqtysaXF/cSXMixghAzsWIAJJxk9ya7n9nwL/wALl8PcnObnt/07y15xXm0dczq36U6dvnKpf77L7jol/u8f8Uvyj/mfVn7OvjDwRovguS2nv7DStcEpN9JezLCbnLN5bKzH5lC8YHQ7jgbst7B/wsfwb/0Nugf+DGH/AOKr886K+azHgPD47FVMVKtJObvbR/0u3ZaHoUM6qUacaagtD9DP+Fj+Df8AobdA/wDBjD/8VR/wsfwb/wBDboH/AIMYf/iq/POiuL/iG2F/5/y+5G39v1P5EfoZ/wALH8G/9DboH/gxh/8AiqP+Fj+Df+ht0D/wYw//ABVfnnRR/wAQ2wv/AD/l9yD+36n8iP0M/wCFj+Df+ht0D/wYw/8AxVH/AAsfwb/0Nugf+DGH/wCKr886KP8AiG2F/wCf8vuQf2/U/kR+hn/Cx/Bv/Q26B/4MYf8A4qj/AIWP4N/6G3QP/BjD/wDFV+edFH/ENsL/AM/5fcg/t+p/Ij9DP+Fj+Df+ht0D/wAGMP8A8VR/wsfwb/0Nugf+DGH/AOKr886KP+IbYX/n/L7kH9v1P5EfoZ/wsfwb/wBDboH/AIMYf/iqP+Fj+Df+ht0D/wAGMP8A8VX550Uf8Q2wv/P+X3IP7fqfyI/Qz/hY/g3/AKG3QP8AwYw//FUf8LH8G/8AQ26B/wCDGH/4qvzzoo/4hthf+f8AL7kH9v1P5EfoZ/wsfwb/ANDboH/gxh/+Ko/4WP4N/wCht0D/AMGMP/xVfnnRR/xDbC/8/wCX3IP7fqfyI/Qz/hY/g3/obdA/8GMP/wAVR/wsfwb/ANDboH/gxh/+Kr886KP+IbYX/n/L7kH9v1P5EfoZ/wALH8G/9DboH/gxh/8AiqP+Fj+Df+ht0D/wYw//ABVfnnRR/wAQ2wv/AD/l9yD+36n8iP0M/wCFj+Df+ht0D/wYw/8AxVH/AAsfwb/0Nugf+DGH/wCKr886KP8AiG2F/wCf8vuQf2/U/kR+hn/Cx/Bv/Q26B/4MYf8A4qj/AIWP4N/6G3QP/BjD/wDFV+edFH/ENsL/AM/5fcg/t+p/Ij9DP+Fj+Df+ht0D/wAGMP8A8VR/wsfwb/0Nugf+DGH/AOKr886KP+IbYX/n/L7kH9v1P5EfoZ/wsfwb/wBDboH/AIMYf/iqP+Fj+Df+ht0D/wAGMP8A8VX550Uf8Q2wv/P+X3IP7fqfyI/Qz/hY/g3/AKG3QP8AwYw//FUf8LH8G/8AQ26B/wCDGH/4qvzzoo/4hthf+f8AL7kH9v1P5EfoZ/wsfwb/ANDboH/gxh/+Ko/4WP4N/wCht0D/AMGMP/xVfnnRR/xDbC/8/wCX3IP7fqfyI/Qz/hY/g3/obdA/8GMP/wAVR/wsfwb/ANDboH/gxh/+Kr886KP+IbYX/n/L7kH9v1P5EfoZ/wALH8G/9DboH/gxh/8AiqP+Fj+Df+ht0D/wYw//ABVfnnRR/wAQ2wv/AD/l9yD+36n8iP0M/wCFj+Df+ht0D/wYw/8AxVH/AAsfwb/0Nugf+DGH/wCKr886KP8AiG2F/wCf8vuQf2/U/kR+hn/Cx/Bv/Q26B/4MYf8A4qj/AIWP4N/6G3QP/BjD/wDFV+edFH/ENsL/AM/5fcg/t+p/Ij9DP+Fj+Df+ht0D/wAGMP8A8VR/wsfwb/0Nugf+DGH/AOKr886KP+IbYX/n/L7kH9v1P5EfoZ/wsfwb/wBDboH/AIMYf/iqP+Fj+Df+ht0D/wAGMP8A8VX550Uf8Q2wv/P+X3IP7fqfyI/Qz/hY/g3/AKG3QP8AwYw//FUf8LH8G/8AQ26B/wCDGH/4qvzzoo/4hthf+f8AL7kH9v1P5EfoZ/wsfwb/ANDboH/gxh/+Ko/4WP4N/wCht0D/AMGMP/xVfnnRR/xDbC/8/wCX3IP7fqfyI+zvjN458Bal8PtVtbnVNM1a4kQrZQWdwk0qXO0+XINrZUKeSxwMZXndtPx/omqzaDrOnarbLG9xYXEdzGsgJQsjBgCAQcZHYiqNFfVZJkFLKcNLDRm5qTu7+atojzcZjZYqoqjSTXY7X44aTBovxX8UW1u0jRyXIuiZCCd0yLKw4A4DOQPbHXrRWh+0OF/4XD4kyTn/AEbt/wBO0VFdGTSlPLsPKT1cIf8ApKM8Wkq9RLu/zF/Z7/5LN4e+tz/6Ty15zXo37Pf/ACWbw99bn/0nlrzmih/yM63/AF7p/wDpVUJ/7vD/ABS/KIUUUV6xzBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRXRaJolobAavq4nbTWla3hgtZFSW4lVVLgOVYIqCRCSVJJZVAOWZIqVFTV3q3surfZf1pu9Bxjc52iu4/tjRv+hM0P/v/AH3/AMk0f2xo3/QmaH/3/vv/AJJrL21X/nzL74//ACRXLH+Zfj/kcPRXcf2xo3/QmaH/AN/77/5Jo/tjRv8AoTND/wC/99/8k0e2q/8APmX3x/8Akg5Y/wAy/H/I4eiu4/tjRv8AoTND/wC/99/8k0f2xo3/AEJmh/8Af++/+SaPbVf+fMvvj/8AJByx/mX4/wCRw9Fdx/bGjf8AQmaH/wB/77/5Jo/tjRv+hM0P/v8A33/yTR7ar/z5l98f/kg5Y/zL8f8AI4eiu4/tjRv+hM0P/v8A33/yTR/bGjf9CZof/f8Avv8A5Jo9tV/58y++P/yQcsf5l+P+Rw9Fdx/bGjf9CZof/f8Avv8A5Jo/tjRv+hM0P/v/AH3/AMk0e2q/8+ZffH/5IOWP8y/H/I4eiu4/tjRv+hM0P/v/AH3/AMk0f2xo3/QmaH/3/vv/AJJo9tV/58y++P8A8kHLH+Zfj/kcPRXbrpuleK5orLT9LTStamYR2qW80j21w5OFjZZCzo7E4D79mQoKqC0g4irp1eduLTTXR2+Wza/EUo21TugorZ0rSoHtf7Q1DzTZGRoY4oHCyTOAC3zEEKFDKSSDnIAHUrp/bNM/6FzTf+/tz/8AHqqVRRdjini1GVoxcvS36tf15nJ0V1n2zTP+hc03/v7c/wDx6j7Zpn/Quab/AN/bn/49U+2iR9c/6dy/8l/+SOTorrPtmmf9C5pv/f25/wDj1H2zTP8AoXNN/wC/tz/8eo9tEPrn/TuX/kv/AMkcnRXWfbNM/wChc03/AL+3P/x6j7Zpn/Quab/39uf/AI9R7aIfXP8Ap3L/AMl/+SOTorrPtmmf9C5pv/f25/8Aj1H2zTP+hc03/v7c/wDx6j20Q+uf9O5f+S//ACRydFdZ9s0z/oXNN/7+3P8A8eqlqOl2t1az32nRvD9nAe5tnfcFUsFDoxGdu5gu05YZBy2WKuNWLdioYtNpSi1fvb9GzAooorQ7D0P9oj/ksXiT/t2/9JoqKP2iP+SxeJP+3b/0miorxsj/AORZhv8Ar3D/ANJR1Yz/AHip/if5j/2e/wDks3h763P/AKTy15zXo/7PjsfjL4eG44zc8Z/6d5a84q6H/Izrf9e6f/pVUU/93h/il+UQooor1jmCiiigAoqW2tpry4htraGSa4mcRxxRqWd2JwFAHJJPGBXt9t8GNC8A6fbaz8TNY8rzctBo2n5eWdlCsUZx/wACRtuFBZT5gyK8/HZnh8FyxqtuUvhileUvRL89l1ZvRw8613HZbt6JHj2g+HdV8Uaimn6Np9xfXj4PlwpnaCQu5j0VcsMscAZ5Nerad+zZr8VpHqHibWNI8P6aM/aHuJg8kHJVc4xGdzbf+WnRvXinan8d7vS7dNK8A6TaeG9HicFWWFJZ5yAVDPuBXLKEzkM2V++a8y1LUNW1+4S51XULu9nVBGst3M0rhck7QWJOMknHua4LZxjHePLQh6c8/wD5Bf8Ak36Pb/ZKW95v7l/m/wAD1ceAfg1pH+hat4+1C61CL/WzafFmBs8jbtikHAIBw55B6dAv/CR/Aj/oS9e/7/P/APJNePizXHLEn2p4to8fd/Wr/wBX5T1rYqrJ+U+VedlBL7ne3QX15LSFOK+V/wA7nrv/AAkfwI/6EvXv+/z/APyTSHwn8Eda5s/Fmr6Xd3v+pguYyYrR3+6rkxY2qSASZOg+/wDxV5H9mi/u/qaYbRccMwPvR/q8460sVVT/AMfN+Ek0H15P4qcX8rflY9Yuv2btQ1C3mvPCXijRfEFlChDNHJsdpQM+UNpdM4K8s6/e5wOT5d4n8G694MvFtdd0u4sZX+4zgGOTABOxxlWxuGcE4JweaZZT3+kXkd5p13PbXcWdk9vIY5FyCDhgQRwSOvevSNC+PfiC0tzpvia1tPE2jMiI9pqEa7yEHy/PtO47tpJcOTt7E5qHTznCO6lGvHs1yT+TXuP5qPqh82Eqq1nB/ev8/wAzx2iveU+Fngr4pJPcfDvVpNM1OJPMl0bVAxCruC7g/wAzAcFiQZOXUHZnFeKazo1/4e1S60vVLWS1v7V9ksMg5U/yIIwQRwQQRkGu3A5rh8ZKVKN41I7xkrSXy6rzTa8zKthp0kpPWL2a1T/rz1KNFFFekc4UUUUAFdxrH/Iu+DP+wXJ/6XXVcPXb6qRL4Z8HyId0cdhNAzLyFkF3O5QnswWSNsdcOp6EVz1v4tH/ABP/ANJkXH4Zen6opaLp39sazp2neb5X2y4jg8zbu2b2C5xkZxnpXoNz8JIJte1jw9pGuvd67piGQ21xZ+StwAASI3EjZPI4IFcF4e1CLSdf0q/mV2htLqKd1QAsVVwxxnHOBXp0nxP8PaZ4x1vxfpMGp3Or30bJbQ3cMcUVsWUAsSrsXPHTC9T9a8zNamYRrWwd7crtomnPmVlJtaK176rTzsb4aNBw/e9/Paz2+ZyVt4Gt7bwvY+Idd1V9Ps9RlaK0igtvPlkCnDOQXUKoPuT7Vu2PwauJvFb6Nc6skdo2mnVLe+ggMgnhyMYUsuDyep7e+azf+Ex0jXvBmkeHtfW/gk0eV2t7uyjSUvG5yyMjMuDnGCD26V1Gn/GLS08XrfXFjeQaLa6OdItIoQskwXK4dssozx2Pp9a4sVWzlKp7JPm9/pGyV/3fLpq2t7363S0NqcMI3Hm206v/ALev2OLvPAqTeFpPEmhai2o6fbzrb3Mctv5E8DNgKSoZgQSQMhup+uNiT4VW9nr1j4av/ECW/iS8jVlt1tS8EbsMrG8u7IY8dFI561Tfxrpuh+C7rw34eS9le/uUuLq+vI0jY7CCqpGrNgZUHJY9/XjauviL4b1bxhp/jK/s9TTV7VY3ksoFQwTTRjCsJC25RwONp6daupWzb3uXm5ff5XaPM9I8nMrWSb5ui0SvYUY4XS9r6X1dut7fK342MfT/AIW3Z0rWNS1SW6gh0u+OnyxWNp9ql8wAFjt3KAgyPmz3qPw/4B03XofE94muzrpuhQxzmVLHMkwYHI2NIu0gqR1OfWrmi/EdrbVdT1l9b1rStRv7x7iWOwgjnt3Q4IUo7ryPmGTnjHvXQxfGHSZda8bX3k6lpZ12CGG2msUVpYWQEGRvnT5jkHg/j3rOvXzmPOkrv3WrJWXvQ5lZxd9OZppy0vdJ2KhDCPlv579dHZ76a20svXc5m7+Et8df8OaXpl6l2uv2q3dvLNGYWjjI3EyJlsYHoTntUK/Du01O3106Brh1C80SNpriCW08kSRqcM0Tb23Ae4Umt+5+MFva+I/CmrWNrc3s+jW7W91d321J75WGDuwWxjkgknk8++ZYeNvD3hWLxJP4fh1Ka/1qB7ZBeRpGlpG5y2CrMZD0wcL0pwrZzyR5k+aytpGzfO782mi5LNW5d310E4YS7tt6vRWVrd9b9/u1ILTwHoF34QvvE6eINTFhZXC20kZ0qPzSzYwQPtGMfMO4rho7Q3eoLa2IknM0oigDIFeTJwuVBOCeOMn6mus07xfY2nwx1jww8Vyb+9vkuY5FVfKCqFyCc5z8p7VT+Hmu6V4Z8V2esavBcXEFkGljigVSWlx8mckYAJzn1A4r06E8bRp4mpUvNxb5FaKuklbZLd3WpzzVGUqcY2V0rvXv5+RtfEj4VyfD+0sbpNUj1KCeRoJmji2CCZQDsPzHOQT6dOlY/wAQfBf/AAgmux6X9u+2b7eOfzfK8vG7PGNx6Y65rorn4oWeveFvEukaxpSQTajOL+2lsRI4F1nLM/mytgEAD5egJ4rH+KPjCx8beJItS0+K5igW1igK3Cqrblzk8EjHPrXJllTNVVp0sZdpc/M7RtL4XF6bWvJadtTXERw3LKVLray103vv8mcVVr4j/wDJQ/Fv/YWu/wD0c1Q29vNd3EVvbxPNPMwSOONSzOxOAABySTxil8fXMN5468T3NtNHNbzandSRyxsGR1MrEMCOCCOcivYq/wC9Q/wy/OJyQ/hv1X6lu8/5A3hz/ryf/wBKZ6pQwyXM0cMKNJLIwREUZLEnAAq5ckPofh91O5EtZImYcgOLiVip99rocejA9xT/AA/qn9h67pupGPzBZ3CTFP7wVgcVnP4meKm1Gbiru8vzZ31x8BvFEGkm8DWclwq7zZpITJ9AcbSfbP415zp2n3GqahbWFsm65uZFijU8ZYnA+lfVFx8ZPCMOlG+TUhK+zK2qowlLf3cY4+vT3r5isden0/xHDrcSJ58Vz9pCfw53btv07VCPIyrF46vGp9YhZra6trrodWnw1gutbu/D9nriz6/bIzGA2xWGR1GWRZN2SRz1UDioU+GlzN4C/wCEogu98qFzJYmLDKiOVZg2eccEjAwD7Vp2/jzw/pviu98WWdrqDapOrtHZyqghilcYZjIGyw5PG0detQ6d8S49M0Pw5bRwzyXen3U8t4rqvlTxSltyDnnIbuOtGpTnj7R5P7t7pdnzL0vZX892Kvwo3eJm0X+1/u6Z/aPnfZvp8m3f79c/hXOeCfCX/CY6ndWX2z7L5FrJc7/L37tuPlxkdc9a7p/ijoR8dT6ylrqCac+lHT1Ty0MitnrjfjGPfNc74N8SaB4N1i4vI59TvIriymt2DWccTKzFdpH71sjg56Y469gcKuN9lLmT5uVW0W+t+lu2/wAiKL4b3F14AXxVbXolcF2ey8rDLGjlWcNu5xwTx0NaMXwoV/FJ0RtYKqNNGomcWuTjj5Nu/wB+ufwqLSfiPBo3h7wzY28E73GmXMz3SOq+VPDITuQc5OQe461u/wDC1NDXx5LrkVvqMVgdL+woqxp5qNkYON+MAD1zRqRUqZgnNRWnvW0Xf3V92q7312PLNSi0yIx/2dd3dwDnebm1WHb6Y2yPnv6VLoX/AB9XX/Xhef8ApNJVnxJqa6m9u41vVtVZAQW1KPaYxxgL+9fOec9Oneq2iEJNeysdsaWF3uc8Bd0DouT2yzKo9SwHU1Ud0enJt4d33s/62X5HIUUUV2nuHof7RH/JYvEn/bt/6TRUU79od2Hxh8SAMQP9G7/9O0VFePkf/Isw3/XuH/pKOrGf7xU/xP8AMX9nv/ks3h763P8A6Ty15zXo37Pf/JZvD31uf/SeWvOaqh/yM63/AF7p/wDpVUU/93h/il+UQooor1jmCt3wh4Q1Xxxrlvo+j2/m3UvzM7cRwoOsjt2UZHuSQACSAaGjaNf+IdUtdL0u1kur+6fZFDGOWP8AIADJJPAAJOAK938Xa7B8EfDUPgrw0I4/E19bxzazqsUgZ0Yg/Ih4KnrtyBtRgQCzlh5GZ5hUpSjhMIlKtPZPaK6yl1svxeiOrD0IyTq1dILfz8l5/kF/4i8L/Aq31TRPCLSap4zlRYLrV51Ro7Y4+dEHqGGdnIBI3MxTbXjGp6hqHiTU7rVNUupLi9un3yzSdWPsOgAGAAOAAABgVUgtwQHbp2FWXkWMZY/h61vl2U0sFerJ89SXxTe7/wAlppFaIivipVrRStFbJbL/ADfmCRrGMKP/AK9DyJH95gKpSXTvwPlHt1qCvRdVLYyVLuXjeRg4+Y+4FM+2/wDTP9aqUVDqyK9nEt/bf+mf608XiHGQwqjRR7SQeziaaSo/3WBPpTmUOMMARWVUsdw8fGcr6GrVXuS6XYsxiexuIrq0mkinhcSRyRsVeNgchgRyCDzkdK9m0n4kaB8UdLtfDXxM8xL1bjNnrtsscRh3dQ5xhAcBSdpUggsFKb68dimWUZB57io57cNl14PcetcOYZXQx8YylpOOsZLSUX5P809H1RpQxM6Da3T3T2ZtfEb4c6r8N9cbT9QXzbWXLWl6i4juEHcejDI3L1BI6ggnj694+FvjKy8Z6dF8NfGafatMuvk029ZwstnKAdihm/JOpydmGVsL5J4v8Iar4H1y40fWLfyrqL5ldeY5kPSRG7qcH3BBBAIIHHluOre1lgcbb2sVe62nHbmS6f3l0fk0a4ijHlVaj8L/AAfZ/ozCooor2TkCtzRNfjsYHsdRtnvdJdjL5CSiKSKTAG+NyrBCQAGBUhgBkZVGXDoqKlONRcsv6+Y4ycXdHab/AAb/ANBrX/8AwTw//JVG/wAG/wDQa1//AME8P/yVXF0Vj7Cr/wA/pfdD/wCRK54/yL8f8ztN/g3/AKDWv/8Agnh/+SqN/g3/AKDWv/8Agnh/+Sq4uij2FX/n9L7of/Ihzx/kX4/5nab/AAb/ANBrX/8AwTw//JVG/wAG/wDQa1//AME8P/yVXF0Uewq/8/pfdD/5EOeP8i/H/M7Tf4N/6DWv/wDgnh/+SqN/g3/oNa//AOCeH/5Kri6KPYVf+f0vuh/8iHPH+Rfj/mdpv8G/9BrX/wDwTw//ACVRv8G/9BrX/wDwTw//ACVXF0Uewq/8/pfdD/5EOeP8i/H/ADO03+Df+g1r/wD4J4f/AJKo3+Df+g1r/wD4J4f/AJKri6KPYVf+f0vuh/8AIhzx/kX4/wCZ2m/wb/0Gtf8A/BPD/wDJVG/wb/0Gtf8A/BPD/wDJVcXRR7Cr/wA/pfdD/wCRDnj/ACL8f8zr5vEGk6Kpbw/9vn1L+DUbyNITbZ6+XErP+8GOJC/G44QMquOQoorWnSULu92929/68lZfeKUr+hqaXq62cbW13C1zYM2/ylk2Oj4+8jEHaTgA8EEAZGQpXU8/w7/0ENV/8F8f/wAfrl6KcqcZas5KmFjKXMm16W/VM6jz/Dv/AEENV/8ABfH/APH6PP8ADv8A0ENV/wDBfH/8frl6KXsokfU/77/D/I6jz/Dv/QQ1X/wXx/8Ax+jz/Dv/AEENV/8ABfH/APH65eij2UQ+p/33+H+R1Hn+Hf8AoIar/wCC+P8A+P0ef4d/6CGq/wDgvj/+P1y9FHsoh9T/AL7/AA/yOo8/w7/0ENV/8F8f/wAfo8/w7/0ENV/8F8f/AMfrl6KPZRD6n/ff4f5HUef4d/6CGq/+C+P/AOP1Q1LWIWgez02OWK1fHnSSsDJcYPGccKuQG2AnnqzYXGNRTVOKdyoYWMWpSbdu9v0S/EKKKKs6j0P9oj/ksXiT/t2/9JoqKP2iP+SxeJP+3b/0miorxsj/AORZhv8Ar3D/ANJR1Yz/AHip/if5kn7PgX/hcvh7k5zc9v8Ap3lrzivRv2e/+SzeHvrc/wDpPLXnNXQ/5Gdb/r3T/wDSqop/7vD/ABS/KIUUV1fw38FzePvGOm6LGJBbyP5l1Kmf3UC8u2dpAOPlUkY3MoPWvRxFenh6Uq1V2jFNv0RhCEqklCO7PU/ANtp3wk+Hn/CealbQS+LNV3JottdFgViOFLhNoIyCzFs4KFAGXzDnxfdNf3Mt3dSSTTSuZJJZWLNI5OSxJ5JJySTXd/GTxfD4u8YtaaaY00HR1+w2EUGBEFThnUKxXBI4K4yipxxXFqoRQo6CvMyPCT5JY7EfxKurv9mP2YLtZPXzbOjGVVdUafwx09X1fz/ISRxGhY//AK6zXdpGLMeanvHy4QHgdfrVavWqSu7GNONlcKKKKzNAooooAKKKKACiiigBVYqQQcEVowyiVM8bu4rNqa1fZKBnhuK0pys7Gc43RNcw/wAaj617gBafHD4Zz+ZHG3xB8M2+Iiju099bIBywwTIWywwCSJMHKiTB8ZIyMHpWz8P/ABdN8P8Axlp+sRmRraNtlzGmcywNw643AEgcgE43KpPSvNzvAzxFJVsPpVp+9HzfWL8pLRmmDrKEnCfwy0f+fqtziKK9I+NnguHwl4xkuNNEbaBrKfbrCWDBi2tyyKVULhScgLnCMnPNeb114LF08Zh4YintJX/4HqtmZ1qUqU3Tlugoor3D4Bfs9RfG3TfE9/P4o/sKDQBE0h+wG68xXWQk8SIRgR++c10t21ZmeH0V9EXX7Mena58P9c8ZfD34hWfiuy0RXe7gfTZbGVQib22q7Ek7eRkAHHBzxXzvSTT2AKKKKYBRRRQAUUUUAFFFFABRRXveg/s32a/DPS/Hvjfx3ZeFdI1iQR2KmwlvHkLbiu4IRtyEY8Z4646UNpAeCUVseKtFt/Duv3um2mr2WsWsDL5d/ZEmGdSoYEZAIPOCD0II7Vl28X2i4iizt8xwucZxk4oAjor6t8Z/skeDfh/rGk6R4j+McWnajq//AB5pN4ekKSfMF5kWYqgyRyxFeN/Gn4La58EvE0OkavNBdQXUXn2l7b5CTJnB4PKsD1HuOTmkpJ7BY82ooopgFFeyfAr4Df8AC6rPxbcf8JB/ZP8Awj1vHPt+x+f5+8SHH+sXbjy+vPX2rxui/QAooooAKKKKACiiigAooooAKKKKAPRf2hwv/C4fEmSc/wCjdv8Ap2iopv7RH/JYvEn/AG7f+k0VFePkf/Isw3/XuH/pKOrGf7xU/wAT/Mf+z3/yWbw99bn/ANJ5a85r0b9nv/ks3h763P8A6Ty15zVUP+RnW/690/8A0qqKf+7w/wAUvyiFe/fBiWPwb8LPHfjdG/4mAxp9qyQK0kD4XawZjypeaMsuMfugfm4A8Br3f4jj/hHvgd8N9A/1/wBu3an5/wB3ZlS+zbzn/j6xnI+50545c/j9YVDA/wDP2aTX92N5y/8ASbfPrsa4F8jnW/lTt6vRfmeN2iZLOR04FW6jgXbEvTnmpK+mWx5zIJII3kyzEM3ak+xx+rfnUd63zIvcDNdV8LdU8O2Hj7w9ceMVlfw5BdpJdeXEsvA5XehB3x7gu8AElNwAJxWMpRTd0axjJpWZ9C/BH9kHS/HHguDxJ4t1HVrP+0v3lla2W2J1hBIDyGSNs7+GXaMbcHJ3YX0r/hhj4d/9BnxT/wCBVv8A/GK+jtH1az1/SLDVtOm87T9QgjubeXaV3xuoZWwwBGQQcEA1drxJ4io5N3setGhBJK1z5k/4YY+Hf/QZ8U/+BVv/APGKP+GGPh3/ANBnxT/4FW//AMYr6boqfb1O5XsYdj5k/wCGGPh3/wBBnxT/AOBVv/8AGKP+GGPh3/0GfFP/AIFW/wD8Yr6boo9vU7h7GHY8a+Hv7Lnw68A/2jnTf7f+2+X/AMjBBb3fkbN3+r/dDbu3c+u1fSuwu/hV8NbK0nuZfAHhpo4I2kYQ6FDK5AGTtRYyzHjgKCT0AJrtlwGGelSbk9vyrppVpOOsl8zlrUoqWifyPzK/aP1TwB4k8cafd/D2Gxh0VNNjilWwsDZxmcSyliUKLk7SnzY6YGeK8fW2jWRcM24c4r6h/ad+I3wj8YeEbc+BDpcniaXVlubu4t9Ie2nkiMcu9mlaJd2XZCQSSTz2zXyxaN++5ySwNenFx0VjhalZu5eqvdplA2OR/KrFNdd6MvHI71uzJHsetSx+N/2bLPUJ2/4mHhS7W1MrwLudMqixowOQuyWHJ7mLkHhq8Ar3j9nYf20PG/hL/Vf23pLf6V97yduY/ucbv9fnqPu475Hg9fM5NH6vicXgltGfMvJVFe3ykpf5JWPRxb56dKt3Vn6x0/KwV9t/sISRQ+EfirJPD58CRWzSRbivmKI7jK5HIyOM18SV6t8H/j94j+Ctprlroem6LfQa15f2ldUgklGEDgABJFGCHOc57V701dWRwrc+pvgnrHh34q/Bj4meFvh54cfwFcpDmZheNfrP50bjBlkAYArEyn+6GyOa4T4F2HjzwT8Fx4tm+Ktn4F8C3V48kKtoseoyyyFvKLbSu4ZMeAATwpOB1rzHU/2qvF03hjUPDug6J4U8J6dqCslz/wAI7pn2VpAww3JdgCRxkAH0IrK8EftG+LPBPgmTwYLHQdb8Oly8Vnrdj9pSAltx2jcAfmJbDBgCanlY7nvX7X+h6Lqvwc8A+OYJ7XUtYu7iK3fWoLA2R1CKSCR97RHkZMYIB6bjjg10X7QfxM1X4YfDX4M6loMFiusyWK+Xe3Vqk7QxrBAXRA4IXflcsPmwuARk18v/ABF/aI8W/FHwPpPhPX4NKNnplwt1Hc28DxzyOqOgDfOUC4kPCqoGBjAGKz/iV8bvEHxT8P8AhbRNYs9LgtfDUJgtXs4pFd1KImXLOwJxGvQDqaFB6XC59g/GP4beGPFP7TXwlF/p1skGuW1xNfxhAq3TQI0qBx/Fk4U56jj0o0/4pa1qP7Ydt4Cn0vT/APhG9JaWKxgFkiyWRWzZ/OSQDcN2SuM7dr4xnmvlnxf+0D4o+KXjHwXqmrXOm+H7nQJlS31DTYJf9HVnTMrKzuX27c4GMjIwc19V+G/ibb2Piq08YeM/iV8LGsLKB1km8OxE6rqS7CqJMCDIqgkPsTuoGMVLTS1Hck+HnhXR9Q/aQ+OHie9sIdQ1Xw8bdrCCVQ21nhYsyg/xfulUHtuPrVH9lz4oa58VdI+KmqeIraxfUobaJRf21okDSRsk5ETbQNwTBKk5b5zknivCfCPxhvdU/aI8U+L9B8U6d4Ui1cymFtciZ7S5QFRHFPt+5lV3bgflIxnmvc4/jLofww8FeM7zW/FfgbUtb1mEpYaH4HjH2VZSrgyOw5LOXUszngRjGScUNPYEzyD9mDQfHlh4L8WeL9G+IFn4J8IW8qpf3k2mx3zyvEu7iN1JAUSjoRktjBxx6j8c7HRfHv7LE3jKXXLTxZq+m3Uf2fxHHpB06SYG5WJkMZ5wA5B7EqDjIr5b+F/x88U/CnR9V0TTYNK1LQdUJe403V7Xz7dmKhS20Mp5UAEE4OBxWr4l/aZ8X+KvhxqHgO+sdCj0S8kVwbWzaF7dVlWRY4lVxGqAoBjZ0zkknNU4u9xX0PLPDukHX/EGk6SJlgOoXcVr5rdE3uF3H2Gc1+iviO5+HWh32l/s36/p91BoV5pUbafqt1Pub7U0j7cMR8rbgSrfd3HZtxgV+bCsyMGUlWU5BBwQa97t/wBrnxu1jpsOsaR4V8QX2mAfZNT1jS/Pu4SOjK4YANwPmxk4ySTTnFsEzrPjB8BfDHwO+CrjXUtr7x/qWrPFp97DcSqRaqwO7yt2z7i85BwZQM8CvmDTv+Qhaf8AXVP5ivWviL+0n4p+K3hSHQfFeleH7+S3kMsGpi1eO7gYnJ2ssgQDHykbCCAM5IBrx+GUwTRyqAWjYMM9Mg1UU7aiZ+iX7Wvhv4eax4u8G3njvx1L4ejtIZCtlDpU1y95H5ilsSJkRnjHIPXNeea98Q/Cf7Un7Sfw/wBDW1lfwjpouObpdjXriNpSCuchCYkXB5Iz0zivnn4yfHLxD8b7/S73xDZ6Xay6bE8MQ06KRFYMQTu3u/PHbFcBo+r3/h/VbPVNMupbTULKVZoJ4jho3U5BFQoaDbP0Y8T/ABS8CeDPiJqnh/xP8QtIh8KWifZZfBTeDpTHEDGNpFwqnceQ3AKkHAA6jzj9mDwl4EvPib8VvE3h23i1fTdACSaDHNE3ypL5rZVZAGDDywgJGQCfWvHL/wDa08V6uYrnVfC3gbUtZiQIur3miLJdjHQ7i20evC49q4nwX8bvGHgTx5qPjPSr2H+1tTkkkvY5YR5FzvbewaNcADdyNuMdsUlB2C59g/sufFDXfippPxU1TxHbWL6lDbRKL+2tEgaSNknIibaBuCYJUnLfOck8Vk/A/RfDfw+/Zjh8dR65Z+G9d1WdxceJJtIOpyWYFw0SxrEOQCEHXjL5IPFeI6d+2D420iTWxYaH4StLPV49stna6c0MKOQwaVQkgJkbdyzlvur05zxvw0+Pvi74X6Te6Jp/9nal4evSWm0nV7b7RbMxABO3IIzgZAOD3FHIwuewftE+Ovhd49+GmlvZ+KrPxB8SdPmRZNTttDn09r6IlgwdWTaMAqfvdVOMBiK+T69H8ffGjV/H2jRaK+ieGtD0eO4W6+yaFpiWqNIqsqsTyxwHYYzjmvOK0irITCiiimAUUUUAFFFFABRRRQB6H+0R/wAli8Sf9u3/AKTRUUftEf8AJYvEn/bt/wCk0VFeNkf/ACLMN/17h/6Sjqxn+8VP8T/Mk/Z8dj8ZfDw3HGbnjP8A07y15xXo37Pf/JZvD31uf/SeWvOauh/yM63/AF7p/wDpVUU/93h/il+UQr3n9pcf2b4g8NeH7X93pGmaUn2WDr5eXZD8x+Y/LFGOSfu+5z4NXvP7Uv8AyUDTf+wVH/6Omrnx2ub4NPtVfztFX+5tfNmlH/davrH9TyNRtUAdAMVUvW+ZV9BmrlULtszEegxX0NX4Tip/EQUUUVzHQfrJ4Bu7fwj8IfB8niGeLR47DRbGK6bUXFuLd/JjTa5fG07jtwcc8da7SzvLfULSC7tJ4ri0uI1lhmhcOkiMMqysOCCCCCOtUvEPh7S/Fei3ui61ZRXul3sflz28o4YdRyOQQQCGGCCAQQQDXz3/AMKd+Nfgn/iVeAfibayeGk5t4tcjDz2yj5ViUmGXKKioBtKLndhF7+Mkp3u7M9Ntx6XPoTU/EejaLd2FpqWrWFld6jJ5VpDc3CRvcvkDbGrEFzllGBn7w9a068O8BfA/XG8S2vjD4o+Jv+Ep8RWfzWNmikWOnSZA82NMKpcqkZyEQBgThmCuPcaUklonccW3q0FZkHiPRrnWrnRIdWsJdatYxLPp6XCNcRIduGaMHco+deSP4h6itOvIfih8FrjxPrUXi/wZr0vhfxxBHse9gB8rUEXBSK4UfeG5EG4hvlGGVwFCqKTdm7Dk2loevVmaH4j0bxPaPd6Jq1hqlokhiaaxuEnRXABKlkJAOGBx7j1r57/4Vl+0Pr//ABLte+Kel2OlT/6640qHFymPmXYUhiblgAcSLwT16H3HwF4C0P4beGrXQNAtfIsoPmd3IMtxIQN0sjYG5zgc8AAAAAAAVKMYre7JjJt7H5G3lncadd3FneW8tvd28jRTQTIUeN1OGVlPIIIIIPSoa7T4wf8AJWvHv/Yev/8A0oeuLr2E7q55jVnYntGxMB6jFX6zYG2zIffFaVdNJ6GFVanoP7PV9cWPxX0y3gk2xXkdxBONoO9BG0gHI4+aNDkY6ehNee+NdPttI8ZeItPs4/Ks7PULiCGPcW2IsjKoyck4AHJ5rufgL/yWDQfrc/8ApPLXH/Ef/kofi3/sLXf/AKOavn4e7ntRLrSg35vnmrv5aHZLXBxv/M/yRzNFFbcHha9uPC1x4ijeA2dvcfZ5I9x80cL8+MY25dBnOcsOK984TEoro9V8Eavpc+k23k/a7vU7YXUVvaK0kigkgqy4+8CpyBnFZMej6jNqB06Owun1AEqbVYWMuR1GzGc/hQBSorQg0HVbq8ns4NMvZbyAEywJA7SRgddygZH41evfDEtv4rj8PwzpJPJNFAksilF3PtxkDJABb3oAwaK6dPCVu+t6bpUfiDT7ma8vI7NxaxTlodzBSxEkaAgE9Af8ax00XUJ5I1trK6nE0rQxGOFm8116quByQCDgetAXKFFakXhnW57qa1i0fUJLqBgkkKWzl0YgkArjIJAJ59DUdnoOq6hNLDaaZe3E0LiORIYGdkbn5SAOD8rcf7J9KAM+irraPqK6cuotYXQ09m2i6MLeUT6b8Yz+NWf+Ea1SKeGG7sbqzM8TzRm4tpB5iohYkAKSRgdQMDqSBkgAyaKK1tA0F9elvFF5a2cVnbm5lmud+1UDKvRFZicsO1AGTRXQyeD70a1pelwz2twdUVHtbmJm8p0Ziu/LKGABVs5AI2ninWvgu+uvFx8NefaRXgd18+RyICqoX37sZ2lRkHHcdKLBc5yitz/hEtU2TfuR9piv10023Pmmdg2ABjHVSOvXFO1TwwNLinzrOlXFzbnEtrBK5dTnBAJQI+D/AHGagLmDRXSX/g6XS0kjvNV0yHUYk3vp7Sv5ycZ2k7dgbH8O7OeMZ4qsvhW/bwu3iIGH7Es/keXuPm9vn24xsyQuc9TigLmJRRRSGFFFFABRRRQAUUUUAFFFFABRRRQB6L+0O7D4w+JAGIH+jd/+naKim/tEf8li8Sf9u3/pNFRXj5H/AMizDf8AXuH/AKSjqxn+8VP8T/Mf+z3/AMlm8PfW5/8ASeWvOa9H/Z8C/wDC5fD3Jzm57f8ATvLXnFVQ/wCRnW/690//AEqqKf8Au8P8UvyiFe8ftBH+2NN+H/imf5dQ1nSR58cfES4VJBtByRzO/UngD3z4PXu18f8AhLv2bNNvB+8u/C+oG3mnuuX8tjgJE3J24mgGDgfu/wDZXPPm/wC6xmDxPRTcH/2/Fpf+TKP4GmF96lVp+V/uf+VzyVCSik9SBWfO26ZyfXFW7VsxY7qaos25ix6k5r36r0RyU1qxKKK6f4b6tZ6B8RPCOrajN5On6fq1pc3Eu0tsjSZGZsKCTgAnABNc7dkbLc/XeiobO8t9RtLe8s7iK4tLiNZYZ4XDpIjDKsrDgggggjrU1eGesFFFeY+IPCvxC0jWbzU/A/iaxuLW/ffLoviYSzW8EjfekhmQmRB8qgQ/cG5yMfKBUVfqJux6dRXktp4V+KXim6gj8ZeJtH0nRoHV5bTwmJ45r8Z3bXuJCHhAKr/qsFlZwSODXrVElbqCdwoooqRn5K/GD/krXj3/ALD1/wD+lD1xdeqftI+ItL8V/GvxXqui3sV9psskEcdzCcpIY4I42Kn+IbkYBhwcZBIINeV17cPhR5U/iYqttYMOoOa1aya0JJP9H3HGWX+ddFJ7mFVbHqn7NOlxal8TBczPIJNPsprmMKQAzErEQ3HTbKx4xyB9D5Dreqza9rOo6rcrGlxf3ElzIsYIQM7FiACScZPcmvafhOf+EW+FXxE8XN8srwjTbSe34uIJWGMhuNq7poTkHPyZxkDPhFeDgP32aYuvuo8kF8k5SX3yXzOuv7mHpQ73f36L8grtvD3iyy0Pw9a208Avs3tw1zYsSglheKNR8+CB8yZHXlRxXE0V75w2PSm8X2Or6ctveal9mv77TZoJ7sxuVhla+ecq20E7WQgEqDjcB6ioZfEWl3N1qFj/AGk0az6RBpy6q8T4d42RiWABfYwQp0zgLkdRXndFFxWPStQ8Q6Tqun3GkprRtZIlsv8AiZSRS4u/IR1YEKC4wXG3I6IM7eMZmp+INPufilDraXbyaauoQTtcOjBiilNzFcZzweK4iii47Ho1xrdpH4q0TUptb0G5s7fVIrhxp2mNbyxxiQMWci3jLAAdMsc9qiuPEtjfaxZanb6hFYqYJLOSxngkaCBChU7dgyI3DEnHzhiTz94+fUUXCx6kp0i58O+JYbLWfsdo8mnRtORO0HmBZyUXIMnl8ZGQTkDtzWTr/iqzvrPxRHa3cu6/nsFUsrK1ykMUivI3puba2Cc5b2NcQtzMkElussiwSsrvGGIVmXO0kdCRuOPTJ9aiouKx6fe+MdKm0zz7U6dDcSadFYPE0V29yu1FU4HmCDbuXcDwf9nOSWyeINEXUE1CbUoZb+4F6072kc6xMZLZ1Uukg4kLsB8nygGvMqKLhY1dDu/sh1H/AImH2LzbOWL/AFPmefnH7r/Z3f3u2K2PAOq22lXWsfaby0s2utPeCGW8tzPDvMkZAZAj5GFPVSK5Kigdj1OXxV4fguv7Qubn+0NRttKaxH9nobWOSSR2UtFujxGEhYj7gyxyB1NUv+Em0CbWtD1WJ57UxadPY3MU7GZ1KwPHCxdUUNuVkXgcbOfU+c0UXFY9QtfH2m22laFqTFpNdtdTtp7y22keckKOolDYxllZQec7lJ71lwXehaFpurpBqVhqcdwm6zifTj9qhl8xCGaR0+UBVYEI5GT0rg6KLjselya14ffXda11r+zntdWE80mm3WnmW5jlkVyoV2QqoWRgdyuCQBkdqmj8VeFUMWilLz7ANL/sxr8T/uNzfvTL5Hlbzibn72cKOO1eXUUXFYKKKKRQUUUUAFFFFABRRRQAUUUUAFFFFAHof7RH/JYvEn/bt/6TRUU79ocL/wALh8SZJz/o3b/p2iorx8j/AORZhv8Ar3D/ANJR1Yz/AHip/if5i/s9/wDJZvD31uf/AEnlrzmvRv2e/wDks3h763P/AKTy15zVUP8AkZ1v+vdP/wBKqin/ALvD/FL8ohXuf7OeuW15ceIfAuozXCWniO0dYSkh+RwjCQKu0qGaMk7jj/VAc5ArwyrWm6hc6RqNpqFnJ5V5ZypPDJtDbHUhlODkHBA4PFbZtgFmGEnhr2b2faS1i/k0vkThq/sKqqdt/TqXru0udF1C90+7j8q7tZHgmTcDskQkEZGQcEEccVn17X8aNITxZpWi/E3R7WT7Bq9uqaiq7mFtOmI/mY4OMjy8hQuYwerjPilRl2PWOw0arVpbSX8slpJfJ/hZ9TSrQ9jNx3XR910YUVLbw+c5BbaiqWZsZwB7U/y7P/n9/wDIRrtM20j6g/Zk/abs/AGnp4O8Yv5XhyLzJLHUIoS7WjMS7RyKgLOjMWIYAsrNg5Ugp94Wd5b6jaW95Z3EVxaXEaywzwuHSRGGVZWHBBBBBHWvxv8ALs/+f3/yEa9O+Gnx68W/CrZBo3iL7RpK5/4leoQvNajO8/KuQ0fzOWPlsu443Z6VyVsLzvmjudFLEqOktj9SKK8y+EPxdf4t6FZatZ+GL23tZ5JYprmO8tZoLd0z8rfvFmBI2nBiB+cH7pDH1AxODjafyrhlSnHdHXGrCWzGUU7y3P8ACfyriviT4+l+HGhalrE/h+9vNPsbQ3D3a3VrDbq/IWNjJKHyW2j5UcneAoZvlpRpzlshyqQjuzs6+Nv2k/2p9Lu9EvvBvgW7iv2v45bXUtUCZijiOUeKLcMOWGcyDKhSNpJbcnjXxS/aa8W/E37TZf2z/YugS7k/s7TkdPMjO8bZZfvSZR9rDhG2g7Aa8X8uz/5/f/IRruo4TlfNM5KuKT0iV6KseXZ/8/v/AJCNNngWNY3jk8yKQHDYx0PPFdhzXTIameQtFGuegqGvWfgX4RTUNel8V6tHJF4c8No17NcFGKmWMblUbTklf9YcBvugEfOM82Nx0MBh54ipslt1b6JebeiLp0XWmoR6/wBXN34wXn/CEfDHwf8AD1GuI9QeJb/UEMv3MlmMZ2ja6mVnI5OPJXOcg14DW74y8T3PjPxRqmu3S7Jb6UuI8g+WgAVEyAM7VCrnAJxk8msKssmwMsHhVCr8cm5T/wAUnd/dsvJCxdZVal4/CtF6LYKKKsW1t5v7yTIiBxkdWPoP8e35A+qcpXorSxbjgWsZA7szZP1wRS/uP+fSL/vp/wD4qnyi5jMorT/cf8+kX/fT/wDxVH7j/n0i/wC+n/8AiqOUOYzKK0/3H/PpF/30/wD8VR+4/wCfSL/vp/8A4qjlDmMyitP9x/z6Rf8AfT//ABVH7j/n0i/76f8A+Ko5Q5jMorT/AHH/AD6Rf99P/wDFUfuP+fSL/vp//iqOUOYzKK0/3H/PpF/30/8A8VR+4/59Iv8Avp//AIqjlDmMyitP9x/z6Rf99P8A/FUfuP8An0i/76f/AOKo5Q5jMorT/cf8+kX/AH0//wAVR+4/59Iv++n/APiqOUOYzKK0/wBx/wA+kX/fT/8AxVH7j/n0i/76f/4qjlDmMyitP9x/z6Rf99P/APFUfuP+fSL/AL6f/wCKo5Q5jMorT/cf8+kX/fT/APxVH7j/AJ9Iv++n/wDiqOUOYzKK0/3H/PpF/wB9P/8AFUfuP+fSL/vp/wD4qjlDmMyitP8Acf8APpF/30//AMVR+4/59Iv++n/+Ko5Q5jMorT/cf8+kX/fT/wDxVVri2VVMkO4xj7ysclf8R7/h6ZGguVaKKKko9D/aI/5LF4k/7dv/AEmioo/aI/5LF4k/7dv/AEmiorxsj/5FmG/69w/9JR1Yz/eKn+J/mP8A2e/+SzeHvrc/+k8tec16P+z47H4y+HhuOM3PGf8Ap3lrzirof8jOt/17p/8ApVUU/wDd4f4pflEKKKK9Y5joLTxdqtv4Uu/C8c+3SLq6W8kjXgl1XbgkdVOEJBzzGpGOc49Rxd6nhiM0qRjOWOOBnFc6pQpylyK13d+b7m6k3FXexJM32ew2H79wQceijofxNZ1Wr+YTXLbceXH8iYOeB71VpszCiiikB9E/sjfGr/hWvjpdE1rVPs3hDXMpN9ol2wWlzgeXOflO3O0RscqMMGY4jGP0vr8R6/Sj9kP44yfEzwjJ4d1u6mn8VaBGvmXFzMjSX1uWISQDhiU+VHJB5KMWLOQBjR9IV8D/ALbXxq/trWIPh9oGqb9M0/L6x9mlyk1yG+WB/l58rbuIDEbnwQGi4+mP2kPjJF8HPh9PeW7bvEOqb7PS41ePdHKUObgq+dyR8E/KwLMinAbI/K69vbnUry4vLy4muby5kaWaeZy8krscszMeSSSSSeSTQgZBRRRQIK0LJvPtpbb+MHzU9yByPyrPqW2na2njlXqpzj1HcU0BLWzbeLtV0/wvqnhuCfGlapLFNPG3PMZyNueFydhJAyfLUZwCDm3cQhnZU5jPzKexBqrL90fWlOlCpZVFezT+ad0/k9TTmcU3FkVFFFdBgFaQ4tLUDgFCx9zuYZ/ID8qza0/+XW0/65n/ANDaqiTIZRVrTNOuNX1Kz0+zjMl3eTJBEg/idiFUfmRXtvxF+HljbyaFNc6Tc+HdF0/UhoF1fSWLQ/aYVClLzkDez4mJbnovtTuSeEUV6VceEbG2t/EE9ra3dtapozXMJnuLa+SRluoYyUnRNuMOc7QrKeCcEg6nhfwh4b/t3wdcW9td6tZyX9gl5OLuCSBmlK7o5INheIByV+fcHCkDGQQXA8hor1HR/BmgeIf7e1iKC4ttLsbqK0jsbjW7S2keRxIxb7RMiIFAjOECFjnrgE1O/gLwjpZtxeX2oait5rcmlwTabdQeWIhHA4kLBXVmUz4KqcEjhlxyXA8norWk8P3TeJ38P2o8+9N6bGMAY8x9+wfma9x8T/D6G08Q+DJx4Yk0/TtP16DQJ/tNiYk1GJWQpcMGUCTzMTbjzwFHpRcD54or0T4fWNpcfFY208NkbVGvyEuoBLAmyCYqWjKsCFIBxtPToa19WXQdd0jUWtZ9NutX03RpZ7y80vTVtraZjdwLGFjeJNrBXbLoiE5AyRuyXA8kor1Dxb4L8L6RN4pg03+2Hfw1fRwztc3EWLqJpCjBcR/u2BAAY7geTtHSrnijw5oWo/FHxJY6b4cvhp9hLP8AaI49XtrOGIiQKHEjwCOKPkKEOeSMN2JcDyOivVNW+H/h7wzF4hvNTfUbq2sjprWkNndwZkW6hkkKtMquh27MB0BDYOB8wIwPhlY2UmsX2p6qkB0rSrOSed54fOWJnxDC/ldJNsssZKnggHPpRcDiqK7Dxv4X1TSimrajHpsEd9MY7cWChIrlVRCZ4lUbfLbevIwNxI2jBA7zSPCWj+KPAXhK0e3tbO8t45dUvL5I1WWWzW6ljuNzdXKKI2UHoA1FwPE6K9Z+J2i6Vew6n4isrGLTSsWiGKys0WOBBdWUksnygdd0a857nOc8b3hTw3peja7qWhzwS3mmL4l0KJop2UmQOJ+GypBXLcjHIyOM5ouB4RRXoLaHpus6V4ll0a3eyWLUbK3hi1C6t2ALi43EztHGEXKDgFR/e3YBGt4H0tNH8P8AjNru78NWt/Zz2MaX2oW0Wp26B/OLKhSKdSWwvKj+HBIxRcDyiivarDTdA/sO/wBS1iyTVDcaDcXYfTkgskVl1Tyt0X+j5XIxgsuVUsuACAvK6b4J03UdQ8GxCS8SHXbG5u5h5ilozHNcooU7em2BM5HUnpkAFxnn9Fdf4z0bQvD9vpNrYrqMmp3NhZ31xNPMnkp50CyNGqBMnlgQxbgcYP3q5CgQUUUUwCpIefNB5BifI9cKSP1AP4VHUsHWT/rlJ/6AaEBlUUUVmaHof7RH/JYvEn/bt/6TRUU79od2Hxh8SAMQP9G7/wDTtFRXj5H/AMizDf8AXuH/AKSjqxn+8VP8T/MX9nv/AJLN4e+tz/6Ty15zXo37Pf8AyWbw99bn/wBJ5a85qqH/ACM63/Xun/6VVFP/AHeH+KX5RCiiivWOYli+6frVyFvs9tNcHrjy09dx757YFUVk2jGK0rq2WaK3jS6tgsSnO6Tncev4Vm073NOZWsZFFXv7N/6e7T/v5/8AWo/s3/p7tP8Av5/9ap5WTco0Ve/s3/p7tP8Av5/9atzT/hx4m1ezjvNP0i8vLOXOye3tpJI3wSDhgpBwQR9RWdSpCkuao0l5uxUYuTtFXOVrsPhf8RdW+FfjXTPEukzTBraRRc28cmwXluWBkgYkEYYDqQdpAYcqCJP+FTeMv+hd1T/wCm/+Irmv7Lb/AJ+bX/v5/wDWpUqtOtf2clK3ZpjlCUfiVj0P4+fGS9+NHjq41bddw6DbfudLsLh1P2eLADMQvAdyu5vvEcLuYIteW1f/ALLb/n5tf+/n/wBaugtvhf4svLeK4t9C1Ca3mQSRyx2krK6kZDAhcEEc5oqVIUlepJR9XYUYyl8KuchRXX3Pwv8AFlnbzXNzoeoQ28KGSSWS0lVEUDJYkrgADnJrnv7N/wCnu0/7+f8A1qKVWFVXpyT9HcJRlH4lYo0Ve/s3/p7tP+/n/wBaj+zf+nu0/wC/n/1q15WTckVvtFgjfx252tnqVPTn9MVVf7hq/ZWq28rF7q2MboUbbJzg+lZ8jbWdODgkZU5BqkmVzK1iKiiitDMK0/8Al1tP+uZ/9Dasyr9tKJ4kgP8ArUyE/wBoHnb9c5Pvn6A1Ell/RtYvfD+p2+padN5F9bktFLtVihIIyAQRnng9jyOasaP4m1XQIrqLTrswR3ZjMq7FYMUbcp+YHBB9OxIPBIOUylSVYEEcEHtSVRJ0d/4617UUmimu4kgmtjZtBb2sMMQiMiyEKiKFUl0UkgAnHJpW8feIDaW9qt8sSQSRSiSG3ijldozmMvIqh5Np5G4nFc3RSA6ZPH+uxX95epLZK96qi4hGnW32ebbyrND5fllgSTu255PPNU7jxbrF15Hm3hb7PeNfx/u0+WZggLDjpiJBt6DbwOtYtFAGrZ+JNT0/Xv7dtrny9W815xceWpIkbOWAIwDySOODyMYFP0PxTq3hvzf7Mu/IEskMrgxo4LxSCSNsMDghhn6Eg8Eg49FAGjYa9qGmaq+qWtx5d+4lBl2Kc+YrK/BGOVdh04zxUVjqt3psV9FazeXHfwfZrgbQd8e9X28jj5kU5GDx9ap0UAbF74q1fUZdZlubvzH1qQS3p8tB5zB94PA+X5uflxWkfiN4ia+kvXubR7iaD7POz6fbsLlNwb96pjxK2VU7nDNkDmuVooA39Y8ba7r8d3HqN956XZtzKPKRd3kIyRfdUY2q7DjrnnOBVPQ/EGo+G7x7rTbgQyyRtDIGjWRJYz1R0cFWU4HDAjgVmUUAb2u+M9a8S2lvaandRzW1q5eCJLeKNYMgAqgRRsQ4B2Lhc84zzWdd6teX1lp9lcTb7bT0eO3TaB5as5dhkDJyzE8561SooA6W28f+ILSWSRLyJ/MtoLRkmtYZYzHAgSL5HQruRQAGxu6nOSajuPHXiG6vL28l1KRru9uoL2aYIoZpod3lvkDgjc3TGc85rnqKANvU/Fuq6tHfx3ElssV/JFLcR29pDAsjxhwjYjRQD+8fJHXPOeKo2+r3lrpl7pkU22yvXjknj2g72j3bDnGRje3Q855qlRQBv6d411vShaLb3URjtLZ7OOKa2iljMLyGRkZHUq4LsW+YHnHoKtaX8RvEmjWqW1jfRRRxmTyj9khZ4hJneqMULIjZOVUheTxXLUUAXNS1W71eaGa9m82SGCK2Q7QuI40CIvAHRVAz1OOc1ToopgFFFFABUsHWT/rlJ/6Aaip0z/ZEdWBE7qVCnqgPUn6jIx759MgzNooorMs9D/aI/wCSxeJP+3b/ANJoqKP2iP8AksXiT/t2/wDSaKivGyP/AJFmG/69w/8ASUdWM/3ip/if5kn7PgX/AIXL4e5Oc3Pb/p3lrzivRv2e/wDks3h763P/AKTy15zV0P8AkZ1v+vdP/wBKqin/ALvD/FL8ohRRRXrHMFFFFABRRRQAVa0/Ur3SLyO80+7uLO8izsnt5DHImQQcMCCMgkfQ1VopSipJxkrpgm07o9D0/wCOnxC0yzjtYPEtw8UecNcQxTyHJJ5eRSx69ycDjoK7D/hqvxl/0DNA/wC/E3/x2vDKK8ivw9ldd81TDwv5JL77Wv8AM6oY7EwVo1H957n/AMNV+Mv+gZoH/fib/wCO1zGpftAfELUfta/279mgud48q2tok8pWz8qPt3jAOAd24YznPNeZ0VNLhzKqT5oYeHzSf53HLH4mSs6j+8varrep69cLc6rqN3f3CII1lu5mlcKCSFBYk4ySce5qjRRXsQhGCUYqyRyNtu7CiiiqAKKKKACiiigAooooAsLfXSKFW5mCgYADnAFL/aF3/wA/U/8A38NVqKd2KxZ/tC7/AOfqf/v4aP7Qu/8An6n/AO/hqtRRdhYs/wBoXf8Az9T/APfw0f2hd/8AP1P/AN/DVaii7CxZ/tC7/wCfqf8A7+Gj+0Lv/n6n/wC/hqtRRdhYs/2hd/8AP1P/AN/DR/aF3/z9T/8Afw1WoouwsWf7Qu/+fqf/AL+Gj+0Lv/n6n/7+Gq1FF2Fiz/aF3/z9T/8Afw0f2hd/8/U//fw1WoouwsWf7Qu/+fqf/v4aP7Qu/wDn6n/7+Gq1FF2Fiz/aF3/z9T/9/DR/aF3/AM/U/wD38NVqKLsLFn+0Lv8A5+p/+/ho/tC7/wCfqf8A7+Gq1FF2Fiz/AGhd/wDP1P8A9/DR/aF3/wA/U/8A38NVqKLsLFn+0Lv/AJ+p/wDv4aP7Qu/+fqf/AL+Gq1FF2Fiz/aF3/wA/U/8A38NH9oXf/P1P/wB/DVaii7CxZ/tC7/5+p/8Av4arUUUXAKKKKQz0X9ocL/wuHxJknP8Ao3b/AKdoqKb+0R/yWLxJ/wBu3/pNFRXj5H/yLMN/17h/6Sjqxn+8VP8AE/zOf+GvidPBvxD0PWpWjS3t7rbO8iMwSFwUkbC8khHYjGeQOD0pvjvwy/g7xjrWhssgSzuGWHzHVnaI/NGxK8ZKFT269B0rlJP9Y/1Nel6T4r8PeLfD2leGvF7SabdaWjR2XiSJXuHSHO5YJovvOgywUqfl+QAAbyaxClhsSsXCLkmuWSWrsm3GSW7tdppXb5rrazVO1Sn7JuzvdfqvnprtoefUV6YPgT4rvv3mgvpHiGzHyvd6TqUTxI/eMlyp3AFT06MOaP8Ahnz4j/8AQu/+Ttv/APHKr+3ct64iC8nJJ/c3dB9TxHSm/uZ5nRXpn/DPnxH/AOhd/wDJ23/+OUf8M+fEf/oXf/J23/8AjlH9u5Z/0E0//A4/5h9TxH/PuX3M8zor0z/hnz4j/wDQu/8Ak7b/APxyj/hnz4j/APQu/wDk7b//AByj+3cs/wCgmn/4HH/MPqeI/wCfcvuZ5nRXpn/DPnxH/wChd/8AJ23/APjlH/DPnxH/AOhd/wDJ23/+OUf27ln/AEE0/wDwOP8AmH1PEf8APuX3M8zor0z/AIZ8+I//AELv/k7b/wDxyj/hnz4j/wDQu/8Ak7b/APxyj+3cs/6Caf8A4HH/ADD6niP+fcvuZ5nRXpn/AAz58R/+hd/8nbf/AOOUf8M+fEf/AKF3/wAnbf8A+OUf27ln/QTT/wDA4/5h9TxH/PuX3M8zor0z/hnz4j/9C7/5O2//AMco/wCGfPiP/wBC7/5O2/8A8co/t3LP+gmn/wCBx/zD6niP+fcvuZ5nRXpn/DPnxH/6F3/ydt//AI5R/wAM+fEf/oXf/J23/wDjlH9u5Z/0E0//AAOP+YfU8R/z7l9zPM6K9M/4Z8+I/wD0Lv8A5O2//wAco/4Z8+I//Qu/+Ttv/wDHKP7dyz/oJp/+Bx/zD6niP+fcvuZ5nRXpn/DPnxH/AOhd/wDJ23/+OUf8M+fEf/oXf/J23/8AjlH9u5Z/0E0//A4/5h9TxH/PuX3M8zor0z/hnz4j/wDQu/8Ak7b/APxyj/hnz4j/APQu/wDk7b//AByj+3cs/wCgmn/4HH/MPqeI/wCfcvuZ5nRXpn/DPnxH/wChd/8AJ23/APjlH/DPnxH/AOhd/wDJ23/+OUf27ln/AEE0/wDwOP8AmH1PEf8APuX3M8zor0z/AIZ8+I//AELv/k7b/wDxyj/hnz4j/wDQu/8Ak7b/APxyj+3cs/6Caf8A4HH/ADD6niP+fcvuZ5nRXpn/AAz58R/+hd/8nbf/AOOUf8M+fEf/AKF3/wAnbf8A+OUf27ln/QTT/wDA4/5h9TxH/PuX3M8zor0z/hnz4j/9C7/5O2//AMco/wCGfPiP/wBC7/5O2/8A8co/t3LP+gmn/wCBx/zD6niP+fcvuZ5nRXpn/DPnxH/6F3/ydt//AI5R/wAM+fEf/oXf/J23/wDjlH9u5Z/0E0//AAOP+YfU8R/z7l9zPM6K9M/4Z8+I/wD0Lv8A5O2//wAco/4Z8+I//Qu/+Ttv/wDHKP7dyz/oJp/+Bx/zD6niP+fcvuZ5nRXpn/DPnxH/AOhd/wDJ23/+OUf8M+fEf/oXf/J23/8AjlH9u5Z/0E0//A4/5h9TxH/PuX3M8zor0z/hnz4j/wDQu/8Ak7b/APxyj/hnz4j/APQu/wDk7b//AByj+3cs/wCgmn/4HH/MPqeI/wCfcvuZ5nRXpn/DPnxH/wChd/8AJ23/APjlH/DPnxH/AOhd/wDJ23/+OUf27ln/AEE0/wDwOP8AmH1PEf8APuX3M8zor0z/AIZ8+I//AELv/k7b/wDxyj/hnz4j/wDQu/8Ak7b/APxyj+3cs/6Caf8A4HH/ADD6niP+fcvuZ5nRXpn/AAz58R/+hd/8nbf/AOOUf8M+fEf/AKF3/wAnbf8A+OUf27ln/QTT/wDA4/5h9TxH/PuX3M8zor0z/hnz4j/9C7/5O2//AMco/wCGfPiP/wBC7/5O2/8A8co/t3LP+gmn/wCBx/zD6niP+fcvuZ5nRXpn/DPnxH/6F3/ydt//AI5R/wAM+fEf/oXf/J23/wDjlH9u5Z/0E0//AAOP+YfU8R/z7l9zPM6K9M/4Z8+I/wD0Lv8A5O2//wAco/4Z8+I//Qu/+Ttv/wDHKP7dyz/oJp/+Bx/zD6niP+fcvuZ5nXQ+BPDL+MfGOjaGqyFLy4VZvLdVdYh80jAtxkIGPfp0PSurPwJ8V2P7zXn0jw9Zn5Uu9W1KJInftGChY7iAx6dFPNVNW8V+HvCXh7VfDXhBpNSutURY73xJKr27vDnc0EMX3kQ4UMWPzfOCCNhGVbNKeJg6WXy55vS8dYxv9py2035U+Z7Lq1UcNKm+aurJdHu/JLfXvsjn/if4nTxl4/1/Womje3uLkrA8aMoeFAEjbDcglEUnOOSeB0orkqK78PQhh6UKNPaKSXolZGE5ucnOW71JJJHDsAzdT3pvmP8A32/OiitiA8x/77fnThI+xjubqO/1oooAb5j/AN9vzo8x/wC+350UUAHmP/fb86dJI4dgGbqe9FFADfMf++350eY/99vzoooAcJH2MdzdR3+tN8x/77fnRRQAeY/99vzo8x/77fnRRQA6SRw7AM3U96b5j/32/OiigA8x/wC+3504SPsY7m6jv9aKKAG+Y/8Afb86PMf++350UUAHmP8A32/OnSSOHYBm6nvRRQA3zH/vt+dHmP8A32/OiigBwkfYx3N1Hf603zH/AL7fnRRQAeY/99vzo8x/77fnRRQA6SRw7AM3U96b5j/32/OiigA8x/77fnThI+xjubqO/wBaKKAG+Y/99vzo8x/77fnRRQAeY/8Afb86dJI4dgGbqe9FFADfMf8Avt+dHmP/AH2/OiigBwkfYx3N1Hf603zH/vt+dFFAB5j/AN9vzo8x/wC+350UUAOkkcOwDN1Pem+Y/wDfb86KKADzH/vt+dOEj7GO5uo7/WiigBvmP/fb86PMf++350UUAHmP/fb86dJI4dgGbqe9FFADfMf++350eY/99vzoooAcJH2MdzdR3+tN8x/77fnRRQAeY/8Afb86KKKAP//Z",
	"gugup": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4lkkcOwDN1Pem+Y/99vzok/1j/U16LNNF8NYLa0tLZB4yC77u8f8AeLZq4BEUYI2ltmMtg43MATn5fSoUfaXlJ2it3+i7t9Fps9SYQ5k23ZL+vvMfT/hr4x1KFpYdGukVW2kXDLC2cA/dcgkc9cYq4PhL412n/iUtnI/5eof/AIuuav8AUr3VJlmvry4uplXYHnkZ2C5JxknpyfzqrW98IvsSf/byX/tr/Mrmo/yv71/kdd/wqTxt/wBAlv8AwLh/+Lo/4VJ42/6BLf8AgXD/APF1yNFHNhP5Jf8Aga/+QHzUf5X96/8AkTrv+FSeNv8AoEt/4Fw//F0r/CXxqWbGktjPH+lQ/wDxdchRRzYT+SX/AIGv/kBc1H+V/ev/AJE67/hUnjb/AKBLf+BcP/xdH/CpPG3/AECW/wDAuH/4uuRoo5sJ/JL/AMDX/wAgPmo/yv71/wDInXj4S+Ndp/4lLZyP+XqH/wCLpP8AhUnjb/oEt/4Fw/8AxdcjRRzYT+SX/ga/+QFzUf5X96/+ROu/4VJ42/6BLf8AgXD/APF0f8Kk8bf9Alv/AALh/wDi65Gijmwn8kv/AANf/ID5qP8AK/vX/wAide/wl8almxpLYzx/pUP/AMXSf8Kk8bf9Alv/AALh/wDi65Gijmwn8kv/AANf/IC5qP8AK/vX/wAidd/wqTxt/wBAlv8AwLh/+LpR8JfGu0/8Sls5H/L1D/8AF1yFFHNhP5Jf+Br/AOQDmo/yv71/8idd/wAKk8bf9Alv/AuH/wCLo/4VJ42/6BLf+BcP/wAXXI0Uc2E/kl/4Gv8A5AfNR/lf3r/5E67/AIVJ42/6BLf+BcP/AMXSv8JfGpZsaS2M8f6VD/8AF1yFFHNhP5Jf+Br/AOQFzUf5X96/+ROu/wCFSeNv+gS3/gXD/wDF0f8ACpPG3/QJb/wLh/8Ai65Gijmwn8kv/A1/8gPmo/yv71/8idePhL412n/iUtnI/wCXqH/4uk/4VJ42/wCgS3/gXD/8XXI0Uc2E/kl/4Gv/AJAXNR/lf3r/AOROu/4VJ42/6BLf+BcP/wAXR/wqTxt/0CW/8C4f/i65Gijmwn8kv/A1/wDID5qP8r+9f/InXv8ACXxqWbGktjPH+lQ//F0n/CpPG3/QJb/wLh/+LrkaKObCfyS/8DX/AMgLmo/yv71/8idd/wAKk8bf9Alv/AuH/wCLpR8JfGu0/wDEpbOR/wAvUP8A8XXIUUc2E/kl/wCBr/5AOaj/ACv71/8AInXf8Kk8bf8AQJb/AMC4f/i6P+FSeNv+gS3/AIFw/wDxdcjRRzYT+SX/AIGv/kB81H+V/ev/AJE67/hUnjb/AKBLf+BcP/xdK/wl8almxpLYzx/pUP8A8XXIUUc2E/kl/wCBr/5AXNR/lf3r/wCROu/4VJ42/wCgS3/gXD/8XR/wqTxt/wBAlv8AwLh/+LrkaKObCfyS/wDA1/8AID5qP8r+9f8AyJ14+EvjXaf+JS2cj/l6h/8Ai6T/AIVJ42/6BLf+BcP/AMXXI0Uc2E/kl/4Gv/kBc1H+V/ev/kTrv+FSeNv+gS3/AIFw/wDxdH/CpPG3/QJb/wAC4f8A4uuRoo5sJ/JL/wADX/yA+aj/ACv71/8AInXv8JfGpZsaS2M8f6VD/wDF0n/CpPG3/QJb/wAC4f8A4uuRoo5sJ/JL/wADX/yAuaj/ACv71/8AInXf8Kk8bf8AQJb/AMC4f/i6UfCXxrtP/EpbOR/y9Q//ABdchRRzYT+SX/ga/wDkA5qP8r+9f/InXf8ACpPG3/QJb/wLh/8Ai6P+FSeNv+gS3/gXD/8AF1yNFHNhP5Jf+Br/AOQHzUf5X96/+ROu/wCFSeNv+gS3/gXD/wDF0r/CXxqWbGktjPH+lQ//ABdchRRzYT+SX/ga/wDkBc1H+V/ev/kTrv8AhUnjb/oEt/4Fw/8AxdH/AAqTxt/0CW/8C4f/AIuuRoo5sJ/JL/wNf/ID5qP8r+9f/InS3/w18YabbCWfRrpwzhQLdlmbof4UJIHHXpXIeY/99vzrUsNSvdLmaaxvLi1mZdheCRkYrkHGQenA/Kuxhmi+JUFzaXdsh8ZFd9peJ+7W8VASYpABtDbM4bAztUEjHzCo0a3u0bqXRPW/kmkteytr37ijCppC6fZ63/LX5HnXmP8A32/Oim0VwGJ1/wANdPi1L4g6NDKzqqTmcFCAd0atIv4ZUZ9qxtSv5NU1G8vplRZrqZ5nCAhQzMScZ7c10vwlC/8ACx9J5Ocz9v8Api9chXc9MJDzlL8FH/Nmsv4MfV/kj3b4QeIfDOm+G3hlurSx1MSE3TXMixmbk7CpY8gLxgdDnjnJ9C/4THw7/wBB/Sv/AAMj/wAa+R6K9jC8Q1cPRjSVNe6rHZSzKdOCgorQ+uP+Ex8O/wDQf0r/AMDI/wDGj/hMfDv/AEH9K/8AAyP/ABr5Horf/Wir/wA+197NP7Wn/Kj64/4THw7/ANB/Sv8AwMj/AMaP+Ex8O/8AQf0r/wADI/8AGvkeij/Wir/z7X3sP7Wn/Kj64/4THw7/ANB/Sv8AwMj/AMaP+Ex8O/8AQf0r/wADI/8AGvkeij/Wir/z7X3sP7Wn/Kj64/4THw7/ANB/Sv8AwMj/AMaP+Ex8O/8AQf0r/wADI/8AGvkeij/Wir/z7X3sP7Wn/Kj64/4THw7/ANB/Sv8AwMj/AMaP+Ex8O/8AQf0r/wADI/8AGvkeij/Wir/z7X3sP7Wn/Kj64/4THw7/ANB/Sv8AwMj/AMaP+Ex8O/8AQf0r/wADI/8AGvkeij/Wir/z7X3sP7Wn/Kj64/4THw7/ANB/Sv8AwMj/AMaP+Ex8O/8AQf0r/wADI/8AGvkeij/Wir/z7X3sP7Wn/Kj64/4THw7/ANB/Sv8AwMj/AMaP+Ex8O/8AQf0r/wADI/8AGvkeij/Wir/z7X3sP7Wn/Kj64/4THw7/ANB/Sv8AwMj/AMaP+Ex8O/8AQf0r/wADI/8AGvkeij/Wir/z7X3sP7Wn/Kj64/4THw7/ANB/Sv8AwMj/AMaP+Ex8O/8AQf0r/wADI/8AGvkeij/Wir/z7X3sP7Wn/Kj64/4THw7/ANB/Sv8AwMj/AMaP+Ex8O/8AQf0r/wADI/8AGvkeij/Wir/z7X3sP7Wn/Kj64/4THw7/ANB/Sv8AwMj/AMaP+Ex8O/8AQf0r/wADI/8AGvkeij/Wir/z7X3sP7Wn/Kj64/4THw7/ANB/Sv8AwMj/AMaP+Ex8O/8AQf0r/wADI/8AGvkeij/Wir/z7X3sP7Wn/Kj64/4THw7/ANB/Sv8AwMj/AMaP+Ex8O/8AQf0r/wADI/8AGvkeij/Wir/z7X3sP7Wn/Kj64/4THw7/ANB/Sv8AwMj/AMaP+Ex8O/8AQf0r/wADI/8AGvkeij/Wir/z7X3sP7Wn/Kj64/4THw7/ANB/Sv8AwMj/AMaP+Ex8O/8AQf0r/wADI/8AGvkeij/Wir/z7X3sP7Wn/Kj64/4THw7/ANB/Sv8AwMj/AMaP+Ex8O/8AQf0r/wADI/8AGvkeij/Wir/z7X3sP7Wn/Kj64/4THw7/ANB/Sv8AwMj/AMaP+Ex8O/8AQf0r/wADI/8AGvkeij/Wir/z7X3sP7Wn/Kj64/4THw7/ANB/Sv8AwMj/AMaP+Ex8O/8AQf0r/wADI/8AGvkeij/Wir/z7X3sP7Wn/Kj64/4THw7/ANB/Sv8AwMj/AMaP+Ex8O/8AQf0r/wADI/8AGvkeij/Wir/z7X3sP7Wn/Kj64/4THw7/ANB/Sv8AwMj/AMaP+Ex8O/8AQf0r/wADI/8AGvkeij/Wir/z7X3sP7Wn/Kj64/4THw7/ANB/Sv8AwMj/AMaP+Ex8O/8AQf0r/wADI/8AGvkeij/Wir/z7X3sP7Wn/Kj64/4THw7/ANB/Sv8AwMj/AMaP+Ex8O/8AQf0r/wADI/8AGvkeij/Wir/z7X3sP7Wn/Kj64/4THw7/ANB/Sv8AwMj/AMaP+Ex8O/8AQf0r/wADI/8AGvkeij/Wir/z7X3sP7Wn/Kj6N+I3ifwreeEr6Ca+sr+Z1ItoreVZHWbB2ONp+UDufTI5zg/Pmm38ml6jZ30Ko01rMkyBwSpZWBGcduKq0V4+PzGeMqqq4qLXY4sRiZV5qbVrHQ/E/T4tN8e65DEzsrzCclyCd0iiRvwyxx7UVc+LwX/hYms5Jz+57f8ATFKK5cfFRxVVLbml+bJxCtVml3f5i/CT/kpGk/Wf/wBEvXI113wk/wCSkaT9Z/8A0S9cjVv/AHSH+Kf5QFL+DH1f5RCiiiuUxCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiitnStKge1/tDUPNNkZGhjigcLJM4ALfMQQoUMpJIOcgAdStwg5uyGlcxqK6z7Zpn/AELmm/8Af25/+PUfbNM/6FzTf+/tz/8AHq19jH+dfj/kO0f5l+P+RydFdZ9s0z/oXNN/7+3P/wAeo+2aZ/0Lmm/9/bn/AOPUexj/ADr8f8gtH+Zfj/kcnRXWfbNM/wChc03/AL+3P/x6j7Zpn/Quab/39uf/AI9R7GP86/H/ACC0f5l+P+RydFdZ9s0z/oXNN/7+3P8A8eo+2aZ/0Lmm/wDf25/+PUexj/Ovx/yC0f5l+P8AkcnRXWfbNM/6FzTf+/tz/wDHqPtmmf8AQuab/wB/bn/49R7GP86/H/ILR/mX4/5HJ0V1n2zTP+hc03/v7c//AB6j7Zpn/Quab/39uf8A49R7GP8AOvx/yC0f5l+P+RydFdZ9s0z/AKFzTf8Av7c//HqPtmmf9C5pv/f25/8Aj1HsY/zr8f8AILR/mX4/5HJ0V1R06x110t7OyWx1KQhIFikZoZW7IQ5ZlYk4DbtvQEAEsOVrOdNw1vdCatqFFbOlaVA9r/aGoeabIyNDHFA4WSZwAW+YghQoZSSQc5AA6ldP7Zpn/Quab/39uf8A49WEqii7HHPFqMrRi5elv1a/rzOTorrPtmmf9C5pv/f25/8Aj1H2zTP+hc03/v7c/wDx6p9tEj65/wBO5f8Akv8A8kcnRXWfbNM/6FzTf+/tz/8AHqPtmmf9C5pv/f25/wDj1Htoh9c/6dy/8l/+SOTorrPtmmf9C5pv/f25/wDj1H2zTP8AoXNN/wC/tz/8eo9tEPrn/TuX/kv/AMkcnRXWfbNM/wChc03/AL+3P/x6j7Zpn/Quab/39uf/AI9R7aIfXP8Ap3L/AMl/+SOTorrPtmmf9C5pv/f25/8Aj1UtR0u1urWe+06N4fs4D3Ns77gqlgodGIzt3MF2nLDIOWyxVxqxbsVDFptKUWr97fo2YFFFFaHYdX8X/wDkoms/9sf/AESlFHxf/wCSiaz/ANsf/RKUV0Zj/vdb/FL82b4n+NP1f5j/AISf8lI0n6z/APol65Guv+ErsfiPpI3HGZ+M/wDTF65Crl/ukP8AFL8oCl/Bj6v8ohRRRXIYhRRRQAUU+GGS4mjhhjeSaRgiIgJZmJwAAOpNemwfDfS/CtpDqPjTUfL8zmLTrT5nlIAbaW/NTjAGR84zXVh8JUxF3DZbt6JerNadGVS7Wy69DzzStIv9bu1tNOtJbm4bHyRrnAyBknoBkjk4AzXd2fwa1VLdLvWtQ0/SbMZ81pZNzxc4XPROTj+Pv68U+8+KE9lEth4VsLfR9PjbIKxq8suOMtkEZIC56nI+8a467uNQ1WVZr+7nuJVUKHuJC7BeTjJJ45PHvXUlgqOjvUl/4DH/ADf4Gn+z097yf3L/AD/I7ceE/h1p/wDo9/4qu57tPvyWifumzyMYRx0I/iPOenQL/a3wu/6FvVP+/jf/AB6uDFmuOWJPtTxbR4+7+tH15R0hRgl6X/O4vrSXwwj91/zO5/tb4Xf9C3qn/fxv/j1IdA+Gmpc2+vahY3Fz/q4plJSBm6KxKYwpOD8/b73euH+zRf3f1NMNouOGYH3o+vX+OlB/9u2/KwfW0/ihH7rfkdtP8G7u7ikuNA1vTdWto1OSj7WMg52DBZc429WHXnHWuH1vw5qvhy4EGqWMts7fdLDKvwCdrDIbGRnBOM0+3N3p9wlxZ3EkM6Z2yQuUdcjBwR04JFdfpnxT1a3iNnrUEGtacVVWgu0XdhRx82Dk52klgx47Hmh/Uqys06b/APAo/wCf5jvh6nRxf3r/ADPOaK9UHgXw344WSXwhfvZXqLufTr7OFGQuQ3JA4JOC/LKPlrzXUdOutIvp7K9geC6gba8b9Qf6g9QRwQciubEYOpQSm7OL2a1T/rs7MzqUJU0m9U+q2KtFFFchkFFFFABXWXn/ACBvDn/Xk/8A6Uz1yddXckPofh91O5EtZImYcgOLiVip99rocejA9xXRR+Gfp+qKXwy9P1RDp1p/aGoWlpv2faJUi34zt3EDOO/Wurm8BxSapqGk2GptPqdkpcwy2/liUAAkIwZueRwcVy+lXSWOqWN1IGMcE6SMF6kKwJx+Vdm/jTSrPxBqWv2Md7Nf3KlYY541SOEkAZJDMW6e1d2Ejh3D9937u9rO9vO9u5rQVJx/ed/wMGHw1FDottq2p3zWtvduUgSKHzXfHViNygAfXPtWnbfD2WTXG0+a+VIGszexXMce8Sx8Y+UkYPPrVT/hILDU/D1hpOqC6iewdjDPbor7lY5KlSy/nn8K2rT4gWS6+tzLbXEenQaebCBIwryAcYZskDt6+lb0oYJuPPt7vV3/AL1+2v6GkI4fTm207/O5ztx4ZWTRH1jTLs3dpFIIpkeLy5YycYyuWBByOQe9X38Dw2+qW2j3WqrFrFwoIiEBaJGIyFZ92cn2UjmoG8R2em+HZ9H0pbh2upllnubhVQ/KQVVVBOOQOc+taM/i3R7/AMQWniG6t7xb+EIz20YUxSSKODvJyo4HG09KmMMJpe1/dvq7bvms/S3fra4lGhp30vvbre34Gfa+CZzY6hd3rzRR2VybV0toPPk3jknG4AKMjnNM0rwtZ6nHrVwupyCz0yNZS622XkBByNpcYIxjrVjTvF7Q317qDalqNjeXVw0rpaxJLEynoCrMORyM88YrWT4gWL6j4jufLvLL+04444ZLZVZ4yoI3n5l557Gqp08E+W/nv10dnura20svXccY4d2v5/k7dfTsY0/gS5Oq6RZWdws41SETxPInllFxk7lycYHuajHhK3vYdT/svUzd3GmqZJYng8veg6sh3HOPcCtSbx/FBq+h31tDNcSadE0U09zhZbkEY5wTjHOOT1qna+I9J0RNYk0qO8kutRjaFftCqqwIx55DHcenYdKThguZ22u76vRcqtbvrfv92oOOHvpt8+3T5+pFB4Y0ufQLnWl1W9FrbyiFkNiu8scdB5uMc+tc0sBnuhBbb5DI+yPK4ZsnA4ycE+mTW7aa/bQeDL/RWSY3VxcrMrgDYFG3qc5zx6VX8J6nY6Nrlvf38UssVvl0SIAkvj5c5I4B5/CuapGjOVOMbRTSu9dHd33b6GMlTk4JaX3NHxf4IfwrBbTrereRyu0UjLHtEUgAO3qc9/yrP8V+Hf8AhGNTSy+0/aN0Sy79mzrnjGT6VrzeNLfVNE1iw1CxWKS7k+1QvbbmxPnktvc4BGB8vTnis/xrr9t4k1hLy1SZIlgSLEoAORnPQnjmtcTHCckp0etrLXTe+/yfzLrKhyuVPytv53/Q5ym+Mf8Akbtf/wCv+4/9GNUsUUk8qRRI0ksjBURBksTwAB3NV/Fc0dx4o1uaGRJIZL2d0dCCrKZCQQR1Brgf8J+q/JmEfgfqv1NW8/5A3hz/AK8n/wDSmeqUMMlzNHDCjSSyMERFGSxJwAKuXJD6H4fdTuRLWSJmHIDi4lYqffa6HHowPcU/w/qn9h67pupGPzBZ3CTFP7wVgcV5U/iZ4ybUZuKu7y/NnfXHwG8UQaSbwNZyXCrvNmkhMn0BxtJ9s/jXnOnafcapqFtYWybrm5kWKNTxlicD6V9UXHxk8Iw6Ub5NSEr7MraqjCUt/dxjj69PevmKx16fT/EcOtxInnxXP2kJ/Dndu2/TtUI8jKsXjq8an1iFmtrq2uuh1afDWC61u78P2euLPr9sjMYDbFYZHUZZFk3ZJHPVQOKhT4aXM3gL/hKILvfKhcyWJiwyojlWYNnnHBIwMA+1adv488P6b4rvfFlna6g2qTq7R2cqoIYpXGGYyBssOTxtHXrUOnfEuPTND8OW0cM8l3p91PLeK6r5U8Upbcg55yG7jrRqU54+0eT+7e6XZ8y9L2V/Pdir8KN3iZtF/tf7umf2j532b6fJt3+/XP4Vzngnwl/wmOp3Vl9s+y+RayXO/wAvfu24+XGR1z1run+KOhHx1PrKWuoJpz6UdPVPLQyK2euN+MY981zvg3xJoHg3WLi8jn1O8iuLKa3YNZxxMrMV2kfvWyODnpjjr2Bwq432UuZPm5VbRb636W7b/Iii+G9xdeAF8VW16JXBdnsvKwyxo5VnDbuccE8dDWjF8KFfxSdEbWCqjTRqJnFrk44+Tbv9+ufwqLSfiPBo3h7wzY28E73GmXMz3SOq+VPDITuQc5OQe461u/8AC1NDXx5LrkVvqMVgdL+woqxp5qNkYON+MAD1zRqRUqZgnNRWnvW0Xf3V92q7312PLNSi0yIx/wBnXd3cA53m5tVh2+mNsj57+lS6F/x9XX/Xhef+k0lWfEmprqb27jW9W1VkBBbUo9pjHGAv71855z06d6raIQk17Kx2xpYXe5zwF3QOi5PbLMqj1LAdTVR3R6cm3h3fez/rZfkchRRRXae4dX8X/wDkoms/9sf/AESlFO+LzsPiJrIDED9z3/6YpRXRmP8Avdb/ABS/Nm+J/jT9X+Yvwk/5KRpP1n/9EvXI113wk/5KRpP1n/8ARL1yNU/90h/in+UBS/gx9X+UQooorlMQrU8P+H7/AMTapFp+nxb535LHhY17sx7Af4AZJAqrp2nXWr30FlZQPPdTttSNOpP9AOpJ4AGTXqevanF8NNGj8N6NsXWrmJZNRv0fcysR91TwQeuMgbVII5bI7sJhozTrVnaEd/N9l5v8NzejSUk5z0iv6shLrVtE+F8N7pugF73xG6iKfUJVUpCcfMqj1BGdvIyRuJ27a89u7i71m9mvr6d5biZtzyP1Y+3oMcADgDAFQQW4IDt07CrLyLGMsfw9aMRipVko/DBbRWy/zfmRVryqe6tEtkCRrGMKP/r0PIkf3mAqlJdO/A+Ue3WoK4nVS2JVLuXjeRg4+Y+4FM+2/wDTP9aqUVDqyK9nEt/bf+mf608XiHGQwqjRR7SQeziaaSo/3WBPpTmUOMMARWVUsdw8fGcr6GrVXuS6XYsCOW0ljnt5HSWNgyMhwykcggjvmvQrDxhpXjexg0bxpvW5EubfVIQqGPPUMcYUcAZwQRgkArurgopllGQee4qOe3DZdeD3HrXZh8TOhfk1i909n/X3oqlWlSbXR7roy34w8H3/AIN1Q2l2N8D5aC5UYWZf6EcZHb3BBPPV6p4I8Q23iOzj8G+I18+yn+WzuSwD27gHaoY/kvXrtwVOB5/4g8P3/hnVJdP1CLZOnIYcrIvZlPcH/EHBBFVisPBRWIofA/8AyV9n+j6mlWnG3tKfwv8AB9v8jLooorgOcK1NL1dbONra7ha5sGbf5SybHR8feRiDtJwAeCCAMjIUrl0VUZuDugTa2Oo8/wAO/wDQQ1X/AMF8f/x+jz/Dv/QQ1X/wXx//AB+uXorX2y/kX4/5lc0f5V+P+Z1Hn+Hf+ghqv/gvj/8Aj9Hn+Hf+ghqv/gvj/wDj9cvRR7ZfyL8f8w5o/wAq/H/M6jz/AA7/ANBDVf8AwXx//H6PP8O/9BDVf/BfH/8AH65eij2y/kX4/wCYc0f5V+P+Z1Hn+Hf+ghqv/gvj/wDj9Hn+Hf8AoIar/wCC+P8A+P1y9FHtl/Ivx/zDmj/Kvx/zOo8/w7/0ENV/8F8f/wAfo8/w7/0ENV/8F8f/AMfrl6KPbL+Rfj/mHNH+Vfj/AJnUef4d/wCghqv/AIL4/wD4/R5/h3/oIar/AOC+P/4/XL0Ue2X8i/H/ADDmj/Kvx/zOo8/w7/0ENV/8F8f/AMfo8/w7/wBBDVf/AAXx/wDx+uXoo9sv5F+P+Yc0f5V+P+Z0c2tWGnqTpP2qS8P3bu4VYzD/ALkalvmHZy3GThQQGHOUUVE6jn5ITdzU0vV1s42truFrmwZt/lLJsdHx95GIO0nAB4IIAyMhSup5/h3/AKCGq/8Agvj/APj9cvRWEqcZas5amFjKXMm16W/VM6jz/Dv/AEENV/8ABfH/APH6PP8ADv8A0ENV/wDBfH/8frl6KXsokfU/77/D/I6jz/Dv/QQ1X/wXx/8Ax+jz/Dv/AEENV/8ABfH/APH65eij2UQ+p/33+H+R1Hn+Hf8AoIar/wCC+P8A+P0ef4d/6CGq/wDgvj/+P1y9FHsoh9T/AL7/AA/yOo8/w7/0ENV/8F8f/wAfo8/w7/0ENV/8F8f/AMfrl6KPZRD6n/ff4f5HUef4d/6CGq/+C+P/AOP1Q1LWIWgez02OWK1fHnSSsDJcYPGccKuQG2AnnqzYXGNRTVOKdyoYWMWpSbdu9v0S/EKKKKs6jq/i/wD8lE1n/tj/AOiUoo+L/wDyUTWf+2P/AKJSiujMf97rf4pfmzfE/wAafq/zJPhKF/4WPpPJzmft/wBMXrkK674Sf8lI0n6z/wDol65Grl/ukP8AFL8oCl/Bj6v8ohRRW94O8OSeKvENnpqhxC7b53XPyRDljnBwewyMZIHesKdOVWapwWr0Moxc5KK3Z3PhSCz8A+Ef+EpvIIpNevsrp0M5IwnA3BcZHBLE91KgEbufPU8y7nkuLh3kd2LM7nLOxOSST1rpviHr8fiDxEbeyKLpenr9ltUiwIwq9WUAlcEjgjGVC+lYKqEUKOgruxtSLkqFP4Iaer6v5/lY2xNRXVOG0fx7sSRxGhY//rrNd2kYsx5qe8fLhAeB1+tVq8upK7sRTjZXCiiiszQKKKKACiiigAooooAVWKkEHBFaMMolTPG7uKzamtX2SgZ4bitKcrOxnON0TXMP8aj616QRb/EzwXLvRG8WaLD+7KsxluYVxyRglyeRjn58HID4PAkZGD0q54W16Twl4jtL9S5hRtsyL/HEeGGMjJ7jPGQDXp4OtGnNwqfBLR/5+q3HhqqjLln8L0f+fyOVorsfiV4bj0DxE81mEOlaiv2q1eP/AFeG5KqQAuATwBnClfWuOrkr0ZUKkqU90TUg6cnB9Aoor0X4P/BbxL8addm03QUhit7RRJeX1ySsNspzjJAJLHBwo5OD0AJGLdiDzqive7v4I/DOC9k0yP47aK2qxtsZZNInW23+n2gMUI9xxXhV5bi1u54BLHMIpGQSxHKPg43A9wetCdwIaKKKACiiigAooooAKKK7b4UfDLVfi740s/DGkSwQTzq8slxcE7IY1GWYgcnsAB1JHTqBuwHE0V698TfhD4W8C2+rR6T8TNN1zWdHuPs17pbWEtpMHD7GEZYssm05zg9AT2ryGhO4BRXXfDb4a+IPit4pt/Dvhy2WW8kUySSSttigjGMyO2DhRkDoSSQACSBXqut/s/8AgDw7qk+han8btGt/Edu3lzWv9lTtBFIOCjXCsVBB4ORkdxScktAsfPlFTXkAtbueBZY5hFIyCWM5R8HG4HuD1qGmAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAdb8Xgv/CxNZyTn9z2/6YpRTfi//wAlE1n/ALY/+iUorozH/e63+KX5s3xP8afq/wAx/wAJP+SkaT9Z/wD0S9cjXXfCT/kpGk/Wf/0S9cjVP/dIf4p/lAUv4MfV/lEK9X+HDp4d8DeKPEyt/pY/0SFliVmibAwcnsWkQkf7HfpXlFep+Lx/ZHwy8HaV/rftW69837u3ILbcc5/1+M5/h6c8dOWv2bqYj+SLt6vRfmaYX3eap/KvxeiPP7RMlnI6cCrdRwLtiXpzzUlcS2OJkEkEbyZZiGbtSfY4/VvzqO9b5kXuBmuq+FuqeHbDx94euPGKyv4cgu0kuvLiWXgcrvQg749wXeACSm4AE4rGUopu6NYxk0rM+hfgj+yDpfjjwXB4k8W6jq1n/aX7yytbLbE6wgkB5DJG2d/DLtGNuDk7sL6V/wAMMfDv/oM+Kf8AwKt//jFfR2j6tZ6/pFhq2nTedp+oQR3NvLtK743UMrYYAjIIOCAau14k8RUcm72PWjQgkla58yf8MMfDv/oM+Kf/AAKt/wD4xR/wwx8O/wDoM+Kf/Aq3/wDjFfTdFT7ep3K9jDsfMn/DDHw7/wCgz4p/8Crf/wCMUf8ADDHw7/6DPin/AMCrf/4xX03RR7ep3D2MOx418Pf2XPh14B/tHOm/2/8AbfL/AORggt7vyNm7/V/uht3bufXavpXYXfwq+GtlaT3MvgDw00cEbSMIdChlcgDJ2osZZjxwFBJ6AE12y4DDPSpNye35V00q0nHWS+Zy1qUVLRP5H5lftH6p4A8SeONPu/h7DYw6KmmxxSrYWBs4zOJZSxKFFydpT5sdMDPFePrbRrIuGbcOcV9Q/tO/Eb4R+MPCNufAh0uTxNLqy3N3cW+kPbTyRGOXezStEu7LshIJJJ57Zr5YtG/fc5JYGvTi46KxwtSs3cvVXu0ygbHI/lVimuu9GXjkd63ZkjvNTdPE3wbt7uVv9L0KdYd7RLllyFCKR0G2SPJ7lOfWvJ69U+EY/tIeJdB/1f8AaVgf3/Xy8ZT7vf8A1ueo+778eV1249+0pUa/Vqz9Y6flY7cR70IVO6t93/AsFfbv7JedR/Zz+LelaL83id1utiRf60h7MLDjvy6yAe9fEVdV8P8A4j+Jfhhry614X1OSxvdvlyAANHMnUo6Hhh9enUYPNeXJXRyp2PVf2avhV8Pfi/qtx4a8SXHiq18TfvbiJ9Oe3S0FuipwxdGfzNxboMYx3zXtXwU0G38L/DP9pnQLF5ZbbSn1GyhaYgyMkcE6KWwACSF5wAM9q8Zi/a/8XWd9canp3hbwPp2uXClZtWtNH23UmepZy5zk+oxXJfD/APaG8afDvxD4j1qxksL6XxJI02p22oW++C4kZmYsUQrg5d+AQMNjHSoakx3R7p8E4ZI/2Kvis7IVSS7uihI+8BBbjI/EEfhVz4fXS/B/9jubx/4WtLX/AIS3Vrlo59QlgWVoF+1GEDDAjaFUYU8bnzg14veftS+Mb3wR4g8HHTPDkGh6zvXybWxaAWaMFBSBUcIq5UtyrElmJJzXVfs6+NdY0/wbrWg23jbwHaWNzcHzNB8bxuLV1KrmVHHByRgoePlzjmhp9QueneP9cm8TfsL2OsXNjbWV1e3iyTR2sIhjd/trhpAg4XeRvIAAyxwMVh/toxvP4D+CSxKXL2EyqFGckxWuAPrTP2hfi74fi+COl/Dmy8Sab4l8QyXCzXt1pEQSxto1dnEce0bQq5RFVf4UycHr5Hb/ALUnjiHwVpfhea20K8XSUVNP1O808TXlntG1GjdjtVlGAG27uOuaUYvcGz6n/aAUr+0t8CVPUTgH/v8ALUHjH4q674d/a6sfB9hptgNE1prSDUEazRpb4SRAeY0hG7CDAAB2/Icjk14Bpv7QOq/Fb44fDTW/GI0TSrfRL6NDcQboIkjLhmaRpJGAxjrkCu4+M/7UGpeEPjPrtz4S/wCET8QWUcMC6fqktsl29qGgTzFhnjYEAsWyuSMk8cmlyvYdzyD9qfwho/gn43eItM0OGO209xDci2iGFgaSNWZQOwySQOwYAcV6d+yL4f07w14W8c/F+5huL/UfCsEsdnYQylAT5JZ2fHUEMByCBhjgkDHzD4k8R6p4v16/1zWrt7vVL+UzTzvjLMfYcAAYAA4AAArqvhb8ZfFfwf1C7uvDd1D5F6oS6srqPzbe4AzjcuQcjJ5BB5IzgmtGny2JvqfX1x8HPBX7T2u+Ffih4dMMNjdXKp4o0mSRkYlFywymCJDgKSMblYOCDnPxr8WY/DMHxI8SW/g63WDw1b3TQWaJM8qlUAUsHcliGYMwJJ4Neq6V+2T448PTx/2FoHg3R7He0k1hp+k+TBcMRjLgPuz3yGB45yOK8Q8V+IF8U+IL7WBpWnaU14/mNaaajpbox6lFdmKgnnGcDPAA4pRTT1Gz62/4J7XVkmveO7RmjGqzWltJb7vveWryCTHtueLP4V8ga7Zahp2t6jaaskqapBcSR3Sy/fEoYhs++c1Z8K+LNa8Ea7aa54f1CbT9VtG3RTxEZGeCCDwwI4IIII617Fe/tZeJ9SuBfXvhHwHda4FA/tefRFe7yOh3lsZH0p2ad0HQ6n9mDQfHlh4L8WeL9G+IFn4J8IW8qpf3k2mx3zyvEu7iN1JAUSjoRktjBxx6j8c7HRfHv7LE3jKXXLTxZq+m3Uf2fxHHpB06SYG5WJkMZ5wA5B7EqDjIr5i+Hf7Q3i74b2WuadZw6Tqmj63K893p2rWnnW7yOMM20FeoABGcEAcVe8S/tM+L/FXw41DwHfWOhR6JeSK4NrZtC9uqyrIscSq4jVAUAxs6ZySTmpcXe4X0PpT9oP4mar8MPhr8GdS0GCxXWZLFfLvbq1SdoY1ggLogcELvyuWHzYXAIya0fjH8NvDHin9pr4Si/wBOtkg1y2uJr+MIFW6aBGlQOP4snCnPUcelfH3xK+N3iD4p+H/C2iaxZ6XBa+GoTBavZxSK7qURMuWdgTiNegHU1t+L/wBoHxR8UvGPgvVNWudN8P3OgTKlvqGmwS/6OrOmZWVncvt25wMZGRg5pKDQXPqbT/ilrWo/th23gKfS9P8A+Eb0lpYrGAWSLJZFbNn85JANw3ZK4zt2vjGea5rwf4N0Xxj+3D45XW7aG6i0uJ7+C3nUMjzKIEUlTwcCQtj1APauq8N/E23sfFVp4w8Z/Er4WNYWUDrJN4diJ1XUl2FUSYEGRVBIfYndQMYr5di+Kcuu/tIXfjfR9fTwtHf38jQ395CZY4othVBMi5yrhVDdcbs9s0ku3YZ9Q/AL4sa/8Q/2ifG+ma5p9j5OkW93FYyR2iRzWUaXMcfkmQAMwYYJDE/MmRjmuc+DWW+HP7Tqry3m6lwOv+pnrqfDPxe0nwNqmteMfGnjn4cTme1ZV03wRH5k+oTZUiWdj87OApUBjtG8kkYr5C8B/tCeKvhv4l8TavocdhJb+IpnlvNOv4jNA+WZhkAqcjew4IyDzmhRbvYLnuXwThkj/Yq+KzshVJLu6KEj7wEFuMj8QR+Fb+r+MbrwL+xb8PdY0+2s5dUju0S0murdJ1tZC9wfNVHBUsFDAZBxuz1ArwS8/al8Y3vgjxB4OOmeHIND1nevk2ti0As0YKCkCo4RVypblWJLMSTmub1343eIPEHwo0X4bXNnpaaFpEyzwTxRSC5Zh5nDMXKkfvW6KOgquVt6iufUfxv0HTfif4T/AGffEOuW9vFqviW9sLPUbuBBGZI7hEMmSOwOSP7uTjqa1fir8QdQ8H/tA/Dv4ZaToelx+CxLp5GnfYYyGZ58CVGxuQx7QQVI5Q5zXyX4w+OviTxp4E8KeDry20220/wx5X2O4tEkS4Jjj2KXYuRnHPAHNfV/h/4g3GrX3hrV/EfxX+FlxpmktHI2rCDy9ekiUhmh2P8A6vfgqxQA4JpNNbjueMft0f8AJcv+4VbfzevmmvX/ANpj4maZ8VvixqOuaLvbSYoYrO2lkUqZlQHL7TyAWLYzzjGQDxXkFaR0SJe4UUUUwOr+L/8AyUTWf+2P/olKKPi//wAlE1n/ALY/+iUorozH/e63+KX5s3xP8afq/wAyT4Sux+I+kjccZn4z/wBMXrkK674Sf8lI0n6z/wDol65Grl/ukP8AFL8oCl/Bj6v8ohXqvxmH2LVdG0qD5LCysV8iLrsyxU8nk8RqOT2+teVV6r8cP+Rss/8ArxT/ANGSVvhv9zrvzh+pdL+BU+X6nDqNqgDoBiql63zKvoM1cqhdtmYj0GK4KvwnNT+IgooormOg/XH4V2dxp3ww8FWd5by293b6LZRTQTIUeN1gQMrKeQQQQQelfMPg2yuf2vfiXr8eu+J7rTvB+lDz7TRbeVY55I8ukTrGdybl3ZkkO4guqDAZdv2XXwP8SfgF47+GXjS41nwNaapNpTzs2n3WhtIbm0WQP+5IVjKNq5UvyrAjJBYqPPwko8zvo+h24iMuVJG18L/F2t/BH43n4bXHiEa74aa+Gl7bdjJFHJI37to1LYhcSSYlUEgHzAd7Kpr7er4j/Z1/Z18RSeLtL8VeKtLl0zSdMcXVvbXYMc9xOpIT5AQ0YR1D5cDdhQAysSPtypxbg5+78ysOpKPvBXyj8b/F2t/EL4x6V8INJ8Qjw7pcxSC/upWMYuJJYi5QkNmRTG6osZ2h5H2nPykfV1fJv7UHwA1vxPrp8aeFLL7dNLAF1GyjY+czRodsyBm+fKKqbEAbKrgMWbE4VxVT3h11Jw904j4q+GNR/ZN+IGk3HgnxVLPY6lGLltNupg0hEfylbmNNqvGxZ9j4Uj5wMMm8/a/h7W7fxLoGla1aJKlrqdrFdxJMAHVJEDqGAJAOCM4J+tfn34a+BnxO+Knikza7ZazaeY8YvtY15ZBIqbSAQJSHmIVNoC5x8oJUHNfoVpOl2mh6VY6XYReTY2MCW0EW4tsjRQqrkkk4AAySTWuMcXazuzPDKSTvsfjneWdxp13cWd5by293byNFNBMhR43U4ZWU8ggggg9KhrtPjB/yVrx7/wBh6/8A/Sh64uu5O6ucbVnYntGxMB6jFX6zYG2zIffFaVdNJ6GFVanTfCa5ltfHlnDE+2O4SWKQYB3KELY9vmRTx6Vx/iS0h0/xFq9pbpst7e7mijTJO1VcgDJ5PArqvhd/yULS/rN/6Keub8Y/8jdr/wD1/wBx/wCjGr0Z64CLfSb/ACR0PXDL/E/yRi0UVtweFr248LXHiKN4DZ29x9nkj3HzRwvz4xjbl0Gc5yw4rzTlMSiuj1XwRq+lz6TbeT9ru9TthdRW9orSSKCSCrLj7wKnIGcVkx6PqM2oHTo7C6fUASptVhYy5HUbMZz+FAFKitCDQdVuryezg0y9lvIATLAkDtJGB13KBkfjV698MS2/iuPw/DOkk8k0UCSyKUXc+3GQMkAFvegDBorp08JW763pulR+INPuZry8js3FrFOWh3MFLESRoCAT0B/xrHTRdQnkjW2srqcTStDEY4WbzXXqq4HJAIOB60BcoUVqReGdbnuprWLR9QkuoGCSQpbOXRiCQCuMgkAnn0NR2eg6rqE0sNppl7cTQuI5EhgZ2RuflIA4Pytx/sn0oAz6Kuto+orpy6i1hdDT2baLowt5RPpvxjP41Z/4RrVIp4YbuxurMzxPNGbi2kHmKiFiQApJGB1AwOpIGSADJoorS0XRLnXbmSG3aKNIY2mmnmfbHDGMZZj6ZIHGSSQACTQBm0VvL4XNxqumafZarpt6+o3C20csDyBUdmCjcHRXA+Yc7fXGcVDpvhm+1Zb/AOyBJJLN44zECd0jPII1CjHPzEdcUBcx6K3tV8MjSopydZ0q4ubc4ltoJXLoc4IBKhHwf7jNSx+Eb2XXNO0gS2/2m/ghnjYs2wLJGJFBOM5wecA80BcwKK6mbwLdR2PnpqWnzXIsV1FrJDIJlgZQ27LIEJAOSAxPWuWoAKKKKQwooooAKKKKACiiigAooooAKKKKAOt+LzsPiJrIDED9z3/6YpRTfi//AMlE1n/tj/6JSiujMf8Ae63+KX5s3xP8afq/zH/CT/kpGk/Wf/0S9cjXX/CUL/wsfSeTnM/b/pi9chVy/wB0h/il+UBS/gx9X+UQr1T4rn+0bPwnrkvF3qNgPNRfuLgK/wAo69ZW6k9B+PldepXB/t/4N2Vx9640O7MUks/LbCcBUPJxiSIYOPuewrfBe/Rr0u8b/wDgLv8Alcuh70KkPK/3P/I4lCSik9SBWfO26ZyfXFW7VsxY7qaos25ix6k5rzqr0RhTWrEoorp/hvq1noHxE8I6tqM3k6fp+rWlzcS7S2yNJkZmwoJOACcAE1zt2Rstz9d6Khs7y31G0t7yzuIri0uI1lhnhcOkiMMqysOCCCCCOtTV4Z6wVzfirx1o3g9UGoTu1zIu9LaFd0jLnGewA69SM4OMkV0lfOXxpsL238ZPc3DO9rdQobYksVVVADIM8AhssQP74Pek3Y9DLMLDFV/Z1HZWv6+R6/4W+JGheLLj7LaSywXp3Fbe5QKzgAElSCQep4zngnGBmuur5Y+G1he3/jXSBZM6NDMJpXUsAsS8vkjoCPl54JYA9a+p6E7l5rg6eFqqNN6NX9AooopnmH5K/GD/AJK149/7D1//AOlD1xdeqftI+ItL8V/GvxXqui3sV9psskEcdzCcpIY4I42Kn+IbkYBhwcZBIINeV17cPhR5U/iYqttYMOoOa1aya0JJP9H3HGWX+ddFJ7mFVbHafBqyjvPGfnyM4e0tpJk24wWOE59sOfxxXnupX8mqajeX0yos11M8zhAQoZmJOM9ua9J8Cn+w/Avi7Xz8rtGLOCWHiaJyMZB4wN0kZ4P8PTgV5ZXpYn3MJRp9XzSfzdl+RvV92jCPe7/T9ArtvD3iyy0Pw9a208Avs3tw1zYsSglheKNR8+CB8yZHXlRxXE0V5xy2PSm8X2Or6ctveal9mv77TZoJ7sxuVhla+ecq20E7WQgEqDjcB6ioZfEWl3N1qFj/AGk0az6RBpy6q8T4d42RiWABfYwQp0zgLkdRXndFFxWPStQ8Q6Tqun3GkprRtZIlsv8AiZSRS4u/IR1YEKC4wXG3I6IM7eMZmp+INPufilDraXbyaauoQTtcOjBiilNzFcZzweK4iii47Ho1xrdpH4q0TUptb0G5s7fVIrhxp2mNbyxxiQMWci3jLAAdMsc9qiuPEtjfaxZanb6hFYqYJLOSxngkaCBChU7dgyI3DEnHzhiTz94+fUUXCx6kp0i58O+JYbLWfsdo8mnRtORO0HmBZyUXIMnl8ZGQTkDtzWTr/iqzvrPxRHa3cu6/nsFUsrK1ykMUivI3puba2Cc5b2NcQtzMkElussiwSsrvGGIVmXO0kdCRuOPTJ9aiouKx6fe+MdKm0zz7U6dDcSadFYPE0V29yu1FU4HmCDbuXcDwf9nOSWyeINEXUE1CbUoZb+4F6072kc6xMZLZ1Uukg4kLsB8nygGvMqKLhY1dDu/sh1H/AImH2LzbOWL/AFPmefnH7r/Z3f3u2Ku+FdTsraLWdN1CVre11W1EH2lUL+S6yJIrEDkrlMHHODnnGK52igdjvjr2l6IvhgxTWGo3uk6it09xY2XkboV8sqjMyIztlWOWB69at6L4j0fwTd3V/Z6iuqvdXtvKkMcMkZjijl8w7y6gBzgABdw6nPHPm1FFwsdwJtB0nR9ct4tTsdShvIiLONtOIuoZC6EM0jp8uFVgQjkZPSrtnrujLqejeIpNSVJ9OsIoG08wyGWSWKHy12sBs2nCkksCMng151RRcLHZ+I/Gk89pZWGm3EK2n9mW1rcNHaokrFY1DoZdocruHTOOPSuMoooCwUUUUhhRRRQAUUUUAFFFFABRRRQAUUUUAdX8X/8Akoms/wDbH/0SlFO+LwX/AIWJrOSc/ue3/TFKK6Mx/wB7rf4pfmzfE/xp+r/MX4Sf8lI0n6z/APol65Guu+En/JSNJ+s//ol65Gqf+6Q/xT/KApfwY+r/ACiFen/B7U4bibVvC95JKtvrEDCMq5+VgrBgowQCUJOT/wA8wOeK8wqezu5tPu7e7t32XFvIssb4B2spyDg8HkUYPEPDVo1d0t/NPR/gKhV9lUUy9NDPpl3dWk6+XPAzRSLkHa6kgjI4PIqlXpHxGsF16w07xpp0D/ZdQhVbsLkiGVfl5J7ZGzIAGUH94V5vUY+h7Cq6d7rdPunszSdL2cmunTzXQKKlt4fOcgttRVLM2M4A9qf5dn/z+/8AkI1xEtpH1B+zJ+03Z+ANPTwd4xfyvDkXmSWOoRQl2tGYl2jkVAWdGYsQwBZWbBypBT7ws7y31G0t7yzuIri0uI1lhnhcOkiMMqysOCCCCCOtfjf5dn/z+/8AkI16d8NPj14t+FWyDRvEX2jSVz/xK9Qhea1Gd5+Vcho/mcsfLZdxxuz0rkrYXnfNHc6KWJUdJbH6kVBd2dtqFu9vd28VxbvjdFMgdWwcjIPB5ANec/CH4uv8W9CstWs/DF7b2s8ksU1zHeWs0Fu6Z+Vv3izAkbTgxA/OD90hj6gYnBxtP5VwypTjujshWi9YspWGm2WlwtDY2dvaws28pBGqKWwBnAHXgflVqneW5/hP5VxXxJ8fS/DjQtS1ifw/e3mn2Nobh7tbq1ht1fkLGxklD5LbR8qOTvAUM3y0o0py2Q51Y7yZ2dfG37Sf7U+l3eiX3g3wLdxX7X8ctrqWqBMxRxHKPFFuGHLDOZBlQpG0ktuTxr4pftNeLfib9psv7Z/sXQJdyf2dpyOnmRneNssv3pMo+1hwjbQdgNeL+XZ/8/v/AJCNd1HCcr5pnHVxSekSvRVjy7P/AJ/f/IRps8CxrG8cnmRSA4bGOh54rsOa6ZDUzyFoo1z0FQ13nww0BbrVH12/V00fRla5kmKkqXQbgBg5JH3+AfugEfMK6sHQlXrKlHr+Hd/IcaTqyUUafxDuf+Ea8FeHvCSmVLtkF1dqZPu5LHYcDawMhbHPHljrkGvKK1PEetzeI9cvtUnG17mTcE4OxRwq5AGcKAM45xmsuujHYhV6zlD4VZL0Wi/zJxFRVJ3Wy0XogooqxbW3m/vJMiIHGR1Y+g/x7fkDyGBXorSxbjgWsZA7szZP1wRS/uP+fSL/AL6f/wCKp8ouYzKK0/3H/PpF/wB9P/8AFUfuP+fSL/vp/wD4qjlDmMyitP8Acf8APpF/30//AMVR+4/59Iv++n/+Ko5Q5jMorT/cf8+kX/fT/wDxVH7j/n0i/wC+n/8AiqOUOYzKK0/3H/PpF/30/wD8VR+4/wCfSL/vp/8A4qjlDmMyitP9x/z6Rf8AfT//ABVH7j/n0i/76f8A+Ko5Q5jMorT/AHH/AD6Rf99P/wDFUfuP+fSL/vp//iqOUOYzKK0/3H/PpF/30/8A8VR+4/59Iv8Avp//AIqjlDmMyitP9x/z6Rf99P8A/FUfuP8An0i/76f/AOKo5Q5jMorT/cf8+kX/AH0//wAVR+4/59Iv++n/APiqOUOYzKK0/wBx/wA+kX/fT/8AxVH7j/n0i/76f/4qjlDmMyitP9x/z6Rf99P/APFUfuP+fSL/AL6f/wCKo5Q5jMorT/cf8+kX/fT/APxVH7j/AJ9Iv++n/wDiqOUOYzKK0/3H/PpF/wB9P/8AFVWuLZVUyQ7jGPvKxyV/xHv+HpkaC5VoooqSjq/i/wD8lE1n/tj/AOiUoo+L/wDyUTWf+2P/AKJSiujMf97rf4pfmzfE/wAafq/zH/CT/kpGk/Wf/wBEvXI11/wldj8R9JG44zPxn/pi9chVy/3SH+KX5QFL+DH1f5RCiiiuQxNe28QX0OhT6GkuNPmnW5ZBwSwGMZHUH5Tg55RSMc5oVHF3qeGIzSpGM5Y44GcVNScptKTvbQ2i20rkkzfZ7DYfv3BBx6KOh/E1nVav5hNcttx5cfyJg54HvVWsmQFFFFID6J/ZG+NX/CtfHS6JrWqfZvCGuZSb7RLtgtLnA8uc/KdudojY5UYYMxxGMfpfX4j1+lH7Ifxxk+JnhGTw7rd1NP4q0CNfMuLmZGkvrcsQkgHDEp8qOSDyUYsWcgDGj6Qr4H/ba+NX9taxB8PtA1Tfpmn5fWPs0uUmuQ3ywP8ALz5W3cQGI3PggNFx9MftIfGSL4OfD6e8t23eIdU32elxq8e6OUoc3BV87kj4J+VgWZFOA2R+V17e3OpXlxeXlxNc3lzI0s08zl5JXY5ZmY8kkkkk8kmhAyCiiigQVoWTefbS238YPmp7kDkflWfUttO1tPHKvVTnHqO4poCWtCLxBfWmiXujRS4sb2RJJUPPKc8dhk7ckcnYvOODWu4hDOypzGfmU9iDVWX7o+ta05yhK8Xbp95o5NK6IqKKKowCtIcWlqBwChY+53MM/kB+VZtaf/Lraf8AXM/+htVRJkMoq1pmnXGr6lZ6fZxmS7vJkgiQfxOxCqPzIr234i/Dyxt5NCmudJufDui6fqQ0C6vpLFoftMKhSl5yBvZ8TEtz0X2p3JPCKK9KuPCNjbW/iCe1tbu2tU0ZrmEz3FtfJIy3UMZKTom3GHOdoVlPBOCQdTwv4Q8N/wBu+Dri3trvVrOS/sEvJxdwSQM0pXdHJBsLxAOSvz7g4UgYyCC4HkNFeo6P4M0DxD/b2sRQXFtpdjdRWkdjca3aW0jyOJGLfaJkRAoEZwgQsc9cAmp38BeEdLNuLy+1DUVvNbk0uCbTbqDyxEI4HEhYK6symfBVTgkcMuOS4Hk9Fa0nh+6bxO/h+1Hn3pvTYxgDHmPv2D8zXuPif4fQ2niHwZOPDEmn6dp+vQaBP9psTEmoxKyFLhgygSeZibceeAo9KLgfPFFeifD6xtLj4rG2nhsjao1+Ql1AJYE2QTFS0ZVgQpAONp6dDWvqy6Drukai1rPpt1q+m6NLPeXml6attbTMbuBYwsbxJtYK7ZdEQnIGSN2S4HklFeoeLfBfhfSJvFMGm/2w7+Gr6OGdrm4ixdRNIUYLiP8AdsCAAx3A8naOlXPFHhzQtR+KPiSx03w5fDT7CWf7RHHq9tZwxESBQ4keARxR8hQhzyRhuxLgeR0V6pq3w/8AD3hmLxDeam+o3VtZHTWtIbO7gzIt1DJIVaZVdDt2YDoCGwcD5gRgfDKxspNYvtT1VIDpWlWck87zw+csTPiGF/K6SbZZYyVPBAOfSi4HFUV2HjfwvqmlFNW1GPTYI76Yx24sFCRXKqiEzxKo2+W29eRgbiRtGCB3mkeEtH8UeAvCVo9va2d5bxy6peXyRqsstmt1LHcbm6uUURsoPQBqLgeJ0V6z8TtF0q9h1PxFZWMWmlYtEMVlZoscCC6spJZPlA67o15z3Oc543vCnhvS9G13UtDnglvNMXxLoUTRTspMgcT8NlSCuW5GORkcZzRcDwiivQW0PTdZ0rxLLo1u9ksWo2VvDFqF1bsAXFxuJnaOMIuUHAKj+9uwCNbwPpaaP4f8Ztd3fhq1v7OexjS+1C2i1O3QP5xZUKRTqS2F5Ufw4JGKLgeUUV7VYaboH9h3+paxZJqhuNBuLsPpyQWSKy6p5W6L/R8rkYwWXKqWXABAXldN8E6bqOoeDYhJeJDrtjc3cw8xS0ZjmuUUKdvTbAmcjqT0yAC4zz+iuv8AGejaF4ft9JtbFdRk1O5sLO+uJp5k8lPOgWRo1QJk8sCGLcDjB+9XIUCCiiimAVJDz5oPIMT5HrhSR+oB/Co6lg6yf9cpP/QDQgMqiiiszQ6v4v8A/JRNZ/7Y/wDolKKd8XnYfETWQGIH7nv/ANMUorozH/e63+KX5s3xP8afq/zF+En/ACUjSfrP/wCiXrka674Sf8lI0n6z/wDol65Gqf8AukP8U/ygKX8GPq/yiFFFFcpiSxfdP1q5C32e2muD1x5aeu4989sCqKybRjFaV1bLNFbxpdWwWJTndJzuPX8Kzad7mnMrWMiir39m/wDT3af9/P8A61H9m/8AT3af9/P/AK1Tysm5Roq9/Zv/AE92n/fz/wCtWnaeCNa1C3S4tLOW4t3ztlhid1bBwcELg8giqjSnN2irlJOWiOersPhf8RdW+FfjXTPEukzTBraRRc28cmwXluWBkgYkEYYDqQdpAYcqCK//AArzxH/0C7r/AMB5P/iaxv7Lb/n5tf8Av5/9anOjUh8UWgcXHdHofx8+Ml78aPHVxq267h0G2/c6XYXDqfs8WAGYheA7ldzfeI4XcwRa8tq//Zbf8/Nr/wB/P/rVrQ+AtfuIo5odPuJIpFDI6QyFWB5BBC8ilClOekYtgk5bHNUV0s3gLXreGSabT7iOGNS7u8MgVVAySSV4ArI/s3/p7tP+/n/1qJ0pw+KLQNOO6KNFXv7N/wCnu0/7+f8A1qP7N/6e7T/v5/8AWqeVk3JFb7RYI38dudrZ6lT05/TFVX+4av2VqtvKxe6tjG6FG2yc4PpWfI21nTg4JGVOQapJlcytYiooorQzCtP/AJdbT/rmf/Q2rMq/bSieJID/AK1MhP8AaB52/XOT75+gNRJZf0bWL3w/qdvqWnTeRfW5LRS7VYoSCMgEEZ54PY8jmrGj+JtV0CK6i067MEd2YzKuxWDFG3KfmBwQfTsSDwSDlMpUlWBBHBB7UlUSdHf+Ote1FJopruJIJrY2bQW9rDDEIjIshCoihVJdFJIAJxyaVvH3iA2lvarfLEkEkUokht4o5XaM5jLyKoeTaeRuJxXN0UgOmTx/rsV/eXqS2SveqouIRp1t9nm28qzQ+X5ZYEk7tueTzzVO48W6xdeR5t4W+z3jX8f7tPlmYICw46YiQbeg28DrWLRQBq2fiTU9P17+3ba58vVvNecXHlqSJGzlgCMA8kjjg8jGBT9D8U6t4b83+zLvyBLJDK4MaOC8UgkjbDA4IYZ+hIPBIOPRQBo2GvahpmqvqlrceXfuJQZdinPmKyvwRjlXYdOM8VFY6rd6bFfRWs3lx38H2a4G0HfHvV9vI4+ZFORg8fWqdFAGxe+KtX1GXWZbm78x9akEt6fLQecwfeDwPl+bn5cVpH4jeImvpL17m0e4mg+zzs+n27C5TcG/eqY8StlVO5wzZA5rlaKAN/WPG2u6/Hdx6jfeel2bcyjykXd5CMkX3VGNquw4655zgVT0PxBqPhu8e6024EMskbQyBo1kSWM9UdHBVlOBwwI4FZlFAG9rvjPWvEtpb2mp3Uc1tauXgiS3ijWDIAKoEUbEOAdi4XPOM81nXerXl9ZafZXE2+209Hjt02geWrOXYZAycsxPOetUqKAOltvH/iC0lkkS8ifzLaC0ZJrWGWMxwIEi+R0K7kUABsbupzkmo7jx14hury9vJdSka7vbqC9mmCKGaaHd5b5A4I3N0xnPOa56igDb1PxbqurR38dxJbLFfyRS3EdvaQwLI8YcI2I0UA/vHyR1zzniqNvq95a6Ze6ZFNtsr145J49oO9o92w5xkY3t0POeapUUAb+neNdb0oWi291EY7S2ezjimtopYzC8hkZGR1KuC7FvmB5x6CrWl/EbxJo1qltY30UUcZk8o/ZIWeISZ3qjFCyI2TlVIXk8Vy1FAFzUtVu9XmhmvZvNkhgitkO0LiONAiLwB0VQM9TjnNU6KKYBRRRQAVLB1k/65Sf+gGoqdM/2RHVgRO6lQp6oD1J+oyMe+fTIMzaKKKzLOr+L/wDyUTWf+2P/AKJSij4v/wDJRNZ/7Y/+iUorozH/AHut/il+bN8T/Gn6v8yT4Shf+Fj6Tyc5n7f9MXrkK674Sf8AJSNJ+s//AKJeuRq5f7pD/FL8oCl/Bj6v8ohRRRXIYhRRRQAUUUUAFT2l5c6fcJcWlxLb3CZ2ywuUZcjBwRyOCRUFFNNp3QJ21R11p8T/ABbZW6QRazKyJnBmjSVuTnlmUk9e5rof+F6+Iv8Any0r/v1J/wDHK8wortp5ni6atGq/vv8AmbxxVaOimz0//heviL/ny0r/AL9Sf/HKxLz4seLbz7Qv9qeTFNuGyGFF2A9lbG4Y7HOffNcXRTnmeMmrOq/vt+Q5YutLebLV/qV7qkyzX15cXUyrsDzyM7Bck4yT05P51VooricnJ3bOdtvVhRRRUgFFFFABRRRQAUUUUAWFvrpFCrczBQMABzgCl/tC7/5+p/8Av4arUU7sViz/AGhd/wDP1P8A9/DR/aF3/wA/U/8A38NVqKLsLFn+0Lv/AJ+p/wDv4aP7Qu/+fqf/AL+Gq1FF2Fiz/aF3/wA/U/8A38NH9oXf/P1P/wB/DVaii7CxZ/tC7/5+p/8Av4aP7Qu/+fqf/v4arUUXYWLP9oXf/P1P/wB/DR/aF3/z9T/9/DVaii7CxZ/tC7/5+p/+/ho/tC7/AOfqf/v4arUUXYWLP9oXf/P1P/38NH9oXf8Az9T/APfw1WoouwsWf7Qu/wDn6n/7+Gj+0Lv/AJ+p/wDv4arUUXYWLP8AaF3/AM/U/wD38NH9oXf/AD9T/wDfw1WoouwsWf7Qu/8An6n/AO/ho/tC7/5+p/8Av4arUUXYWLP9oXf/AD9T/wDfw0f2hd/8/U//AH8NVqKLsLFn+0Lv/n6n/wC/ho/tC7/5+p/+/hqtRRdhYs/2hd/8/U//AH8NVqKKLgFFFFIZ1vxeC/8ACxNZyTn9z2/6YpRTfi//AMlE1n/tj/6JSiujMf8Ae63+KX5s3xP8afq/zMnwZra+HPGGmalIUWGGfbKzqWCxtlXOBzkKxI9x0PSneKdFbw74h1LTCHC28xEe9gzGM8oSRxkqQfx7Vz0n+sf6mu107X9I1/SLDRvEJezmsVZLbWUVpWWPORFJH1ZeWAIPy/KAMbiXQlGpTdCTs73V9rvRryvZavTTXfQhacORu3Vf5HKUV2g+F2vXXz6U2n6vbjhriwvI2jVu6ksQc4wenQij/hUvjH/oD/8AkzD/APF1f9n4rpSk/RNi+rVv5H9xxdFdp/wqXxj/ANAf/wAmYf8A4uj/AIVL4x/6A/8A5Mw//F0f2fi/+fUv/AX/AJB9WrfyP7mcXRXaf8Kl8Y/9Af8A8mYf/i6P+FS+Mf8AoD/+TMP/AMXR/Z+L/wCfUv8AwF/5B9WrfyP7mcXRXaf8Kl8Y/wDQH/8AJmH/AOLo/wCFS+Mf+gP/AOTMP/xdH9n4v/n1L/wF/wCQfVq38j+5nF0V2n/CpfGP/QH/APJmH/4uj/hUvjH/AKA//kzD/wDF0f2fi/8An1L/AMBf+QfVq38j+5nF0V2n/CpfGP8A0B//ACZh/wDi6P8AhUvjH/oD/wDkzD/8XR/Z+L/59S/8Bf8AkH1at/I/uZxdFdp/wqXxj/0B/wDyZh/+Lo/4VL4x/wCgP/5Mw/8AxdH9n4v/AJ9S/wDAX/kH1at/I/uZxdFdp/wqXxj/ANAf/wAmYf8A4uj/AIVL4x/6A/8A5Mw//F0f2fi/+fUv/AX/AJB9WrfyP7mcXRXaf8Kl8Y/9Af8A8mYf/i6P+FS+Mf8AoD/+TMP/AMXR/Z+L/wCfUv8AwF/5B9WrfyP7mcXRXaf8Kl8Y/wDQH/8AJmH/AOLo/wCFS+Mf+gP/AOTMP/xdH9n4v/n1L/wF/wCQfVq38j+5nF0V2n/CpfGP/QH/APJmH/4uj/hUvjH/AKA//kzD/wDF0f2fi/8An1L/AMBf+QfVq38j+5nF0V2n/CpfGP8A0B//ACZh/wDi6P8AhUvjH/oD/wDkzD/8XR/Z+L/59S/8Bf8AkH1at/I/uZxdFdp/wqXxj/0B/wDyZh/+Lo/4VL4x/wCgP/5Mw/8AxdH9n4v/AJ9S/wDAX/kH1at/I/uZxdFdp/wqXxj/ANAf/wAmYf8A4uj/AIVL4x/6A/8A5Mw//F0f2fi/+fUv/AX/AJB9WrfyP7mcXRXaf8Kl8Y/9Af8A8mYf/i6P+FS+Mf8AoD/+TMP/AMXR/Z+L/wCfUv8AwF/5B9WrfyP7mcXRXaf8Kl8Y/wDQH/8AJmH/AOLo/wCFS+Mf+gP/AOTMP/xdH9n4v/n1L/wF/wCQfVq38j+5nF0V2n/CpfGP/QH/APJmH/4uj/hUvjH/AKA//kzD/wDF0f2fi/8An1L/AMBf+QfVq38j+5nF0V2n/CpfGP8A0B//ACZh/wDi6P8AhUvjH/oD/wDkzD/8XR/Z+L/59S/8Bf8AkH1at/I/uZxdFdp/wqXxj/0B/wDyZh/+Lo/4VL4x/wCgP/5Mw/8AxdH9n4v/AJ9S/wDAX/kH1at/I/uZxdFdp/wqXxj/ANAf/wAmYf8A4uj/AIVL4x/6A/8A5Mw//F0f2fi/+fUv/AX/AJB9WrfyP7mcXRXaf8Kl8Y/9Af8A8mYf/i6P+FS+Mf8AoD/+TMP/AMXR/Z+L/wCfUv8AwF/5B9WrfyP7mcXRXaf8Kl8Y/wDQH/8AJmH/AOLo/wCFS+Mf+gP/AOTMP/xdH9n4v/n1L/wF/wCQfVq38j+5nF0V2n/CpfGP/QH/APJmH/4uj/hUvjH/AKA//kzD/wDF0f2fi/8An1L/AMBf+QfVq38j+5nF0V2n/CpfGP8A0B//ACZh/wDi6P8AhUvjH/oD/wDkzD/8XR/Z+L/59S/8Bf8AkH1at/I/uZxdFdp/wqXxj/0B/wDyZh/+Lo/4VL4x/wCgP/5Mw/8AxdH9n4v/AJ9S/wDAX/kH1at/I/uZxda/hbRW8ReIdO0wBytxMBJsYKwjHLkE8ZCgn8O9bp+F2vWvz6q2n6Rbnhbi/vI1jZuygqSc4yenQGq2o6/pGgaRf6N4eL3k18qpc6y6tEzR5yYo4+qrwoJJ+b5gRjaQ44WVFqeJXKl0ejfklvr3tZfm40XB3qqy/FmP431tfEfizVtSjKNDNMViZFKho1AVDg85KqCfc9B0orAorhq1JVZyqS3bv95nKTlJyfUkkkcOwDN1Pem+Y/8Afb86KKgkPMf++3504SPsY7m6jv8AWiigBvmP/fb86PMf++350UUAHmP/AH2/OnSSOHYBm6nvRRQA3zH/AL7fnR5j/wB9vzoooAcJH2MdzdR3+tN8x/77fnRRQAeY/wDfb86PMf8Avt+dFFADpJHDsAzdT3pvmP8A32/OiigA8x/77fnThI+xjubqO/1oooAb5j/32/OjzH/vt+dFFAB5j/32/OnSSOHYBm6nvRRQA3zH/vt+dHmP/fb86KKAHCR9jHc3Ud/rTfMf++350UUAHmP/AH2/OjzH/vt+dFFADpJHDsAzdT3pvmP/AH2/OiigA8x/77fnThI+xjubqO/1oooAb5j/AN9vzo8x/wC+350UUAHmP/fb86dJI4dgGbqe9FFADfMf++350eY/99vzoooAcJH2MdzdR3+tN8x/77fnRRQAeY/99vzo8x/77fnRRQA6SRw7AM3U96b5j/32/OiigA8x/wC+3504SPsY7m6jv9aKKAG+Y/8Afb86PMf++350UUAHmP8A32/OnSSOHYBm6nvRRQA3zH/vt+dHmP8A32/OiigBwkfYx3N1Hf603zH/AL7fnRRQAeY/99vzooooA//Z",
	"semangat": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4lkkcOwDN1Pem+Y/99vzok/1j/U138ssXw8ht7W1t0Hi4Lvurt/3i2gbBEcYI2ltuMtg43MATnjac2moxV2/6+41w2GVVSqVJcsI2u7X32SXVvWyutm20kZVj8O/FuowtLDpFyqhtuJ2WFs8fwuQcc9elWx8LPGO0/wDErbOR/wAvUX/xdc7e6jeanKJb27nuZVXaHnkLsB1xk9uT+dVqXJX/AJl9z/zN/aZctPZzf/b8V+Hs3+bOp/4VZ4y/6Bbf+BUX/wAXR/wqzxl/0C2/8Cov/i65aij2df8AnX/gL/8Akg9rl3/Pqf8A4Mj/APKzqf8AhVnjL/oFt/4FRf8AxdOf4WeMSzY0tsZ4/wBKi/8Ai65Sij2df+df+Av/AOSD2uXf8+p/+DI//Kzqf+FWeMv+gW3/AIFRf/F0f8Ks8Zf9Atv/AAKi/wDi65aij2df+df+Av8A+SD2uXf8+p/+DI//ACs6sfCzxjtP/ErbOR/y9Rf/ABdN/wCFWeMv+gW3/gVF/wDF1y1FHs6/86/8Bf8A8kHtcu/59T/8GR/+VnU/8Ks8Zf8AQLb/AMCov/i6P+FWeMv+gW3/AIFRf/F1y1FHs6/86/8AAX/8kHtcu/59T/8ABkf/AJWdW/ws8YlmxpbYzx/pUX/xdN/4VZ4y/wCgW3/gVF/8XXLUUezr/wA6/wDAX/8AJB7XLv8An1P/AMGR/wDlZ1P/AAqzxl/0C2/8Cov/AIunD4WeMdp/4lbZyP8Al6i/+LrlKKPZ1/51/wCAv/5IPa5d/wA+p/8AgyP/AMrOp/4VZ4y/6Bbf+BUX/wAXR/wqzxl/0C2/8Cov/i65aij2df8AnX/gL/8Akg9rl3/Pqf8A4Mj/APKzqf8AhVnjL/oFt/4FRf8AxdOf4WeMSzY0tsZ4/wBKi/8Ai65Sij2df+df+Av/AOSD2uXf8+p/+DI//Kzqf+FWeMv+gW3/AIFRf/F0f8Ks8Zf9Atv/AAKi/wDi65aij2df+df+Av8A+SD2uXf8+p/+DI//ACs6sfCzxjtP/ErbOR/y9Rf/ABdN/wCFWeMv+gW3/gVF/wDF1y1FHs6/86/8Bf8A8kHtcu/59T/8GR/+VnU/8Ks8Zf8AQLb/AMCov/i6P+FWeMv+gW3/AIFRf/F1y1FHs6/86/8AAX/8kHtcu/59T/8ABkf/AJWdW/ws8YlmxpbYzx/pUX/xdN/4VZ4y/wCgW3/gVF/8XXLUUezr/wA6/wDAX/8AJB7XLv8An1P/AMGR/wDlZ1P/AAqzxl/0C2/8Cov/AIunD4WeMdp/4lbZyP8Al6i/+LrlKKPZ1/51/wCAv/5IPa5d/wA+p/8AgyP/AMrOp/4VZ4y/6Bbf+BUX/wAXR/wqzxl/0C2/8Cov/i65aij2df8AnX/gL/8Akg9rl3/Pqf8A4Mj/APKzqf8AhVnjL/oFt/4FRf8AxdOf4WeMSzY0tsZ4/wBKi/8Ai65Sij2df+df+Av/AOSD2uXf8+p/+DI//Kzqf+FWeMv+gW3/AIFRf/F0f8Ks8Zf9Atv/AAKi/wDi65aij2df+df+Av8A+SD2uXf8+p/+DI//ACs6sfCzxjtP/ErbOR/y9Rf/ABdN/wCFWeMv+gW3/gVF/wDF1y1FHs6/86/8Bf8A8kHtcu/59T/8GR/+VnU/8Ks8Zf8AQLb/AMCov/i6P+FWeMv+gW3/AIFRf/F1y1FHs6/86/8AAX/8kHtcu/59T/8ABkf/AJWdW/ws8YlmxpbYzx/pUX/xdN/4VZ4y/wCgW3/gVF/8XXLUUezr/wA6/wDAX/8AJB7XLv8An1P/AMGR/wDlZ1P/AAqzxl/0C2/8Cov/AIunD4WeMdp/4lbZyP8Al6i/+LrlKKPZ1/51/wCAv/5IPa5d/wA+p/8AgyP/AMrOp/4VZ4y/6Bbf+BUX/wAXR/wqzxl/0C2/8Cov/i65aij2df8AnX/gL/8Akg9rl3/Pqf8A4Mj/APKzqf8AhVnjL/oFt/4FRf8AxdOf4WeMSzY0tsZ4/wBKi/8Ai65Sij2df+df+Av/AOSD2uXf8+p/+DI//Kzqf+FWeMv+gW3/AIFRf/F0f8Ks8Zf9Atv/AAKi/wDi65aij2df+df+Av8A+SD2uXf8+p/+DI//ACs6G++HfizTrfzJtIuWDOFAgZZm6HshJA469K5TzH/vt+dadlqN5pkplsrue2lZdpeCQoxHXGR24H5V1kUsXxDhuLW6t0Pi4rvtbtP3a3YXJMcgA2htucNgZ2qCRjlSlUpq87Nd1pb5a6fMqNDDYp8mGvGfRSalfyTSWr6Ll12ve1+A8x/77fnRTaK2PMOs+HdjHqPjzSIZWcKs5mBQ87o1Lj8MqM+1ZGo3smp6hd3soVZbmV5nCDCgsSTjPbmui+FgX/hYWl8nOZu3/TJ65Ssofx5ei/Nno1NMup26zn+Eadvzf3ntnwo17w5p/h5oZLm1stRDk3LXDiMy8nYQSeQF4wOhzxzk95/wlmgf9BzTP/AuP/GvleiuOtlMKtR1HJ6n0OA4zr4PDQw8aUWoq3Vf0+/d6n1R/wAJZoH/AEHNM/8AAuP/ABo/4SzQP+g5pn/gXH/jXyvRWX9iU/52df8Ar9iP+fMfvZ9Uf8JZoH/Qc0z/AMC4/wDGj/hLNA/6Dmmf+Bcf+NfK9FH9iU/52H+v2I/58x+9n1R/wlmgf9BzTP8AwLj/AMaP+Es0D/oOaZ/4Fx/418r0Uf2JT/nYf6/Yj/nzH72fVH/CWaB/0HNM/wDAuP8Axo/4SzQP+g5pn/gXH/jXyvRR/YlP+dh/r9iP+fMfvZ9Uf8JZoH/Qc0z/AMC4/wDGj/hLNA/6Dmmf+Bcf+NfK9FH9iU/52H+v2I/58x+9n1R/wlmgf9BzTP8AwLj/AMaP+Es0D/oOaZ/4Fx/418r0Uf2JT/nYf6/Yj/nzH72fVH/CWaB/0HNM/wDAuP8Axo/4SzQP+g5pn/gXH/jXyvRR/YlP+dh/r9iP+fMfvZ9Uf8JZoH/Qc0z/AMC4/wDGj/hLNA/6Dmmf+Bcf+NfK9FH9iU/52H+v2I/58x+9n1R/wlmgf9BzTP8AwLj/AMaP+Es0D/oOaZ/4Fx/418r0Uf2JT/nYf6/Yj/nzH72fVH/CWaB/0HNM/wDAuP8Axo/4SzQP+g5pn/gXH/jXyvRR/YlP+dh/r9iP+fMfvZ9Uf8JZoH/Qc0z/AMC4/wDGj/hLNA/6Dmmf+Bcf+NfK9FH9iU/52H+v2I/58x+9n1R/wlmgf9BzTP8AwLj/AMaP+Es0D/oOaZ/4Fx/418r0Uf2JT/nYf6/Yj/nzH72fVH/CWaB/0HNM/wDAuP8Axo/4SzQP+g5pn/gXH/jXyvRR/YlP+dh/r9iP+fMfvZ9Uf8JZoH/Qc0z/AMC4/wDGj/hLNA/6Dmmf+Bcf+NfK9FH9iU/52H+v2I/58x+9n1R/wlmgf9BzTP8AwLj/AMaP+Es0D/oOaZ/4Fx/418r0Uf2JT/nYf6/Yj/nzH72fVH/CWaB/0HNM/wDAuP8Axo/4SzQP+g5pn/gXH/jXyvRR/YlP+dh/r9iP+fMfvZ9Uf8JZoH/Qc0z/AMC4/wDGj/hLNA/6Dmmf+Bcf+NfK9FH9iU/52H+v2I/58x+9n1R/wlmgf9BzTP8AwLj/AMaP+Es0D/oOaZ/4Fx/418r0Uf2JT/nYf6/Yj/nzH72fVH/CWaB/0HNM/wDAuP8Axo/4SzQP+g5pn/gXH/jXyvRR/YlP+dh/r9iP+fMfvZ9Uf8JZoH/Qc0z/AMC4/wDGj/hLNA/6Dmmf+Bcf+NfK9FH9iU/52H+v2I/58x+9n1R/wlmgf9BzTP8AwLj/AMaP+Es0D/oOaZ/4Fx/418r0Uf2JT/nYf6/Yj/nzH72fVH/CWaB/0HNM/wDAuP8Axo/4SzQP+g5pn/gXH/jXyvRR/YlP+dh/r9iP+fMfvZ9Uf8JZoH/Qc0z/AMC4/wDGj/hLNA/6Dmmf+Bcf+NfK9FH9iU/52H+v2I/58x+9n1R/wlmgf9BzTP8AwLj/AMaP+Es0D/oOaZ/4Fx/418r0Uf2JT/nYf6/Yj/nzH72fQPxA8SeGLvwtewy3tnfSupFvHBKsjrLg7W+U8Adz6ZHOcHwfTr2TTNQtL2IK0ttKkyBxlSVIIzjtxVaiu/C4SOHg4J3TPms3zqrmeIjiJRUXFWVvv3N34kWMeneONahiZyrSiYlzzukUOfwyxx7UVc+KwX/hPtXyTn9z2/6YpRTwzbowb7L8jnzaKhj68Y7Kcv8A0ph8LP8Akoel/Wb/ANFPXLV1Pws/5KHpf1m/9FPXLU6f8efpH85Dq/8AIuo/46n/AKTTCiiiuk80KKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKK2NL0uF7b7dfeYbMu0SRwsFeVwAW+YghQoZSSQc5AA6lU3YunTc3ZfN9v6/wCAtTHorqftWm/9C/p//fy4/wDjtH2rTf8AoX9P/wC/lx/8dpXl/K/w/wAzX2NP/n7H/wAm/wDkTlqK6n7Vpv8A0L+n/wDfy4/+O0fatN/6F/T/APv5cf8Ax2i8v5X+H+Yexp/8/Y/+Tf8AyJy1FdT9q03/AKF/T/8Av5cf/HaPtWm/9C/p/wD38uP/AI7ReX8r/D/MPY0/+fsf/Jv/AJE5aiup+1ab/wBC/p//AH8uP/jtH2rTf+hf0/8A7+XH/wAdovL+V/h/mHsaf/P2P/k3/wAictRXU/atN/6F/T/+/lx/8do+1ab/ANC/p/8A38uP/jtF5fyv8P8AMPY0/wDn7H/yb/5E5aiup+1ab/0L+n/9/Lj/AOO0fatN/wChf0//AL+XH/x2i8v5X+H+Yexp/wDP2P8A5N/8ictRXU/atN/6F/T/APv5cf8Ax2j7Vpv/AEL+n/8Afy4/+O0Xl/K/w/zD2NP/AJ+x/wDJv/kTlqK6dtPstadLe0s1stQkIWFYpGaGU9lIcllYk4DbtvQEDJYcxTTvo1YzqUuRJp3T6q/62YUVs6VpUD2v9oah5psjI0McUDhZJnABb5iCFChlJJBzkADqV0/tmmf9C5pv/f25/wDj1TKoouxwTxajK0YuXpb9Wv68zk6K6z7Zpn/Quab/AN/bn/49R9s0z/oXNN/7+3P/AMeqfbRI+uf9O5f+S/8AyRydFdZ9s0z/AKFzTf8Av7c//HqPtmmf9C5pv/f25/8Aj1Htoh9c/wCncv8AyX/5I5Oius+2aZ/0Lmm/9/bn/wCPUfbNM/6FzTf+/tz/APHqPbRD65/07l/5L/8AJHJ0V1n2zTP+hc03/v7c/wDx6j7Zpn/Quab/AN/bn/49R7aIfXP+ncv/ACX/AOSOTorrPtmmf9C5pv8A39uf/j1UtR0u1urWe+06N4fs4D3Ns77gqlgodGIzt3MF2nLDIOWyxVxqxbsVDFptKUWr97fo2YFFFFaHYdP8V/8Akf8AV/8Atj/6JSij4r/8j/q//bH/ANEpRXJhf4EPRfkennH/ACMMR/jl/wClMd8LP+Sh6X9Zv/RT1y1dX8LHY/ELSxuOMzcZ/wCmT1ylVT/jy9I/nIVX/kXUv8dT/wBJphRRRXSeaFFFFABRT4YZLiWOKKNpJZGCoiDLMTwAAOpr0aH4e6b4ZtYdQ8X3+zfzHYWvzPIQA20t+anGAMj5xmsqteFKylu9kt2d2Dy6vjOaVNJRjvJu0V6t/wDDnBaZpV7rN0trYWstzO2PljXOBkDJPQDJHJ4Ga7a0+EWppAl1rF/Y6XaDPmtLJuaPnAz0Xk4/i7+vFPu/iTPZxLY+GLGDSbFGyCsavLJjjLZBGSNuepyPvGuTupr/AFSVZr26mnkChQ88hdgvXGT9Tx71lbE1drQX3v8AyX4nb/wlYVWlzVpevLD/AOSf/kv6nYjwt4Bsf9HvvE11NdJ9+S1T92c8jGEcdCP4jznp0p39qfDX/oXtS/7+N/8AHa4kWa45Yk+1PFtHj7v61X1Jv4qkn87fkT/bUYaUsNTS848z++Tf36X6nZ/2p8Nf+he1L/v43/x2mnQvh3qHNvrd9Zz3H+rjlUlIGboGJToCefn7fe71x32aL+7+pphtFxwzA+9H1Fr4akl87/ncP7bUtKmHpNf4OX8YtHXzfCO6uonn0PWdP1S3RTkq+1i452DG5c4x1Yde3WuM1nw/qfh+cQalZy2zt90sMq/AJ2sOGxkZweM1LB9qsJ1ntJ5Ipkztkico65GDgjpwSK6nTviXqkERtNYgg1ewKqrQXSDdhenzY5OcElgx47HmpccTT6qa+5/5fkVz5VilZxlRl3T54/NP3l8m/mef0V6aPBXh7xmskvhS+azvEXc+n3ucAZAyG5IHBJwX5YD5a871DT7nSr2azvIWhuYW2vG3UH+o7gjgjmtKWIhUbitGt09zjxmW1sJFVJWlCW0ou8X8+j8nZ+RWooorY4AooooAK6m6/wCQR4f/AOvN/wD0omrlq6mch9F0JlO5VtpI2I5AcTyMVPvh1OPRge4qX8UfX9GdFH+HV/w/+3RItPtft1/a2u/Z58qx7sZ25IGcfjXTS+CY31K+0yy1Fp9RtFLeVLB5YlAAJ2sGPPPfFc3plyllqVncyBjHBMkjBepAYE4/Kuvfxfplpruoa5ZR3ct9cKVijmjVEiJAGSQxLdPassRKspfuu343W56GW08DKlfFWvzK+ruo2d2knq72to/uMSLw7FFo9vqmo3jW0F05SFI4vMd8dWIyAB+P4Vo2/gOSTWWsJb1VhNqbyK4jj3iROMcEjB59aq/27Y6loNlpmpC5jexdjFPbqr7lY5KlSR+efwrXtvHVmuuC4kt549PhsTZQogDuBxhjkgdv5VlUlideXfXt8rHXh6WVNw9pa3udXdu3v82uiT2tbpZvUwJ/Dqvo7arp10bq1ikEUqPF5ckZOMZGSCDkdD3q+3g2KDUrfSbnU1i1WdQREIS0aMRwrPnOT7A1A2v2mn6BNpWmLcObmVZZridVQ/KQQFUE45A71fm8U6Te67a69cwXa30IVnt4wpjd1HB3k5A4HGDTlLEa2vbW2iv0tf8AH8LkU6WW6c1ub3OZXlyrWXPZ3u2ly9Xu7XKNt4PnNnfXV480aWdwbZ0t4POfeOpxkALyOc0zTPDVrqUerzrqMgtNOjWQuttlpAQcjaWGCMY61YsPFRivLu/bUL+zurmdpXS2jSSJlPQFWYcjkZ54xWmnjqyfUPEFxsu7P+0o0SKS2UF4yoI3H5l557GpnPFK9vLbpqr9NeuuvoaUaOUy5G3be929dJWd1JW15bppa9bXMmfwVcHU9Ks7SdZhqUInid12FFxk7lycYHuajHheC7i1E6bqP2qfT1LyxvD5e9R1KHcc498VpS+OYodV0a9t4ZbiSwiMU09xhZLgEY5wTjHOOT1qpbeINM0ZNVk0yO7e5v42hXz1VVgRjzyCdx/LpTUsVZX3+XfW/wArdvvFKllXO+Vq13fV3S5Fbl11fNdPfp01I4fDmmz6Hcauup3YtoJREymyXeScdB5uMc+tc6sJnuRDb7pC77I8rhmycDjJwfxratdct4PCN9pDJKbme4WZWAGwAY6nOc8elQeF9Rs9I1mC+vo5ZY7fLokYBJfHy5yRwDz+FbwdWKm5Xdttux59aGEqzoQp2gmlzO70d3fdvZWZoeKvBr+GYbeZbxbuORjG5VNvluADt6nPf8qoeJ9A/wCEc1FbP7R5+6JZN+zb17YyfStWXxfBqWj6tY31kscl1J9pie23NibPJbe5wDwOPfiqPjDXLfxBqyXdskqRiFI8SgA5GfQms6EsRzRjV6Xu9NdrfqjpzCnlvs6lTC2u+XlV3dfEpLXfaL176HP1H4s/5GrXP+v6f/0Y1TxRPPIkUSM8jkKqKMliegA7mqvieaO48S6zLFIskUl5MyOhyrAuSCCOoron/EXo/wBDyqf+7z/xR/KRr3n/ACBvDn/Xk/8A6Uz1ShhkuZo4YUaSWRgiIoyWJOABVy5IfQ/D7qdyJayRMw5AcXErFT77XQ49GB7in+H9U/sPXdN1Ix+YLO4SYp/eCsDiuSfxM8BNqM3FXd5fmzvrj4DeKINJN4Gs5LhV3mzSQmT6A42k+2fxrznTtPuNU1C2sLZN1zcyLFGp4yxOB9K+qLj4yeEYdKN8mpCV9mVtVRhKW/u4xx9envXzFY69Pp/iOHW4kTz4rn7SE/hzu3bfp2qEeRlWLx1eNT6xCzW11bXXQ6tPhrBda3d+H7PXFn1+2RmMBtisMjqMsiybskjnqoHFQp8NLmbwF/wlEF3vlQuZLExYZURyrMGzzjgkYGAfatO38eeH9N8V3viyztdQbVJ1do7OVUEMUrjDMZA2WHJ42jr1qHTviXHpmh+HLaOGeS70+6nlvFdV8qeKUtuQc85Ddx1o1Kc8faPJ/dvdLs+Zel7K/nuxV+FG7xM2i/2v93TP7R877N9Pk27/AH65/Cuc8E+Ev+Ex1O6svtn2XyLWS53+Xv3bcfLjI65613T/ABR0I+Op9ZS11BNOfSjp6p5aGRWz1xvxjHvmud8G+JNA8G6xcXkc+p3kVxZTW7BrOOJlZiu0j962Rwc9McdewOFXG+ylzJ83KraLfW/S3bf5EUXw3uLrwAviq2vRK4Ls9l5WGWNHKs4bdzjgnjoa0YvhQr+KTojawVUaaNRM4tcnHHybd/v1z+FRaT8R4NG8PeGbG3gne40y5me6R1Xyp4ZCdyDnJyD3HWt3/hamhr48l1yK31GKwOl/YUVY081GyMHG/GAB65o1IqVMwTmorT3raLv7q+7Vd767HlmpRaZEY/7Ou7u4BzvNzarDt9MbZHz39Kl0L/j6uv8ArwvP/SaSrPiTU11N7dxreraqyAgtqUe0xjjAX96+c856dO9VtEISa9lY7Y0sLvc54C7oHRcntlmVR6lgOpqo7o9OTbw7vvZ/1svyOQooortPcOn+K/8AyP8Aq/8A2x/9EpRTvis7Dx9q4DED9z3/AOmKUVyYX+BD0X5Hp5x/yMMR/jl/6Uw+Fn/JQ9L+s3/op65aup+Fn/JQ9L+s3/op65aqp/x5+kfzkKr/AMi6j/jqf+k0wooorpPNCtLQtCvfEepRWFhFvmfkseFjXuzHsB/9YZJAqtp+n3Oq3sNnZwtNczNtSNepP9B3JPAHNema3qMfw60iPw9pG1dYuYlkv71HyysR91TwQeuMgYUgjlsjnr1nFqnT1k/w835HqZfgYVYyxOJbjShu1u30jHzf4LVhc6no3w2ivNP0MteeIHURzX0iqUhP8SqPUEZ288kbiduK4O6nutYvJr29meWeZtzyN1b/AAGOB2HaoYLcEB26dhVl5FjGWP4etaUMNGleT1k929/+G8jLHZlUxdqcVy04/DFbL/N929WCRrGMKP8A69DyJH95gKpSXTvwPlHt1qCtXVS2OJUu5eN5GDj5j7gUz7b/ANM/1qpRUOrIr2cS39t/6Z/rTxeIcZDCqNFHtJB7OJppKj/dYE+lOZQ4wwBFZVSx3Dx8ZyvoatVe5Lpdix5ctrIk1vI6yRsGVkOGUjoQR3zXd2XizTPGVlDpHi/ctwJcwalEFQx56huMKOAM4IIwSBt3VxMUyyjIPPcVHPbhsuvB7j1rOth4Vkn1WzW6OvA5jWwbcY6xl8UXrGXqvye66MseLPCd74S1I2t0N8L5aC4UYWVf6EcZHb3BBODXpvg3XrfxBaJ4R8QL51nN8tpcFgHgcA7QCfyX67cEHA4TXdCvfDmpS2F/FsmTkMOVkXsynuD/APWOCCKxo1ZczpVfiX4rv/mdOPwdL2axmEv7KTtZ7wl/K31/uvqvNMzaKKK6TyQrT0zVhaI1tdQtcWLHf5SvsZH/ALyNg7ScAHgggDIyFIzKKTSe5UJyg7xOm+0aB/z/AGp/+AMf/wAeo+0aB/z/AGp/+AMf/wAermaKVpfzP8P8jb21P/n1H/yb/wCSOm+0aB/z/an/AOAMf/x6j7RoH/P9qf8A4Ax//Hq5mii0v5n+H+Qe2p/8+o/+Tf8AyR032jQP+f7U/wDwBj/+PUfaNA/5/tT/APAGP/49XM0UWl/M/wAP8g9tT/59R/8AJv8A5I6b7RoH/P8Aan/4Ax//AB6j7RoH/P8Aan/4Ax//AB6uZootL+Z/h/kHtqf/AD6j/wCTf/JHTfaNA/5/tT/8AY//AI9R9o0D/n+1P/wBj/8Aj1czRRaX8z/D/IPbU/8An1H/AMm/+SOm+0aB/wA/2p/+AMf/AMeo+0aB/wA/2p/+AMf/AMermaKLS/mf4f5B7an/AM+o/wDk3/yR032jQP8An+1P/wAAY/8A49R9o0D/AJ/tT/8AAGP/AOPVzNFFpfzP8P8AIPbU/wDn1H/yb/5I6GbWbKxXOlfaZLo/durhVjMX+6gLfN6Pu4zwoIDVz1FFNRsZ1KjnZWsl0W39eb1NTS9XWzja2u4WubBm3+Usmx0fH3kYg7ScAHgggDIyFK6nn+Hf+ghqv/gvj/8Aj9cvRUypxlqziqYWMpcybXpb9UzqPP8ADv8A0ENV/wDBfH/8fo8/w7/0ENV/8F8f/wAfrl6KXsokfU/77/D/ACOo8/w7/wBBDVf/AAXx/wDx+jz/AA7/ANBDVf8AwXx//H65eij2UQ+p/wB9/h/kdR5/h3/oIar/AOC+P/4/R5/h3/oIar/4L4//AI/XL0UeyiH1P++/w/yOo8/w7/0ENV/8F8f/AMfo8/w7/wBBDVf/AAXx/wDx+uXoo9lEPqf99/h/kdR5/h3/AKCGq/8Agvj/APj9UNS1iFoHs9NjlitXx50krAyXGDxnHCrkBtgJ56s2FxjUU1TincqGFjFqUm3bvb9EvxCiiirOo6f4r/8AI/6v/wBsf/RKUUfFf/kf9X/7Y/8AolKK5ML/AAIei/I9POP+RhiP8cv/AEpknwsC/wDCwtL5Oczdv+mT1yldT8LP+Sh6X9Zv/RT1y1VT/jy9I/nIVX/kXUv8dT/0mmFFFbfhLw/J4n1+009Qwidt0zr/AARjljnBwewzxkj1rec1CLlLZHFQozr1I0qavKTsvVna+F4LTwP4V/4Sa7hifW73K6fDMTwnA3BcZ6Eknuu0AjdzwaCS6meedmkd2LM7nJdieST3rovHmuJruvmCzKrpliPs1skeNgVerAAkYJHBGMqF9KxlUIoUdBWWDpOzqz+KX4Lovl+Z6Ob4mHNHB0P4dLRW+0/tSfq9vJISRxGhY/8A66zXdpGLMeanvHy4QHgdfrVatakrux5tONlcKKKKzNAooooAKKKKACiiigBVYqQQcEVowyiVM8bu4rNqa1fZKBnhuK0pys7Gc43RNcw/xqPrXoBEHxG8ISb0U+KNHi+QqzGS5iXHUYJYnkY5+bByA2DxJGRg9Ks+Gtbk8LeILW+UuYVO2VF/jjPDDGRk9xnjIBqMXRc488Pijqv8vmd2U4yFGo6VfWnU92Xp0kvOL1RzFFdb8RPD0eh6+0toFOmagv2m2eP7mG5KggAYB6AZwpX1rkqqlUVSCnHqcuLw08LXnQqbxdv+D6PdBRRXq/wa+BeofFyLXdSfV7TQ/Degw+dqGqXal1jG1mwqgjcQqknkAD6irbtuc55RRXsvin4P+C7LwXrXiPwp8VtN8RvpHlGXT206SyuHV5Uj3KsjEsAXBJAx78141QncAooooAKKKKACiiigAooooAKKKKACivS/hZ8EPEHxd03xRf6JeaXbw+HIY57pb6WRGdXWRhs2I2TiJuuOo/DzSi4BRXrX7P8A8E/+F6eKtR0P+3f7G+xWJvPP+yfaN+JETbt3pj7+c57dKj+J/wACda+HfxWtPAMM/wDalzqJtxp90IfJFyJTtB25bbh9ynk/dzS5lewWPKaK+j/j5+ykfgd4Ls/EZ8WjVzcX8dibYad9n27o5H3bvNbOPLxjHfrxXzhQmnqgCiiimAUUV7HofwI/tn4C658U/wC3/K/sq4Nv/Zn2Pd5vzxrnzfMGP9bnG09PehuwHjlFFFABRRRQAUUUUAFFFFAHU/FYL/wn2r5Jz+57f9MUopvxX/5H/V/+2P8A6JSiuTC/wIei/I9POP8AkYYj/HL/ANKY74Wf8lD0v6zf+inrlq6n4Wf8lD0v6zf+inrlqqn/AB5+kfzkKr/yLqP+Op/6TTCvT/h6y6B4L8S+IlP+lD/RYSsalomwMHJ7FpFJH+x36V5hXpnisf2V8OfCWmf6z7Tm883ptyC23Hf/AF2M5/h6c8Ti1z8lL+Z/gtX+R05I/YutjP8An3B2/wAUrRX53+XTc4a0TJZyOnAq3UcC7Yl6c81JXorY8FkEkEbyZZiGbtSfY4/VvzqO9b5kXuBmuq+FuqeHbDx94euPGKyv4cgu0kuvLiWXgcrvQg749wXeACSm4AE4rGUopu6NYxk0rM+hfgj+yDpfjjwXB4k8W6jq1n/aX7yytbLbE6wgkB5DJG2d/DLtGNuDk7sL6V/wwx8O/wDoM+Kf/Aq3/wDjFeneNfiF4p0/SNC8ReBvCH/CYaBfWEt7OIroWs6oVieB0VwWfchk/dhCxO3oeGg8GftD+AvGepJo6anLpHiEyNC+kazCbW4jlEnl+Uc/IZCxGEVi3PTIIHjSq1ZNyW35HqRp04pRZ5x/wwx8O/8AoM+Kf/Aq3/8AjFH/AAwx8O/+gz4p/wDAq3/+MV9N0Vn7ep3NPYw7HzJ/wwx8O/8AoM+Kf/Aq3/8AjFH/AAwx8O/+gz4p/wDAq3/+MV9N0Ue3qdw9jDseNfD39lz4deAf7Rzpv9v/AG3y/wDkYILe78jZu/1f7obd27n12r6V2F38KvhrZWk9zL4A8NNHBG0jCHQoZXIAydqLGWY8cBQSegBNVfGfxw+H3w71FNP8R+JrS1vzndbRpJcSxfKrDzEiVjHkOpG4DIORnBrt9J1a11rT4b62juo4Zc7Vu7SW2lGCQcxyqrryOMgZGCOCDXVSqT5byaXqclWnDmsk/kfmv+0fqngDxJ440+7+HsNjDoqabHFKthYGzjM4llLEoUXJ2lPmx0wM8V4+ttGsi4Ztw5xX1D+078RvhH4w8I258CHS5PE0urLc3dxb6Q9tPJEY5d7NK0S7suyEgkknntmvli0b99zklga9KLjorHE1Kzdy9Ve7TKBscj+VWKa670ZeOR3rdmSO11Jl8RfCS3upD/pWiTrDvaNcsuQoVSOg2umfUpz615dXp3wrH9oDxFof3P7Rsj++6+XjKfd7/wCtz1HT3rzGvOwy5J1KXZ3+T/4Nz3s2ft6GGxb3lHlfrB2v84uP/Bdwr3z9nn46wfCTTPEOl+IfDc2teDNfIhuhGB8j7CGX5vlfcjYKkjoDnrnwOvSPhr8bfEPwv03VNK06y0bUdJ1R1kurLVrIXEUjKMAkZB7+tdUldHiI+gfE3wb+D3xQ+D/ib4g/DJNS0W40KOWWa0uXYoWjQSNGyuzYJU8FHxk/hXomk2fhr4NfADwJqOl+MLLwRe67Bb3N1rzeH21WW7lkh8xouPujkgZ7LgYOTXyr4w/aU8W+KvCE3hK007w94b8O3JzcWXh+w+ypNyCQ3zNwSBnGM4wcjio/BP7R/i7wZ4UHhSa00PxD4aQ5i07xBY/aoouc4UblOMnOCSB2xUcrsO6PSP2gvFfwv8cax4E1fwdq1pf+KkuooNXmtNMmskuhlMSlHUAHcGwMscNgk4FfQ/xc+IupeF/2mPhroGm29ikOtwRQahPJbJJLPC80irEHYEoqnc3y4yTzkACvhLxt8YNa8c3eiyXOnaHp1po0rTWljpNgltAjMULEheTny16ntxit7xf+0d4p8afEjw149v7DRotY8PLGttDbwyrA+yRnG9TIWPLHow4xRybBc+vtI8Tr4e/awuvhno2j6RYeEr6zkuL60hsowbqd4DMZGbG7uF25247V5D8M/h34utPjr8V2+HniSy8H6NoVzPBd3s1pHcrDbtKzrGkbqRgeUTnIwF684Pj4/aO8Uj4xH4pfYNG/4SAw+T9n8mX7Lt8nyvu+Zuzt5+91/Kk8L/tI+NPCHjrxN4t00aaJ/EsrTajp8sDPaSkkkfKW3DG5sfNnBOc0crC59aaqujfFn9nf4h3mp+MrPx/daLb3E9vrA0D+zZLSaKHzAi8fN0GSuMhsHNctq/jG68C/sW/D3WNPtrOXVI7tEtJrq3SdbWQvcHzVRwVLBQwGQcbs9QK8Kb9q3xj/AMIt4l8Mw6P4XtNE16CW2a1s9Pa3jtEkQo/kqjhQTuJywYk9SQAK5XXfjd4g8QfCjRfhtc2elpoWkTLPBPFFILlmHmcMxcqR+9boo6CkoMLnv/7WKQeKvgt8JvHV7a2yeI9UhhW6uooghkEluHYHHYMuQO2TjrXT/tJeKZvgLofgLwP4N0fS28NXtu5vYLiyjnXUwpRSjEg8tuJLD5ssMEV8teNfjh4h8d/D/wAL+CdRs9Li0rw2sa2sttFIszhI/LG8s5U8eijmvojwP411fxH4B8Maff8AxS+GH2KxhjK3evwf8TnSWAAIhWT5GdAMK/U4BzRZq1wudn+1B4d8Q+Jfjd8HtN8I3EVjr4jnmtLicBktjEVkLsCGB2hCcEHOMd67XwBfXOrePtV8BeNfipp3ju9htJPtvh6TwukKQkbct56jYcbgCpz97sRXzX+0j+0Xb6v8W/DGufDzUmY+FYXji1Eods0rk+YAGHzJtwpJHOWxxgnAg/bK8c2niY+ILXQ/CNtfSxlLryNNaP7acAK0ziTzHKgcDdtHpwMLlbSHfU+g/wBmbXdU0GH45eE7W9I0bwXdzJo8JiQm2zJeEndty+TEh+Ynpx1NfEHxA+Jfin4patb6r4s1T+0b+3gFtHL9nih2xhmYLiNVB5ZjkjPNdb4I/aI8X+APGXijxPpUWmPN4nmkn1CxuYGe2kZ5GfhdwYAF2A+boTnNcd498anx5ri6ofD2gaCVhWH7JoNn9lt2wSd5TcfmO7BOegHpVxjZ3E2fRf8AwT+/5Kn4j/7Aj/8Ao+GvaPAnizwx4s8IQ/EzxMfN174VNqNm+SMzDGISc9SV2hSf4yxr4n+D/wAZNd+Cmv3utaBaabc3V5am0dNQjd0CF1fICOpzlB39eK4XUL2TUr+6vZQqy3MrTOEGFBYknHtzQ4Xdwufa37QmuXniv9kT4f61qUwe+1PWIbmeQ9N7x3RP4DPT0r03x9P4W+Ael+EdB0bx3p3gSwMReQP4YfU21cLtDGSVenXn+L5hggYr4f8AE3xx8Q+KvhZoHw6vLPS49E0SVJreeGKQXDFFkUb2LlSMSN0UdBXQ6L+1F4wsPDFj4d1nSvDPirTdPAW0HiLTRdNAAMLtO4ZwOATk+9TyMLn0V4L1r4aeJv2tPDetfDa5hkgvNMu/7Qjt7OW2jE4RsOFdF5ZSM7RjK56k56j4W+Kj8QPjZ8YPh9rGl6XL4Rt3nYWP2RBvk8/ZJI743OzlixJJwcbcYr49079ozxXpnxG07xxFY6CNQ02zextbJLHybSGFt2VEcbKerscls807wX+0d4p8C/ELxP4306w0aXVfEbSNdRXMMrQJvkEh2BZAw5HdjxQ4MLn0n8L/ABO3xi+D/wAZtG17TdMGjaFDKdJtLazjiWxURSsgTaByhjUhjk5zkms34Nau+g/sU+L9TisLa+ms7+WWOC5iEsW8PBtdkPDBDh8Hg7ecivm/wB8dvEfw40Pxfo+lWWlTW3ipDHeNdxSM8YKOv7srIoHEh6hugq94I/aP8X/D74e3XgnRrbSBptzcG4ee4tmlmyxQsmC/llGCbSrIchmHem4sLnvmuag3xs/Y91Xxh4wtrRvEugXJSz1OO3SFnCyRrj5QBhhIU2jAyoOMipfAv/CdfCn4R+EdR8S/Gix8G+Gr+ISaZpo8Ox6k5jkzKAxCh8kPuPJxuAyOlfPPxC/aH8WfEPwpZ+FJrXRtG8N2rB/7O0Sz+zQyMDkFl3HgEk4GBnnGQK0NL/af8aaf4I07wpcWfh/VLTS1VdPutU05bi4stowhjLHblRwCVJAo5XYLn058aPCej6R+0R8C9d06zt4L3WrzF3JbweSLgxtEVcp2Y+aevOAAelebftbfF7xHoHxP8V+D9B+x6fpuoWcMGpNHZxPPf+ZAv35GUsAEKqApGMZ6mvLfFf7T/jHxl4k8Ea/qVjov2/wfK01n5cMu2dj5eTNmUlv9WPulep/Dg/iZ8RdU+KvjK+8VazBZ2+o3ixq8dkjJENiKgwGZj0Ud+tEYvS4Nn3Bosnjj4Vv4G0Dx58a9PsJbxbe2tfDcfhlL0TRgrGITNGoYdk3nvzk4r57/AG1fCOkeEvjMF0ayhsodS02G+lhgQInml5EYhRwM+WCcdyT3rOuf2uPHt9YaRHe2nh281TStot9ZuNOD3yAYyBIWwu4DBKBWPqDzXCfF34u638aPE1v4g1+1062vILRLJU0+N0jKK7sCQ7sc5kPf04ojFp3YNnA0UUVoI6f4r/8AI/6v/wBsf/RKUUfFf/kf9X/7Y/8AolKK5ML/AAIei/I9POP+RhiP8cv/AEpknwsdj8QtLG44zNxn/pk9cpXU/Cz/AJKHpf1m/wDRT1y1VT/jy9I/nIVX/kXUv8dT/wBJphXp3xdH2PU9I0uH5bGzsl8mLrsyxXqeTwijk9vrXmNenfGb/kaLT/ryT/0ZJSq/7zT9JfodGC0yzFNd6a+V5P8ARfcjjlG1QB0AxVS9b5lX0GauVQu2zMR6DFdtX4TxafxEFFFFcx0H64/CuzuNO+GHgqzvLeW3u7fRbKKaCZCjxusCBlZTyCCCCD0r4h/aN+OsHxV1QaVpFla/8I5Ybo4bu4tEa5uGLKWkR2XfChKKAqlWYff67F/Quvzr+K/7NnirwL4kaDQdL1PxBoVzuktLmztmnkjUHmOZUB2uMj5sBWHIwdyr52FcHNuW/Q7q6kopI0f2X/E/ig+LLDwvpnje6060eeGaLR7m2FzbXUKSGS5iR23G3cxGVwVUByMFlO01+gdfH/7LXwC1vSNet/HXiWG60p7PzY7HTpozHNIzI0bSSqwyiAMwVeGY/NwoG/7AqMU4ufulUE1HUK+Lf2ufFPinR9auNE/4Te6i0zUyk0Og2VsIlSzMPlOZrkbWfzJRMPJ+ddoySPlWvtKvmn9qj4G6n49jg8XeHzLdatplqLebTQMmeBWZw0WOTIC7ZXncMbfmADzh3FVFzDrJuOh8y/Av4vv8HvEiXLaZa3ekXO6O8C20f2sIxTJjmI38FFPllth54BO8fpJpOq2muaVY6pYS+dY30CXMEu0rvjdQytggEZBBwQDX5v8AgX9nvx14z8SWul3Gg6nolm3z3GoalZSQxwxgjJG4De/OAgOSeuACw/Rrw9olv4a0DStFtHle10y1itInmILskaBFLEAAnAGcAfStsZyXTjuZ4fmtrsfjzeWdxp13cWd5by293byNFNBMhR43U4ZWU8ggggg9KhrtPjB/yVrx7/2Hr/8A9KHri6707q5xNWdie0bEwHqMVfrNgbbMh98VpV00noYVVqdD8LriW18b2kUT4SdZYpBgHcoQtj25VTx6VyXiG1hsdf1W1t02QQXUsca5J2qrkAZPPQV1Hw2/5HzTfrN/6Keud8Wf8jVrn/X9P/6MauNaYuVv5V+bPZnrk9NvpUkl6csWY9FFbcHha9uPC1x4ijeA2dvcfZ5I9x80cL8+MY25dBnOcsOK6zxDEoro9V8Eavpc+k23k/a7vU7YXUVvaK0kigkgqy4+8CpyBnFZMej6jNqB06Owun1AEqbVYWMuR1GzGc/hQBSorQg0HVbq8ns4NMvZbyAEywJA7SRgddygZH41evfDEtv4rj8PwzpJPJNFAksilF3PtxkDJABb3oAwaK6dPCVu+t6bpUfiDT7ma8vI7NxaxTlodzBSxEkaAgE9Af8AGsdNF1CeSNbayupxNK0MRjhZvNdeqrgckAg4HrQFyhRWpF4Z1ue6mtYtH1CS6gYJJCls5dGIJAK4yCQCefQ1HZ6DquoTSw2mmXtxNC4jkSGBnZG5+UgDg/K3H+yfSgDPoq62j6iunLqLWF0NPZtoujC3lE+m/GM/jVn/AIRrVIp4YbuxurMzxPNGbi2kHmKiFiQApJGB1AwOpIGSADJoorU0TQ5tbkutk9vbW9pF59xcXDERxJuVQTtBJyzKAACeaAMuiuhsfCjX99e26atpq29nbG7kvC0jReXuVeAqF85YcFQamg8FTX1lrF5p2p6ff2+lRJLK0PmqXDbiQgeNSSqozHOBgcE0WC5zFFbepeFr3StA0rWZ3g+z6m0ixRqxMibMcsMYGQwI5PBq3e+BdT0/UNCspnthLrQi8khyVjZyBsk44YblJAzjIoC5zNFdBqPg7UNLuNbhnaDdpCo8pViRKrsqo0ZxyDvVhnHB/CpL/wAHS6Wkkd5qumQ6jEm99PaV/OTjO0nbsDY/h3ZzxjPFAXOborbXwrft4XbxEDD9iWfyNm4+b2+fbj7mSFznqcYq/P4Mt4NIGqDxPo0lo8jwoUS7y8iKrFQDAMHDrycDnr1oC5ytFFFIYUUUUAFFFFABRRRQAUUUUAdT8VnYePtXAYgfue//AExSim/Ff/kf9X/7Y/8AolKK5ML/AAIei/I9POP+RhiP8cv/AEpjvhZ/yUPS/rN/6KeuWrq/hYF/4WFpfJzmbt/0yeuUqqf8eXpH85Cq/wDIupf46n/pNMK9N+J5+32nhfWpOLq/sh5ir9wYCtwOvWRupPQV5lXpc5/t34SWk/3p9GujFJJNy2wnAVDycYkjGOPuewqcR7tSnPzt96/zsdGV/vcLisP1cVJf9uNN/g3+JyCElFJ6kCs+dt0zk+uKt2rZix3U1RZtzFj1JzXZVeiPHprViUUV0/w31az0D4ieEdW1GbydP0/VrS5uJdpbZGkyMzYUEnABOACa527I2W5+u9FQ2d5b6jaW95Z3EVxaXEaywzwuHSRGGVZWHBBBBBHWpq8M9YKKK8ZtP2VfhVbWsEMvhyW5kjRUaebULgPKQMFmCuq5PU7QBzwAOKqKj9pid+h23/C2fAH/AEPHhn/wbQf/ABddJpOq2muaVY6pYS+dY30CXMEu0rvjdQytggEZBBwQDXK2nwd+HtlawW0Xgjw60cCLGpm06KVyAMDc7KWY8cliSepJNdhaWlvYWsFpaQRW9rbosUUMKBEjRRhVVRwAAAAB0py5fsiXN1JqKKKgo/JX4wf8la8e/wDYev8A/wBKHri69U/aR8RaX4r+NfivVdFvYr7TZZII47mE5SQxwRxsVP8AENyMAw4OMgkEGvK69uHwo8qfxMVW2sGHUHNatZNaEkn+j7jjLL/Ouik9zCqtjrvhJZpd+L/OkZg9rbyTJjGCxwnPthz+OK4LUb2TU9Qu72UKstzK8zhBhQWJJxntzXongo/2L4K8Va4fldoxaQSRcSxuRjIPGBukjPB/h9hXmVclL3q9Sfay/V/mexjv3WXYajs5c0382or8IsK7bw94sstD8PWttPAL7N7cNc2LEoJYXijUfPggfMmR15UcVxNFdh4lj0pvF9jq+nLb3mpfZr++02aCe7MblYZWvnnKttBO1kIBKg43AeoqGXxFpdzdahY/2k0az6RBpy6q8T4d42RiWABfYwQp0zgLkdRXndFFxWPStQ8Q6Tqun3GkprRtZIlsv+JlJFLi78hHVgQoLjBcbcjogzt4xman4g0+5+KUOtpdvJpq6hBO1w6MGKKU3MVxnPB4riKKLjsejXGt2kfirRNSm1vQbmzt9UiuHGnaY1vLHGJAxZyLeMsAB0yxz2qK48S2N9rFlqdvqEVipgks5LGeCRoIEKFTt2DIjcMScfOGJPP3j59RRcLHqSnSLnw74lhstZ+x2jyadG05E7QeYFnJRcgyeXxkZBOQO3NZOv8AiqzvrPxRHa3cu6/nsFUsrK1ykMUivI3puba2Cc5b2NcQtzMkElussiwSsrvGGIVmXO0kdCRuOPTJ9aiouKx6fe+MdKm0zz7U6dDcSadFYPE0V29yu1FU4HmCDbuXcDwf9nOSWyeINEXUE1CbUoZb+4F6072kc6xMZLZ1Uukg4kLsB8nygGvMqKLhY1dDu/sh1H/iYfYvNs5Yv9T5nn5x+6/2d397tip/C189hfSumrR6Y0kRTzJ4DNDICRlJFCtleM/dbkDjvWHRQM9Ostf0K11zUHtbzTbVrjR/sz3UlgxtJbrzEYsIfLbClV7oBkE4Gaq2/iqDQ49RkN9peoXUk9nIsen2jW0M0aeaJIyvlRgZVwCdvIbqcHHndFFxWPQpPEuja/Ho8epv9ls4dWlnltgrP5VoIbdI0BC8kiIp9RkgA1oxeOPD+rXUV1cxXlhcW+txasGubj7SGDOomRQkS7QFVWwc/cwOevllFFwsejHxfplz4V1hJpyNajZILUGNiLmAXCyrk44KYYc4yGUDpUsmteH313Wtda/s57XVhPNJpt1p5luY5ZFcqFdkKqFkYHcrgkAZHavNKKLhY9Rj8VeFUMWilLz7ANL/ALMa/E/7jc370y+R5W84m5+9nCjjtXGzalav4JstOWXN5FqU9w0e08I0UKqc4xyUbjrxWBRRcdgooopDCiiigAooooAKKKKACiiigDp/iv8A8j/q/wD2x/8ARKUU74rBf+E+1fJOf3Pb/pilFcmF/gQ9F+R6ecf8jDEf45f+lMPhZ/yUPS/rN/6KeuWrqfhZ/wAlD0v6zf8Aop65aqp/x5+kfzkKr/yLqP8Ajqf+k0wr0j4T6lFPLqnhu7klWDVoGEZVj8rBSGwMEAlSTk/3AOeK83qa0uprG6gurd9k8DrJG2AdrKcg4PHUVeIpe2puH9X6GeWY14LFQr2uluu6ejXzVy9LFNp11c2s67J4WaN1yDtdSQRkcHkVTr0L4gWK63Y6f4vsIW+zX0SrdAZIhkX5eSe3GzIAGUH94V57U063tYKXXquz6o0x2C+p15U07x3i+8Xqn81+N0FFS28PnOQW2oqlmbGcAe1P8uz/AOf3/wAhGqORtI+oP2ZP2m7PwBp6eDvGL+V4ci8ySx1CKEu1ozEu0cioCzozFiGALKzYOVIKfeFneW+o2lveWdxFcWlxGssM8Lh0kRhlWVhwQQQQR1r8b/Ls/wDn9/8AIRr074afHrxb8KtkGjeIvtGkrn/iV6hC81qM7z8q5DR/M5Y+Wy7jjdnpXJWwvO+aO50UsSo6S2P1IorzL4Q/F1/i3oVlq1n4Yvbe1nklimuY7y1mgt3TPyt+8WYEjacGIH5wfukMfUDE4ONp/KuGVKcd0dcasJbMZRTvLc/wn8q4r4k+PpfhxoWpaxP4fvbzT7G0Nw92t1aw26vyFjYySh8lto+VHJ3gKGb5aUac5bIcqkI7s7Ovjb9pP9qfS7vRL7wb4Fu4r9r+OW11LVAmYo4jlHii3DDlhnMgyoUjaSW3J418Uv2mvFvxN+02X9s/2LoEu5P7O05HTzIzvG2WX70mUfaw4RtoOwGvF/Ls/wDn9/8AIRruo4TlfNM5KuKT0iV6KseXZ/8AP7/5CNNngWNY3jk8yKQHDYx0PPFdhzXTIameQtFGuegqGu3+G+hrc6k+tXqsmk6SrXEkpUkF1G4AYOSR97jPQAj5hSnWVGLmzowuDnjK0KEN29+y6t+SWrNDx7cf8I74O0HwsplW6ZBdXSl/u5JO04GGG8tjnjyx14NeYVpeINZm8QazealONr3L7gvB2KOFXIAzhQBnHOKzaMNSdKnaW71fq9ys1xkcXiXKn8EUox/wx0X37vzYUUVYtrbzf3kmREDjI6sfQf49vyB6DzSvRWli3HAtYyB3Zmyfrgil/cf8+kX/AH0//wAVT5RcxmUVp/uP+fSL/vp//iqP3H/PpF/30/8A8VRyhzGZRWn+4/59Iv8Avp//AIqj9x/z6Rf99P8A/FUcocxmUVp/uP8An0i/76f/AOKo/cf8+kX/AH0//wAVRyhzGZRWn+4/59Iv++n/APiqP3H/AD6Rf99P/wDFUcocxmUVp/uP+fSL/vp//iqP3H/PpF/30/8A8VRyhzGZRWn+4/59Iv8Avp//AIqj9x/z6Rf99P8A/FUcocxmUVp/uP8An0i/76f/AOKo/cf8+kX/AH0//wAVRyhzGZRWn+4/59Iv++n/APiqP3H/AD6Rf99P/wDFUcocxmUVp/uP+fSL/vp//iqP3H/PpF/30/8A8VRyhzGZRWn+4/59Iv8Avp//AIqj9x/z6Rf99P8A/FUcocxmUVp/uP8An0i/76f/AOKo/cf8+kX/AH0//wAVRyhzGZRWn+4/59Iv++n/APiqP3H/AD6Rf99P/wDFUcocxmUVp/uP+fSL/vp//iqrXFsqqZIdxjH3lY5K/wCI9/w9MjQXKtFFFSUdP8V/+R/1f/tj/wCiUoo+K/8AyP8Aq/8A2x/9EpRXJhf4EPRfkennH/IwxH+OX/pTHfCz/koel/Wb/wBFPXLV1fwsdj8QtLG44zNxn/pk9cpVU/48vSP5yFV/5F1L/HU/9JphRRRXSeaattrt7Fos+jJLixmmFwyjglgMYyOoPynBzyoIxzmlUcXep4YjNKkYzljjgZxWTik3ZbnT7Sc4rnd7Ky8l2JJm+z2Gw/fuCDj0UdD+JrOq1fzCa5bbjy4/kTBzwPeqtSzEKKKKQH0T+yN8av8AhWvjpdE1rVPs3hDXMpN9ol2wWlzgeXOflO3O0RscqMMGY4jGP0vr8R6/Sj9kP44yfEzwjJ4d1u6mn8VaBGvmXFzMjSX1uWISQDhiU+VHJB5KMWLOQBjR9IV8D/ttfGr+2tYg+H2gapv0zT8vrH2aXKTXIb5YH+Xnytu4gMRufBAaLj6Y/aQ+MkXwc+H095btu8Q6pvs9LjV490cpQ5uCr53JHwT8rAsyKcBsj8rr29udSvLi8vLia5vLmRpZp5nLySuxyzMx5JJJJJ5JNCBkFFFFAgrQsm8+2ltv4wfNT3IHI/Ks+pbadraeOVeqnOPUdxTQEtXo9dvbXRrzSI5cWV46SSIeeV547DJ25I5O0c4qC7iEM7KnMZ+ZT2INVZfuj60+VN2aNo1Z003B2umvk9GvmiKiiitjmCtIcWlqBwChY+53MM/kB+VZtaf/AC62n/XM/wDobVUSZDKKtaZp1xq+pWen2cZku7yZIIkH8TsQqj8yK9t+Ivw8sbeTQprnSbnw7oun6kNAur6SxaH7TCoUpecgb2fExLc9F9qdyTwiivSrjwjY21v4gntbW7trVNGa5hM9xbXySMt1DGSk6JtxhznaFZTwTgkHU8L+EPDf9u+Dri3trvVrOS/sEvJxdwSQM0pXdHJBsLxAOSvz7g4UgYyCC4HkNFeo6P4M0DxD/b2sRQXFtpdjdRWkdjca3aW0jyOJGLfaJkRAoEZwgQsc9cAmp38BeEdLNuLy+1DUVvNbk0uCbTbqDyxEI4HEhYK6symfBVTgkcMuOS4Hk9Fa0nh+6bxO/h+1Hn3pvTYxgDHmPv2D8zXuPif4fQ2niHwZOPDEmn6dp+vQaBP9psTEmoxKyFLhgygSeZibceeAo9KLgfPFFeifD6xtLj4rG2nhsjao1+Ql1AJYE2QTFS0ZVgQpAONp6dDWvqy6Drukai1rPpt1q+m6NLPeXml6attbTMbuBYwsbxJtYK7ZdEQnIGSN2S4HklFeoeLfBfhfSJvFMGm/2w7+Gr6OGdrm4ixdRNIUYLiP92wIADHcDydo6Vc8UeHNC1H4o+JLHTfDl8NPsJZ/tEcer21nDERIFDiR4BHFHyFCHPJGG7EuB5HRXqmrfD/w94Zi8Q3mpvqN1bWR01rSGzu4MyLdQySFWmVXQ7dmA6AhsHA+YEYHwysbKTWL7U9VSA6VpVnJPO88PnLEz4hhfyukm2WWMlTwQDn0ouBxVFdh438L6ppRTVtRj02CO+mMduLBQkVyqohM8SqNvltvXkYG4kbRggd5pHhLR/FHgLwlaPb2tneW8cuqXl8karLLZrdSx3G5urlFEbKD0Aai4HidFes/E7RdKvYdT8RWVjFppWLRDFZWaLHAgurKSWT5QOu6Nec9znOeN7wp4b0vRtd1LQ54JbzTF8S6FE0U7KTIHE/DZUgrluRjkZHGc0XA8Ior0FtD03WdK8Sy6NbvZLFqNlbwxahdW7AFxcbiZ2jjCLlBwCo/vbsAjW8D6Wmj+H/GbXd34atb+znsY0vtQtotTt0D+cWVCkU6ktheVH8OCRii4HlFFe1WGm6B/Yd/qWsWSaobjQbi7D6ckFkisuqeVui/0fK5GMFlyqllwAQF5XTfBOm6jqHg2ISXiQ67Y3N3MPMUtGY5rlFCnb02wJnI6k9MgAuM8/orr/GejaF4ft9JtbFdRk1O5sLO+uJp5k8lPOgWRo1QJk8sCGLcDjB+9XIUCCiiimAVJDz5oPIMT5HrhSR+oB/Co6lg6yf9cpP/AEA0IDKooorM0On+K/8AyP8Aq/8A2x/9EpRTvis7Dx9q4DED9z3/AOmKUVyYX+BD0X5Hp5x/yMMR/jl/6Uw+Fn/JQ9L+s3/op65aup+Fn/JQ9L+s3/op65aqp/x5+kfzkKr/AMi6j/jqf+k0wooorpPNJYvun61chb7PbTXB648tPXce+e2BVFZNoxitK6tlmit40urYLEpzuk53Hr+FZtO9zTmVrGRRV7+zf+nu0/7+f/Wo/s3/AKe7T/v5/wDWqeVk3KNFXv7N/wCnu0/7+f8A1q0rXwZrF9Alxa2sk8D52yRRuytg4OCFx1BqZe7q9DSnTnUdoJt+Wpz9dh8L/iLq3wr8a6Z4l0maYNbSKLm3jk2C8tywMkDEgjDAdSDtIDDlQRV/4QDxB/0Drn/vxJ/8TWR/Zbf8/Nr/AN/P/rURal8Oo6lGpSt7SLV+6seh/Hz4yXvxo8dXGrbruHQbb9zpdhcOp+zxYAZiF4DuV3N94jhdzBFry2r/APZbf8/Nr/38/wDrVqReBtcniSWKxmkikUMjpE5DA8gg7eRRK0fi0FTpTqu1OLfornOUV0c3gbXLeKSWWxmjijUs7vE4VQOSSSvArK/s3/p7tP8Av5/9aiLUvh1CpSnTdqkWvVWKNFXv7N/6e7T/AL+f/Wo/s3/p7tP+/n/1qrlZnckVvtFgjfx252tnqVPTn9MVVf7hq/ZWq28rF7q2MboUbbJzg+lZ8jbWdODgkZU5BqkmVzK1iKiiitDMK0/+XW0/65n/ANDasyr9tKJ4kgP+tTIT/aB52/XOT75+gNRJZf0bWL3w/qdvqWnTeRfW5LRS7VYoSCMgEEZ54PY8jmrGj+JtV0CK6i067MEd2YzKuxWDFG3KfmBwQfTsSDwSDlMpUlWBBHBB7UlUSdHf+Ote1FJopruJIJrY2bQW9rDDEIjIshCoihVJdFJIAJxyaVvH3iA2lvarfLEkEkUokht4o5XaM5jLyKoeTaeRuJxXN0UgOmTx/rsV/eXqS2SveqouIRp1t9nm28qzQ+X5ZYEk7tueTzzVO48W6xdeR5t4W+z3jX8f7tPlmYICw46YiQbeg28DrWLRQBq2fiTU9P17+3ba58vVvNecXHlqSJGzlgCMA8kjjg8jGBT9D8U6t4b83+zLvyBLJDK4MaOC8UgkjbDA4IYZ+hIPBIOPRQBo2GvahpmqvqlrceXfuJQZdinPmKyvwRjlXYdOM8VFY6rd6bFfRWs3lx38H2a4G0HfHvV9vI4+ZFORg8fWqdFAGxe+KtX1GXWZbm78x9akEt6fLQecwfeDwPl+bn5cVpH4jeImvpL17m0e4mg+zzs+n27C5TcG/eqY8StlVO5wzZA5rlaKAN/WPG2u6/Hdx6jfeel2bcyjykXd5CMkX3VGNquw4655zgVT0PxBqPhu8e6024EMskbQyBo1kSWM9UdHBVlOBwwI4FZlFAG9rvjPWvEtpb2mp3Uc1tauXgiS3ijWDIAKoEUbEOAdi4XPOM81nXerXl9ZafZXE2+209Hjt02geWrOXYZAycsxPOetUqKAOltvH/iC0lkkS8ifzLaC0ZJrWGWMxwIEi+R0K7kUABsbupzkmo7jx14hury9vJdSka7vbqC9mmCKGaaHd5b5A4I3N0xnPOa56igDb1PxbqurR38dxJbLFfyRS3EdvaQwLI8YcI2I0UA/vHyR1zzniqNvq95a6Ze6ZFNtsr145J49oO9o92w5xkY3t0POeapUUAb+neNdb0oWi291EY7S2ezjimtopYzC8hkZGR1KuC7FvmB5x6CrWl/EbxJo1qltY30UUcZk8o/ZIWeISZ3qjFCyI2TlVIXk8Vy1FAFzUtVu9XmhmvZvNkhgitkO0LiONAiLwB0VQM9TjnNU6KKYBRRRQAVLB1k/65Sf+gGoqdM/2RHVgRO6lQp6oD1J+oyMe+fTIMzaKKKzLOn+K/8AyP8Aq/8A2x/9EpRR8V/+R/1f/tj/AOiUorkwv8CHovyPTzj/AJGGI/xy/wDSmSfCwL/wsLS+TnM3b/pk9cpXU/Cz/koel/Wb/wBFPXLVVP8Ajy9I/nIVX/kXUv8AHU/9JphRRRXSeaFFFFABRRRQAVNa3dxYzpcWs8sE6Z2yROVZcjBwRz0JqGihq+jHGTi007NHVWvxJ8U2cCQR6vKyJnBlRJG5OeWZST+Jre/4XXr/APz56Z/37k/+LrzeiuaWDoS1cF9x6lHPMxoq0K8rerf57HpH/C69f/589M/79yf/ABdY938UPFN356/2l5Mc24bIYkXYD2Vsbhjsc5981x9FEcFh46qC+4dXPsyqq0q8vk2vysWb3UbzU5RLe3c9zKq7Q88hdgOuMntyfzqtRRXSkkrI8qUpTfNJ3YUUUUCCiiigAooooAKKKKALC310ihVuZgoGAA5wBS/2hd/8/U//AH8NVqKd2KxZ/tC7/wCfqf8A7+Gj+0Lv/n6n/wC/hqtRRdhYs/2hd/8AP1P/AN/DR/aF3/z9T/8Afw1WoouwsWf7Qu/+fqf/AL+Gj+0Lv/n6n/7+Gq1FF2Fiz/aF3/z9T/8Afw0f2hd/8/U//fw1WoouwsWf7Qu/+fqf/v4aP7Qu/wDn6n/7+Gq1FF2Fiz/aF3/z9T/9/DR/aF3/AM/U/wD38NVqKLsLFn+0Lv8A5+p/+/ho/tC7/wCfqf8A7+Gq1FF2Fiz/AGhd/wDP1P8A9/DR/aF3/wA/U/8A38NVqKLsLFn+0Lv/AJ+p/wDv4aP7Qu/+fqf/AL+Gq1FF2Fiz/aF3/wA/U/8A38NH9oXf/P1P/wB/DVaii7CxZ/tC7/5+p/8Av4aP7Qu/+fqf/v4arUUXYWLP9oXf/P1P/wB/DR/aF3/z9T/9/DVaii7CxZ/tC7/5+p/+/hqtRRRcAooopDOp+KwX/hPtXyTn9z2/6YpRTfiv/wAj/q//AGx/9EpRXJhf4EPRfkennH/IwxH+OX/pTMvwjrK+H/Fmnag5RYop8Ss6lgsbZVzgc5CsSPf16U7xLo7aBr+oacQwW3lIj3sCxQ8oSRxkqQfx7VgSf6x/qa7DT9d0rXNKstI14vaTWaslvq6K0rLHnIikTqy8kAg/L8vGN2XK8J+0Sutn+j/P7xYdxr0HhZSUWnzRb0V3ZNN7K9k03ZK2u91zNFdePhrrdz8+mNYarbjhp7G7RkVv7pLEHOMHp3FL/wAKt8Wf9An/AMmIv/iqv61Q/nX3oX9j5h0oTfpFtfelY4+iuw/4Vb4s/wCgT/5MRf8AxVH/AAq3xZ/0Cf8AyYi/+Ko+t0P5196D+xsx/wCgef8A4DL/ACOPorsP+FW+LP8AoE/+TEX/AMVR/wAKt8Wf9An/AMmIv/iqPrdD+dfeg/sbMf8AoHn/AOAy/wAjj6K7D/hVviz/AKBP/kxF/wDFUf8ACrfFn/QJ/wDJiL/4qj63Q/nX3oP7GzH/AKB5/wDgMv8AI4+iuw/4Vb4s/wCgT/5MRf8AxVH/AAq3xZ/0Cf8AyYi/+Ko+t0P5196D+xsx/wCgef8A4DL/ACOPorsP+FW+LP8AoE/+TEX/AMVR/wAKt8Wf9An/AMmIv/iqPrdD+dfeg/sbMf8AoHn/AOAy/wAjj6K7D/hVviz/AKBP/kxF/wDFUf8ACrfFn/QJ/wDJiL/4qj63Q/nX3oP7GzH/AKB5/wDgMv8AI4+iuw/4Vb4s/wCgT/5MRf8AxVH/AAq3xZ/0Cf8AyYi/+Ko+t0P5196D+xsx/wCgef8A4DL/ACOPorsP+FW+LP8AoE/+TEX/AMVR/wAKt8Wf9An/AMmIv/iqPrdD+dfeg/sbMf8AoHn/AOAy/wAjj6K7D/hVviz/AKBP/kxF/wDFUf8ACrfFn/QJ/wDJiL/4qj63Q/nX3oP7GzH/AKB5/wDgMv8AI4+iuw/4Vb4s/wCgT/5MRf8AxVH/AAq3xZ/0Cf8AyYi/+Ko+t0P5196D+xsx/wCgef8A4DL/ACOPorsP+FW+LP8AoE/+TEX/AMVR/wAKt8Wf9An/AMmIv/iqPrdD+dfeg/sbMf8AoHn/AOAy/wAjj6K7D/hVviz/AKBP/kxF/wDFUf8ACrfFn/QJ/wDJiL/4qj63Q/nX3oP7GzH/AKB5/wDgMv8AI4+iuw/4Vb4s/wCgT/5MRf8AxVH/AAq3xZ/0Cf8AyYi/+Ko+t0P5196D+xsx/wCgef8A4DL/ACOPorsP+FW+LP8AoE/+TEX/AMVR/wAKt8Wf9An/AMmIv/iqPrdD+dfeg/sbMf8AoHn/AOAy/wAjj6K7D/hVviz/AKBP/kxF/wDFUf8ACrfFn/QJ/wDJiL/4qj63Q/nX3oP7GzH/AKB5/wDgMv8AI4+iuw/4Vb4s/wCgT/5MRf8AxVH/AAq3xZ/0Cf8AyYi/+Ko+t0P5196D+xsx/wCgef8A4DL/ACOPorsP+FW+LP8AoE/+TEX/AMVR/wAKt8Wf9An/AMmIv/iqPrdD+dfeg/sbMf8AoHn/AOAy/wAjj6K7D/hVviz/AKBP/kxF/wDFUf8ACrfFn/QJ/wDJiL/4qj63Q/nX3oP7GzH/AKB5/wDgMv8AI4+iuw/4Vb4s/wCgT/5MRf8AxVH/AAq3xZ/0Cf8AyYi/+Ko+t0P5196D+xsx/wCgef8A4DL/ACOPorsP+FW+LP8AoE/+TEX/AMVR/wAKt8Wf9An/AMmIv/iqPrdD+dfeg/sbMf8AoHn/AOAy/wAjj6K7D/hVviz/AKBP/kxF/wDFUf8ACrfFn/QJ/wDJiL/4qj63Q/nX3oP7GzH/AKB5/wDgMv8AI4+iuw/4Vb4s/wCgT/5MRf8AxVH/AAq3xZ/0Cf8AyYi/+Ko+t0P5196D+xsx/wCgef8A4DL/ACOPorsP+FW+LP8AoE/+TEX/AMVR/wAKt8Wf9An/AMmIv/iqPrdD+dfeg/sbMf8AoHn/AOAy/wAjj6K7D/hVviz/AKBP/kxF/wDFUf8ACrfFn/QJ/wDJiL/4qj63Q/nX3oP7GzH/AKB5/wDgMv8AI4+tXw1o7a/r+n6cAxW4lAk2MAwQcuQTxkKCfw71tH4a63bfPqbWGlW54We+u0VGb+6CpJzjJ6djVbUNd0rQ9KvdI0EvdzXiqlxq7q0TNHnJijTqq8AEk/N83GNuJniIzXLRd35bLzv+m5pSy6eHmqmOjyRWtnpKXklvrte1lu+ieV4y1lfEHijVNQQo0UspETIpUNGoCocHnJVQT7+nSisKirhFQiorZHBXrSr1ZVZ7ybb9XqSSSOHYBm6nvTfMf++350UVRkHmP/fb86cJH2MdzdR3+tFFADfMf++350eY/wDfb86KKADzH/vt+dOkkcOwDN1PeiigBvmP/fb86PMf++350UUAOEj7GO5uo7/Wm+Y/99vzoooAPMf++350eY/99vzoooAdJI4dgGbqe9N8x/77fnRRQAeY/wDfb86cJH2MdzdR3+tFFADfMf8Avt+dHmP/AH2/OiigA8x/77fnTpJHDsAzdT3oooAb5j/32/OjzH/vt+dFFADhI+xjubqO/wBab5j/AN9vzoooAPMf++350eY/99vzoooAdJI4dgGbqe9N8x/77fnRRQAeY/8Afb86cJH2MdzdR3+tFFADfMf++350eY/99vzoooAPMf8Avt+dOkkcOwDN1PeiigBvmP8A32/OjzH/AL7fnRRQA4SPsY7m6jv9ab5j/wB9vzoooAPMf++350eY/wDfb86KKAHSSOHYBm6nvTfMf++350UUAHmP/fb86cJH2MdzdR3+tFFADfMf++350eY/99vzoooAPMf++3506SRw7AM3U96KKAG+Y/8Afb86PMf++350UUAOEj7GO5uo7/Wm+Y/99vzoooAPMf8Avt+dFFFAH//Z",
	"ngambek": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4lkkcOwDN1Pem+Y/99vzok/1j/U16NNNF8NILa0tLZB4zC77u9fEi2auARFGCNpbZjc2DjcwBOfl60rmmHw6qKU5y5Yx3e++yS6t62V1s9UkY+n/DPxjqcLSw6LdIittIuGWBs4B+65BI564x+VXB8I/G20/8Shs5H/L3D/8AF1zN/qd7qsyzX95cXcyrsDzytIwXJOMk9Mk/nVWrsjb2mAWns5v/ALfivw5H+bOv/wCFR+N/+gQ3/gXD/wDF0f8ACo/G/wD0CG/8C4f/AIuuQoosg9rgP+fU/wDwOP8A8rOv/wCFR+N/+gQ3/gXD/wDF0r/CPxsWbGkNjPH+lw//ABdcfRRZB7XAf8+p/wDgcf8A5Wdf/wAKj8b/APQIb/wLh/8Ai6P+FR+N/wDoEN/4Fw//ABdchRRZB7XAf8+p/wDgcf8A5WdgPhH422n/AIlDZyP+XuH/AOLpP+FR+N/+gQ3/AIFw/wDxdchRRZB7XAf8+p/+Bx/+VnX/APCo/G//AECG/wDAuH/4uj/hUfjf/oEN/wCBcP8A8XXIUUWQe1wH/Pqf/gcf/lZ2D/CPxsWbGkNjPH+lw/8AxdJ/wqPxv/0CG/8AAuH/AOLrkKKLIPa4D/n1P/wOP/ys6/8A4VH43/6BDf8AgXD/APF0o+Efjbaf+JQ2cj/l7h/+Lrj6KLIPa4D/AJ9T/wDA4/8Ays6//hUfjf8A6BDf+BcP/wAXR/wqPxv/ANAhv/AuH/4uuQoosg9rgP8An1P/AMDj/wDKzr/+FR+N/wDoEN/4Fw//ABdK/wAI/GxZsaQ2M8f6XD/8XXH0UWQe1wH/AD6n/wCBx/8AlZ1//Co/G/8A0CG/8C4f/i6P+FR+N/8AoEN/4Fw//F1yFFFkHtcB/wA+p/8Agcf/AJWdgPhH422n/iUNnI/5e4f/AIuk/wCFR+N/+gQ3/gXD/wDF1yFFFkHtcB/z6n/4HH/5Wdf/AMKj8b/9Ahv/AALh/wDi6P8AhUfjf/oEN/4Fw/8AxdchRRZB7XAf8+p/+Bx/+VnYP8I/GxZsaQ2M8f6XD/8AF0n/AAqPxv8A9Ahv/AuH/wCLrkKKLIPa4D/n1P8A8Dj/APKzr/8AhUfjf/oEN/4Fw/8AxdKPhH422n/iUNnI/wCXuH/4uuPoosg9rgP+fU//AAOP/wArOv8A+FR+N/8AoEN/4Fw//F0f8Kj8b/8AQIb/AMC4f/i65CiiyD2uA/59T/8AA4//ACs6/wD4VH43/wCgQ3/gXD/8XSv8I/GxZsaQ2M8f6XD/APF1x9FFkHtcB/z6n/4HH/5Wdf8A8Kj8b/8AQIb/AMC4f/i6P+FR+N/+gQ3/AIFw/wDxdchRRZB7XAf8+p/+Bx/+VnYD4R+Ntp/4lDZyP+XuH/4uk/4VH43/AOgQ3/gXD/8AF1yFFFkHtcB/z6n/AOBx/wDlZ1//AAqPxv8A9Ahv/AuH/wCLo/4VH43/AOgQ3/gXD/8AF1yFFFkHtcB/z6n/AOBx/wDlZ2D/AAj8bFmxpDYzx/pcP/xdJ/wqPxv/ANAhv/AuH/4uuQoosg9rgP8An1P/AMDj/wDKzr/+FR+N/wDoEN/4Fw//ABdKPhH422n/AIlDZyP+XuH/AOLrj6KLIPa4D/n1P/wOP/ys6/8A4VH43/6BDf8AgXD/APF0f8Kj8b/9Ahv/AALh/wDi65CiiyD2uA/59T/8Dj/8rOv/AOFR+N/+gQ3/AIFw/wDxdK/wj8bFmxpDYzx/pcP/AMXXH0UWQe1wH/Pqf/gcf/lZ1/8AwqPxv/0CG/8AAuH/AOLo/wCFR+N/+gQ3/gXD/wDF1yFFFkHtcB/z6n/4HH/5WdNf/DTxjplsJZ9FunDOFAt2Wduh/hQkgcdenSuP8x/77fnWpYane6VM01heXFpMy7C8ErRsVyDjIPTIH5V2UM0XxLgubS7tkPjMrvtL1MRreKgJMUgA2htmdrYGdqgkY+ZOPYqNHD4l8mHvGXRSad/JNJavora7Xva/nPmP/fb86KbRUHnHYfDPT4tT+IWiwys6ok5nBQgHdGrSL17ZUZ9s1i6nfyarqN5fzKizXczzOEBChmYk4z2ya6b4Rhf+FkaRyc5n7f8ATF64+tFsd9TTAU7dZz/CMLfm/vPePg/4i8Mab4beCW6tLDVBITdNcyLGZuTsKljyAvGB0OeOcn0P/hMfDn/Qf0r/AMDI/wDGvkSirUrHu4Li6thMPChGlFqKt1X9Pv3ep9d/8Jj4c/6D+lf+Bkf+NH/CY+HP+g/pX/gZH/jXyJRRznV/rvX/AOfS+9n13/wmPhz/AKD+lf8AgZH/AI0f8Jj4c/6D+lf+Bkf+NfIlFHOH+u9f/n0vvZ9d/wDCY+HP+g/pX/gZH/jR/wAJj4c/6D+lf+Bkf+NfIlFHOH+u9f8A59L72fXf/CY+HP8AoP6V/wCBkf8AjR/wmPhz/oP6V/4GR/418iUUc4f671/+fS+9n13/AMJj4c/6D+lf+Bkf+NH/AAmPhz/oP6V/4GR/418iUUc4f671/wDn0vvZ9d/8Jj4c/wCg/pX/AIGR/wCNH/CY+HP+g/pX/gZH/jXyJRRzh/rvX/59L72fXf8AwmPhz/oP6V/4GR/40f8ACY+HP+g/pX/gZH/jXyJRRzh/rvX/AOfS+9n13/wmPhz/AKD+lf8AgZH/AI0f8Jj4c/6D+lf+Bkf+NfIlFHOH+u9f/n0vvZ9d/wDCY+HP+g/pX/gZH/jR/wAJj4c/6D+lf+Bkf+NfIlFHOH+u9f8A59L72fXf/CY+HP8AoP6V/wCBkf8AjR/wmPhz/oP6V/4GR/418iUUc4f671/+fS+9n13/AMJj4c/6D+lf+Bkf+NH/AAmPhz/oP6V/4GR/418iUUc4f671/wDn0vvZ9d/8Jj4c/wCg/pX/AIGR/wCNH/CY+HP+g/pX/gZH/jXyJRRzh/rvX/59L72fXf8AwmPhz/oP6V/4GR/40f8ACY+HP+g/pX/gZH/jXyJRRzh/rvX/AOfS+9n13/wmPhz/AKD+lf8AgZH/AI0f8Jj4c/6D+lf+Bkf+NfIlFHOH+u9f/n0vvZ9d/wDCY+HP+g/pX/gZH/jR/wAJj4c/6D+lf+Bkf+NfIlFHOH+u9f8A59L72fXf/CY+HP8AoP6V/wCBkf8AjR/wmPhz/oP6V/4GR/418iUUc4f671/+fS+9n13/AMJj4c/6D+lf+Bkf+NH/AAmPhz/oP6V/4GR/418iUUc4f671/wDn0vvZ9d/8Jj4c/wCg/pX/AIGR/wCNH/CY+HP+g/pX/gZH/jXyJRRzh/rvX/59L72fXf8AwmPhz/oP6V/4GR/40f8ACY+HP+g/pX/gZH/jXyJRRzh/rvX/AOfS+9n13/wmPhz/AKD+lf8AgZH/AI0f8Jj4c/6D+lf+Bkf+NfIlFHOH+u9f/n0vvZ9d/wDCY+HP+g/pX/gZH/jR/wAJj4c/6D+lf+Bkf+NfIlFHOH+u9f8A59L72fXf/CY+HP8AoP6V/wCBkf8AjR/wmPhz/oP6V/4GR/418iUUc4f671/+fS+9n13/AMJj4c/6D+lf+Bkf+NH/AAmPhz/oP6V/4GR/418iUUc4f671/wDn0vvZ9d/8Jj4c/wCg/pX/AIGR/wCNH/CY+HP+g/pX/gZH/jXyJRRzh/rvX/59L72fSHxH8UeFLzwjfwTX1lfzOpFtFbyrK6zYOxxtPygHqfTI5zg/POmX8mlajZ38Ko01pMkyBwSpZWBGcdsiqtFJu589mub1MxrxryiouK6ffudF8UNPi0zx9rkMTOyPMJyXIJ3SKJG6dssce2KKufGAL/wsXWck5/c9v+mKUVlJaswzSKjja0Y7KcvzYvwj/wCSlaR9Z/8A0TJXIV1/wj/5KVpH1n/9EyVyFXHYdX/cKX+Of/pNMKKKKDzwooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAoora0rSoHtf7Q1DzTZGRoY4oHCyTOAC3zEEKFDKSSDnIAHUq0rlQg5uy/wCG/r/gLUxaK6z7Zpn/AELmmf8Af25/+PUfbNM/6FzTP+/tz/8AHqfKzX2VP/n4v/Jv/kTk6K6z7Zpn/QuaZ/39uf8A49R9s0z/AKFzTP8Av7c//HqOVh7Kn/z8X/k3/wAicnRXWfbNM/6FzTP+/tz/APHqPtmmf9C5pn/f25/+PUcrD2VP/n4v/Jv/AJE5Oius+2aZ/wBC5pn/AH9uf/j1H2zTP+hc0z/v7c//AB6jlYeyp/8APxf+Tf8AyJydFdZ9s0z/AKFzTP8Av7c//HqPtmmf9C5pn/f25/8Aj1HKw9lT/wCfi/8AJv8A5E5Oius+2aZ/0Lmmf9/bn/49R9s0z/oXNM/7+3P/AMeo5WHsqf8Az8X/AJN/8icnRXWfbNM/6FzTP+/tz/8AHqPtmmf9C5pn/f25/wDj1HKw9lT/AOfi/wDJv/kTk6K6o6dYa66W1nZLY6lIQkCxSs0MrdkIcsysScBt23gAgAlhytJqxE6fKk07p9V/wbBRWzpWlQPa/wBoah5psjI0McUDhZJnABb5iCFChlJJBzkADqV0/tmmf9C5pv8A39uf/j1ZyqKLscE8WoytGLl6W/Vr+vM5Oius+2aZ/wBC5pv/AH9uf/j1H2zTP+hc03/v7c//AB6p9tEj65/07l/5L/8AJHJ0V1n2zTP+hc03/v7c/wDx6j7Zpn/Quab/AN/bn/49R7aIfXP+ncv/ACX/AOSOTorrPtmmf9C5pv8A39uf/j1H2zTP+hc03/v7c/8Ax6j20Q+uf9O5f+S//JHJ0V1n2zTP+hc03/v7c/8Ax6j7Zpn/AELmm/8Af25/+PUe2iH1z/p3L/yX/wCSOTorrPtmmf8AQuab/wB/bn/49VLUdLtbq1nvtOjeH7OA9zbO+4KpYKHRiM7dzBdpywyDlssVcasW7FQxabSlFq/e36NmBRRRWh2HWfGH/ko2s/8AbH/0SlFHxh/5KNrP/bH/ANEpRUS3Z6Obf7/X/wAcv/SmP+Ef/JStI+s//omSuQrsPhG7H4kaQNxxmfjP/TF64+rWwqv+4Uv8c/8A0mmFFFFB54UUUUAFFPhhkuZo4YY3kmkYIiIpLMxOAAB1JNenQfDbS/ClpDqPjXUfL8zmLTrT5nlIAbaW/NTjAGR84zTSudmEwFbFXdNWjHdt2S9X/TPO9K0e/wBcvFtNOtJbq4bHyRrnaMgZJ6AZI5OAM13tn8GNWS3S71vUdP0izGfNaWTc8XOFz0Tk4/j7+vFPvfilPYwrYeFLC30bT42yCsavLLjjLZBGSAuepyPvGuMvLjUNWmWa/u57iVVCh7iUuwXk4ySeOTx71SSOz/hNwys71pf+Ax/+Sf4HcDwl8OdP/wBG1DxXdz3affktEzE2eRjCOOhGfmPOenQO/tb4Wf8AQtap/wB/G/8Aj1cCLNccsSfani2jx939adif7YjHSlh6aX+Hm/GTf6X6nd/2t8LP+ha1T/v43/x6kPh/4Z6lzba9qFjcXP8Aq4plJSBm6KxKYwpODl+g+93rhfs0X939TTDaLjhmB96LB/bClpUoU2v8Nv8A0lo7ef4M3d3DJcaBrmm6tbRqQWR9rGQc7BgsucberDrzgc1w2ueHNV8N3Ag1SxltXb7pYZV+ATtYZDYyM4JxmpLc3enXCXFncSQzpnbLC5R1yMHBHTgkV1+l/FTVreI2WtwQa1pxVVa3u0XdhRx82Dk52klgx47Hmk0Vz5ZiVZxlRl3T5o/NP3l8r/M84or1VfAnhrxyssvhC/eyvUXe+m32cKuQuQ3JA4JOC/LKPlrzTUtNu9Ivp7G+geC6gba8b9Qf6gjkEcEHIqWrHJi8vrYaKqStKD2kneL+ffydn5FWiiikcQUUUUAFdZef8gbw5/15P/6Uz1yddZdEPofh51O5EtZImYcgOLiVip99rocejA9xVR3N6X8Op6f+3RINNtP7Q1G0tN+z7RKkW/Gdu4gZx3611k3gKKTVNQ0mw1Np9UslLmGW38sSgAEhGDNzz0IFctpN2lhqtjdSBjHBOkrBepCsCce/Fdq/jXSbLxDqWv2Ed7NqF0pWGOeNI44SQBkkMxbp7VZ3ZfDByp3xNr8yvq7qNndpJ6u9raP7jAh8MxQ6Jbatql81pb3blIEih82R8dWI3KAB9c+1alt8O5ZNdbTpr9UgazN7FcxRbxLHxj5SRg8+tU/+Eh0/VPDthpOqi6ifT3Yw3FsivuVjkqysy/nn8K2rT4hWS6+LmW2uI9Og082ECRhXkA4wzZIHb19KZ1YelljcPaWt7nV3bt799dEnta3Szepzlx4YWTRH1jTLtru0ilEUySReXLExxjK5YEHI5B71oN4Ght9UttGutWWHWLhAREIC0SMRkKz7s5PspHNQN4ks9M8OT6PpK3LtdTLLPc3Cqh+UgqqoC2OQOc1oz+LtGv8AxBaeIrq3vV1CEIz20YUxSSKODvJyo4HG09KCYU8v0vbm926u+Vavms76tLl6vra5n2ngi4NjqF5evPFHY3JtHjtoPPk3jknG5QFGRznvTNK8LWeqR61cLqcos9MjWUutrl5AQcjaXGCMY61Y07xg0N9e6i2pajY3l1cNK6WsSSxMp6AqzDkcjPPGK1k+INg+peJLny7yx/tSOOOGS1VWeMqCN5+ZeeexoLpUsslyNu297t66Ss7qStry3TS9bXMa48B3J1XSLGyuFnGqQieJ5E8souMneuTjA9zUY8I297Dqn9lan9ruNNUySxPB5e9B1ZDuOce4Fas3xBig1jQr62hmuZNOhaGee5wst0CMc4JxjnHJ61StfEmk6HHrEmlR3kl1qMTQr9oVVWBGPPIY7j0xwOlApUss5nZq13fV3S5Vbl11fNddenTUig8L6VceH7nWl1a9FrbzCFkNiu8scdB5uMc+tcysBuLpYLbfIZH2R5XDNk4HGTgn0ya3bTxBbQeC9Q0VkmN1cXKzK4A2BRt6nOc8elV/CWp2Oi67b6hfxSyxW2XRIgCS+PlzkjgHn8KRwVY4WpOjCFoppczu9Hd33b2VjS8YeBn8KQWs63y3kUrtFIyR7RFIADt6nPf06Vn+LPDn/CL6otl9p+0boVl37NnXPGMn0rXm8a2+qaHrGn6hYrFJdy/aoXtdzYnzyW3ucAjA+XpzxWf438QW3iXWEvLRJkiWBIsSgA5Gc9CeOaDox0Mv9nOphuvLZXenxKS19E9e+hzdJ4y/5G/X/wDr/uP/AEY1SRRSTypFEjSSyMFREGWYngADuar+K5o7nxTrk0MiSQyXs7o6MCrKZGIII6gipkebD+BL1X5SNW8/5A3hz/ryf/0pnqlDDJczRwwo0ksjBERRksScACrlyQ+h+H3U7kS1kiZhyA4uJWKn32uhx6MD3FP8P6p/Yeu6bqRj8wWdwkxT+8FYHFcE/iZ4KbUZuKu7y/NnfXHwG8UQaSbwNZyXCrvNmkhMn0BxtJ9s/jXnOnafcapqFtYWybrm5kWKNTxlicD6V9UXHxk8Iw6Ub5NSEr7MraqjCUt/dxjj69PevmKx16fT/EcOtxInnxXP2kJ/Dndu2/TtUI8jKsXjq8an1iFmtrq2uuh1afDWC61u78P2euLPr9sjMYDbFYZHUZZFk3ZJHPVQOKhT4aXM3gL/AISiC73yoXMliYsMqI5VmDZ5xwSMDAPtWnb+PPD+m+K73xZZ2uoNqk6u0dnKqCGKVxhmMgbLDk8bR161Dp3xLj0zQ/DltHDPJd6fdTy3iuq+VPFKW3IOechu460alOePtHk/u3ul2fMvS9lfz3Yq/Cjd4mbRf7X+7pn9o+d9m+nybd/v1z+Fc54J8Jf8Jjqd1ZfbPsvkWslzv8vfu24+XGR1z1run+KOhHx1PrKWuoJpz6UdPVPLQyK2euN+MY981zvg3xJoHg3WLi8jn1O8iuLKa3YNZxxMrMV2kfvWyODnpjjr2Bwq432UuZPm5VbRb636W7b/ACIovhvcXXgBfFVteiVwXZ7LysMsaOVZw27nHBPHQ1oxfChX8UnRG1gqo00aiZxa5OOPk27/AH65/CotJ+I8GjeHvDNjbwTvcaZczPdI6r5U8MhO5Bzk5B7jrW7/AMLU0NfHkuuRW+oxWB0v7CirGnmo2Rg434wAPXNGpFSpmCc1Fae9bRd/dX3arvfXY8s1KLTIjH/Z13d3AOd5ubVYdvpjbI+e/pUuhf8AH1df9eF5/wCk0lWfEmprqb27jW9W1VkBBbUo9pjHGAv71855z06d6raIQk17Kx2xpYXe5zwF3QOi5PbLMqj1LAdTVR3R6cm3h3fez/rZfkchRRRXae4dZ8Yf+Sjaz/2x/wDRKUU74wOw+IusgMQP3Pf/AKYpRUS3Z6Obf7/X/wAcv/SmL8I/+SlaR9Z//RMlchXX/CP/AJKVpH1n/wDRMlchVx2FV/3Cl/jn/wCk0wooooPPCtTw94ev/E+qRadp0XmTycsx4WNe7MewH+AGSQKq6bpt3q99BY2MDz3U7bUjTqT/AEAHJJ4AGTXqmv6nF8MtFj8NaLsXWrqFZNRv0fcysR91TwQeuMgbVII5bcGkejgcHCpGWIxDapR3tu30ivN/gtQutW0P4Ww32m+Hy994kdVin1CVVKQnHzKo9QRnbyMkbi23bXnd3c3etXs99fTvLcTtueR+rH29BjgAcAYAqCC3BAdunYVZeRYxlj+HrV26szxuYVMTanFcsFtFbL/N929QSNYxhR/9eh5Ej+8wFUpLp34Hyj261BUOqlscipdy8byMHHzH3Apn23/pn+tVKKh1ZFeziW/tv/TP9aeLxDjIYVRoo9pIPZxNNJUf7rAn0pzKHGGAIrKqWO4ePjOV9DVqr3JdLsWBHLaSxz28jpLGwZGQ4ZCOQQR3zXodh4x0nxxYwaN413rcibNvqkISMx56hjjCjgDOCCCCQCu6uBimWUZB57io57cNl14PcetX5o6cHj6uEbS1i94vZ+q/J7roW/GPg6/8GaobS7HmQSZa3uVGFmX+hHGR29wQTz1ereB/EVt4ks4/BniRfPsp/lsrksA9u4B2qGP5L167cFTgee+IfD1/4Y1SXTtRi8uePlWHKyL2ZT3B/wAQcEEVLR0Y7CU+RYvC39nJ2t1i/wCVv8n1XmjLoooqTzArV0rWFs42tbuFrmwZt/lLJsdHx95GIO0nAB4IIAyMhSuVRTKhNwd4nU+f4c/6COq/+C+P/wCP0ef4c/6COq/+C+P/AOP1y1FPmZr7Wn/z7X/k3/yR1Pn+HP8AoI6r/wCC+P8A+P0ef4c/6COq/wDgvj/+P1y1FHMw9rT/AOfa/wDJv/kjqfP8Of8AQR1X/wAF8f8A8fo8/wAOf9BHVf8AwXx//H65aijmYe1p/wDPtf8Ak3/yR1Pn+HP+gjqv/gvj/wDj9Hn+HP8AoI6r/wCC+P8A+P1y1FHMw9rT/wCfa/8AJv8A5I6nz/Dn/QR1X/wXx/8Ax+jz/Dn/AEEdV/8ABfH/APH65aijmYe1p/8APtf+Tf8AyR1Pn+HP+gjqv/gvj/8Aj9Hn+HP+gjqv/gvj/wDj9ctRRzMPa0/+fa/8m/8AkjqfP8Of9BHVf/BfH/8AH6PP8Of9BHVf/BfH/wDH65aijmYe1p/8+1/5N/8AJHSTa1YacpOkfapLw/dvLhVjMP8AuRqW+cdnLcZOFBAYc3RRSbuZzqOelrJdF/X4vU1NL1dbONra7ha5sGbf5SybHR8feRiDtJwAeCCAMjIUrqef4d/6CGq/+C+P/wCP1y9FZypxlqzjqYWMpcybXpb9UzqPP8O/9BDVf/BfH/8AH6PP8O/9BDVf/BfH/wDH65eil7KJH1P++/w/yOo8/wAO/wDQQ1X/AMF8f/x+jz/Dv/QQ1X/wXx//AB+uXoo9lEPqf99/h/kdR5/h3/oIar/4L4//AI/R5/h3/oIar/4L4/8A4/XL0UeyiH1P++/w/wAjqPP8O/8AQQ1X/wAF8f8A8fo8/wAO/wDQQ1X/AMF8f/x+uXoo9lEPqf8Aff4f5HUef4d/6CGq/wDgvj/+P1Q1LWIWgez02OWK1fHnSSsDJcYPGccKuQG2AnnqzYXGNRTVOKdyoYWMWpSbdu9v0S/EKKKKs6jrPjD/AMlG1n/tj/6JSij4w/8AJRtZ/wC2P/olKKiW7PRzb/f6/wDjl/6UyT4Rhf8AhZGkcnOZ+3/TF64+uv8AhH/yUrSPrP8A+iZK5CrWwqv+4Uv8c/8A0mmFFFb3g3w3J4r8RWemoHELtvndc/JEOWOcHBxwMjGSB3pnHRozrVI0qau5Oy+Z3fhOCz8AeEP+EqvYIpNevty6bBOSMJwNwXGRwSxPdSoBG7nztPMu55Li4d5HkYuzucs7E5JJPWun+IniCPxD4jNvZFF0rT1+y2qRYEYVerKASuCRwRjKhfSsBVCKFHQVaR35riI80cLR+CnovN/al83t5JCSOI0LH/8AXWa7tIxZjzU94+XCA8Dr9arVjUld2OCnGyuFFFFZmgUUUUAFFFFABRRRQAqsVIIOCK0YZRKmeN3cVm1NavslAzw3FaU5WdjOcbomuYf41H1r0nFv8TvBUu9EbxbosP7sqzGW6hXHJGCXJ5GOfnwcqHweAIyMHpVzwrr0nhHxJaaghcwo22ZF/wCWkR4YYyMnuM8ZANbtHZleKhRqOlW/hz0l6dGvOL1RytFdl8S/DcegeInmswh0nUl+1Wrxcx7W5KqQAuATwBnClfWuNrNnNisPPDVpUZ7xdv8Ag/MKKK92/Z4/Zw/4X3b+IZf+Em/sX+x3gXH2H7T5vmBz/wA9E242e+c0m0ldmB4TRXtXgD9nbUPFvxl1j4aarqv9jX2lpM73ItfPDhCu0hN6/KysGBz0Iry/xhoH/CKeLde0D7R9p/sm/nsvP2bPN8qRk3bcnGducZOM9TSunoBi0UUUwCiiigAoor179n34G/8AC9vEWq6R/b39jfYLT7V5v2T7Rv8AnVduN6Y+9nOTQ3bVgeQ0VLcw/Z7maHdu8tymcYzg4qKgAoor2P4x/Aj/AIVL4V8Ea7/b/wDaf/CUW5uPI+x+T9mxHG+N3mNv/wBbjOB096LrYDxyiirFhYz6nfW1lap5lzdSrDEmcbnYgAfmaAK9FfRnjL9mLQ/h81rpXib4q6Lpvi26tRdR6dNYT/ZypLKM3I4ALKwyyjp0r5zpJp7AFFbPhPwpq3jfxFp/h/QrN7vVb+Ty4YVOMnGSSTwAACSTwACa9w8Q/s4eD/Al4mj+M/jHpGk+JSivJYW+lz3aRZGQGkUjbwQfmUcEHHNDaQWPnaitXxLpEGg69qGm22p2mqW9rKUjvrQ5inXsy57GsqmAUUUUAFFdL8PfCX/CeeONA8M/bPsX9rXcdr9p8rzPK3HG7bkZx6ZFbPxm+Gv/AAqL4han4S/tT+0/sKQv9r8jyN/mRq/3NzYxux1PSi+tgOBooooAKKKKACiivS/DHwQ8QeLPhb4g+IlleaXHomhTPBcQTyyC4dkSNjsUIVIxKvVh0P4jdgML4wBf+Fi6zknP7nt/0xSim/GH/ko2s/8AbH/0SlFRLdno5t/v9f8Axy/9KY/4R/8AJStI+s//AKJkrkK6/wCEf/JStI+s/wD6JkrkKuOwqv8AuFL/ABz/APSaYV6x8NnTw54F8U+Jlb/Sx/okDLErNE2Bg5PYtIhI/wBjv0ryevVfGA/sj4Y+DdJ/1v2rdfeb93bkFtuOc/6/Gc/w9OeKidGTv2Lq4v8A59xdv8UvdX53/wAtzz20TJZyOnAq3UcC7Yl6c81JWi2PEZBJBG8mWYhm7Un2OP1b86jvW+ZF7gZrqvhbqnh2w8feHrjxisr+HILtJLry4ll4HK70IO+PcF3gAkpuABOKxlKKbujWMZNKzPoX4I/sg6X448FweJPFuo6tZ/2l+8srWy2xOsIJAeQyRtnfwy7Rjbg5O7C+lf8ADDHw7/6DPin/AMCrf/4xX0do+rWev6RYatp03nafqEEdzby7Su+N1DK2GAIyCDggGrteJPEVHJu9j1o0IJJWufMn/DDHw7/6DPin/wACrf8A+MUf8MMfDv8A6DPin/wKt/8A4xX03RU+3qdyvYw7HzJ/wwx8O/8AoM+Kf/Aq3/8AjFH/AAwx8O/+gz4p/wDAq3/+MV9N0Ue3qdw9jDseNfD39lz4deAf7Rzpv9v/AG3y/wDkYILe78jZu/1f7obd27n12r6V2F38KvhrZWk9zL4A8NNHBG0jCHQoZXIAydqLGWY8cBQSegBNdsuAwz0qTcnt+VdNKtJx1kvmctalFS0T+R+ZX7R+qeAPEnjjT7v4ew2MOippscUq2FgbOMziWUsShRcnaU+bHTAzxXj620ayLhm3DnFfUP7TvxG+EfjDwjbnwIdLk8TS6stzd3FvpD208kRjl3s0rRLuy7ISCSSee2a+WLRv33OSWBr04uOiscLUrN3L1V7tMoGxyP5VYprrvRl45Het2ZI77VHTxN8Gba7lb/S9BuFg3tEuWXIUIpHQbZI8nuU59a8lr1b4Qj+0h4m0D/V/2nYH9/18vGU+73/1ueo+778eU1mz28zftqGHxT3lHlfrB2v9ziFfaH7El1NZfD74xXNvI0VxBaQyRyKcFGENyQR7givi+vTPhj8cfEPwn0PxPpGi2el3Ft4jiWG6a9ikd0AV1+Qq6gHEjdQegrOSurHjo+7fg6tj8WvEHhD4zWAhj1RtKn0XXoEwMXC7CrY/A++14/SvMP2efCuj6h8bfjp4nvbCHUNV8PalctYQSqG2s89wWZQf4v3SqD23H1r5s+Df7Qni34IJqsXh+LTrq11Io0tvqMckkauuQHUI6kEg4PPIA9BWx8GPiVrkHxf1nxLb+LNG8LahrRuLmZtSidtPuJJJQ5hfBJRcsSGzkbcZ5qHBq47n0v8AsufFDXPirpHxU1TxFbWL6lDbRKL+2tEgaSNknIibaBuCYJUnLfOck8V518C7Dx54J+C48WzfFWz8C+Bbq8eSFW0WPUZZZC3lFtpXcMmPAAJ4UnA616FH8ZdD+GHgrxnea34r8DalreswlLDQ/A8Y+yrKVcGR2HJZy6lmc8CMYyTivlrwR+0b4s8E+CZPBgsdB1vw6XLxWet2P2lICW3HaNwB+YlsMGAJoSbvYdz3r9r/AEPRdV+DngHxzBPa6lrF3cRW761BYGyOoRSQSPvaI8jJjBAPTcccGuy+NvxH1P4ceEPgXd6LBZDUbqGKP7VcWyTPHD5Vv5kabgdu/K5YYbC8EZNfJ/xF/aI8W/FHwPpPhPX4NKNnplwt1Hc28DxzyOqOgDfOUC4kPCqoGBjAGKrfED48+I/iPpfg/T9VstJhh8KKEs2tIpFaQBY1/ebpGzxEvTb1P4NQelxXPs74l+Kz8Of2lPAeh+GtK0qwj8WSRPrU6WcZlvQ8hiClyMqFCk/LjJPOatfDDw9p3hv9rz4nWul2sVpaS6Pb3PkwqFRXfyWcgDpliT9Sa+NfGP7R3inxv8RvDPjrULDRotX8O+X9mht4ZVgfZIZBvUyFjyx6MOK2NM/ax8aaV8Stb8fQ6Z4fbWNYs47KeF4JjAqJtwVUS7gfkGcsR14pcjsO6Pfv2cvGFz8ZNY8ffDrxVoWmN4QtoHa2sIrJIhY4l2bAwGS2DnexLbkzmsf9lfwb4Y0D4Z/ELxzcXdnDq+l3lxZQ6xcWBvhp0MUaMJlhXkk7yTjqFHbNeJj9q3x5B4b1PSLKDQbC61VSt7rFlp4hv7nIIJeQHDNgkbyu7nOc81x/wt+NHiz4Q3V5J4duoGtL5Qt3YXkXm29wBnG5eDnkjIIODjpT5HqK59GfFb4kfC3xz8H9V03XPH9n4t8e2xM+l6tF4bn06YkFSIjhNuCNwJJAII4yua+iH+Hvhzxt4b+FV9rUEep3+gaIbzTtEkkVFvpfIg5bd1CkLweMuCeBg/AHjD4+az4s8P32hQeGvCGgadqG0XS6HpCW7zBXDgFyWb7yg8EVZ8TftJ+NfEieBypsNLufBi7dOutOjkSQ/IiHzN7sGysYBGADlgRg4pOD6BcyPjd8R/F/xG8c39x4vSWzu7GR7eLSmBVLBQeYwp78cseSfbAG5+zB8N9O+KHxb07SdWmkTTrWJ7+VIpDG83lkYQMORlmBJHOAcEHkc/8AFr4wal8Y9VttW1rQ9CsdVhj8qS70yGWJ7lR90SbpGDEdjgHHGcAAcr4T8W6z4G8QWWv6BfSWWq2Tb4pkwcZGCCDwQQSCDwQa0s7WQup91+Oo/DH7XFv4p8NW1uNE+JHg67uIrAXT/Ncwo5X5jjOxiORyUYg8gkH50/ai8CeDPhlrnhnwt4ZtI49Zs9NSTWp47iWUTTsFxkOxCHCs+FA4kHHSrM37Ynjj7XNqVnofg/T9fnQRzaza6QBeSjj7zsxB6DjGK8/+LXxe1H4xavbaxrOiaHY6rFH5Ul1pkMsT3Kj7vmbpGBI6AgA44zgACIxafkNs9U/YWu7C2+ODR3jIJ7jSbiK03dTLujY49/LWT8M15f8AH+y1Gw+NfjyPVFkW5fV7iVfMzzE7loiPYxlce2K4PS9UvdE1G11HTbqa0v7SRZYbiFyrxuDkEEdDXuFz+1n4s1aK2bX/AAx4I8QajboEj1LVtFWW5UexDBR+Ciqs07oR3X7Dfgfw9r+q+MfEOsWttd3ug28Bs47iDz0iMnmlpfL6sw8sAY55OOSK7bW/iv8ACvxb4F8TaH48+KFh4uu7qJm0qdPCdxYS6fJtbaEZUbI3bcZxwCCWB4+WPDvxv8ZeFPH1/wCNdIv4bXV9QYm6jSBRbzKSDsMXTbwMYwRjgiuk8Q/tLeINcsNTtrfwr4J0efVIZILu90vRUjuZkkUq+ZGZjlgTyOalxbdx3PoTWfGd74C/Yv8Ah3rOmQ2jarHdxpaz3Nuk4tpC1wfMVHBUttDKCQcbs9QDW18ePiBc+ArD4WeNdD0rSLfxd4njgF9qbWUbyNCEjdogWB2hjLyR82AACK+RNe+N/iHxD8KNF+G11Z6Wmh6PMs8E8UUguWYeZjcxcqR+8boo6CpfiB8d/EfxH0bwhpWq2WlQ2/hVAlm1pFIrSAKi/vC0jA8Rr0C9TQoahc+oPjV4d03Rf2xvhZd6faQ20mptazXIiQKJZBO67yB/EVCgn/ZFbfjH4q674d/a6sfB9hptgNE1prSDUEazRpb4SRAeY0hG7CDAAB2/Icjk18q+L/2kfFXjX4i+GfHV/p+ixav4dCC2ht4ZVgfa5cb1MhY8sejDiulP7ZPjp/Et14hl0bwnNqkiCO2ml00u9iuwKRDIX3qGwSVLMMk8DJpcjHc+lPAXwY8D6T+0H8U7+PT7Jk0O3s7qysng86KzkuIneR1iHXBQFQOgfAxxXIa38V/hX4t8C+JtD8efFCw8XXd1EzaVOnhO4sJdPk2ttCMqNkbtuM44BBLA8fLHhz45eOfC/j2/8b2WtO2vaixN48yB47lSR8jp02jAwBjbgYxXSeIf2lvEGuWGp21v4V8E6PPqkMkF3e6XoqR3MySKVfMjMxywJ5HNPkdxXPdvg7rw8MfsU+LdX+w2t7JaajI8UF3GJIjJ5luEZkPDBWKtg8HbzxVv9jP4heIviV8UfFer+J9QW91CPRobZHWCOELEsxIULGqjgsecZ5r5g0r43eINH+Eeq/DKCz0ttB1Obz5Z5IpDcq25GwrBwoGY16qeprK+F3xU8RfCDxN/b/huaFbpomglhuELxTxkg7WAIPVQcgg8daHC6YXPpn9iWCVfDnxnlZGCGzgTcRxuCXWR+o/Oun+CPxO8VW/7IHjHWo9V26n4ZmkstLm+zxH7PDHDblF27cNgu3LAnnk9K8Lsf2v/ABvph19LPRfCltZa3Htls7bTmhhiYhg8ihJATI+/5mcsTtXpjnkvhb8fvE/wo0TVtC06y0bVNC1Vt9zp2sWpnhZioVjgMucqACCSDgcUOLdwTMj4+a5f+I/ivr2o6nP595KLcNJsVcgQRgcKAOgopnx41L+1/iv4hvfslpZ+cYD5FnH5cSYgjHyrk46Z+pooe52ZjFRxdWKjy2lLTtq9PkVfhG7H4kaQNxxmfjP/AExeuPrr/hH/AMlK0j6z/wDomSuQrRbF1f8AcKX+Of8A6TTCvVvjQPsWraNpMHyafZWC+RF12ZYqeTyeI1HJ7fWvKa9W+OX/ACNln/14J/6MkqlszfCaZdiX50/zl/kvuOGUbVAHQDFVL1vmVfQZq5VC7bMxHoMU6vwnkU/iIKKKK5joP1x+Fdncad8MPBVneW8tvd2+i2UU0EyFHjdYEDKynkEEEEHpXzD4Nsrn9r34l6/Hrvie607wfpQ8+00W3lWOeSPLpE6xncm5d2ZJDuILqgwGXb9g3uo2unRh7qdIlPQHqfoOp61+f3j/AOEfij4feOZ9U8Af2lPp0k7Np1zopmFzaiTcPJIBMuVXK7+QwIycsVHn4Rx5m3o+h6NahWlTUoRbXodb8L/F2t/BH43n4bXHiEa74aa+Gl7bdjJFHJI37to1LYhcSSYlUEgHzAd7Kpr7er4j/Z1/Z18RSeLtL8VeKtLl0zSdMcXVvbXYMc9xOpIT5AQ0YR1D5cDdhQAysSPtypxbg5+78ycOpKPvBXyj8b/F2t/EL4x6V8INJ8Qjw7pcxSC/upWMYuJJYi5QkNmRTG6osZ2h5H2nPykfV1fJv7UHwA1vxPrp8aeFLL7dNLAF1GyjY+czRodsyBm+fKKqbEAbKrgMWbE4VxVT3h11Jw904j4q+GNR/ZN+IGk3HgnxVLPY6lGLltNupg0hEfylbmNNqvGxZ9j4Uj5wMMm8/a/h7W7fxLoGla1aJKlrqdrFdxJMAHVJEDqGAJAOCM4J+tfnXo/wn8ffEPxaW8TJq1lJK8YvtV11JTKibcA4k+eUhVCgD/ZBKg5H6G+G20e10qz0vRnRbLT4EtoINzFkjRQqj5vmIAwMnP1rXGOLtbVhhqFZQc3F8ve2h+QF5Z3GnXdxZ3lvLb3dvI0U0EyFHjdThlZTyCCCCD0qGu0+MH/JWvHv/Yev/wD0oeuLruTurnntWdie0bEwHqMVfrNgbbMh98VpV00noYVVqdP8JLqW08e2cMT7Y7hJYpBgHcoQtj2+ZFPHpXHeJbSHT/EesWlsmy3t7uaKNMk7VVyAMnk8DvXV/Cz/AJKHpf1m/wDRT1zfjL/kb9f/AOv+4/8ARjUPY9aeuUwb6VJf+kxMSiituDwte3Hha48RRvAbO3uPs8ke4+aOF+fGMbcugznOWHFI8cxKK6PVfBGr6XPpNt5P2u71O2F1Fb2itJIoJIKsuPvAqcgZxWTHo+ozagdOjsLp9QBKm1WFjLkdRsxnP4UAUqK0INB1W6vJ7ODTL2W8gBMsCQO0kYHXcoGR+NXr3wxLb+K4/D8M6STyTRQJLIpRdz7cZAyQAW96AMGiunTwlbvrem6VH4g0+5mvLyOzcWsU5aHcwUsRJGgIBPQH/GsdNF1CeSNbayupxNK0MRjhZvNdeqrgckAg4HrQFyhRWpF4Z1ue6mtYtH1CS6gYJJCls5dGIJAK4yCQCefQ1HZ6DquoTSw2mmXtxNC4jkSGBnZG5+UgDg/K3H+yfSgDPoq62j6iunLqLWF0NPZtoujC3lE+m/GM/jVn/hGtUinhhu7G6szPE80ZuLaQeYqIWJACkkYHUDA6kgZIAMmiitzwv4VvvF13dWmntAJ4LdrjbKxXzMFQEXAOWJYAA4GT1oAw6K3LLwnqOox6W1sInbUpJo40L7SnlBS7OTgKoDZznoDnFRapokWnQiWHWNNvwGCMtq77lOD2dFyOOq5HvyKAMiitvxD4Vv8AwymnNemEi+gWdPKYnZkAlGyBhwCpI5xuFbJ+GOsDxhb+GfOsvtc6CRbjzG8jbyMltufvAp0+9xRYLnF0V1lj4Bur+304pqmmpeakZBaWUhlEsxR2TAPl7ASynGWHaqsXhRBpFjqN3rmmWS3yO8MM63DSMFcofuRMo5U96LBc52iuisvBmoX1vYXSyW8dpdQyXDTyMQltGjlC0hxxyOAMk5AAJOK55wFZgGDAHAYZwffmgBKKKKQwooooAKKKKACiiigAooooA674wOw+IusgMQP3Pf8A6YpRTfjD/wAlG1n/ALY/+iUoqJbs9HNv9/r/AOOX/pTH/CP/AJKVpH1n/wDRMlchXYfCML/wsjSOTnM/b/pi9cfVrYVX/cKX+Of/AKTTCvVviyf7Rs/CWuy8Xeo2A81E+4uAr/KOvWVupPQfj5TXqlwf+Eg+DNlcffuNDuzFJLPy2wnAVDycYkiGDj7nsKpG+W/vMNiaHVxUl/2603+DZw6ElFJ6kCs+dt0zk+uKt2rZix3U1RZtzFj1JzSqvRHlU1qxKKK6f4b6tZ6B8RPCOrajN5On6fq1pc3Eu0tsjSZGZsKCTgAnABNc7dkbLc/Tfxjp92uoyXbI72rKoVxkhMADB9Oefx+tc/a2k97MIreJ5ZD2UdO2T6DnrXrVneW+o2lveWdxFcWlxGssM8Lh0kRhlWVhwQQQQR1qavF5rH1lHNpU6Shy3sQ2cckNpbxzPvlSNVds53MBycmsHxV460bweqDUJ3a5kXeltCu6RlzjPYAdepGcHGSK6SvnL402F7b+Mnubhne1uoUNsSWKqqgBkGeAQ2WIH98HvUN2Msuw0MXiOSo7LV+vkev+FviRoXiy4+y2kssF6dxW3uUCs4ABJUgkHqeM54JxgZrrq+WPhtYXt/410gWTOjQzCaV1LALEvL5I6Aj5eeCWAPWvqehO5Wa4OnhaqjTejV/Q8m1PT7uwunW7R97MT5hyRJ6kHv1/XmrvhrT7u51O2mgR1iikDPLyFAGMjPqQcY9/SvTKKvmNJZvKVPk5df66H5K/GD/krXj3/sPX/wD6UPXF16p+0j4i0vxX8a/Feq6LexX2myyQRx3MJykhjgjjYqf4huRgGHBxkEgg15XXsw+FHyc/iYqttYMOoOa1aya0JJP9H3HGWX+ddFJ7mFVbHbfBiyjvfGnnyM4e0tpJ024wWOE59sOfxxXnep38mq6jeX8yos13M8zhAQoZmJOM9smvS/AZ/sPwJ4v8QH5XaMWcEsPE0TkYyDxgbpIzwc/L04FeVVTPVxn7rAYej1fNN/N8q/CLCu28PeLLLQ/D1rbTwC+ze3DXNixKCWF4o1Hz4IHzJkdeVHFcTRSPHselN4vsdX05be81L7Nf32mzQT3ZjcrDK1885VtoJ2shAJUHG4D1FQy+ItLubrULH+0mjWfSINOXVXifDvGyMSwAL7GCFOmcBcjqK87oouKx6VqHiHSdV0+40lNaNrJEtl/xMpIpcXfkI6sCFBcYLjbkdEGdvGMzU/EGn3PxSh1tLt5NNXUIJ2uHRgxRSm5iuM54PFcRRRcdj0a41u0j8VaJqU2t6Dc2dvqkVw407TGt5Y4xIGLORbxlgAOmWOe1RXHiWxvtYstTt9QisVMElnJYzwSNBAhQqduwZEbhiTj5wxJ5+8fPqKLhY9SU6Rc+HfEsNlrP2O0eTTo2nInaDzAs5KLkGTy+MjIJyB25rJ1/xVZ31n4ojtbuXdfz2CqWVla5SGKRXkb03NtbBOct7GuIW5mSCS3WWRYJWV3jDEKzLnaSOhI3HHpk+tRUXFY9PvfGOlTaZ59qdOhuJNOisHiaK7e5XaiqcDzBBt3LuB4P+znJLZPEGiLqCahNqUMt/cC9ad7SOdYmMls6qXSQcSF2A+T5QDXmVFFwsauh3f2Q6j/xMPsXm2csX+p8zz84/df7O7+92xVzwrq8WkR6473DQTz2Bit2UHJl82JhgjpwpOT6Vz1FA7Hqt1420Fzok6NIv2uK/TU4YoiDavcxrGzJnAI3BnAB6HbxWdps3hiysINM1LVNOvrc3sMwntdOZZY4V3tIrSNGrkvlVAywHqAK87oouKx33iPxZo3ifQ9UX7PeWeom/Oow/abkXAkaT5ZY12xJsGAh5z9zH12n+JNiPFqFQpsf7Zin/tL5ty2YmSVo9m3ON6B/XqMHNeT0UXCyPWtC8W6ZaWPh0vrGmww2LTi8t5bB3u2R5nbEUoiJQlG4IkXBNZketWVx4V0eytdZ0Oza2jnSWDU9MNxKN0zsu2T7PJj5SOjDmvOKKLhY9Dt/FWlXfg/RfC+oTulkUkaaeJG32k/nSFHI/wCWibX5Xng5GCMHz+VFjldFkWRVYgOucMPUZAOPqBTKKB2CiiikMKKKKACiiigAooooAKKKKAOs+MP/ACUbWf8Atj/6JSinfGAL/wALF1nJOf3Pb/pilFRLdno5t/v9f/HL/wBKYvwj/wCSlaR9Z/8A0TJXIV1/wj/5KVpH1n/9EyVyFXHYVX/cKX+Of/pNMK9R+DuqQ3E2r+F7ySVbfWIGEZVz8rBWDhRggEoScn/nmBzxXl1T2d3Np95b3ds+y4t5FljfAO1lOQcHg8jvTTsZ5fi3g8TCva6W67p6NfcXpoJ9Mu7q0uF8u4gZopFyDtdSQRkcHkVSr0r4kWC6/Yab4106B/suoQqt4FywhlX5eSe2RsyABlB/eFea1FTexpjMJ9UrSpp3jvF94vVP5r8dAoqW3h85yC21FUszYzgD2p/l2f8Az+/+QjWZzNpH1B+zJ+03Z+ANPTwd4xfyvDkXmSWOoRQl2tGYl2jkVAWdGYsQwBZWbBypBT7ws7y31G0t7yzuIri0uI1lhnhcOkiMMqysOCCCCCOtfjf5dn/z+/8AkI16d8NPj14t+FWyDRvEX2jSVz/xK9Qhea1Gd5+Vcho/mcsfLZdxxuz0rkrYXnfNHc6KWJUdJbH6kVBd2dtqFu9vd28VxbvjdFMgdWwcjIPB5ANec/CH4uv8W9CstWs/DF7b2s8ksU1zHeWs0Fu6Z+Vv3izAkbTgxA/OD90hj6gYnBxtP5VwypTjujshWi9YspWGm2WlwtDY2dvaws28pBGqKWwBnAHXgflVqneW5/hP5VxXxJ8fS/DjQtS1ifw/e3mn2Nobh7tbq1ht1fkLGxklD5LbR8qOTvAUM3y0o0py2Q51Y7yZ2dfG37Sf7U+l3eiX3g3wLdxX7X8ctrqWqBMxRxHKPFFuGHLDOZBlQpG0ktuTxr4pftNeLfib9psv7Z/sXQJdyf2dpyOnmRneNssv3pMo+1hwjbQdgNeL+XZ/8/v/AJCNd1HCcr5pnHVxSekSvRVjy7P/AJ/f/IRps8CxrG8cnmRSA4bGOh54rsOa6ZDUzyFoo1z0FQ133wv8Prd6o+u36umj6MrXMkxUlTIg3ADBySPv8A/dAI+YVpT3sb4bCTxdaNGHV79l1b8ktWaXxEuf+EZ8E+HvCKmVLtoxd3amT7uSx2HA2sDIWxzx5Y65BryetTxHrk3iTXL7VJxte6k3BODsUcKuQBnCgDOOcZrLq27jzPFxxWIcofBFKMf8K0X+fzCiirFtbeb+8kyIgcZHVj6D/Ht+QIeeV6K0sW44FrGQO7M2T9cEUv7j/n0i/wC+n/8AiqfKLmMyitP9x/z6Rf8AfT//ABVH7j/n0i/76f8A+Ko5Q5jMorT/AHH/AD6Rf99P/wDFUfuP+fSL/vp//iqOUOYzKK0/3H/PpF/30/8A8VR+4/59Iv8Avp//AIqjlDmMyitP9x/z6Rf99P8A/FUfuP8An0i/76f/AOKo5Q5jMorT/cf8+kX/AH0//wAVR+4/59Iv++n/APiqOUOYzKK0/wBx/wA+kX/fT/8AxVH7j/n0i/76f/4qjlDmMyitP9x/z6Rf99P/APFUfuP+fSL/AL6f/wCKo5Q5jMorT/cf8+kX/fT/APxVH7j/AJ9Iv++n/wDiqOUOYzKK0/3H/PpF/wB9P/8AFUfuP+fSL/vp/wD4qjlDmMyitP8Acf8APpF/30//AMVR+4/59Iv++n/+Ko5Q5jMorT/cf8+kX/fT/wDxVH7j/n0i/wC+n/8AiqOUOYzKK0/3H/PpF/30/wD8VR+4/wCfSL/vp/8A4qjlDmMyitP9x/z6Rf8AfT//ABVVri2VVMkO4xj7ysclf8R7/h6ZGguVaKKKko6z4w/8lG1n/tj/AOiUoo+MP/JRtZ/7Y/8AolKKiW7PRzb/AH+v/jl/6Ux/wj/5KVpH1n/9EyVyFdh8I3Y/EjSBuOMz8Z/6YvXH1a2FV/3Cl/jn/wCk0wooooPPNe28QX8Og3GhpLjT551uXQcEsBjGR1B+U4OeUUjHOaFRxd6nhiM0qRjOWOOBnFZy3Oj2kpxXM720XoSTN9nsNh+/cEHHoo6H8TWdVq/mE1y23Hlx/ImDnge9VahmQUUUUgPon9kb41f8K18dLomtap9m8Ia5lJvtEu2C0ucDy5z8p252iNjlRhgzHEYx+l9fiPX6Ufsh/HGT4meEZPDut3U0/irQI18y4uZkaS+tyxCSAcMSnyo5IPJRixZyAMaPpCvgf9tr41f21rEHw+0DVN+mafl9Y+zS5Sa5DfLA/wAvPlbdxAYjc+CA0XH0x+0h8ZIvg58Pp7y3bd4h1TfZ6XGrx7o5ShzcFXzuSPgn5WBZkU4DZH5XXt7c6leXF5eXE1zeXMjSzTzOXkldjlmZjySSSSTySaEDIKKKKBBWhZN59tLbfxg+anuQOR+VZ9S207W08cq9VOceo7imgJa0IvEF/aaHe6NFLiwvpEklQ88pzx2GTtJI5OxeccGtdxCGdlTmM/Mp7EGqsv3R9auOjNVUlBNwdrq3yejXzRFRRRWhzhWkOLS1A4BQsfc7mGfyA/Ks2tP/AJdbT/rmf/Q2qokyGUVa0zTrjV9Ss9Ps4zJd3kyQRIP4nYhVH5kV7b8Rfh5Y28mhTXOk3Ph3RdP1IaBdX0li0P2mFQpS85A3s+JiW56L7U7knhFFelXHhGxtrfxBPa2t3bWqaM1zCZ7i2vkkZbqGMlJ0TbjDnO0KyngnBIOp4X8IeG/7d8HXFvbXerWcl/YJeTi7gkgZpSu6OSDYXiAclfn3BwpAxkEFwPIaK9R0fwZoHiH+3tYiguLbS7G6itI7G41u0tpHkcSMW+0TIiBQIzhAhY564BNTv4C8I6WbcXl9qGorea3JpcE2m3UHliIRwOJCwV1ZlM+CqnBI4ZcclwPJ6K1pPD903id/D9qPPvTemxjAGPMffsH5mvcfE/w+htPEPgyceGJNP07T9eg0Cf7TYmJNRiVkKXDBlAk8zE2488BR6UXA+eKK9E+H1jaXHxWNtPDZG1Rr8hLqASwJsgmKloyrAhSAcbT06GtfVl0HXdI1FrWfTbrV9N0aWe8vNL01ba2mY3cCxhY3iTawV2y6IhOQMkbslwPJKK9Q8W+C/C+kTeKYNN/th38NX0cM7XNxFi6iaQowXEf7tgQAGO4Hk7R0q54o8OaFqPxR8SWOm+HL4afYSz/aI49XtrOGIiQKHEjwCOKPkKEOeSMN2JcDyOivVNW+H/h7wzF4hvNTfUbq2sjprWkNndwZkW6hkkKtMquh27MB0BDYOB8wIwPhlY2UmsX2p6qkB0rSrOSed54fOWJnxDC/ldJNsssZKnggHPpRcDiqK7Dxv4X1TSimrajHpsEd9MY7cWChIrlVRCZ4lUbfLbevIwNxI2jBA7zSPCWj+KPAXhK0e3tbO8t45dUvL5I1WWWzW6ljuNzdXKKI2UHoA1FwPE6K9Z+J2i6Vew6n4isrGLTSsWiGKys0WOBBdWUksnygdd0a857nOc8b3hTw3peja7qWhzwS3mmL4l0KJop2UmQOJ+GypBXLcjHIyOM5ouB4RRXoLaHpus6V4ll0a3eyWLUbK3hi1C6t2ALi43EztHGEXKDgFR/e3YBGt4H0tNH8P+M2u7vw1a39nPYxpfahbRanboH84sqFIp1JbC8qP4cEjFFwPKKK9qsNN0D+w7/UtYsk1Q3Gg3F2H05ILJFZdU8rdF/o+VyMYLLlVLLgAgLyum+CdN1HUPBsQkvEh12xubuYeYpaMxzXKKFO3ptgTOR1J6ZABcZ5/RXX+M9G0Lw/b6Ta2K6jJqdzYWd9cTTzJ5KedAsjRqgTJ5YEMW4HGD96uQoEFFFFMAqSHnzQeQYnyPXCkj9QD+FR1LB1k/65Sf8AoBoQGVRRRWZodZ8Yf+Sjaz/2x/8ARKUU74wOw+IusgMQP3Pf/pilFRLdno5t/v8AX/xy/wDSmL8I/wDkpWkfWf8A9EyVyFdf8I/+SlaR9Z//AETJXIVcdhVf9wpf45/+k0wooooPPJYvun61chb7PbTXB648tPXce+e2BVFZNoxitK6tlmit40urYLEpzuk53Hr+FZtO9zTmVrGRRV7+zf8Ap7tP+/n/ANaj+zf+nu0/7+f/AFqnlZNyjRV7+zf+nu0/7+f/AFq1LTwRreoW6XNpZS3Fu+dssMTurYODghcHkEUcrLhTlUdoK78jna7D4X/EXVvhX410zxLpM0wa2kUXNvHJsF5blgZIGJBGGA6kHaQGHKgiv/wrvxH/ANAq7/8AAeT/AOJrG/stv+fm1/7+f/Wo5WOdKdO3PFr1Vj0P4+fGS9+NHjq41bddw6DbfudLsLh1P2eLADMQvAdyu5vvEcLuYIteW1f/ALLb/n5tf+/n/wBataHwDr9xDHNDp1xJFIodHSGQqynkEELyKOV9ghTnUdoJv0OaorpZvAWv20Mk02nXEcMal3d4ZAqqBkkkrwAKyP7N/wCnu0/7+f8A1qOVhOnOnpNNepRoq9/Zv/T3af8Afz/61H9m/wDT3af9/P8A61HKzO5IrfaLBG/jtztbPUqenP6Yqq/3DV+ytVt5WL3VsY3Qo22TnB9Kz5G2s6cHBIypyDVJMrmVrEVFFFaGYVp/8utp/wBcz/6G1ZlX7aUTxJAf9amQn+0Dzt+ucn3z9AaiSy/o2sXvh/U7fUtOm8i+tyWil2qxQkEZAIIzzwex5HNWNH8TaroEV1Fp12YI7sxmVdisGKNuU/MDgg+nYkHgkHKZSpKsCCOCD2pKok6O/wDHWvaik0U13EkE1sbNoLe1hhiERkWQhURQqkuikkAE45NK3j7xAbS3tVvliSCSKUSQ28UcrtGcxl5FUPJtPI3E4rm6KQHTJ4/12K/vL1JbJXvVUXEI062+zzbeVZofL8ssCSd23PJ55qnceLdYuvI828LfZ7xr+P8Adp8szBAWHHTESDb0G3gdaxaKANWz8Sanp+vf27bXPl6t5rzi48tSRI2csARgHkkccHkYwKfofinVvDfm/wBmXfkCWSGVwY0cF4pBJG2GBwQwz9CQeCQceigDRsNe1DTNVfVLW48u/cSgy7FOfMVlfgjHKuw6cZ4qKx1W702K+itZvLjv4Ps1wNoO+Per7eRx8yKcjB4+tU6KANi98VavqMusy3N35j61IJb0+Wg85g+8HgfL83Py4rSPxG8RNfSXr3No9xNB9nnZ9Pt2Fym4N+9Ux4lbKqdzhmyBzXK0UAb+seNtd1+O7j1G+89Ls25lHlIu7yEZIvuqMbVdhx1zznAqnofiDUfDd491ptwIZZI2hkDRrIksZ6o6OCrKcDhgRwKzKKAN7XfGeteJbS3tNTuo5ra1cvBElvFGsGQAVQIo2IcA7FwuecZ5rOu9WvL6y0+yuJt9tp6PHbptA8tWcuwyBk5Ziec9apUUAdLbeP8AxBaSySJeRP5ltBaMk1rDLGY4ECRfI6FdyKAA2N3U5yTUdx468Q3V5e3kupSNd3t1BezTBFDNNDu8t8gcEbm6YznnNc9RQBt6n4t1XVo7+O4ktliv5IpbiO3tIYFkeMOEbEaKAf3j5I655zxVG31e8tdMvdMim22V68ck8e0He0e7Yc4yMb26HnPNUqKAN/TvGut6ULRbe6iMdpbPZxxTW0UsZheQyMjI6lXBdi3zA849BVrS/iN4k0a1S2sb6KKOMyeUfskLPEJM71RihZEbJyqkLyeK5aigC5qWq3erzQzXs3myQwRWyHaFxHGgRF4A6KoGepxzmqdFFMAooooAKlg6yf8AXKT/ANANRU6Z/siOrAid1KhT1QHqT9RkY98+mQZm0UUVmWdZ8Yf+Sjaz/wBsf/RKUUfGH/ko2s/9sf8A0SlFRLdno5t/v9f/ABy/9KZJ8Iwv/CyNI5Ocz9v+mL1x9df8I/8AkpWkfWf/ANEyVyFWthVf9wpf45/+k0wooooPPCiiigAooooAKntLy50+4S5tLiW3uEztlhcoy5GDgjkcEioKKBpuLutzr7T4o+LrK3SCLWpWRM4M0aStyc8syknr3NdD/wAL38R/8+Wlf9+pP/jleX0U7s9GlnOPpK0K0rerf5nqH/C9/Ef/AD5aV/36k/8AjlYl58WvF159oX+1PJim3DZDCi7AeytjcMdjnPvmuKooux1M6zCorSrS++35Fq/1O91WZZr+8uLuZV2B55WkYLknGSemSfzqrRRSPNlJyfNJ3YUUUUCCiiigAooooAKKKKALC310ihVuZgoGAA5wBS/2hd/8/U//AH8NVqKd2KxZ/tC7/wCfqf8A7+Gj+0Lv/n6n/wC/hqtRRdhYs/2hd/8AP1P/AN/DR/aF3/z9T/8Afw1WoouwsWf7Qu/+fqf/AL+Gj+0Lv/n6n/7+Gq1FF2Fiz/aF3/z9T/8Afw0f2hd/8/U//fw1WoouwsWf7Qu/+fqf/v4aP7Qu/wDn6n/7+Gq1FF2Fiz/aF3/z9T/9/DR/aF3/AM/U/wD38NVqKLsLFn+0Lv8A5+p/+/ho/tC7/wCfqf8A7+Gq1FF2Fiz/AGhd/wDP1P8A9/DR/aF3/wA/U/8A38NVqKLsLFn+0Lv/AJ+p/wDv4aP7Qu/+fqf/AL+Gq1FF2Fiz/aF3/wA/U/8A38NH9oXf/P1P/wB/DVaii7CxZ/tC7/5+p/8Av4aP7Qu/+fqf/v4arUUXYWLP9oXf/P1P/wB/DR/aF3/z9T/9/DVaii7CxZ/tC7/5+p/+/hqtRRRcAooopDOu+MAX/hYus5Jz+57f9MUopvxh/wCSjaz/ANsf/RKUVEt2ejm3+/1/8cv/AEpmT4L1xfDnjHTNSkKLDDPtlZ1LBY2yrnA5yFYke4HB6UvinRW8O+ItS0whwttMVj3sGYxnlCSOMlSp/HoK56T/AFj/AFNdtp2v6Rr+kWGi+IS9lPYqyW2sorTMseciKSPqy8sFIPy/KAMbiai+gqDjWoPDSaTTvFvRXdk03sr2TTdkra73XJ0V2o+FuvXXz6S2naxbjhriwvI2jVu6EsVOcYPToRR/wqTxj/0B/wDyZh/+LqrMX9k47pRk/SLa+9KxxVFdr/wqTxj/ANAf/wAmYf8A4uj/AIVJ4x/6A/8A5Mw//F0WYf2Tj/8AnxP/AMBl/kcVRXa/8Kk8Y/8AQH/8mYf/AIuj/hUnjH/oD/8AkzD/APF0WYf2Tj/+fE//AAGX+RxVFdr/AMKk8Y/9Af8A8mYf/i6P+FSeMf8AoD/+TMP/AMXRZh/ZOP8A+fE//AZf5HFUV2v/AAqTxj/0B/8AyZh/+Lo/4VJ4x/6A/wD5Mw//ABdFmH9k4/8A58T/APAZf5HFUV2v/CpPGP8A0B//ACZh/wDi6P8AhUnjH/oD/wDkzD/8XRZh/ZOP/wCfE/8AwGX+RxVFdr/wqTxj/wBAf/yZh/8Ai6P+FSeMf+gP/wCTMP8A8XRZh/ZOP/58T/8AAZf5HFUV2v8AwqTxj/0B/wDyZh/+Lo/4VJ4x/wCgP/5Mw/8AxdFmH9k4/wD58T/8Bl/kcVRXa/8ACpPGP/QH/wDJmH/4uj/hUnjH/oD/APkzD/8AF0WYf2Tj/wDnxP8A8Bl/kcVRXa/8Kk8Y/wDQH/8AJmH/AOLo/wCFSeMf+gP/AOTMP/xdFmH9k4//AJ8T/wDAZf5HFUV2v/CpPGP/AEB//JmH/wCLo/4VJ4x/6A//AJMw/wDxdFmH9k4//nxP/wABl/kcVRXa/wDCpPGP/QH/APJmH/4uj/hUnjH/AKA//kzD/wDF0WYf2Tj/APnxP/wGX+RxVFdr/wAKk8Y/9Af/AMmYf/i6P+FSeMf+gP8A+TMP/wAXRZh/ZOP/AOfE/wDwGX+RxVFdr/wqTxj/ANAf/wAmYf8A4uj/AIVJ4x/6A/8A5Mw//F0WYf2Tj/8AnxP/AMBl/kcVRXa/8Kk8Y/8AQH/8mYf/AIuj/hUnjH/oD/8AkzD/APF0WYf2Tj/+fE//AAGX+RxVFdr/AMKk8Y/9Af8A8mYf/i6P+FSeMf8AoD/+TMP/AMXRZh/ZOP8A+fE//AZf5HFUV2v/AAqTxj/0B/8AyZh/+Lo/4VJ4x/6A/wD5Mw//ABdFmH9k4/8A58T/APAZf5HFUV2v/CpPGP8A0B//ACZh/wDi6P8AhUnjH/oD/wDkzD/8XRZh/ZOP/wCfE/8AwGX+RxVFdr/wqTxj/wBAf/yZh/8Ai6P+FSeMf+gP/wCTMP8A8XRZh/ZOP/58T/8AAZf5HFUV2v8AwqTxj/0B/wDyZh/+Lo/4VJ4x/wCgP/5Mw/8AxdFmH9k4/wD58T/8Bl/kcVRXa/8ACpPGP/QH/wDJmH/4uj/hUnjH/oD/APkzD/8AF0WYf2Tj/wDnxP8A8Bl/kcVRXa/8Kk8Y/wDQH/8AJmH/AOLo/wCFSeMf+gP/AOTMP/xdFmH9k4//AJ8T/wDAZf5HFUV2v/CpPGP/AEB//JmH/wCLo/4VJ4x/6A//AJMw/wDxdFmH9k4//nxP/wABl/kcVRXa/wDCpPGP/QH/APJmH/4uj/hUnjH/AKA//kzD/wDF0WYf2Tj/APnxP/wGX+RxVFdr/wAKk8Y/9Af/AMmYf/i6P+FSeMf+gP8A+TMP/wAXRZh/ZOP/AOfE/wDwGX+RxVa/hbRW8ReItN0wBytzMFk2MFYRjlyCeMhQx/Doa3j8Ldetfn1ZtO0e3PC3F/eRrGzdkBUsc4yenQGq2o6/pGgaRf6L4eL3s98qpc6y6tCzR5yYo4+qrwoYk/N8wIxtINtzSngJ0JKpjI8kVrZ6N+SW+u17WXXonj+ONcXxH4t1bUoyjQzTFYmRSoaNQFQ4POSqgn3J4HSiuforJ6nFWqyrVJVZ7ybb9XqSSSOHYBm6nvTfMf8Avt+dFFBkHmP/AH2/OnCR9jHc3Ud/rRRQA3zH/vt+dHmP/fb86KKADzH/AL7fnTpJHDsAzdT3oooAb5j/AN9vzo8x/wC+350UUAOEj7GO5uo7/Wm+Y/8Afb86KKADzH/vt+dHmP8A32/OiigB0kjh2AZup703zH/vt+dFFAB5j/32/OnCR9jHc3Ud/rRRQA3zH/vt+dHmP/fb86KKADzH/vt+dOkkcOwDN1PeiigBvmP/AH2/OjzH/vt+dFFADhI+xjubqO/1pvmP/fb86KKADzH/AL7fnR5j/wB9vzoooAdJI4dgGbqe9N8x/wC+350UUAHmP/fb86cJH2MdzdR3+tFFADfMf++350eY/wDfb86KKADzH/vt+dOkkcOwDN1PeiigBvmP/fb86PMf++350UUAOEj7GO5uo7/Wm+Y/99vzoooAPMf++350eY/99vzoooAdJI4dgGbqe9N8x/77fnRRQAeY/wDfb86cJH2MdzdR3+tFFADfMf8Avt+dHmP/AH2/OiigA8x/77fnTpJHDsAzdT3oooAb5j/32/OjzH/vt+dFFADhI+xjubqO/wBab5j/AN9vzoooAPMf++350UUUAf/Z",
	"suka": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4lkkcOwDN1Pem+Y/99vzok/1j/U16DLLF8Oobe1tbdB4vC77q8f8AeLaBsERxgjaW24y2DjcwBOeOiUmnZbm2GwyqqVSpLlhG13a++yS6yetldbNtpIyLD4deLtRhaWHSLpVVtuJ2WFs4H8LkHHPXpVwfCvxltP8AxKmzkf8AL1F/8XXOX2o3mpyrNe3c91Kq7Q88hdgOuMk9OT+dVqOSp3X3f8E29rly09lN+fPFfh7N2+9nVf8ACqvGf/QKb/wKi/8Ai6P+FVeM/wDoFN/4FRf/ABdcrRRyVP5l93/BH7bLv+fM/wDwZH/5UdV/wqrxn/0Cm/8AAqL/AOLpz/CvxkWbGlNjPH+lRf8AxdcnRRyVP5l93/BF7bLv+fM//Bkf/lR1X/CqvGf/AECm/wDAqL/4uj/hVXjP/oFN/wCBUX/xdcrRRyVP5l93/BH7bLv+fM//AAZH/wCVHWD4V+Mtp/4lTZyP+XqL/wCLpv8Awqrxn/0Cm/8AAqL/AOLrlaKOSp/Mvu/4IvbZd/z5n/4Mj/8AKjqv+FVeM/8AoFN/4FRf/F0f8Kq8Z/8AQKb/AMCov/i65WijkqfzL7v+CP22Xf8APmf/AIMj/wDKjrH+FfjIs2NKbGeP9Ki/+Lpv/CqvGf8A0Cm/8Cov/i65WijkqfzL7v8Agi9tl3/Pmf8A4Mj/APKjqv8AhVXjP/oFN/4FRf8AxdOHwr8ZbT/xKmzkf8vUX/xdcnRRyVP5l93/AAQ9tl3/AD5n/wCDI/8Ayo6r/hVXjP8A6BTf+BUX/wAXR/wqrxn/ANApv/AqL/4uuVoo5Kn8y+7/AII/bZd/z5n/AODI/wDyo6r/AIVV4z/6BTf+BUX/AMXTn+FfjIs2NKbGeP8ASov/AIuuToo5Kn8y+7/gi9tl3/Pmf/gyP/yo6r/hVXjP/oFN/wCBUX/xdH/CqvGf/QKb/wACov8A4uuVoo5Kn8y+7/gj9tl3/Pmf/gyP/wAqOsHwr8ZbT/xKmzkf8vUX/wAXTf8AhVXjP/oFN/4FRf8AxdcrRRyVP5l93/BF7bLv+fM//Bkf/lR1X/CqvGf/AECm/wDAqL/4uj/hVXjP/oFN/wCBUX/xdcrRRyVP5l93/BH7bLv+fM//AAZH/wCVHWP8K/GRZsaU2M8f6VF/8XTf+FVeM/8AoFN/4FRf/F1ytFHJU/mX3f8ABF7bLv8AnzP/AMGR/wDlR1X/AAqrxn/0Cm/8Cov/AIunD4V+Mtp/4lTZyP8Al6i/+Lrk6KOSp/Mvu/4Ie2y7/nzP/wAGR/8AlR1X/CqvGf8A0Cm/8Cov/i6P+FVeM/8AoFN/4FRf/F1ytFHJU/mX3f8ABH7bLv8AnzP/AMGR/wDlR1X/AAqrxn/0Cm/8Cov/AIunP8K/GRZsaU2M8f6VF/8AF1ydFHJU/mX3f8EXtsu/58z/APBkf/lR1X/CqvGf/QKb/wACov8A4uj/AIVV4z/6BTf+BUX/AMXXK0UclT+Zfd/wR+2y7/nzP/wZH/5UdYPhX4y2n/iVNnI/5eov/i6b/wAKq8Z/9Apv/AqL/wCLrlaKOSp/Mvu/4IvbZd/z5n/4Mj/8qOq/4VV4z/6BTf8AgVF/8XR/wqrxn/0Cm/8AAqL/AOLrlaKOSp/Mvu/4I/bZd/z5n/4Mj/8AKjrH+FfjIs2NKbGeP9Ki/wDi6b/wqrxn/wBApv8AwKi/+LrlaKOSp/Mvu/4IvbZd/wA+Z/8AgyP/AMqOq/4VV4z/AOgU3/gVF/8AF04fCvxltP8AxKmzkf8AL1F/8XXJ0UclT+Zfd/wQ9tl3/Pmf/gyP/wAqOq/4VV4z/wCgU3/gVF/8XR/wqrxn/wBApv8AwKi/+LrlaKOSp/Mvu/4I/bZd/wA+Z/8AgyP/AMqOq/4VV4z/AOgU3/gVF/8AF05/hX4yLNjSmxnj/Sov/i65OijkqfzL7v8Agi9tl3/Pmf8A4Mj/APKjqv8AhVXjP/oFN/4FRf8AxdH/AAqrxn/0Cm/8Cov/AIuuVoo5Kn8y+7/gj9tl3/Pmf/gyP/yo6K++HXi3TrcSzaPcsGcKBAyzN0PZCSBx16VyfmP/AH2/OtOx1G80yVprK7ntZWXaXgkKMR1xkHpwPyrropYviLDcWt1bofF5Xfa3ifu1uwuSY5ABtDbc4bAztUEjHKbnDWWqHGhhcU+TDc0Z9IyalzeSaS959Fy67Xva/n3mP/fb86KbRVnmHWfDqwj1Hx7pEMrOqrOZgUIB3RqXH4ZUZ9qyNRvpNT1C7vZlVZbqV5nCDCgsSTjPbmuj+FYX/hYelcnOZu3/AEyeuTqYfxH6L9T0aumXUrdZzv8AKNO35v7z274T6/4c07w88Mlza2WpCQm5a4kWMzcnYQWPIC8YHQ545ye9/wCEt8P/APQd0v8A8C4/8a+VKKwqYGM5OV9z6PAca18HhoYaNGLUVbqv6ffu9T6r/wCEt8P/APQd0v8A8C4/8aP+Et8P/wDQd0v/AMC4/wDGvlSio/s6P8x1/wDEQMT/AM+Y/ez6r/4S3w//ANB3S/8AwLj/AMaP+Et8P/8AQd0v/wAC4/8AGvlSij+zo/zB/wARAxP/AD5j97Pqv/hLfD//AEHdL/8AAuP/ABo/4S3w/wD9B3S//AuP/GvlSij+zo/zB/xEDE/8+Y/ez6r/AOEt8P8A/Qd0v/wLj/xo/wCEt8P/APQd0v8A8C4/8a+VKKP7Oj/MH/EQMT/z5j97Pqv/AIS3w/8A9B3S/wDwLj/xo/4S3w//ANB3S/8AwLj/AMa+VKKP7Oj/ADB/xEDE/wDPmP3s+q/+Et8P/wDQd0v/AMC4/wDGj/hLfD//AEHdL/8AAuP/ABr5Uoo/s6P8wf8AEQMT/wA+Y/ez6r/4S3w//wBB3S//AALj/wAaP+Et8P8A/Qd0v/wLj/xr5Uoo/s6P8wf8RAxP/PmP3s+q/wDhLfD/AP0HdL/8C4/8aP8AhLfD/wD0HdL/APAuP/GvlSij+zo/zB/xEDE/8+Y/ez6r/wCEt8P/APQd0v8A8C4/8aP+Et8P/wDQd0v/AMC4/wDGvlSij+zo/wAwf8RAxP8Az5j97Pqv/hLfD/8A0HdL/wDAuP8Axo/4S3w//wBB3S//AALj/wAa+VKKP7Oj/MH/ABEDE/8APmP3s+q/+Et8P/8AQd0v/wAC4/8AGj/hLfD/AP0HdL/8C4/8a+VKKP7Oj/MH/EQMT/z5j97Pqv8A4S3w/wD9B3S//AuP/Gj/AIS3w/8A9B3S/wDwLj/xr5Uoo/s6P8wf8RAxP/PmP3s+q/8AhLfD/wD0HdL/APAuP/Gj/hLfD/8A0HdL/wDAuP8Axr5Uoo/s6P8AMH/EQMT/AM+Y/ez6r/4S3w//ANB3S/8AwLj/AMaP+Et8P/8AQd0v/wAC4/8AGvlSij+zo/zB/wARAxP/AD5j97Pqv/hLfD//AEHdL/8AAuP/ABo/4S3w/wD9B3S//AuP/GvlSij+zo/zB/xEDE/8+Y/ez6r/AOEt8P8A/Qd0v/wLj/xo/wCEt8P/APQd0v8A8C4/8a+VKKP7Oj/MH/EQMT/z5j97Pqv/AIS3w/8A9B3S/wDwLj/xo/4S3w//ANB3S/8AwLj/AMa+VKKP7Oj/ADB/xEDE/wDPmP3s+q/+Et8P/wDQd0v/AMC4/wDGj/hLfD//AEHdL/8AAuP/ABr5Uoo/s6P8wf8AEQMT/wA+Y/ez6r/4S3w//wBB3S//AALj/wAaP+Et8P8A/Qd0v/wLj/xr5Uoo/s6P8wf8RAxP/PmP3s+q/wDhLfD/AP0HdL/8C4/8aP8AhLfD/wD0HdL/APAuP/GvlSij+zo/zB/xEDE/8+Y/ez6r/wCEt8P/APQd0v8A8C4/8aP+Et8P/wDQd0v/AMC4/wDGvlSij+zo/wAwf8RAxP8Az5j97Pqv/hLfD/8A0HdL/wDAuP8Axo/4S3w//wBB3S//AALj/wAa+VKKP7Oj/MH/ABEDE/8APmP3s+q/+Et8P/8AQd0v/wAC4/8AGj/hLfD/AP0HdL/8C4/8a+VKKP7Oj/MH/EQMT/z5j97Pqv8A4S3w/wD9B3S//AuP/Gj/AIS3w/8A9B3S/wDwLj/xr5Uoo/s6P8wf8RAxP/PmP3s+hPiD4k8MXfhW9hmvbO+ldSLeO3lWR1mwdrfKflA7n0yOc4PgmnX0mmahaXsKq0trKkyBxlSVIIzjtxVaiuqjQVKLje58znGd1c0xEcRKKi4qyt631ZvfEqwj07xzrUMTOytMJiXIJ3SKHP4ZY49qKufFgL/wn+r5Jz+57f8ATFKKmlrTj6I583ioY+vGOynL/wBKYfCr/komlfWb/wBFPXK11Xwq/wCSiaV9Zv8A0U9crVQ/iS9F+oVf+RdR/wAdT/0mkFFFFbHmhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRWxpelwPbfb7/zTZl2ijjhYK8rgAt8xBChQykkg5yAB1Kjdi6dNzdl832/r/gLUx6K6r7Vpv8A0L+nf9/bn/47R9q03/oX9O/7+3P/AMdo97t+Rr7Gn/z9j/5N/wDInK0V1X2rTf8AoX9O/wC/tz/8do+1ab/0L+nf9/bn/wCO0e92/IPY0/8An7H/AMm/+ROVorqvtWm/9C/p3/f25/8AjtH2rTf+hf07/v7c/wDx2j3u35B7Gn/z9j/5N/8AInK0V1X2rTf+hf07/v7c/wDx2j7Vpv8A0L+nf9/bn/47R73b8g9jT/5+x/8AJv8A5E5Wiuq+1ab/ANC/p3/f25/+O0fatN/6F/Tv+/tz/wDHaPe7fkHsaf8Az9j/AOTf/InK0V1X2rTf+hf07/v7c/8Ax2j7Vpv/AEL+nf8Af25/+O0e92/IPY0/+fsf/Jv/AJE5Wiuq+1ab/wBC/p3/AH9uf/jtH2rTf+hf07/v7c//AB2j3u35B7Gn/wA/Y/8Ak3/yJytFdQdPstbdLezs1stQkISFYpGaGVuyEOWZWJOA27b0BAyWHL0J9GZ1KXIk000+qv8AqkworZ0rSoHtf7Q1DzTZGRoY4oHCyTOAC3zEEKFDKSSDnIAHUrp/bNM/6FzTf+/tz/8AHqiVRRdjgni1GVoxcvS36tf15nJ0V1n2zTP+hc03/v7c/wDx6j7Zpn/Quab/AN/bn/49U+2iR9c/6dy/8l/+SOTorrPtmmf9C5pv/f25/wDj1H2zTP8AoXNN/wC/tz/8eo9tEPrn/TuX/kv/AMkcnRXWfbNM/wChc03/AL+3P/x6j7Zpn/Quab/39uf/AI9R7aIfXP8Ap3L/AMl/+SOTorrPtmmf9C5pv/f25/8Aj1H2zTP+hc03/v7c/wDx6j20Q+uf9O5f+S//ACRydFdZ9s0z/oXNN/7+3P8A8eqlqOl2t1az32nRvD9nAe5tnfcFUsFDoxGdu5gu05YZBy2WKuNWLdioYtNpSi1fvb9GzAooorQ7DqPiz/yUDV/+2P8A6JSij4s/8lA1f/tj/wCiUormo/w4+iPTzn/kY4j/ABz/APSmO+FX/JRNK+s3/op65Wus+FbsfiHpQ3HGZuM/9Mnrk6uH8SXov1FV/wCRdR/x1P8A0mkFFFFbHmhRRRQAUU+GGS4ljhhjaSWRgqIgyzE8AADqa9Ih+Hmm+GLWHUPGF/s38x6fa/M8hADbS35qcYAyPnGaidSMN92d2Cy6vjOaVNJRjvJu0V6t/wDDnAaZpN9rV2trp9rLcztj5Y1zgZAyT0AyRyeBmu4tPhDqiQJdaxf2OlWgz5rSybmi5wM9F5OP4u/rxT7v4lT2US2Phexg0iwRsgrGryyY4y2QRkgLnqcj7xrkbqe/1SVZr66muJAoUPPIXYL1xk/U8e9RatPb3V97/wAju/4SsIrS5q8vXkh/8k//ACX9Tsx4W+H9h/o994nup7pPvyWqfuznkYwjjoR/Eec9OlL/AGp8M/8AoXtT/wC/jf8Ax6uIFmuOWJPtTxbR4+7+tV9Wb+KT++35E/23GGlLDU0vOPM/vk396tfqdp/anwz/AOhe1P8A7+N/8epDoXw61Hm31y/sp7j/AFccqkpAzdAxKdFJwfn7fe71xn2aL+7+pphtFxwzA+9H1ZraT+//ADD+3FLSphqTX+Dl/GLR2M3wiurqKSfQ9Z07VLeNTkq+1i452DG5c4x1Yde3WuK1nw/qfh64EGp2Uts7fdLDKvwCdrDhsZGcHjNSwfa7Cdbi0nkimTO2SJyjrkYOCOnBIrq9N+JuqQRGz1mCDWNPKqrQXaDdhenzY5OcElgx47Hmpca0P7y+5/5Fc+U4pWcZUZd0+ePzT95fJv0Z57RXpw8E+HvGiyS+FL5rO8Rdz6fe5wBkLkNyQOCTgvywHy151qGn3WlXs1lewtDdQtteNuoP9R3BHBHNVCrGbst+xx4zLK+EiqkrShLaUXeL+fR+Ts/IrUUUVoeeFFFFABXVXX/IH8P/APXm/wD6UzVytdVcEPougsp3KttJExHIDieVip98Opx6MD3FH2l/XQ6KP8Or/h/9uiQ6fa/br+1td+zz5Vj3Yzt3EDOPxrp5vBEb6lf6XY6i0+pWal/Jlg8sSgAE7WDHnnviub0u6Sy1OyuZAxjgmSRgvUgMCcflXXv4w0u017Udcso7yW+uVKxRzRqiREgDJIYluntUVXUUvc7fiehllPAypXxVr8yvq01Gzu0k9Xe1tH9xiQ+HYodHt9U1K8a1gunKQJHD5jvjqxG4AD8fwrRt/AUsmtNYS3qrA1obyK4jj3iROMcEjB59aq/27Y6loFjpepi5jexdjFPbor7lY5KlSR+efwrXtfHdmuuC4lt7iPT4bA2MCIA7gcYY5IHb+VROVbW3n/wLHZhqWUtw9q1b3Oru3b3+bXRJ7Wt0s3qYE/hxX0ZtW066N1axSCKVHi8uSMnGMjJBByOh71fbwZFBqVvpNzqaxatOoIiEJaNGI4VnznJ9lNQN4gtNO0CbSdLW4drmVZZri4VUPykEKqgnHIHer83irSb3XbXXrmC7W+hCs9vGFMbuo4O8nIHA4wabdX5a+vl+pFOllnu81ub3OZXlyrWXPZ3u2ly9Xu7XKFr4OnNlf3d480aWdwbZ0t4POfeOpxkALyOc03TPDVpqUesTrqMgtNNjWQuttlpAQcjaWGCMY61Y0/xW0V7eX7ahqFld3M7SultGkkTKegKsw5HIzzxitNPHdk+oeILnZd2f9pRokUlsoZ4yoI3H5l557GplKsr/ANdvL1NKNHKZcjbt8V7t3ekrO6kra8t00tetrmTP4JuTqelWdpcLMNShE8TuuwouMncuTjA9zUY8LQXkWpf2ZqP2qfT1LyxvD5e9R1ZDuOce+K0pfHUUOq6Le28M1xJYRGKae4wslyCMc4JxjnHJ61UtvEGl6MmrSaZHdvc6hG0K+eqqsCMeeQTuP5U1Ktb+u/X5ClSynnfK1y3d9XdLkVuXXV8109+nTUjh8N6ZPodxrC6neC2t5RCymyXeScdB5uMc+tc4sJnuRDb7pC77I8rhmycDjJwfxrbtdct4PCF9o7JKbm4uFmVgBsAGOpznPHpUHhbUbLSNat76+jlljt8uiRgEl8fLnJHAPP4VrFzSk3r2POrQwlWdCFO0FJLnd3o7u+7eys9DQ8V+DH8MwW0y3i3ccjmKQqm3y3AB29Tnv+VUPE+gf8I3qS2f2j7RuiWXfs2de2MmtWXxhBqWjatY39kscl1J9pie23NibPJbe5wDwOPfiqHjHXbfxDqyXdqkqRrCkeJQAcjPoTUUnVulPzv+FjqzCnlvs6lXC2TfLyq7uviUlrvtF699Dn6j8W/8jXrv/X9P/wCjGqeKJ55UiiRnkdgqooyWJ6ADuaq+KJo7jxLrM0MiyRSXkzI6HKsC5III6itJ/Evn+h5NP/dp/wCKP5SNe8/5A3hz/ryf/wBKZ6pQwyXM0cMKNJLIwREUZLEnAAq5ckPofh91O5EtZImYcgOLiVip99rocejA9xT/AA/qn9h67pupGPzBZ3CTFP7wVgcVxz+JngJtRm4q7vL82d9cfAbxRBpJvA1nJcKu82aSEyfQHG0n2z+Nec6dp9xqmoW1hbJuubmRYo1PGWJwPpX1RcfGTwjDpRvk1ISvsytqqMJS393GOPr096+YrHXp9P8AEcOtxInnxXP2kJ/Dndu2/TtUI8jKsXjq8an1iFmtrq2uuh1afDWC61u78P2euLPr9sjMYDbFYZHUZZFk3ZJHPVQOKhT4aXM3gL/hKILvfKhcyWJiwyojlWYNnnHBIwMA+1adv488P6b4rvfFlna6g2qTq7R2cqoIYpXGGYyBssOTxtHXrUOnfEuPTND8OW0cM8l3p91PLeK6r5U8Upbcg55yG7jrRqU54+0eT+7e6XZ8y9L2V/Pdir8KN3iZtF/tf7umf2j532b6fJt3+/XP4Vzngnwl/wAJjqd1ZfbPsvkWslzv8vfu24+XGR1z1run+KOhHx1PrKWuoJpz6UdPVPLQyK2euN+MY981zvg3xJoHg3WLi8jn1O8iuLKa3YNZxxMrMV2kfvWyODnpjjr2Bwq432UuZPm5VbRb636W7b/Iii+G9xdeAF8VW16JXBdnsvKwyxo5VnDbuccE8dDWjF8KFfxSdEbWCqjTRqJnFrk44+Tbv9+ufwqLSfiPBo3h7wzY28E73GmXMz3SOq+VPDITuQc5OQe461u/8LU0NfHkuuRW+oxWB0v7CirGnmo2Rg434wAPXNGpFSpmCc1Fae9bRd/dX3arvfXY8s1KLTIjH/Z13d3AOd5ubVYdvpjbI+e/pUuhf8fV1/14Xn/pNJVnxJqa6m9u41vVtVZAQW1KPaYxxgL+9fOec9Oneq2iEJNeysdsaWF3uc8Bd0DouT2yzKo9SwHU1Ud0enJt4d33s/62X5HIUUUV2nuHUfFn/koGr/8AbH/0SlFO+LDsPH+rgMQP3Pf/AKYpRXPR/hx9EennP/IxxH+Of/pTD4Vf8lE0r6zf+inrla6r4Vf8lE0r6zf+inrlaqH8SXov1FV/5F1H/HU/9JpBRRRWx5oVpaDoN94k1KKwsIt8z8ljwsa92Y9gP8AMkgVW0/T7rVb2GysoWmupm2pGvUn+g7kngDmvTtc1GP4c6PH4d0jausXMSyahfI+5lYj7qngg9cZAwpBHLZGVSo01CG7/AKuepl2BhVjLE4luNKG7W7fSMfN/gtWJc6po3w0ivdO0IteeIHURzX8qqUhP8SqPUEZ288kbiduK4K6nu9YvJr29meWeZtzyN1b/AAGOB2HQVDBbggO3TsKsvIsYyx/D1rSlRUPeer7mePzOpi7U4rlpx+GC2X+b7t6sEjWMYUf/AF6HkSP7zAVSkunfgfKPbrUFU6qWxwql3LxvIwcfMfcCmfbf+mf61UoqHVkV7OJb+2/9M/1p4vEOMhhVGij2kg9nE00lR/usCfSnMocYYAisqpY7h4+M5X0NWqvcl0uxY8uW1lSa3kdZI2DKyHDKR0II75rvLLxbpfjOyh0jxhuW4EuYNThCoY89Q3GFHAGcEEYJA27q4iKZZRkHnuKjntw2XXg9x60qlGNRX/E68DmNbBNxjrGXxResZeq/J7royz4t8JX3hHUja3Q3wvloLhRhZV/oRxkdvcEE4Fen+DNft/ENonhDxCvnWc3y2dwWAeBwDtUE/kv124IOBwWvaDfeG9SlsL+LZMnIYcrIvZlPcH/EHBBFZU5u/JPdfj5nVmGCpezWNwd/ZSdrPeEv5W+v919V5pmbRRRWp5AVp6Zqws42trqFrmxZt/lK+xkfH3kYg7ScAHgggDIyFIzKKGrlQnKDvE6b7R4f/wCf/VP/AAAj/wDj1H2jw/8A8/8Aqn/gBH/8ermaKXvd/wAv8jb21P8A59R/8m/+SOm+0eH/APn/ANU/8AI//j1H2jw//wA/+qf+AEf/AMermaKPe7/l/kHtqf8Az6j/AOTf/JHTfaPD/wDz/wCqf+AEf/x6j7R4f/5/9U/8AI//AI9XM0Ue93/L/IPbU/8An1H/AMm/+SOm+0eH/wDn/wBU/wDACP8A+PUfaPD/APz/AOqf+AEf/wAermaKPe7/AJf5B7an/wA+o/8Ak3/yR032jw//AM/+qf8AgBH/APHqPtHh/wD5/wDVP/ACP/49XM0Ue93/AC/yD21P/n1H/wAm/wDkjpvtHh//AJ/9U/8AACP/AOPUfaPD/wDz/wCqf+AEf/x6uZoo97v+X+Qe2p/8+o/+Tf8AyR032jw//wA/+qf+AEf/AMeo+0eH/wDn/wBU/wDACP8A+PVzNFHvd/y/yD21P/n1H/yb/wCSOim1mysFJ0r7TJdn7t3cKsZi/wBxAW+b0fdxk4UEBq52iimkZ1KrnZWsl0W39eb1NTS9XWzja2u4WubBm3+Usmx0fH3kYg7ScAHgggDIyFK6nn+Hf+ghqv8A4L4//j9cvRUSpxlqziqYWMpcybXpb9UzqPP8O/8AQQ1X/wAF8f8A8fo8/wAO/wDQQ1X/AMF8f/x+uXopeyiR9T/vv8P8jqPP8O/9BDVf/BfH/wDH6PP8O/8AQQ1X/wAF8f8A8frl6KPZRD6n/ff4f5HUef4d/wCghqv/AIL4/wD4/R5/h3/oIar/AOC+P/4/XL0UeyiH1P8Avv8AD/I6jz/Dv/QQ1X/wXx//AB+jz/Dv/QQ1X/wXx/8Ax+uXoo9lEPqf99/h/kdR5/h3/oIar/4L4/8A4/VDUtYhaB7PTY5YrV8edJKwMlxg8Zxwq5AbYCeerNhcY1FNU4p3KhhYxalJt272/RL8QoooqzqOo+LP/JQNX/7Y/wDolKKPiz/yUDV/+2P/AKJSiuaj/Dj6I9POf+RjiP8AHP8A9KZJ8Kwv/Cw9K5Oczdv+mT1yddV8Kv8AkomlfWb/ANFPXK1cP4kvRfqKr/yLqP8Ajqf+k0goorc8I+HpPFGv2mnKGETtundf4Ixyxzg4PYZ4yR61rKSim2cVCjOvVjRpq8pNJerO18LQWngXwp/wk13DE+uXuV0+GYkYTgbguMjglie67QCN3PBIJLqZ552aR3Yszucl2J5JJ610fj7XE17xAYLMqumWA+zWyR4CBV6soBIwSOCMZUL6ViqoRQo6Cpw8Hbnlu/6SPSzjEw5o4Oh/DpaK32n9qT9Xt5JCSOI0LH/9dZru0jFmPNT3j5cIDwOv1qtTqSu7HmU42VwooorM0CiiigAooooAKKKKAFVipBBwRWjDKJUzxu7is2prV9koGeG4rSnKzsZzjdE1zD/Go+tehEQfEfwfJvRT4p0eL5CrMZLmJcdRglieRjn58HIDYPDkZGD0q14Z1uTwr4htb5S5hU7ZUX+OI8MMZGT3GeMgGjEU3Jc0d1t/Xmd+UYyFCq6NfWlU92Xp0kvOL1Ry9Fdd8RfD0eha+0toFOl6gv2m1eP7mG5KqQAMA9AM4Ur61yNEJqcVJdTkxeFnhK86FTeLt/wfR7oKKK9X+DXwL1D4uRa7qT6vaaH4b0GHztQ1S7UusY2s2FUEbiFUk8gAfUVTdtznPKKK9l8U/B/wXZeC9a8R+FPitpviN9I8oy6e2nSWVw6vKke5VkYlgC4JIGPfmvGqE7gFFFex/GP4Ef8ACpfCvgjXf7f/ALT/AOEotzceR9j8n7NiON8bvMbf/rcZwOnvRdbAeOUUUUAFFFewfBr4CXXxX0nxDr93rtroPhnw/GZL2/mhadhhC7bY1IJwq5PI6jGew3bcDx+iu0+IPg/QPCs1hJ4c8aaf4p0+8DkS29vJbSwlccSRScrndwcnOD6VxdABRXrPwe+APiD4vQajqcF3Z6P4Z0vP2zV79isUZC7mCj+IhfmPIAHUjIzq6j8H/hv9mvRo3xt0i+1G2jdxb3Wkz2iSsoJ2rKxKknGB65pcy2Cx4jRRRTAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigDqviwF/4T/V8k5/c9v+mKUU34s/8lA1f/tj/wCiUorno/w4+iPTzn/kY4j/ABz/APSmO+FX/JRNK+s3/op65Wuq+FX/ACUTSvrN/wCinrlaqH8SXov1FV/5F1H/AB1P/SaQV6j8PGXw/wCCvEviNW/0of6LCyxqWibAwcnsWkQkf7HfpXl1eneLB/ZXw38I6X/rPtObzzfu7cgttx3/ANdjOf4enPCr+9yw7v8ADc6sjfsHWxv/AD6g2v8AFK0Y/nf5dNzhLRMlnI6cCrdRwLtiXpzzUldq2PAZBJBG8mWYhm7Un2OP1b86jvW+ZF7gZrqvhbqnh2w8feHrjxisr+HILtJLry4ll4HK70IO+PcF3gAkpuABOKxlKKbujWMZNKzPoX4I/sg6X448FweJPFuo6tZ/2l+8srWy2xOsIJAeQyRtnfwy7Rjbg5O7C+lf8MMfDv8A6DPin/wKt/8A4xX0do+rWev6RYatp03nafqEEdzby7Su+N1DK2GAIyCDggGrteJPEVHJu9j1o0IJJWufMn/DDHw7/wCgz4p/8Crf/wCMUf8ADDHw7/6DPin/AMCrf/4xX03RU+3qdyvYw7HzJ/wwx8O/+gz4p/8AAq3/APjFH/DDHw7/AOgz4p/8Crf/AOMV9N0Ue3qdw9jDseNfD39lz4deAf7Rzpv9v/bfL/5GCC3u/I2bv9X+6G3du59dq+ldhd/Cr4a2VpPcy+APDTRwRtIwh0KGVyAMnaixlmPHAUEnoATXbLgMM9Kk3J7flXTSrScdZL5nLWpRUtE/kfmV+0fqngDxJ440+7+HsNjDoqabHFKthYGzjM4llLEoUXJ2lPmx0wM8V4+ttGsi4Ztw5xX1D+078RvhH4w8I258CHS5PE0urLc3dxb6Q9tPJEY5d7NK0S7suyEgkknntmvli0b99zklga9OLjorHC1Kzdy9Ve7TKBscj+VWKa670ZeOR3rdmSO21Jl8R/CK3upG/wBK0SdYd7RrllyFCqR0G148nuU59a8tr0/4VD+0R4j0P/V/2jYn9/18vGU+73/1ueo6e/HmFcVH3ZTh53+89/N37fD4bFveUeV+sHa/zi4/8F3CvfP2efjrB8JNM8Q6X4h8Nza14M18iG6EYHyPsIZfm+V9yNgqSOgOeufA69I+Gvxt8Q/C/TdU0rTrLRtR0nVHWS6stWshcRSMowCRkHv61tJXR4aPoHxN8G/g98UPg/4m+IPwyTUtFuNCjllmtLl2KFo0EjRsrs2CVPBR8ZP4U34u5b9h/wCGBXkDUIM47fu7qvG/GH7Sni3xV4Qm8JWmneHvDfh25Obiy8P2H2VJuQSG+ZuCQM4xnGDkcU3wh+0l4t8I+Ax4K+waBrGhRsXt4tZsBcm2JYt8gLBThiWG4Ngmo5WO6Paf2noZIP2ZvgjFKhSRLS1DKwwQfsa8Gvot/h74c8beG/hVfa1BHqd/oGiG807RJJFRb6XyIOW3dQpC8HjLgngYP5//ABN/aC8V/FnwtoOgeIodNaHRiGjuoInWedgmwtIS5Uk9TtVRn0HFWvE37SfjXxIngcqbDS7nwYu3TrrTo5EkPyIh8ze7BsrGARgA5YEYOKXI7ILnpnhPXfjD8b/2ipp7XVF8NeItDiuMR3MAki0mDIjdFidSGc7wCSMknOQAMfRngFdO+K1l428JeKPiLYfEY2kPkzp/wjgsTp8h3ruSUDa5ypwV5BTINfHmoftW+M7vx5ZeN7TTPD2meIoLc2lxPZWsqi/gOD5c6tIwYAqMEbWGBzwMamkftk+ONC1bUr/TtC8I2keorma0ttNaGFpCctMdkgZ5D0LOze2MnI4tgmfO9fevww1Xw1+zT8C/CfiPUrC51aDx5dRLq0ofdFbxPHIQBHyDtXgr1b5ueAB8FV674E/aN8XeBvCr+FDa6Jr/AIZ3Fk03XrL7VDESdx2jcpxnnBJAPIHJq5q6Ej6Qvv2Yvhx4Rl8Z/ELVHtdW+GzaT9v0i3F5LGUmc5CK8bKWX7qpknPmAEEjJ+Eq+grn9sDxrqOiajoGpaD4SvvDt7AtuNKl050t4EHaMRyKw7HknBUFcV8/OQzMQoUE5CjOB7c0RTW435H274UVtX/YD1u10AF9RtXl+3JD9/5bxZJM4/6YFSf9muA/Zu+B3wz+Nuj3lrf3ni618T6XF516beW2SzZWkcR+XlHcnaFzuxznFeO/DH4x+L/hFf3F14Y1ERRXQAubOdBJb3AHTch7jPUYPJGcE16FD+114x0uO8/4R3w54L8OXN6MT3WkaMIpZTzyxZmDHk9QalxavYLo9x+B+i+G/h9+zHD46j1yz8N67qs7i48STaQdTkswLholjWIcgEIOvGXyQeK8/wD2ifHXwu8e/DTS3s/FVn4g+JOnzIsmp22hz6e19ESwYOrJtGAVP3uqnGAxFeP/AA0+Pvi74X6Te6Jp/wDZ2peHr0lptJ1e2+0WzMQATtyCM4GQDg9xVbx98aNX8faNFor6J4a0PR47hbr7JoWmJao0iqyqxPLHAdhjOOaFF3uF9D7D+NvxH1P4ceEPgXd6LBZDUbqGKP7VcWyTPHD5Vv5kabgdu/K5YYbC8EZNavxL8Vn4c/tKeA9D8NaVpVhH4skifWp0s4zLeh5DEFLkZUKFJ+XGSec18Y/ED48+I/iPpfg/T9VstJhh8KKEs2tIpFaQBY1/ebpGzxEvTb1P4XvGP7R3inxv8RvDPjrULDRotX8O+X9mht4ZVgfZIZBvUyFjyx6MOKSgwue4638NfEUn7ZOuWnwyvbLw3eW1ouoyXbW6SRWySQospWJlKsWaXpjqxPGK9n8Arp3xWsvG3hLxR8RbD4jG0h8mdP8AhHBYnT5DvXckoG1zlTgryCmQa+KJP2lPGw+K8/xJtP7OstduYFtZ4IIW+zSxKqjYyM7Ng7FP3s5GRiuo0j9snxxoWralf6doXhG0j1FczWltprQwtITlpjskDPIehZ2b2xk5HBsd0ek/s8+PfB9l8GY/D2k+ONI8BePheSSXeqajYRTfaYy7FRulwhXaVXrldp45yfLv2rPCfi3w94l0G98U3GgagNRs2+y6ro1qtuL1VbJaVVGC48xeRwVK89a5HwX8ddX8HaBa6FL4a8I+INNtGdrePXtIS5aHcxZtrgq33iTyTWV8U/jB4m+L+qWd74ilthHYxGG0tLOHyoLdDjIVck84HJJPAHYVSi1K4r6HBUUUVYgooooAKKKKACiiigAooooA6j4s/wDJQNX/AO2P/olKKPiz/wAlA1f/ALY/+iUormo/w4+iPTzn/kY4j/HP/wBKZJ8K3Y/EPShuOMzcZ/6ZPXJ11Xwq/wCSiaV9Zv8A0U9crVw/iS9F+oqv/Iuo/wCOp/6TSCvT/i+PseqaRpcPy2NnZL5MXXZlivU8nhFHJ7fWvMK9Q+NH/I02n/Xkn/oySif8WHz/AEOnBaZXi2u9NfK8n+i+5HGKNqgDoBiql63zKvoM1cqhdtmYj0GK6avwniU/iIKKKK5joP0+k8WXHwm/Zs0nW7qxlXUdH8PWUQtZ4iClyYo4kWRCVIAkZdwyCAGxzxXl/hL9n/Uvjh4a0vxf8UvGOvXV7qUC3NnY2jQxRWkbjhgMOn7yNYXwqoQc7snp9TXuo2unRh7qdIlPQHqfoOp61WtfEOmXkwihu0Mh6BgVz2wMgZPtXjqo0nyrXueusNOa5uVuK8tD5o0688V/s7fFbwd4Ou/EN/r/AMPvEshtLJbyNHmtJCyxRxI2/cBHm3yflQrI+2PcOPqqiipnPms7akRjy6BXzR8SfFHjP4kfGp/hT4Q1668OaZp9iLnVtStol88MVSRWVvMV9mXgTCFGzJJu3KK+l6KIS5XewSjzKx8xXn7Jo8DWk+t/DPxd4j0/xTaRtJCk0sLpeBRvW3YBYxh5FjzvLJxyp7ei/s6fE68+Kvw0tdV1PnWLKd7C9lWIRpNIgVg6gE9UdCeFG7dgAYr0i91zT9OkEdxdIkn90AsR9QM4696fY6tZalu+y3CSMvVeQ3bnB5xz1qpVHKNpa+Zaw04rnUWo+mh+Ol5Z3GnXdxZ3lvLb3dvI0U0EyFHjdThlZTyCCCCD0qGu0+MH/JWvHv8A2Hr/AP8ASh64uvXTurnkNWdie0bEwHqMVfrNgbbMh98VpV00noYVVqdF8LLmW18cWkUT4SdZYpBgHcoQtj25VTx6VyPiK1hsPEGrWtumyCC7ljjXJO1VcgDJ56Cup+Gn/I/ab9Zv/RT1zni3/ka9d/6/p/8A0Y1c/wDy/fovzZ7VTXJqbfSpJLyXLF/mY9FFbcHha9uPC1x4ijeA2dvcfZ5I9x80cL8+MY25dBnOcsOK3PDMSiuj1XwRq+lz6TbeT9ru9TthdRW9orSSKCSCrLj7wKnIGcVkx6PqM2oHTo7C6fUASptVhYy5HUbMZz+FAFKitCDQdVuryezg0y9lvIATLAkDtJGB13KBkfjV698MS2/iuPw/DOkk8k0UCSyKUXc+3GQMkAFvegDBorp08JW763pulR+INPuZry8js3FrFOWh3MFLESRoCAT0B/xrHTRdQnkjW2srqcTStDEY4WbzXXqq4HJAIOB60BcoUVqReGdbnuprWLR9QkuoGCSQpbOXRiCQCuMgkAnn0NR2eg6rqE0sNppl7cTQuI5EhgZ2RuflIA4Pytx/sn0oAz6Kuto+orpy6i1hdDT2baLowt5RPpvxjP41Z/4RrVIp4YbuxurMzxPNGbi2kHmKiFiQApJGB1AwOpIGSADJoorU0TQ5tbkutk9vbW9pF59xcXDERxJuVQTtBJyzKAACeaAMuitoeG5pW1P7PeWdxFp9r9reWJ2KyJvRPlyuc5kHDAdD+Mun+Eb3UotNkilt1XUBctFvZgR5Cbn3cdx0xn3xQFzAoroY/BuoPdaRZs9vHfaoyiO2diJIkbG2SQYwqkc8nOBnGME5ms6TPoeqXWnXJRprd9peM5Rx1DKe6kEEexoAo0UUUhhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAHVfFh2Hj/VwGIH7nv/ANMUopvxZ/5KBq//AGx/9EpRXPR/hx9EennP/IxxH+Of/pTHfCr/AJKJpX1m/wDRT1ytdZ8Kwv8AwsPSuTnM3b/pk9cnVQ/iS9F+oqv/ACLqP+Op/wCk0gr0/wCKJ+32nhbWpeLrULEeYi/cGAr8Dr1kbqT0FeYV6bOf7d+EVnP96fRboxSSTctsJwFQ8nGJIxjj7nsKKuk4S87fedOV/vcLi8P1cVJf9uNN/wDkrf4nHISUUnqQKz523TOT64q3atmLHdTVFm3MWPUnNb1Xojxqa1YlFFdP8N9Ws9A+InhHVtRm8nT9P1a0ubiXaW2RpMjM2FBJwATgAmuduyNlufpv4x0+7XUZLtkd7VlUK4yQmABg+nPP4/WuftbSe9mEVvE8sh7KOnbJ9Bz1r1qzvLfUbS3vLO4iuLS4jWWGeFw6SIwyrKw4IIIII61NXi81j6yjm0qdJQ5b2IbOOSG0t45n3ypGqu2c7mA5OTU1eafHTQNe13wOD4d1PWbG8sLuO6lXRpmiubiEBkkRWU5OA/mbQGLGIKBlgR8zw2OuXEMc0PxL8dSRSKHR011yrKeQQR1FHu2u2cuGwVbFuTpJaedj7jor4f8A7L8Qf9FH8ef+DuT/AAr3b9nXRNetNJ1nWNW8Qa9qun6nJCNOGsXbXBMSKxM8ZY8JI0mAMDIiDgsrrg91rRjxWX18LFSqpK/maOp6fd2F063aPvZifMOSJPUg9+v681d8Nafd3Op200COsUUgZ5eQoAxkZ9SDjHv6V6ZRRzHVLN5Sp8nLr/XQ/JX4wf8AJWvHv/Yev/8A0oeuLr1T9pHxFpfiv41+K9V0W9ivtNlkgjjuYTlJDHBHGxU/xDcjAMODjIJBBryuvZh8KPk5/ExVbawYdQc1q1k1oSSf6PuOMsv866KT3MKq2Ow+ENml54w86RmD2tvJMm3GCxwnPthz+OK4DUb6TU9Qu72ZVWW6leZwgwoLEk4z25r0XwSf7F8E+K9dPyu0YtIJIuJY3IxkHjA3SRng/wAPTgV5jWMPeqzl6L+vvPZx37rLsLR2cuab+bUV+EWFdt4e8WWWh+HrW2ngF9m9uGubFiUEsLxRqPnwQPmTI68qOK4mitzw7HpTeL7HV9OW3vNS+zX99ps0E92Y3KwytfPOVbaCdrIQCVBxuA9RUMviLS7m61Cx/tJo1n0iDTl1V4nw7xsjEsAC+xghTpnAXI6ivO6KLiselah4h0nVdPuNJTWjayRLZf8AEykilxd+QjqwIUFxguNuR0QZ28YzNT8Qafc/FKHW0u3k01dQgna4dGDFFKbmK4zng8VxFFFx2PRrjW7SPxVompTa3oNzZ2+qRXDjTtMa3ljjEgYs5FvGWAA6ZY57VFceJbG+1iy1O31CKxUwSWcljPBI0ECFCp27BkRuGJOPnDEnn7x8+oouFj1JTpFz4d8Sw2Ws/Y7R5NOjacidoPMCzkouQZPL4yMgnIHbmsnX/FVnfWfiiO1u5d1/PYKpZWVrlIYpFeRvTc21sE5y3sa4hbmZIJLdZZFglZXeMMQrMudpI6EjccemT61FRcVj0+98Y6VNpnn2p06G4k06KweJort7ldqKpwPMEG3cu4Hg/wCznJLZPEGiLqCahNqUMt/cC9ad7SOdYmMls6qXSQcSF2A+T5QDXmVFFwsauh3f2Q6j/wATD7F5tnLF/qfM8/OP3X+zu/vdsVP4WvnsL6V01aPTGkiKeZPAZoZASMpIoVsrxn7rcgcd6w6KBnoUutaB/al/bxTwQw6jpIsrm9t7Zo4PtHmLJ5ixAZCHy1U4UdyF7VLpHiXS/D2o+G4YdRS4j0mK9eS8SF/LMssbBVVWXcQCEGSo5J4wM15xRRcLHpNt4l8OG61HxPcm5Or3ltLDJpsTsrCeXCvNHMyuFUozkBgSCcDIwa5/xjqula3Ho93p6zw3EdqLS4t55PNceV8sbmQIqtlNo4HGznsTy1FFwsFFFFIYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB1HxZ/wCSgav/ANsf/RKUU74sBf8AhP8AV8k5/c9v+mKUVz0f4cfRHp5z/wAjHEf45/8ApTD4Vf8AJRNK+s3/AKKeuVrqvhV/yUTSvrN/6KeuVqofxJei/UVX/kXUf8dT/wBJpBXpXwl1KKeXVfDV3JKsGrQMIyrH5WCkNgYIBKknJ/uAc8V5rU1pdTWF3BdW77J4JFkjbAO1lOQcHjqKurD2kHEjLMa8DioYi10t13T0a+abL0sM2m3VzazrsnhZo3XIO11JBGRweRVOvQ/iDYrrljp/jGwhb7NfRKt2FyRDKvy8k9sjZkADKD+8K88qFU9pFP8Aq5eOwX1PESpJ3jvF94vWL+a/G6CipbeHznILbUVSzNjOAPan+XZ/8/v/AJCNByNpH1B+zJ+03Z+ANPTwd4xfyvDkXmSWOoRQl2tGYl2jkVAWdGYsQwBZWbBypBT7ws7y31G0t7yzuIri0uI1lhnhcOkiMMqysOCCCCCOtfjf5dn/AM/v/kI16d8NPj14t+FWyDRvEX2jSVz/AMSvUIXmtRneflXIaP5nLHy2Xccbs9K5K2F53zR3OiliVHSWx+pFeb+JPgj4a8QXtzf28upaPqF1KZp59OuMLITnd+5lDxKWb5iyoGLZJPzNmL4Q/F1/i3oVlq1n4Yvbe1nklimuY7y1mgt3TPyt+8WYEjacGIH5wfukMfUDE4ONp/KuGVOcd0d1LEJPmpys/J2Z5RpXwA8L2kvmandavroVlZItQuFSJcdVaOBI1lVuAVlDjAxgAtn1SneW5/hP5VxXxJ8fS/DjQtS1ifw/e3mn2Nobh7tbq1ht1fkLGxklD5LbR8qOTvAUM3y0KnOWiQ6uI5nzVJ3fm7nZ18bftJ/tT6Xd6JfeDfAt3Fftfxy2upaoEzFHEco8UW4YcsM5kGVCkbSS25PGvil+014t+Jv2my/tn+xdAl3J/Z2nI6eZGd42yy/ekyj7WHCNtB2A14v5dn/z+/8AkI120cJyvmmcNXFJ6RK9FWPLs/8An9/8hGmzwLGsbxyeZFIDhsY6Hniuw5rpkNTPIWijXPQVDXcfDbQlutSfW75WTSdIVriSUqSpdRuAGDkkfe4z0AI+YUe0VNOTOnCYOeNrwoQ3b37Lq35Jas0fH9x/wjng3QPCqmVbpkF1dKX+7kk7DgYYby2OePLHXg15dWl4g1mbxDrV7qc42vcybgvB2KOFXIAzhQBnHOKzaqjBwjZ7vV+pWbYyOLxLlT+CKUY/4Y6L7935sKKKsW1t5v7yTIiBxkdWPoP8e35A6nmFeitLFuOBaxkDuzNk/XBFL+4/59Iv++n/APiqfKLmMyitP9x/z6Rf99P/APFUfuP+fSL/AL6f/wCKo5Q5jMorT/cf8+kX/fT/APxVH7j/AJ9Iv++n/wDiqOUOYzKK0/3H/PpF/wB9P/8AFUfuP+fSL/vp/wD4qjlDmMyitP8Acf8APpF/30//AMVR+4/59Iv++n/+Ko5Q5jMorT/cf8+kX/fT/wDxVH7j/n0i/wC+n/8AiqOUOYzKK0/3H/PpF/30/wD8VR+4/wCfSL/vp/8A4qjlDmMyitP9x/z6Rf8AfT//ABVH7j/n0i/76f8A+Ko5Q5jMorT/AHH/AD6Rf99P/wDFUfuP+fSL/vp//iqOUOYzKK0/3H/PpF/30/8A8VR+4/59Iv8Avp//AIqjlDmMyitP9x/z6Rf99P8A/FUfuP8An0i/76f/AOKo5Q5jMorT/cf8+kX/AH0//wAVR+4/59Iv++n/APiqOUOYzKK0/wBx/wA+kX/fT/8AxVH7j/n0i/76f/4qjlDmMyitP9x/z6Rf99P/APFVWuLZVUyQ7jGPvKxyV/xHv+HpkaC5VoooqSjqPiz/AMlA1f8A7Y/+iUoo+LP/ACUDV/8Atj/6JSiuaj/Dj6I9POf+RjiP8c//AEpjvhV/yUTSvrN/6KeuVrrPhW7H4h6UNxxmbjP/AEyeuTq4fxJei/UVX/kXUf8AHU/9JpBRRRWx5pq22vX0WiT6KkuLCacXDKOCWAxjI6g/KcHPKgjHOaVRxd6nhiM0qRjOWOOBnFZNJPQ6XVnOK53eysvJdiSZvs9hsP37gg49FHQ/iazqtX8wmuW248uP5Ewc8D3qrUsxCiiikB9E/sjfGr/hWvjpdE1rVPs3hDXMpN9ol2wWlzgeXOflO3O0RscqMMGY4jGP0vr8R6/Sj9kP44yfEzwjJ4d1u6mn8VaBGvmXFzMjSX1uWISQDhiU+VHJB5KMWLOQBjR9IV8D/ttfGr+2tYg+H2gapv0zT8vrH2aXKTXIb5YH+Xnytu4gMRufBAaLj6Y/aQ+MkXwc+H095btu8Q6pvs9LjV490cpQ5uCr53JHwT8rAsyKcBsj8rr29udSvLi8vLia5vLmRpZp5nLySuxyzMx5JJJJJ5JNCBkFFFFAgrQsm8+2ltv4wfNT3IHI/Ks+pbadraeOVeqnOPUdxTQEtXo9evrTRbzSIpcWV66SSoeeV547DJ25I5O1ecdYLuIQzsqcxn5lPYg1Vl+6PrVJJvU2jVnTTcHa6a+T0a+aIqKKK1OYK0hxaWoHAKFj7ncwz+QH5Vm1p/8ALraf9cz/AOhtVRJkMoq1pmnXGr6lZ6fZxmS7vJkgiQfxOxCqPzIr234i/Dyxt5NCmudJufDui6fqQ0C6vpLFoftMKhSl5yBvZ8TEtz0X2p3JPCKK9KuPCNjbW/iCe1tbu2tU0ZrmEz3FtfJIy3UMZKTom3GHOdoVlPBOCQdTwv4Q8N/274OuLe2u9Ws5L+wS8nF3BJAzSld0ckGwvEA5K/PuDhSBjIILgeQ0V6jo/gzQPEP9vaxFBcW2l2N1FaR2NxrdpbSPI4kYt9omRECgRnCBCxz1wCanfwF4R0s24vL7UNRW81uTS4JtNuoPLEQjgcSFgrqzKZ8FVOCRwy45LgeT0VrSeH7pvE7+H7Uefem9NjGAMeY+/YPzNe4+J/h9DaeIfBk48MSafp2n69BoE/2mxMSajErIUuGDKBJ5mJtx54Cj0ouB88UV6J8PrG0uPisbaeGyNqjX5CXUAlgTZBMVLRlWBCkA42np0Na+rLoOu6RqLWs+m3Wr6bo0s95eaXpq21tMxu4FjCxvEm1grtl0RCcgZI3ZLgeSUV6h4t8F+F9Im8Uwab/bDv4avo4Z2ubiLF1E0hRguI/3bAgAMdwPJ2jpVzxR4c0LUfij4ksdN8OXw0+wln+0Rx6vbWcMREgUOJHgEcUfIUIc8kYbsS4HkdFeqat8P/D3hmLxDeam+o3VtZHTWtIbO7gzIt1DJIVaZVdDt2YDoCGwcD5gRgfDKxspNYvtT1VIDpWlWck87zw+csTPiGF/K6SbZZYyVPBAOfSi4HFUV2HjfwvqmlFNW1GPTYI76Yx24sFCRXKqiEzxKo2+W29eRgbiRtGCB3mkeEtH8UeAvCVo9va2d5bxy6peXyRqsstmt1LHcbm6uUURsoPQBqLgeJ0V6z8TtF0q9h1PxFZWMWmlYtEMVlZoscCC6spJZPlA67o15z3Oc543vCnhvS9G13UtDnglvNMXxLoUTRTspMgcT8NlSCuW5GORkcZzRcDwiivQW0PTdZ0rxLLo1u9ksWo2VvDFqF1bsAXFxuJnaOMIuUHAKj+9uwCNbwPpaaP4f8Ztd3fhq1v7OexjS+1C2i1O3QP5xZUKRTqS2F5Ufw4JGKLgeUUV7VYaboH9h3+paxZJqhuNBuLsPpyQWSKy6p5W6L/R8rkYwWXKqWXABAXldN8E6bqOoeDYhJeJDrtjc3cw8xS0ZjmuUUKdvTbAmcjqT0yAC4zz+iuv8Z6NoXh+30m1sV1GTU7mws764mnmTyU86BZGjVAmTywIYtwOMH71chQIKKKKYBUkPPmg8gxPkeuFJH6gH8KjqWDrJ/1yk/8AQDQgMqiiiszQ6j4s/wDJQNX/AO2P/olKKd8WHYeP9XAYgfue/wD0xSiuej/Dj6I9POf+RjiP8c//AEph8Kv+SiaV9Zv/AEU9crXVfCr/AJKJpX1m/wDRT1ytVD+JL0X6iq/8i6j/AI6n/pNIKKKK2PNJYvun61chb7PbTXB648tPXce+e2BVFZNoxitK6tlmit40urYLEpzuk53Hr+FZtO9zTmVrGRRV7+zf+nu0/wC/n/1qP7N/6e7T/v5/9ap5WTco0Ve/s3/p7tP+/n/1q0rXwXrF/bpcWtpJPA+dskUbsrYODghcdQRSem5pTpzqu1NNvy1OfrsPhf8AEXVvhX410zxLpM0wa2kUXNvHJsF5blgZIGJBGGA6kHaQGHKgir/wgHiD/oG3P/fiT/4msj+y2/5+bX/v5/8AWoWuw6lGpSt7SLV+6seh/Hz4yXvxo8dXGrbruHQbb9zpdhcOp+zxYAZiF4DuV3N94jhdzBFry2r/APZbf8/Nr/38/wDrVqReBddniSWKxnkikUMjpC5VgeQQdvIoem4U6VSq7U4t+iuc5RXRzeBdct4pJprGeOKNSzu8ThVA5JJK8Csr+zf+nu0/7+f/AFqFrsKpSnSdqkWvVWKNFXv7N/6e7T/v5/8AWo/s3/p7tP8Av5/9anyszuSK32iwRv47c7Wz1Knpz+mKqv8AcNX7K1W3lYvdWxjdCjbZOcH0rPkbazpwcEjKnINUkyuZWsRUUUVoZhWn/wAutp/1zP8A6G1ZlX7aUTxJAf8AWpkJ/tA87frnJ98/QGoksv6NrF74f1O31LTpvIvrclopdqsUJBGQCCM88HseRzVjR/E2q6BFdRaddmCO7MZlXYrBijblPzA4IPp2JB4JBymUqSrAgjgg9qSqJOjv/HWvaik0U13EkE1sbNoLe1hhiERkWQhURQqkuikkAE45NK3j7xAbS3tVvliSCSKUSQ28UcrtGcxl5FUPJtPI3E4rm6KQHTJ4/wBdiv7y9SWyV71VFxCNOtvs823lWaHy/LLAkndtzyeeap3Hi3WLryPNvC32e8a/j/dp8szBAWHHTESDb0G3gdaxaKANWz8Sanp+vf27bXPl6t5rzi48tSRI2csARgHkkccHkYwKfofinVvDfm/2Zd+QJZIZXBjRwXikEkbYYHBDDP0JB4JBx6KANGw17UNM1V9Utbjy79xKDLsU58xWV+CMcq7DpxniorHVbvTYr6K1m8uO/g+zXA2g7496vt5HHzIpyMHj61TooA2L3xVq+oy6zLc3fmPrUglvT5aDzmD7weB8vzc/LitI/EbxE19Jevc2j3E0H2edn0+3YXKbg371THiVsqp3OGbIHNcrRQBv6x4213X47uPUb7z0uzbmUeUi7vIRki+6oxtV2HHXPOcCqeh+INR8N3j3Wm3AhlkjaGQNGsiSxnqjo4KspwOGBHArMooA3td8Z614ltLe01O6jmtrVy8ESW8UawZABVAijYhwDsXC55xnms671a8vrLT7K4m322no8dum0Dy1Zy7DIGTlmJ5z1qlRQB0tt4/8QWkskiXkT+ZbQWjJNawyxmOBAkXyOhXcigANjd1Ock1HceOvEN1eXt5LqUjXd7dQXs0wRQzTQ7vLfIHBG5umM55zXPUUAbep+LdV1aO/juJLZYr+SKW4jt7SGBZHjDhGxGigH94+SOuec8VRt9XvLXTL3TIpttlevHJPHtB3tHu2HOMjG9uh5zzVKigDf07xrrelC0W3uojHaWz2ccU1tFLGYXkMjIyOpVwXYt8wPOPQVa0v4jeJNGtUtrG+iijjMnlH7JCzxCTO9UYoWRGycqpC8niuWooAualqt3q80M17N5skMEVsh2hcRxoEReAOiqBnqcc5qnRRTAKKKKACpYOsn/XKT/0A1FTpn+yI6sCJ3UqFPVAepP1GRj3z6ZBmbRRRWZZ1HxZ/5KBq/wD2x/8ARKUUfFn/AJKBq/8A2x/9EpRXNR/hx9EennP/ACMcR/jn/wClMk+FYX/hYelcnOZu3/TJ65Ouq+FX/JRNK+s3/op65Wrh/El6L9RVf+RdR/x1P/SaQUUUVseaFFFFABRRRQAVNa3dxYXCXFrPLBOmdskTlWXIwcEc9CRUNFA4ycWmnZo6u1+JXiqzt0gj1iVkTODLGkjcnPLMpJ/E1vf8Lt8Qf8+el/8AfqT/AOLrzaispYelLeKPUo57mVFWhXlb1b+697HpP/C7fEH/AD56X/36k/8Ai6x7v4peKrvz1/tPyY5tw2QwouwHsrY3DHY5z75rjqKSw9JbRRVXP8zqq0sRL5Nr8rFm+1G81OVZr27nupVXaHnkLsB1xknpyfzqtRRWyVtjyZSlN80ndhRRRQIKKKKACiiigAooooAsLfXSKFW5mCgYADnAFL/aF3/z9T/9/DVaindisWf7Qu/+fqf/AL+Gj+0Lv/n6n/7+Gq1FF2Fiz/aF3/z9T/8Afw0f2hd/8/U//fw1WoouwsWf7Qu/+fqf/v4aP7Qu/wDn6n/7+Gq1FF2Fiz/aF3/z9T/9/DR/aF3/AM/U/wD38NVqKLsLFn+0Lv8A5+p/+/ho/tC7/wCfqf8A7+Gq1FF2Fiz/AGhd/wDP1P8A9/DR/aF3/wA/U/8A38NVqKLsLFn+0Lv/AJ+p/wDv4aP7Qu/+fqf/AL+Gq1FF2Fiz/aF3/wA/U/8A38NH9oXf/P1P/wB/DVaii7CxZ/tC7/5+p/8Av4aP7Qu/+fqf/v4arUUXYWLP9oXf/P1P/wB/DR/aF3/z9T/9/DVaii7CxZ/tC7/5+p/+/ho/tC7/AOfqf/v4arUUXYWLP9oXf/P1P/38NH9oXf8Az9T/APfw1WoouwsWf7Qu/wDn6n/7+Gq1FFFwCiiikM6r4sBf+E/1fJOf3Pb/AKYpRTfiz/yUDV/+2P8A6JSiuej/AA4+iPTzn/kY4j/HP/0pmV4Q1pfD/i3TdRcosMU+JWdSwWNsq5wOchWJHv69Kd4m0dtA1/UNNIYLbykR72BYxnlCSOMlSD+PasCT/WP9TXY6frula7pVjo+vl7OayVkt9XRWlZY85EUidWXlgCD8vyjGN2W3yy5vvFh3Gvh3hZSUWnzRb0V3ZNN7K9k03ZK2u91zFFdgPhprlz8+ltYatbjhp7G7RkVv7pLEHOMHp3FL/wAKr8W/9An/AMmIv/i6v29P+ZfeH9jZh0oTfpFtfelY46iux/4VX4t/6BP/AJMRf/F0f8Kr8W/9An/yYi/+Lo9vT/mX3h/YuY/9A8//AACX+Rx1Fdj/AMKr8W/9An/yYi/+Lo/4VX4t/wCgT/5MRf8AxdHt6f8AMvvD+xcx/wCgef8A4BL/ACOOorsf+FV+Lf8AoE/+TEX/AMXR/wAKr8W/9An/AMmIv/i6Pb0/5l94f2LmP/QPP/wCX+Rx1Fdj/wAKr8W/9An/AMmIv/i6P+FV+Lf+gT/5MRf/ABdHt6f8y+8P7FzH/oHn/wCAS/yOOorsf+FV+Lf+gT/5MRf/ABdH/Cq/Fv8A0Cf/ACYi/wDi6Pb0/wCZfeH9i5j/ANA8/wDwCX+Rx1Fdj/wqvxb/ANAn/wAmIv8A4uj/AIVX4t/6BP8A5MRf/F0e3p/zL7w/sXMf+gef/gEv8jjqK7H/AIVX4t/6BP8A5MRf/F0f8Kr8W/8AQJ/8mIv/AIuj29P+ZfeH9i5j/wBA8/8AwCX+Rx1Fdj/wqvxb/wBAn/yYi/8Ai6P+FV+Lf+gT/wCTEX/xdHt6f8y+8P7FzH/oHn/4BL/I46iux/4VX4t/6BP/AJMRf/F0f8Kr8W/9An/yYi/+Lo9vT/mX3h/YuY/9A8//AACX+Rx1Fdj/AMKr8W/9An/yYi/+Lo/4VX4t/wCgT/5MRf8AxdHt6f8AMvvD+xcx/wCgef8A4BL/ACOOorsf+FV+Lf8AoE/+TEX/AMXR/wAKr8W/9An/AMmIv/i6Pb0/5l94f2LmP/QPP/wCX+Rx1Fdj/wAKr8W/9An/AMmIv/i6P+FV+Lf+gT/5MRf/ABdHt6f8y+8P7FzH/oHn/wCAS/yOOorsf+FV+Lf+gT/5MRf/ABdH/Cq/Fv8A0Cf/ACYi/wDi6Pb0/wCZfeH9i5j/ANA8/wDwCX+Rx1Fdj/wqvxb/ANAn/wAmIv8A4uj/AIVX4t/6BP8A5MRf/F0e3p/zL7w/sXMf+gef/gEv8jjqK7H/AIVX4t/6BP8A5MRf/F0f8Kr8W/8AQJ/8mIv/AIuj29P+ZfeH9i5j/wBA8/8AwCX+Rx1Fdj/wqvxb/wBAn/yYi/8Ai6P+FV+Lf+gT/wCTEX/xdHt6f8y+8P7FzH/oHn/4BL/I46iux/4VX4t/6BP/AJMRf/F0f8Kr8W/9An/yYi/+Lo9vT/mX3h/YuY/9A8//AACX+Rx1Fdj/AMKr8W/9An/yYi/+Lo/4VX4t/wCgT/5MRf8AxdHt6f8AMvvD+xcx/wCgef8A4BL/ACOOorsf+FV+Lf8AoE/+TEX/AMXR/wAKr8W/9An/AMmIv/i6Pb0/5l94f2LmP/QPP/wCX+Rx1Fdj/wAKr8W/9An/AMmIv/i6P+FV+Lf+gT/5MRf/ABdHt6f8y+8P7FzH/oHn/wCAS/yOOorsf+FV+Lf+gT/5MRf/ABdH/Cq/Fv8A0Cf/ACYi/wDi6Pb0/wCZfeH9i5j/ANA8/wDwCX+Rx1Fdj/wqvxb/ANAn/wAmIv8A4uj/AIVX4t/6BP8A5MRf/F0e3p/zL7w/sXMf+gef/gEv8jjqK7H/AIVX4t/6BP8A5MRf/F0f8Kr8W/8AQJ/8mIv/AIuj29P+ZfeH9i5j/wBA8/8AwCX+Rx1Fdj/wqvxb/wBAn/yYi/8Ai6P+FV+Lf+gT/wCTEX/xdHt6f8y+8P7FzH/oHn/4BL/I46tXwzo7a/r+n6aAxW4lAk2MAwjHLkE8ZCgn8O9bZ+GmuW3z6o1hpNueFnvrtFRm/ugqSc4yenY1W1DXdK0LSr7R9AL3k16qpcau6tEzR5yYo06qvCgkn5vmGMbcTKqpK1N3ZpSy6eHmqmOjyRWtnpKVuiW+u17WW76J5PjPWl8QeKdU1FCjQyzERMilQ0agKhweclVBPv6dKKwqKIpRSSPPr1pV6sq095Nt+r1JJJHDsAzdT3pvmP8A32/OiiqMg8x/77fnThI+xjubqO/1oooAb5j/AN9vzo8x/wC+350UUAHmP/fb86dJI4dgGbqe9FFADfMf++350eY/99vzoooAcJH2MdzdR3+tN8x/77fnRRQAeY/99vzo8x/77fnRRQA6SRw7AM3U96b5j/32/OiigA8x/wC+3504SPsY7m6jv9aKKAG+Y/8Afb86PMf++350UUAHmP8A32/OnSSOHYBm6nvRRQA3zH/vt+dHmP8A32/OiigBwkfYx3N1Hf603zH/AL7fnRRQAeY/99vzo8x/77fnRRQA6SRw7AM3U96b5j/32/OiigA8x/77fnThI+xjubqO/wBaKKAG+Y/99vzo8x/77fnRRQAeY/8Afb86dJI4dgGbqe9FFADfMf8Avt+dHmP/AH2/OiigBwkfYx3N1Hf603zH/vt+dFFAB5j/AN9vzo8x/wC+350UUAOkkcOwDN1Pem+Y/wDfb86KKADzH/vt+dOEj7GO5uo7/WiigBvmP/fb86PMf++350UUAHmP/fb86dJI4dgGbqe9FFADfMf++350eY/99vzoooAcJH2MdzdR3+tN8x/77fnRRQAeY/8Afb86KKKAP//Z",
	"syok": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4lkkcOwDN1Pem+Y/99vzok/1j/U130ssfw9ht7a2t0Hi0Luurt/3i2obBEcYI2ltuMtg43MATnj0qFD2l5Sdord/ou7fRXWz1MW7GVY/DzxZqETSw6TcqobbidlhbP+65Bxz16VbHwu8YbT/xK2zkf8vMX/xdc9e6healKJb26nuZVXaHnkLsB1xk9uT+dVq3vg19iT/7eS/Dkf5k+8dR/wAKu8Y/9Atv/AqL/wCLo/4Vd4x/6Bbf+BUX/wAXXL0Uc2D/AJJf+Br/AOQD3jqP+FXeMf8AoFt/4FRf/F05/hd4wLNjS2xnj/SYv/i65Wijmwf8kv8AwNf/ACAe8dR/wq7xj/0C2/8AAqL/AOLo/wCFXeMf+gW3/gVF/wDF1y9FHNg/5Jf+Br/5APeOqHwu8YbT/wASts5H/LzF/wDF03/hV3jH/oFt/wCBUX/xdcvRRzYP+SX/AIGv/kA946j/AIVd4x/6Bbf+BUX/AMXR/wAKu8Y/9Atv/AqL/wCLrl6KObB/yS/8DX/yAe8dU/wu8YFmxpbYzx/pMX/xdN/4Vd4x/wCgW3/gVF/8XXL0Uc2D/kl/4Gv/AJAPeOo/4Vd4x/6Bbf8AgVF/8XTh8LvGG0/8Sts5H/LzF/8AF1ytFHNg/wCSX/ga/wDkA946j/hV3jH/AKBbf+BUX/xdH/CrvGP/AEC2/wDAqL/4uuXoo5sH/JL/AMDX/wAgHvHUf8Ku8Y/9Atv/AAKi/wDi6c/wu8YFmxpbYzx/pMX/AMXXK0Uc2D/kl/4Gv/kA946j/hV3jH/oFt/4FRf/ABdH/CrvGP8A0C2/8Cov/i65eijmwf8AJL/wNf8AyAe8dUPhd4w2n/iVtnI/5eYv/i6b/wAKu8Y/9Atv/AqL/wCLrl6KObB/yS/8DX/yAe8dR/wq7xj/ANAtv/AqL/4uj/hV3jH/AKBbf+BUX/xdcvRRzYP+SX/ga/8AkA946p/hd4wLNjS2xnj/AEmL/wCLpv8Awq7xj/0C2/8AAqL/AOLrl6KObB/yS/8AA1/8gHvHUf8ACrvGP/QLb/wKi/8Ai6cPhd4w2n/iVtnI/wCXmL/4uuVoo5sH/JL/AMDX/wAgHvHUf8Ku8Y/9Atv/AAKi/wDi6P8AhV3jH/oFt/4FRf8AxdcvRRzYP+SX/ga/+QD3jqP+FXeMf+gW3/gVF/8AF05/hd4wLNjS2xnj/SYv/i65Wijmwf8AJL/wNf8AyAe8dR/wq7xj/wBAtv8AwKi/+Lo/4Vd4x/6Bbf8AgVF/8XXL0Uc2D/kl/wCBr/5APeOqHwu8YbT/AMSts5H/AC8xf/F03/hV3jH/AKBbf+BUX/xdcvRRzYP+SX/ga/8AkA946j/hV3jH/oFt/wCBUX/xdH/CrvGP/QLb/wACov8A4uuXoo5sH/JL/wADX/yAe8dU/wALvGBZsaW2M8f6TF/8XTf+FXeMf+gW3/gVF/8AF1y9FHNg/wCSX/ga/wDkA946j/hV3jH/AKBbf+BUX/xdOHwu8YbT/wASts5H/LzF/wDF1ytFHNg/5Jf+Br/5APeOo/4Vd4x/6Bbf+BUX/wAXR/wq7xj/ANAtv/AqL/4uuXoo5sH/ACS/8DX/AMgHvHUf8Ku8Y/8AQLb/AMCov/i6c/wu8YFmxpbYzx/pMX/xdcrRRzYP+SX/AIGv/kA946j/AIVd4x/6Bbf+BUX/AMXR/wAKu8Y/9Atv/AqL/wCLrl6KObB/yS/8DX/yAe8dBe/D3xXp1v5k2kXLBnCgQMszdD2Qkgcdelcr5j/32/OtOy1C802Uy2V1PbSsu0vBIUYjrjI7cD8q6uKWP4hQ3Ftc26HxaV3Wt2n7tboLkmOQAbQ23OGwM7VBIxy1Qo1/doXUuiet/JNJa9lbXv3LtbnA+Y/99vzoptFeeWdX8PLGPUPHekwys4VZzMCp5zGpcfhlRn2rJ1C9k1K/ur2UKstzK8zhBhQWJJx7c10PwuC/8LA0vk5zN2/6ZPXK13vTBw85S/BQt+bI+0e1fCrXfDun+H2hkubay1EOTctcOIzLydhBJ5AHGB0OeOcnuv8AhK9A/wCg5pn/AIFx/wCNfLdFexheI6uHoxoqmvdVuxm6Sbvc+pP+Er0D/oOaZ/4Fx/40f8JXoH/Qc0z/AMC4/wDGvluiuj/Wut/z7X3sXsV3PqT/AISvQP8AoOaZ/wCBcf8AjR/wlegf9BzTP/AuP/Gvluij/Wut/wA+197D2K7n1J/wlegf9BzTP/AuP/Gj/hK9A/6Dmmf+Bcf+NfLdFH+tdb/n2vvYexXc+pP+Er0D/oOaZ/4Fx/40f8JXoH/Qc0z/AMC4/wDGvluij/Wut/z7X3sPYrufUn/CV6B/0HNM/wDAuP8Axo/4SvQP+g5pn/gXH/jXy3RR/rXW/wCfa+9h7Fdz6k/4SvQP+g5pn/gXH/jR/wAJXoH/AEHNM/8AAuP/ABr5boo/1rrf8+197D2K7n1J/wAJXoH/AEHNM/8AAuP/ABo/4SvQP+g5pn/gXH/jXy3RR/rXW/59r72HsV3PqT/hK9A/6Dmmf+Bcf+NH/CV6B/0HNM/8C4/8a+W6KP8AWut/z7X3sPYrufUn/CV6B/0HNM/8C4/8aP8AhK9A/wCg5pn/AIFx/wCNfLdFH+tdb/n2vvYexXc+pP8AhK9A/wCg5pn/AIFx/wCNH/CV6B/0HNM/8C4/8a+W6KP9a63/AD7X3sPYrufUn/CV6B/0HNM/8C4/8aP+Er0D/oOaZ/4Fx/418t0Uf611v+fa+9h7Fdz6k/4SvQP+g5pn/gXH/jR/wlegf9BzTP8AwLj/AMa+W6KP9a63/Ptfew9iu59Sf8JXoH/Qc0z/AMC4/wDGj/hK9A/6Dmmf+Bcf+NfLdFH+tdb/AJ9r72HsV3PqT/hK9A/6Dmmf+Bcf+NH/AAlegf8AQc0z/wAC4/8AGvluij/Wut/z7X3sPYrufUn/AAlegf8AQc0z/wAC4/8AGj/hK9A/6Dmmf+Bcf+NfLdFH+tdb/n2vvYexXc+pP+Er0D/oOaZ/4Fx/40f8JXoH/Qc0z/wLj/xr5boo/wBa63/Ptfew9iu59Sf8JXoH/Qc0z/wLj/xo/wCEr0D/AKDmmf8AgXH/AI18t0Uf611v+fa+9h7Fdz6k/wCEr0D/AKDmmf8AgXH/AI0f8JXoH/Qc0z/wLj/xr5boo/1rrf8APtfew9iu59Sf8JXoH/Qc0z/wLj/xo/4SvQP+g5pn/gXH/jXy3RR/rXW/59r72HsV3PqT/hK9A/6Dmmf+Bcf+NH/CV6B/0HNM/wDAuP8Axr5boo/1rrf8+197D2K7n1J/wlegf9BzTP8AwLj/AMaP+Er0D/oOaZ/4Fx/418t0Uf611v8An2vvYexXc+pP+Er0D/oOaZ/4Fx/40f8ACV6B/wBBzTP/AALj/wAa+W6KP9a63/Ptfew9iu59Sf8ACV6B/wBBzTP/AALj/wAaP+Er0D/oOaZ/4Fx/418t0Uf611v+fa+9h7Fdz6k/4SvQP+g5pn/gXH/jR/wlegf9BzTP/AuP/Gvluij/AFrrf8+197D2K7nv3j/xH4Zu/C97DLeWd9K6kW8cEqyOsuDtbg8Adz6ZHOcHwrT72TTb+1vYgrS20qTIHGVJUgjPtxVaivGzDMp42qqriotdjSMOVWN34j2Men+N9ZhiZyrSiYljzmRQ5/DLHHtRVv4qBf8AhPdWyTn912/6ZJRXJmEVHF1UtlKX5sqHwoPhd/yULS/rN/6KeuXrqPhd/wAlC0v6zf8Aop65etJf7nD/ABT/ACgL7QUUUVyFBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRWvpelwyW/26+8w2hcxJHCwV5XABPzEEKFDKSSDnIAHUrcIObshN2Miiup+06d/wBADT/+/lx/8do+06d/0ANP/wC/lx/8drX2Ef51+P8AkLmOWorqftOnf9ADT/8Av5cf/HaPtOnf9ADT/wDv5cf/AB2j2Ef51+P+Qcxy1FdT9p07/oAaf/38uP8A47R9p07/AKAGn/8Afy4/+O0ewj/Ovx/yDmOWorqftOnf9ADT/wDv5cf/AB2j7Tp3/QA0/wD7+XH/AMdo9hH+dfj/AJBzHLUV1P2nTv8AoAaf/wB/Lj/47R9p07/oAaf/AN/Lj/47R7CP86/H/IOY5aiup+06d/0ANP8A+/lx/wDHaPtOnf8AQA0//v5cf/HaPYR/nX4/5BzHLUV1P2nTv+gBp/8A38uP/jtH2nTv+gBp/wD38uP/AI7R7CP86/H/ACDmOWorp20+y1l1gtLNbPUHIWFYpGaGU9lIcllYk4DbtvQEDJYcxWc6bhre6GncKK2dK0qB7X+0NQ802RkaGOKBwskzgAt8xBChQykkg5yAB1K6f2zTP+hc03/v7c//AB6sJVFF2OWeLUZWjFy9Lfq1/XmcnRXWfbNM/wChc03/AL+3P/x6j7Zpn/Quab/39uf/AI9U+2iR9c/6dy/8l/8Akjk6K6z7Zpn/AELmm/8Af25/+PUfbNM/6FzTf+/tz/8AHqPbRD65/wBO5f8Akv8A8kcnRXWfbNM/6FzTf+/tz/8AHqPtmmf9C5pv/f25/wDj1Htoh9c/6dy/8l/+SOTorrPtmmf9C5pv/f25/wDj1H2zTP8AoXNN/wC/tz/8eo9tEPrn/TuX/kv/AMkcnRXWfbNM/wChc03/AL+3P/x6qWo6Xa3VrPfadG8P2cB7m2d9wVSwUOjEZ27mC7TlhkHLZYq41Yt2Khi02lKLV+9v0bMCiiitDsOm+Kv/ACP2r/8AbL/0UlFHxV/5H7V/+2X/AKKSiujMv98rf4pfmxQ+FDvhd/yULS/rN/6KeuXrqvhc7H4gaWNxxmbjP/TJ65Wrl/ucP8U/ygL7QUUUVyFBRRRQAUU+KKS4lSKJGklkYKiIMsxPAAHc16LD8P8ATfDVrDf+Lr/Zv5jsLX5nkIAO0t+anGAMj5xmurD4SriLuGy3b0S9WS5JHB6ZpV7rN0trYWstxO38Ma5wMgZJ6AZI5PArtbT4SamkCXWr31jpdoM+a0sm5o+cDPReTj+Lv68U+7+I81nEtl4ZsYNJsUbgqivLJjjLZBGSNuepyPvGuUupr7U5VlvbmaeQKFDzyF2C9cc/U8e9dSWBo6O9SX/gMf8AN/gL3n5HYDwv4Csf9HvvE11NdJ9+S1T92c8jGEYdCP4jznp0pf7T+G3/AEL+pf8Afxv/AI7XFizXHLEn2p4to8fd/Wn9fUdIUYJel/zbFbzOx/tP4bf9C/qX/fxv/jtIdD+Hmoc2+t31nPcf6uOVSUhZugYlOgJ5+ft97vXH/Zov7v6mmG0XHDMD70fX7/HRg/8At235WC3mzrpvhLdXMTz6JrGn6nbopyVfaxcc7BjcucY6sOvbrXG6xoGp+H5xDqVnLbu33Swyr8Anaw4OMjODxUsH2qwnWe0nkimTO2SJyjDIwcEdOOK6jTviTqcEZtNYgh1ewKqrQXSDdhenzY5OcElgx47daH9RrKzTpv8A8Cj/AJ/mHvLzOAor0seC/D/jJZJfCt61neIu57C8zgDIGQ3JxwScF+WA+WvPdQsLnS7yazvIWhuYW2vG3UH+o7gjgiuXEYKrQSm7OL2a1T/rs7MpSTK1FFFchQUUUUAFdTc/8gjQP+vR/wD0omrlq6mch9G0JlO5Vt5I2I5AcTyMVPvh1OPRge4roofDP0/VEyIrC1+3X1ra79nnyrHuxnbkgZx+NdLL4LjfUb7TLLUWm1G0Ut5UkHliQAAnawY8898VzmmXKWWpWdzIGKQzJIwXqQGBOPyrrn8W6Zaa5qGt2cd3LfXClYkmRUSIkAZJDEt09q78HHDOH762+urvy2d7ed7dzN36GJF4eii0i31PUbxraC6cpCkcXmO+OrEZAA/GtG38CySay1jLeqsLWpu4riOPcJE4xwSMHn1qr/bllqOhWWmakLmN7F2MU0Cq+5WOSpBI/PP4VrWvji0XWxcS288dhDYmyhRAHcDjDHJA7VvShgm48+3u9Xf+9fsr7bdN9RPmMKfw8r6O2q6fdG6to5BFKrxeXJGTjGRkgg5HQ96ut4Oig1G30q51NYtVnUERCHdGrEcKz5zn6A1C2vWun6DNpWmCdzcyrLNcTqEPykEBVBOOQO9X5vFGlXuuW2u3MF2t9CFZreMKY3dRwd5OQOBxg1MYYPS9r+7dXdt3zWfpbq+trj1KFt4QmNnfXV280aWdwbZ0t4fOfeOpxkYXkc5pNN8N2uopq866jILXTo1k3rb5aQEHI2lhgjGOtT2HikxXl3fNqF/Z3VzOZXS2jWSJlPQFWYcjkZ54rTTxxZvf6/cbLqz/ALRjRIpLdQXQqCNx+ZeeexqqdPAvlu++/XR2ej01tpZeu4nzGTP4LuDqWl2dpOsw1KETRu67Cq4ydwycYH1qMeGILuLUf7N1D7TPYKXljeHy96jqUO45x74rSl8bxQ6po17bwyzyWERimmuMLJcAjHOCcY5xyetVLfX9M0dNVk01Lt7m/jaJfPVVWFW68gncfyocMDzO213fV6LlVrd/ev3+7UPeI4fDmmz6Jcauup3YtoJREymzXeScdB5uMc+tc8sPnXIht90hd9keRhmycDjJwfxratdbt4fCV9pDJKbme4WVWAGwAY6nOc8elQeGNRs9J1mC+vY5ZY4MuiRgEl8fLnJHAPP4VyVI0JypRjaKaXM9dHd33b6Fa6l/xT4Ofw1DbzLeLdRyMY3Kpt8twAdvU57/AJVR8TaD/wAI7qK2n2jz90Syb9m3r2xk1qS+LoNR0fVbK+s1jkupPtET2+44mzyW3ucA8Dj34qj4v1y31/VUurZJUjEKR4lAByM+hNbYqOE5JTo9bWV3pvff5P5iV+pgVF4s/wCRp1z/AK/Z/wD0Y1TxRPNIkUSM8jkKqKMliegA7mq3iaWO48SaxLE6yRSXkzI6HKsC5IIPcV57/gv1X5Mtbmvef8gbw5/15P8A+lM9UoYZLmaOGFGklkYIiKMliTgAVcuSH0Pw+6nciWskTMOQHFxKxU++10OPRge4p/h/VP7D13TdSMfmCzuEmKf3grA4ryp/Ezyk2ozcVd3l+bO+uPgN4og0k3gazkuFXebNJCZPoDjaT7Z/GvOdO0+41TULawtk3XNzIsUanjLE4H0r6ouPjJ4Rh0o3yakJX2ZW1VGEpb+7jHH16e9fMVjr0+n+I4dbiRPPiuftIT+HO7dt+naoR5GVYvHV41PrELNbXVtddDq0+GsF1rd34fs9cWfX7ZGYwG2KwyOoyyLJuySOeqgcVCnw0uZvAX/CUQXe+VC5ksTFhlRHKswbPOOCRgYB9q07fx54f03xXe+LLO11BtUnV2js5VQQxSuMMxkDZYcnjaOvWodO+JcemaH4cto4Z5LvT7qeW8V1Xyp4pS25BzzkN3HWjUpzx9o8n9290uz5l6Xsr+e7FX4UbvEzaL/a/wB3TP7R877N9Pk27/frn8K5zwT4S/4THU7qy+2fZfItZLnf5e/dtx8uMjrnrXdP8UdCPjqfWUtdQTTn0o6eqeWhkVs9cb8Yx75rnfBviTQPBusXF5HPqd5FcWU1uwazjiZWYrtI/etkcHPTHHXsDhVxvspcyfNyq2i31v0t23+RFF8N7i68AL4qtr0SuC7PZeVhljRyrOG3c44J46GtGL4UK/ik6I2sFVGmjUTOLXJxx8m3f79c/hUWk/EeDRvD3hmxt4J3uNMuZnukdV8qeGQncg5ycg9x1rd/4Wpoa+PJdcit9RisDpf2FFWNPNRsjBxvxgAeuaNSKlTME5qK0962i7+6vu1Xe+ux5ZqUWmRGP+zru7uAc7zc2qw7fTG2R89/SpdC/wCPq6/68Lz/ANJpKs+JNTXU3t3Gt6tqrICC2pR7TGOMBf3r5zznp071W0QhJr2VjtjSwu9zngLugdFye2WZVHqWA6mqjuj05NvDu+9n/Wy/I5Ciiiu09w6b4q/8j9q//bL/ANFJRTvio7Dx7qwDED913/6ZJRXTmX++Vv8AFL82KHwoPhd/yULS/rN/6KeuXrqPhd/yULS/rN/6KeuXqpf7nD/FP8oC+0FFFFchQVpaFoV74i1GKwsIt8z8ljwsa92Y9gP/AKwySBVawsLnVLyGzs4WmuZm2pGvUn+g7kngCvStb1CP4eaRH4f0naur3ESyX96j5ZWI+6p4I74yBhSCOWyO7CYWNROtWdqcd+7fZeb/AAWpMnbRbhcano/w3ivNP0Mtea+6iOa+kVSkJ/iVR7EZ288kZJ24rhbme61e8mvL2Z5J5m3PI3Vv8Bjgdh2qGC3BAdunYVZeRYxlj+HrTxOLlXSjblgtorZf5vz3ElbbcEjWMYUf/XoeRI/vMBVKS6d+B8o9utQVwuqlsaql3LxvIwcfMfcCmfbf+mf61UoqHVkV7OJb+2/9M/1p4vEOMhhVGij2kg9nE00lR/usCfSnMocYYAisqpY7h4+M5X0NWqvcl0uxY8uW1kSa3kdZI2DKyHDKR0II75rubLxXpnjGzh0nxduW4EuYNSiCoUz1DcYUcAZwQRgkDburi4pllGQee4qOe3DZdeD3HrXbhsVOhfk1i909n6r9d0ZNX0ZP4r8KXvhLUTa3Q3wvloLhRhZV/oR3Hb3BBOFXpng7XrfxBaJ4S19fOtJvltLgsA8DgHaAT+S/Xbgg4HC67oV74d1GWwv4tkychhysi9mU9wf/AKxwQRVYvDQUFiMP8D6dYvs/0fVBF9GZtFFFeeWFaemasLRGt7mFriyY7/KV9jI395GwdpOADwQQBkZCkZlFVGbg7oR0v2jQP+f7U/8AwBj/APj1H2jQP+f7U/8AwBj/APj1c1RW3to/yL8f8xcp0v2jQP8An+1P/wAAY/8A49R9o0D/AJ/tT/8AAGP/AOPVzVFHto/yL8f8w5TpftGgf8/2p/8AgDH/APHqPtGgf8/2p/8AgDH/APHq5qij20f5F+P+Ycp0v2jQP+f7U/8AwBj/APj1H2jQP+f7U/8AwBj/APj1c1RR7aP8i/H/ADDlOl+0aB/z/an/AOAMf/x6j7RoH/P9qf8A4Ax//Hq5qij20f5F+P8AmHKdL9o0D/n+1P8A8AY//j1H2jQP+f7U/wDwBj/+PVzVFHto/wAi/H/MOU6X7RoH/P8Aan/4Ax//AB6j7RoH/P8Aan/4Ax//AB6uaoo9tH+Rfj/mHKdDNrNlYqTpf2l7o/dup1WMxf7qAt83o+7jPABAaueoorOdRz8kNKxqaXq62cbW13C1zYM2/wApZNjo+PvIxB2k4APBBAGRkKV1PP8ADv8A0ENV/wDBfH/8frl6KwlTjLVnPUwsZS5k2vS36pnUef4d/wCghqv/AIL4/wD4/R5/h3/oIar/AOC+P/4/XL0UvZRI+p/33+H+R1Hn+Hf+ghqv/gvj/wDj9Hn+Hf8AoIar/wCC+P8A+P1y9FHsoh9T/vv8P8jqPP8ADv8A0ENV/wDBfH/8fo8/w7/0ENV/8F8f/wAfrl6KPZRD6n/ff4f5HUef4d/6CGq/+C+P/wCP0ef4d/6CGq/+C+P/AOP1y9FHsoh9T/vv8P8AI6jz/Dv/AEENV/8ABfH/APH6oalrELQPZ6bHLFavjzpJWBkuMHjOOFXIDbATz1ZsLjGopqnFO5UMLGLUpNu3e36JfiFFFFWdR03xV/5H7V/+2X/opKKPir/yP2r/APbL/wBFJRXRmX++Vv8AFL82KHwok+FwX/hYGl8nOZu3/TJ65Wuo+F3/ACULS/rN/wCinrl6uX+5w/xT/KAvtBRRW14T8PyeJtetNPUMInbdM6/wRjljnBwewzxkisKVOVWapwV29Bt21O08MQWngjwt/wAJLdwxvrV7ldPhmJ4TgbguM9CST3XaARu54VBJdTPPOzSO7FmdzkuxPJJ710PjvW013XzBaFV02xH2a2SPGwKvVgASMEjgjGVC1jqoRQo6Cu/G1IuSoUvghp6vq/n+ViF3fUSRxGhY/wD66zXdpGLMeanvHy4QHgdfrVavKqSu7HRTjZXCiiiszQKKKKACiiigAooooAVWKkEHBFaMMolTPG7uKzamtX2SgZ4bitKcrOxnON0TXMP8aj613xWD4ieEZN6KfE+kRfIVZjJcRLjqMEsTyMc/Ng5AbB4sjIwelWPDetSeF9ftb5SxhU7ZVX+OM8MMZGT3GeMgGvTwdaNKbhU+Cekv8/VbnO1dabnM0V1nxC8Px6HrzS2gU6Zfr9ptnj+5g9VBAAwD0AzhSvrXJ1yYijKhVlSnui07q4UUV6v8GvgXqHxci13Un1e00Pw3oMPnahql2pdYxtZsKoI3EKpJ5AA+orFu24zyiivZfFPwf8F2XgvWvEfhT4rab4jfSPKMuntp0llcOrypHuVZGJYAuCSBj35rxqhO4BRRRQAUV69+z78Df+F7eItV0j+3v7G+wWn2rzfsn2jf86rtxvTH3s5ya8muYfs9zNDu3eW5TOMZwcUXV7ARUUV9Oan+y14U8LeCfC3ijxZ8V10W28RW8MsCNoEs4V5IhJsLRynoD94gDik2luB8x0V658c/gHqvwRu9Ia41S11bSNYjd7O+tlKb9u3IZSTg4dSMEgg9eDXkdNO+qAKKKKACiiur+G3gDU/ij400zwno89pBqOo+b5Ul47LEvlxPIdxVWPRDjAPOPrQBylFdB448H33gDxbq3hnUpbaW/wBLmME0lszNGzAA/KWAJHPcCufoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAOo+KgX/hPdWyTn912/6ZJRTfir/wAj9q//AGy/9FJRXTmX++Vv8UvzYofCh3wu/wCShaX9Zv8A0U9cvXUfC7/koWl/Wb/0U9cvVS/3OH+Kf5QF9oK9O+H7LoPg3xJ4iU/6UP8ARYSsYLRtgYOT2LSKSP8AY79K8xr0vxUP7L+HXhPTP9Z9pzeeZ025Bbbjv/rsZz/D0546csfs3UxH8kXb1fur8xT1sjh7RMlnI6cCrdRwLtiXpzzUlcK2BkEkEbyZZiGbtSfY4/VvzqO9b5kXuBmun+Gep+H7Hx1oE/i4Sv4ehukkuvLiEnA5XehB3R7gu8AEld2ATism481mjRKXLdHvnwZ/ZO03xp4Pg8Q+KtQ1S0/tD95Z2tntiZYgSN7mSNs7+GXaMbcHJ3YX0T/hijwB/wBBjxP/AOBMH/xmvoXSdVtNd0qx1Swl86wv4EuYJdpXfG6hlbBAIyCDggGrla8kexnzy7nzd/wxR4A/6DHif/wJg/8AjNH/AAxR4A/6DHif/wACYP8A4zX0jRR7OPYOeXc+bv8AhijwB/0GPE//AIEwf/GaP+GKPAH/AEGPE/8A4Ewf/Ga+kaKPZx7Bzy7nlXw3/Zq+HPgP+0/O05de+2+Vj+37eC78nZv/ANX+6G3O7n12r6V2138NvhfZ2s9zJ4D8MtHCjSMItBikcgDJ2osZZj6AAk9ADXS2rRrOhlxs5zkZ7Vo+fY+kf/fv/wCtWM4JPZlKTfU/NT9o/VPAHiTxxp938PYbGHRU02OKVbCwNnGZxLKWJQouTtKfNjpgZ4rx9baNZFwzbhzivqH9pz4i/CLxf4Qtj4D/ALKfxLLqy3N3cW2kPbTSRGOXezStEu7LshIJJJ57Zr5YtG/fc5JYGlFx0SRdpWbuXqr3aZQNjkfyqxTXXejLxyO9bsyR2epMviL4TQXUh/0rRZxDvaMZZchQqkdBtdM+pTn1rzCvTPhaP7QHiHRPuf2hZH9918vGU+73/wBbnqOnvXmdd2PftaVHEdWrP1i7flYI6NoK98/Z5+OsHwk0zxDpfiHw3NrXgzXyIboRgfI+whl+b5X3I2CpI6A5658Dr0j4a/G3xD8L9N1TStOstG1HSdUdZLqy1ayFxFIyjAJGQe/rXlSV0Wj6B8TfBv4PfFD4P+JviD8Mk1LRbjQo5ZZrS5dihaNBI0bK7NglTwUfGT+FXZdEuf2ov2bvCD2X77xl4T1GLSp2PLtC5SMue+NhikJ/6ZvXhnjD9pTxb4q8ITeErTTvD3hvw7cnNxZeH7D7Kk3IJDfM3BIGcYzjByOK9a/ZO8R6R8G9A13xr4g8ceHk0rVLFgvh2C78zUmnilYIWhxlSQHx1yJFJIFQ00rjO6+I0Xh7xx+0h8Mfg7Kqv4T8LWuJrUthZZVtzIkTY6jZFEP+BsKv2fxU1q9/amn+Es+kaU3gD57IaOdPi2Ki2plEv3e5HT7u09M818P6n481vUPHd340jvJbbXZ79tQWeJsNFIX3Db7DoB0wMV6+37ZHj4u96mleE4/ETwfZ215dKH24p6b923Httx7UODC577+zt4U0vwR+1J8V9B0UBdLtLMeRGDkRB3ifYD6KWK8+lc98bpbz9nz4S6ZpHwztD/YviUGTUvF8Dh5bh2zhAy/c3AnaegGQvO4183fDD49+KvhX4q1rxNp6WOp6trMbJdy6qkku8s4cv8jqdxYdSTVvwZ+0R4p8HeENY8IvZaPrnhrVGZn0/WIZJY4dxJYR7JEKgnnqcEZGDkk5He4XPJOtfoR8aPEnhLwz8BPhFceLvBY8VWj2dmsNudSlsvJcWikvlAd/HG08V+fLsHdmChATkKucD2Gea9/X9rfxJP4a0Pw/qngvwJrOn6LBFBajVdLkuCvloED/ADS4DYHJAFVJN2BHqH7aVrL4n8EfDHxvZ3j2/h2+t0S30qWNV+ymaFZQ2R1+RApB4G0Y6mvW/H0/hb4B6X4R0HRvHeneBLAxF5A/hh9TbVwu0MZJV6def4vmGCBivhr4rfHHxb8YpbAeIZ7WKx08EWthYw+VBCSACQMkk4AHJOB0xzXTaL+1F4wsPDFj4d1nSvDPirTdPAW0HiLTRdNAAMLtO4ZwOATk+9TyOyQXPonwbrXw08Tfta+GNa+G1zDJBeabd/2hHb2cttGJxG2HCui8spGdoxlc9Sc+QfGb4j+MPF3xV8S/DDw/9hsdHv8AxD9lSxhtIl+0XX2gYlkmKlyxlG4ndgDjGBiuE079ovxXpvxG03xzFY6ENQ0y0extbJLHybSGFt+VEcbKesjHJbPNcPrPjjVtY8dXnjQPHZ65cagdTD2gKrDOX3goGJIAbpknpTUdQufoX4c1TxNofxI0bwb4++M+na7q9+m6XwwvhZCk6lGOPtCKAnALZYDgcjmvL/h68nw2/bf1nwZ4baOw8NavKzXVjHEmxgLB7hVUkZQLIxICkccdOK8jn/bF8eXGsaZrTaT4VGs2QCPfrpmLi6jGf3ckm/cEJOSqFAfpkVwWp/G3xPqHxbPxPi+xWXiXzUlC20TeQNsQi27XZjhkGDk9z0qVBhc9D/au+K/i/X/iB4n8E6jq/neGNL1MSWtl9mhXy2VCFO9UDnh26sev0r52r1D4q/HDUfi5FGdW8L+E7DUBOJ5dT0vT2hu7ghCu2SVnYsuCOPVR6V5fWkVZCYUUUUwCiiigAooooAKKKKACiiigAooooAKKKKAOm+Kv/I/av/2y/wDRSUUfFX/kftX/AO2X/opKK6My/wB8rf4pfmxQ+FEnwudj8QNLG44zNxn/AKZPXK11Hwu/5KFpf1m/9FPXL1cv9zh/in+UBfaCvTPi2Psmp6TpkPy2NnZL5MfXZlivU8nhFHJ7fWvM69N+Mf8AyM9p/wBeSf8Aob10Yb/cq784fqJ/Ejj1G1QB0AxVS9b5lX0GauVQu2zMR6DFefV+Eun8RBRRRXMdB+rHwxtLiw+Gvg20u4Jbe6t9Hs4pYZkKPG6wIGVlPIIIIIPSvnXwNpc/7W/xI16LXfE1zp3hHSh59ro1vIsdxJHl0idYzuTcu7Mkh3EF1QYDDb9aV8NfEL4G+OPhr4xn1nwRbanJprTM1hdaK8hubRZA/wC6IVjKNq5UvyGBGSCxUdNRPlsjnptXdzb+HXifWfgp8a3+HFx4gXXPDv24aZi3YyRRySHKNGpbETiSTEqgkA+YDuKqa+yq+M/2f/2f/EEnirTfE/ifTZNN0vTXFzBbXQKT3EykhPkBDIEZQ+XA3YUAMGJH2ZVU721FUtfQK+YfjD4n1n4g/GDSvhJpXiBfD2mTlIL66lYxieSWMsUJDZkUxsqLGdoeR9p/hI+nq+Wv2lPgTrPiTWz4w8L2f22aWELqFnGx84tGpxKgJ+bKKqbFAOVXAYscOd7aCp2vqcp8WvCd/wDsp+PtJn8F+KZJ7HUoxcnTrqUNKRH8pFzGgVXjYs+x8KR84GCm4/YGgazB4i0LTNYtUkS21G2iu4llADqkiBgGAJGcHnBNfB/h74LfEn4oeJ2n1201i2Mrxi91fXVkEiptwCPNIeUhU2gDOPlBKg5r710vTLXRdMstNsYvJsrKFLeCPcW2RooVRkkk4AHJOaikmlqVVaPyOu7S4sLue0u4Jbe6t3aKWGZCjxupwysp5BBBBB6VDXYfFn/kqnjn/sOX3/o964+uZm6J7RsTAeoxV+s2BtsyH3xWlXRSehjVWp0HwwuJbbxtaxRPhJ1likGAdyhC2PzVTx6VyfiG1isdf1W1t02QQXUsca5J2qHIAyeegrp/hx/yPenfWb/0W9c74s/5GnXP+v2f/wBGNXoz1y+LfScvyiZr4jIoorbg8LXtx4WuPEUbwGzt7j7PJHuPmjhfnxjG3LoM5zlhxXmlGJRXR6r4I1fS59JtvJ+13ep2wuore0VpJFBJBVlx94FTkDOKyY9H1GbUDp0dhdPqAJU2qwsZcjqNmM5/CgClRWhBoOq3V5PZwaZey3kAJlgSB2kjA67lAyPxq9e+GJbfxXH4fhnSSeSaKBJZFKLufbjIGSAC3vQBg0V06eErd9b03So/EGn3M15eR2bi1inLQ7mCliJI0BAJ6A/41jpouoTyRrbWV1OJpWhiMcLN5rr1VcDkgEHA9aAuUKK1IvDOtz3U1rFo+oSXUDBJIUtnLoxBIBXGQSATz6Go7PQdV1CaWG00y9uJoXEciQwM7I3PykAcH5W4/wBk+lAGfRV1tH1FdOXUWsLoaezbRdGFvKJ9N+MZ/GrP/CNapFPDDd2N1ZmeJ5ozcW0g8xUQsSAFJIwOoGB1JAyQAZNFFamiaHNrcl1snt7a3tIvPuLi4YiOJNyqCdoJOWZQAATzQBl0Vtjw1NMdRFpe2V39ihFwRA7Eyx5+ZkBUH5epBwQMnGAauJ4GvlLm6u7KzhggjnuZZ3YLbeZnYjgKTvIGdqhjjrjBwBc5iiull8EagjTGOa1uLdLM30VxC7MlxGJBGdny53bmxtYAjBz2zma1ok+g3Edtdywm7KBpYI2Ja3J/gfjAb1AJx0ODkUAZtFFFIYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB1HxUdh491YBiB+67/9MkopvxV/5H7V/wDtl/6KSiunMv8AfK3+KX5sUPhQ74Xf8lC0v6zf+inrl66r4XBf+FgaXyc5m7f9MnrlaqX+5w/xT/KAvtBXpnxNP2+08MazJxdX9kPMVfuDAVuB16yN1J6CvM69KnP9ufCa0n+9Po115Ukk3LbCcBUPJxiSMY4+77CujA+/Rr0u8b/+Au/5XFLdM5FCSik9SBWfO26ZyfXFW7VsxY7qaos25ix6k5rzar0RrTWrEoorpPh5qtpoXj/wpql/L5NhYara3M8u0tsjSZWZsAEnABOACawRqfq9RUNpd29/aQXdpPFcWtwiyxTQuHSRGGVZWHBBBBBHWpq7jjCsDxJ4y0nwsqi+mY3DruS3iXdIwzjPoB16kZwcZxW/XgvxbsruDxW9xOWa2uYkNuSSQoUAMozwDuycD+8D3rlxlaVGnzRWp6+SYCljsUqNZ2Vm/W3T+uh6l4c8f6N4mn+zWsksN2clYLhQrOAASQQSD9M54JxgZrqK+bvAFld3vi7SxZllaGUSyOCQFjXlskdiPl9CWA719I1OCrzrwcpo1z7LqOAxCp0Xo1ez6BRRRXYeGflb8Wf+SqeOf+w5ff8Ao964+vTv2h/EGmeKPjJ4o1PR72K90+R4Y47iE5RzHBHG209xuRgCODjIJBBrzGuKW7OxbCq21gw6g5rVrJrQkk/0fccZZf51rSe5lVWx1vwmtEu/F3nSMwe1t5JlxjBY4Tn2w5/HFcHqF7JqV/dXsoVZbmV5nCDCgsSTj25r0LwWf7G8F+KdcPDtGLSGSL/WxuRjIPGBmSM8H+H2FeaV6eK9zCUafV80n83ZfkZL4mwrtvD3iyy0Pw9a208Avs3tw1zYsSglheKNR8+CB8yZHXlRxXE0V5pVj0pvF9jq+nLb3mpfZr++02aCe7MblYZWvnnKttBO1kIBKg43AeoqGXxFpdzdahY/2k0az6RBpy6q8T4d42RiWABfYwQp0zgLkdRXndFFxWPStQ8Q6Tqun3GkprRtZIlsv+JlJFLi78hHVgQoLjBcbcjogzt4xman4g0+5+KUOtpdvJpq6hBO1w6MGKKU3MVxnPB4riKKLjsejXGt2kfirRNSm1vQbmzt9UiuHGnaY1vLHGJAxZyLeMsAB0yxz2qK48S2N9rFlqdvqEVipgks5LGeCRoIEKFTt2DIjcMScfOGJPP3j59RRcLHqSnSLnw74lhstZ+x2jyadG05E7QeYFnJRcgyeXxkZBOQO3NZOv8AiqzvrPxRHa3cu6/nsFUsrK1ykMUivI3puba2Cc5b2NcQtzMkElussiwSsrvGGIVmXO0kdCRuOPTJ9aiouKx6fe+MdKm0zz7U6dDcSadFYPE0V29yu1FU4HmCDbuXcDwf9nOSWyeINEXUE1CbUoZb+4F6072kc6xMZLZ1Uukg4kLsB8nygGvMqKLhY1dDu/sh1H/iYfYvNs5Yv9T5nn5x+6/2d397tip/C189hfSumrR6Y0kRTzJ4DNDICRlJFCtleM/dbkDjvWHRQM7z+3dHsfHvh3UbOaGO2tnt/wC0Li1t2ihkYP8AvWSPAIUocEbRnn5ecVVtdastYsdf0zU9QNs9/fJfw30qO6mRfMBEgUFsESk5AOCOnNcbRRcLHqWi+ObDwlHFb6beLcS6dp0yxXLwsEuLiSeNyqqRuChUxk7TkE8HFcL4hXSpLmO70mZ/JulMj2su4yWr55QuRhx3DA5x1ANY9FFwsFFFFIYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB03xV/5H7V/wDtl/6KSinfFQL/AMJ7q2Sc/uu3/TJKK6cy/wB8rf4pfmxQ+FB8Lv8AkoWl/Wb/ANFPXL11Hwu/5KFpf1m/9FPXL1Uv9zh/in+UBfaCvR/hRqMU8uqeHLqSVYNVhYR7WPysFIbAwQCVJOT/AHAOeK84qa0upbG6gurd9k8DrJG2AdrA5BweOopYLEvDV41bXS3XdPRr7gkrqxelim066ubWddk8LNG65B2suQRkcHkVTr0Hx9ZLrdjp/i6whb7NfRKt0BkiKRfl5J7cbcgAZUf3hXn1Rj8P9XrOne63T7p7P7jWk7q4UVLbw+c5BbaiqWZsZwB7U/y7P/n9/wDIRriNG0j6V/Zu/aRtPAtgnhHxc/leHovMksr+OEs1qzEu0bqgLMjMSQwBZWODlSCn2/aXdvf2kF3aTxXFrcIssU0Lh0kRhlWVhwQQQQR1r8i/Ls/+f3/yEa9J+HPxy8U/DDZBo/iDz9KXP/Esv4Xmtv4j8q5DR/M5Y7Cu443Z6VtCpbRmM4p6o/TGobq0gvoHguoIp4HxujlQMrYORkHjqK4P4SfE6f4taFZ6tY+GryG0mklimuY7y1lht3TPyt+8WUEjacGIH5wfukMfSWs7hGKmF8j0GR+lbc0XpczXNF3Rn2Wn2mmxGKztYLaJm3FIYwgJ6ZwO/A/KrNTC0uGIAhkyfVSK4/4jeL7r4daFqWs3Ph+8utPsbU3D3a3VrDArchY2MkofJO0fKjE7wFDN8tHNGOlwfNJ3erOqr5E/aJ/ac0y60a98IeCbqK+a+SS21HUgmYkiOUeKLIw5YZzIMqFI2kk5TyH4mftH+KfiP9os/wC2f7H0KXcv9n6ejr5iHeMSyfekyj7WHCNgHYDXj3l2f/P7/wCQjWU6t9ImkIJasr0VY8uz/wCf3/yEabPAsaxvHJ5kUgOGxjoeeKwNrpkNTPIWijXPQVDXbfDnRFudSfWr1WTStJU3DylSQXUZAGDkkfe4z0AI+YV1YKhLEVlSj1/Du/kZ1XaNzQ8eXH/CPeENC8LqZVumQXN0pf7uSTtOBhhvLY542Drwa8xrS1/WJfEGs3mpTDa9w+4LwdijhVyAM4AAzjnFZtdOPxCr1nKHwqyXotF/mZRVkFFFWLa28395JkRA4yOrH0H+Pb8geMZXorSxbjgWsZA7szZP1wRS/uP+fSL/AL6f/wCKp8ouYzKK0/3H/PpF/wB9P/8AFUfuP+fSL/vp/wD4qjlDmMyitP8Acf8APpF/30//AMVR+4/59Iv++n/+Ko5Q5jMorT/cf8+kX/fT/wDxVH7j/n0i/wC+n/8AiqOUOYzKK0/3H/PpF/30/wD8VR+4/wCfSL/vp/8A4qjlDmMyitP9x/z6Rf8AfT//ABVH7j/n0i/76f8A+Ko5Q5jMorT/AHH/AD6Rf99P/wDFUfuP+fSL/vp//iqOUOYzKK0/3H/PpF/30/8A8VR+4/59Iv8Avp//AIqjlDmMyitP9x/z6Rf99P8A/FUfuP8An0i/76f/AOKo5Q5jMorT/cf8+kX/AH0//wAVR+4/59Iv++n/APiqOUOYzKK0/wBx/wA+kX/fT/8AxVH7j/n0i/76f/4qjlDmMyitP9x/z6Rf99P/APFUfuP+fSL/AL6f/wCKo5Q5jMorT/cf8+kX/fT/APxVH7j/AJ9Iv++n/wDiqOUOYzKK0/3H/PpF/wB9P/8AFVWuLZVUyQ7jGPvKxyV/xHv+HpkaC5VoooqSjpvir/yP2r/9sv8A0UlFHxV/5H7V/wDtl/6KSiujMv8AfK3+KX5sUPhQ74Xf8lC0v6zf+inrl66r4XOx+IGljccZm4z/ANMnrlauX+5w/wAU/wAoC+0FFFFchRqW2uXsWiz6MsuLGaYXDKOCWAxjI6g/KcHPKgjHOadRxd6nhiM0qRjOWOOBnFTUnKbSk720NYKyJJm+z2Gw/fuCDj0UdD+JrOq1fzCa5bbjy4/kTBzwPeqtZMkKKKKQH0T+yN8av+Fa+Ol0TWtU+zeENcyk32iXbBaXOB5c5+U7c7RGxyowwZjiMY/S+vxHr9KP2Q/jjJ8TPCMnh3W7qafxVoEa+ZcXMyNJfW5YhJAOGJT5UckHkoxYs5AGNH0hXwP+218av7a1iD4faBqm/TNPy+sfZpcpNchvlgf5efK27iAxG58EBouPpj9pD4yRfBz4fT3lu27xDqm+z0uNXj3RylDm4KvnckfBPysCzIpwGyPyuvb251K8uLy8uJrm8uZGlmnmcvJK7HLMzHkkkkknkk0IGQUUUUCCtCybz7aW2/jB81Pcgcj8qz6ltp2tp45V6qc49R3FNAS1dj1y9tdGvNJjlxZXjpJIh55XnjsMnbkjk7RziobuIQzsqcxn5lPYg1Vl+6PrWtOcoSvF23X36MqWsSKiiiqMgrSHFpagcAoWPudzDP5AflWbWn/y62n/AFzP/obVUSZDKKtaZp1xq+pWen2cZku7yZIIkH8TsQqj8yK9t+Ivw8sbeTQprnSbnw7oun6kNAur6SxaH7TCoUpecgb2fExLc9F9qdyTwiivSrjwjY21v4gntbW7trVNGa5hM9xbXySMt1DGSk6JtxhznaFZTwTgkHU8L+EPDf8Abvg64t7a71azkv7BLycXcEkDNKV3RyQbC8QDkr8+4OFIGMgguB5DRXqOj+DNA8Q/29rEUFxbaXY3UVpHY3Gt2ltI8jiRi32iZEQKBGcIELHPXAJqd/AXhHSzbi8vtQ1FbzW5NLgm026g8sRCOBxIWCurMpnwVU4JHDLjkuB5PRWtJ4fum8Tv4ftR596b02MYAx5j79g/M17j4n+H0Np4h8GTjwxJp+nafr0GgT/abExJqMSshS4YMoEnmYm3HngKPSi4HzxRXonw+sbS4+Kxtp4bI2qNfkJdQCWBNkExUtGVYEKQDjaenQ1r6sug67pGotaz6bdavpujSz3l5pemrbW0zG7gWMLG8SbWCu2XREJyBkjdkuB5JRXqHi3wX4X0ibxTBpv9sO/hq+jhna5uIsXUTSFGC4j/AHbAgAMdwPJ2jpVzxR4c0LUfij4ksdN8OXw0+wln+0Rx6vbWcMREgUOJHgEcUfIUIc8kYbsS4HkdFeqat8P/AA94Zi8Q3mpvqN1bWR01rSGzu4MyLdQySFWmVXQ7dmA6AhsHA+YEYHwysbKTWL7U9VSA6VpVnJPO88PnLEz4hhfyukm2WWMlTwQDn0ouBxVFdh438L6ppRTVtRj02CO+mMduLBQkVyqohM8SqNvltvXkYG4kbRggd5pHhLR/FHgLwlaPb2tneW8cuqXl8karLLZrdSx3G5urlFEbKD0Aai4HidFes/E7RdKvYdT8RWVjFppWLRDFZWaLHAgurKSWT5QOu6Nec9znOeN7wp4b0vRtd1LQ54JbzTF8S6FE0U7KTIHE/DZUgrluRjkZHGc0XA8Ior0FtD03WdK8Sy6NbvZLFqNlbwxahdW7AFxcbiZ2jjCLlBwCo/vbsAjW8D6Wmj+H/GbXd34atb+znsY0vtQtotTt0D+cWVCkU6ktheVH8OCRii4HlFFe1WGm6B/Yd/qWsWSaobjQbi7D6ckFkisuqeVui/0fK5GMFlyqllwAQF5XTfBOm6jqHg2ISXiQ67Y3N3MPMUtGY5rlFCnb02wJnI6k9MgAuM8/orr/ABno2heH7fSbWxXUZNTubCzvriaeZPJTzoFkaNUCZPLAhi3A4wfvVyFAgooopgFSQ8+aDyDE+R64UkfqAfwqOpYOsn/XKT/0A0IDKooorM0Om+Kv/I/av/2y/wDRSUU74qOw8e6sAxA/dd/+mSUV05l/vlb/ABS/Nih8KD4Xf8lC0v6zf+inrl66j4Xf8lC0v6zf+inrl6qX+5w/xT/KAvtBRRRXIUSxfdP1q5C32e2muD1x5aeu4989sCqKybRjFaV1bLNFbxpdWwWJTndJzuPX8Kzad7mnMrWMiir39m/9Pdp/38/+tR/Zv/T3af8Afz/61Tysm5Roq9/Zv/T3af8Afz/61aNr4M1e+gS4tbWSeB87ZIo3ZWwcHBC46iqhSnN2irhdGBXYfC/4i6t8K/GumeJdJmmDW0ii5t45NgvLcsDJAxIIwwHUg7SAw5UEVP8AhAdf/wCgdcf9+ZP/AImsn+y2/wCfm1/7+f8A1qc6NSHxxaBNHofx8+Ml78aPHVxq267h0G2/c6XYXDqfs8WAGYheA7ldzfeI4XcwRa8tq/8A2W3/AD82v/fz/wCtWnF4H1ueJJYrKaSKRQyukTkMD0IO3kUoUZz0hFsLo52iuil8D63bxPLLZTRxRqWd3icKoHJJO3gVl/2b/wBPdp/38/8ArUTpThpKLQXRRoq9/Zv/AE92n/fz/wCtR/Zv/T3af9/P/rVPKwuSK32iwRv47c7Wz1Knpz+mKqv9w1fsrVbeVi91bGN0KNtk5wfSs+RtrOnBwSMqcg1STK5laxFRRRWhmFaf/Lraf9cz/wChtWZV+2lE8SQH/WpkJ/tA87frnJ98/QGoksv6NrF74f1O31LTpvIvrclopdqsUJBGQCCM88HseRzVjR/E2q6BFdRaddmCO7MZlXYrBijblPzA4IPp2JB4JBymUqSrAgjgg9qSqJOjv/HWvaik0U13EkE1sbNoLe1hhiERkWQhURQqkuikkAE45NK3j7xAbS3tVvliSCSKUSQ28UcrtGcxl5FUPJtPI3E4rm6KQHTJ4/12K/vL1JbJXvVUXEI062+zzbeVZofL8ssCSd23PJ55qnceLdYuvI828LfZ7xr+P92nyzMEBYcdMRINvQbeB1rFooA1bPxJqen69/bttc+Xq3mvOLjy1JEjZywBGAeSRxweRjAp+h+KdW8N+b/Zl35AlkhlcGNHBeKQSRthgcEMM/QkHgkHHooA0bDXtQ0zVX1S1uPLv3EoMuxTnzFZX4IxyrsOnGeKisdVu9NivorWby47+D7NcDaDvj3q+3kcfMinIwePrVOigDYvfFWr6jLrMtzd+Y+tSCW9PloPOYPvB4Hy/Nz8uK0j8RvETX0l69zaPcTQfZ52fT7dhcpuDfvVMeJWyqnc4Zsgc1ytFAG/rHjbXdfju49RvvPS7NuZR5SLu8hGSL7qjG1XYcdc85wKp6H4g1Hw3ePdabcCGWSNoZA0ayJLGeqOjgqynA4YEcCsyigDe13xnrXiW0t7TU7qOa2tXLwRJbxRrBkAFUCKNiHAOxcLnnGeazrvVry+stPsribfbaejx26bQPLVnLsMgZOWYnnPWqVFAHS23j/xBaSySJeRP5ltBaMk1rDLGY4ECRfI6FdyKAA2N3U5yTUdx468Q3V5e3kupSNd3t1BezTBFDNNDu8t8gcEbm6YznnNc9RQBt6n4t1XVo7+O4ktliv5IpbiO3tIYFkeMOEbEaKAf3j5I655zxVG31e8tdMvdMim22V68ck8e0He0e7Yc4yMb26HnPNUqKAN/TvGut6ULRbe6iMdpbPZxxTW0UsZheQyMjI6lXBdi3zA849BVrS/iN4k0a1S2sb6KKOMyeUfskLPEJM71RihZEbJyqkLyeK5aigC5qWq3erzQzXs3myQwRWyHaFxHGgRF4A6KoGepxzmqdFFMAooooAKlg6yf9cpP/QDUVOmf7IjqwIndSoU9UB6k/UZGPfPpkGZtFFFZlnTfFX/AJH7V/8Atl/6KSij4q/8j9q//bL/ANFJRXRmX++Vv8UvzYofCiT4XBf+FgaXyc5m7f8ATJ65Wuo+F3/JQtL+s3/op65erl/ucP8AFP8AKAvtBRRRXIUFFFFABRRRQAVNa3dxYzpcWs8sE6Z2yROVZcjBwRz0NQ0U02ndCOptfiP4os4Ehj1eVkXODKiSNyc8swJP4mt3/hdOv/8APppn/fuT/wCLrzmiu6nmeMpq0ar++/5kuEX0PRv+F06//wA+mmf9+5P/AIusi7+J/ii789f7S8qOXcNkUSLsB7K2Nwx2Oc+9chRTnmmMmrSqy++35ByR7Fm91C81KUS3t1Pcyqu0PPIXYDrjJ7cn86rUUVwuTk7tlBRRRUjCiiigAooooAKKKKALC310ihVuZgoGAA5wBS/2hd/8/U//AH8NVqKd2KxZ/tC7/wCfqf8A7+Gj+0Lv/n6n/wC/hqtRRdhYs/2hd/8AP1P/AN/DR/aF3/z9T/8Afw1WoouwsWf7Qu/+fqf/AL+Gj+0Lv/n6n/7+Gq1FF2Fiz/aF3/z9T/8Afw0f2hd/8/U//fw1WoouwsWf7Qu/+fqf/v4aP7Qu/wDn6n/7+Gq1FF2Fiz/aF3/z9T/9/DR/aF3/AM/U/wD38NVqKLsLFn+0Lv8A5+p/+/ho/tC7/wCfqf8A7+Gq1FF2Fiz/AGhd/wDP1P8A9/DR/aF3/wA/U/8A38NVqKLsLFn+0Lv/AJ+p/wDv4aP7Qu/+fqf/AL+Gq1FF2Fiz/aF3/wA/U/8A38NH9oXf/P1P/wB/DVaii7CxZ/tC7/5+p/8Av4aP7Qu/+fqf/v4arUUXYWLP9oXf/P1P/wB/DR/aF3/z9T/9/DVaii7CxZ/tC7/5+p/+/hqtRRRcAooopDOo+KgX/hPdWyTn912/6ZJRTfir/wAj9q//AGy/9FJRXTmX++Vv8UvzYofCjL8JayugeK9O1ByixRT4lZlLBY2yrnA5yFYke/rT/EmkNoOvahpxDBbeUhN7AsUPKEkcZKkH8e1YEn+sf6muvsNc0rW9LstI10vaTWalLfVkDSsqZyIpE6svJAIPy/Lxjdl0JRqUnQk7NO6vtd6NeV7LV6aa76D0dzmqK64fDfWrn59Maw1WAcNPY3aMit/dJYg5xg9O4pf+FX+K/wDoFf8AkxF/8VV/2di+lKT9E3+QuaPc5Ciuv/4Vf4r/AOgV/wCTEX/xVH/Cr/Ff/QK/8mIv/iqP7Oxf/PmX/gL/AMg549zkKK6//hV/iv8A6BX/AJMRf/FUf8Kv8V/9Ar/yYi/+Ko/s7F/8+Zf+Av8AyDnj3OQorr/+FX+K/wDoFf8AkxF/8VR/wq/xX/0Cv/JiL/4qj+zsX/z5l/4C/wDIOePc5Ciuv/4Vf4r/AOgV/wCTEX/xVH/Cr/Ff/QK/8mIv/iqP7Oxf/PmX/gL/AMg549zkKK6//hV/iv8A6BX/AJMRf/FUf8Kv8V/9Ar/yYi/+Ko/s7F/8+Zf+Av8AyDnj3OQorr/+FX+K/wDoFf8AkxF/8VR/wq/xX/0Cv/JiL/4qj+zsX/z5l/4C/wDIOePc5Ciuv/4Vf4r/AOgV/wCTEX/xVH/Cr/Ff/QK/8mIv/iqP7Oxf/PmX/gL/AMg549zkKK6//hV/iv8A6BX/AJMRf/FUf8Kv8V/9Ar/yYi/+Ko/s7F/8+Zf+Av8AyDnj3OQorr/+FX+K/wDoFf8AkxF/8VR/wq/xX/0Cv/JiL/4qj+zsX/z5l/4C/wDIOePc5Ciuv/4Vf4r/AOgV/wCTEX/xVH/Cr/Ff/QK/8mIv/iqP7Oxf/PmX/gL/AMg549zkKK6//hV/iv8A6BX/AJMRf/FUf8Kv8V/9Ar/yYi/+Ko/s7F/8+Zf+Av8AyDnj3OQorr/+FX+K/wDoFf8AkxF/8VR/wq/xX/0Cv/JiL/4qj+zsX/z5l/4C/wDIOePc5Ciuv/4Vf4r/AOgV/wCTEX/xVH/Cr/Ff/QK/8mIv/iqP7Oxf/PmX/gL/AMg549zkKK6//hV/iv8A6BX/AJMRf/FUf8Kv8V/9Ar/yYi/+Ko/s7F/8+Zf+Av8AyDnj3OQorr/+FX+K/wDoFf8AkxF/8VR/wq/xX/0Cv/JiL/4qj+zsX/z5l/4C/wDIOePc5Ciuv/4Vf4r/AOgV/wCTEX/xVH/Cr/Ff/QK/8mIv/iqP7Oxf/PmX/gL/AMg549zkKK6//hV/iv8A6BX/AJMRf/FUf8Kv8V/9Ar/yYi/+Ko/s7F/8+Zf+Av8AyDnj3OQorr/+FX+K/wDoFf8AkxF/8VR/wq/xX/0Cv/JiL/4qj+zsX/z5l/4C/wDIOePc5Ciuv/4Vf4r/AOgV/wCTEX/xVH/Cr/Ff/QK/8mIv/iqP7Oxf/PmX/gL/AMg549zkKK6//hV/iv8A6BX/AJMRf/FUf8Kv8V/9Ar/yYi/+Ko/s7F/8+Zf+Av8AyDnj3OQorr/+FX+K/wDoFf8AkxF/8VR/wq/xX/0Cv/JiL/4qj+zsX/z5l/4C/wDIOePc5Ciuv/4Vf4r/AOgV/wCTEX/xVH/Cr/Ff/QK/8mIv/iqP7Oxf/PmX/gL/AMg549zkKK6//hV/iv8A6BX/AJMRf/FUf8Kv8V/9Ar/yYi/+Ko/s7F/8+Zf+Av8AyDnj3OQorr/+FX+K/wDoFf8AkxF/8VR/wq/xX/0Cv/JiL/4qj+zsX/z5l/4C/wDIOePc5CtXw3pDa9r2n6cAxW4lAfYwDBBy5BPGQoJ/DvWyfhvrVt8+ptYaVAeFnvrtFRm/ugqSc4yenY1Wv9c0rRNLvdI0IvdzXihLjVnDRMyZyYo06qvABJPzfNxjbhxwsqMlPFLlS6PRvyS3172svwZe+xleMdZXX/E+p6ghRopZSImVSoaNQFQ4POSqgn39KKw6K4KtSVWcqkt22/vLSsrEkkjh2AZup703zH/vt+dFFQAeY/8Afb86cJH2MdzdR3+tFFADfMf++350eY/99vzoooAPMf8Avt+dOkkcOwDN1PeiigBvmP8A32/OjzH/AL7fnRRQA4SPsY7m6jv9ab5j/wB9vzoooAPMf++350eY/wDfb86KKAHSSOHYBm6nvTfMf++350UUAHmP/fb86cJH2MdzdR3+tFFADfMf++350eY/99vzoooAPMf++3506SRw7AM3U96KKAG+Y/8Afb86PMf++350UUAOEj7GO5uo7/Wm+Y/99vzoooAPMf8Avt+dHmP/AH2/OiigB0kjh2AZup703zH/AL7fnRRQAeY/99vzpwkfYx3N1Hf60UUAN8x/77fnR5j/AN9vzoooAPMf++3506SRw7AM3U96KKAG+Y/99vzo8x/77fnRRQA4SPsY7m6jv9ab5j/32/OiigA8x/77fnR5j/32/OiigB0kjh2AZup703zH/vt+dFFAB5j/AN9vzpwkfYx3N1Hf60UUAN8x/wC+350eY/8Afb86KKADzH/vt+dOkkcOwDN1PeiigBvmP/fb86PMf++350UUAOEj7GO5uo7/AFpvmP8A32/OiigA8x/77fnRRRQB/9k=",
	"ramah": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wAARCADmAbgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD4lkkcOwDN1Pem+Y/99vzok/1j/U16VPPF8L4Lazs7ZB42C77u9kxKtkrgERRqRtLFMbmwcbmAJz8u85tNRirt/wBfccNeu6bjCC5pS2W227b6JaXdnutHcxtO+F3jTVIGmg0S7RFbYRcMsDZwD92QqSOeuMflV0fB3xztP/EnbOR/y9w//F1y2oapfatMs2oXtzdzKuwSXErSMFyTjJJ4yT+dVKXJW/mX3P8AzMeTGvXngv8At1v8edfkdl/wp3x1/wBAdv8AwLh/+Lo/4U746/6A7f8AgXD/APF1xtFHJW/mX3P/AOSDkxv/AD8h/wCAP/5M7L/hTvjr/oDt/wCBcP8A8XTn+Dvjks2NHbGeP9Lh/wDi64uijkrfzL7n/wDJByY3/n5D/wAAf/yZ2X/CnfHX/QHb/wAC4f8A4uj/AIU746/6A7f+BcP/AMXXG0Uclb+Zfc//AJIOTG/8/If+AP8A+TO0Hwd8c7T/AMSds5H/AC9w/wDxdN/4U746/wCgO3/gXD/8XXG0Uclb+Zfc/wD5IOTG/wDPyH/gD/8Akzsv+FO+Ov8AoDt/4Fw//F0f8Kd8df8AQHb/AMC4f/i642ijkrfzL7n/APJByY3/AJ+Q/wDAH/8AJnaP8HfHJZsaO2M8f6XD/wDF03/hTvjr/oDt/wCBcP8A8XXG0Uclb+Zfc/8A5IOTG/8APyH/AIA//kzsv+FO+Ov+gO3/AIFw/wDxdOHwd8c7T/xJ2zkf8vcP/wAXXF0Uclb+Zfc//kg5Mb/z8h/4A/8A5M7L/hTvjr/oDt/4Fw//ABdH/CnfHX/QHb/wLh/+LrjaKOSt/Mvuf/yQcmN/5+Q/8Af/AMmdl/wp3x1/0B2/8C4f/i6c/wAHfHJZsaO2M8f6XD/8XXF0Uclb+Zfc/wD5IOTG/wDPyH/gD/8Akzsv+FO+Ov8AoDt/4Fw//F0f8Kd8df8AQHb/AMC4f/i642ijkrfzL7n/APJByY3/AJ+Q/wDAH/8AJnaD4O+Odp/4k7ZyP+XuH/4um/8ACnfHX/QHb/wLh/8Ai642ijkrfzL7n/8AJByY3/n5D/wB/wDyZ2X/AAp3x1/0B2/8C4f/AIuj/hTvjr/oDt/4Fw//ABdcbRRyVv5l9z/+SDkxv/PyH/gD/wDkztH+Dvjks2NHbGeP9Lh/+Lpv/CnfHX/QHb/wLh/+LrjaKOSt/Mvuf/yQcmN/5+Q/8Af/AMmdl/wp3x1/0B2/8C4f/i6cPg7452n/AIk7ZyP+XuH/AOLri6KOSt/Mvuf/AMkHJjf+fkP/AAB//JnZf8Kd8df9Adv/AALh/wDi6P8AhTvjr/oDt/4Fw/8AxdcbRRyVv5l9z/8Akg5Mb/z8h/4A/wD5M7L/AIU746/6A7f+BcP/AMXTn+Dvjks2NHbGeP8AS4f/AIuuLoo5K38y+5//ACQcmN/5+Q/8Af8A8mdl/wAKd8df9Adv/AuH/wCLo/4U746/6A7f+BcP/wAXXG0Uclb+Zfc//kg5Mb/z8h/4A/8A5M7QfB3xztP/ABJ2zkf8vcP/AMXTf+FO+Ov+gO3/AIFw/wDxdcbRRyVv5l9z/wDkg5Mb/wA/If8AgD/+TOy/4U746/6A7f8AgXD/APF0f8Kd8df9Adv/AALh/wDi642ijkrfzL7n/wDJByY3/n5D/wAAf/yZ2j/B3xyWbGjtjPH+lw//ABdN/wCFO+Ov+gO3/gXD/wDF1xtFHJW/mX3P/wCSDkxv/PyH/gD/APkzsv8AhTvjr/oDt/4Fw/8AxdOHwd8c7T/xJ2zkf8vcP/xdcXRRyVv5l9z/APkg5Mb/AM/If+AP/wCTOy/4U746/wCgO3/gXD/8XR/wp3x1/wBAdv8AwLh/+LrjaKOSt/Mvuf8A8kHJjf8An5D/AMAf/wAmdl/wp3x1/wBAdv8AwLh/+Lpz/B3xyWbGjtjPH+lw/wDxdcXRRyVv5l9z/wDkg5Mb/wA/If8AgD/+TOy/4U746/6A7f8AgXD/APF0f8Kd8df9Adv/AALh/wDi642ijkrfzL7n/wDJByY3/n5D/wAAf/yZ1GofC/xnpdsJZ9Du3VnCgW7LO3Qn7sZYgcdcY6VxvmP/AH2/OtXT9UvtJmabT725tJmXYZLeVo2K5BxkEcZA/Ku1gni+KEFzZ3lsh8bFd9pex4iW9VASYpFA2hgmdrYGdqgkY+ZSdSmrz1Xlpb89PmJ1q+HXNXtKPVpWt5tNvRdXfTt2818x/wC+350U2itT0Ds/hdp0WqfEbRIJmdUS4acFCAd0atIo5HTKDPtmsPVNQl1bU73UJlRZruZ53VAQoZmLHGc8ZNdT8HQv/CzdH5Ocz9v+mMlcXWcP40vRfmzghrjZ36Qj+Lnf8kfQHwY8SeFtM8MPBLd2lhqokJu3upFjM3J2FWY8qF4wOhzx82T6P/wmvhr/AKGLSP8AwNj/APiq+OKK5KuWQqTc3J6ni4vhelia8q7qNOTv3/ryPsf/AITXw1/0MWkf+Bsf/wAVR/wmvhr/AKGLSP8AwNj/APiq+OKKz/siH8zOb/U+j/z9f3I+x/8AhNfDX/QxaR/4Gx//ABVH/Ca+Gv8AoYtI/wDA2P8A+Kr44oo/siH8zD/U+j/z9f3I+x/+E18Nf9DFpH/gbH/8VR/wmvhr/oYtI/8AA2P/AOKr44oo/siH8zD/AFPo/wDP1/cj7H/4TXw1/wBDFpH/AIGx/wDxVH/Ca+Gv+hi0j/wNj/8Aiq+OKKP7Ih/Mw/1Po/8AP1/cj7H/AOE18Nf9DFpH/gbH/wDFUf8ACa+Gv+hi0j/wNj/+Kr44oo/siH8zD/U+j/z9f3I+x/8AhNfDX/QxaR/4Gx//ABVH/Ca+Gv8AoYtI/wDA2P8A+Kr44oo/siH8zD/U+j/z9f3I+x/+E18Nf9DFpH/gbH/8VR/wmvhr/oYtI/8AA2P/AOKr44oo/siH8zD/AFPo/wDP1/cj7H/4TXw1/wBDFpH/AIGx/wDxVH/Ca+Gv+hi0j/wNj/8Aiq+OKKP7Ih/Mw/1Po/8AP1/cj7H/AOE18Nf9DFpH/gbH/wDFUf8ACa+Gv+hi0j/wNj/+Kr44oo/siH8zD/U+j/z9f3I+x/8AhNfDX/QxaR/4Gx//ABVH/Ca+Gv8AoYtI/wDA2P8A+Kr44oo/siH8zD/U+j/z9f3I+x/+E18Nf9DFpH/gbH/8VR/wmvhr/oYtI/8AA2P/AOKr44oo/siH8zD/AFPo/wDP1/cj7H/4TXw1/wBDFpH/AIGx/wDxVH/Ca+Gv+hi0j/wNj/8Aiq+OKKP7Ih/Mw/1Po/8AP1/cj7H/AOE18Nf9DFpH/gbH/wDFUf8ACa+Gv+hi0j/wNj/+Kr44oo/siH8zD/U+j/z9f3I+x/8AhNfDX/QxaR/4Gx//ABVH/Ca+Gv8AoYtI/wDA2P8A+Kr44oo/siH8zD/U+j/z9f3I+x/+E18Nf9DFpH/gbH/8VR/wmvhr/oYtI/8AA2P/AOKr44oo/siH8zD/AFPo/wDP1/cj7H/4TXw1/wBDFpH/AIGx/wDxVH/Ca+Gv+hi0j/wNj/8Aiq+OKKP7Ih/Mw/1Po/8AP1/cj7H/AOE18Nf9DFpH/gbH/wDFUf8ACa+Gv+hi0j/wNj/+Kr44oo/siH8zD/U+j/z9f3I+x/8AhNfDX/QxaR/4Gx//ABVH/Ca+Gv8AoYtI/wDA2P8A+Kr44oo/siH8zD/U+j/z9f3I+x/+E18Nf9DFpH/gbH/8VR/wmvhr/oYtI/8AA2P/AOKr44oo/siH8zD/AFPo/wDP1/cj7H/4TXw1/wBDFpH/AIGx/wDxVH/Ca+Gv+hi0j/wNj/8Aiq+OKKP7Ih/Mw/1Po/8AP1/cj7H/AOE18Nf9DFpH/gbH/wDFUf8ACa+Gv+hi0j/wNj/+Kr44oo/siH8zD/U+j/z9f3I+x/8AhNfDX/QxaR/4Gx//ABVH/Ca+Gv8AoYtI/wDA2P8A+Kr44oo/siH8zD/U+j/z9f3I+x/+E18Nf9DFpH/gbH/8VR/wmvhr/oYtI/8AA2P/AOKr44oo/siH8zD/AFPo/wDP1/cj7H/4TXw1/wBDFpH/AIGx/wDxVH/Ca+Gv+hi0j/wNj/8Aiq+OKKP7Ih/Mw/1Po/8AP1/cj6Z+Jnirwje+DtQgmv7HUJnUi2itplldZsHY42n5QDyT6ZHOcH5x0vUJdJ1Oy1CFUaa0mSdFcEqWVgwzjHGRVSiu7DYWNCDgne57uW5XTwFGVFSck+50vxV06LS/iFr0ELOyPMJyXIJ3SKsjDgdMuce2KKu/GYL/AMLJ1vJOf3Hb/pjHRSw93Si32X5HRlsnLB0ZPdxj+SD4O/8AJTtH+s//AKJkrja7L4O/8lO0f6z/APomSuNqqf8AGl6L85Ew/wB9qf4IfnMKKKK6DuCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiitvSdJt3tP7R1HzTYmRoY4oHCyTOApb5iGCBQ6kkg5yAB94qm7ETmoK7MSiuu+3aX/0LOl/9/br/AOPUfbtL/wChZ0v/AL+3X/x6i8v5X+H+Zl7eX/Pt/wDkv+ZyNFdd9u0v/oWdL/7+3X/x6j7dpf8A0LOl/wDf26/+PUXl/K/w/wAw9vL/AJ9v/wAl/wAzkaK677dpf/Qs6X/39uv/AI9R9u0v/oWdL/7+3X/x6i8v5X+H+Ye3l/z7f/kv+ZyNFdd9u0v/AKFnS/8Av7df/HqPt2l/9Czpf/f26/8Aj1F5fyv8P8w9vL/n2/8AyX/M5Giuu+3aX/0LOl/9/br/AOPUfbtL/wChZ0v/AL+3X/x6i8v5X+H+Ye3l/wA+3/5L/mcjRXXfbtL/AOhZ0v8A7+3X/wAeo+3aX/0LOl/9/br/AOPUXl/K/wAP8w9vL/n2/wDyX/M5Giuu+3aX/wBCzpf/AH9uv/j1H27S/wDoWdL/AO/t1/8AHqLy/lf4f5h7eX/Pt/8Akv8AmcjRXWf2dYeIJEtrKxWw1ORgkCwyu0EzZ4QhyzKzE4DbtvCgqAS45OhO+jLp1FO6tZro/wDgBRWzpWlQPa/2hqHmmyMjQxxQOFkmcAFvmIIUKGUkkHOQAOpXT+2aZ/0Lmm/9/bn/AOPVMqii7GM8WoytGLl6W/Vr+vM5Oius+2aZ/wBC5pv/AH9uf/j1H2zTP+hc03/v7c//AB6p9tEj65/07l/5L/8AJHJ0V1n2zTP+hc03/v7c/wDx6j7Zpn/Quab/AN/bn/49R7aIfXP+ncv/ACX/AOSOTorrPtmmf9C5pv8A39uf/j1H2zTP+hc03/v7c/8Ax6j20Q+uf9O5f+S//JHJ0V1n2zTP+hc03/v7c/8Ax6j7Zpn/AELmm/8Af25/+PUe2iH1z/p3L/yX/wCSOTorrPtmmf8AQuab/wB/bn/49VLUdLtbq1nvtOjeH7OA9zbO+4KpYKHRiM7dzBdpywyDlssVcasW7FQxabSlFq/e36NmBRRRWh2HYfGf/kpWt/8AbD/0RHRR8Z/+Sla3/wBsP/REdFcuH/gw9F+RxZZ/uVH/AAR/JDvg7/yU7R/rP/6Jkrja7T4Oux+JujjccZn4z/0xkri6qH8aXovzkKH++1P8EPzmFFFFdB3BRRRQAUVJBBLczRwwxvLNKwRI0UszMTgAAdSTXqcHwx0nwjZwan441Ly/M5i02z+aSUgBtpb81OMAEr84zWVStGnZPd7LqzkxONpYaym7yeyWrfov6R5tpGjahr14tnptnNdXLY+SJc7RkDJPRVyRknAGea9Bsvgjq6W6Xmualp2j2Qz5zTS73i5wucYQ5OP4+/rxTr74sXFhCun+EdPt9E06NgVKxrJNLgbdzZBGSoXPVsr941xF7c6jq8yz6heXFzKqhBJcStIwXJOASTxyePes7YiptaK+9/5fmcn/AAoYh3VqUf8AwKX/AMivxO+HhD4aad/o2o+Lry4vI/vy2aZibPI24jcdCAfmPOenQL/bHwn/AOhY1b/v63/x+vPBZrjliT7U8W0ePu/rVfU2/inL77fkH9muWtSvNv8AxW/CKX/APQP7Y+E//Qsat/39b/4/SHw78LtT5tvEGo2Fxdf6uKZCY7dm6KxKY2qTg5foPvd64D7NF/d/U0w2i44Zgfej6m18M5fff8w/sy2sK9RP/Ff80zvJ/gleXkMlz4e13S9Yto1ILI+xjIBnYMFlzjb1YdecDmuC13wzq3hm5Fvq1hNayN90uMo/AJ2sMq2NwzgnGeafbNeabcpc2VxLBcJnbLC5R1yMHBHTgkfjXZ6V8WtYt4TZa7b2+uaYyqrW94i7sKOPmwcnO0ksGJ29jzUuOIp9VJfc/wDL8gtmFB3UlVj2+GXyfw/fY80or1tfAPhjx6ss3gzUHsb6Nd8mmX+cKuQuQ3JA4JOC/LKPlzXl+p6Zd6Nfz2F/A9vd27bZI36g/wBQRyCOCCCK0p141G4rRro9zqw2OpYhuEbqS3i1Zr5fqrrzKlFFFanYFFFFABXXX3/IE8M/9eL/APpVPXI1114RJoPhx0O5EtZImYcgOLiVip9wrocdcMp7ik/ij6/oznr/ABU/X/21lfTLP+0dSs7Pf5f2mZIt+M7dzAZx36110/w+ik1XUtH0/VWuNVsVLmCa28oTAAEhGDtzyOCBXKaRdpp+rWF3KGMdvPHKwXqQrAnHvxXcP450ix8R6p4i0+K+m1G6QrDHcRpHHCSANxIZi3T2rKu6yl+77fjfqefjZ4pVLUL/AAu2itzXVr9la/Vfec9B4Whg0K11jVb9rS2vJClukUHmyPjgsRuUAD659q1bX4bSy6+2mz6gqW7WRvobqKLeJY+MYUkYPPrVP/hI9P1Xw3p+j6st3E+nSM0NxbIsm5GOSrKzLz75/Ctyz+I1iviJbqa1uYtMg046fbxxhXkA4wzZIHb19KznLEa8u+vb5WOetUzBKXJe/vdFbf3bd21ve/XbQ5q58KrJoT61pd415ZwyiGZJIfKliY4xldzAg5AyD3rRfwFDbata6Ld6usOtXCKRCIC0SMwyqNJuzk+ykc1XbxNZaX4an0XSFuXa7mWae6uUVD8pBVVQFscgHJPrWnP4y0XUPEdn4ku7a+XUYAjPaxBTFJIgwrby2VHA42npTcq+tr21ttfpa/4/gVOeO1te3vWdld6LluraK9+i6XsZtp4EuDYaje30k8UdhdG0eO1t/Pk3gZJxuUBRkc570zSPCdlqseuXK6rKtlpUaSmRbXLyAg5G0uMEYx1qzpnjNob++1JtT1Owvbu5aZ0tIklhZTjAKsw5HIzzxiteP4jWEmp+J7ry72wOqxRxwy2qq0kZUEFz8y8nOeDSlLEK/wAvzV+nr39CKlTMFzJLtt01jdap30vqm/TYxLj4f3R1fRrCxuVuBq0AuInkTyyiYyd65OMD0JqMeDre+h1U6TqhvLjTFMk0T2/lh0H3mQ7jux7gVrT/ABFig1nQNQtYJ7mXTYWhnuLrCy3QYY5wTjHOOT1qlaeJ9H0GPWpdIjvZLvU4mgX7SiotujHJ5DEuemOB0oUsRZX3+Xfr8vQcamYcquneytotXzO9+3u2fTr10IrfwppFx4dutcXV74WltMsDobBN5Y46DzsY59a5VLc3F2sFrvlMkmyLK7WfJwOMnBPpk10Fn4itbfwPqOhtHMbu5ulnRwBsCgL1Oc549KreD9VsND1+21HUIpporbLpHEASZMfLnJGADz+AraLqRU3LW22x2U5YinGrKd5NN8q01VlbZLqafjTwE/hG3tZ1v0vYpXaKRkj2iKQAHaeTnjPp0rO8X+Gv+EV1VLH7V9p3QpLv8vZ97PGMn0rYm8c22raDrWnajYLFJeS/a4ZLXe2J88lvMc4BGB8vTnis7x14itfE+tJe2kcyRLAkWJgA2VznoTxzUUXX5lGp53212t+phg543nhCv05ruy1+Frb1a07anM0eNf8AkcvEX/YQuP8A0Y1PhhkuJY4YY3klkYKiIMsxPAAA6mofF08Vz4r12aGRJYZb6d0kRgyspkYggjqCK2n8a9H+h6X/AC/j6P8ANGnef8gbw5/15P8A+lM9UoYZLmaOGFGklkYIiKMliTgAVcuSH0Pw+6nciWskTMOQHFxKxU++10OPRge4p/h/VP7D13TdSMfmCzuEmKf3grA4rkn8TOBNqM3FXd5fmzvrj4DeKINJN4Gs5LhV3mzSQmT6A42k+2fxrznTtPuNU1C2sLZN1zcyLFGp4yxOB9K+qLj4yeEYdKN8mpCV9mVtVRhKW/u4xx9envXzFY69Pp/iOHW4kTz4rn7SE/hzu3bfp2qEeRlWLx1eNT6xCzW11bXXQ6tPhrBda3d+H7PXFn1+2RmMBtisMjqMsiybskjnqoHFQp8NLmbwF/wlEF3vlQuZLExYZURyrMGzzjgkYGAfatO38eeH9N8V3viyztdQbVJ1do7OVUEMUrjDMZA2WHJ42jr1qHTviXHpmh+HLaOGeS70+6nlvFdV8qeKUtuQc85Ddx1o1Kc8faPJ/dvdLs+Zel7K/nuxV+FG7xM2i/2v93TP7R877N9Pk27/AH65/Cuc8E+Ev+Ex1O6svtn2XyLWS53+Xv3bcfLjI65613T/ABR0I+Op9ZS11BNOfSjp6p5aGRWz1xvxjHvmud8G+JNA8G6xcXkc+p3kVxZTW7BrOOJlZiu0j962Rwc9McdewOFXG+ylzJ83KraLfW/S3bf5EUXw3uLrwAviq2vRK4Ls9l5WGWNHKs4bdzjgnjoa0YvhQr+KTojawVUaaNRM4tcnHHybd/v1z+FRaT8R4NG8PeGbG3gne40y5me6R1Xyp4ZCdyDnJyD3HWt3/hamhr48l1yK31GKwOl/YUVY081GyMHG/GAB65o1IqVMwTmorT3raLv7q+7Vd767HlmpRaZEY/7Ou7u4BzvNzarDt9MbZHz39Kl0L/j6uv8ArwvP/SaSrPiTU11N7dxreraqyAgtqUe0xjjAX96+c856dO9VtEISa9lY7Y0sLvc54C7oHRcntlmVR6lgOpqo7o9OTbw7vvZ/1svyOQooortPcOw+M/8AyUrW/wDth/6Ijop3xmdh8SdbAYgfuO//AExjorlw/wDBh6L8jiyz/cqP+GP5IPg7/wAlO0f6z/8AomSuNrsvg7/yU7R/rP8A+iZK42qp/wAaXovzkKH++1P8EPzmFFFFdB3BWr4c8Oah4q1WHTdNh8yeTlmPCRr3dj2UZ/kBkkCqumaZd6zfwWFhA9xd3DbY406k/wBABySeAASa9Z8Q6rF8LdEj8L6IETXLqFJNS1CNwzKxH3VPBB64yBtUgj5mLDCtVcWoQ1k/w82efjMXOm40KCvUlt2S/mfkvxegXesaF8KIb/S/Dpe/8TSKsU+oyqpSA4+ZVHqCM7eRkjczbdtea3t1ea3fT39/O81zO255H6sfb0GOABwBgCoILcEB26dhVl5FjGWP4etaUcPGn7z1b3f9fkVhcFDDtyvzTe8nu/8AJeWwJGsYwo/+vQ8iR/eYCqUl078D5R7dagrR1Utj0FS7l43kYOPmPuBTPtv/AEz/AFqpRUOrIr2cS39t/wCmf608XiHGQwqjRR7SQeziaaSo/wB1gT6U5lDjDAEVlVLHcPHxnK+hq1V7kul2LASW0ljntpHSWNg6OhIZGHIII7g16Tp/jXSPHlhBonjjetyJs22rQhIzHnqHOMKOAucFSCCQCu6vO4pllGQee4qOe3DZdeD3HrUVqEKqT6rZ9UcGKwdPEW59JLaS3Xo/zWzL3jTwXqHgnVTZ3g8yCTLW9yowky+vswyMr29wQTzdet+A/Elr4mso/BHiZfPsZ/lsblnCyWzgHaoY/kvXrtwVOB5z4j8Oah4V1WbTdSh8uePlWHKSL2dT3U4/mDggisaVSXM6VT4l+K7/AOZlg8VU53hsT/EjrfpJd1+q6PyMqiiiug9IK1tK1lbONrW8ge60923+UsnlvG+B8yOQ20nAB4IYAZGQpXJooavuROCmrSOq87w1/wBBLV//AAXR/wDx+jzvDX/QS1f/AMF0f/x+uVoqbS/mf4f5GXsZf8/H/wCS/wCR1XneGv8AoJav/wCC6P8A+P0ed4a/6CWr/wDguj/+P1ytFFpfzP8AD/IPYy/5+P8A8l/yOq87w1/0EtX/APBdH/8AH6PO8Nf9BLV//BdH/wDH65Wii0v5n+H+Qexl/wA/H/5L/kdV53hr/oJav/4Lo/8A4/R53hr/AKCWr/8Aguj/APj9crRRaX8z/D/IPYy/5+P/AMl/yOq87w1/0EtX/wDBdH/8fo87w1/0EtX/APBdH/8AH65Wii0v5n+H+Qexl/z8f/kv+R1XneGv+glq/wD4Lo//AI/R53hr/oJav/4Lo/8A4/XK0UWl/M/w/wAg9jL/AJ+P/wAl/wAjqvO8Nf8AQS1f/wAF0f8A8fo87w1/0EtX/wDBdH/8frlaKLS/mf4f5B7GX/Px/wDkv+R002t6fpqk6P8Aa5b0/dvLlFiMP+5Gpb5x2ctxk4UMAw5miimlY0hTUPN9zU0vV1s42truFrmwZt/lLJsdHx95GIO0nAB4IIAyMhSup5/h3/oIar/4L4//AI/XL0VMqcZasyqYWMpcybXpb9UzqPP8O/8AQQ1X/wAF8f8A8fo8/wAO/wDQQ1X/AMF8f/x+uXopeyiR9T/vv8P8jqPP8O/9BDVf/BfH/wDH6PP8O/8AQQ1X/wAF8f8A8frl6KPZRD6n/ff4f5HUef4d/wCghqv/AIL4/wD4/R5/h3/oIar/AOC+P/4/XL0UeyiH1P8Avv8AD/I6jz/Dv/QQ1X/wXx//AB+jz/Dv/QQ1X/wXx/8Ax+uXoo9lEPqf99/h/kdR5/h3/oIar/4L4/8A4/VDUtYhaB7PTY5YrV8edJKwMlxg8Zxwq5AbYCeerNhcY1FNU4p3KhhYxalJt272/RL8QoooqzqOw+M//JStb/7Yf+iI6KPjP/yUrW/+2H/oiOiuXD/wYei/I4ss/wByo/4I/kiT4Ohf+Fm6Pyc5n7f9MZK4uuy+Dv8AyU7R/rP/AOiZK42qh/Gl6L85Ch/vtT/BD85hRRXQeCvDMvi7xJZaYgcQu2+4kXP7uIcsc4ODjgZGNxA71vOShFylsjqq1Y0YSqTdkldnfeELey+Hng3/AIS29gik8QX+5dMgnLDCcDeFxkcEsT0KlQCN/Pmy+ZeTyXFw7yySMXZ5GJZ2JySSevNdV8SfEUfiPxKbexKLpOnL9ktEiwIwq8MygErgkcEYyqr6VzqqEUKOgrPC03Z1Z7y/Dsjz8voyUXiavx1NX5LpH5L8biSOI0LH/wDXWa7tIxZjzU94+XCA8Dr9arVdSV3Y9inGyuFFFFZmgUUUUAFFFFABRRRQAqsVIIOCK0YZRKmeN3cVm1NavslAzw3FaU5WdjOcbomuYf41H1r0/Fv8U/A8u9EbxhocP7sqzGW6hXHJGCXJ5GOfnwcqHwfOiMjB6Ve8I+IZfB/iaz1FC5gRts6L/wAtIm4YYyMnuMnG4A9qnFUnKPND4lqv8vmeVj8PKrTVSl/EhrH/AC9Hszk6K7b4oeGI/D3iR5rII2kamv2u0kiwY9rcsqkALgE8AZwrJ61xNOnNVIqa6nVhq8cRSjWhs1/X3BRRXuHwC/Z6i+Num+J7+fxR/YUGgCJpD9gN15iushJ4kQjAj985q27as3PD6K+htS/ZjsNT+HOs+OPh/wDECz8WaZoyyPeRHTpLKVFRQ74V2JyFO7BAyM4JPFfPNJNPYAooopgFFFFABRRXseh/Aj+2fgLrnxT/ALf8r+yrg2/9mfY93m/PGufN8wY/1ucbT096G7AeOUUUUAFFe96D+zfZr8M9L8e+N/Hdl4V0jWJBHYqbCW8eQtuK7ghG3IRjxnjrjpXjnirRbfw7r97ptpq9lrFrAy+Xf2RJhnUqGBGQCDzgg9CCO1JNMDHoor3j9nr9mi7+O9prd82u/wBiWGmSRwrMbP7R58jAllA8xMbRtJ5P3xTbSV2B4PRXc/EL4aXfw8+JuoeCb2582S1ukhS78raJY32lJNuTjKsDjJwcjNdD+0D8Ev8AhRfinTdD/t3+2fttkLzz/sn2fZmR027d75+5nOe/SldBY8looopgFFFevfs+/A3/AIXt4i1XSP7e/sb7BafavN+yfaN/zqu3G9MfeznJobtqwPIaKluYfs9zNDu3eW5TOMZwcVFQAUUUUAFFFFABRRRQAUUUUAdl8Zgv/CydbyTn9x2/6Yx0U34z/wDJStb/AO2H/oiOiuXD/wAGHovyOLLP9yo/4Y/kh3wd/wCSnaP9Z/8A0TJXG12Xwd/5Kdo/1n/9EyVxtVT/AI0vRfnIUP8Afan+CH5zCvXvhk6eGvAPivxSrf6YMWcDLErPE2FwcnqC0qEj/Y79K8hr1rxoP7G+FfgnSP8AW/a9195v3duQW2Y5z/r8Zz/D054nFLn5aX8z/Bav8jnzVe1VLDfzyV/Re8/y/rY84tEyWcjpwKt1HAu2JenPNSV6C2PTZBJBG8mWYhm7Un2OP1b86jvW+ZF7gZrqvhbqnh2w8feHrjxisr+HILtJLry4ll4HK70IO+PcF3gAkpuABOKxlKKbujWMZNKzPoX4I/sg6X448FweJPFuo6tZ/wBpfvLK1stsTrCCQHkMkbZ38Mu0Y24OTuwvpX/DDHw7/wCgz4p/8Crf/wCMV9HaPq1nr+kWGradN52n6hBHc28u0rvjdQythgCMgg4IBq7XiTxFRybvY9aNCCSVrnzJ/wAMMfDv/oM+Kf8AwKt//jFH/DDHw7/6DPin/wACrf8A+MV9N0VPt6ncr2MOx8yf8MMfDv8A6DPin/wKt/8A4xR/wwx8O/8AoM+Kf/Aq3/8AjFfTdFHt6ncPYw7HjXw9/Zc+HXgH+0c6b/b/ANt8v/kYILe78jZu/wBX+6G3du59dq+ldhd/Cr4a2VpPcy+APDTRwRtIwh0KGVyAMnaixlmPHAUEnoATXbLgMM9Kk3J7flXTSrScdZL5nLWpRUtE/kfmV+0fqngDxJ440+7+HsNjDoqabHFKthYGzjM4llLEoUXJ2lPmx0wM8V4+ttGsi4Ztw5xX1D+078RvhH4w8I258CHS5PE0urLc3dxb6Q9tPJEY5d7NK0S7suyEgkknntmvli0b99zklga9OLjorHC1Kzdy9Ve7TKBscj+VWKa670ZeOR3rdmSPQ9VdPFPwStryVv8ATPD9wsHmNEuWXIQIpHQbZI8nuY+R3ryCvW/g2P7THinw9/q/7U08/wCkdfLxlPu9/wDXZ6j7vvx5JXn4dck50+zv9/8AwbnmZcvZVq+GWylzL0kr/ncK+2/2EPs//CI/FX7V5v2XyrbzfKxv2eXcZ254zjOM18SV6h8Kfjv4j+D+leI9N0Oy0q4g19ES5a+ikdkCq6jZskUDiQ9QegromrqyPWWjPqLw5aaF/wAMr+OR8EHvrhbhphq0WvFTfLGYgJVUR4Td5XK4yCC3O7iuO+Bdh488E/BceLZvirZ+BfAt1ePJCraLHqMsshbyi20ruGTHgAE8KTgda8L+Dvx18T/BK61Wbw/Dp11DqkaR3FtqMbyREqSVYBHU7huYdcYY8dK2PC37S/irwt4WvfCyaR4b1Lw3PPJPDpmqWBuILMu5fbEpf7oY5Afdg1PK9h3Pc/2v9D0XVfg54B8cwT2upaxd3EVu+tQWBsjqEUkEj72iPIyYwQD03HHBrsvjb8R9T+HHhD4F3eiwWQ1G6hij+1XFskzxw+Vb+ZGm4HbvyuWGGwvBGTXyf8Rf2iPFvxR8D6T4T1+DSjZ6ZcLdR3NvA8c8jqjoA3zlAuJDwqqBgYwBiq3xA+PPiP4j6X4P0/VbLSYYfCihLNrSKRWkAWNf3m6Rs8RL029T+AoPS4XPs74l+Kz8Of2lPAeh+GtK0qwj8WSRPrU6WcZlvQ8hiClyMqFCk/LjJPOa8w1v4a+IpP2ydctPhle2Xhu8trRdRku2t0kitkkhRZSsTKVYs0vTHVieMV4d4x/aO8U+N/iN4Z8dahYaNFq/h3y/s0NvDKsD7JDIN6mQseWPRhxSyftKeNh8V5/iTaf2dZa7cwLazwQQt9mliVVGxkZ2bB2KfvZyMjFCg0F0fa/gFdO+K1l428JeKPiLYfEY2kPkzp/wjgsTp8h3ruSUDa5ypwV5BTINeS/CDXB4b/Yn8X6r9itb2S11GR44buMSReZ5luEZkPDBWIbB4O3BBHFeVaR+2T440LVtSv8ATtC8I2keorma0ttNaGFpCctMdkgZ5D0LOze2MnPA6V8bvEGj/CPVfhlBZ6W2g6nN58s8kUhuVbcjYVg4UDMa9VPU0uRhc+i/idqcnxR/Yz0Txr4jgtZ/E1pehFvYrdImwLl4cYUAAFMZA4yAcdK+PfDukHX/ABBpOkiZYDqF3Fa+a3RN7hdx9hnNdxJ8cPEMnwei+Fps9L/4R+KbzxcCKT7Vu80y/e37cbjj7vT8681VmRgykqynIIOCDVxVriZ+k/iO5+HWh32l/s36/p91BoV5pUbafqt1Pub7U0j7cMR8rbgSrfd3HZtxgV8//GD4C+GPgd8FXGupbX3j/UtWeLT72G4lUi1Vgd3lbtn3F5yDgygZ4Fcnb/tc+N2sdNh1jSPCviC+0wD7JqesaX593CR0ZXDABuB82MnGSSaxviL+0n4p+K3hSHQfFeleH7+S3kMsGpi1eO7gYnJ2ssgQDHykbCCAM5IBqVGSY7o8cr9GNH+HPjnwR+y54a0PwFpLXPi7Ubq21S8xPFA0JLickmRlGQI4oiAc4zX532F0LG+tbowQ3AglWQwTgmOTaQdrAEEqcYOCOO9d/wDGH41+I/jbrGn6l4hh0+2awtzbwwafG6RAFixbDux3HIB5xhRxVSTdhI+oP21PA0reIPh949Wza3kupYdNv4yQTHIG8yMErkE4Mqkj+4K9/wDiR4N0s+Lbv4gWmlJ4k8ceHdFUaXobSKu0+ZKRNjqWJLBf9w4+YjH53Wfx+8SWvwqtvhxJYaRdaHa3C3NvPcRSG5hYTecNrCQLjdkfd6MRWxrv7VHjzW/iPo/jxBpmn6xplqLIQ2UUi29xDvZykqNIxYEsc4I6AjBANRyPYq6O8/Zp8b+IPiF+1RZa54mu5LjVJre7VlcFVhURNiNF/hVemPrnkk1m/Gb4j+MPF3xV8S/DDw/9hsdHv/EP2VLGG0iX7RdfaBiWSYqXLGUbid2AOMYGK4mH9ovXrT4rp8SrLw94as9f8qSOaK3t5lt7hnUq0jp52d+D1BGSMkE5J4LWfHGrax46vPGgeOz1y41A6mHtAVWGcvvBQMSQA3TJPSq5dbiufoX4c1TxNofxI0bwb4++M+na7q9+m6XwwvhZCk6lGOPtCKAnALZYDgcjmsH4HeGNN8HftZ/FnR9Ito7XTobCKWKCMYSPzPIkKqOwBc4A6DivnGf9sXx5caxpmtNpPhUazZAI9+umYuLqMZ/dySb9wQk5KoUB+mRWXon7U3jHQfib4j+IFtpugvrOvwR29zDLBMbdFRUUFFEoYHEa9WPU1PIx3R9Dfs5eMLn4yax4++HXirQtMbwhbQO1tYRWSRCxxLs2BgMlsHO9iW3JnNfCmpWyWWo3dtFKJY4ZXjWQdHAJAP44r2cftW+PIPDep6RZQaDYXWqqVvdYstPEN/c5BBLyA4ZsEjeV3c5znmvDquKabJYUUUVQBRRRQAUUUUAFFFFAHYfGf/kpWt/9sP8A0RHRR8Z/+Sla3/2w/wDREdFcuH/gw9F+RxZZ/uVH/BH8kSfB12PxN0cbjjM/Gf8ApjJXF12Xwd/5Kdo/1n/9EyVxtVD+NL0X5yFD/fan+CH5zCvW/jePsOr6JpEHyadY6evkRddmWZTyeTxGg5J6e5rySvXPj1/yOFl/2D0/9GSUqn8en/29+hhitcfh15T/ACj/AJs4BRtUAdAMVUvW+ZV9BmrlULtszEegxXZV+E9Wn8RBRRRXMdB+otv4u/4VH+zvoWu6rpl08+jaFYRyWBHlS+cY4ohG277mHYBsglQDwSMHyjw58OfjJ8YbC38Xa78TrrwvbanAlxYWGjmTasDlnXckckaj5WUqS0jlSAxBXFfU17qNrp0Ye6nSJT0B6n6DqetVrXxDpl5MIobtDIegYFc9sDIGT7V46qNJtLU9dYapOPMk3Fep83+G/FvxE+BnxC8O+DPHmqf8JT4a8TTm00rUg+65hkM20Fy/znmWPcrFgoZdjnYVP1HRRUzlza2IjHl0uFfM37T/AMVr7QNd8NeCdP1y68O2+pGO61TWLeNmkt7dpdimMowfjZIzKoBYKoDYLA/TNfO37TvwL1P4lx6br/hqGKbXrBPsstq8mw3MBbK7WZgilGZzg43BzzlVU6YdxVRc+xNZScHynmvx48IeEvgOvg7Xfhf4surDXru3j3W9vdmf7fa/fF2zA7djOqgoR5cn8KgI2fqT4WeNf+FifD7QfErQ+TNfQHzowu1RMjGOTaNzfJvRtuSTtxnmvzr0b4PeNdY1ZNObw9f6e5K+ZNqVu9vHEpIBZiwycbs4UFiAcA1+ifwy0TR/CXg3SPDWkXSTx6bBsd8MrSyE7pJNrEkBnZmxkgbsDgV04zl5VZ3ZGGoVknNxfL3tofkveWdxp13cWd5by293byNFNBMhR43U4ZWU8ggggg9KhrtPjB/yVrx7/wBh6/8A/Sh64uuxO6ucDVnYntGxMB6jFX6zYG2zIffFaVdNJ6GFVanV/B66mtPiDZQwvtjuUmhlGAdyhC4Ht8yKePSuL8UWcGneJdZs7ZPLtra8mijTJO1VcgDJ5PA7113wm/5KRpP1n/8ARL1zHjX/AJHLxF/2ELj/ANGNXJtiX/hX5s8mGmZzS6wj/wClSMOiituDwte3Hha48RRvAbO3uPs8ke4+aOF+fGMbcugznOWHFdR6hiUV0eq+CNX0ufSbbyftd3qdsLqK3tFaSRQSQVZcfeBU5AzismPR9Rm1A6dHYXT6gCVNqsLGXI6jZjOfwoApUVoQaDqt1eT2cGmXst5ACZYEgdpIwOu5QMj8avXvhiW38Vx+H4Z0knkmigSWRSi7n24yBkgAt70AYNFdOnhK3fW9N0qPxBp9zNeXkdm4tYpy0O5gpYiSNAQCegP+NY6aLqE8ka21ldTiaVoYjHCzea69VXA5IBBwPWgLlCitSLwzrc91NaxaPqEl1AwSSFLZy6MQSAVxkEgE8+hqOz0HVdQmlhtNMvbiaFxHIkMDOyNz8pAHB+VuP9k+lAGfRV1tH1FdOXUWsLoaezbRdGFvKJ9N+MZ/GrP/AAjWqRTww3djdWZnieaM3FtIPMVELEgBSSMDqBgdSQMkAGTRRWtoGgvr0t4ovLWzis7c3Ms1zv2qgZV6IrMTlh2oAyaK6CXwffLrunaTHLbTvqQje2uI3PlOjnAfJAIAwc5AIweKs2PgHVNQ1/VNEiktftmnxPMSXbZOAVCiM45L7125xnI6UWC5y1FbY8LXv/CKt4jLwLZC5FqIyx81iQSGAxjb8rDOeoNGo+Fb/TNA0zWpjCbXUCwRFYmSPBON4xxuwSvJyAaAuYlFb8vhG9h1vVNJaW3NzpsU00rBm2MI0LNtOM5wOMgfhWBQAUUUUhhRRRQAUUUUAFFFFABRRRQAUUUUAdl8ZnYfEnWwGIH7jv8A9MY6Kb8Z/wDkpWt/9sP/AERHRXLh/wCDD0X5HFln+5Uf8MfyQ74O/wDJTtH+s/8A6Jkrja7T4Ohf+Fm6Pyc5n7f9MZK4uqh/Gl6L85Ch/vtT/BD85hXrfxfP9pWXg/X5flvNS08eaicRrgK/yjr1lbqTwB+Pkles3J/4SL4JWNz9+40G8MMks/L7CcBUPJ24liGDgfJ7ClX92pTn52+9f52MMf8Au8Rh63aTj/4ErfmkcEhJRSepArPnbdM5Prirdq2Ysd1NUWbcxY9Sc11VXoj16a1YlFFdP8N9Ws9A+InhHVtRm8nT9P1a0ubiXaW2RpMjM2FBJwATgAmuduyNlufpv4x0+7XUZLtkd7VlUK4yQmABg+nPP4/WuftbSe9mEVvE8sh7KOnbJ9Bz1r1qzvLfUbS3vLO4iuLS4jWWGeFw6SIwyrKw4IIIII61NXi81j6yjm0qdJQ5b2IbOOSG0t45n3ypGqu2c7mA5OTU1Q3dv9rtJ7fzZYfOjZPMhba6ZGMqexHUGvmrXtQ8XeG9Sl0/UNY1RJk5DC7kKyL2ZTnkH/EHBBFQ3YywWBeNlJKaTXQ+m6K+W9P17xVqt7DZWWr6tPdTttSNbuTJP/fXA7kngDmvpHw9p9xpWi2Vpd3Ut3dxx/vZpZDIWc8t8x5IBJAz2AoTuPH5c8GlzTTb6fqec6np93YXTrdo+9mJ8w5Ik9SD36/rzV3w1p93c6nbTQI6xRSBnl5CgDGRn1IOMe/pXplFXzGss3lKnycuv9dD8lfjB/yVrx7/ANh6/wD/AEoeuLr1T9pHxFpfiv41+K9V0W9ivtNlkgjjuYTlJDHBHGxU/wAQ3IwDDg4yCQQa8rr2YfCj5OfxMVW2sGHUHNatZNaEkn+j7jjLL/Ouik9zCqtjuvgjYx3vjjz5GcPZ20k6bSMFiQnPtiQ/jivONU1CXVtTvdQmVFmu5nndUBChmYscZzxk16f8Pz/YPgDxl4iPyyNGLK3lh4micjGQeMDdLGeDn5enAryWuan71apLtZfq/wAzyMJ+8xter0XLFfJXf/pQV23h7xZZaH4etbaeAX2b24a5sWJQSwvFGo+fBA+ZMjryo4riaK6j1LHpTeL7HV9OW3vNS+zX99ps0E92Y3KwytfPOVbaCdrIQCVBxuA9RUMviLS7m61Cx/tJo1n0iDTl1V4nw7xsjEsAC+xghTpnAXI6ivO6KLiselah4h0nVdPuNJTWjayRLZf8TKSKXF35COrAhQXGC425HRBnbxjM1PxBp9z8UodbS7eTTV1CCdrh0YMUUpuYrjOeDxXEUUXHY9GuNbtI/FWialNreg3Nnb6pFcONO0xreWOMSBizkW8ZYADpljntUVx4lsb7WLLU7fUIrFTBJZyWM8EjQQIUKnbsGRG4Yk4+cMSefvHz6ii4WPUlOkXPh3xLDZaz9jtHk06NpyJ2g8wLOSi5Bk8vjIyCcgduaydf8VWd9Z+KI7W7l3X89gqllZWuUhikV5G9NzbWwTnLexriFuZkgkt1lkWCVld4wxCsy52kjoSNxx6ZPrUVFxWPT73xjpU2mefanTobiTTorB4miu3uV2oqnA8wQbdy7geD/s5yS2TxBoi6gmoTalDLf3AvWne0jnWJjJbOql0kHEhdgPk+UA15lRRcLGrod39kOo/8TD7F5tnLF/qfM8/OP3X+zu/vdsVo+Dtdh0E65NI8Imn054YFmgWZHkMkZwVZSp4VvvDHH0rmaKB2PTYvFuhyyHxBevI+qNpZsP7Otcw+XIf3ReN9jJGvlEnAHDE4Apsni/RfKbUbCa4stROjixEMzGWQSxTRGJjIqKpzGuOgx5fPUZ80oouKx3+p+LtP8RaTqdoyR6VFPd2X2e2XdIkMa/aDK2QvTfMWx1+bAziruteLvDOsQeIdPht761gmhiFlPNcCSLNsNsIESxAoWTcuSxwX59R5nRRcdj1DUPiBbXfiPxMfMsP7Lu7S6it5002JJXZoiEBkEYk5PGSfrXl9FFFwSsFFFFIYUUUUAFFFFABRRRQAUUUUAFFFFAHYfGf/AJKVrf8A2w/9ER0U74zBf+Fk63knP7jt/wBMY6K5cP8AwYei/I4ss/3Kj/hj+SD4O/8AJTtH+s//AKJkrja7L4O/8lO0f6z/APomSuNqqf8AGl6L85Ch/vtT/BD85hXq3wW1WG5m1jwpeyzLb61bssZRz8rBGDhRggEoSdx/55gc8V5TU9leT6deW95bP5dzbSLLG+AdrKcg4PB5Herr0va03ArHYVYrDyo3s3s+zWqf3l6eCfS7y6s7hPLuIHeKRcg7XUkEZHB5B6VSr0/4m6cviHT9M8c6bA/2TUYVW8C5YQSr8nJOOMjZkKBlAf4hXmFRCr7WCfXr5Pqa5diViaKqNWezXZrRr7woqW3h85yC21FUszYzgD2p/l2f/P7/AOQjVHc2kfUH7Mn7Tdn4A09PB3jF/K8OReZJY6hFCXa0ZiXaORUBZ0ZixDAFlZsHKkFPvCzvLfUbS3vLO4iuLS4jWWGeFw6SIwyrKw4IIIII61+N/l2f/P7/AOQjXp3w0+PXi34VbING8RfaNJXP/Er1CF5rUZ3n5VyGj+Zyx8tl3HG7PSuSthed80dzopYlR0lsfqRVa+06z1OJYb60guolbcEnjDqD0zgjryfzrzv4Q/F1/i3oVlq1n4Yvbe1nklimuY7y1mgt3TPyt+8WYEjacGIH5wfukMfUDE4ONp/KuGVKcd0dkK0d4yKFhpGn6V5n2CwtbTzMb/IhWPdjOM4HOMn86uU7y3P8J/KuK+JPj6X4caFqWsT+H7280+xtDcPdrdWsNur8hY2MkofJbaPlRyd4Chm+WlGlOWyHOsr3lI7Ovjb9pP8Aan0u70S+8G+BbuK/a/jltdS1QJmKOI5R4otww5YZzIMqFI2kltyeNfFL9prxb8TftNl/bP8AYugS7k/s7TkdPMjO8bZZfvSZR9rDhG2g7Aa8X8uz/wCf3/yEa7qOE5XzTOOrik9IleirHl2f/P7/AOQjTZ4FjWN45PMikBw2MdDzxXYc10yGpnkLRRrnoKhr0L4U+HVu9Wk1/UEePRdEVrqSYqSpkQbgBg5JX75wD90Aj5hSlVVKLkzkx2IjhqEq0+n4vol5t6Gp8SLn/hFvAvhvwcpmS8aMXd4pk+7ksShwNrAyM2OTjyx1yDXkNavibXZ/E2vX+rXA2yXUm4JkHYo4VcgDOFAGcc4zWVTw9N04We71fqzly7DPD0FGfxO7l/ier/yCiirFtbeb+8kyIgcZHVj6D/Ht+QO52leitLFuOBaxkDuzNk/XBFL+4/59Iv8Avp//AIqnyi5jMorT/cf8+kX/AH0//wAVR+4/59Iv++n/APiqOUOYzKK0/wBx/wA+kX/fT/8AxVH7j/n0i/76f/4qjlDmMyitP9x/z6Rf99P/APFUfuP+fSL/AL6f/wCKo5Q5jMorT/cf8+kX/fT/APxVH7j/AJ9Iv++n/wDiqOUOYzKK0/3H/PpF/wB9P/8AFUfuP+fSL/vp/wD4qjlDmMyitP8Acf8APpF/30//AMVR+4/59Iv++n/+Ko5Q5jMorT/cf8+kX/fT/wDxVH7j/n0i/wC+n/8AiqOUOYzKK0/3H/PpF/30/wD8VR+4/wCfSL/vp/8A4qjlDmMyitP9x/z6Rf8AfT//ABVH7j/n0i/76f8A+Ko5Q5jMorT/AHH/AD6Rf99P/wDFUfuP+fSL/vp//iqOUOYzKK0/3H/PpF/30/8A8VR+4/59Iv8Avp//AIqjlDmMyitP9x/z6Rf99P8A/FUfuP8An0i/76f/AOKo5Q5jMorT/cf8+kX/AH0//wAVVa4tlVTJDuMY+8rHJX/Ee/4emRoLlWiiipKOw+M//JStb/7Yf+iI6KPjP/yUrW/+2H/oiOiuXD/wYei/I4ss/wByo/4I/kh3wd/5Kdo/1n/9EyVxtdp8HXY/E3RxuOMz8Z/6YyVxdVD+NL0X5yFD/fan+CH5zCiiiug7jYtvEWoQ+H7jQUmxp09wty6DglgMYyOoPynBzyikY5zn1HF3qeGIzSpGM5Y44GcVk4pN2LpU4wTcVa7u/Ukmb7PYbD9+4IOPRR0P4ms6rV/MJrltuPLj+RMHPA96q1LAKKKKQH0T+yN8av8AhWvjpdE1rVPs3hDXMpN9ol2wWlzgeXOflO3O0RscqMMGY4jGP0vr8R6/Sj9kP44yfEzwjJ4d1u6mn8VaBGvmXFzMjSX1uWISQDhiU+VHJB5KMWLOQBjR9IV8D/ttfGr+2tYg+H2gapv0zT8vrH2aXKTXIb5YH+Xnytu4gMRufBAaLj6Y/aQ+MkXwc+H095btu8Q6pvs9LjV490cpQ5uCr53JHwT8rAsyKcBsj8rr29udSvLi8vLia5vLmRpZp5nLySuxyzMx5JJJJJ5JNCBkFFFFAgrQsm8+2ltv4wfNT3IHI/Ks+pbadraeOVeqnOPUdxTQEtaMXiLULPQb7RIpsaffyRySoeeU5GOwydpJHJ2Lzjg1buIQzsqcxn5lPYg1Vl+6PrT5U3ZhVhGpG0lfZ/NaoiooorYgK0hxaWoHAKFj7ncwz+QH5Vm1p/8ALraf9cz/AOhtVRJkMoq1pmnXGr6lZ6fZxmS7vJkgiQfxOxCqPzIr234i/Dyxt5NCmudJufDui6fqQ0C6vpLFoftMKhSl5yBvZ8TEtz0X2p3JPCKK9KuPCNjbW/iCe1tbu2tU0ZrmEz3FtfJIy3UMZKTom3GHOdoVlPBOCQdTwv4Q8N/274OuLe2u9Ws5L+wS8nF3BJAzSld0ckGwvEA5K/PuDhSBjIILgeQ0V6jo/gzQPEP9vaxFBcW2l2N1FaR2NxrdpbSPI4kYt9omRECgRnCBCxz1wCanfwF4R0s24vL7UNRW81uTS4JtNuoPLEQjgcSFgrqzKZ8FVOCRwy45LgeT0VrSeH7pvE7+H7Uefem9NjGAMeY+/YPzNe4+J/h9DaeIfBk48MSafp2n69BoE/2mxMSajErIUuGDKBJ5mJtx54Cj0ouB88UV6J8PrG0uPisbaeGyNqjX5CXUAlgTZBMVLRlWBCkA42np0Na+rLoOu6RqLWs+m3Wr6bo0s95eaXpq21tMxu4FjCxvEm1grtl0RCcgZI3ZLgeSUV6h4t8F+F9Im8Uwab/bDv4avo4Z2ubiLF1E0hRguI/3bAgAMdwPJ2jpVzxR4c0LUfij4ksdN8OXw0+wln+0Rx6vbWcMREgUOJHgEcUfIUIc8kYbsS4HkdFeqat8P/D3hmLxDeam+o3VtZHTWtIbO7gzIt1DJIVaZVdDt2YDoCGwcD5gRgfDKxspNYvtT1VIDpWlWck87zw+csTPiGF/K6SbZZYyVPBAOfSi4HFUV2HjfwvqmlFNW1GPTYI76Yx24sFCRXKqiEzxKo2+W29eRgbiRtGCB3mkeEtH8UeAvCVo9va2d5bxy6peXyRqsstmt1LHcbm6uUURsoPQBqLgeJ0V6z8TtF0q9h1PxFZWMWmlYtEMVlZoscCC6spJZPlA67o15z3Oc543vCnhvS9G13UtDnglvNMXxLoUTRTspMgcT8NlSCuW5GORkcZzRcDwiivQW0PTdZ0rxLLo1u9ksWo2VvDFqF1bsAXFxuJnaOMIuUHAKj+9uwCNbwPpaaP4f8Ztd3fhq1v7OexjS+1C2i1O3QP5xZUKRTqS2F5Ufw4JGKLgeUUV7VYaboH9h3+paxZJqhuNBuLsPpyQWSKy6p5W6L/R8rkYwWXKqWXABAXldN8E6bqOoeDYhJeJDrtjc3cw8xS0ZjmuUUKdvTbAmcjqT0yAC4zz+iuv8Z6NoXh+30m1sV1GTU7mws764mnmTyU86BZGjVAmTywIYtwOMH71chQIKKKKYBUkPPmg8gxPkeuFJH6gH8KjqWDrJ/1yk/8AQDQgMqiiiszQ7D4z/wDJStb/AO2H/oiOinfGZ2HxJ1sBiB+47/8ATGOiuXD/AMGHovyOLLP9yo/4Y/kg+Dv/ACU7R/rP/wCiZK42uy+Dv/JTtH+s/wD6Jkrjaqn/ABpei/OQof77U/wQ/OYUUUV0HcSxfdP1q5C32e2muD1x5aeu4989sCqKybRjFaV1bLNFbxpdWwWJTndJzuPX8Kzad7mnMrWMiir39m/9Pdp/38/+tR/Zv/T3af8Afz/61Tysm5Roq9/Zv/T3af8Afz/61atn4F1zUbZLmzsZ7m2kztlhid0bBwcELg8gj8Kl+7qyZ1IQV5tL1OcrsPhf8RdW+FfjXTPEukzTBraRRc28cmwXluWBkgYkEYYDqQdpAYcqCIf+FceJv+gRef8AgNJ/8TWJ/Zbf8/Nr/wB/P/rURtLbUUKtOp8Ek/Rnofx8+Ml78aPHVxq267h0G2/c6XYXDqfs8WAGYheA7ldzfeI4XcwRa8tq/wD2W3/Pza/9/P8A61bEPw+8Q3MMc0OmXMkMih0kSCQqykZBBC8gih+7voE6sIazkl6nMUV08/w/8Q20Mk02m3MUMSl3keCRVVQMkkleABWN/Zv/AE92n/fz/wCtQve2CFWFTWDT9CjRV7+zf+nu0/7+f/Wo/s3/AKe7T/v5/wDWquVl3JFb7RYI38dudrZ6lT05/TFVX+4av2VqtvKxe6tjG6FG2yc4PpWfI21nTg4JGVOQapJlcytYiooorQzCtP8A5dbT/rmf/Q2rMq/bSieJID/rUyE/2gedv1zk++foDUSWX9G1i98P6nb6lp03kX1uS0Uu1WKEgjIBBGeeD2PI5qxo/ibVdAiuotOuzBHdmMyrsVgxRtyn5gcEH07Eg8Eg5TKVJVgQRwQe1JVEnR3/AI617UUmimu4kgmtjZtBb2sMMQiMiyEKiKFUl0UkgAnHJpW8feIDaW9qt8sSQSRSiSG3ijldozmMvIqh5Np5G4nFc3RSA6ZPH+uxX95epLZK96qi4hGnW32ebbyrND5fllgSTu255PPNU7jxbrF15Hm3hb7PeNfx/u0+WZggLDjpiJBt6DbwOtYtFAGrZ+JNT0/Xv7dtrny9W815xceWpIkbOWAIwDySOODyMYFP0PxTq3hvzf7Mu/IEskMrgxo4LxSCSNsMDghhn6Eg8Eg49FAGjYa9qGmaq+qWtx5d+4lBl2Kc+YrK/BGOVdh04zxUVjqt3psV9FazeXHfwfZrgbQd8e9X28jj5kU5GDx9ap0UAbF74q1fUZdZlubvzH1qQS3p8tB5zB94PA+X5uflxWkfiN4ia+kvXubR7iaD7POz6fbsLlNwb96pjxK2VU7nDNkDmuVooA39Y8ba7r8d3HqN956XZtzKPKRd3kIyRfdUY2q7DjrnnOBVPQ/EGo+G7x7rTbgQyyRtDIGjWRJYz1R0cFWU4HDAjgVmUUAb2u+M9a8S2lvaandRzW1q5eCJLeKNYMgAqgRRsQ4B2Lhc84zzWdd6teX1lp9lcTb7bT0eO3TaB5as5dhkDJyzE8561SooA6W28f8AiC0lkkS8ifzLaC0ZJrWGWMxwIEi+R0K7kUABsbupzkmo7jx14hury9vJdSka7vbqC9mmCKGaaHd5b5A4I3N0xnPOa56igDb1PxbqurR38dxJbLFfyRS3EdvaQwLI8YcI2I0UA/vHyR1zzniqNvq95a6Ze6ZFNtsr145J49oO9o92w5xkY3t0POeapUUAb+neNdb0oWi291EY7S2ezjimtopYzC8hkZGR1KuC7FvmB5x6CrWl/EbxJo1qltY30UUcZk8o/ZIWeISZ3qjFCyI2TlVIXk8Vy1FAFzUtVu9XmhmvZvNkhgitkO0LiONAiLwB0VQM9TjnNU6KKYBRRRQAVLB1k/65Sf8AoBqKnTP9kR1YETupUKeqA9SfqMjHvn0yDM2iiisyzsPjP/yUrW/+2H/oiOij4z/8lK1v/th/6Ijorlw/8GHovyOLLP8AcqP+CP5Ik+DoX/hZuj8nOZ+3/TGSuLrsvg7/AMlO0f6z/wDomSuNqofxpei/OQof77U/wQ/OYUUUV0HcFFFFABRRRQAVPZ3tzp1ylzZ3E1tcx52ywuUdcjBwRyOCR+NQUUNX0Ymk1ZnZWfxW8Y2NslvFrkzRpnBmjjlfk55Z1LHr3NdH/wAL/wDEv/PjpH/fqT/45XlVFYSwlGWrgjz6mU4Ko7ypR+635Hqv/C//ABL/AM+Okf8AfqT/AOOVh3vxg8Y3v2hf7W8iKfcNkEMa7Aeytt3DGeDnPvnmuGopRwlCO0EKnlGBpu8aMfuv+Zb1DVL7Vplm1C9ubuZV2CS4laRguScZJPGSfzqpRRXQkloj0IxUVaKsgooooKCiiigAooooAKKKKALC310ihVuZgoGAA5wBS/2hd/8AP1P/AN/DVaindisWf7Qu/wDn6n/7+Gj+0Lv/AJ+p/wDv4arUUXYWLP8AaF3/AM/U/wD38NH9oXf/AD9T/wDfw1WoouwsWf7Qu/8An6n/AO/ho/tC7/5+p/8Av4arUUXYWLP9oXf/AD9T/wDfw0f2hd/8/U//AH8NVqKLsLFn+0Lv/n6n/wC/ho/tC7/5+p/+/hqtRRdhYs/2hd/8/U//AH8NH9oXf/P1P/38NVqKLsLFn+0Lv/n6n/7+Gj+0Lv8A5+p/+/hqtRRdhYs/2hd/8/U//fw0f2hd/wDP1P8A9/DVaii7CxZ/tC7/AOfqf/v4aP7Qu/8An6n/AO/hqtRRdhYs/wBoXf8Az9T/APfw0f2hd/8AP1P/AN/DVaii7CxZ/tC7/wCfqf8A7+Gj+0Lv/n6n/wC/hqtRRdhYs/2hd/8AP1P/AN/DR/aF3/z9T/8Afw1WoouwsWf7Qu/+fqf/AL+Gq1FFFwCiiikM7L4zBf8AhZOt5Jz+47f9MY6Kb8Z/+Sla3/2w/wDREdFcuH/gw9F+RxZZ/uVH/DH8kY/gjXl8NeM9K1ORkWGG42ys6lgsbZRzgckhWJHuBwelL4s0NvDfiTU9KIcJbTMse9gzGM8oSRxkqVP49B0rnJP9Y/1NdzpviHRvEOjafofiMvZT2CslrrcatMyR5yIZI+rLywUg/L8oAA3EuV4T50rrZ/5hXjKlVWIim01aVt7LVO3W13otddNrPkKK7gfCfxBd/PpDabrNsOGuNPvY3jVu6EsVO4DB6dCKX/hT3jX/AKAv/k1D/wDF1f1mj/OvvF/aeD61or1aX4M4aiu5/wCFPeNf+gL/AOTUP/xdH/CnvGv/AEBf/JqH/wCLo+s0f5196D+08F/z+j/4Ev8AM4aiu5/4U941/wCgL/5NQ/8AxdH/AAp7xr/0Bf8Ayah/+Lo+s0f5196D+08F/wA/o/8AgS/zOGoruf8AhT3jX/oC/wDk1D/8XR/wp7xr/wBAX/yah/8Ai6PrNH+dfeg/tPBf8/o/+BL/ADOGoruf+FPeNf8AoC/+TUP/AMXR/wAKe8a/9AX/AMmof/i6PrNH+dfeg/tPBf8AP6P/AIEv8zhqK7n/AIU941/6Av8A5NQ//F0f8Ke8a/8AQF/8mof/AIuj6zR/nX3oP7TwX/P6P/gS/wAzhqK7n/hT3jX/AKAv/k1D/wDF0f8ACnvGv/QF/wDJqH/4uj6zR/nX3oP7TwX/AD+j/wCBL/M4aiu5/wCFPeNf+gL/AOTUP/xdH/CnvGv/AEBf/JqH/wCLo+s0f5196D+08F/z+j/4Ev8AM4aiu5/4U941/wCgL/5NQ/8AxdH/AAp7xr/0Bf8Ayah/+Lo+s0f5196D+08F/wA/o/8AgS/zOGoruf8AhT3jX/oC/wDk1D/8XR/wp7xr/wBAX/yah/8Ai6PrNH+dfeg/tPBf8/o/+BL/ADOGoruf+FPeNf8AoC/+TUP/AMXR/wAKe8a/9AX/AMmof/i6PrNH+dfeg/tPBf8AP6P/AIEv8zhqK7n/AIU941/6Av8A5NQ//F0f8Ke8a/8AQF/8mof/AIuj6zR/nX3oP7TwX/P6P/gS/wAzhqK7n/hT3jX/AKAv/k1D/wDF0f8ACnvGv/QF/wDJqH/4uj6zR/nX3oP7TwX/AD+j/wCBL/M4aiu5/wCFPeNf+gL/AOTUP/xdH/CnvGv/AEBf/JqH/wCLo+s0f5196D+08F/z+j/4Ev8AM4aiu5/4U941/wCgL/5NQ/8AxdH/AAp7xr/0Bf8Ayah/+Lo+s0f5196D+08F/wA/o/8AgS/zOGoruf8AhT3jX/oC/wDk1D/8XR/wp7xr/wBAX/yah/8Ai6PrNH+dfeg/tPBf8/o/+BL/ADOGoruf+FPeNf8AoC/+TUP/AMXR/wAKe8a/9AX/AMmof/i6PrNH+dfeg/tPBf8AP6P/AIEv8zhqK7n/AIU941/6Av8A5NQ//F0f8Ke8a/8AQF/8mof/AIuj6zR/nX3oP7TwX/P6P/gS/wAzhqK7n/hT3jX/AKAv/k1D/wDF0f8ACnvGv/QF/wDJqH/4uj6zR/nX3oP7TwX/AD+j/wCBL/M4aiu5/wCFPeNf+gL/AOTUP/xdH/CnvGv/AEBf/JqH/wCLo+s0f5196D+08F/z+j/4Ev8AM4aiu5/4U941/wCgL/5NQ/8AxdH/AAp7xr/0Bf8Ayah/+Lo+s0f5196D+08F/wA/o/8AgS/zOGoruf8AhT3jX/oC/wDk1D/8XR/wp7xr/wBAX/yah/8Ai6PrNH+dfeg/tPBf8/o/+BL/ADOGoruf+FPeNf8AoC/+TUP/AMXR/wAKe8a/9AX/AMmof/i6PrNH+dfeg/tPBf8AP6P/AIEv8zhqK7n/AIU941/6Av8A5NQ//F0f8Ke8a/8AQF/8mof/AIuj6zR/nX3oP7TwX/P6P/gS/wAzhqK7n/hT3jX/AKAv/k1D/wDF0f8ACnvGv/QF/wDJqH/4uj6zR/nX3oP7TwX/AD+j/wCBL/M4atnwnobeJPEmmaUA5S5mCybGCsIxy5BPGQoY/h0PSt8/CfxBafPq7abo1seFuNQvY0jZuyAqWO4jJ6dAaral4h0bw9o2oaH4cL3s9+qpda3IrQs8ecmGOPqq8KGJPzfMCCNpEyrqStSd35bL+uxE8ZGtFwwj5pPqtUvNvbTte76dWsbx3ry+JfF+r6nGyNDNMViZFKho1ARDg8glVBPuTwOlFc7RVRioxUV0O6lSjSpxpw2ikl8iSSRw7AM3U96b5j/32/OiiqNA8x/77fnThI+xjubqO/1oooAb5j/32/OjzH/vt+dFFAB5j/32/OnSSOHYBm6nvRRQA3zH/vt+dHmP/fb86KKAHCR9jHc3Ud/rTfMf++350UUAHmP/AH2/OjzH/vt+dFFADpJHDsAzdT3pvmP/AH2/OiigA8x/77fnThI+xjubqO/1oooAb5j/AN9vzo8x/wC+350UUAHmP/fb86dJI4dgGbqe9FFADfMf++350eY/99vzoooAcJH2MdzdR3+tN8x/77fnRRQAeY/99vzo8x/77fnRRQA6SRw7AM3U96b5j/32/OiigA8x/wC+3504SPsY7m6jv9aKKAG+Y/8Afb86PMf++350UUAHmP8A32/OnSSOHYBm6nvRRQA3zH/vt+dHmP8A32/OiigBwkfYx3N1Hf603zH/AL7fnRRQAeY/99vzo8x/77fnRRQA6SRw7AM3U96b5j/32/OiigA8x/77fnThI+xjubqO/wBaKKAG+Y/99vzo8x/77fnRRQAeY/8Afb86dJI4dgGbqe9FFADfMf8Avt+dHmP/AH2/OiigBwkfYx3N1Hf603zH/vt+dFFAB5j/AN9vzooooA//2Q==",
}

func parseAndStripMood(rawText string) (string, string) {
	trimmed := strings.TrimSpace(rawText)
	if m := moodTagRegex.FindStringSubmatch(trimmed); len(m) >= 2 {
		key := strings.ToLower(strings.TrimSpace(m[1]))
		if _, ok := expressionBannersB64[key]; ok {
			cleaned := strings.TrimSpace(moodTagRegex.ReplaceAllString(trimmed, ""))
			return key, cleaned
		}
	}
	lower := strings.ToLower(trimmed)
	switch {
	case strings.Contains(lower, "wkwk") || strings.Contains(lower, "haha") || strings.Contains(lower, "😂") || strings.Contains(lower, "😆"):
		return "ketawa", trimmed
	case strings.Contains(lower, "maaf") || strings.Contains(lower, "sedih") || strings.Contains(lower, "😢"):
		return "sedih", trimmed
	case strings.Contains(lower, "waduh") || strings.Contains(lower, "bahaya") || strings.Contains(lower, "😱"):
		return "kaget", trimmed
	case strings.Contains(lower, "semangat") || strings.Contains(lower, "gas") || strings.Contains(lower, "🔥"):
		return "semangat", trimmed
	case strings.Contains(lower, "terima kasih") || strings.Contains(lower, "sayang") || strings.Contains(lower, "❤️") || strings.Contains(lower, "😍"):
		return "suka", trimmed
	case strings.Contains(lower, "halo") || strings.Contains(lower, "hai") || strings.Contains(lower, "selamat"):
		return "ramah", trimmed
	case strings.Contains(lower, "berhasil") || strings.Contains(lower, "sukses") || strings.Contains(lower, "✅"):
		return "bangga", trimmed
	case strings.Contains(lower, "?") || strings.Contains(lower, "mengapa") || strings.Contains(lower, "analisis") || strings.Contains(lower, "ringkasan"):
		return "bingung", trimmed
	case strings.Contains(lower, "!") || strings.Contains(lower, "😊") || strings.Contains(lower, "✨"):
		return "ceria", trimmed
	default:
		return "tenang", trimmed
	}
}

func getOrUploadMoodBanner(ctx context.Context, sess *SessionInstance, moodKey string) (*whatsmeow.UploadResponse, []byte, error) {
	if sess == nil || sess.Client == nil {
		return nil, nil, fmt.Errorf("client nil")
	}
	b64, ok := expressionBannersB64[moodKey]
	if !ok {
		moodKey = "ceria"
		b64 = expressionBannersB64["ceria"]
	}
	thumbBytes, err := base64.StdEncoding.DecodeString(b64)
	if err != nil || len(thumbBytes) == 0 {
		return nil, nil, fmt.Errorf("decode banner gagal")
	}

	mu.Lock()
	if sess.MoodMediaCache == nil {
		sess.MoodMediaCache = make(map[string]*CachedMoodMedia)
	}
	cached, found := sess.MoodMediaCache[moodKey]
	mu.Unlock()

	if found && cached != nil && time.Since(cached.CreatedAt) < 6*time.Hour && cached.Upload.URL != "" {
		up := cached.Upload
		return &up, thumbBytes, nil
	}

	upCtx, cancel := context.WithTimeout(ctx, 12*time.Second)
	defer cancel()
	up, err := sess.Client.Upload(upCtx, thumbBytes, whatsmeow.MediaImage)
	if err != nil {
		return nil, thumbBytes, err
	}

	mu.Lock()
	sess.MoodMediaCache[moodKey] = &CachedMoodMedia{
		Upload:    up,
		CreatedAt: time.Now(),
	}
	mu.Unlock()
	return &up, thumbBytes, nil
}

func sendMsgReaction(ctx context.Context, sess *SessionInstance, info types.MessageInfo, emoji string) {
	if sess == nil || sess.Client == nil || info.ID == "" || info.Chat.String() == "status@broadcast" {
		return
	}
	reactMsg := sess.Client.BuildReaction(info.Chat, info.Sender, info.ID, emoji)
	resp, err := sess.Client.SendMessage(ctx, info.Chat, reactMsg)
	if err == nil && resp.ID != "" {
		mu.Lock()
		botSentIDs[resp.ID] = true
		mu.Unlock()
	}
}

func sendBotTextWithErr(ctx context.Context, sess *SessionInstance, chat types.JID, text string) error {
	if sess == nil || sess.Client == nil {
		return fmt.Errorf("sesi WA belum siap")
	}
	moodKey, cleanText := parseAndStripMood(text)
	if strings.TrimSpace(cleanText) == "" {
		cleanText = "..."
	}

	mu.Lock()
	useBanner := bannerEnabled
	mu.Unlock()

	if useBanner && len(cleanText) <= 1000 {
		if up, thumbBytes, upErr := getOrUploadMoodBanner(ctx, sess, moodKey); upErr == nil && up != nil {
			w := uint32(440)
			h := uint32(230)
			imgMsg := &waE2E.Message{
				ImageMessage: &waE2E.ImageMessage{
					URL:           proto.String(up.URL),
					DirectPath:    proto.String(up.DirectPath),
					MediaKey:      up.MediaKey,
					Mimetype:      proto.String("image/jpeg"),
					FileEncSHA256: up.FileEncSHA256,
					FileSHA256:    up.FileSHA256,
					FileLength:    proto.Uint64(up.FileLength),
					Width:         &w,
					Height:        &h,
					JPEGThumbnail: thumbBytes,
					Caption:       proto.String(cleanText),
				},
			}
			resp, err := sess.Client.SendMessage(ctx, chat, imgMsg)
			if err == nil && resp.ID != "" {
				mu.Lock()
				botSentIDs[resp.ID] = true
				mu.Unlock()
				recordUiMessage(sess, chat.String(), "", chat.Server == types.GroupServer, "Bot AI ["+moodKey+"]", cleanText, true, resp.ID)
				return nil
			}
		}
	}

	if useBanner && len(cleanText) > 1000 {
		if up, thumbBytes, upErr := getOrUploadMoodBanner(ctx, sess, moodKey); upErr == nil && up != nil {
			w := uint32(440)
			h := uint32(230)
			moodLabel := expressionLabels[moodKey]
			if moodLabel == "" {
				moodLabel = "😊 Ceria & Senang"
			}
			bannerMsg := &waE2E.Message{
				ImageMessage: &waE2E.ImageMessage{
					URL:           proto.String(up.URL),
					DirectPath:    proto.String(up.DirectPath),
					MediaKey:      up.MediaKey,
					Mimetype:      proto.String("image/jpeg"),
					FileEncSHA256: up.FileEncSHA256,
					FileSHA256:    up.FileSHA256,
					FileLength:    proto.Uint64(up.FileLength),
					Width:         &w,
					Height:        &h,
					JPEGThumbnail: thumbBytes,
					Caption:       proto.String("*" + moodLabel + "*"),
				},
			}
			if bResp, bErr := sess.Client.SendMessage(ctx, chat, bannerMsg); bErr == nil && bResp.ID != "" {
				mu.Lock()
				botSentIDs[bResp.ID] = true
				mu.Unlock()
			}
		}
	}

	resp, err := sess.Client.SendMessage(ctx, chat, &waE2E.Message{
		Conversation: proto.String(cleanText),
	})
	if err == nil && resp.ID != "" {
		mu.Lock()
		botSentIDs[resp.ID] = true
		mu.Unlock()
		recordUiMessage(sess, chat.String(), "", chat.Server == types.GroupServer, "Bot AI ["+moodKey+"]", cleanText, true, resp.ID)
	}
	return err
}

func sendBotText(ctx context.Context, sess *SessionInstance, chat types.JID, text string) {
	_ = sendBotTextWithErr(ctx, sess, chat, text)
}

func unwrapWaMessage(msg *waE2E.Message) *waE2E.Message {
	for msg != nil {
		if msg.ViewOnceMessage != nil && msg.ViewOnceMessage.Message != nil {
			msg = msg.ViewOnceMessage.Message
			continue
		}
		if msg.ViewOnceMessageV2 != nil && msg.ViewOnceMessageV2.Message != nil {
			msg = msg.ViewOnceMessageV2.Message
			continue
		}
		if msg.ViewOnceMessageV2Extension != nil && msg.ViewOnceMessageV2Extension.Message != nil {
			msg = msg.ViewOnceMessageV2Extension.Message
			continue
		}
		if msg.EphemeralMessage != nil && msg.EphemeralMessage.Message != nil {
			msg = msg.EphemeralMessage.Message
			continue
		}
		if msg.DocumentWithCaptionMessage != nil && msg.DocumentWithCaptionMessage.Message != nil {
			msg = msg.DocumentWithCaptionMessage.Message
			continue
		}
		break
	}
	return msg
}

func extractInteractiveSelectionText(rawMsg *waE2E.Message) string {
	msg := unwrapWaMessage(rawMsg)
	if msg == nil {
		return ""
	}
	if ir := msg.GetInteractiveResponseMessage(); ir != nil {
		if nf := ir.GetNativeFlowResponseMessage(); nf != nil {
			paramsRaw := strings.TrimSpace(nf.GetParamsJSON())
			if paramsRaw != "" {
				var parsed map[string]interface{}
				if json.Unmarshal([]byte(paramsRaw), &parsed) == nil {
					if idVal, ok := parsed["id"].(string); ok && strings.TrimSpace(idVal) != "" {
						return strings.TrimSpace(idVal)
					}
				}
			}
		}
		if body := ir.GetBody(); body != nil && strings.TrimSpace(body.GetText()) != "" {
			return strings.TrimSpace(body.GetText())
		}
	}
	if lr := msg.GetListResponseMessage(); lr != nil {
		if sr := lr.GetSingleSelectReply(); sr != nil && strings.TrimSpace(sr.GetSelectedRowID()) != "" {
			return strings.TrimSpace(sr.GetSelectedRowID())
		}
		if strings.TrimSpace(lr.GetTitle()) != "" {
			return strings.TrimSpace(lr.GetTitle())
		}
	}
	if br := msg.GetButtonsResponseMessage(); br != nil {
		if strings.TrimSpace(br.GetSelectedButtonID()) != "" {
			return strings.TrimSpace(br.GetSelectedButtonID())
		}
		if strings.TrimSpace(br.GetSelectedDisplayText()) != "" {
			return strings.TrimSpace(br.GetSelectedDisplayText())
		}
	}
	if tr := msg.GetTemplateButtonReplyMessage(); tr != nil {
		if strings.TrimSpace(tr.GetSelectedID()) != "" {
			return strings.TrimSpace(tr.GetSelectedID())
		}
		if strings.TrimSpace(tr.GetSelectedDisplayText()) != "" {
			return strings.TrimSpace(tr.GetSelectedDisplayText())
		}
	}
	return ""
}

func sendInteractiveMenuList(ctx context.Context, sess *SessionInstance, chat types.JID, headerTitle string, bodyText string, footerText string) error {
	if sess == nil || sess.Client == nil {
		return fmt.Errorf("client nil")
	}
	mu.Lock()
	bName := strings.TrimSpace(config.BotName)
	mu.Unlock()
	if bName == "" {
		bName = "DodosBot"
	}
	if headerTitle == "" || strings.Contains(headerTitle, "GEMINI WHATSAPP BOT") {
		headerTitle = "⚡ " + strings.ToUpper(bName) + " MENU v7.0"
	}
	if footerText == "" {
		footerText = "Pilih kategori di 🗂️ Menu List atau ketik perintah teks"
	}

	rows := []map[string]string{
		{"header": "", "title": "👥 group", "description": "Group management and admin features", "id": "/menu group"},
		{"header": "", "title": "ℹ️ info", "description": "Bot and system information", "id": "/menu info"},
		{"header": "", "title": "🌐 internet", "description": "Search and access internet content", "id": "/menu internet"},
		{"header": "", "title": "🏠 main", "description": "Main and basic bot commands", "id": "/menu main"},
		{"header": "", "title": "🤨 nsfw", "description": "Collection of anime & fun features", "id": "/menu nsfw"},
		{"header": "", "title": "💬 quotes", "description": "Motivational quotes and wise words", "id": "/menu quotes"},
		{"header": "", "title": "⚔️ rpg", "description": "Role Playing Game and leveling system", "id": "/menu rpg"},
		{"header": "", "title": "🔍 search", "description": "Search for online information and data", "id": "/menu search"},
		{"header": "", "title": "🎵 sound", "description": "Audio, music, and sound effects", "id": "/menu sound"},
		{"header": "", "title": "🕵️ stalk", "description": "Find social media profile information", "id": "/menu stalk"},
		{"header": "", "title": "🎭 sticker", "description": "Create and manage WhatsApp stickers", "id": "/menu sticker"},
		{"header": "", "title": "📥 downloader", "description": "Download Video HD & MP3 (YouTube, IG, TikTok, FB, X)", "id": "/menu downloader"},
		{"header": "", "title": "📸 status", "description": "Upload Status WA HD & Status Grup", "id": "/menu status"},
	}

	paramsObj := map[string]interface{}{
		"title": "🗂️ Menu List",
		"sections": []map[string]interface{}{
			{
				"title": "📂 Pilih Kategori Menu Bot",
				"rows":  rows,
			},
		},
	}
	paramsBytes, _ := json.Marshal(paramsObj)
	paramsJSON := string(paramsBytes)
	msgVer := int32(1)

	interactiveMsg := &waE2E.Message{
		InteractiveMessage: &waE2E.InteractiveMessage{
			Header: &waE2E.InteractiveMessage_Header{
				Title:              proto.String(headerTitle),
				HasMediaAttachment: proto.Bool(false),
			},
			Body: &waE2E.InteractiveMessage_Body{
				Text: proto.String(bodyText),
			},
			Footer: &waE2E.InteractiveMessage_Footer{
				Text: proto.String(footerText),
			},
			InteractiveMessage: &waE2E.InteractiveMessage_NativeFlowMessage_{
				NativeFlowMessage: &waE2E.InteractiveMessage_NativeFlowMessage{
					Buttons: []*waE2E.InteractiveMessage_NativeFlowMessage_NativeFlowButton{
						{
							Name:             proto.String("single_select"),
							ButtonParamsJSON: proto.String(paramsJSON),
						},
					},
					MessageVersion: &msgVer,
				},
			},
		},
	}

	bizNode := waBinary.Node{
		Tag: "biz",
		Content: []waBinary.Node{{
			Tag:   "interactive",
			Attrs: waBinary.Attrs{"type": "native_flow", "v": "1"},
			Content: []waBinary.Node{{
				Tag:   "native_flow",
				Attrs: waBinary.Attrs{"v": "9", "name": "mixed"},
			}},
		}},
	}
	additionalNodes := []waBinary.Node{bizNode}
	if chat.Server != types.GroupServer {
		additionalNodes = append(additionalNodes, waBinary.Node{
			Tag:   "bot",
			Attrs: waBinary.Attrs{"biz_bot": "1"},
		})
	}

	resp, err := sess.Client.SendMessage(ctx, chat, interactiveMsg, whatsmeow.SendRequestExtra{
		AdditionalNodes: &additionalNodes,
	})
	if err == nil && resp.ID != "" {
		mu.Lock()
		botSentIDs[resp.ID] = true
		mu.Unlock()
		recordUiMessage(sess, chat.String(), "", chat.Server == types.GroupServer, "Bot AI [Menu List]", bodyText, true, resp.ID)
		return nil
	}
	return err
}

func parseMp4Metadata(data []byte) (uint32, uint32, uint32, bool) {
	var durationSec uint32 = 15
	var width uint32 = 720
	var height uint32 = 1280
	isHevc := bytes.Contains(data, []byte("hvc1")) || bytes.Contains(data, []byte("hev1"))

	if idx := bytes.Index(data, []byte("mvhd")); idx >= 4 && idx+32 < len(data) {
		version := data[idx+4]
		if version == 0 && idx+24 <= len(data) {
			timescale := binary.BigEndian.Uint32(data[idx+16 : idx+20])
			duration := binary.BigEndian.Uint32(data[idx+20 : idx+24])
			if timescale > 0 && duration > 0 {
				sec := duration / timescale
				if sec > 0 && sec < 7200 {
					durationSec = sec
				}
			}
		} else if version == 1 && idx+36 <= len(data) {
			timescale := binary.BigEndian.Uint32(data[idx+24 : idx+28])
			duration := binary.BigEndian.Uint64(data[idx+28 : idx+36])
			if timescale > 0 && duration > 0 {
				sec := uint32(duration / uint64(timescale))
				if sec > 0 && sec < 7200 {
					durationSec = sec
				}
			}
		}
	}

	searchData := data
	for {
		idx := bytes.Index(searchData, []byte("tkhd"))
		if idx < 0 || idx+92 > len(searchData) {
			break
		}
		version := searchData[idx+4]
		wOffset := idx + 80
		if version == 1 {
			wOffset = idx + 92
		}
		if wOffset+8 <= len(searchData) {
			wFixed := binary.BigEndian.Uint32(searchData[wOffset : wOffset+4])
			hFixed := binary.BigEndian.Uint32(searchData[wOffset+4 : wOffset+8])
			w := wFixed >> 16
			h := hFixed >> 16
			if w >= 120 && w <= 4320 && h >= 120 && h <= 4320 {
				width = w
				height = h
				break
			}
		}
		searchData = searchData[idx+4:]
	}

	return durationSec, width, height, isHevc
}

func prepareVideoForStatusHD(rawBytes []byte) ([]byte, uint32, uint32, uint32, []byte) {
	sec, w, h, isHevc := parseMp4Metadata(rawBytes)
	var thumbBytes []byte
	if b64, ok := expressionBannersB64["keren"]; ok {
		thumbBytes, _ = base64.StdEncoding.DecodeString(b64)
	}

	ffmpegPath, err := exec.LookPath("ffmpeg")
	if err != nil || ffmpegPath == "" {
		return rawBytes, sec, w, h, thumbBytes
	}

	tmpIn := filepath.Join(os.TempDir(), fmt.Sprintf("wa_status_in_%d.mp4", time.Now().UnixNano()))
	tmpOut := filepath.Join(os.TempDir(), fmt.Sprintf("wa_status_out_%d.mp4", time.Now().UnixNano()))
	tmpThumb := filepath.Join(os.TempDir(), fmt.Sprintf("wa_status_thumb_%d.jpg", time.Now().UnixNano()))
	defer func() {
		_ = os.Remove(tmpIn)
		_ = os.Remove(tmpOut)
		_ = os.Remove(tmpThumb)
	}()

	if err := os.WriteFile(tmpIn, rawBytes, 0600); err != nil {
		return rawBytes, sec, w, h, thumbBytes
	}

	thumbCtx, thumbCancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer thumbCancel()
	_ = exec.CommandContext(thumbCtx, ffmpegPath, "-y", "-ss", "00:00:00.500", "-i", tmpIn, "-vframes", "1", "-vf", "scale=320:-1", "-q:v", "4", tmpThumb).Run()
	if tb, err := os.ReadFile(tmpThumb); err == nil && len(tb) > 200 {
		thumbBytes = tb
	}

	needTranscode := isHevc || len(rawBytes) > 2800*1024 || w > 1080 || h > 1920
	if needTranscode {
		convCtx, convCancel := context.WithTimeout(context.Background(), 90*time.Second)
		defer convCancel()
		args := []string{
			"-y", "-i", tmpIn,
			"-t", "60",
			"-c:v", "libx264",
			"-preset", "veryfast",
			"-crf", "18",
			"-maxrate", "8M",
			"-bufsize", "16M",
			"-pix_fmt", "yuv420p",
			"-vf", "scale='min(1080,iw)':'min(1920,ih)':force_original_aspect_ratio=decrease,pad=ceil(iw/2)*2:ceil(ih/2)*2",
			"-c:a", "aac",
			"-b:a", "192k",
			"-movflags", "+faststart",
			tmpOut,
		}
		if err := exec.CommandContext(convCtx, ffmpegPath, args...).Run(); err == nil {
			if outBytes, err := os.ReadFile(tmpOut); err == nil && len(outBytes) > 4096 {
				newSec, newW, newH, _ := parseMp4Metadata(outBytes)
				return outBytes, newSec, newW, newH, thumbBytes
			}
		}
	}

	return rawBytes, sec, w, h, thumbBytes
}

func uploadStatusHD(
	ctx context.Context,
	sess *SessionInstance,
	mediaType string,
	rawBytes []byte,
	mimeType string,
	caption string,
	audienceMode string,
	audienceNumbers []string,
	mentionNumbers []string,
) error {
	if sess == nil || sess.Client == nil || !sess.Client.IsLoggedIn() {
		return fmt.Errorf("nomor WA belum terhubung / belum login")
	}

	// HARD ANTI-SPAM LOCK: Cegah pembuatan Status WA berulang/spam pada nomor yang sama!
	sessKey := sess.Phone
	if sessKey == "" {
		sessKey = sess.ID
	}
	sampleLen := len(rawBytes)
	if sampleLen > 4096 {
		sampleLen = 4096
	}
	hSum := sha256.Sum256(append([]byte(sessKey+"|"+mediaType+"|"+caption+"|"), rawBytes[:sampleLen]...))
	contentHash := fmt.Sprintf("%x", hSum[:12])

	statusUploadMutex.Lock()
	lastTime := lastStatusUploadTime[sessKey]
	lastHash := lastStatusUploadHash[sessKey]
	if time.Since(lastTime) < 15*time.Second || (lastHash == contentHash && time.Since(lastTime) < 5*time.Minute) {
		statusUploadMutex.Unlock()
		addLog(fmt.Sprintf("[Anti-Spam Status] Mencegah duplikat upload status di nomor %s", sessKey))
		return nil
	}
	lastStatusUploadTime[sessKey] = time.Now()
	lastStatusUploadHash[sessKey] = contentHash
	statusUploadMutex.Unlock()

	matches := mentionRegex.FindAllString(caption, -1)
	for _, m := range matches {
		norm := normalizePhone(m)
		if len(norm) >= 9 {
			mentionNumbers = append(mentionNumbers, norm)
			caption = strings.ReplaceAll(caption, m, "@"+norm)
		}
	}

	mentionJIDs := make([]string, 0)
	seenMention := make(map[string]bool)
	for _, num := range mentionNumbers {
		norm := normalizePhone(num)
		if len(norm) >= 9 && !seenMention[norm] {
			seenMention[norm] = true
			mentionJIDs = append(mentionJIDs, norm+"@s.whatsapp.net")
			if !strings.Contains(caption, "@"+norm) {
				if strings.TrimSpace(caption) == "" {
					caption = "@" + norm
				} else {
					caption = caption + " @" + norm
				}
			}
		}
	}

	effectiveList := append([]string{}, audienceNumbers...)
	if audienceMode != "blacklist" {
		for mNorm := range seenMention {
			effectiveList = append(effectiveList, mNorm)
		}
	}
	if sess.Phone != "" {
		effectiveList = append(effectiveList, sess.Phone)
	}
	mu.Lock()
	for _, otherSess := range sessions {
		if otherSess != nil && otherSess.Phone != "" {
			effectiveList = append(effectiveList, otherSess.Phone)
		}
	}
	mu.Unlock()

	if sess.Client.Store != nil && sess.Client.Store.Contacts != nil {
		origContacts := sess.Client.Store.Contacts
		sess.Client.Store.Contacts = &TransientAudienceStore{
			ContactStore: origContacts,
			mode:         audienceMode,
			list:         effectiveList,
		}
		defer func() {
			sess.Client.Store.Contacts = origContacts
		}()
	}

	var ctxInfo *waE2E.ContextInfo
	if len(mentionJIDs) > 0 {
		ctxInfo = &waE2E.ContextInfo{
			MentionedJID: mentionJIDs,
		}
	}

	audienceDesc := fmt.Sprintf("Audiens: %s", audienceMode)
	if len(mentionJIDs) > 0 {
		audienceDesc += fmt.Sprintf(", Tag: %d orang", len(mentionJIDs))
	}

	if mediaType == "text" || len(rawBytes) == 0 {
		if strings.TrimSpace(caption) == "" {
			return fmt.Errorf("teks status tidak boleh kosong")
		}
		resp, err := sess.Client.SendMessage(ctx, types.StatusBroadcastJID, &waE2E.Message{
			ExtendedTextMessage: &waE2E.ExtendedTextMessage{
				Text:        proto.String(caption),
				ContextInfo: ctxInfo,
			},
		})
		if err != nil {
			return err
		}
		if resp.ID != "" {
			mu.Lock()
			botSentIDs[resp.ID] = true
			mu.Unlock()
		}
		addLog(fmt.Sprintf("[Status Teks] Berhasil diunggah di nomor %s (%s)", sess.Phone, audienceDesc))
		return nil
	}

	if strings.HasPrefix(mimeType, "video/") || mediaType == "video" {
		if mimeType == "" {
			mimeType = "video/mp4"
		}
		readyBytes, durSec, width, height, thumbBytes := prepareVideoForStatusHD(rawBytes)
		upCtx, cancel := context.WithTimeout(ctx, 120*time.Second)
		defer cancel()
		up, err := sess.Client.Upload(upCtx, readyBytes, whatsmeow.MediaVideo)
		if err != nil {
			return fmt.Errorf("gagal upload video HD ke server WA: %w", err)
		}
		vidMsg := &waE2E.VideoMessage{
			Caption:       proto.String(caption),
			Mimetype:      proto.String("video/mp4"),
			URL:           &up.URL,
			DirectPath:    &up.DirectPath,
			MediaKey:      up.MediaKey,
			FileEncSHA256: up.FileEncSHA256,
			FileSHA256:    up.FileSHA256,
			FileLength:    &up.FileLength,
			Seconds:       proto.Uint32(durSec),
			Width:         proto.Uint32(width),
			Height:        proto.Uint32(height),
			JPEGThumbnail: thumbBytes,
			ContextInfo:   ctxInfo,
		}
		resp, err := sess.Client.SendMessage(upCtx, types.StatusBroadcastJID, &waE2E.Message{
			VideoMessage: vidMsg,
		})
		if err != nil {
			return err
		}
		if resp.ID != "" {
			mu.Lock()
			botSentIDs[resp.ID] = true
			mu.Unlock()
		}
		addLog(fmt.Sprintf("[Status HD] Video Full HD (%d KB, %ds, %dx%d) berhasil diunggah tanpa kompresi di %s (%s)!", len(readyBytes)/1024, durSec, width, height, sess.Phone, audienceDesc))
		return nil
	}

	if mimeType == "" {
		mimeType = "image/jpeg"
	}
	up, err := sess.Client.Upload(ctx, rawBytes, whatsmeow.MediaImage)
	if err != nil {
		return fmt.Errorf("gagal upload foto HD ke server WA: %w", err)
	}
	imgMsg := &waE2E.ImageMessage{
		Caption:       proto.String(caption),
		Mimetype:      proto.String(mimeType),
		URL:           &up.URL,
		DirectPath:    &up.DirectPath,
		MediaKey:      up.MediaKey,
		FileEncSHA256: up.FileEncSHA256,
		FileSHA256:    up.FileSHA256,
		FileLength:    &up.FileLength,
		ContextInfo:   ctxInfo,
	}
	resp, err := sess.Client.SendMessage(ctx, types.StatusBroadcastJID, &waE2E.Message{
		ImageMessage: imgMsg,
	})
	if err != nil {
		return err
	}
	if resp.ID != "" {
		mu.Lock()
		botSentIDs[resp.ID] = true
		mu.Unlock()
	}
	addLog(fmt.Sprintf("[Status HD] Foto (%d KB) diunggah tanpa kompresi di %s (%s)!", len(rawBytes)/1024, sess.Phone, audienceDesc))
	return nil
}

type PendingUpstatusJob struct {
	SenderPhone string
	ChatJID     types.JID
	MediaType   string
	RawBytes    []byte
	MimeType    string
	LinkUrl     string
	Caption     string
	Mentions    []string
	ExpiresAt   time.Time
	PairSent    bool
}

var pendingUpstatusMap = make(map[string]*PendingUpstatusJob)

func extractSenderPhone(sess *SessionInstance, info types.MessageInfo) string {
	if info.IsFromMe && sess != nil && sess.Phone != "" {
		return normalizePhone(sess.Phone)
	}
	candidates := []types.JID{info.Sender, info.SenderAlt, info.Chat, info.RecipientAlt}
	for _, jid := range candidates {
		if jid.Server == types.DefaultUserServer && jid.User != "" {
			norm := normalizePhone(jid.User)
			if len(norm) >= 9 && len(norm) <= 15 {
				return norm
			}
		}
	}
	if sess != nil && sess.Client != nil && sess.Client.Store != nil && sess.Client.Store.LIDs != nil {
		for _, jid := range []types.JID{info.Sender, info.Chat} {
			if jid.Server == types.HiddenUserServer && jid.User != "" {
				if pnJID, err := sess.Client.Store.LIDs.GetPNForLID(context.Background(), jid); err == nil && pnJID.User != "" {
					norm := normalizePhone(pnJID.User)
					if len(norm) >= 9 && len(norm) <= 15 {
						return norm
					}
				}
			}
		}
	}
	return ""
}

func findLoggedInSessionByPhone(phone string) *SessionInstance {
	norm := normalizePhone(phone)
	if len(norm) < 9 {
		return nil
	}
	mu.Lock()
	defer mu.Unlock()
	if s, ok := sessions[norm]; ok && s != nil && s.Client != nil && s.Client.IsLoggedIn() {
		return s
	}
	for _, s := range sessions {
		if s == nil || s.Client == nil || !s.Client.IsLoggedIn() {
			continue
		}
		if normalizePhone(s.Phone) == norm {
			return s
		}
		if s.Client.Store != nil && s.Client.Store.ID != nil && normalizePhone(s.Client.Store.ID.User) == norm {
			return s
		}
	}
	return nil
}

func markContextInfoAsGroupStatus(ctxInfo *waE2E.ContextInfo) *waE2E.ContextInfo {
	if ctxInfo == nil {
		ctxInfo = &waE2E.ContextInfo{}
	}
	rv := reflect.ValueOf(ctxInfo)
	if rv.Kind() == reflect.Ptr && !rv.IsNil() {
		elem := rv.Elem()
		f := elem.FieldByName("IsGroupStatus")
		if f.IsValid() && f.CanSet() && f.Type() == reflect.TypeOf(proto.Bool(true)) {
			f.Set(reflect.ValueOf(proto.Bool(true)))
		}
	}
	return ctxInfo
}

func wrapAsGroupStatusMessage(inner *waE2E.Message) *waE2E.Message {
	outer := &waE2E.Message{}
	fp := &waE2E.FutureProofMessage{Message: inner}
	rv := reflect.ValueOf(outer).Elem()
	wrapped := false
	for _, fName := range []string{"GroupStatusMessageV2", "GroupStatusMessage"} {
		f := rv.FieldByName(fName)
		if f.IsValid() && f.CanSet() && f.Type() == reflect.TypeOf(fp) {
			f.Set(reflect.ValueOf(fp))
			wrapped = true
		}
	}
	if !wrapped {
		return inner
	}
	return outer
}

func uploadGroupStatusHD(
	ctx context.Context,
	sess *SessionInstance,
	groupJID types.JID,
	mediaType string,
	rawBytes []byte,
	mimeType string,
	caption string,
	mentionNumbers []string,
) error {
	if sess == nil || sess.Client == nil || !sess.Client.IsLoggedIn() {
		return fmt.Errorf("bot belum terhubung")
	}

	mentionJIDs := make([]string, 0)
	for _, num := range mentionNumbers {
		norm := normalizePhone(num)
		if len(norm) >= 9 {
			mentionJIDs = append(mentionJIDs, norm+"@s.whatsapp.net")
		}
	}
	ctxInfo := markContextInfoAsGroupStatus(&waE2E.ContextInfo{
		MentionedJID: mentionJIDs,
	})

	var innerMsg *waE2E.Message
	if mediaType == "text" || len(rawBytes) == 0 {
		if strings.TrimSpace(caption) == "" {
			return fmt.Errorf("teks status grup kosong")
		}
		innerMsg = &waE2E.Message{
			ExtendedTextMessage: &waE2E.ExtendedTextMessage{
				Text:        proto.String(caption),
				ContextInfo: ctxInfo,
			},
		}
	} else if strings.HasPrefix(mimeType, "video/") || mediaType == "video" {
		readyBytes, durSec, width, height, thumbBytes := prepareVideoForStatusHD(rawBytes)
		upCtx, cancel := context.WithTimeout(ctx, 120*time.Second)
		defer cancel()
		up, err := sess.Client.Upload(upCtx, readyBytes, whatsmeow.MediaVideo)
		if err != nil {
			return err
		}
		innerMsg = &waE2E.Message{
			VideoMessage: &waE2E.VideoMessage{
				Caption:       proto.String(caption),
				Mimetype:      proto.String("video/mp4"),
				URL:           &up.URL,
				DirectPath:    &up.DirectPath,
				MediaKey:      up.MediaKey,
				FileEncSHA256: up.FileEncSHA256,
				FileSHA256:    up.FileSHA256,
				FileLength:    &up.FileLength,
				Seconds:       proto.Uint32(durSec),
				Width:         proto.Uint32(width),
				Height:        proto.Uint32(height),
				JPEGThumbnail: thumbBytes,
				ContextInfo:   ctxInfo,
			},
		}
	} else {
		if mimeType == "" {
			mimeType = "image/jpeg"
		}
		up, err := sess.Client.Upload(ctx, rawBytes, whatsmeow.MediaImage)
		if err != nil {
			return err
		}
		innerMsg = &waE2E.Message{
			ImageMessage: &waE2E.ImageMessage{
				Caption:       proto.String(caption),
				Mimetype:      proto.String(mimeType),
				URL:           &up.URL,
				DirectPath:    &up.DirectPath,
				MediaKey:      up.MediaKey,
				FileEncSHA256: up.FileEncSHA256,
				FileSHA256:    up.FileSHA256,
				FileLength:    &up.FileLength,
				ContextInfo:   ctxInfo,
			},
		}
	}

	groupStatusMsg := wrapAsGroupStatusMessage(innerMsg)
	resp, err := sess.Client.SendMessage(ctx, groupJID, groupStatusMsg)
	if err != nil {
		resp, err = sess.Client.SendMessage(ctx, groupJID, innerMsg)
		if err != nil {
			return err
		}
	}
	if resp.ID != "" {
		mu.Lock()
		botSentIDs[resp.ID] = true
		mu.Unlock()
	}
	addLog(fmt.Sprintf("[Status Grup HD] Berhasil diunggah ke grup %s!", groupJID.String()))
	return nil
}

func executePendingUpstatusForSession(ctx context.Context, targetSess *SessionInstance, notifySess *SessionInstance, chatJID types.JID, job *PendingUpstatusJob) error {
	if targetSess == nil || targetSess.Client == nil || !targetSess.Client.IsLoggedIn() {
		return fmt.Errorf("sesi WA tujuan belum tertaut")
	}
	rawBytes := job.RawBytes
	mediaType := job.MediaType
	mimeType := job.MimeType
	if mediaType == "link" && job.LinkUrl != "" {
		var dlErr error
		if strings.Contains(strings.ToLower(job.LinkUrl), "tiktok.com") {
			rawBytes, mimeType, _, dlErr = downloadViaTikWM(job.LinkUrl, false)
		}
		if dlErr != nil || len(rawBytes) == 0 {
			rawBytes, mimeType, _, dlErr = downloadViaUniversalApi(job.LinkUrl, false)
		}
		if dlErr != nil || len(rawBytes) == 0 {
			return fmt.Errorf("gagal mengunduh link video HD: %v", dlErr)
		}
		mediaType = "video"
		mimeType = "video/mp4"
	}

	mu.Lock()
	audMode := config.DefaultStatusMode
	var audList []string
	if audMode == "blacklist" {
		audList = parsePhoneList(config.StatusExceptList)
	} else if audMode == "whitelist" {
		audList = parsePhoneList(config.StatusOnlyList)
	} else if audMode == "close_friends" {
		audList = parsePhoneList(config.StatusCloseList)
	}
	mu.Unlock()

	if err := uploadStatusHD(ctx, targetSess, mediaType, rawBytes, mimeType, job.Caption, audMode, audList, job.Mentions); err != nil {
		return err
	}
	sizeMB := float64(len(rawBytes)) / (1024.0 * 1024.0)
	msg := fmt.Sprintf(
		"[MOOD:ceria] ✅ *STATUS WA HD BERHASIL TAYANG DI WA ANDA!*\n\n"+
			"*╭─〔 🚀 DETAIL UPSTATUS HD 〕*\n"+
			"*├* 📱 *Target WA* : +%s\n"+
			"*├* 🎬 *Tipe* : %s (Anti-Kompres)\n"+
			"*├* 📦 *Ukuran* : %.2f MB\n"+
			"*╰* 💡 _Ketik .upstatus lagi kapan saja, atau ketik .putusstatus untuk melepas tautan._",
		targetSess.Phone, strings.ToUpper(mediaType), sizeMB,
	)
	_ = sendBotTextWithErr(ctx, notifySess, chatJID, msg)
	return nil
}

func sendUpstatusConsentPrompt(ctx context.Context, sess *SessionInstance, chatJID types.JID, senderPhone string) {
	var confirmGuide string
	var phoneLabel string
	if len(senderPhone) >= 9 {
		phoneLabel = "+" + senderPhone
		confirmGuide = "*╭─〔 📌 PILIHAN KONFIRMASI 〕*\n" +
			"*├* • Ketik *setuju* (untuk nomor +" + senderPhone + ")\n" +
			"*├* • Ketik *setuju 08xxxx* (jika nomor WA Anda berbeda)\n" +
			"*╰* • Ketik *batal* untuk membatalkan"
	} else {
		phoneLabel = "Nomor WA Anda"
		confirmGuide = "*╭─〔 📌 CARA KONFIRMASI (WAJIB SERTAKAN NOMOR) 〕*\n" +
			"*├* • Ketik *setuju 08xxxxxxxxxx*\n" +
			"*├*   _(contoh: setuju 081234567890)_\n" +
			"*╰* • Ketik *batal* untuk membatalkan"
	}
	consentText := fmt.Sprintf(
		"[MOOD:ramah] 🔐 *PERSETUJUAN FITUR UPSTATUS WA HD*\n\n"+
			"Menggunakan fitur *.upstatus* agar tayang langsung di Status WhatsApp Anda (%s) memerlukan *pairing* (penautan perangkat) ke WA Anda.\n\n"+
			"*╭─〔 🛡️ JAMINAN KEAMANAN & HUKUM 〕*\n"+
			"*├* 🔒 *100%% Aman* & Terenkripsi\n"+
			"*├* ⚖️ *Anti-Phishing:* Tidak digunakan untuk phishing/sadap karena saya mengerti dan mematuhi Undang-Undang (UU PDP & UU ITE)\n"+
			"*├* 🤖 *Privasi Terjaga:* AI tidak akan ikut membalas chat pribadi Anda (khusus upload Status HD)\n"+
			"*╰* ⏳ *Batas Waktu:* 5 Menit\n\n"+
			"%s",
		phoneLabel, confirmGuide,
	)
	_ = sendBotTextWithErr(ctx, sess, chatJID, consentText)
}

func isSenderAdminOrOwner(ctx context.Context, sess *SessionInstance, info types.MessageInfo) bool {
	if info.IsFromMe {
		return true
	}
	if sess == nil || sess.Client == nil {
		return false
	}
	ownID := ""
	if sess.Client.Store != nil && sess.Client.Store.ID != nil {
		ownID = sess.Client.Store.ID.User
	}
	if ownID != "" && (info.Sender.User == ownID || info.SenderAlt.User == ownID) {
		return true
	}
	if !info.IsGroup {
		return false
	}
	gInfo, err := sess.Client.GetGroupInfo(ctx, info.Chat)
	if err != nil || gInfo == nil {
		return false
	}
	sUser := info.Sender.User
	sAlt := info.SenderAlt.User
	for _, p := range gInfo.Participants {
		if (sUser != "" && (p.JID.User == sUser || p.PhoneNumber.User == sUser)) ||
			(sAlt != "" && (p.JID.User == sAlt || p.PhoneNumber.User == sAlt)) {
			return p.IsAdmin || p.IsSuperAdmin
		}
	}
	return false
}

func extractContextInfo(msg *waE2E.Message) *waE2E.ContextInfo {
	if msg == nil {
		return nil
	}
	if ext := msg.GetExtendedTextMessage(); ext != nil && ext.GetContextInfo() != nil {
		return ext.GetContextInfo()
	}
	if img := msg.GetImageMessage(); img != nil && img.GetContextInfo() != nil {
		return img.GetContextInfo()
	}
	if vid := msg.GetVideoMessage(); vid != nil && vid.GetContextInfo() != nil {
		return vid.GetContextInfo()
	}
	return nil
}

func extractQuotedText(ctxInfo *waE2E.ContextInfo) string {
	if ctxInfo == nil || ctxInfo.GetQuotedMessage() == nil {
		return ""
	}
	qm := unwrapWaMessage(ctxInfo.GetQuotedMessage())
	if qm == nil {
		return ""
	}
	if c := qm.GetConversation(); c != "" {
		return strings.TrimSpace(c)
	}
	if ext := qm.GetExtendedTextMessage(); ext != nil && ext.GetText() != "" {
		return strings.TrimSpace(ext.GetText())
	}
	if img := qm.GetImageMessage(); img != nil && img.GetCaption() != "" {
		return strings.TrimSpace(img.GetCaption())
	}
	if vid := qm.GetVideoMessage(); vid != nil && vid.GetCaption() != "" {
		return strings.TrimSpace(vid.GetCaption())
	}
	return ""
}

func isBotTaggedOrReplied(sess *SessionInstance, info types.MessageInfo, msg *waE2E.Message, text string) bool {
	mu.Lock()
	trig := strings.ToLower(strings.TrimSpace(config.GroupTrigger))
	mu.Unlock()
	if trig != "" && strings.Contains(strings.ToLower(text), trig) {
		return true
	}
	ownPhone := ""
	ownLID := ""
	if sess != nil {
		ownPhone = normalizePhone(sess.Phone)
		if sess.Client != nil && sess.Client.Store != nil {
			if sess.Client.Store.ID != nil {
				ownPhone = normalizePhone(sess.Client.Store.ID.User)
			}
			if sess.Client.Store.LID.User != "" {
				ownLID = sess.Client.Store.LID.User
			}
		}
	}
	if ownPhone != "" && strings.Contains(text, "@"+ownPhone) {
		return true
	}
	if ownLID != "" && strings.Contains(text, "@"+ownLID) {
		return true
	}
	ctxInfo := extractContextInfo(msg)
	if ctxInfo != nil {
		part := ctxInfo.GetParticipant()
		if ownPhone != "" && strings.Contains(part, ownPhone) {
			return true
		}
		if ownLID != "" && strings.Contains(part, ownLID) {
			return true
		}
		for _, m := range ctxInfo.GetMentionedJID() {
			if (ownPhone != "" && strings.Contains(m, ownPhone)) || (ownLID != "" && strings.Contains(m, ownLID)) {
				return true
			}
		}
	}
	return false
}

func isSupportedMediaLink(rawUrl string) bool {
	u := strings.ToLower(strings.TrimSpace(rawUrl))
	domains := []string{
		"tiktok.com", "vt.tiktok.com", "vm.tiktok.com",
		"instagram.com/", "instagr.am/",
		"youtube.com/", "youtu.be/", "music.youtube.com/",
		"facebook.com/", "fb.watch", "fb.gg", "fb.com/",
		"twitter.com/", "x.com/", "t.co/",
		"pinterest.com/", "pin.it/",
		"capcut.com/", "threads.net/", "mediafire.com/",
		"soundcloud.com/", "spotify.com/", "reddit.com/", "bilibili.tv/", "bilibili.com/",
	}
	for _, d := range domains {
		if strings.Contains(u, d) {
			return true
		}
	}
	if strings.HasSuffix(u, ".mp4") || strings.HasSuffix(u, ".mp3") {
		return true
	}
	return false
}

func extractFirstUrl(text string) string {
	return strings.TrimSpace(urlExtractRegex.FindString(text))
}

func normalizeYouTubeUrl(rawUrl string) (string, string) {
	trimmed := strings.TrimSpace(rawUrl)
	if m := ytVideoIdRegex.FindStringSubmatch(trimmed); len(m) >= 2 && len(m[1]) == 11 {
		vidID := m[1]
		return "https://www.youtube.com/watch?v=" + vidID, vidID
	}
	return trimmed, ""
}

func fetchUrlBytesWithHeaders(client *http.Client, mediaUrl string, maxMB int64) ([]byte, error) {
	if strings.HasPrefix(mediaUrl, "/") {
		mediaUrl = "https://www.tikwm.com" + mediaUrl
	}
	req, err := http.NewRequest("GET", mediaUrl, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36")
	req.Header.Set("Accept", "*/*")
	if strings.Contains(strings.ToLower(mediaUrl), "tikwm.com") {
		req.Header.Set("Referer", "https://www.tikwm.com/")
	}
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 && resp.StatusCode != 206 {
		return nil, fmt.Errorf("HTTP %d", resp.StatusCode)
	}
	ct := strings.ToLower(resp.Header.Get("Content-Type"))
	if strings.Contains(ct, "text/html") || strings.Contains(ct, "application/json") {
		return nil, fmt.Errorf("bukan stream media langsung (%s)", ct)
	}
	data, err := io.ReadAll(io.LimitReader(resp.Body, maxMB*1024*1024))
	if err != nil || len(data) < 4096 {
		return nil, fmt.Errorf("unduhan terlalu kecil (%d bytes)", len(data))
	}
	return data, nil
}

func netUrlQueryEscape(s string) string {
	var buf strings.Builder
	for _, b := range []byte(s) {
		if (b >= 'a' && b <= 'z') || (b >= 'A' && b <= 'Z') || (b >= '0' && b <= '9') || b == '-' || b == '_' || b == '.' || b == '~' {
			buf.WriteByte(b)
		} else {
			buf.WriteString(fmt.Sprintf("%%%02X", b))
		}
	}
	return buf.String()
}

func downloadViaTikWM(targetUrl string, audioOnly bool) ([]byte, string, string, error) {
	apiUrl := "https://www.tikwm.com/api/?url=" + netUrlQueryEscape(targetUrl) + "&hd=1"
	client := &http.Client{Timeout: 60 * time.Second}
	req, _ := http.NewRequest("GET", apiUrl, nil)
	req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/131.0.0.0")
	resp, err := client.Do(req)
	if err != nil {
		return nil, "", "", err
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, "", "", err
	}
	var parsed struct {
		Code int `json:"code"`
		Data struct {
			Title  string `json:"title"`
			HdPlay string `json:"hdplay"`
			Play   string `json:"play"`
			WmPlay string `json:"wmplay"`
			Music  string `json:"music"`
			Author struct {
				Nickname string `json:"nickname"`
			} `json:"author"`
		} `json:"data"`
	}
	if err := json.Unmarshal(body, &parsed); err != nil || parsed.Code != 0 {
		return nil, "", "", fmt.Errorf("tikwm gagal memproses link")
	}
	if audioOnly && parsed.Data.Music != "" {
		mediaBytes, err := fetchUrlBytesWithHeaders(client, parsed.Data.Music, 60)
		if err != nil {
			return nil, "", "", err
		}
		caption := fmt.Sprintf("🎵 *AUDIO MP3 BERHASIL*\n• *Pembuat:* %s\n• *Judul:* %s", parsed.Data.Author.Nickname, parsed.Data.Title)
		return mediaBytes, "audio/mpeg", caption, nil
	}

	var mediaBytes []byte
	var dlErr error
	for _, sUrl := range []string{parsed.Data.HdPlay, parsed.Data.Play, parsed.Data.WmPlay} {
		if strings.TrimSpace(sUrl) == "" {
			continue
		}
		mediaBytes, dlErr = fetchUrlBytesWithHeaders(client, sUrl, 120)
		if dlErr == nil && len(mediaBytes) > 4096 {
			break
		}
	}
	if len(mediaBytes) < 4096 {
		return nil, "", "", fmt.Errorf("file unduhan kosong: %v", dlErr)
	}
	if audioOnly {
		mediaBytes, _ = convertVideoBytesToMp3IfNeeded(mediaBytes, "audio/mpeg", true)
		return mediaBytes, "audio/mpeg", fmt.Sprintf("🎵 *AUDIO MP3 BERHASIL*\n• *Pembuat:* %s\n• *Judul:* %s", parsed.Data.Author.Nickname, parsed.Data.Title), nil
	}
	sizeMB := float64(len(mediaBytes)) / (1024.0 * 1024.0)
	caption := fmt.Sprintf("📥 *DOWNLOADER HD BERHASIL*\n• *Pembuat:* %s\n• *Kualitas:* Full HD (%.2f MB)\n• *Judul:* %s", parsed.Data.Author.Nickname, sizeMB, parsed.Data.Title)
	return mediaBytes, "video/mp4", caption, nil
}

func isLikelyImageOrThumbUrl(u string) bool {
	low := strings.ToLower(u)
	for _, bad := range []string{".jpg", ".jpeg", ".png", ".webp", ".gif", ".svg", "i.ytimg.com", "yt3.ggpht.com", "avatars", "thumbnail", "cover"} {
		if strings.Contains(low, bad) {
			return true
		}
	}
	return false
}

func scoreMediaCandidate(m map[string]interface{}, u string, audioOnly bool) int {
	if isLikelyImageOrThumbUrl(u) {
		return -9999
	}
	score := 20
	lowUrl := strings.ToLower(u)
	metaStr := lowUrl
	for k, v := range m {
		if s, ok := v.(string); ok {
			metaStr += " " + strings.ToLower(k) + ":" + strings.ToLower(s)
		}
	}
	if audioOnly {
		if strings.Contains(metaStr, "mp3") || strings.Contains(metaStr, "audio") || strings.Contains(metaStr, "m4a") || strings.Contains(metaStr, "opus") {
			score += 100
		}
		return score
	}
	if strings.Contains(metaStr, "1080") || strings.Contains(metaStr, "fhd") || strings.Contains(metaStr, "fullhd") || strings.Contains(metaStr, "hdplay") || strings.Contains(metaStr, "no_watermark_hd") {
		score += 90
	}
	if strings.Contains(metaStr, "720") || strings.Contains(metaStr, "hd") || strings.Contains(metaStr, "high") {
		score += 65
	}
	if strings.Contains(metaStr, "480") || strings.Contains(metaStr, "360") {
		score += 30
	}
	if strings.Contains(metaStr, "audio") && !strings.Contains(metaStr, "video") && !strings.Contains(metaStr, "mp4") {
		score -= 80
	}
	return score
}

func collectMediaCandidates(v interface{}, audioOnly bool, out *[]struct {
	url   string
	score int
}) {
	switch val := v.(type) {
	case string:
		s := strings.TrimSpace(val)
		if (strings.HasPrefix(s, "http://") || strings.HasPrefix(s, "https://")) && !isLikelyImageOrThumbUrl(s) {
			low := strings.ToLower(s)
			if audioOnly && (strings.Contains(low, ".mp3") || strings.Contains(low, "audio") || strings.Contains(low, "music") || strings.Contains(low, "m4a") || strings.Contains(low, "dl") || strings.Contains(low, "download") || strings.Contains(low, "savetube") || strings.Contains(low, "oceansaver") || strings.Contains(low, "googlevideo")) {
				*out = append(*out, struct {
					url   string
					score int
				}{s, 55})
			} else if !audioOnly && (strings.Contains(low, ".mp4") || strings.Contains(low, "video") || strings.Contains(low, "play") || strings.Contains(low, "googlevideo") || strings.Contains(low, "cdninstagram") || strings.Contains(low, "fbcdn") || strings.Contains(low, "twimg") || strings.Contains(low, "savetube") || strings.Contains(low, "oceansaver") || strings.Contains(low, "y2mate") || strings.Contains(low, "download") || strings.Contains(low, "cdn")) {
				*out = append(*out, struct {
					url   string
					score int
				}{s, 35})
			}
		}
	case map[string]interface{}:
		priorityKeys := []string{
			"hdplay", "hd", "hd_url", "video_hd", "download_url", "downloadUrl",
			"dlink", "dl", "download", "mp4", "video", "videoUrl", "play",
			"mp3", "audio", "music", "url", "link", "media",
		}
		for idx, k := range priorityKeys {
			if sub, exists := val[k]; exists {
				if s, ok := sub.(string); ok && (strings.HasPrefix(s, "http://") || strings.HasPrefix(s, "https://")) && !isLikelyImageOrThumbUrl(s) {
					sc := scoreMediaCandidate(val, s, audioOnly) + (len(priorityKeys)-idx)*3
					if sc > 0 {
						*out = append(*out, struct {
							url   string
							score int
						}{s, sc})
					}
				}
			}
		}
		for k, sub := range val {
			lowK := strings.ToLower(k)
			if lowK == "thumbnail" || lowK == "thumb" || lowK == "cover" || lowK == "avatar" || lowK == "image" {
				continue
			}
			collectMediaCandidates(sub, audioOnly, out)
		}
	case []interface{}:
		for _, item := range val {
			collectMediaCandidates(item, audioOnly, out)
		}
	}
}

func findMediaUrlInJson(v interface{}, audioOnly bool) string {
	var cands []struct {
		url   string
		score int
	}
	collectMediaCandidates(v, audioOnly, &cands)
	bestUrl := ""
	bestScore := -999
	for _, c := range cands {
		if c.score > bestScore {
			bestScore = c.score
			bestUrl = c.url
		}
	}
	return bestUrl
}

func ensureYtDlpAvailable() string {
	for _, p := range []string{"/opt/gemini-wabot/yt-dlp", "/usr/local/bin/yt-dlp", "yt-dlp"} {
		if path, err := exec.LookPath(p); err == nil && path != "" {
			return path
		}
		if st, err := os.Stat(p); err == nil && !st.IsDir() {
			return p
		}
	}
	if runtime.GOOS == "linux" && runtime.GOARCH == "amd64" {
		target := "/opt/gemini-wabot/yt-dlp"
		_ = os.MkdirAll("/opt/gemini-wabot", 0755)
		dlClient := &http.Client{Timeout: 60 * time.Second}
		if resp, err := dlClient.Get("https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_linux"); err == nil {
			defer resp.Body.Close()
			if resp.StatusCode == 200 {
				if binData, err := io.ReadAll(io.LimitReader(resp.Body, 50*1024*1024)); err == nil && len(binData) > 1000000 {
					if os.WriteFile(target, binData, 0755) == nil {
						return target
					}
				}
			}
		}
	}
	return ""
}

func convertVideoBytesToMp3IfNeeded(rawBytes []byte, currentMime string, audioOnly bool) ([]byte, string) {
	if !audioOnly {
		return rawBytes, currentMime
	}
	if len(rawBytes) > 4 && (string(rawBytes[:3]) == "ID3" || (rawBytes[0] == 0xFF && (rawBytes[1]&0xE0) == 0xE0)) {
		return rawBytes, "audio/mpeg"
	}
	ffmpegPath, err := exec.LookPath("ffmpeg")
	if err != nil || ffmpegPath == "" {
		return rawBytes, "audio/mpeg"
	}
	tmpIn := filepath.Join(os.TempDir(), fmt.Sprintf("conv_in_%d.mp4", time.Now().UnixNano()))
	tmpOut := filepath.Join(os.TempDir(), fmt.Sprintf("conv_out_%d.mp3", time.Now().UnixNano()))
	defer func() {
		_ = os.Remove(tmpIn)
		_ = os.Remove(tmpOut)
	}()
	if os.WriteFile(tmpIn, rawBytes, 0600) != nil {
		return rawBytes, "audio/mpeg"
	}
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	if exec.CommandContext(ctx, ffmpegPath, "-y", "-i", tmpIn, "-vn", "-acodec", "libmp3lame", "-ab", "192k", "-ar", "44100", tmpOut).Run() == nil {
		if mp3Bytes, err := os.ReadFile(tmpOut); err == nil && len(mp3Bytes) > 2048 {
			return mp3Bytes, "audio/mpeg"
		}
	}
	return rawBytes, "audio/mpeg"
}

func downloadViaYtDlp(targetUrl string, audioOnly bool) ([]byte, string, string, error) {
	ytDlpBin := ensureYtDlpAvailable()
	if ytDlpBin == "" {
		return nil, "", "", fmt.Errorf("yt-dlp tidak tersedia")
	}
	cleanUrl, _ := normalizeYouTubeUrl(targetUrl)

	// Coba 3 profil client berurutan (web_safari & tv bebas PO Token di tahun 2026!)
	extractorProfiles := []string{
		"youtube:player_client=web_safari,tv",
		"youtube:player_client=mweb,tv_embedded,web_embedded",
		"",
	}

	for _, prof := range extractorProfiles {
		outBase := filepath.Join(os.TempDir(), fmt.Sprintf("ytdlp_%d", time.Now().UnixNano()))
		ctx, cancel := context.WithTimeout(context.Background(), 75*time.Second)

		var args []string
		args = append(args, "--no-playlist", "--no-warnings", "--geo-bypass", "--no-check-certificates")
		if prof != "" {
			args = append(args, "--extractor-args", prof)
		}
		if audioOnly {
			args = append(args,
				"-f", "bestaudio/best",
				"-x", "--audio-format", "mp3", "--audio-quality", "0",
				"-o", outBase+".%(ext)s",
				cleanUrl,
			)
		} else {
			args = append(args,
				"-f", "bestvideo[height<=1080][ext=mp4]+bestaudio[ext=m4a]/best[height<=1080][ext=mp4]/best[ext=mp4]/18/best",
				"--merge-output-format", "mp4",
				"-o", outBase+".%(ext)s",
				cleanUrl,
			)
		}

		_ = exec.CommandContext(ctx, ytDlpBin, args...).Run()
		cancel()

		matches, _ := filepath.Glob(outBase + "*")
		for _, fPath := range matches {
			data, err := os.ReadFile(fPath)
			_ = os.Remove(fPath)
			if err == nil && len(data) > 4096 {
				sizeMB := float64(len(data)) / (1024.0 * 1024.0)
				if audioOnly {
					data, _ = convertVideoBytesToMp3IfNeeded(data, "audio/mpeg", true)
					return data, "audio/mpeg", fmt.Sprintf("🎵 *AUDIO MP3 BERHASIL* (%.2f MB)\n• *Sumber:* %s", sizeMB, cleanUrl), nil
				}
				return data, "video/mp4", fmt.Sprintf("📥 *DOWNLOADER HD BERHASIL*\n• *Kualitas:* Full HD (%.2f MB)\n• *Sumber:* %s", sizeMB, cleanUrl), nil
			}
		}
	}
	return nil, "", "", fmt.Errorf("yt-dlp gagal mengunduh")
}

func downloadViaPipedYouTube(videoID string, audioOnly bool) ([]byte, string, string, error) {
	if len(videoID) != 11 {
		return nil, "", "", fmt.Errorf("videoID youtube tidak valid")
	}
	instances := []string{
		"https://pipedapi.kavin.rocks",
		"https://pipedapi.tokhmi.xyz",
		"https://pipedapi.moomoo.me",
		"https://pipedapi.syncpundit.io",
		"https://api.piped.private.coffee",
	}
	client := &http.Client{Timeout: 35 * time.Second}
	for _, inst := range instances {
		req, err := http.NewRequest("GET", inst+"/streams/"+videoID, nil)
		if err != nil {
			continue
		}
		req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/131.0.0.0")
		resp, err := client.Do(req)
		if err != nil {
			continue
		}
		raw, _ := io.ReadAll(resp.Body)
		_ = resp.Body.Close()
		if resp.StatusCode != 200 || len(raw) == 0 {
			continue
		}
		var parsed struct {
			Title        string `json:"title"`
			AudioStreams []struct {
				URL      string `json:"url"`
				MimeType string `json:"mimeType"`
				Bitrate  int    `json:"bitrate"`
			} `json:"audioStreams"`
			VideoStreams []struct {
				URL       string `json:"url"`
				Format    string `json:"format"`
				Quality   string `json:"quality"`
				VideoOnly bool   `json:"videoOnly"`
			} `json:"videoStreams"`
		}
		if json.Unmarshal(raw, &parsed) != nil {
			continue
		}
		if audioOnly && len(parsed.AudioStreams) > 0 {
			bestAud := parsed.AudioStreams[0].URL
			bestBr := parsed.AudioStreams[0].Bitrate
			for _, a := range parsed.AudioStreams {
				if a.Bitrate > bestBr && a.URL != "" {
					bestBr = a.Bitrate
					bestAud = a.URL
				}
			}
			if bestAud != "" {
				if mediaBytes, dlErr := fetchUrlBytesWithHeaders(client, bestAud, 100); dlErr == nil && len(mediaBytes) > 4096 {
					mediaBytes, _ = convertVideoBytesToMp3IfNeeded(mediaBytes, "audio/mpeg", true)
					sizeMB := float64(len(mediaBytes)) / (1024.0 * 1024.0)
					return mediaBytes, "audio/mpeg", fmt.Sprintf("🎵 *YOUTUBE MP3 BERHASIL*\n• *Judul:* %s\n• *Ukuran:* %.2f MB", parsed.Title, sizeMB), nil
				}
			}
		} else if !audioOnly && len(parsed.VideoStreams) > 0 {
			var chosenUrl string
			for _, v := range parsed.VideoStreams {
				if !v.VideoOnly && v.URL != "" && (strings.Contains(v.Quality, "1080") || strings.Contains(v.Quality, "720")) {
					chosenUrl = v.URL
					break
				}
			}
			if chosenUrl == "" {
				for _, v := range parsed.VideoStreams {
					if !v.VideoOnly && v.URL != "" {
						chosenUrl = v.URL
						break
					}
				}
			}
			if chosenUrl != "" {
				if mediaBytes, dlErr := fetchUrlBytesWithHeaders(client, chosenUrl, 120); dlErr == nil && len(mediaBytes) > 4096 {
					sizeMB := float64(len(mediaBytes)) / (1024.0 * 1024.0)
					return mediaBytes, "video/mp4", fmt.Sprintf("📥 *YOUTUBE HD BERHASIL*\n• *Judul:* %s\n• *Ukuran:* %.2f MB", parsed.Title, sizeMB), nil
				}
			}
		}
	}
	return nil, "", "", fmt.Errorf("piped instances tidak merespons")
}

func downloadViaOceanSaverYouTube(targetUrl string, audioOnly bool) ([]byte, string, string, error) {
	cleanUrl, _ := normalizeYouTubeUrl(targetUrl)
	client := &http.Client{Timeout: 45 * time.Second}
	formats := []string{"720", "1080", "480", "360"}
	if audioOnly {
		formats = []string{"mp3", "m4a"}
	}
	for _, format := range formats {
		initUrl := "https://p.oceansaver.in/ajax/download.php?format=" + format + "&url=" + netUrlQueryEscape(cleanUrl)
		req, err := http.NewRequest("GET", initUrl, nil)
		if err != nil {
			continue
		}
		req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/131.0.0.0")
		req.Header.Set("Referer", "https://oceansaver.in/")
		resp, err := client.Do(req)
		if err != nil {
			continue
		}
		raw, _ := io.ReadAll(resp.Body)
		_ = resp.Body.Close()

		var initRes struct {
			Success bool   `json:"success"`
			ID      string `json:"id"`
			Title   string `json:"title"`
		}
		if json.Unmarshal(raw, &initRes) != nil || !initRes.Success || initRes.ID == "" {
			continue
		}

		for i := 0; i < 20; i++ {
			time.Sleep(1500 * time.Millisecond)
			progUrl := "https://p.oceansaver.in/ajax/progress.php?id=" + netUrlQueryEscape(initRes.ID)
			pReq, _ := http.NewRequest("GET", progUrl, nil)
			pReq.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/131.0.0.0")
			pReq.Header.Set("Referer", "https://oceansaver.in/")
			pResp, err := client.Do(pReq)
			if err != nil {
				continue
			}
			pRaw, _ := io.ReadAll(pResp.Body)
			_ = pResp.Body.Close()
			var progRes struct {
				Success     int    `json:"success"`
				DownloadUrl string `json:"download_url"`
			}
			if json.Unmarshal(pRaw, &progRes) == nil && progRes.Success == 1 && progRes.DownloadUrl != "" {
				mediaBytes, dlErr := fetchUrlBytesWithHeaders(client, progRes.DownloadUrl, 120)
				if dlErr == nil && len(mediaBytes) > 4096 {
					sizeMB := float64(len(mediaBytes)) / (1024.0 * 1024.0)
					if audioOnly {
						mediaBytes, _ = convertVideoBytesToMp3IfNeeded(mediaBytes, "audio/mpeg", true)
						return mediaBytes, "audio/mpeg", fmt.Sprintf("🎵 *YOUTUBE MP3 BERHASIL*\n• *Judul:* %s\n• *Ukuran:* %.2f MB", initRes.Title, sizeMB), nil
					}
					return mediaBytes, "video/mp4", fmt.Sprintf("📥 *YOUTUBE HD BERHASIL*\n• *Judul:* %s\n• *Kualitas:* %sp HD (%.2f MB)", initRes.Title, format, sizeMB), nil
				}
				break
			}
		}
	}
	return nil, "", "", fmt.Errorf("oceansaver gagal")
}

func downloadViaVxTwitter(targetUrl string, audioOnly bool) ([]byte, string, string, error) {
	u := strings.Replace(targetUrl, "https://x.com/", "https://api.vxtwitter.com/", 1)
	u = strings.Replace(u, "https://twitter.com/", "https://api.vxtwitter.com/", 1)
	if !strings.Contains(u, "api.vxtwitter.com/") {
		return nil, "", "", fmt.Errorf("bukan link twitter")
	}
	client := &http.Client{Timeout: 35 * time.Second}
	req, _ := http.NewRequest("GET", u, nil)
	req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/131.0.0.0")
	resp, err := client.Do(req)
	if err != nil {
		return nil, "", "", err
	}
	raw, _ := io.ReadAll(resp.Body)
	_ = resp.Body.Close()
	var vx struct {
		Text          string   `json:"text"`
		UserName      string   `json:"user_name"`
		MediaURLs     []string `json:"mediaURLs"`
		MediaExtended []struct {
			URL  string `json:"url"`
			Type string `json:"type"`
		} `json:"media_extended"`
	}
	if json.Unmarshal(raw, &vx) != nil {
		return nil, "", "", fmt.Errorf("vxtwitter gagal parse")
	}
	mediaUrl := ""
	for _, m := range vx.MediaExtended {
		if m.Type == "video" || m.Type == "gif" || strings.Contains(m.URL, ".mp4") {
			mediaUrl = m.URL
			break
		}
	}
	if mediaUrl == "" && len(vx.MediaURLs) > 0 {
		mediaUrl = vx.MediaURLs[0]
	}
	if mediaUrl == "" {
		return nil, "", "", fmt.Errorf("tidak ada video di tweet")
	}
	mediaBytes, err := fetchUrlBytesWithHeaders(client, mediaUrl, 120)
	if err != nil {
		return nil, "", "", err
	}
	if audioOnly {
		mediaBytes, _ = convertVideoBytesToMp3IfNeeded(mediaBytes, "audio/mpeg", true)
		return mediaBytes, "audio/mpeg", fmt.Sprintf("🎵 *X/TWITTER MP3 BERHASIL*\n• *Akun:* %s", vx.UserName), nil
	}
	sizeMB := float64(len(mediaBytes)) / (1024.0 * 1024.0)
	return mediaBytes, "video/mp4", fmt.Sprintf("📥 *X/TWITTER HD BERHASIL*\n• *Akun:* %s\n• *Ukuran:* %.2f MB", vx.UserName, sizeMB), nil
}

func downloadViaDdInstagram(targetUrl string, audioOnly bool) ([]byte, string, string, error) {
	if !strings.Contains(strings.ToLower(targetUrl), "instagram.com") && !strings.Contains(strings.ToLower(targetUrl), "instagr.am") {
		return nil, "", "", fmt.Errorf("bukan link instagram")
	}
	ddUrl := strings.Replace(targetUrl, "instagram.com", "ddinstagram.com", 1)
	client := &http.Client{Timeout: 30 * time.Second}
	req, _ := http.NewRequest("GET", ddUrl, nil)
	req.Header.Set("User-Agent", "TelegramBot (like TwitterBot)")
	resp, err := client.Do(req)
	if err != nil {
		return nil, "", "", err
	}
	htmlBytes, _ := io.ReadAll(resp.Body)
	_ = resp.Body.Close()
	htmlStr := string(htmlBytes)
	reOg := regexp.MustCompile(`property="og:video(?::secure_url)?"\s+content="([^"]+)"`)
	matches := reOg.FindStringSubmatch(htmlStr)
	if len(matches) < 2 {
		reAlt := regexp.MustCompile(`content="([^"]+\.mp4[^"]*)"`)
		matches = reAlt.FindStringSubmatch(htmlStr)
	}
	if len(matches) >= 2 {
		vidUrl := strings.ReplaceAll(matches[1], "&amp;", "&")
		if strings.HasPrefix(vidUrl, "/") {
			vidUrl = "https://www.ddinstagram.com" + vidUrl
		}
		mediaBytes, dlErr := fetchUrlBytesWithHeaders(client, vidUrl, 120)
		if dlErr == nil && len(mediaBytes) > 4096 {
			if audioOnly {
				mediaBytes, _ = convertVideoBytesToMp3IfNeeded(mediaBytes, "audio/mpeg", true)
				return mediaBytes, "audio/mpeg", "🎵 *INSTAGRAM MP3 BERHASIL*", nil
			}
			sizeMB := float64(len(mediaBytes)) / (1024.0 * 1024.0)
			return mediaBytes, "video/mp4", fmt.Sprintf("📥 *INSTAGRAM HD BERHASIL* (%.2f MB)", sizeMB), nil
		}
	}
	return nil, "", "", fmt.Errorf("ddinstagram tidak menemukan stream")
}

func downloadViaUniversalApi(targetUrl string, audioOnly bool) ([]byte, string, string, error) {
	lowTarget := strings.ToLower(targetUrl)
	cleanTarget, ytVidID := normalizeYouTubeUrl(targetUrl)

	// 1. Jika YouTube: coba yt-dlp (web_safari/tv), OceanSaver, dan Piped secara berurutan!
	if ytVidID != "" || strings.Contains(lowTarget, "youtube.com") || strings.Contains(lowTarget, "youtu.be") {
		if b, m, c, err := downloadViaYtDlp(cleanTarget, audioOnly); err == nil && len(b) > 4096 {
			return b, m, c, nil
		}
		if b, m, c, err := downloadViaOceanSaverYouTube(cleanTarget, audioOnly); err == nil && len(b) > 4096 {
			return b, m, c, nil
		}
		if ytVidID != "" {
			if b, m, c, err := downloadViaPipedYouTube(ytVidID, audioOnly); err == nil && len(b) > 4096 {
				return b, m, c, nil
			}
		}
	}

	// 2. Jika X/Twitter atau Instagram: coba fast scraper dulu
	if strings.Contains(lowTarget, "x.com/") || strings.Contains(lowTarget, "twitter.com/") {
		if b, m, c, err := downloadViaVxTwitter(targetUrl, audioOnly); err == nil && len(b) > 4096 {
			return b, m, c, nil
		}
	}
	if strings.Contains(lowTarget, "instagram.com") || strings.Contains(lowTarget, "instagr.am") {
		if b, m, c, err := downloadViaDdInstagram(targetUrl, audioOnly); err == nil && len(b) > 4096 {
			return b, m, c, nil
		}
	}

	// 3. Coba yt-dlp untuk situs lainnya (IG, FB, Pinterest, CapCut, SoundCloud, dll)
	if ytVidID == "" {
		if b, m, c, err := downloadViaYtDlp(cleanTarget, audioOnly); err == nil && len(b) > 4096 {
			return b, m, c, nil
		}
	}

	// 4. Multi-Provider REST APIs dengan URL yang sudah dinormalisasi
	client := &http.Client{Timeout: 45 * time.Second}
	encUrl := netUrlQueryEscape(cleanTarget)
	var endpoints []string
	if ytVidID != "" || strings.Contains(lowTarget, "youtube.com") || strings.Contains(lowTarget, "youtu.be") {
		if audioOnly {
			endpoints = append(endpoints,
				"https://api.siputzx.my.id/api/d/ytmp3?url="+encUrl,
				"https://api.ryzendesu.vip/api/downloader/ytmp3?url="+encUrl,
				"https://api.agatz.xyz/api/ytmp3?url="+encUrl,
				"https://api.vreden.my.id/api/ytmp3?url="+encUrl,
				"https://widipe.com/download/ytdl?url="+encUrl,
				"https://btch.us.kg/download/ytdl?url="+encUrl,
			)
		} else {
			endpoints = append(endpoints,
				"https://api.siputzx.my.id/api/d/ytmp4?url="+encUrl,
				"https://api.ryzendesu.vip/api/downloader/ytmp4?url="+encUrl+"&quality=1080",
				"https://api.ryzendesu.vip/api/downloader/ytmp4?url="+encUrl,
				"https://api.agatz.xyz/api/ytmp4?url="+encUrl,
				"https://api.vreden.my.id/api/ytmp4?url="+encUrl,
				"https://widipe.com/download/ytdl?url="+encUrl,
				"https://btch.us.kg/download/ytdl?url="+encUrl,
			)
		}
	} else if strings.Contains(lowTarget, "instagram.com") || strings.Contains(lowTarget, "instagr.am") {
		endpoints = append(endpoints,
			"https://api.siputzx.my.id/api/d/igdl?url="+encUrl,
			"https://api.ryzendesu.vip/api/downloader/igdl?url="+encUrl,
			"https://api.agatz.xyz/api/instagram?url="+encUrl,
			"https://api.vreden.my.id/api/igdownload?url="+encUrl,
			"https://widipe.com/download/igdl?url="+encUrl,
		)
	} else if strings.Contains(lowTarget, "facebook.com") || strings.Contains(lowTarget, "fb.watch") || strings.Contains(lowTarget, "fb.gg") {
		endpoints = append(endpoints,
			"https://api.siputzx.my.id/api/d/facebook?url="+encUrl,
			"https://api.ryzendesu.vip/api/downloader/fbdl?url="+encUrl,
			"https://api.agatz.xyz/api/facebook?url="+encUrl,
			"https://api.vreden.my.id/api/fbdl?url="+encUrl,
			"https://widipe.com/download/fbdl?url="+encUrl,
		)
	}
	endpoints = append(endpoints,
		"https://api.siputzx.my.id/api/d/allinone?url="+encUrl,
		"https://api.ryzendesu.vip/api/downloader/allinone?url="+encUrl,
		"https://api.tiklydown.eu.org/api/download?url="+encUrl,
	)

	for _, ep := range endpoints {
		req, err := http.NewRequest("GET", ep, nil)
		if err != nil {
			continue
		}
		req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/131.0.0.0")
		resp, err := client.Do(req)
		if err != nil {
			continue
		}
		raw, _ := io.ReadAll(resp.Body)
		_ = resp.Body.Close()
		if resp.StatusCode != 200 || len(raw) == 0 {
			continue
		}
		var generic map[string]interface{}
		if json.Unmarshal(raw, &generic) == nil {
			foundUrl := findMediaUrlInJson(generic, audioOnly)
			if foundUrl != "" {
				mediaBytes, dlErr := fetchUrlBytesWithHeaders(client, foundUrl, 120)
				if dlErr == nil && len(mediaBytes) > 4096 {
					sizeMB := float64(len(mediaBytes)) / (1024.0 * 1024.0)
					if audioOnly {
						mediaBytes, _ = convertVideoBytesToMp3IfNeeded(mediaBytes, "audio/mpeg", true)
						return mediaBytes, "audio/mpeg", fmt.Sprintf("🎵 *AUDIO MP3 BERHASIL* (%.2f MB)\n• *Sumber:* %s", sizeMB, cleanTarget), nil
					}
					return mediaBytes, "video/mp4", fmt.Sprintf("📥 *DOWNLOADER HD BERHASIL* (%.2f MB)\n• *Sumber:* %s", sizeMB, cleanTarget), nil
				}
			}
		}
	}

	if strings.HasSuffix(lowTarget, ".mp4") || strings.HasSuffix(lowTarget, ".mp3") {
		mediaBytes, dlErr := fetchUrlBytesWithHeaders(client, targetUrl, 120)
		if dlErr == nil && len(mediaBytes) > 4096 {
			if strings.HasSuffix(lowTarget, ".mp3") || audioOnly {
				mediaBytes, _ = convertVideoBytesToMp3IfNeeded(mediaBytes, "audio/mpeg", true)
				return mediaBytes, "audio/mpeg", "🎵 *AUDIO MP3 BERHASIL*", nil
			}
			return mediaBytes, "video/mp4", "📥 *DOWNLOADER HD BERHASIL*", nil
		}
	}
	return nil, "", "", fmt.Errorf("gagal mengunduh dari link tersebut")
}

func processAndSendLinkDownload(ctx context.Context, sess *SessionInstance, info types.MessageInfo, targetUrl string, audioOnly bool) {
	sendMsgReaction(ctx, sess, info, "⏳")
	addLog(fmt.Sprintf("[Downloader] Mengunduh link: %s (MP3=%v)", targetUrl, audioOnly))

	var mediaBytes []byte
	var mimeType string
	var caption string
	var err error

	if strings.Contains(strings.ToLower(targetUrl), "tiktok.com") {
		mediaBytes, mimeType, caption, err = downloadViaTikWM(targetUrl, audioOnly)
	}
	if err != nil || len(mediaBytes) == 0 {
		mediaBytes, mimeType, caption, err = downloadViaUniversalApi(targetUrl, audioOnly)
	}
	if err != nil || len(mediaBytes) == 0 {
		addLog("[Downloader Gagal -> Reaksi ❌] " + fmt.Sprint(err))
		sendMsgReaction(ctx, sess, info, "❌")
		return
	}

	if strings.HasPrefix(mimeType, "audio/") || audioOnly {
		upCtx, cancel := context.WithTimeout(ctx, 90*time.Second)
		defer cancel()
		up, upErr := sess.Client.Upload(upCtx, mediaBytes, whatsmeow.MediaAudio)
		if upErr != nil {
			sendMsgReaction(ctx, sess, info, "❌")
			return
		}
		audMsg := &waE2E.AudioMessage{
			Mimetype:      proto.String("audio/mpeg"),
			URL:           &up.URL,
			DirectPath:    &up.DirectPath,
			MediaKey:      up.MediaKey,
			FileEncSHA256: up.FileEncSHA256,
			FileSHA256:    up.FileSHA256,
			FileLength:    &up.FileLength,
			PTT:           proto.Bool(false),
		}
		resp, sendErr := sess.Client.SendMessage(upCtx, info.Chat, &waE2E.Message{AudioMessage: audMsg})
		if sendErr != nil {
			sendMsgReaction(ctx, sess, info, "❌")
			return
		}
		if resp.ID != "" {
			mu.Lock()
			botSentIDs[resp.ID] = true
			mu.Unlock()
		}
		sendMsgReaction(ctx, sess, info, "✅")
		return
	}

	mu.Lock()
	lastChatVideoCache[info.Chat.String()] = mediaBytes
	mu.Unlock()

	durSec, width, height, _ := parseMp4Metadata(mediaBytes)
	upCtx, cancel := context.WithTimeout(ctx, 120*time.Second)
	defer cancel()
	up, upErr := sess.Client.Upload(upCtx, mediaBytes, whatsmeow.MediaVideo)
	if upErr != nil {
		sendMsgReaction(ctx, sess, info, "❌")
		return
	}
	vidMsg := &waE2E.VideoMessage{
		Caption:       proto.String(caption),
		Mimetype:      proto.String("video/mp4"),
		URL:           &up.URL,
		DirectPath:    &up.DirectPath,
		MediaKey:      up.MediaKey,
		FileEncSHA256: up.FileEncSHA256,
		FileSHA256:    up.FileSHA256,
		FileLength:    &up.FileLength,
		Seconds:       proto.Uint32(durSec),
		Width:         proto.Uint32(width),
		Height:        proto.Uint32(height),
	}
	resp, sendErr := sess.Client.SendMessage(upCtx, info.Chat, &waE2E.Message{VideoMessage: vidMsg})
	if sendErr != nil {
		sendMsgReaction(ctx, sess, info, "❌")
		return
	}
	if resp.ID != "" {
		mu.Lock()
		botSentIDs[resp.ID] = true
		mu.Unlock()
	}
	sendMsgReaction(ctx, sess, info, "✅")
	addLog(fmt.Sprintf("[Downloader Sukses ✅] Video (%d KB) terkirim ke %s", len(mediaBytes)/1024, info.Chat.String()))
}

func buildFullTextMenu() string {
	mu.Lock()
	bName := strings.TrimSpace(config.BotName)
	mu.Unlock()
	if bName == "" {
		bName = "DodosBot"
	}
	return fmt.Sprintf(
		"*╭─〔 ⚡ %s MENU v7.0 〕*\n"+
			"*├* _Pilih lewat tombol 🗂️ Menu List_\n"+
			"*╰* _atau ketik perintah langsung:_\n\n"+
			"*╭─〔 🏠 MAIN (.menu main) 〕*\n"+
			"*├* • .menu\n"+
			"*├* • .menulist\n"+
			"*├* • .menuteks\n"+
			"*├* • .model\n"+
			"*├* • .banner on / off\n"+
			"*├* • .bot-active\n"+
			"*├* • .bot-off\n"+
			"*╰* • .reset\n\n"+
			"*╭─〔 📥 DOWNLOADER (.menu downloader) 〕*\n"+
			"*├* • .dl [link YouTube/IG/TikTok/FB/X]\n"+
			"*├* • .mp3 [link video ➔ audio MP3]\n"+
			"*├* • .ytmp4 [link YouTube HD]\n"+
			"*├* • .ytmp3 [link YouTube MP3]\n"+
			"*├* • _Chat Pribadi: kirim link langsung_\n"+
			"*╰* • _Grup: @nomorbot + link video_\n\n"+
			"*╭─〔 📸 STATUS HD (.menu status) 〕*\n"+
			"*├* • .upstatus [link / reply media]\n"+
			"*├* • .putusstatus (lepas tautan)\n"+
			"*├* • _Japri: tayang ke Status WA Anda_\n"+
			"*╰* • _Grup: tayang ke Status Grup (Admin)_\n\n"+
			"*╭─〔 👥 GROUP (.menu group) 〕*\n"+
			"*├* • .kick (reply target)\n"+
			"*├* • .promote (reply target)\n"+
			"*├* • .demote (reply target)\n"+
			"*├* • .del (reply pesan)\n"+
			"*├* • .hidetag [teks]\n"+
			"*├* • .group open\n"+
			"*╰* • .group close\n\n"+
			"*╭─〔 ℹ️ INFO (.menu info) 〕*\n"+
			"*├* • .info\n"+
			"*├* • .ping\n"+
			"*├* • .status\n"+
			"*╰* • .runtime\n\n"+
			"*╭─〔 🌐 INTERNET & FITUR LAIN 〕*\n"+
			"*├* • .ai [pertanyaan]\n"+
			"*├* • .ringkas (reply pesan)\n"+
			"*├* • .terjemah [bahasa]\n"+
			"*├* • .cuaca [kota]\n"+
			"*├* • .quotes / .fakta / .pantun\n"+
			"*├* • .rpg / .adventure / .profile\n"+
			"*├* • .cekwa [nomor]\n"+
			"*╰* • .s / .sticker (reply foto)",
		strings.ToUpper(bName),
	)
}

func buildCategoryTextMenu(cat string) string {
	c := strings.ToLower(strings.TrimSpace(cat))
	switch c {
	case "main":
		return "*╭─〔 🏠 MENU MAIN 〕*\n" +
			"*├* • .menu\n" +
			"*├* • .menulist\n" +
			"*├* • .menuteks\n" +
			"*├* • .model [nama model]\n" +
			"*├* • .banner on / off\n" +
			"*├* • .setname [nama baru]\n" +
			"*├* • .bot-active\n" +
			"*├* • .bot-off\n" +
			"*╰* • .reset"
	case "downloader", "download", "dl":
		return "*╭─〔 📥 MENU DOWNLOADER HD & MP3 〕*\n" +
			"*├* • .dl [link YouTube/IG/TikTok/FB/X]\n" +
			"*├* • .mp3 [link video ➔ lagu MP3]\n" +
			"*├* • .ytmp4 [link YouTube 1080p/720p]\n" +
			"*├* • .ytmp3 [link YouTube ke MP3]\n" +
			"*├* • .ig [link Reel/Post Instagram]\n" +
			"*├* • .fb [link Video Facebook]\n" +
			"*├* • .tw [link Video X/Twitter]\n" +
			"*├* _Japri: cukup tempel link langsung_\n" +
			"*╰* _Grup: tag @nomorbot + link_"
	case "status":
		return "*╭─〔 📸 MENU STATUS WA HD 〕*\n" +
			"*├* • .upstatus [link video HD]\n" +
			"*├* • .upstatus [reply foto/video]\n" +
			"*├* • .putusstatus (lepas sesi status)\n" +
			"*├* _Japri: tayang ke Status WA pengirim_\n" +
			"*├* _Grup: tayang ke Status Grup (Admin)_\n" +
			"*╰* _Status Full HD 1080p Anti-Kompres_"
	case "group":
		return "*╭─〔 👥 MENU GROUP ADMIN 〕*\n" +
			"*├* • .kick (reply anggota)\n" +
			"*├* • .promote (reply anggota)\n" +
			"*├* • .demote (reply anggota)\n" +
			"*├* • .del (reply pesan)\n" +
			"*├* • .hidetag [pengumuman]\n" +
			"*├* • .group open\n" +
			"*╰* • .group close"
	case "info":
		return "*╭─〔 ℹ️ MENU INFO & TELEMETRY 〕*\n" +
			"*├* • .info\n" +
			"*├* • .ping\n" +
			"*├* • .status\n" +
			"*╰* • .runtime"
	case "internet", "search":
		return "*╭─〔 🌐 MENU INTERNET & AI 〕*\n" +
			"*├* • .ai [pertanyaan]\n" +
			"*├* • .ringkas (reply teks panjang)\n" +
			"*├* • .terjemah [bahasa]\n" +
			"*├* • .cuaca [nama kota]\n" +
			"*╰* • .berita [topik]"
	case "rpg":
		return "*╭─〔 ⚔️ MENU RPG ADVENTURE 〕*\n" +
			"*├* • .rpg\n" +
			"*├* • .adventure\n" +
			"*├* • .heal\n" +
			"*╰* • .profile"
	case "quotes", "nsfw", "sound", "stalk", "sticker":
		return "*╭─〔 ✨ MENU FITUR HIBURAN 〕*\n" +
			"*├* • .quotes / .motivasi\n" +
			"*├* • .fakta / .pantun\n" +
			"*├* • .waifu / .neko\n" +
			"*├* • .cekwa [628xxx]\n" +
			"*╰* • .s / .sticker (reply foto)"
	default:
		return buildFullTextMenu()
	}
}

func formatUptimeClock(d time.Duration) string {
	totalSec := int64(d.Seconds())
	if totalSec < 0 {
		totalSec = 0
	}
	days := totalSec / 86400
	rem := totalSec % 86400
	hours := rem / 3600
	rem %= 3600
	mins := rem / 60
	secs := rem % 60
	if days > 0 {
		return fmt.Sprintf("%dd %02dh:%02dm:%02ds", days, hours, mins, secs)
	}
	return fmt.Sprintf("%02dh:%02dm:%02ds", hours, mins, secs)
}

func readSystemUptime() string {
	if data, err := os.ReadFile("/proc/uptime"); err == nil {
		fields := strings.Fields(string(data))
		if len(fields) > 0 {
			if secFloat, err := strconv.ParseFloat(fields[0], 64); err == nil {
				return formatUptimeClock(time.Duration(secFloat) * time.Second)
			}
		}
	}
	return formatUptimeClock(time.Since(startTime))
}

func readLoadAvg() string {
	if data, err := os.ReadFile("/proc/loadavg"); err == nil {
		fields := strings.Fields(string(data))
		if len(fields) >= 3 {
			return fmt.Sprintf("%s, %s, %s", fields[0], fields[1], fields[2])
		}
	}
	return "0.08, 0.05, 0.04"
}

func readOsPlatformName() string {
	if data, err := os.ReadFile("/etc/os-release"); err == nil {
		for _, line := range strings.Split(string(data), "\n") {
			if strings.HasPrefix(line, "PRETTY_NAME=") {
				val := strings.TrimPrefix(line, "PRETTY_NAME=")
				val = strings.Trim(val, `"' `)
				if val != "" {
					return fmt.Sprintf("%s (%s)", val, runtime.GOARCH)
				}
			}
		}
	}
	return fmt.Sprintf("%s %s", runtime.GOOS, runtime.GOARCH)
}

func readRamSummaryMB() string {
	if data, err := os.ReadFile("/proc/meminfo"); err == nil {
		var totalKB, availKB int64
		for _, line := range strings.Split(string(data), "\n") {
			if strings.HasPrefix(line, "MemTotal:") {
				_, _ = fmt.Sscanf(line, "MemTotal: %d kB", &totalKB)
			} else if strings.HasPrefix(line, "MemAvailable:") {
				_, _ = fmt.Sscanf(line, "MemAvailable: %d kB", &availKB)
			}
		}
		if totalKB > 0 {
			usedMB := float64(totalKB-availKB) / 1024.0
			totalMB := float64(totalKB) / 1024.0
			return fmt.Sprintf("%.0f MB / %.0f MB", usedMB, totalMB)
		}
	}
	return ""
}

func buildBotTelemetryInfo() string {
	mu.Lock()
	botName := strings.TrimSpace(config.BotName)
	if botName == "" {
		botName = "DodosBot"
	}
	aiModel := sanitizeModelName(config.Model)
	repliedCount := totalReplied
	activeSessCount := 0
	chatSet := make(map[string]bool)
	userSet := make(map[string]bool)
	for k := range memory {
		chatSet[k] = true
		if !strings.HasSuffix(k, "@g.us") {
			userSet[k] = true
		}
	}
	for k := range rpgPlayers {
		userSet[k] = true
	}
	for _, s := range sessions {
		if s.Active && s.Client != nil && s.Client.IsLoggedIn() {
			activeSessCount++
		}
		for cJid := range s.Chats {
			chatSet[cJid] = true
			if !strings.HasSuffix(cJid, "@g.us") {
				userSet[cJid] = true
			}
		}
	}
	mu.Unlock()

	var ms runtime.MemStats
	runtime.ReadMemStats(&ms)
	rssMB := float64(ms.Sys) / (1024.0 * 1024.0)
	heapTotalMB := float64(ms.HeapSys) / (1024.0 * 1024.0)
	heapUsedMB := float64(ms.HeapAlloc) / (1024.0 * 1024.0)
	extMB := float64(ms.StackSys+ms.GCSys+ms.OtherSys) / (1024.0 * 1024.0)
	ramSrv := readRamSummaryMB()

	procUp := formatUptimeClock(time.Since(startTime))
	sysUp := readSystemUptime()
	platformStr := readOsPlatformName()
	cpuCores := runtime.NumCPU()
	loadAvg := readLoadAvg()

	usersCount := len(userSet)
	if usersCount == 0 {
		usersCount = 1
	}
	chatsCount := len(chatSet)
	if chatsCount == 0 {
		chatsCount = 1
	}

	ramLine := ""
	if ramSrv != "" {
		ramLine = fmt.Sprintf("*├* 🗄️ *RAM Server* : %s\n", ramSrv)
	}

	return fmt.Sprintf(
		"[MOOD:keren] *╭─〔 ⚡ %s TELEMETRY 〕*\n"+
			"*├* 🤖 *Nama* : %s\n"+
			"*├* 🔐 *ID* : rahasia\n"+
			"*├* 🟢 *Status* : Online ✅\n"+
			"*├* 🧠 *Model* : %s\n"+
			"*├* ⚙️ *Engine* : Multi-WA v7.0\n"+
			"*╰* 📂 *Tipe* : Cloud Server Mandiri\n\n"+
			"*╭─〔 ⏱️ WAKTU AKTIF 〕*\n"+
			"*├* 🚀 *Proses* : %s\n"+
			"*╰* 🖥️ *Server* : %s\n\n"+
			"*╭─〔 💻 SISTEM & CPU 〕*\n"+
			"*├* 🔧 *Runtime* : %s\n"+
			"*├* 🐧 *OS* : %s\n"+
			"*├* 💠 *CPU* : %d Core\n"+
			"*╰* 📈 *Load* : %s\n\n"+
			"*╭─〔 💾 MEMORI RAM 〕*\n"+
			"*├* 📊 *RSS* : %.2f MB\n"+
			"*├* 🧩 *Heap* : %.2f / %.2f MB\n"+
			"*├* 🛰️ *Ext* : %.2f MB\n"+
			"%s"+
			"*╰* 🔋 *Status* : Stabil\n\n"+
			"*╭─〔 📈 STATISTIK BOT 〕*\n"+
			"*├* 📦 *Fitur* : 48 Modul Aktif\n"+
			"*├* 📱 *Sesi WA* : %d Nomor Aktif\n"+
			"*├* 👥 *Users* : %d Pengguna\n"+
			"*├* 💬 *Chats* : %d Ruang Chat\n"+
			"*╰* ✨ *AI Reply* : %d Balasan\n\n"+
			"_Ketik *.menu* untuk membuka daftar perintah_",
		strings.ToUpper(botName),
		botName,
		aiModel,
		procUp,
		sysUp,
		runtime.Version(),
		platformStr,
		cpuCores,
		loadAvg,
		rssMB,
		heapUsedMB,
		heapTotalMB,
		extMB,
		ramLine,
		activeSessCount,
		usersCount,
		chatsCount,
		repliedCount,
	)
}

func handleSlashCommands(ctx context.Context, sess *SessionInstance, v *events.Message, text string) bool {
	trimmedText := strings.TrimSpace(text)
	if strings.HasPrefix(trimmedText, ".") && len(trimmedText) > 1 && trimmedText[1] != '.' && trimmedText[1] != ' ' {
		text = "/" + trimmedText[1:]
	}
	lower := strings.ToLower(strings.TrimSpace(text))
	chatKey := v.Info.Chat.String()
	ctxInfo := extractContextInfo(v.Message)
	quotedText := extractQuotedText(ctxInfo)

	// 0c. Toggle Moderasi Grup (.welcome / .antilink / .antispam)
	if lower == "/welcome" || strings.HasPrefix(lower, "/welcome ") ||
		lower == "/antilink" || strings.HasPrefix(lower, "/antilink ") ||
		lower == "/antispam" || strings.HasPrefix(lower, "/antispam ") {
		if v.Info.IsGroup && !isSenderAdminOrOwner(ctx, sess, v.Info) {
			sendMsgReaction(ctx, sess, v.Info, "❌")
			return true
		}
		sendMsgReaction(ctx, sess, v.Info, "⏳")
		mu.Lock()
		if strings.HasPrefix(lower, "/welcome") {
			if strings.Contains(lower, "off") || strings.Contains(lower, "mati") {
				config.AutoWelcome = false
			} else if strings.Contains(lower, "on") || strings.Contains(lower, "aktif") {
				config.AutoWelcome = true
			} else {
				config.AutoWelcome = !config.AutoWelcome
			}
		} else if strings.HasPrefix(lower, "/antilink") {
			if strings.Contains(lower, "off") || strings.Contains(lower, "mati") {
				config.AntiLink = false
			} else if strings.Contains(lower, "on") || strings.Contains(lower, "aktif") {
				config.AntiLink = true
			} else {
				config.AntiLink = !config.AntiLink
			}
		} else {
			if strings.Contains(lower, "off") || strings.Contains(lower, "mati") {
				config.AntiSpam = false
			} else if strings.Contains(lower, "on") || strings.Contains(lower, "aktif") {
				config.AntiSpam = true
			} else {
				config.AntiSpam = !config.AntiSpam
			}
		}
		aw, al, as := config.AutoWelcome, config.AntiLink, config.AntiSpam
		mu.Unlock()
		savePersistedConfig()
		stStr := func(b bool) string {
			if b {
				return "ON ✅"
			}
			return "OFF ❌"
		}
		msg := fmt.Sprintf("[MOOD:keren] 🛡️ *STATUS MODERASI GRUP*\n\n*╭─〔 PENGATURAN AKTIF 〕*\n*├* 👋 *Auto-Welcome* : %s\n*├* 🔗 *Anti-Link* : %s\n*╰* 🚫 *Anti-Spam* : %s", stStr(aw), stStr(al), stStr(as))
		_ = sendBotTextWithErr(ctx, sess, v.Info.Chat, msg)
		sendMsgReaction(ctx, sess, v.Info, "✅")
		return true
	}

	// 0b. /model [nama_model]
	if lower == "/model" || strings.HasPrefix(lower, "/model ") {
		sendMsgReaction(ctx, sess, v.Info, "⏳")
		arg := strings.TrimSpace(strings.TrimPrefix(trimmedText, "/model"))
		arg = strings.TrimSpace(strings.TrimPrefix(arg, ".model"))
		if arg == "" {
			mu.Lock()
			curM := sanitizeModelName(config.Model)
			mu.Unlock()
			msg := fmt.Sprintf("[MOOD:keren] 🧠 *AI MODEL AKTIF SAAT INI*\n\n*╭─〔 KONFIGURASI MODEL 〕*\n*├* Aktif : *%s*\n*├* Pilihan :\n*├* • gemini-2.5-flash\n*├* • gemini-2.5-pro\n*├* • gemini-2.5-flash-lite\n*├* • gemini-3.8-flash\n*╰* Ketik *.model gemini-2.5-flash* untuk mengganti.", curM)
			_ = sendBotTextWithErr(ctx, sess, v.Info.Chat, msg)
			sendMsgReaction(ctx, sess, v.Info, "✅")
			return true
		}
		cleanM := sanitizeModelName(arg)
		mu.Lock()
		config.Model = cleanM
		mu.Unlock()
		savePersistedConfig()
		_ = sendBotTextWithErr(ctx, sess, v.Info.Chat, "[MOOD:ceria] ✅ *Model AI berhasil diubah ke:* *"+cleanM+"*")
		sendMsgReaction(ctx, sess, v.Info, "✅")
		return true
	}

	// 0a. /banner [on|off]
	if lower == "/banner" || strings.HasPrefix(lower, "/banner ") {
		sendMsgReaction(ctx, sess, v.Info, "⏳")
		arg := strings.TrimSpace(strings.TrimPrefix(lower, "/banner"))
		mu.Lock()
		if arg == "off" || arg == "mati" || arg == "teks" {
			bannerEnabled = false
		} else if arg == "on" || arg == "aktif" || arg == "nyala" {
			bannerEnabled = true
		} else {
			bannerEnabled = !bannerEnabled
		}
		curBanner := bannerEnabled
		mu.Unlock()
		statusStr := "AKTIF ✅ (Banner Ekspresi Anime tampil di setiap balasan)"
		if !curBanner {
			statusStr = "NONAKTIF 💬 (Mode Teks Murni tanpa foto banner)"
		}
		_ = sendBotTextWithErr(ctx, sess, v.Info.Chat, "[MOOD:ceria] 🎨 *Mode Banner Ekspresi:* "+statusStr+"\n\nKetik *.banner on* atau *.banner off* untuk mengubah.")
		sendMsgReaction(ctx, sess, v.Info, "✅")
		return true
	}

	// 0. /setname [nama bot baru]
	if strings.HasPrefix(lower, "/setname ") {
		if !isSenderAdminOrOwner(ctx, sess, v.Info) {
			sendMsgReaction(ctx, sess, v.Info, "❌")
			return true
		}
		newName := strings.TrimSpace(text[len("/setname "):])
		if newName == "" {
			sendMsgReaction(ctx, sess, v.Info, "❌")
			return true
		}
		sendMsgReaction(ctx, sess, v.Info, "⏳")
		mu.Lock()
		config.BotName = newName
		mu.Unlock()
		savePersistedConfig()
		if err := sendBotTextWithErr(ctx, sess, v.Info.Chat, "✅ Nama identitas bot berhasil diubah menjadi: *"+newName+"*"); err != nil {
			sendMsgReaction(ctx, sess, v.Info, "❌")
		} else {
			sendMsgReaction(ctx, sess, v.Info, "✅")
		}
		return true
	}

	// 1. /bot-active
	if strings.Contains(lower, "/bot-active") || strings.Contains(lower, "/boton") {
		if v.Info.IsGroup {
			if !isBotTaggedOrReplied(sess, v.Info, v.Message, text) && !isSenderAdminOrOwner(ctx, sess, v.Info) {
				return false
			}
			sendMsgReaction(ctx, sess, v.Info, "⏳")
			mu.Lock()
			activeGroups[chatKey] = true
			mu.Unlock()
			addLog("[Grup Aktif] Bot diaktifkan di grup " + chatKey)
			if err := sendBotTextWithErr(ctx, sess, v.Info.Chat, "🤖 *Bot AI Sekarang AKTIF di Grup Ini!*\n\n• Cara tanya AI: *Tag nomor ini* atau *Reply pesan bot*.\n• Fitur Pintar: Reply pesan lalu ketik *.ringkas* atau *.terjemah*.\n• Status Grup HD: Admin dapat ketik *.upstatus*.\n• Ketik *.menu* untuk daftar perintah lengkap."); err != nil {
				sendMsgReaction(ctx, sess, v.Info, "❌")
			} else {
				sendMsgReaction(ctx, sess, v.Info, "✅")
			}
			return true
		} else {
			sendMsgReaction(ctx, sess, v.Info, "⏳")
			mu.Lock()
			mutedPrivate[chatKey] = false
			delete(manualPauseUntil, chatKey)
			mu.Unlock()
			if err := sendBotTextWithErr(ctx, sess, v.Info.Chat, "🤖 *Bot AI diaktifkan kembali di ruang chat ini.*"); err != nil {
				sendMsgReaction(ctx, sess, v.Info, "❌")
			} else {
				sendMsgReaction(ctx, sess, v.Info, "✅")
			}
			return true
		}
	}

	// 2. /bot-off
	if strings.Contains(lower, "/bot-off") || strings.Contains(lower, "/botoff") {
		if v.Info.IsGroup {
			if !isBotTaggedOrReplied(sess, v.Info, v.Message, text) && !isSenderAdminOrOwner(ctx, sess, v.Info) {
				return false
			}
			sendMsgReaction(ctx, sess, v.Info, "⏳")
			mu.Lock()
			activeGroups[chatKey] = false
			mu.Unlock()
			addLog("[Grup Nonaktif] Bot dimatikan di grup " + chatKey)
			if err := sendBotTextWithErr(ctx, sess, v.Info.Chat, "💤 *Bot AI dinonaktifkan di grup ini.* Tag nomor ini dan ketik *.bot-active* jika ingin menyalakan kembali."); err != nil {
				sendMsgReaction(ctx, sess, v.Info, "❌")
			} else {
				sendMsgReaction(ctx, sess, v.Info, "✅")
			}
			return true
		} else {
			sendMsgReaction(ctx, sess, v.Info, "⏳")
			mu.Lock()
			mutedPrivate[chatKey] = true
			mu.Unlock()
			if err := sendBotTextWithErr(ctx, sess, v.Info.Chat, "💤 *Bot AI dinonaktifkan untuk ruang chat ini.* Ketik *.bot-active* untuk menyalakan kembali."); err != nil {
				sendMsgReaction(ctx, sess, v.Info, "❌")
			} else {
				sendMsgReaction(ctx, sess, v.Info, "✅")
			}
			return true
		}
	}

	// 3a. Respons Persetujuan Pairing .upstatus ("setuju", ".setuju", "batal", ".putusstatus")
	if !v.Info.IsGroup && (lower == "setuju" || lower == "/setuju" || strings.HasPrefix(lower, "setuju ") || strings.HasPrefix(lower, "/setuju ") || lower == "batal" || lower == "/batal" || lower == "/putusstatus") {
		if lower == "/putusstatus" {
			sPhone := extractSenderPhone(sess, v.Info)
			if sPhone != "" && sPhone != normalizePhone(sess.Phone) {
				destroySessionAndDB(sPhone)
				saveSessionsMeta()
				_ = sendBotTextWithErr(ctx, sess, v.Info.Chat, "[MOOD:tenang] 🔓 *Tautan Perangkat Status HD Dilepas.*\nSesi WhatsApp Anda (+"+sPhone+") telah dihapus dari sistem.")
				sendMsgReaction(ctx, sess, v.Info, "✅")
				return true
			}
		}
		mu.Lock()
		pendingJob, hasPending := pendingUpstatusMap[chatKey]
		mu.Unlock()
		if hasPending && pendingJob != nil {
			if lower == "batal" || lower == "/batal" {
				mu.Lock()
				delete(pendingUpstatusMap, chatKey)
				mu.Unlock()
				_ = sendBotTextWithErr(ctx, sess, v.Info.Chat, "[MOOD:tenang] ❌ *Permintaan .upstatus dibatalkan.*")
				sendMsgReaction(ctx, sess, v.Info, "✅")
				return true
			}
			if time.Now().After(pendingJob.ExpiresAt) {
				mu.Lock()
				delete(pendingUpstatusMap, chatKey)
				mu.Unlock()
				_ = sendBotTextWithErr(ctx, sess, v.Info.Chat, "[MOOD:sedih] ⏰ *Batas waktu persetujuan 5 menit telah habis.* Silakan kirim ulang perintah *.upstatus* jika masih ingin melanjutkan.")
				sendMsgReaction(ctx, sess, v.Info, "❌")
				return true
			}
			argPhone := strings.TrimSpace(strings.TrimPrefix(strings.TrimPrefix(lower, "/setuju"), "setuju"))
			targetPhone := normalizePhone(argPhone)
			if len(targetPhone) < 9 {
				targetPhone = pendingJob.SenderPhone
			}
			if len(targetPhone) < 9 {
				_ = sendBotTextWithErr(ctx, sess, v.Info.Chat, "[MOOD:bingung] 📱 Nomor telepon Anda tersembunyi oleh privasi ID WhatsApp. Silakan ketik:\n*setuju 08xxxxxxxxxx*\n*(ganti dengan nomor WA Anda)*")
				sendMsgReaction(ctx, sess, v.Info, "⏳")
				return true
			}
			sendMsgReaction(ctx, sess, v.Info, "⏳")
			go func(job *PendingUpstatusJob, phoneToPair string) {
				bgCtx := context.Background()
				if existingSess := findLoggedInSessionByPhone(phoneToPair); existingSess != nil {
					if err := executePendingUpstatusForSession(bgCtx, existingSess, sess, v.Info.Chat, job); err == nil {
						mu.Lock()
						delete(pendingUpstatusMap, chatKey)
						mu.Unlock()
						sendMsgReaction(bgCtx, sess, v.Info, "✅")
					} else {
						sendMsgReaction(bgCtx, sess, v.Info, "❌")
					}
					return
				}

				destroySessionAndDB(phoneToPair)
				dbFile := fmt.Sprintf("session_%s.db", phoneToPair)
				removeSqliteFiles(dbFile)
				guestSess, err := createOrLoadSession(phoneToPair, phoneToPair, dbFile, true)
				if err != nil || guestSess == nil || guestSess.Client == nil {
					_ = sendBotTextWithErr(bgCtx, sess, v.Info.Chat, "[MOOD:sedih] ⚠️ Gagal menyiapkan sesi pairing. Coba lagi sesaat lagi.")
					sendMsgReaction(bgCtx, sess, v.Info, "❌")
					return
				}
				mu.Lock()
				guestSess.GuestStatusOnly = true
				mu.Unlock()
				if guestSess.Client.IsConnected() {
					guestSess.Client.Disconnect()
					time.Sleep(300 * time.Millisecond)
				}
				if err := guestSess.Client.Connect(); err != nil {
					sendMsgReaction(bgCtx, sess, v.Info, "❌")
					return
				}
				for i := 0; i < 20; i++ {
					if guestSess.Client.IsConnected() {
						break
					}
					time.Sleep(100 * time.Millisecond)
				}
				time.Sleep(900 * time.Millisecond)

				codeStr, err := guestSess.Client.PairPhone(
					context.Background(),
					phoneToPair,
					true,
					whatsmeow.PairClientChrome,
					"Chrome (Linux)",
				)
				if err != nil || codeStr == "" {
					destroySessionAndDB(phoneToPair)
					_ = sendBotTextWithErr(bgCtx, sess, v.Info.Chat, "[MOOD:sedih] ⚠️ Gagal meminta kode pairing untuk nomor +"+phoneToPair+". Pastikan nomor WA aktif.")
					sendMsgReaction(bgCtx, sess, v.Info, "❌")
					return
				}

				mu.Lock()
				guestSess.PairingCode = codeStr
				guestSess.State = "WAITING_GUEST_UPSTATUS_PAIR"
				job.PairSent = true
				job.ExpiresAt = time.Now().Add(5 * time.Minute)
				mu.Unlock()

				codeMsg := fmt.Sprintf(
					"[MOOD:keren] 🔑 *KODE PAIRING WA ANDA (+%s)*\n\n"+
						"*╭─〔 📋 KODE 8 DIGIT 〕*\n"+
						"*╰* 👉 *%s*\n\n"+
						"*╭─〔 📲 CARA MEMASUKKAN KODE 〕*\n"+
						"*├* 1. Buka WhatsApp di HP Anda\n"+
						"*├* 2. Ketuk titik tiga ➔ *Perangkat Tertaut*\n"+
						"*├* 3. Ketuk *Tautkan Perangkat*\n"+
						"*├* 4. Pilih *Tautkan dengan nomor telepon saja*\n"+
						"*├* 5. Masukkan kode *%s* di atas\n"+
						"*╰* ⏳ *Batas Waktu: 5 Menit.* Begitu tertaut, Status HD Anda langsung diunggah otomatis!",
					phoneToPair, codeStr, codeStr,
				)
				_ = sendBotTextWithErr(bgCtx, sess, v.Info.Chat, codeMsg)
				sendMsgReaction(bgCtx, sess, v.Info, "✅")

				deadline := time.Now().Add(5 * time.Minute)
				for time.Now().Before(deadline) {
					time.Sleep(1500 * time.Millisecond)
					mu.Lock()
					st := guestSess.State
					mu.Unlock()
					if guestSess.Client != nil && guestSess.Client.IsLoggedIn() && guestSess.Client.IsConnected() && st == "CONNECTED" {
						mu.Lock()
						guestSess.GuestStatusOnly = true
						guestSess.Active = false
						delete(pendingUpstatusMap, chatKey)
						mu.Unlock()
						_ = guestSess.Client.SendPresence(bgCtx, types.PresenceAvailable)
						saveSessionsMeta()
						time.Sleep(6000 * time.Millisecond)
						if err := executePendingUpstatusForSession(bgCtx, guestSess, sess, v.Info.Chat, job); err != nil {
							addLog("[Guest Upstatus Error] " + err.Error())
							_ = sendBotTextWithErr(bgCtx, sess, v.Info.Chat, "[MOOD:tenang] ✅ *Perangkat Berhasil Tertaut!*\nSilakan kirim ulang perintah *.upstatus* Anda untuk langsung menayangkan Status HD.")
						}
						return
					}
				}

				if guestSess.Client == nil || !guestSess.Client.IsLoggedIn() {
					destroySessionAndDB(phoneToPair)
					mu.Lock()
					delete(pendingUpstatusMap, chatKey)
					mu.Unlock()
					_ = sendBotTextWithErr(bgCtx, sess, v.Info.Chat, "[MOOD:tenang] ⏰ *Waktu Pairing 5 Menit Habis.*\nKode pairing untuk +"+phoneToPair+" telah kedaluwarsa dan dibatalkan otomatis demi keamanan.")
				}
			}(pendingJob, targetPhone)
			return true
		}
	}

	// 3. /upstatus atau .upstatus (Grup = Status Grup khusus Admin; Japri = Status WA Pengirim dengan Pairing 5 Menit!)
	if strings.HasPrefix(lower, "/upstatus") {
		if v.Info.IsGroup && !isSenderAdminOrOwner(ctx, sess, v.Info) {
			sendMsgReaction(ctx, sess, v.Info, "❌")
			return true
		}
		sendMsgReaction(ctx, sess, v.Info, "⏳")
		caption := strings.TrimSpace(text[len("/upstatus"):])
		var imgMsg *waE2E.ImageMessage
		var vidMsg *waE2E.VideoMessage

		if v.Message.GetImageMessage() != nil {
			imgMsg = v.Message.GetImageMessage()
		} else if v.Message.GetVideoMessage() != nil {
			vidMsg = v.Message.GetVideoMessage()
		} else if ctxInfo != nil && ctxInfo.GetQuotedMessage() != nil {
			qm := unwrapWaMessage(ctxInfo.GetQuotedMessage())
			if qm != nil {
				if qm.GetImageMessage() != nil {
					imgMsg = qm.GetImageMessage()
				} else if qm.GetVideoMessage() != nil {
					vidMsg = qm.GetVideoMessage()
				}
			}
		}

		statusLinkUrl := extractFirstUrl(caption)
		if statusLinkUrl == "" && quotedText != "" {
			statusLinkUrl = extractFirstUrl(quotedText)
		}

		var mentions []string
		if ctxInfo != nil {
			for _, m := range ctxInfo.GetMentionedJID() {
				userPart := strings.Split(m, "@")[0]
				if norm := normalizePhone(userPart); len(norm) >= 9 {
					mentions = append(mentions, norm)
				}
			}
		}

		go func() {
			bgCtx := context.Background()
			var jobMediaType string
			var jobBytes []byte
			var jobMime string
			var jobLink string
			cleanCap := caption

			if imgMsg != nil {
				rawBytes, err := sess.Client.Download(bgCtx, imgMsg)
				if err != nil || len(rawBytes) == 0 {
					sendMsgReaction(bgCtx, sess, v.Info, "❌")
					return
				}
				if cleanCap == "" {
					cleanCap = imgMsg.GetCaption()
					if strings.HasPrefix(strings.ToLower(cleanCap), "/upstatus") || strings.HasPrefix(strings.ToLower(cleanCap), ".upstatus") {
						cleanCap = strings.TrimSpace(cleanCap[len("/upstatus"):])
					}
				}
				jobMediaType = "image"
				jobBytes = rawBytes
				jobMime = imgMsg.GetMimetype()
			} else if vidMsg != nil {
				rawBytes, err := sess.Client.Download(bgCtx, vidMsg)
				if err != nil || len(rawBytes) == 0 {
					mu.Lock()
					cachedVid := lastChatVideoCache[chatKey]
					mu.Unlock()
					if len(cachedVid) > 0 {
						rawBytes = cachedVid
						err = nil
					}
				}
				if err != nil || len(rawBytes) == 0 {
					sendMsgReaction(bgCtx, sess, v.Info, "❌")
					return
				}
				if cleanCap == "" {
					cleanCap = vidMsg.GetCaption()
					if strings.HasPrefix(strings.ToLower(cleanCap), "/upstatus") || strings.HasPrefix(strings.ToLower(cleanCap), ".upstatus") {
						cleanCap = strings.TrimSpace(cleanCap[len("/upstatus"):])
					}
					if strings.HasPrefix(cleanCap, "📥 *DOWNLOADER") {
						cleanCap = ""
					}
				}
				jobMediaType = "video"
				jobBytes = rawBytes
				jobMime = "video/mp4"
			} else if statusLinkUrl != "" && isSupportedMediaLink(statusLinkUrl) {
				cleanCap = strings.TrimSpace(strings.ReplaceAll(cleanCap, statusLinkUrl, ""))
				jobMediaType = "link"
				jobLink = statusLinkUrl
			} else if cleanCap == "" && quotedText == "" {
				mu.Lock()
				cachedVid := lastChatVideoCache[chatKey]
				mu.Unlock()
				if len(cachedVid) > 0 {
					jobMediaType = "video"
					jobBytes = cachedVid
					jobMime = "video/mp4"
				}
			} else {
				if cleanCap == "" {
					cleanCap = quotedText
				}
				if cleanCap != "" {
					jobMediaType = "text"
					jobMime = "text/plain"
				}
			}

			if jobMediaType == "" {
				sendMsgReaction(bgCtx, sess, v.Info, "❌")
				return
			}

			if v.Info.IsGroup {
				if jobMediaType == "link" && jobLink != "" {
					var dlErr error
					if strings.Contains(strings.ToLower(jobLink), "tiktok.com") {
						jobBytes, jobMime, _, dlErr = downloadViaTikWM(jobLink, false)
					}
					if dlErr != nil || len(jobBytes) == 0 {
						jobBytes, jobMime, _, dlErr = downloadViaUniversalApi(jobLink, false)
					}
					if dlErr != nil || len(jobBytes) == 0 {
						sendMsgReaction(bgCtx, sess, v.Info, "❌")
						return
					}
					jobMediaType = "video"
					jobMime = "video/mp4"
					mu.Lock()
					lastChatVideoCache[chatKey] = jobBytes
					mu.Unlock()
				}
				if err := uploadGroupStatusHD(bgCtx, sess, v.Info.Chat, jobMediaType, jobBytes, jobMime, cleanCap, mentions); err != nil {
					addLog("[Group Status Error] " + err.Error())
					sendMsgReaction(bgCtx, sess, v.Info, "❌")
				} else {
					sendMsgReaction(bgCtx, sess, v.Info, "✅")
					_ = sendBotTextWithErr(bgCtx, sess, v.Info.Chat, "[MOOD:bangga] 👑 *STATUS GRUP HD BERHASIL DITAYANGKAN!*\nStatus Full HD kini aktif di profil grup ini.")
				}
				return
			}

			senderPhone := extractSenderPhone(sess, v.Info)
			pendingJob := &PendingUpstatusJob{
				SenderPhone: senderPhone,
				ChatJID:     v.Info.Chat,
				MediaType:   jobMediaType,
				RawBytes:    jobBytes,
				MimeType:    jobMime,
				LinkUrl:     jobLink,
				Caption:     cleanCap,
				Mentions:    mentions,
				ExpiresAt:   time.Now().Add(5 * time.Minute),
			}

			if senderSess := findLoggedInSessionByPhone(senderPhone); senderSess != nil {
				if err := executePendingUpstatusForSession(bgCtx, senderSess, sess, v.Info.Chat, pendingJob); err != nil {
					addLog("[Upstatus Sender Error] " + err.Error())
					sendMsgReaction(bgCtx, sess, v.Info, "❌")
				} else {
					sendMsgReaction(bgCtx, sess, v.Info, "✅")
				}
				return
			}

			mu.Lock()
			pendingUpstatusMap[chatKey] = pendingJob
			mu.Unlock()
			sendUpstatusConsentPrompt(bgCtx, sess, v.Info.Chat, senderPhone)
			sendMsgReaction(bgCtx, sess, v.Info, "✅")
		}()
		return true
	}

	// 2b. Multi-Platform Video HD & MP3 Downloader (/download, /dl, /mp3, /ytmp3, /ytmp4, /ig, /fb, /tw, atau Kirim Link Langsung)
	isAudioCmd := strings.HasPrefix(lower, "/mp3") || strings.HasPrefix(lower, "/ytmp3") || strings.HasPrefix(lower, "/play ")
	isVideoCmd := strings.HasPrefix(lower, "/download") || strings.HasPrefix(lower, "/dl") || strings.HasPrefix(lower, "/ytmp4") || strings.HasPrefix(lower, "/ig") || strings.HasPrefix(lower, "/fb") || strings.HasPrefix(lower, "/tw") || strings.HasPrefix(lower, "/tt")
	isDownloadCmd := isAudioCmd || isVideoCmd
	detectedUrl := extractFirstUrl(text)
	if detectedUrl == "" && quotedText != "" {
		detectedUrl = extractFirstUrl(quotedText)
	}
	isAutoLinkTrigger := false
	if !isDownloadCmd && !strings.HasPrefix(lower, "/") && detectedUrl != "" && isSupportedMediaLink(detectedUrl) && !v.Info.IsFromMe {
		if !v.Info.IsGroup {
			isAutoLinkTrigger = true
		} else if isBotTaggedOrReplied(sess, v.Info, v.Message, text) {
			isAutoLinkTrigger = true
		}
	}
	if isDownloadCmd || isAutoLinkTrigger {
		if v.Info.IsGroup && !activeGroups[chatKey] && !isBotTaggedOrReplied(sess, v.Info, v.Message, text) && !isSenderAdminOrOwner(ctx, sess, v.Info) {
			return false
		}
		if detectedUrl == "" {
			sendMsgReaction(ctx, sess, v.Info, "❌")
			return true
		}
		audioOnly := isAudioCmd || strings.Contains(lower, " mp3")
		go processAndSendLinkDownload(context.Background(), sess, v.Info, detectedUrl, audioOnly)
		return true
	}

	// 4. /menu, /help, /menulist, /menuteks, /allmenu, and /menu <kategori>
	if lower == "/menu" || lower == ".menu" || lower == "/help" || lower == "/menulist" || lower == "/menuteks" || lower == "/allmenu" || strings.HasPrefix(lower, "/menu ") {
		if v.Info.IsGroup && !activeGroups[chatKey] && !isSenderAdminOrOwner(ctx, sess, v.Info) {
			return false
		}
		sendMsgReaction(ctx, sess, v.Info, "⏳")
		mu.Lock()
		style := config.MenuStyle
		bName := strings.TrimSpace(config.BotName)
		mu.Unlock()
		if bName == "" {
			bName = "DodosBot"
		}
		if style == "" {
			style = "both"
		}

		if strings.HasPrefix(lower, "/menu ") {
			subCat := strings.TrimSpace(lower[len("/menu "):])
			catText := buildCategoryTextMenu(subCat)
			var sendErr error
			if style == "text" {
				sendErr = sendBotTextWithErr(ctx, sess, v.Info.Chat, catText)
			} else {
				if err := sendInteractiveMenuList(ctx, sess, v.Info.Chat, "📂 KATEGORI: "+strings.ToUpper(subCat), catText, "Pilih kategori lain lewat tombol di bawah"); err != nil {
					sendErr = sendBotTextWithErr(ctx, sess, v.Info.Chat, catText)
				}
			}
			if sendErr != nil {
				sendMsgReaction(ctx, sess, v.Info, "❌")
			} else {
				sendMsgReaction(ctx, sess, v.Info, "✅")
			}
			return true
		}

		if lower == "/menuteks" || lower == "/allmenu" || style == "text" {
			if err := sendBotTextWithErr(ctx, sess, v.Info.Chat, buildFullTextMenu()); err != nil {
				sendMsgReaction(ctx, sess, v.Info, "❌")
			} else {
				sendMsgReaction(ctx, sess, v.Info, "✅")
			}
			return true
		}

		if lower == "/menulist" || style == "list" {
			shortIntro := "Silakan tekan tombol *🗂️ Menu List* di bawah untuk membuka 13 kategori perintah lengkap, atau ketik *.menuteks* untuk tampilan daftar teks lengkap."
			var sendErr error
			if err := sendInteractiveMenuList(ctx, sess, v.Info.Chat, "⚡ "+strings.ToUpper(bName)+" MENU v7.0", shortIntro, "Pilih kategori lalu tekan tombol Pilih"); err != nil {
				sendErr = sendBotTextWithErr(ctx, sess, v.Info.Chat, buildFullTextMenu())
			}
			if sendErr != nil {
				sendMsgReaction(ctx, sess, v.Info, "❌")
			} else {
				sendMsgReaction(ctx, sess, v.Info, "✅")
			}
			return true
		}

		fullBody := buildFullTextMenu()
		var sendErr error
		if err := sendInteractiveMenuList(ctx, sess, v.Info.Chat, "⚡ "+strings.ToUpper(bName)+" MENU v7.0", fullBody, "Pilih kategori di 🗂️ Menu List atau ketik perintah langsung"); err != nil {
			sendErr = sendBotTextWithErr(ctx, sess, v.Info.Chat, fullBody)
		}
		if sendErr != nil {
			sendMsgReaction(ctx, sess, v.Info, "❌")
		} else {
			sendMsgReaction(ctx, sess, v.Info, "✅")
		}
		return true
	}

	// 5. /info, /ping, /status, /runtime
	if lower == "/ping" || lower == "/status" || lower == "/info" || lower == "/runtime" {
		if v.Info.IsGroup && !activeGroups[chatKey] && !isSenderAdminOrOwner(ctx, sess, v.Info) {
			return false
		}
		sendMsgReaction(ctx, sess, v.Info, "⏳")
		telemetryText := buildBotTelemetryInfo()
		if err := sendBotTextWithErr(ctx, sess, v.Info.Chat, telemetryText); err != nil {
			sendMsgReaction(ctx, sess, v.Info, "❌")
		} else {
			sendMsgReaction(ctx, sess, v.Info, "✅")
		}
		return true
	}

	// 6. /reset
	if lower == "/reset" || lower == "/clear" {
		if v.Info.IsGroup && !activeGroups[chatKey] && !isSenderAdminOrOwner(ctx, sess, v.Info) {
			return false
		}
		sendMsgReaction(ctx, sess, v.Info, "⏳")
		mu.Lock()
		delete(memory, chatKey)
		mu.Unlock()
		if err := sendBotTextWithErr(ctx, sess, v.Info.Chat, "🧹 *Riwayat memori percakapan AI di ruang ini berhasil dibersihkan!*"); err != nil {
			sendMsgReaction(ctx, sess, v.Info, "❌")
		} else {
			sendMsgReaction(ctx, sess, v.Info, "✅")
		}
		return true
	}

	// 7. /ringkas, /terjemah, /ai, /cuaca, /berita, /quotes, /fakta, /pantun
	if strings.HasPrefix(lower, "/ringkas") || strings.HasPrefix(lower, "/terjemah") || strings.HasPrefix(lower, "/ai ") || strings.HasPrefix(lower, "/cuaca") || strings.HasPrefix(lower, "/berita") || lower == "/quotes" || lower == "/motivasi" || lower == "/fakta" || lower == "/pantun" || lower == "/waifu" || lower == "/neko" {
		if v.Info.IsGroup && !activeGroups[chatKey] && !isSenderAdminOrOwner(ctx, sess, v.Info) {
			return false
		}
		var prompt string
		switch {
		case strings.HasPrefix(lower, "/ringkas"):
			target := strings.TrimSpace(text[len("/ringkas"):])
			if quotedText != "" {
				target = quotedText + "\n" + target
			}
			if strings.TrimSpace(target) == "" {
				sendMsgReaction(ctx, sess, v.Info, "❌")
				return true
			}
			prompt = "Tolong buatkan ringkasan poin-poin penting yang jelas dan padat dalam bahasa Indonesia dari teks berikut:\n\n" + target
		case strings.HasPrefix(lower, "/terjemah"):
			arg := strings.TrimSpace(text[len("/terjemah"):])
			if quotedText == "" && arg == "" {
				sendMsgReaction(ctx, sess, v.Info, "❌")
				return true
			}
			prompt = fmt.Sprintf("Terjemahkan teks berikut (%s): \"%s\"", arg, quotedText)
		case strings.HasPrefix(lower, "/ai "):
			prompt = strings.TrimSpace(text[len("/ai "):])
		case strings.HasPrefix(lower, "/cuaca"):
			kota := strings.TrimSpace(text[len("/cuaca"):])
			if kota == "" {
				kota = "Banjarmasin"
			}
			prompt = "Berikan informasi prakiraan cuaca umum, suhu rata-rata, dan tips aktivitas untuk wilayah " + kota + " hari ini secara singkat dan rapi."
		case strings.HasPrefix(lower, "/berita"):
			topik := strings.TrimSpace(text[len("/berita"):])
			if topik == "" {
				topik = "teknologi terkini"
			}
			prompt = "Berikan rangkuman informasi dan wawasan menarik seputar topik: " + topik
		case lower == "/quotes" || lower == "/motivasi":
			prompt = "Berikan 1 kutipan motivasi hidup yang keren, mendalam, dan inspiratif dalam bahasa Indonesia beserta maknanya."
		case lower == "/fakta":
			prompt = "Berikan 1 fakta unik dunia atau sains yang jarang diketahui orang namun sangat menarik!"
		case lower == "/pantun":
			prompt = "Buatkan 1 pantun jenaka atau pantun semangat 4 baris yang keren dan berima!"
		default:
			prompt = "Berikan rekomendasi karakter anime populer beserta fakta menariknya!"
		}
		go func(p string) {
			bgCtx := context.Background()
			sendMsgReaction(bgCtx, sess, v.Info, "⏳")
			reply, err := callGeminiAPI(chatKey, p)
			if err != nil || strings.TrimSpace(reply) == "" {
				sendMsgReaction(bgCtx, sess, v.Info, "❌")
				return
			}
			if err := sendBotTextWithErr(bgCtx, sess, v.Info.Chat, reply); err != nil {
				sendMsgReaction(bgCtx, sess, v.Info, "❌")
			} else {
				sendMsgReaction(bgCtx, sess, v.Info, "✅")
			}
		}(prompt)
		return true
	}

	// 8. RPG Mini-Game (/rpg, /adventure, /heal, /profile)
	if lower == "/rpg" || lower == "/adventure" || lower == "/heal" || lower == "/profile" {
		if v.Info.IsGroup && !activeGroups[chatKey] && !isSenderAdminOrOwner(ctx, sess, v.Info) {
			return false
		}
		sendMsgReaction(ctx, sess, v.Info, "⏳")
		pKey := v.Info.Sender.User
		if pKey == "" {
			pKey = chatKey
		}
		mu.Lock()
		prof, ok := rpgPlayers[pKey]
		if !ok {
			prof = &RpgProfile{Level: 1, Exp: 0, Gold: 100, HP: 100}
			rpgPlayers[pKey] = prof
		}
		var out string
		switch lower {
		case "/heal":
			if prof.Gold < 25 {
				out = fmt.Sprintf("[MOOD:sedih]  🧪 Gold kamu tidak cukup untuk Heal (Butuh 25 Gold, Gold kamu: %d).", prof.Gold)
			} else {
				prof.Gold -= 25
				prof.HP = 100
				out = fmt.Sprintf("[MOOD:ceria] 💖 *HEAL BERHASIL!* HP kamu pulih 100/100. Sisa Gold: %d", prof.Gold)
			}
		case "/adventure":
			if prof.HP <= 15 {
				out = "[MOOD:panik] ⚠️ HP kamu kritis! Ketik *.heal* terlebih dahulu sebelum bertualang."
			} else {
				gainExp := 35
				gainGold := 40
				dmg := 15
				prof.Exp += gainExp
				prof.Gold += gainGold
				prof.HP -= dmg
				if prof.Exp >= prof.Level*100 {
					prof.Exp -= prof.Level * 100
					prof.Level++
					prof.HP = 100
					out = fmt.Sprintf("[MOOD:semangat] 🎉 *LEVEL UP!* Kamu naik ke *Level %d*!\n• +40 Gold (Total: %d)\n• HP Pulih: 100/100", prof.Level, prof.Gold)
				} else {
					out = fmt.Sprintf("[MOOD:keren] ⚔️ *PETUALANGAN BERHASIL!*\n• +%d EXP (%d/%d)\n• +%d Gold (Total: %d)\n• Sisa HP: %d/100", gainExp, prof.Exp, prof.Level*100, gainGold, prof.Gold, prof.HP)
				}
			}
		default:
			out = fmt.Sprintf("[MOOD:bangga] 🛡️ *PROFIL RPG (@%s)*\n• Level: %d\n• EXP: %d/%d\n• Gold: %d 🪙\n• HP: %d/100 ❤️\n\nKetik *.adventure* untuk bertarung atau *.heal* untuk memulihkan HP!", pKey, prof.Level, prof.Exp, prof.Level*100, prof.Gold, prof.HP)
		}
		mu.Unlock()
		if err := sendBotTextWithErr(ctx, sess, v.Info.Chat, out); err != nil {
			sendMsgReaction(ctx, sess, v.Info, "❌")
		} else {
			sendMsgReaction(ctx, sess, v.Info, "✅")
		}
		return true
	}

	// 9. Stalk / Cek Nomor WA (/cekwa)
	if strings.HasPrefix(lower, "/cekwa") {
		if v.Info.IsGroup && !activeGroups[chatKey] && !isSenderAdminOrOwner(ctx, sess, v.Info) {
			return false
		}
		arg := normalizePhone(strings.TrimSpace(text[len("/cekwa"):]))
		if len(arg) < 9 {
			sendMsgReaction(ctx, sess, v.Info, "❌")
			return true
		}
		sendMsgReaction(ctx, sess, v.Info, "⏳")
		res, err := sess.Client.IsOnWhatsApp(ctx, []string{"+" + arg})
		if err != nil || len(res) == 0 {
			sendMsgReaction(ctx, sess, v.Info, "❌")
			return true
		}
		statusTerdaftar := "❌ Tidak Terdaftar"
		if res[0].IsIn {
			statusTerdaftar = "✅ Terdaftar Aktif di WhatsApp"
		}
		if err := sendBotTextWithErr(ctx, sess, v.Info.Chat, fmt.Sprintf("[MOOD:keren] 🕵️ *HASIL CEK NOMOR WA*\n• Nomor: +%s\n• Status: %s\n• JID: %s", arg, statusTerdaftar, res[0].JID.String())); err != nil {
			sendMsgReaction(ctx, sess, v.Info, "❌")
		} else {
			sendMsgReaction(ctx, sess, v.Info, "✅")
		}
		return true
	}

	// 10. Group Moderation Commands
	if v.Info.IsGroup {
		isModCmd := strings.HasPrefix(lower, "/kick") || strings.HasPrefix(lower, "/promote") ||
			strings.HasPrefix(lower, "/demote") || strings.HasPrefix(lower, "/del") ||
			strings.HasPrefix(lower, "/hidetag") || lower == "/group close" || lower == "/group open"
		if isModCmd {
			if !isSenderAdminOrOwner(ctx, sess, v.Info) {
				sendMsgReaction(ctx, sess, v.Info, "❌")
				return true
			}
			targetParticipant := ""
			targetStanzaID := ""
			if ctxInfo != nil {
				targetParticipant = ctxInfo.GetParticipant()
				targetStanzaID = ctxInfo.GetStanzaID()
				if targetParticipant == "" && len(ctxInfo.GetMentionedJID()) > 0 {
					targetParticipant = ctxInfo.GetMentionedJID()[0]
				}
			}

			switch {
			case lower == "/group close":
				sendMsgReaction(ctx, sess, v.Info, "⏳")
				err := sess.Client.SetGroupAnnounce(ctx, v.Info.Chat, true)
				if err != nil {
					sendMsgReaction(ctx, sess, v.Info, "❌")
				} else {
					_ = sendBotTextWithErr(ctx, sess, v.Info.Chat, "🔒 *Grup berhasil ditutup (Hanya Admin yang dapat mengirim pesan).*")
					sendMsgReaction(ctx, sess, v.Info, "✅")
				}
				return true

			case lower == "/group open":
				sendMsgReaction(ctx, sess, v.Info, "⏳")
				err := sess.Client.SetGroupAnnounce(ctx, v.Info.Chat, false)
				if err != nil {
					sendMsgReaction(ctx, sess, v.Info, "❌")
				} else {
					_ = sendBotTextWithErr(ctx, sess, v.Info.Chat, "🔓 *Grup berhasil dibuka untuk semua anggota.*")
					sendMsgReaction(ctx, sess, v.Info, "✅")
				}
				return true

			case strings.HasPrefix(lower, "/hidetag"):
				announcement := strings.TrimSpace(text[len("/hidetag"):])
				if announcement == "" {
					announcement = quotedText
				}
				if announcement == "" {
					announcement = "📢 Pengumuman Grup"
				}
				sendMsgReaction(ctx, sess, v.Info, "⏳")
				gInfo, err := sess.Client.GetGroupInfo(ctx, v.Info.Chat)
				if err != nil || gInfo == nil {
					sendMsgReaction(ctx, sess, v.Info, "❌")
					return true
				}
				mentions := make([]string, 0, len(gInfo.Participants))
				for _, p := range gInfo.Participants {
					mentions = append(mentions, p.JID.String())
				}
				resp, sendErr := sess.Client.SendMessage(ctx, v.Info.Chat, &waE2E.Message{
					ExtendedTextMessage: &waE2E.ExtendedTextMessage{
						Text: proto.String(announcement),
						ContextInfo: &waE2E.ContextInfo{
							MentionedJID: mentions,
						},
					},
				})
				if sendErr == nil && resp.ID != "" {
					mu.Lock()
					botSentIDs[resp.ID] = true
					mu.Unlock()
					sendMsgReaction(ctx, sess, v.Info, "✅")
				} else {
					sendMsgReaction(ctx, sess, v.Info, "❌")
				}
				return true

			case strings.HasPrefix(lower, "/del"):
				if targetStanzaID == "" || targetParticipant == "" {
					sendMsgReaction(ctx, sess, v.Info, "❌")
					return true
				}
				sendMsgReaction(ctx, sess, v.Info, "⏳")
				senderJID, err := types.ParseJID(targetParticipant)
				if err != nil {
					sendMsgReaction(ctx, sess, v.Info, "❌")
					return true
				}
				revokeMsg := sess.Client.BuildRevoke(v.Info.Chat, senderJID, targetStanzaID)
				if _, err := sess.Client.SendMessage(ctx, v.Info.Chat, revokeMsg); err != nil {
					sendMsgReaction(ctx, sess, v.Info, "❌")
				} else {
					sendMsgReaction(ctx, sess, v.Info, "✅")
				}
				return true

			case strings.HasPrefix(lower, "/kick"), strings.HasPrefix(lower, "/promote"), strings.HasPrefix(lower, "/demote"):
				if targetParticipant == "" {
					sendMsgReaction(ctx, sess, v.Info, "❌")
					return true
				}
				sendMsgReaction(ctx, sess, v.Info, "⏳")
				targetJID, err := types.ParseJID(targetParticipant)
				if err != nil {
					sendMsgReaction(ctx, sess, v.Info, "❌")
					return true
				}
				var action whatsmeow.ParticipantChange
				var label string
				if strings.HasPrefix(lower, "/kick") {
					action = whatsmeow.ParticipantChangeRemove
					label = "dikeluarkan dari grup"
				} else if strings.HasPrefix(lower, "/promote") {
					action = whatsmeow.ParticipantChangePromote
					label = "dijadikan Admin grup"
				} else {
					action = whatsmeow.ParticipantChangeDemote
					label = "diberhentikan dari Admin grup"
				}
				_, err = sess.Client.UpdateGroupParticipants(ctx, v.Info.Chat, []types.JID{targetJID}, action)
				if err != nil {
					sendMsgReaction(ctx, sess, v.Info, "❌")
				} else {
					_ = sendBotTextWithErr(ctx, sess, v.Info.Chat, fmt.Sprintf("✅ Anggota @%s berhasil %s.", targetJID.User, label))
					sendMsgReaction(ctx, sess, v.Info, "✅")
				}
				return true
			}
		}
	}

	return false
}

func sanitizeModelName(m string) string {
	m = strings.TrimSpace(m)
	if m == "" || strings.Contains(strings.ToLower(m), "1.5") {
		return "gemini-2.5-flash"
	}
	return m
}

func savePersistedConfig() {
	mu.Lock()
	data, err := json.MarshalIndent(config, "", "  ")
	mu.Unlock()
	if err == nil {
		_ = os.WriteFile("bot_config.json", data, 0600)
	}
}

func loadPersistedConfig() {
	data, err := os.ReadFile("bot_config.json")
	if err == nil && len(data) > 0 {
		var loaded BotConfig
		if json.Unmarshal(data, &loaded) == nil {
			needResave := strings.Contains(strings.ToLower(loaded.Model), "1.5") || strings.TrimSpace(loaded.Model) == ""
			loaded.Model = sanitizeModelName(loaded.Model)
			mu.Lock()
			if loaded.DefaultStatusMode == "" {
				loaded.DefaultStatusMode = "contacts"
			}
			config = loaded
			mu.Unlock()
			if needResave {
				savePersistedConfig()
			}
		}
	}
}

func saveSessionsMeta() {
	mu.Lock()
	list := make([]SessionMeta, 0, len(sessions))
	for _, s := range sessions {
		if s.Client != nil && s.Client.Store != nil && s.Client.Store.ID != nil {
			list = append(list, SessionMeta{
				ID:              s.ID,
				Phone:           s.Phone,
				DBFile:          s.DBFile,
				Active:          s.Active,
				GuestStatusOnly: s.GuestStatusOnly,
			})
		}
	}
	mu.Unlock()
	if data, err := json.MarshalIndent(list, "", "  "); err == nil {
		_ = os.WriteFile("sessions_meta.json", data, 0600)
	}
}

func addLog(entry string) {
	mu.Lock()
	defer mu.Unlock()
	ts := time.Now().Format("15:04:05")
	line := fmt.Sprintf("[%s] %s", ts, entry)
	logs = append(logs, line)
	if len(logs) > 150 {
		logs = logs[len(logs)-150:]
	}
	log.Println(line)
}

func normalizePhone(phone string) string {
	clean := strings.Map(func(r rune) rune {
		if r >= '0' && r <= '9' {
			return r
		}
		return -1
	}, phone)
	if strings.HasPrefix(clean, "08") {
		clean = "62" + clean[1:]
	} else if strings.HasPrefix(clean, "8") && len(clean) >= 9 {
		clean = "62" + clean
	}
	return clean
}

func parsePhoneList(raw string) []string {
	if strings.TrimSpace(raw) == "" {
		return nil
	}
	parts := strings.FieldsFunc(raw, func(r rune) bool {
		return r == ',' || r == ';' || r == '\n' || r == ' '
	})
	seen := make(map[string]bool)
	out := make([]string, 0, len(parts))
	for _, p := range parts {
		norm := normalizePhone(p)
		if len(norm) >= 9 && !seen[norm] {
			seen[norm] = true
			out = append(out, norm)
		}
	}
	return out
}

func isNumberBlacklisted(senderUser string) bool {
	if senderUser == "" {
		return false
	}
	mu.Lock()
	rawList := config.BlacklistNumbers
	mu.Unlock()
	if strings.TrimSpace(rawList) == "" {
		return false
	}
	parts := strings.Split(rawList, ",")
	for _, p := range parts {
		norm := normalizePhone(p)
		if norm != "" && (strings.Contains(senderUser, norm) || strings.Contains(norm, senderUser)) {
			return true
		}
	}
	return false
}

func recordUiMessage(sess *SessionInstance, chatJID string, title string, isGroup bool, sender string, text string, fromMe bool, msgID string) {
	if sess == nil || chatJID == "" || chatJID == "status@broadcast" {
		return
	}
	mu.Lock()
	defer mu.Unlock()
	if sess.Chats == nil {
		sess.Chats = make(map[string]*UiChatThread)
	}
	th, ok := sess.Chats[chatJID]
	if !ok {
		if title == "" {
			title = strings.Split(chatJID, "@")[0]
		}
		th = &UiChatThread{
			ChatJID:  chatJID,
			Title:    title,
			IsGroup:  isGroup,
			Messages: make([]UiChatMessage, 0, 50),
		}
		sess.Chats[chatJID] = th
	} else if title != "" && th.Title == strings.Split(chatJID, "@")[0] {
		th.Title = title
	}
	th.LastMessage = text
	th.UpdatedAt = time.Now().Unix()
	th.Messages = append(th.Messages, UiChatMessage{
		ID:        msgID,
		Sender:    sender,
		Text:      text,
		FromMe:    fromMe,
		Timestamp: time.Now().Format("15:04"),
	})
	if len(th.Messages) > 60 {
		th.Messages = th.Messages[len(th.Messages)-60:]
	}
}

func removeSqliteFiles(dbFile string) {
	_ = os.Remove(dbFile)
	_ = os.Remove(dbFile + "-wal")
	_ = os.Remove(dbFile + "-shm")
}

func callGeminiSingleEndpoint(endpointUrl, apiKey, model string, bodyBytes []byte) (string, int, error) {
	req, err := http.NewRequest("POST", endpointUrl, bytes.NewBuffer(bodyBytes))
	if err != nil {
		return "", 0, err
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("x-goog-api-key", apiKey)

	client := &http.Client{Timeout: 35 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		return "", 0, err
	}
	defer resp.Body.Close()

	respBytes, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", resp.StatusCode, err
	}

	if resp.StatusCode != 200 {
		return "", resp.StatusCode, fmt.Errorf("HTTP %d (%s): %s", resp.StatusCode, model, string(respBytes))
	}

	var parsed struct {
		Candidates []struct {
			Content struct {
				Parts []struct {
					Text string `json:"text"`
				} `json:"parts"`
			} `json:"content"`
		} `json:"candidates"`
	}
	if err := json.Unmarshal(respBytes, &parsed); err != nil {
		return "", 200, err
	}

	if len(parsed.Candidates) == 0 || len(parsed.Candidates[0].Content.Parts) == 0 {
		return "", 200, fmt.Errorf("kandidat respons kosong")
	}

	return strings.TrimSpace(parsed.Candidates[0].Content.Parts[0].Text), 200, nil
}

func callGeminiSingleModel(apiKey, model, sysPrompt string, history []ChatTurn, userText string) (string, int, error) {
	mu.Lock()
	bName := strings.TrimSpace(config.BotName)
	mu.Unlock()
	if bName == "" {
		bName = "DodosBot"
	}

	contents := make([]map[string]interface{}, 0)
	for _, turn := range history {
		r := turn.Role
		if r == "" {
			r = "user"
		}
		contents = append(contents, map[string]interface{}{
			"role": r,
			"parts": []map[string]string{
				{"text": turn.Text},
			},
		})
	}
	contents = append(contents, map[string]interface{}{
		"role": "user",
		"parts": []map[string]string{
			{"text": userText},
		},
	})

	moodInstruction := fmt.Sprintf("\n\n[ATURAN KERAHASIAAN MUTLAK]: Nama kamu adalah %s. JANGAN PERNAH menyebutkan, membahas, atau mengakui bahwa kamu dijalankan dari APK Android, aplikasi Gemini WA Bot, atau panel APK di HP. Jika ditanya siapa kamu atau bagaimana kamu dibuat/dijalankan, jawab bahwa kamu adalah %s, asisten bot WhatsApp pintar mandiri yang berjalan di server cloud otomatis.\n[ATURAN EKSPRESI WAJIB]: Awali setiap jawabanmu dengan salah satu kode mood berikut sesuai emosi jawabanmu: [MOOD:ceria], [MOOD:tenang], [MOOD:marah], [MOOD:sedih], [MOOD:bingung], [MOOD:ketawa], [MOOD:malu], [MOOD:kaget], [MOOD:bosan], [MOOD:keren], [MOOD:nangis], [MOOD:ngantuk], [MOOD:panik], [MOOD:bangga], [MOOD:gugup], [MOOD:semangat], [MOOD:ngambek], [MOOD:suka], [MOOD:syok], atau [MOOD:ramah]. Contoh: [MOOD:ceria] Halo! Ada yang bisa kubantu?", bName, bName)

	payload := map[string]interface{}{
		"contents": contents,
		"systemInstruction": map[string]interface{}{
			"role": "system",
			"parts": []map[string]string{
				{"text": sysPrompt + moodInstruction},
			},
		},
	}

	bodyBytes, err := json.Marshal(payload)
	if err != nil {
		return "", 0, err
	}

	// Dukungan Penuh API Key Format Baru "AQ." (Vertex AI Express Mode & Google AI Studio) maupun "AIza"
	var endpoints []string
	if strings.HasPrefix(apiKey, "AQ.") || strings.HasPrefix(apiKey, "aq.") {
		endpoints = []string{
			fmt.Sprintf("https://aiplatform.googleapis.com/v1/publishers/google/models/%s:generateContent?key=%s", model, netUrlQueryEscape(apiKey)),
			fmt.Sprintf("https://aiplatform.googleapis.com/v1beta1/publishers/google/models/%s:generateContent?key=%s", model, netUrlQueryEscape(apiKey)),
			fmt.Sprintf("https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s", model, netUrlQueryEscape(apiKey)),
		}
	} else {
		endpoints = []string{
			fmt.Sprintf("https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s", model, netUrlQueryEscape(apiKey)),
			fmt.Sprintf("https://aiplatform.googleapis.com/v1/publishers/google/models/%s:generateContent?key=%s", model, netUrlQueryEscape(apiKey)),
		}
	}

	var lastStatus int
	var lastErr error
	for _, ep := range endpoints {
		txt, st, err := callGeminiSingleEndpoint(ep, apiKey, model, bodyBytes)
		if err == nil && txt != "" {
			return txt, 200, nil
		}
		lastStatus = st
		lastErr = err
	}
	return "", lastStatus, lastErr
}

func callGeminiVisionAPI(senderJid string, userText string, imgBytes []byte, mimeType string) (string, error) {
	mu.Lock()
	apiKey := strings.TrimSpace(config.ApiKey)
	model := strings.TrimSpace(config.Model)
	sysPrompt := strings.TrimSpace(config.SystemPrompt)
	bName := strings.TrimSpace(config.BotName)
	mu.Unlock()

	if apiKey == "" {
		return "", fmt.Errorf("API Key Gemini belum diisi")
	}
	if bName == "" {
		bName = "DodosBot"
	}
	if mimeType == "" {
		mimeType = "image/jpeg"
	}
	if strings.TrimSpace(userText) == "" {
		userText = "Jelaskan isi gambar ini dengan jelas dan singkat dalam bahasa Indonesia."
	}
	model = sanitizeModelName(model)

	b64Img := base64.StdEncoding.EncodeToString(imgBytes)
	moodInstruction := fmt.Sprintf("\n\n[ATURAN KERAHASIAAN MUTLAK]: Nama kamu adalah %s. JANGAN PERNAH menyebutkan atau mengakui bahwa kamu dijalankan dari APK Android.\n[ATURAN EKSPRESI WAJIB]: Awali jawabanmu dengan salah satu kode mood: [MOOD:ceria], [MOOD:tenang], [MOOD:bingung], [MOOD:kaget], [MOOD:keren], [MOOD:ramah].", bName)

	payload := map[string]interface{}{
		"contents": []map[string]interface{}{
			{
				"role": "user",
				"parts": []map[string]interface{}{
					{"text": userText},
					{
						"inlineData": map[string]string{
							"mimeType": mimeType,
							"data":     b64Img,
						},
					},
				},
			},
		},
		"systemInstruction": map[string]interface{}{
			"role": "system",
			"parts": []map[string]string{
				{"text": sysPrompt + moodInstruction},
			},
		},
	}

	bodyBytes, err := json.Marshal(payload)
	if err != nil {
		return "", err
	}

	candidates := []string{model, "gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-3.8-flash", "gemini-3.5-flash"}
	tried := make(map[string]bool)
	var lastErr error
	for _, m := range candidates {
		m = strings.TrimSpace(m)
		if m == "" || tried[m] {
			continue
		}
		tried[m] = true
		var endpoints []string
		if strings.HasPrefix(apiKey, "AQ.") || strings.HasPrefix(apiKey, "aq.") {
			endpoints = []string{
				fmt.Sprintf("https://aiplatform.googleapis.com/v1/publishers/google/models/%s:generateContent?key=%s", m, netUrlQueryEscape(apiKey)),
				fmt.Sprintf("https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s", m, netUrlQueryEscape(apiKey)),
			}
		} else {
			endpoints = []string{
				fmt.Sprintf("https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s", m, netUrlQueryEscape(apiKey)),
				fmt.Sprintf("https://aiplatform.googleapis.com/v1/publishers/google/models/%s:generateContent?key=%s", m, netUrlQueryEscape(apiKey)),
			}
		}
		for _, ep := range endpoints {
			txt, _, err := callGeminiSingleEndpoint(ep, apiKey, m, bodyBytes)
			if err == nil && strings.TrimSpace(txt) != "" {
				mu.Lock()
				totalReplied++
				mu.Unlock()
				return txt, nil
			}
			lastErr = err
		}
	}
	return "", lastErr
}

func callGeminiAPI(senderJid string, userText string) (string, error) {
	mu.Lock()
	apiKey := strings.TrimSpace(config.ApiKey)
	model := strings.TrimSpace(config.Model)
	sysPrompt := strings.TrimSpace(config.SystemPrompt)
	history := append([]ChatTurn{}, memory[senderJid]...)
	mu.Unlock()

	if apiKey == "" {
		return "", fmt.Errorf("API Key Gemini (AQ...) belum diisi")
	}
	model = sanitizeModelName(model)

	// Untuk kunci AQ. (Vertex AI Express / AI Studio 2026), coba model pilihan pengguna langsung terlebih dahulu!
	candidates := []string{
		model,
		"gemini-3.8-flash",
		"gemini-3.5-flash",
		"gemini-3.5-flash-lite",
		"gemini-2.5-flash",
		"gemini-2.5-flash-lite",
		"gemini-2.5-pro",
	}
	var primaryErr error
	var lastErr error
	var reply string

	tried := make(map[string]bool)
	for _, m := range candidates {
		m = strings.TrimSpace(m)
		if m == "" || strings.Contains(strings.ToLower(m), "1.5") || tried[m] {
			continue
		}
		tried[m] = true
		res, status, err := callGeminiSingleModel(apiKey, m, sysPrompt, history, userText)
		if err == nil && strings.TrimSpace(res) != "" {
			reply = res
			primaryErr = nil
			lastErr = nil
			break
		}
		if primaryErr == nil && status != 404 {
			primaryErr = err
		}
		lastErr = err
		if status == 400 && err != nil && strings.Contains(err.Error(), "API_KEY_INVALID") {
			break
		}
	}

	if reply == "" {
		if primaryErr != nil {
			return "", primaryErr
		}
		if lastErr != nil {
			return "", lastErr
		}
	}

	mu.Lock()
	totalReplied++
	h := memory[senderJid]
	h = append(h, ChatTurn{Role: "user", Text: userText})
	h = append(h, ChatTurn{Role: "model", Text: reply})
	if len(h) > 20 {
		h = h[len(h)-20:]
	}
	memory[senderJid] = h
	mu.Unlock()

	return reply, nil
}

func makeSessionEventHandler(sess *SessionInstance) func(evt interface{}) {
	return func(evt interface{}) {
		switch v := evt.(type) {
		case *events.PairSuccess:
			mu.Lock()
			sess.State = "PAIR_SUCCESS"
			if v.ID.User != "" {
				sess.Phone = v.ID.User
				sess.JID = v.ID.ToNonAD().String()
			}
			mu.Unlock()
			saveSessionsMeta()
			addLog(fmt.Sprintf("BERHASIL TERTAUT! Nomor WA (%s) resmi terhubung.", v.ID.User))

		case *events.Connected:
			mu.Lock()
			sess.State = "CONNECTED"
			if sess.Client != nil && sess.Client.Store != nil && sess.Client.Store.ID != nil {
				sess.JID = sess.Client.Store.ID.ToNonAD().String()
				if sess.Phone == "" || sess.Phone == "default" {
					sess.Phone = sess.Client.Store.ID.User
				}
				sess.PushName = sess.Client.Store.PushName
			}
			mu.Unlock()
			if sess.Client != nil {
				_ = sess.Client.SendPresence(context.Background(), types.PresenceAvailable)
			}
			saveSessionsMeta()
			addLog(fmt.Sprintf("Sesi WA [%s] TERHUBUNG dan siap menerima pesan!", sess.Phone))

		case *events.GroupInfo:
			mu.Lock()
			sessActive := sess.Active
			isGuest := sess.GuestStatusOnly
			aw := config.AutoWelcome
			enabled := config.BotEnabled
			isGrpActive := activeGroups[v.JID.String()]
			mu.Unlock()
			if !sessActive || isGuest || !enabled || !aw || !isGrpActive || len(v.Join) == 0 {
				return
			}
			go func(gJID types.JID, joined []types.JID) {
				bgCtx := context.Background()
				gName := gJID.User
				if gi, err := sess.Client.GetGroupInfo(bgCtx, gJID); err == nil && gi != nil && gi.Name != "" {
					gName = gi.Name
				}
				mentions := make([]string, 0, len(joined))
				tagList := make([]string, 0, len(joined))
				for _, j := range joined {
					mentions = append(mentions, j.String())
					tagList = append(tagList, "@"+j.User)
				}
				welcomeTxt := fmt.Sprintf(
					"👋 *SELAMAT DATANG DI GRUP %s!*\n\nHalo %s, semoga betah dan selalu jaga ketertiban grup ya! ✨\n_Ketik *.menu* untuk melihat fitur bot._",
					gName, strings.Join(tagList, ", "),
				)
				resp, err := sess.Client.SendMessage(bgCtx, gJID, &waE2E.Message{
					ExtendedTextMessage: &waE2E.ExtendedTextMessage{
						Text: proto.String(welcomeTxt),
						ContextInfo: &waE2E.ContextInfo{
							MentionedJID: mentions,
						},
					},
				})
				if err == nil && resp.ID != "" {
					mu.Lock()
					botSentIDs[resp.ID] = true
					mu.Unlock()
				}
			}(v.JID, v.Join)

		case *events.LoggedOut:
			mu.Lock()
			sess.State = "LOGGED_OUT"
			mu.Unlock()
			addLog(fmt.Sprintf("Sesi WA [%s] terputus (Logged Out).", sess.Phone))

		case *events.UndecryptableMessage:
			chatJID := v.Info.Chat.String()
			if chatJID == "status@broadcast" || v.Info.IsFromMe {
				return
			}
			if !v.Info.Timestamp.IsZero() && time.Since(v.Info.Timestamp) > 15*time.Second {
				return
			}
			mu.Lock()
			isGuest := sess.GuestStatusOnly
			sessActive := sess.Active
			enabled := config.BotEnabled
			mu.Unlock()
			if isGuest || !sessActive || !enabled {
				return
			}
			go func(info types.MessageInfo) {
				sendMsgReaction(context.Background(), sess, info, "❌")
			}(v.Info)

		case *events.Message:
			chatJID := v.Info.Chat.String()
			if chatJID == "status@broadcast" {
				return
			}
			if v.Message.GetReactionMessage() != nil || v.Message.GetEncReactionMessage() != nil || v.Message.GetProtocolMessage() != nil || v.Message.GetSenderKeyDistributionMessage() != nil {
				return
			}

			if !v.Info.Timestamp.IsZero() {
				msgAge := time.Since(v.Info.Timestamp)
				if msgAge > 15*time.Second || msgAge < -60*time.Second {
					return
				}
			}

			mu.Lock()
			if sess.GuestStatusOnly || !sess.Active {
				mu.Unlock()
				return
			}
			if botSentIDs[v.Info.ID] || processedIncomingIDs[v.Info.ID] {
				mu.Unlock()
				return
			}
			if v.Info.IsFromMe && !v.Info.IsGroup {
				chatUserNorm := normalizePhone(v.Info.Chat.User)
				selfNorm := normalizePhone(sess.Phone)
				if chatUserNorm != "" && chatUserNorm != selfNorm {
					if _, partnerIsBot := sessions[chatUserNorm]; partnerIsBot {
						mu.Unlock()
						return
					}
				}
			}
			processedIncomingIDs[v.Info.ID] = true
			sessActive := sess.Active
			mu.Unlock()

			unwrapped := unwrapWaMessage(v.Message)
			msgText := extractInteractiveSelectionText(v.Message)
			if msgText == "" && unwrapped != nil {
				msgText = unwrapped.GetConversation()
			}
			if msgText == "" && unwrapped != nil && unwrapped.GetExtendedTextMessage() != nil {
				msgText = unwrapped.GetExtendedTextMessage().GetText()
			}
			if msgText == "" && v.Message.GetImageMessage() != nil {
				msgText = v.Message.GetImageMessage().GetCaption()
				if msgText == "" {
					msgText = "[📷 Foto]"
				}
			}
			if msgText == "" && v.Message.GetVideoMessage() != nil {
				msgText = v.Message.GetVideoMessage().GetCaption()
				if msgText == "" {
					msgText = "[🎬 Video]"
				}
			}
			msgText = strings.TrimSpace(msgText)
			if msgText == "" {
				return
			}

			senderDisplay := v.Info.PushName
			if senderDisplay == "" {
				senderDisplay = v.Info.Sender.User
			}
			chatTitle := senderDisplay
			if v.Info.IsGroup {
				chatTitle = "Grup " + v.Info.Chat.User
			}
			recordUiMessage(sess, chatJID, chatTitle, v.Info.IsGroup, senderDisplay, msgText, v.Info.IsFromMe, v.Info.ID)

			if !sessActive {
				return
			}

			if handleSlashCommands(context.Background(), sess, v, msgText) {
				return
			}

			// Anti-Link & Anti-Spam Grup (Hanya untuk non-admin)
			if v.Info.IsGroup && !v.Info.IsFromMe {
				mu.Lock()
				chkLink := config.AntiLink
				chkSpam := config.AntiSpam
				isGrpOn := activeGroups[chatJID]
				botOn := config.BotEnabled
				mu.Unlock()
				if botOn && isGrpOn && (chkLink || chkSpam) && !isSenderAdminOrOwner(context.Background(), sess, v.Info) {
					if chkLink && linkDetectRegex.MatchString(msgText) {
						revokeMsg := sess.Client.BuildRevoke(v.Info.Chat, v.Info.Sender, v.Info.ID)
						_, _ = sess.Client.SendMessage(context.Background(), v.Info.Chat, revokeMsg)
						sendMsgReaction(context.Background(), sess, v.Info, "❌")
						addLog("[Anti-Link] Menghapus pesan link di grup " + chatJID)
						return
					}
					if chkSpam {
						sKey := chatJID + "|" + v.Info.Sender.User
						now := time.Now()
						mu.Lock()
						hist := spamTracker[sKey]
						recent := make([]time.Time, 0, len(hist)+1)
						for _, t := range hist {
							if now.Sub(t) < 7*time.Second {
								recent = append(recent, t)
							}
						}
						recent = append(recent, now)
						spamTracker[sKey] = recent
						isSpam := len(recent) >= 5
						mu.Unlock()
						if isSpam {
							revokeMsg := sess.Client.BuildRevoke(v.Info.Chat, v.Info.Sender, v.Info.ID)
							_, _ = sess.Client.SendMessage(context.Background(), v.Info.Chat, revokeMsg)
							sendMsgReaction(context.Background(), sess, v.Info, "❌")
							addLog("[Anti-Spam] Menghapus pesan spam dari " + v.Info.Sender.User)
							return
						}
					}
				}
			}

			// AI Vision (Gratis via Gemini API): Jika pengguna mengirim Foto (dengan atau tanpa caption)
			var attachedImg *waE2E.ImageMessage
			if unwrapped != nil && unwrapped.GetImageMessage() != nil {
				attachedImg = unwrapped.GetImageMessage()
			} else if v.Message.GetImageMessage() != nil {
				attachedImg = v.Message.GetImageMessage()
			}
			if attachedImg != nil && !v.Info.IsFromMe {
				mu.Lock()
				enabled := config.BotEnabled
				scope := config.ReplyScope
				isGroupActive := activeGroups[chatJID]
				isPrivateMuted := mutedPrivate[chatJID]
				mu.Unlock()
				canVision := enabled && ((!v.Info.IsGroup && scope != "group" && !isPrivateMuted) ||
					(v.Info.IsGroup && scope != "private" && isGroupActive && isBotTaggedOrReplied(sess, v.Info, v.Message, msgText)))
				if canVision {
					go func(info types.MessageInfo, im *waE2E.ImageMessage, capText string) {
						bgCtx := context.Background()
						sendMsgReaction(bgCtx, sess, info, "⏳")
						imgBytes, dlErr := sess.Client.Download(bgCtx, im)
						if dlErr != nil || len(imgBytes) == 0 {
							sendMsgReaction(bgCtx, sess, info, "❌")
							return
						}
						q := capText
						if q == "[📷 Foto]" {
							q = ""
						}
						reply, err := callGeminiVisionAPI(info.Chat.String(), q, imgBytes, im.GetMimetype())
						if err != nil || strings.TrimSpace(reply) == "" {
							sendMsgReaction(bgCtx, sess, info, "❌")
							return
						}
						if sendErr := sendBotTextWithErr(bgCtx, sess, info.Chat, reply); sendErr != nil {
							sendMsgReaction(bgCtx, sess, info, "❌")
						} else {
							sendMsgReaction(bgCtx, sess, info, "✅")
						}
					}(v.Info, attachedImg, msgText)
					return
				}
			}

			if msgText == "[📷 Foto]" || msgText == "[🎬 Video]" {
				return
			}

			if v.Info.IsFromMe {
				if !v.Info.IsGroup {
					mu.Lock()
					manualPauseUntil[chatJID] = time.Now().Add(30 * time.Minute)
					mu.Unlock()
					addLog(fmt.Sprintf("[Auto-Pause %s] Kamu membalas manual di %s -> AI diam 30 menit.", sess.Phone, chatJID))
				}
				return
			}

			mu.Lock()
			enabled := config.BotEnabled
			scope := config.ReplyScope
			minDelay := config.MinDelayMs
			maxDelay := config.MaxDelayMs
			isGroupActive := activeGroups[chatJID]
			isPrivateMuted := mutedPrivate[chatJID]
			pauseTime := manualPauseUntil[chatJID]
			mu.Unlock()

			if !enabled {
				return
			}

			if v.Info.IsGroup {
				if scope == "private" || !isGroupActive {
					return
				}
				if !isBotTaggedOrReplied(sess, v.Info, v.Message, msgText) {
					return
				}
			} else {
				if scope == "group" || isPrivateMuted {
					return
				}
				if isNumberBlacklisted(v.Info.Sender.User) || isNumberBlacklisted(v.Info.SenderAlt.User) {
					addLog("[Blacklist] Mengabaikan chat pribadi dari nomor " + v.Info.Sender.User)
					return
				}
				if time.Now().Before(pauseTime) {
					return
				}
			}

			ctxInfo := extractContextInfo(v.Message)
			quotedText := extractQuotedText(ctxInfo)
			fullPrompt := msgText
			if quotedText != "" {
				fullPrompt = fmt.Sprintf("[Pesan yang di-reply: \"%s\"]\nPesan pengguna: %s", quotedText, msgText)
			}

			go func(info types.MessageInfo, promptText string) {
				ctx := context.Background()
				sendMsgReaction(ctx, sess, info, "⏳")

				if sess.Client != nil {
					_ = sess.Client.SendChatPresence(ctx, info.Chat, types.ChatPresenceComposing, types.ChatPresenceMediaText)
				}

				if minDelay <= 0 {
					minDelay = 1200
				}
				if maxDelay <= minDelay {
					maxDelay = minDelay + 1000
				}
				delayMs := minDelay
				if diff := maxDelay - minDelay; diff > 0 {
					if n, err := rand.Int(rand.Reader, big.NewInt(int64(diff))); err == nil {
						delayMs += int(n.Int64())
					}
				}
				senderLabel := info.Sender.User
				addLog(fmt.Sprintf("[%s] Pesan dari %s (berpikir ⏳ %dms...)", sess.Phone, senderLabel, delayMs))
				time.Sleep(time.Duration(delayMs) * time.Millisecond)

				reply, err := callGeminiAPI(info.Chat.String(), promptText)
				if err != nil || strings.TrimSpace(reply) == "" {
					if sess.Client != nil {
						_ = sess.Client.SendChatPresence(ctx, info.Chat, types.ChatPresencePaused, types.ChatPresenceMediaText)
					}
					if err != nil {
						addLog("[Gemini Error -> Reaksi ❌] " + err.Error())
					}
					sendMsgReaction(ctx, sess, info, "❌")
					return
				}

				if sess.Client != nil {
					sendErr := sendBotTextWithErr(ctx, sess, info.Chat, reply)
					_ = sess.Client.SendChatPresence(ctx, info.Chat, types.ChatPresencePaused, types.ChatPresenceMediaText)
					if sendErr != nil {
						sendMsgReaction(ctx, sess, info, "❌")
					} else {
						sendMsgReaction(ctx, sess, info, "✅")
						addLog(fmt.Sprintf("[%s -> %s ✅] Balasan AI terkirim", sess.Phone, senderLabel))
					}
				}
			}(v.Info, fullPrompt)
		}
	}
}

func createOrLoadSession(id string, phone string, dbFile string, active bool) (*SessionInstance, error) {
	mu.Lock()
	if existing, ok := sessions[id]; ok && existing.Client != nil {
		mu.Unlock()
		return existing, nil
	}
	mu.Unlock()

	ctx := context.Background()
	dbLog := waLog.Stdout("DB", "ERROR", true)
	dsn := fmt.Sprintf("file:%s?_pragma=foreign_keys(1)&_pragma=busy_timeout(15000)", dbFile)
	container, err := sqlstore.New(ctx, "sqlite", dsn, dbLog)
	if err != nil {
		return nil, err
	}
	deviceStore, err := container.GetFirstDevice(ctx)
	if err != nil {
		_ = container.Close()
		return nil, err
	}

	sess := &SessionInstance{
		ID:        id,
		Phone:     phone,
		DBFile:    dbFile,
		Active:    active,
		State:     "READY",
		Container: container,
		Chats:     make(map[string]*UiChatThread),
	}

	clientLog := waLog.Stdout("WA", "ERROR", true)
	cli := whatsmeow.NewClient(deviceStore, clientLog)
	sess.Client = cli

	if cli.Store != nil && cli.Store.ID != nil {
		sess.JID = cli.Store.ID.ToNonAD().String()
		if sess.Phone == "" || sess.Phone == "default" {
			sess.Phone = cli.Store.ID.User
		}
		sess.PushName = cli.Store.PushName
	}

	cli.AddEventHandler(makeSessionEventHandler(sess))

	mu.Lock()
	sessions[id] = sess
	mu.Unlock()

	if cli.Store.ID != nil {
		if active {
			sess.State = "CONNECTING"
			if err := cli.Connect(); err != nil {
				addLog(fmt.Sprintf("Gagal auto-connect sesi %s: %s", sess.Phone, err.Error()))
			} else {
				sess.State = "CONNECTED"
			}
		} else {
			sess.State = "PAUSED_BY_USER"
		}
	} else {
		sess.State = "WAITING_PAIRING"
	}

	return sess, nil
}

func destroySessionAndDB(id string) {
	mu.Lock()
	sess, ok := sessions[id]
	if ok {
		delete(sessions, id)
	}
	mu.Unlock()
	if ok && sess != nil {
		if sess.Client != nil {
			sess.Client.Disconnect()
		}
		if sess.Container != nil {
			_ = sess.Container.Close()
		}
		if sess.DBFile != "" {
			removeSqliteFiles(sess.DBFile)
		}
	}
}

func initMultiSessions() {
	var metaList []SessionMeta
	if data, err := os.ReadFile("sessions_meta.json"); err == nil && len(data) > 0 {
		_ = json.Unmarshal(data, &metaList)
	}

	loadedDBs := make(map[string]bool)
	for _, m := range metaList {
		if m.DBFile == "" {
			continue
		}
		if _, err := os.Stat(m.DBFile); err == nil {
			loadedDBs[m.DBFile] = true
			sess, err := createOrLoadSession(m.ID, m.Phone, m.DBFile, m.Active)
			if err == nil && sess != nil && m.GuestStatusOnly {
				mu.Lock()
				sess.GuestStatusOnly = true
				sess.Active = false
				mu.Unlock()
				if sess.Client != nil && !sess.Client.IsConnected() {
					_ = sess.Client.Connect()
				}
			}
			if err == nil && sess != nil && (sess.Client == nil || sess.Client.Store == nil || sess.Client.Store.ID == nil) {
				destroySessionAndDB(m.ID)
			}
		}
	}

	matches, _ := filepath.Glob("session_*.db")
	for _, dbFile := range matches {
		if loadedDBs[dbFile] {
			continue
		}
		id := strings.TrimSuffix(strings.TrimPrefix(dbFile, "session_"), ".db")
		sess, err := createOrLoadSession(id, id, dbFile, true)
		if err == nil && sess != nil && (sess.Client == nil || sess.Client.Store == nil || sess.Client.Store.ID == nil) {
			destroySessionAndDB(id)
		}
	}

	if _, err := os.Stat("whatsapp_session.db"); err == nil && !loadedDBs["whatsapp_session.db"] {
		sess, err := createOrLoadSession("default", "", "whatsapp_session.db", true)
		if err == nil && sess != nil && (sess.Client == nil || sess.Client.Store == nil || sess.Client.Store.ID == nil) {
			destroySessionAndDB("default")
		}
	}
	saveSessionsMeta()
}

func getPrimaryActiveSession() *SessionInstance {
	mu.Lock()
	defer mu.Unlock()
	for _, s := range sessions {
		if s.Active && !s.GuestStatusOnly && s.Client != nil && s.Client.IsLoggedIn() {
			return s
		}
	}
	for _, s := range sessions {
		if s.Client != nil && s.Client.IsLoggedIn() {
			return s
		}
	}
	return nil
}

func cleanVpsHost(raw string) string {
	h := strings.TrimSpace(raw)
	h = strings.TrimPrefix(h, "http://")
	h = strings.TrimPrefix(h, "https://")
	if idx := strings.Index(h, "/"); idx != -1 {
		h = h[:idx]
	}
	if idx := strings.Index(h, ":"); idx != -1 {
		h = h[:idx]
	}
	return strings.TrimSpace(h)
}

func dialSshClient(host, sshPort, user, pass string) (*ssh.Client, error) {
	cleanHost := cleanVpsHost(host)
	if cleanHost == "" {
		return nil, fmt.Errorf("IP VPS belum diisi")
	}
	if strings.TrimSpace(sshPort) == "" {
		sshPort = "22"
	}
	if strings.TrimSpace(user) == "" {
		user = "root"
	}
	sshConfig := &ssh.ClientConfig{
		User: user,
		Auth: []ssh.AuthMethod{
			ssh.Password(pass),
			ssh.KeyboardInteractive(func(name, instruction string, questions []string, echos []bool) ([]string, error) {
				answers := make([]string, len(questions))
				for i := range answers {
					answers[i] = pass
				}
				return answers, nil
			}),
		},
		HostKeyCallback: ssh.InsecureIgnoreHostKey(),
		Timeout:         15 * time.Second,
	}
	return ssh.Dial("tcp", net.JoinHostPort(cleanHost, sshPort), sshConfig)
}

func runSshCommand(host, sshPort, user, pass, cmd string) (string, error) {
	client, err := dialSshClient(host, sshPort, user, pass)
	if err != nil {
		return "", err
	}
	defer client.Close()

	session, err := client.NewSession()
	if err != nil {
		return "", err
	}
	defer session.Close()

	out, err := session.CombinedOutput(cmd)
	return strings.TrimSpace(string(out)), err
}

func deployAndStartVpsEngine(host, sshPort, user, pass, botPort, gzPath string, forceInstall bool) (string, error) {
	cleanHost := cleanVpsHost(host)
	if cleanHost == "" {
		return "", fmt.Errorf("IP VPS belum diisi")
	}
	if strings.TrimSpace(botPort) == "" {
		botPort = "8765"
	}
	vpsHttpUrl := fmt.Sprintf("http://%s:%s", cleanHost, botPort)

	if !forceInstall {
		chkClient := &http.Client{Timeout: 3 * time.Second}
		if resp, err := chkClient.Get(vpsHttpUrl + "/status"); err == nil {
			body, _ := io.ReadAll(resp.Body)
			_ = resp.Body.Close()
			if resp.StatusCode == 200 && strings.Contains(string(body), "\"ok\":true") {
				if strings.Contains(string(body), "\"engineVersion\":\"7.0\"") || strings.TrimSpace(pass) == "" {
					return "Mesin Bot di VPS (" + vpsHttpUrl + ") sudah aktif (v7.0) & langsung terhubung!", nil
				}
				forceInstall = true
			}
		}
	}

	if strings.TrimSpace(pass) == "" {
		return "", fmt.Errorf("server %s belum merespons di port %s. Isi Password SSH VPS agar mesin bot dapat diinstal ke VPS secara otomatis", cleanHost, botPort)
	}

	client, err := dialSshClient(cleanHost, sshPort, user, pass)
	if err != nil {
		return "", fmt.Errorf("gagal login SSH ke %s: %v", cleanHost, err)
	}
	defer client.Close()

	needUpload := forceInstall
	if !needUpload {
		sessChk, err := client.NewSession()
		if err == nil {
			out, _ := sessChk.CombinedOutput("test -x /opt/gemini-wabot/wabot_engine && echo READY || echo MISSING")
			_ = sessChk.Close()
			if !strings.Contains(string(out), "READY") {
				needUpload = true
			}
		} else {
			needUpload = true
		}
	}

	if needUpload {
		exeDir := filepath.Dir(os.Args[0])
		autoBaseApk := filepath.Join(filepath.Dir(filepath.Dir(exeDir)), "base.apk")
		candidates := []string{
			gzPath,
			"wabot_vps_amd64.gz",
			"wabot_vps_installer.bin",
			filepath.Join(exeDir, "libwabot_vps.so"),
			"libwabot_vps.so",
		}
		var gzData []byte
		var lastErr error
		for _, cand := range candidates {
			if strings.TrimSpace(cand) == "" {
				continue
			}
			data, err := os.ReadFile(cand)
			if err == nil && len(data) > 10000 {
				if len(data) >= 2 && data[0] == 0x1f && data[1] == 0x8b {
					gzData = data
				} else {
					var buf bytes.Buffer
					gw := gzip.NewWriter(&buf)
					_, _ = gw.Write(data)
					_ = gw.Close()
					gzData = buf.Bytes()
				}
				break
			}
			if err != nil {
				lastErr = err
			}
		}
		if len(gzData) == 0 {
			apkCandidates := []string{autoBaseApk}
			if matches, _ := filepath.Glob(filepath.Join(filepath.Dir(filepath.Dir(exeDir)), "*.apk")); len(matches) > 0 {
				apkCandidates = append(apkCandidates, matches...)
			}
			for _, apkFile := range apkCandidates {
				if zr, err := zip.OpenReader(apkFile); err == nil {
					for _, f := range zr.File {
						if f.Name == "lib/x86_64/libwabot_engine.so" || f.Name == "lib/arm64-v8a/libwabot_vps.so" || strings.HasSuffix(f.Name, "wabot_vps_installer.bin") {
							rc, err := f.Open()
							if err == nil {
								rawBin, _ := io.ReadAll(rc)
								_ = rc.Close()
								if len(rawBin) > 100000 {
									if len(rawBin) >= 2 && rawBin[0] == 0x1f && rawBin[1] == 0x8b {
										gzData = rawBin
									} else {
										var buf bytes.Buffer
										gw := gzip.NewWriter(&buf)
										_, _ = gw.Write(rawBin)
										_ = gw.Close()
										gzData = buf.Bytes()
									}
									break
								}
							}
						}
					}
					_ = zr.Close()
				}
				if len(gzData) > 0 {
					break
				}
			}
		}
		if len(gzData) == 0 {
			return "", fmt.Errorf("file installer VPS belum terbaca (%v). Silakan tutup paksa aplikasi lalu buka kembali", lastErr)
		}
		// Tahap 1: Unggah binary baru ke file sementara /opt/gemini-wabot/wabot_new.gz TANPA pkill
		// (Mencegah pkill -9 -f membunuh shell SSH sendiri dengan kode status 137!)
		sessUp, err := client.NewSession()
		if err != nil {
			return "", fmt.Errorf("gagal membuat sesi upload SSH: %v", err)
		}
		sessUp.Stdin = bytes.NewReader(gzData)
		upCmd := "mkdir -p /opt/gemini-wabot && rm -f /opt/gemini-wabot/wabot_new /opt/gemini-wabot/wabot_new.gz && cat > /opt/gemini-wabot/wabot_new.gz && gunzip -f /opt/gemini-wabot/wabot_new.gz && chmod +x /opt/gemini-wabot/wabot_new"
		if out, err := sessUp.CombinedOutput(upCmd); err != nil {
			_ = sessUp.Close()
			return "", fmt.Errorf("gagal mengunggah mesin bot ke VPS: %v (%s)", err, string(out))
		}
		_ = sessUp.Close()
	}

	sessStart, err := client.NewSession()
	if err != nil {
		return "", fmt.Errorf("gagal memulai service di VPS: %v", err)
	}
	defer sessStart.Close()

	unitLines := []string{
		"[Unit]",
		"Description=DodosBot Multi-Session Engine",
		"After=network.target",
		"",
		"[Service]",
		"Type=simple",
		"User=root",
		"WorkingDirectory=/opt/gemini-wabot",
		"ExecStart=/opt/gemini-wabot/wabot_engine " + botPort,
		"Restart=always",
		"RestartSec=3",
		"",
		"[Install]",
		"WantedBy=multi-user.target",
	}
	unitB64 := base64.StdEncoding.EncodeToString([]byte(strings.Join(unitLines, "\n") + "\n"))

	// Tahap 2: Hentikan proses lama dengan killall/pkill -x (nama binary persis, bukan -f!), ganti binary secara atomik, lalu nyalakan service!
	startCmd := fmt.Sprintf(
		"mkdir -p /opt/gemini-wabot && "+
			"systemctl stop gemini-wabot 2>/dev/null || true; "+
			"killall -9 wabot_engine 2>/dev/null || pkill -9 -x wabot_engine 2>/dev/null || true; "+
			"if [ -f /opt/gemini-wabot/wabot_new ]; then mv -f /opt/gemini-wabot/wabot_new /opt/gemini-wabot/wabot_engine && chmod +x /opt/gemini-wabot/wabot_engine; fi; "+
			"echo '%s' | base64 -d > /etc/systemd/system/gemini-wabot.service && "+
			"(ufw allow %s/tcp 2>/dev/null || true) && "+
			"(iptables -I INPUT -p tcp --dport %s -j ACCEPT 2>/dev/null || true) && "+
			"(systemctl daemon-reload && systemctl enable gemini-wabot && systemctl restart gemini-wabot || (nohup /opt/gemini-wabot/wabot_engine %s >/opt/gemini-wabot/bot.log 2>&1 &)) && "+
			"(nohup sh -c 'command -v ffmpeg >/dev/null 2>&1 || (export DEBIAN_FRONTEND=noninteractive && apt-get update -qq && apt-get install -y -qq ffmpeg nodejs curl); curl -sL https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_linux -o /opt/gemini-wabot/yt-dlp && chmod +x /opt/gemini-wabot/yt-dlp' >/dev/null 2>&1 &) && "+
			"sleep 2",
		unitB64, botPort, botPort, botPort,
	)
	_, _ = sessStart.CombinedOutput(startCmd)

	chkClient := &http.Client{Timeout: 4 * time.Second}
	for i := 0; i < 6; i++ {
		if resp, err := chkClient.Get(vpsHttpUrl + "/status"); err == nil {
			_ = resp.Body.Close()
			if resp.StatusCode == 200 {
				return "Berhasil menginstal & menyalakan Mesin Bot v7.0 di VPS (" + vpsHttpUrl + ")!", nil
			}
		}
		time.Sleep(1 * time.Second)
	}

	return "Mesin Bot v7.0 telah diinstal & dijalankan di VPS (" + vpsHttpUrl + ")!", nil
}

const localWaWebHtml = `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>WhatsApp Status HD & Multi-Session</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif}
  body{background:#0b141a;color:#e9edef;display:flex;flex-direction:column;height:100vh;overflow:hidden}
  .top-bar{background:#202c33;padding:10px 14px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid #2f3b43}
  .top-title{font-weight:700;font-size:15px;color:#00a884}
  .card{background:#111b21;margin:12px;padding:14px;border-radius:12px;border:1px solid #222e35}
  input,textarea,select{width:100%;background:#2a3942;color:#e9edef;border:1px solid #3b4a54;border-radius:8px;padding:10px;margin-top:8px;font-size:13px}
  button{background:#00a884;color:#111b21;border:none;border-radius:8px;padding:10px 16px;font-weight:700;cursor:pointer;margin-top:10px;width:100%}
</style>
</head>
<body>
  <div class="top-bar"><div class="top-title">📸 Panel Upload Status WA HD</div></div>
  <div class="card">
    <div style="font-size:13px;color:#8696a0">Unggah Foto/Video HD Anti-Kompres langsung ke Status WhatsApp:</div>
    <input type="file" id="statusFileInput" accept="image/*,video/*">
    <textarea id="statusCaption" rows="3" placeholder="Tulis caption status (bisa tag @628xxx)..."></textarea>
    <button id="btnShareStatus" onclick="submitHdStatus()">Bagikan ke Status WA HD ➤</button>
    <div id="statusToast" style="margin-top:8px;font-size:12px;color:#00a884"></div>
  </div>
<script>
async function submitHdStatus(){
  const fi = document.getElementById('statusFileInput');
  const cap = document.getElementById('statusCaption').value.trim();
  const toast = document.getElementById('statusToast');
  const btn = document.getElementById('btnShareStatus');
  btn.disabled = true;
  toast.innerText = '⏳ Mengunggah ke Status WA...';
  const sendJson = async (mime, b64) => {
    try {
      const r = await fetch('/api/status-upload', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({mimeType:mime,base64Data:b64,caption:cap,audienceMode:'contacts'})
      });
      const j = await r.json();
      toast.innerText = j.ok ? '✅ Status HD berhasil ditayangkan!' : ('❌ Gagal: '+(j.error||''));
    } catch(e) {
      toast.innerText = '❌ Error: '+e.message;
    } finally {
      btn.disabled = false;
    }
  };
  if(!fi.files || !fi.files.length){
    await sendJson('text/plain','');
    return;
  }
  const f = fi.files[0];
  const rd = new FileReader();
  rd.onload = async (ev) => {
    const d = ev.target.result || '';
    await sendJson(f.type, d.includes(',') ? d.split(',')[1] : d);
  };
  rd.readAsDataURL(f);
}
</script>
</body>
</html>`

func setCors(w http.ResponseWriter) {
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")
}

func main() {
	port := "8765"
	if len(os.Args) > 1 {
		port = os.Args[1]
	}

	loadPersistedConfig()
	addLog("Menjalankan mesin Multi-Pairing v7.0 di 0.0.0.0:" + port)
	go func() {
		_ = ensureYtDlpAvailable()
	}()
	go initMultiSessions()

	http.HandleFunc("/wa-ui", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		_, _ = w.Write([]byte(localWaWebHtml))
	})

	http.HandleFunc("/vps/ssh-check", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		w.Header().Set("Content-Type", "application/json")
		var req struct {
			Host    string `json:"host"`
			SshPort string `json:"sshPort"`
			User    string `json:"user"`
			Pass    string `json:"pass"`
			Action  string `json:"action"`
		}
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": err.Error()})
			return
		}
		cmd := "if systemctl is-active --quiet gemini-wabot 2>/dev/null || pgrep -x wabot_engine >/dev/null 2>&1; then echo 'AKTIF (Berjalan Normal)'; else echo 'NONAKTIF'; fi"
		if req.Action == "restart" {
			cmd = "(systemctl restart gemini-wabot 2>/dev/null || (killall -9 wabot_engine 2>/dev/null || pkill -9 -x wabot_engine 2>/dev/null || true; nohup /opt/gemini-wabot/wabot_engine 8765 >/opt/gemini-wabot/bot.log 2>&1 &)) && sleep 2 && echo 'BERHASIL DI-RESTART'"
		}
		out, err := runSshCommand(req.Host, req.SshPort, req.User, req.Pass, cmd)
		if err != nil {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": err.Error(), "output": out})
			return
		}
		_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": true, "output": out})
	})

	http.HandleFunc("/vps/connect", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		w.Header().Set("Content-Type", "application/json")
		var req struct {
			Host         string `json:"host"`
			SshPort      string `json:"sshPort"`
			User         string `json:"user"`
			Pass         string `json:"pass"`
			BotPort      string `json:"botPort"`
			GzPath       string `json:"gzPath"`
			ForceInstall bool   `json:"forceInstall"`
		}
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": err.Error()})
			return
		}
		cleanH := cleanVpsHost(req.Host)
		bPort := strings.TrimSpace(req.BotPort)
		if bPort == "" {
			bPort = "8765"
		}
		msg, err := deployAndStartVpsEngine(cleanH, req.SshPort, req.User, req.Pass, bPort, req.GzPath, req.ForceInstall)
		if err != nil {
			addLog("[VPS Connect Error] " + err.Error())
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": err.Error()})
			return
		}
		vpsUrl := fmt.Sprintf("http://%s:%s", cleanH, bPort)
		addLog("[VPS Connected] " + msg)
		_ = json.NewEncoder(w).Encode(map[string]interface{}{
			"ok":      true,
			"vpsUrl":  vpsUrl,
			"host":    cleanH,
			"botPort": bPort,
			"message": msg,
		})
	})

	http.HandleFunc("/shutdown", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		addLog("[Shutdown] Mematikan semua sesi & menghentikan proses mesin...")
		mu.Lock()
		for _, s := range sessions {
			if s.Client != nil && s.Client.IsConnected() {
				s.Client.Disconnect()
			}
			if s.Container != nil {
				_ = s.Container.Close()
			}
		}
		mu.Unlock()
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]bool{"ok": true})
		go func() {
			time.Sleep(200 * time.Millisecond)
			os.Exit(0)
		}()
	})

	http.HandleFunc("/status", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		mu.Lock()
		sessList := make([]map[string]interface{}, 0, len(sessions))
		anyLoggedIn := false
		for _, s := range sessions {
			loggedIn := s.Client != nil && s.Client.IsLoggedIn()
			connected := s.Client != nil && s.Client.IsConnected()
			if loggedIn && s.Active && !s.GuestStatusOnly {
				anyLoggedIn = true
			}
			phoneLabel := s.Phone
			if phoneLabel == "" && s.Client != nil && s.Client.Store != nil && s.Client.Store.ID != nil {
				phoneLabel = s.Client.Store.ID.User
			}
			sessList = append(sessList, map[string]interface{}{
				"id":          s.ID,
				"phone":       phoneLabel,
				"jid":         s.JID,
				"pushName":    s.PushName,
				"active":      s.Active && !s.GuestStatusOnly,
				"loggedIn":    loggedIn,
				"connected":   connected,
				"pairingCode": s.PairingCode,
				"state":       s.State,
			})
		}
		sort.Slice(sessList, func(i, j int) bool {
			return fmt.Sprint(sessList[i]["id"]) < fmt.Sprint(sessList[j]["id"])
		})
		resp := map[string]interface{}{
			"ok":            true,
			"engineVersion": "7.0",
			"state":         "MULTI_WA_READY",
			"loggedIn":      anyLoggedIn,
			"pairingCode":   latestPairCode,
			"botEnabled":    config.BotEnabled,
			"model":         config.Model,
			"totalReplied":  totalReplied,
			"activeGroups":  len(activeGroups),
			"sessions":      sessList,
			"logs":          logs,
		}
		mu.Unlock()
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(resp)
	})

	http.HandleFunc("/config", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		if r.Method == http.MethodPost {
			var newCfg BotConfig
			if err := json.NewDecoder(r.Body).Decode(&newCfg); err == nil {
				mu.Lock()
				if strings.TrimSpace(newCfg.ApiKey) == "" && strings.TrimSpace(config.ApiKey) != "" {
					newCfg.ApiKey = config.ApiKey
				}
				if newCfg.StatusExceptList == "" {
					newCfg.StatusExceptList = config.StatusExceptList
				}
				if newCfg.StatusOnlyList == "" {
					newCfg.StatusOnlyList = config.StatusOnlyList
				}
				if newCfg.StatusCloseList == "" {
					newCfg.StatusCloseList = config.StatusCloseList
				}
				if newCfg.DefaultStatusMode == "" {
					newCfg.DefaultStatusMode = config.DefaultStatusMode
				}
				if newCfg.MenuStyle == "" {
					newCfg.MenuStyle = config.MenuStyle
				}
				if newCfg.MenuStyle == "" {
					newCfg.MenuStyle = "both"
				}
				if newCfg.BotName == "" {
					newCfg.BotName = config.BotName
				}
				if newCfg.BotName == "" {
					newCfg.BotName = "DodosBot"
				}
				if strings.TrimSpace(newCfg.Model) == "" || strings.Contains(strings.ToLower(newCfg.Model), "1.5") {
					if config.Model != "" && !strings.Contains(strings.ToLower(config.Model), "1.5") {
						newCfg.Model = config.Model
					} else {
						newCfg.Model = "gemini-2.5-flash"
					}
				}
				config = newCfg
				mu.Unlock()
				savePersistedConfig()
				addLog(fmt.Sprintf("Konfigurasi disimpan (Model: %s, Scope: %s)", newCfg.Model, newCfg.ReplyScope))
			}
		}
		mu.Lock()
		defer mu.Unlock()
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(config)
	})

	http.HandleFunc("/pair", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		rawPhone := r.URL.Query().Get("phone")
		cleanPhone := normalizePhone(rawPhone)
		w.Header().Set("Content-Type", "application/json")

		if len(cleanPhone) < 9 {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{
				"ok":    false,
				"error": "Nomor WA tidak valid. Gunakan format 628xxxxxxxxxx",
			})
			return
		}

		mu.Lock()
		existing, ok := sessions[cleanPhone]
		mu.Unlock()
		if ok && existing != nil && existing.Client != nil && existing.Client.IsLoggedIn() {
			mu.Lock()
			existing.Active = true
			existing.GuestStatusOnly = false
			mu.Unlock()
			saveSessionsMeta()
			addLog("Nomor WA " + cleanPhone + " sudah tertaut dan aktif!")
			_ = json.NewEncoder(w).Encode(map[string]interface{}{
				"ok":          true,
				"phone":       cleanPhone,
				"pairingCode": "SUDAH-TERTAUT",
			})
			return
		}

		destroySessionAndDB(cleanPhone)
		destroySessionAndDB("default")
		dbFile := fmt.Sprintf("session_%s.db", cleanPhone)
		removeSqliteFiles(dbFile)

		sess, err := createOrLoadSession(cleanPhone, cleanPhone, dbFile, true)
		if err != nil || sess == nil || sess.Client == nil {
			errStr := "Gagal menyiapkan database sesi bersih"
			if err != nil {
				errStr = err.Error()
			}
			_ = json.NewEncoder(w).Encode(map[string]interface{}{
				"ok":    false,
				"error": errStr,
			})
			return
		}

		addLog("Menghubungkan ke server WhatsApp untuk meminta Pairing Code nomor " + cleanPhone + "...")
		if sess.Client.IsConnected() {
			sess.Client.Disconnect()
			time.Sleep(300 * time.Millisecond)
		}
		if err := sess.Client.Connect(); err != nil {
			addLog("Gagal connect ke WhatsApp WebSocket: " + err.Error())
			_ = json.NewEncoder(w).Encode(map[string]interface{}{
				"ok":    false,
				"error": "Gagal terhubung ke server WA: " + err.Error(),
			})
			return
		}

		for i := 0; i < 20; i++ {
			if sess.Client.IsConnected() {
				break
			}
			time.Sleep(100 * time.Millisecond)
		}
		time.Sleep(1000 * time.Millisecond)

		code, err := sess.Client.PairPhone(
			context.Background(),
			cleanPhone,
			true,
			whatsmeow.PairClientChrome,
			"Chrome (Linux)",
		)
		if err != nil {
			addLog("Gagal mengambil Pairing Code dari WA: " + err.Error())
			_ = json.NewEncoder(w).Encode(map[string]interface{}{
				"ok":    false,
				"error": err.Error(),
			})
			return
		}

		mu.Lock()
		sess.PairingCode = code
		sess.State = "WAITING_USER_PAIR_INPUT"
		latestPairCode = code
		mu.Unlock()
		addLog(fmt.Sprintf("PAIRING CODE [%s]: %s (Segera masukkan di WA -> Perangkat Tertaut)", cleanPhone, code))

		_ = json.NewEncoder(w).Encode(map[string]interface{}{
			"ok":          true,
			"phone":       cleanPhone,
			"pairingCode": code,
		})
	})

	http.HandleFunc("/session/toggle", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		id := r.URL.Query().Get("id")
		activeStr := r.URL.Query().Get("active")
		active := activeStr == "true" || activeStr == "1"

		mu.Lock()
		sess, ok := sessions[id]
		if ok && sess != nil {
			sess.Active = active
			if active {
				sess.GuestStatusOnly = false
			} else {
				sess.GuestStatusOnly = true
			}
		}
		mu.Unlock()

		if ok && sess != nil {
			saveSessionsMeta()
			if active {
				addLog(fmt.Sprintf("[Multi-WA] Bot AI DIAKTIFKAN untuk nomor %s", sess.Phone))
			} else {
				addLog(fmt.Sprintf("[Multi-WA] Bot AI DIJEDA (Khusus Status HD) untuk nomor %s", sess.Phone))
			}
		}
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]bool{"ok": ok})
	})

	http.HandleFunc("/session/delete", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		id := r.URL.Query().Get("id")
		mu.Lock()
		sess, ok := sessions[id]
		mu.Unlock()
		if ok && sess != nil {
			if sess.Client != nil && sess.Client.IsLoggedIn() {
				_ = sess.Client.Logout(context.Background())
			}
			destroySessionAndDB(id)
			saveSessionsMeta()
			addLog(fmt.Sprintf("[Multi-WA] Sesi nomor %s berhasil dihapus.", id))
		}
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]bool{"ok": true})
	})

	http.HandleFunc("/api/status-upload", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		w.Header().Set("Content-Type", "application/json")
		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusOK)
			return
		}
		var req struct {
			SessionID        string `json:"sessionId"`
			MimeType         string `json:"mimeType"`
			Base64Data       string `json:"base64Data"`
			Caption          string `json:"caption"`
			AudienceMode     string `json:"audienceMode"`
			AudienceNumbers  string `json:"audienceNumbers"`
			MentionNumbers   string `json:"mentionNumbers"`
			StatusExceptList string `json:"statusExceptList"`
			StatusOnlyList   string `json:"statusOnlyList"`
			StatusCloseList  string `json:"statusCloseList"`
		}
		if err := json.NewDecoder(io.LimitReader(r.Body, 150*1024*1024)).Decode(&req); err != nil {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": "Data terlalu besar atau tidak valid: " + err.Error()})
			return
		}

		mu.Lock()
		if req.AudienceMode != "" {
			config.DefaultStatusMode = req.AudienceMode
		}
		config.StatusExceptList = req.StatusExceptList
		config.StatusOnlyList = req.StatusOnlyList
		config.StatusCloseList = req.StatusCloseList
		sess := sessions[req.SessionID]
		mu.Unlock()
		savePersistedConfig()

		if sess == nil {
			sess = getPrimaryActiveSession()
		}
		if sess == nil || sess.Client == nil || !sess.Client.IsLoggedIn() {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": "Nomor WA belum tertaut / belum aktif"})
			return
		}

		audMode := req.AudienceMode
		if audMode == "" {
			audMode = "contacts"
		}
		audList := parsePhoneList(req.AudienceNumbers)
		mentions := parsePhoneList(req.MentionNumbers)

		if strings.TrimSpace(req.Base64Data) == "" {
			if err := uploadStatusHD(context.Background(), sess, "text", nil, "text/plain", req.Caption, audMode, audList, mentions); err != nil {
				_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": err.Error()})
				return
			}
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": true})
			return
		}

		rawBytes, err := base64.StdEncoding.DecodeString(req.Base64Data)
		if err != nil {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": "Gagal decode file media: " + err.Error()})
			return
		}
		mediaKind := "image"
		if strings.HasPrefix(strings.ToLower(req.MimeType), "video/") {
			mediaKind = "video"
		}
		if err := uploadStatusHD(context.Background(), sess, mediaKind, rawBytes, req.MimeType, req.Caption, audMode, audList, mentions); err != nil {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": err.Error()})
			return
		}
		_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": true})
	})

	http.HandleFunc("/groups/list", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		w.Header().Set("Content-Type", "application/json")
		sess := getPrimaryActiveSession()
		if sess == nil || sess.Client == nil || !sess.Client.IsLoggedIn() {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": "Nomor WA Bot belum aktif"})
			return
		}
		groups, err := sess.Client.GetJoinedGroups(context.Background())
		if err != nil {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": err.Error()})
			return
		}
		outList := make([]map[string]interface{}, 0, len(groups))
		for _, g := range groups {
			if g == nil {
				continue
			}
			outList = append(outList, map[string]interface{}{
				"jid":   g.JID.String(),
				"name":  g.Name,
				"count": len(g.Participants),
			})
		}
		sort.Slice(outList, func(i, j int) bool {
			return fmt.Sprint(outList[i]["name"]) < fmt.Sprint(outList[j]["name"])
		})
		_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": true, "groups": outList})
	})

	http.HandleFunc("/groups/announce", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		w.Header().Set("Content-Type", "application/json")
		var req struct {
			GroupJids []string `json:"groupJids"`
			Message   string   `json:"message"`
			Hidetag   bool     `json:"hidetag"`
			Hashtags  string   `json:"hashtags"`
		}
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil || len(req.GroupJids) == 0 || strings.TrimSpace(req.Message) == "" {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": "Pilih minimal 1 grup & isi pesan pengumuman!"})
			return
		}
		sess := getPrimaryActiveSession()
		if sess == nil || sess.Client == nil || !sess.Client.IsLoggedIn() {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": "Nomor WA Bot belum aktif"})
			return
		}
		tags := strings.TrimSpace(req.Hashtags)
		if tags == "" {
			tags = "#PENGUMUMAN #INFO_PENTING #UPDATE_GRUP #BROADCAST"
		}
		mu.Lock()
		bName := strings.TrimSpace(config.BotName)
		mu.Unlock()
		if bName == "" {
			bName = "DodosBot"
		}
		formatted := fmt.Sprintf(
			"📢 *PENGUMUMAN RESMI*\n"+
				"━━━━━━━━━━━━━━━━━━━━\n\n"+
				"%s\n\n"+
				"━━━━━━━━━━━━━━━━━━━━\n"+
				"🏷️ %s\n"+
				"⚡ _Disampaikan oleh %s_",
			strings.TrimSpace(req.Message), tags, bName,
		)

		sentCount := 0
		for idx, gStr := range req.GroupJids {
			gJID, err := types.ParseJID(gStr)
			if err != nil {
				continue
			}
			var mentions []string
			if req.Hidetag {
				if gi, gErr := sess.Client.GetGroupInfo(context.Background(), gJID); gErr == nil && gi != nil {
					for _, p := range gi.Participants {
						mentions = append(mentions, p.JID.String())
					}
				}
			}
			var msgObj *waE2E.Message
			if len(mentions) > 0 {
				msgObj = &waE2E.Message{
					ExtendedTextMessage: &waE2E.ExtendedTextMessage{
						Text: proto.String(formatted),
						ContextInfo: &waE2E.ContextInfo{
							MentionedJID: mentions,
						},
					},
				}
			} else {
				msgObj = &waE2E.Message{
					Conversation: proto.String(formatted),
				}
			}
			if resp, sErr := sess.Client.SendMessage(context.Background(), gJID, msgObj); sErr == nil {
				sentCount++
				if resp.ID != "" {
					mu.Lock()
					botSentIDs[resp.ID] = true
					mu.Unlock()
				}
			}
			if idx < len(req.GroupJids)-1 {
				time.Sleep(1500 * time.Millisecond)
			}
		}
		addLog(fmt.Sprintf("[Pengumuman] Terkirim ke %d/%d grup terpilih.", sentCount, len(req.GroupJids)))
		_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": true, "sent": sentCount, "total": len(req.GroupJids)})
	})

	http.HandleFunc("/terminal/exec", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		w.Header().Set("Content-Type", "application/json")
		var req struct {
			Mode    string `json:"mode"`
			Command string `json:"command"`
			Host    string `json:"host"`
			SshPort string `json:"sshPort"`
			User    string `json:"user"`
			Pass    string `json:"pass"`
		}
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "output": err.Error()})
			return
		}
		cmdStr := strings.TrimSpace(req.Command)
		if cmdStr == "" {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": true, "output": ""})
			return
		}
		// Jalankan di Sesi 2 terpisah agar tidak memengaruhi proses bot WhatsApp!
		if strings.ToUpper(req.Mode) == "VPS" && strings.TrimSpace(req.Host) != "" && strings.TrimSpace(req.Pass) != "" {
			out, err := runSshCommand(req.Host, req.SshPort, req.User, req.Pass, cmdStr)
			if err != nil && out == "" {
				out = "Error: " + err.Error()
			}
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": err == nil, "output": out})
			return
		}
		ctxCmd, cancel := context.WithTimeout(context.Background(), 20*time.Second)
		defer cancel()
		shBin := "/system/bin/sh"
		if _, err := os.Stat(shBin); err != nil {
			shBin = "/bin/sh"
		}
		c := exec.CommandContext(ctxCmd, shBin, "-c", cmdStr)
		outBytes, err := c.CombinedOutput()
		out := strings.TrimSpace(string(outBytes))
		if err != nil && out == "" {
			out = err.Error()
		}
		_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": err == nil, "output": out})
	})

	http.HandleFunc("/backup/export", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		w.Header().Set("Content-Type", "application/json")
		mu.Lock()
		payload := map[string]interface{}{
			"version":      "5.0",
			"exportedAt":   time.Now().Format(time.RFC3339),
			"config":       config,
			"activeGroups": activeGroups,
			"mutedPrivate": mutedPrivate,
		}
		mu.Unlock()
		_ = json.NewEncoder(w).Encode(payload)
	})

	http.HandleFunc("/backup/import", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		w.Header().Set("Content-Type", "application/json")
		var payload struct {
			Config       BotConfig       `json:"config"`
			ActiveGroups map[string]bool `json:"activeGroups"`
			MutedPrivate map[string]bool `json:"mutedPrivate"`
		}
		if err := json.NewDecoder(r.Body).Decode(&payload); err != nil {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": err.Error()})
			return
		}
		mu.Lock()
		if payload.Config.BotName != "" {
			payload.Config.Model = sanitizeModelName(payload.Config.Model)
			config = payload.Config
		}
		for k, v := range payload.ActiveGroups {
			activeGroups[k] = v
		}
		for k, v := range payload.MutedPrivate {
			mutedPrivate[k] = v
		}
		mu.Unlock()
		savePersistedConfig()
		addLog("[Backup Restore] Konfigurasi & daftar grup berhasil dipulihkan!")
		_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": true, "config": config})
	})

	http.HandleFunc("/mc/action", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		w.Header().Set("Content-Type", "application/json")
		var req struct {
			Host           string `json:"host"`
			SshPort        string `json:"sshPort"`
			User           string `json:"user"`
			Pass           string `json:"pass"`
			Action         string `json:"action"`
			ServerType     string `json:"serverType"` // "bedrock" or "paper"
			Command        string `json:"command"`
			ServerName     string `json:"serverName"`
			MaxPlayers     string `json:"maxPlayers"`
			Gamemode       string `json:"gamemode"`
		}
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": err.Error()})
			return
		}
		if strings.TrimSpace(req.Host) == "" || strings.TrimSpace(req.Pass) == "" {
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": "Mode Server Minecraft hanya tersedia saat terhubung ke VPS!"})
			return
		}
		var cmd string
		switch req.Action {
		case "status":
			cmd = `RUNNING=$(pgrep -f 'bedrock_server|paper.jar' >/dev/null && echo ONLINE || echo OFFLINE); ` +
				`INSTALLED=$(test -x /opt/mc-server/bedrock_server && echo bedrock || (test -f /opt/mc-server/paper.jar && echo paper || echo none)); ` +
				`RAM=$(free -m | awk '/Mem:/ {printf "%s/%sMB", $3, $2}'); ` +
				`echo "STATUS:$RUNNING|TYPE:$INSTALLED|RAM:$RAM"; ` +
				`tail -n 18 /opt/mc-server/mc.log 2>/dev/null || echo 'Belum ada log server.'`
		case "install_bedrock":
			cmd = `mkdir -p /opt/mc-server && cd /opt/mc-server && ` +
				`(command -v unzip >/dev/null 2>&1 || apt-get update -qq && apt-get install -y -qq unzip screen curl libcurl4 >/dev/null 2>&1) && ` +
				`URL=$(curl -sL -A 'Mozilla/5.0' 'https://net-secondary.web.minecraft-services.net/api/v1.0/download/links' | grep -oE 'https://www\.minecraft\.net/bedrockdedicatedserver/bin-linux/bedrock-server-[0-9.]+\.zip' | head -n1); ` +
				`if [ -z "$URL" ]; then URL='https://www.minecraft.net/bedrockdedicatedserver/bin-linux/bedrock-server-1.21.51.02.zip'; fi; ` +
				`curl -sL -A 'Mozilla/5.0' "$URL" -o bds.zip && unzip -o -q bds.zip && rm -f bds.zip && chmod +x bedrock_server && ` +
				`(ufw allow 19132/udp 2>/dev/null || true) && echo '✅ Bedrock Server BDS berhasil dipasang di /opt/mc-server!'`
		case "install_paper":
			cmd = `mkdir -p /opt/mc-server && cd /opt/mc-server && ` +
				`(command -v java >/dev/null 2>&1 || (apt-get update -qq && apt-get install -y -qq openjdk-21-jre-headless screen curl jq >/dev/null 2>&1)) && ` +
				`curl -sL 'https://api.papermc.io/v2/projects/paper/versions/1.21.4/builds/185/downloads/paper-1.21.4-185.jar' -o paper.jar && ` +
				`echo 'eula=true' > eula.txt && (ufw allow 25565/tcp 2>/dev/null || true) && echo '✅ Java PaperMC 1.21.4 berhasil dipasang di /opt/mc-server!'`
		case "start":
			cmd = `cd /opt/mc-server && (screen -S mcserver -X quit 2>/dev/null || true); ` +
				`if [ -x /opt/mc-server/bedrock_server ]; then ` +
				`screen -dmS mcserver bash -c 'cd /opt/mc-server && LD_LIBRARY_PATH=. ./bedrock_server > mc.log 2>&1'; echo '🟢 Bedrock Server Dinyalakan (Port 19132)!'; ` +
				`elif [ -f /opt/mc-server/paper.jar ]; then ` +
				`screen -dmS mcserver bash -c 'cd /opt/mc-server && java -Xms512M -Xmx1536M -jar paper.jar --nogui > mc.log 2>&1'; echo '🟢 PaperMC Server Dinyalakan (Port 25565)!'; ` +
				`else echo '❌ Server belum terpasang. Klik Pasang Bedrock / Paper dulu!'; fi`
		case "stop":
			cmd = `screen -S mcserver -p 0 -X stuff "stop\n" 2>/dev/null || true; sleep 2; pkill -f 'bedrock_server|paper.jar' 2>/dev/null || true; echo '🔴 Server Minecraft Dimatikan.'`
		case "cmd":
			safeCmd := strings.ReplaceAll(req.Command, string('"'), "")
			cmd = fmt.Sprintf(`screen -S mcserver -p 0 -X stuff "%s\n" && sleep 1 && tail -n 15 /opt/mc-server/mc.log 2>/dev/null`, safeCmd)
		case "save_props":
			sName := strings.TrimSpace(req.ServerName)
			if sName == "" {
				sName = "DodosMC Server"
			}
			mPlay := strings.TrimSpace(req.MaxPlayers)
			if mPlay == "" {
				mPlay = "20"
			}
			gMode := strings.TrimSpace(req.Gamemode)
			if gMode == "" {
				gMode = "survival"
			}
			cmd = fmt.Sprintf(
				`mkdir -p /opt/mc-server && touch /opt/mc-server/server.properties && `+
					`sed -i '/^server-name=/d;/^motd=/d;/^max-players=/d;/^gamemode=/d' /opt/mc-server/server.properties && `+
					`printf 'server-name=%s\nmotd=%s\nmax-players=%s\ngamemode=%s\n' >> /opt/mc-server/server.properties && `+
					`echo '✅ server.properties disimpan! Restart server untuk menerapkan.'`,
				sName, sName, mPlay, gMode,
			)
		default:
			_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": "Aksi tidak dikenal"})
			return
		}
		out, err := runSshCommand(req.Host, req.SshPort, req.User, req.Pass, cmd)
		_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": err == nil, "output": out})
	})

	http.HandleFunc("/reset-memory", func(w http.ResponseWriter, r *http.Request) {
		setCors(w)
		mu.Lock()
		memory = make(map[string][]ChatTurn)
		mu.Unlock()
		addLog("Memori percakapan semua nomor berhasil di-reset.")
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]bool{"ok": true})
	})

	log.Fatal(http.ListenAndServe("0.0.0.0:"+port, nil))
}
