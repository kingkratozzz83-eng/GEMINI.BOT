module gemini-wabot-engine

go 1.22
