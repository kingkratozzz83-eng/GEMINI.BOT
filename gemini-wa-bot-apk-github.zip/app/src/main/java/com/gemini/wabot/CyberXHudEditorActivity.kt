package com.gemini.wabot

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.util.UUID

class CyberXHudEditorActivity : AppCompatActivity() {

    private lateinit var storage: CyberXStorageManager
    private lateinit var allProfiles: MutableList<CyberXHudProfile>
    private lateinit var activeProfile: CyberXHudProfile
    private var selectedBtnId: String? = null
    private var isPlayPreviewMode = false

    private val undoStack = ArrayDeque<CyberXHudProfile>()
    private val redoStack = ArrayDeque<CyberXHudProfile>()

    private lateinit var canvasFrame: FrameLayout
    private lateinit var tvProfileName: TextView
    private lateinit var tvSelectedInfo: TextView
    private lateinit var btnPreviewToggle: Button
    private lateinit var controlPanel: LinearLayout
    private lateinit var seekSize: SeekBar
    private lateinit var seekAlpha: SeekBar
    private lateinit var btnLockToggle: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        storage = CyberXStorageManager(this)
        allProfiles = storage.getHudProfiles()
        activeProfile = (allProfiles.firstOrNull { it.id == storage.activeHudProfileId } ?: allProfiles.first()).deepCopy()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#060810"))
        }

        // === TOP BAR ===
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#0D111C"))
            setPadding(16, 12, 16, 12)
        }
        val btnBack = makeBarBtn("< Kembali", "#1E293B") { finish() }
        tvProfileName = TextView(this).apply {
            text = "HUD: ${activeProfile.name}"
            setTextColor(Color.WHITE)
            textSize = 13f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(16, 0, 12, 0)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { showProfilePickerDialog() }
        }
        val btnUndo = makeBarBtn("Undo", "#1E293B") { performUndo() }
        val btnRedo = makeBarBtn("Redo", "#1E293B") { performRedo() }
        btnPreviewToggle = makeBarBtn("Preview", "#0284C7") {
            isPlayPreviewMode = !isPlayPreviewMode
            btnPreviewToggle.text = if (isPlayPreviewMode) "Edit Mode" else "Preview"
            controlPanel.visibility = if (isPlayPreviewMode) View.GONE else View.VISIBLE
            renderCanvasButtons()
        }
        val btnSave = makeBarBtn("Simpan", "#10B981", Color.BLACK) {
            saveActiveProfile()
            Toast.makeText(this, "Layout '${activeProfile.name}' disimpan!", Toast.LENGTH_SHORT).show()
        }

        topBar.addView(btnBack)
        topBar.addView(tvProfileName)
        topBar.addView(btnUndo)
        topBar.addView(btnRedo)
        topBar.addView(btnPreviewToggle)
        topBar.addView(btnSave)
        root.addView(topBar)

        // === INTERACTIVE CANVAS ===
        val bodyRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }

        canvasFrame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
            addView(HudGridView(this@CyberXHudEditorActivity))
        }
        bodyRow.addView(canvasFrame)

        // === RIGHT INSPECTOR PANEL ===
        controlPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0B0F1A"))
            setPadding(14, 12, 14, 12)
            layoutParams = LinearLayout.LayoutParams(420, LinearLayout.LayoutParams.MATCH_PARENT)
        }

        tvSelectedInfo = TextView(this).apply {
            text = "Pilih tombol di canvas atau tambah baru"
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 11f
            typeface = android.graphics.Typeface.MONOSPACE
        }
        controlPanel.addView(tvSelectedInfo)

        val rowAddReset = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 10, 0, 6)
        }
        rowAddReset.addView(makeBarBtn("+ Tombol", "#E11D48") { addNewButton() })
        rowAddReset.addView(makeBarBtn("Reset", "#334155") { confirmReset() })
        rowAddReset.addView(makeBarBtn("IO JSON", "#334155") { showImportExportDialog() })
        controlPanel.addView(rowAddReset)

        val lblSize = TextView(this).apply { text = "Ukuran Tombol"; setTextColor(Color.WHITE); textSize = 11f }
        seekSize = SeekBar(this).apply {
            max = 60 // 36dp..96dp
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    getSelectedButton()?.let { b ->
                        b.sizeDp = 36 + p
                        renderCanvasButtons()
                    }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) { pushUndoSnapshot() }
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        val lblAlpha = TextView(this).apply { text = "Transparansi"; setTextColor(Color.WHITE); textSize = 11f }
        seekAlpha = SeekBar(this).apply {
            max = 80 // 0.2..1.0
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    getSelectedButton()?.let { b ->
                        b.alpha = 0.2f + (p / 100f)
                        renderCanvasButtons()
                    }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) { pushUndoSnapshot() }
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        controlPanel.addView(lblSize)
        controlPanel.addView(seekSize)
        controlPanel.addView(lblAlpha)
        controlPanel.addView(seekAlpha)

        val rowAttrs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 6) }
        rowAttrs.addView(makeBarBtn("Ikon", "#1E293B") { pickIconForSelected() })
        rowAttrs.addView(makeBarBtn("Warna", "#1E293B") { cycleColorForSelected() })
        btnLockToggle = makeBarBtn("Kunci", "#1E293B") { toggleLockSelected() }
        rowAttrs.addView(btnLockToggle)
        controlPanel.addView(rowAttrs)

        val rowDel = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 4, 0, 4) }
        rowDel.addView(makeBarBtn("Nama/Macro", "#1E293B") { editSelectedLabelAndMacro() })
        rowDel.addView(makeBarBtn("Hapus", "#991B1B") { deleteSelectedButton() })
        controlPanel.addView(rowDel)

        bodyRow.addView(controlPanel)
        root.addView(bodyRow)
        setContentView(root)

        canvasFrame.post { renderCanvasButtons() }
    }

    private fun makeBarBtn(label: String, bgHex: String, txtColor: Int = Color.WHITE, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 10.5f
            isAllCaps = false
            setTextColor(txtColor)
            setBackgroundColor(Color.parseColor(bgHex))
            setPadding(16, 8, 16, 8)
            minHeight = 0; minimumHeight = 0
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                marginEnd = 6
            }
            setOnClickListener { onClick() }
        }
    }

    private fun pushUndoSnapshot() {
        undoStack.addLast(activeProfile.deepCopy())
        if (undoStack.size > 20) undoStack.removeFirst()
        redoStack.clear()
    }

    private fun performUndo() {
        if (undoStack.isEmpty()) return
        redoStack.addLast(activeProfile.deepCopy())
        activeProfile = undoStack.removeLast()
        renderCanvasButtons()
    }

    private fun performRedo() {
        if (redoStack.isEmpty()) return
        undoStack.addLast(activeProfile.deepCopy())
        activeProfile = redoStack.removeLast()
        renderCanvasButtons()
    }

    private fun getSelectedButton(): CyberXHudButton? = activeProfile.buttons.firstOrNull { it.id == selectedBtnId }

    private fun updateInspector() {
        val b = getSelectedButton()
        if (b == null) {
            tvSelectedInfo.text = "Tap tombol pada canvas untuk mengedit"
            return
        }
        val cw = canvasFrame.width.coerceAtLeast(1)
        val ch = canvasFrame.height.coerceAtLeast(1)
        tvSelectedInfo.text = "${b.label} | X:${(b.xNorm * cw).toInt()} Y:${(b.yNorm * ch).toInt()} | ${b.sizeDp}dp"
        seekSize.progress = (b.sizeDp - 36).coerceIn(0, 60)
        seekAlpha.progress = ((b.alpha - 0.2f) * 100f).toInt().coerceIn(0, 80)
        btnLockToggle.text = if (b.locked) "Terkunci" else "Kunci"
    }

    private fun renderCanvasButtons() {
        // Keep grid view at index 0
        while (canvasFrame.childCount > 1) {
            canvasFrame.removeViewAt(1)
        }
        val cw = canvasFrame.width.toFloat().coerceAtLeast(100f)
        val ch = canvasFrame.height.toFloat().coerceAtLeast(100f)
        val density = resources.displayMetrics.density

        for (b in activeProfile.buttons) {
            val pxSize = (b.sizeDp * density).toInt()
            val isSel = (!isPlayPreviewMode && b.id == selectedBtnId)
            val container = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                alpha = b.alpha
                background = CyberXGlassCardDrawable(
                    fillColor = Color.parseColor("#CC0A0E18"),
                    borderColor = Color.parseColor(if (isSel) "#FFFFFF" else b.colorHex),
                    cornerPx = pxSize / 3f,
                    strokePx = if (isSel) 5f else 3f
                )
            }
            val iv = ImageView(this).apply {
                setImageResource(CyberXIconMapper.resolveIconRes(b.iconKey))
                layoutParams = LinearLayout.LayoutParams((pxSize * 0.45f).toInt(), (pxSize * 0.45f).toInt())
            }
            val tv = TextView(this).apply {
                text = b.label
                setTextColor(Color.WHITE)
                textSize = 9f
                gravity = Gravity.CENTER
            }
            container.addView(iv)
            container.addView(tv)

            val lp = FrameLayout.LayoutParams(pxSize, pxSize).apply {
                leftMargin = (b.xNorm * cw - pxSize / 2f).toInt().coerceIn(0, (cw - pxSize).toInt().coerceAtLeast(0))
                topMargin = (b.yNorm * ch - pxSize / 2f).toInt().coerceIn(0, (ch - pxSize).toInt().coerceAtLeast(0))
            }

            if (!isPlayPreviewMode) {
                var downX = 0f; var downY = 0f; var startL = 0; var startT = 0; var moved = false
                container.setOnTouchListener { v, ev ->
                    when (ev.action) {
                        MotionEvent.ACTION_DOWN -> {
                            selectedBtnId = b.id
                            downX = ev.rawX; downY = ev.rawY
                            val curLp = v.layoutParams as FrameLayout.LayoutParams
                            startL = curLp.leftMargin; startT = curLp.topMargin
                            moved = false
                            updateInspector()
                            true
                        }
                        MotionEvent.ACTION_MOVE -> {
                            if (b.locked) return@setOnTouchListener true
                            val dx = (ev.rawX - downX).toInt()
                            val dy = (ev.rawY - downY).toInt()
                            if (!moved && (kotlin.math.abs(dx) > 6 || kotlin.math.abs(dy) > 6)) {
                                pushUndoSnapshot()
                                moved = true
                            }
                            val curLp = v.layoutParams as FrameLayout.LayoutParams
                            curLp.leftMargin = (startL + dx).coerceIn(0, (cw - pxSize).toInt().coerceAtLeast(0))
                            curLp.topMargin = (startT + dy).coerceIn(0, (ch - pxSize).toInt().coerceAtLeast(0))
                            v.layoutParams = curLp
                            b.xNorm = (curLp.leftMargin + pxSize / 2f) / cw
                            b.yNorm = (curLp.topMargin + pxSize / 2f) / ch
                            updateInspector()
                            true
                        }
                        MotionEvent.ACTION_UP -> {
                            renderCanvasButtons()
                            true
                        }
                        else -> false
                    }
                }
            } else {
                container.setOnClickListener {
                    Toast.makeText(this, "Preview Tombol: ${b.label}", Toast.LENGTH_SHORT).show()
                }
            }
            canvasFrame.addView(container, lp)
        }
        updateInspector()
    }

    private fun addNewButton() {
        pushUndoSnapshot()
        val nb = CyberXHudButton(
            id = UUID.randomUUID().toString(),
            label = "BTN${activeProfile.buttons.size + 1}",
            xNorm = 0.5f,
            yNorm = 0.5f
        )
        activeProfile.buttons.add(nb)
        selectedBtnId = nb.id
        renderCanvasButtons()
    }

    private fun pickIconForSelected() {
        val b = getSelectedButton() ?: return
        val names = CyberXIconMapper.availableIcons.map { it.second }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Pilih Ikon Tombol")
            .setItems(names) { _, idx ->
                pushUndoSnapshot()
                b.iconKey = CyberXIconMapper.availableIcons[idx].first
                renderCanvasButtons()
            }
            .show()
    }

    private fun cycleColorForSelected() {
        val b = getSelectedButton() ?: return
        pushUndoSnapshot()
        val palette = listOf("#FF1744", "#00E5FF", "#10B981", "#FDE047", "#FFFFFF")
        val next = palette[(palette.indexOf(b.colorHex) + 1) % palette.size]
        b.colorHex = next
        renderCanvasButtons()
    }

    private fun toggleLockSelected() {
        val b = getSelectedButton() ?: return
        pushUndoSnapshot()
        b.locked = !b.locked
        renderCanvasButtons()
    }

    private fun editSelectedLabelAndMacro() {
        val b = getSelectedButton() ?: return
        val macros = storage.getMacros()
        val input = EditText(this).apply { setText(b.label) }
        val macroNames = listOf("(Tanpa Macro)") + macros.map { it.name }
        AlertDialog.Builder(this)
            .setTitle("Ubah Label Tombol")
            .setView(input)
            .setPositiveButton("Simpan Label") { _, _ ->
                pushUndoSnapshot()
                b.label = input.text.toString().trim().ifEmpty { "BTN" }
                renderCanvasButtons()
            }
            .setNeutralButton("Kaitkan Macro") { _, _ ->
                AlertDialog.Builder(this)
                    .setTitle("Pilih Macro untuk ${b.label}")
                    .setItems(macroNames.toTypedArray()) { _, idx ->
                        pushUndoSnapshot()
                        b.linkedMacroId = if (idx == 0) "" else macros[idx - 1].id
                        renderCanvasButtons()
                    }
                    .show()
            }
            .show()
    }

    private fun deleteSelectedButton() {
        val b = getSelectedButton() ?: return
        AlertDialog.Builder(this)
            .setTitle("Hapus Tombol?")
            .setMessage("Yakin ingin menghapus tombol '${b.label}' dari HUD?")
            .setPositiveButton("Hapus") { _, _ ->
                pushUndoSnapshot()
                activeProfile.buttons.removeAll { it.id == b.id }
                selectedBtnId = null
                renderCanvasButtons()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun confirmReset() {
        AlertDialog.Builder(this)
            .setTitle("Reset Layout?")
            .setMessage("Kembalikan posisi tombol ke preset awal?")
            .setPositiveButton("Reset") { _, _ ->
                pushUndoSnapshot()
                activeProfile.buttons.clear()
                activeProfile.buttons.add(CyberXHudButton("b1", "AIM", "ic_rm_ai", "#FF1744", 0.85f, 48, 0.14f, 0.30f))
                renderCanvasButtons()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun saveActiveProfile() {
        val idx = allProfiles.indexOfFirst { it.id == activeProfile.id }
        if (idx >= 0) allProfiles[idx] = activeProfile.deepCopy() else allProfiles.add(activeProfile.deepCopy())
        storage.saveHudProfiles(allProfiles)
        storage.activeHudProfileId = activeProfile.id
    }

    private fun showProfilePickerDialog() {
        val names = (allProfiles.map { it.name } + "+ Buat Profil Baru").toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Pilih Profil HUD")
            .setItems(names) { _, idx ->
                if (idx == allProfiles.size) {
                    val inp = EditText(this).apply { hint = "Nama Profil HUD" }
                    AlertDialog.Builder(this)
                        .setTitle("Profil HUD Baru")
                        .setView(inp)
                        .setPositiveButton("Buat") { _, _ ->
                            val np = CyberXHudProfile(UUID.randomUUID().toString(), inp.text.toString().trim().ifEmpty { "HUD ${allProfiles.size + 1}" })
                            allProfiles.add(np)
                            activeProfile = np.deepCopy()
                            storage.saveHudProfiles(allProfiles)
                            storage.activeHudProfileId = activeProfile.id
                            tvProfileName.text = "HUD: ${activeProfile.name}"
                            renderCanvasButtons()
                        }
                        .show()
                } else {
                    activeProfile = allProfiles[idx].deepCopy()
                    storage.activeHudProfileId = activeProfile.id
                    tvProfileName.text = "HUD: ${activeProfile.name}"
                    renderCanvasButtons()
                }
            }
            .show()
    }

    private fun showImportExportDialog() {
        val jsonStr = activeProfile.toJson().toString(2)
        val inp = EditText(this).apply { setText(jsonStr); textSize = 10f }
        AlertDialog.Builder(this)
            .setTitle("Import / Export Layout JSON")
            .setView(inp)
            .setPositiveButton("Import JSON") { _, _ ->
                if (storage.importHudProfileJson(inp.text.toString())) {
                    allProfiles = storage.getHudProfiles()
                    activeProfile = storage.getActiveHudProfile().deepCopy()
                    tvProfileName.text = "HUD: ${activeProfile.name}"
                    renderCanvasButtons()
                    Toast.makeText(this, "Layout berhasil di-import!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Format JSON tidak valid", Toast.LENGTH_SHORT).show()
                }
            }
            .setNeutralButton("Salin JSON") { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("CyberX HUD", jsonStr))
                Toast.makeText(this, "JSON Layout disalin ke clipboard!", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    class HudGridView(context: Context) : View(context) {
        private val gridPaint = Paint().apply { color = Color.parseColor("#18FFFFFF"); strokeWidth = 1.5f }
        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat(); val h = height.toFloat()
            val step = 64f
            var x = step
            while (x < w) { canvas.drawLine(x, 0f, x, h, gridPaint); x += step }
            var y = step
            while (y < h) { canvas.drawLine(0f, y, w, y, gridPaint); y += step }
        }
    }
}
