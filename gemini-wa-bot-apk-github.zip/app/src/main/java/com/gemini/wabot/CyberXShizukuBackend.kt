package com.gemini.wabot

import android.content.Context
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

data class ShizukuStatusReport(
    val shizukuInstalled: Boolean,
    val binderAlive: Boolean,
    val permissionGranted: Boolean,
    val uid: Int,
    val summary: String,
    val detail: String
)

object CyberXShizukuBackend {

    @Volatile
    var lastDiagnosticError: String = ""

    fun isShizukuInstalled(context: Context): Boolean {
        return try {
            context.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun getStatus(context: Context): ShizukuStatusReport {
        val installed = isShizukuInstalled(context)
        val binder = try { Shizuku.pingBinder() } catch (_: Throwable) { false }
        if (!binder) {
            val msg = if (installed) "Shizuku terpasang tapi belum aktif. Buka aplikasi Shizuku lalu tekan Start via Wireless Debugging / ADB."
            else "Aplikasi Shizuku belum terpasang. Instal Shizuku dari Play Store / GitHub lalu aktifkan via ADB / Wireless Debugging."
            return ShizukuStatusReport(installed, false, false, -1, "Shizuku TIDAK AKTIF", msg)
        }
        val perm = try { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (_: Throwable) { false }
        val uid = try { Shizuku.getUid() } catch (_: Throwable) { -1 }
        return if (perm) {
            ShizukuStatusReport(installed, true, true, uid, "Shizuku AKTIF (UID $uid)", "Backend ADB/Shizuku siap menjalankan input sentuhan nyata.")
        } else {
            ShizukuStatusReport(installed, true, false, uid, "Izin Shizuku BELUM DIBERIKAN", "Tekan 'Minta Izin Shizuku' lalu izinkan CYBERX di popup Shizuku.")
        }
    }

    fun requestPermission(reqCode: Int = 8001): Boolean {
        return try {
            if (!Shizuku.pingBinder()) return false
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) return true
            Shizuku.requestPermission(reqCode)
            true
        } catch (e: Throwable) {
            lastDiagnosticError = "Gagal meminta izin Shizuku: ${e.message}"
            false
        }
    }

    fun execShell(cmd: String): Pair<Boolean, String> {
        val binder = try { Shizuku.pingBinder() } catch (_: Throwable) { false }
        if (!binder) {
            val err = "Shizuku tidak aktif (binder mati). Aktifkan Shizuku terlebih dahulu."
            lastDiagnosticError = err
            return false to err
        }
        val perm = try { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (_: Throwable) { false }
        if (!perm) {
            val err = "Izin Shizuku belum diberikan untuk aplikasi ini."
            lastDiagnosticError = err
            return false to err
        }
        return try {
            @Suppress("DEPRECATION")
            val proc = Shizuku.newProcess(arrayOf("sh", "-c", cmd), null, null)
            val out = BufferedReader(InputStreamReader(proc.inputStream)).readText().trim()
            val err = BufferedReader(InputStreamReader(proc.errorStream)).readText().trim()
            val code = proc.waitFor()
            if (code == 0) {
                lastDiagnosticError = ""
                true to out.ifEmpty { "OK (exit 0)" }
            } else {
                val msg = "Exit $code: ${err.ifEmpty { out.ifEmpty { "Perintah input ditolak sistem" } }}"
                lastDiagnosticError = msg
                false to msg
            }
        } catch (e: Throwable) {
            val msg = "Exception Shizuku: ${e.javaClass.simpleName}: ${e.message}"
            lastDiagnosticError = msg
            false to msg
        }
    }

    fun injectTouchStep(step: CyberXTouchStep, speedMultiplier: Float): Pair<Boolean, String> {
        val spd = speedMultiplier.coerceIn(0.25f, 4.0f)
        val x1 = step.xPx.toInt().coerceAtLeast(0)
        val y1 = step.yPx.toInt().coerceAtLeast(0)
        val x2 = step.endXPx.toInt().coerceAtLeast(0)
        val y2 = step.endYPx.toInt().coerceAtLeast(0)
        val dur = (step.durationMs / spd).toLong().coerceIn(25L, 10000L)

        val cmd = when (step.type) {
            CyberXTouchType.TAP -> "input tap $x1 $y1"
            CyberXTouchType.HOLD -> "input swipe $x1 $y1 $x1 $y1 $dur"
            CyberXTouchType.SWIPE -> "input swipe $x1 $y1 $x2 $y2 $dur"
        }
        return execShell(cmd)
    }
}
