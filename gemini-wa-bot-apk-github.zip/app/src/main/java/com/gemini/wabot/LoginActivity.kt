package com.gemini.wabot

import android.accounts.AccountManager
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.RadioButton
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    private lateinit var prefs: BotPrefsManager
    private lateinit var etEmailInput: EditText

    private val accountPickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val accountName = result.data?.getStringExtra(AccountManager.KEY_ACCOUNT_NAME) ?: ""
            if (accountName.isNotEmpty()) {
                etEmailInput.setText(accountName)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = BotPrefsManager(this)
        setContentView(R.layout.activity_login)

        val tvOwnerLockInfo: TextView = findViewById(R.id.tvOwnerLockInfo)
        val btnPickGoogleAccount: Button = findViewById(R.id.btnPickGoogleAccount)
        etEmailInput = findViewById(R.id.etEmailInput)
        val etPinInput: EditText = findViewById(R.id.etPinInput)
        val rbThemeNormal: RadioButton = findViewById(R.id.rbThemeNormal)
        val rbThemeCyber: RadioButton = findViewById(R.id.rbThemeCyber)
        if (prefs.uiThemeMode == "normal") {
            rbThemeNormal.isChecked = true
        } else {
            rbThemeCyber.isChecked = true
        }
        val switchLockOwnerEmail: CheckBox = findViewById(R.id.switchLockOwnerEmail)
        val btnContinueLogin: Button = findViewById(R.id.btnContinueLogin)

        if (prefs.ownerLockedEmail.isNotEmpty()) {
            etEmailInput.setText(prefs.ownerLockedEmail)
            switchLockOwnerEmail.isChecked = true
            tvOwnerLockInfo.text = "🔒 APK ini dikunci khusus untuk akun: ${prefs.ownerLockedEmail}"
        }

        btnPickGoogleAccount.setOnClickListener {
            try {
                val intent = AccountManager.newChooseAccountIntent(
                    null, null, arrayOf("com.google"), null, null, null, null
                )
                accountPickerLauncher.launch(intent)
            } catch (_: Exception) {
                Toast.makeText(this, "Silakan ketik alamat Gmail Anda secara manual.", Toast.LENGTH_SHORT).show()
            }
        }

        btnContinueLogin.setOnClickListener {
            val email = etEmailInput.text.toString().trim().lowercase()
            val pin = etPinInput.text.toString().trim()
            if (email.isEmpty() || !email.contains("@")) {
                Toast.makeText(this, "Masukkan alamat email Google yang valid!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val lockedOwner = prefs.ownerLockedEmail.trim().lowercase()
            if (lockedOwner.isNotEmpty() && email != lockedOwner) {
                Toast.makeText(
                    this,
                    "❌ Akses Ditolak! APK ini sudah dikunci khusus untuk pemilik ($lockedOwner).",
                    Toast.LENGTH_LONG
                ).show()
                return@setOnClickListener
            }

            if (prefs.appPin.isNotEmpty() && pin != prefs.appPin) {
                Toast.makeText(this, "❌ PIN Keamanan salah!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (switchLockOwnerEmail.isChecked) {
                prefs.ownerLockedEmail = email
            }
            if (pin.isNotEmpty() && prefs.appPin.isEmpty()) {
                prefs.appPin = pin
            }
            prefs.uiThemeMode = if (rbThemeCyber.isChecked) "cyber" else "normal"
            prefs.loggedInEmail = email

            val mainIntent = Intent(this, MainActivity::class.java).apply {
                putExtra("play_welcome_cinematic", true)
            }
            startActivity(mainIntent)
            finish()
        }
    }
}
