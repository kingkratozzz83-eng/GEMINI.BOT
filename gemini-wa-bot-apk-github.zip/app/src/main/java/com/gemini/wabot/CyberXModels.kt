package com.gemini.wabot

import org.json.JSONArray
import org.json.JSONObject

enum class CyberXActionType(val label: String) {
    DELAY("Jeda (ms)"),
    TAP_POINT("Tap Koordinat"),
    SHORTCUT_DND("Toggle DND"),
    SHORTCUT_CROSSHAIR("Ganti Crosshair"),
    SHORTCUT_VOL_UP("Volume +"),
    SHORTCUT_VOL_DOWN("Volume -")
}

data class CyberXMacroAction(
    val id: String,
    var type: CyberXActionType,
    var delayMs: Int = 80,
    var xNorm: Float = 0.5f,
    var yNorm: Float = 0.5f
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("type", type.name)
        put("delayMs", delayMs)
        put("xNorm", xNorm.toDouble())
        put("yNorm", yNorm.toDouble())
    }

    companion object {
        fun fromJson(o: JSONObject): CyberXMacroAction {
            val t = try { CyberXActionType.valueOf(o.optString("type", "DELAY")) } catch (_: Exception) { CyberXActionType.DELAY }
            return CyberXMacroAction(
                id = o.optString("id", java.util.UUID.randomUUID().toString()),
                type = t,
                delayMs = o.optInt("delayMs", 80),
                xNorm = o.optDouble("xNorm", 0.5).toFloat(),
                yNorm = o.optDouble("yNorm", 0.5).toFloat()
            )
        }
    }
}

data class CyberXMacroProfile(
    val id: String,
    var name: String,
    var enabled: Boolean = true,
    var buttonLabel: String = "M1",
    var iconKey: String = "ic_rm_ai",
    var colorHex: String = "#FF1744",
    var alpha: Float = 0.85f,
    var sizeDp: Int = 52,
    var xNorm: Float = 0.82f,
    var yNorm: Float = 0.65f,
    val actions: MutableList<CyberXMacroAction> = mutableListOf()
) {
    fun deepCopy(newId: String = id, newName: String = name): CyberXMacroProfile {
        return CyberXMacroProfile(
            id = newId,
            name = newName,
            enabled = enabled,
            buttonLabel = buttonLabel,
            iconKey = iconKey,
            colorHex = colorHex,
            alpha = alpha,
            sizeDp = sizeDp,
            xNorm = xNorm,
            yNorm = yNorm,
            actions = actions.map { it.copy() }.toMutableList()
        )
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("enabled", enabled)
        put("buttonLabel", buttonLabel)
        put("iconKey", iconKey)
        put("colorHex", colorHex)
        put("alpha", alpha.toDouble())
        put("sizeDp", sizeDp)
        put("xNorm", xNorm.toDouble())
        put("yNorm", yNorm.toDouble())
        val arr = JSONArray()
        for (a in actions) arr.put(a.toJson())
        put("actions", arr)
    }

    companion object {
        fun fromJson(o: JSONObject): CyberXMacroProfile {
            val acts = mutableListOf<CyberXMacroAction>()
            val arr = o.optJSONArray("actions")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    acts.add(CyberXMacroAction.fromJson(arr.getJSONObject(i)))
                }
            }
            return CyberXMacroProfile(
                id = o.optString("id", java.util.UUID.randomUUID().toString()),
                name = o.optString("name", "Macro Baru"),
                enabled = o.optBoolean("enabled", true),
                buttonLabel = o.optString("buttonLabel", "M1"),
                iconKey = o.optString("iconKey", "ic_rm_ai"),
                colorHex = o.optString("colorHex", "#FF1744"),
                alpha = o.optDouble("alpha", 0.85).toFloat(),
                sizeDp = o.optInt("sizeDp", 52),
                xNorm = o.optDouble("xNorm", 0.82).toFloat(),
                yNorm = o.optDouble("yNorm", 0.65).toFloat(),
                actions = acts
            )
        }
    }
}

data class CyberXHudButton(
    val id: String,
    var label: String,
    var iconKey: String = "ic_rm_server",
    var colorHex: String = "#FF1744",
    var alpha: Float = 0.85f,
    var sizeDp: Int = 54,
    var xNorm: Float = 0.5f,
    var yNorm: Float = 0.5f,
    var locked: Boolean = false,
    var linkedMacroId: String = ""
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("label", label)
        put("iconKey", iconKey)
        put("colorHex", colorHex)
        put("alpha", alpha.toDouble())
        put("sizeDp", sizeDp)
        put("xNorm", xNorm.toDouble())
        put("yNorm", yNorm.toDouble())
        put("locked", locked)
        put("linkedMacroId", linkedMacroId)
    }

    companion object {
        fun fromJson(o: JSONObject): CyberXHudButton = CyberXHudButton(
            id = o.optString("id", java.util.UUID.randomUUID().toString()),
            label = o.optString("label", "BTN"),
            iconKey = o.optString("iconKey", "ic_rm_server"),
            colorHex = o.optString("colorHex", "#FF1744"),
            alpha = o.optDouble("alpha", 0.85).toFloat(),
            sizeDp = o.optInt("sizeDp", 54),
            xNorm = o.optDouble("xNorm", 0.5).toFloat(),
            yNorm = o.optDouble("yNorm", 0.5).toFloat(),
            locked = o.optBoolean("locked", false),
            linkedMacroId = o.optString("linkedMacroId", "")
        )
    }
}

data class CyberXHudProfile(
    val id: String,
    var name: String,
    val buttons: MutableList<CyberXHudButton> = mutableListOf()
) {
    fun deepCopy(newId: String = id, newName: String = name): CyberXHudProfile =
        CyberXHudProfile(newId, newName, buttons.map { it.copy() }.toMutableList())

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        val arr = JSONArray()
        for (b in buttons) arr.put(b.toJson())
        put("buttons", arr)
    }

    companion object {
        fun fromJson(o: JSONObject): CyberXHudProfile {
            val btns = mutableListOf<CyberXHudButton>()
            val arr = o.optJSONArray("buttons")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    btns.add(CyberXHudButton.fromJson(arr.getJSONObject(i)))
                }
            }
            return CyberXHudProfile(
                id = o.optString("id", java.util.UUID.randomUUID().toString()),
                name = o.optString("name", "Default HUD"),
                buttons = btns
            )
        }
    }
}

data class CyberXGameStat(
    val packageName: String,
    var lastPlayedMs: Long = 0L,
    var playCount: Int = 0
)
