package com.gemini.wabot

import org.json.JSONArray
import org.json.JSONObject

enum class CyberXTouchType(val label: String) {
    TAP("Tap"),
    HOLD("Hold"),
    SWIPE("Swipe")
}

data class CyberXTouchStep(
    val id: String,
    var order: Int,
    var type: CyberXTouchType,
    var xPx: Float,
    var yPx: Float,
    var endXPx: Float = xPx,
    var endYPx: Float = yPx,
    var timestampMs: Long = 0L,
    var delayFromPrevMs: Long = 100L,
    var durationMs: Long = 50L
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("order", order)
        put("type", type.name)
        put("xPx", xPx.toDouble())
        put("yPx", yPx.toDouble())
        put("endXPx", endXPx.toDouble())
        put("endYPx", endYPx.toDouble())
        put("timestampMs", timestampMs)
        put("delayFromPrevMs", delayFromPrevMs)
        put("durationMs", durationMs)
    }

    companion object {
        fun fromJson(o: JSONObject): CyberXTouchStep {
            val t = try { CyberXTouchType.valueOf(o.optString("type", "TAP")) } catch (_: Exception) { CyberXTouchType.TAP }
            val xp = o.optDouble("xPx", 500.0).toFloat()
            val yp = o.optDouble("yPx", 500.0).toFloat()
            return CyberXTouchStep(
                id = o.optString("id", java.util.UUID.randomUUID().toString()),
                order = o.optInt("order", 1),
                type = t,
                xPx = xp,
                yPx = yp,
                endXPx = o.optDouble("endXPx", xp.toDouble()).toFloat(),
                endYPx = o.optDouble("endYPx", yp.toDouble()).toFloat(),
                timestampMs = o.optLong("timestampMs", 0L),
                delayFromPrevMs = o.optLong("delayFromPrevMs", 100L),
                durationMs = o.optLong("durationMs", 50L)
            )
        }
    }
}

data class CyberXMacroProfile(
    val id: String,
    var name: String,
    var enabled: Boolean = true,
    var loopCount: Int = 1, // 0 = Infinite Loop
    var speedMultiplier: Float = 1.0f,
    var showOnHud: Boolean = true,
    var buttonLabel: String = "M1",
    var colorHex: String = "#FF1744",
    var alpha: Float = 0.85f,
    var sizeDp: Int = 52,
    var xNorm: Float = 0.84f,
    var yNorm: Float = 0.62f,
    val steps: MutableList<CyberXTouchStep> = mutableListOf()
) {
    fun deepCopy(newId: String = id, newName: String = name): CyberXMacroProfile {
        return CyberXMacroProfile(
            id = newId,
            name = newName,
            enabled = enabled,
            loopCount = loopCount,
            speedMultiplier = speedMultiplier,
            showOnHud = showOnHud,
            buttonLabel = buttonLabel,
            colorHex = colorHex,
            alpha = alpha,
            sizeDp = sizeDp,
            xNorm = xNorm,
            yNorm = yNorm,
            steps = steps.map { it.copy() }.toMutableList()
        )
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("enabled", enabled)
        put("loopCount", loopCount)
        put("speedMultiplier", speedMultiplier.toDouble())
        put("showOnHud", showOnHud)
        put("buttonLabel", buttonLabel)
        put("colorHex", colorHex)
        put("alpha", alpha.toDouble())
        put("sizeDp", sizeDp)
        put("xNorm", xNorm.toDouble())
        put("yNorm", yNorm.toDouble())
        val arr = JSONArray()
        for (s in steps) arr.put(s.toJson())
        put("steps", arr)
    }

    companion object {
        fun fromJson(o: JSONObject): CyberXMacroProfile {
            val st = mutableListOf<CyberXTouchStep>()
            val arr = o.optJSONArray("steps")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    st.add(CyberXTouchStep.fromJson(arr.getJSONObject(i)))
                }
            }
            return CyberXMacroProfile(
                id = o.optString("id", java.util.UUID.randomUUID().toString()),
                name = o.optString("name", "Macro Baru"),
                enabled = o.optBoolean("enabled", true),
                loopCount = o.optInt("loopCount", 1),
                speedMultiplier = o.optDouble("speedMultiplier", 1.0).toFloat(),
                showOnHud = o.optBoolean("showOnHud", true),
                buttonLabel = o.optString("buttonLabel", "M1"),
                colorHex = o.optString("colorHex", "#FF1744"),
                alpha = o.optDouble("alpha", 0.85).toFloat(),
                sizeDp = o.optInt("sizeDp", 52),
                xNorm = o.optDouble("xNorm", 0.84).toFloat(),
                yNorm = o.optDouble("yNorm", 0.62).toFloat(),
                steps = st
            )
        }
    }
}

data class CyberXHudButton(
    val id: String,
    var label: String,
    var iconKey: String = "ic_rm_server",
    var colorHex: String = "#FF1744",
    var alpha: Float = 0.85f,
    var sizeDp: Int = 54,
    var xNorm: Float = 0.5f,
    var yNorm: Float = 0.5f,
    var locked: Boolean = false,
    var linkedMacroId: String = ""
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("label", label)
        put("iconKey", iconKey)
        put("colorHex", colorHex)
        put("alpha", alpha.toDouble())
        put("sizeDp", sizeDp)
        put("xNorm", xNorm.toDouble())
        put("yNorm", yNorm.toDouble())
        put("locked", locked)
        put("linkedMacroId", linkedMacroId)
    }

    companion object {
        fun fromJson(o: JSONObject): CyberXHudButton = CyberXHudButton(
            id = o.optString("id", java.util.UUID.randomUUID().toString()),
            label = o.optString("label", "BTN"),
            iconKey = o.optString("iconKey", "ic_rm_server"),
            colorHex = o.optString("colorHex", "#FF1744"),
            alpha = o.optDouble("alpha", 0.85).toFloat(),
            sizeDp = o.optInt("sizeDp", 54),
            xNorm = o.optDouble("xNorm", 0.5).toFloat(),
            yNorm = o.optDouble("yNorm", 0.5).toFloat(),
            locked = o.optBoolean("locked", false),
            linkedMacroId = o.optString("linkedMacroId", "")
        )
    }
}

data class CyberXHudProfile(
    val id: String,
    var name: String,
    val buttons: MutableList<CyberXHudButton> = mutableListOf()
) {
    fun deepCopy(newId: String = id, newName: String = name): CyberXHudProfile =
        CyberXHudProfile(newId, newName, buttons.map { it.copy() }.toMutableList())

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        val arr = JSONArray()
        for (b in buttons) arr.put(b.toJson())
        put("buttons", arr)
    }

    companion object {
        fun fromJson(o: JSONObject): CyberXHudProfile {
            val btns = mutableListOf<CyberXHudButton>()
            val arr = o.optJSONArray("buttons")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    btns.add(CyberXHudButton.fromJson(arr.getJSONObject(i)))
                }
            }
            return CyberXHudProfile(
                id = o.optString("id", java.util.UUID.randomUUID().toString()),
                name = o.optString("name", "Default HUD"),
                buttons = btns
            )
        }
    }
}

data class CyberXGameStat(
    val packageName: String,
    var lastPlayedMs: Long = 0L,
    var playCount: Int = 0
)
