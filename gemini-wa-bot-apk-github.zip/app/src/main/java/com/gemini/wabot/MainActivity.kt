package com.gemini.wabot

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import kotlinx.coroutines.Job
import android.app.PictureInPictureParams
import android.graphics.drawable.GradientDrawable
import android.view.animation.LinearInterpolator
import android.widget.CheckBox
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import com.google.android.material.card.MaterialCardView
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.util.Rational
import android.view.animation.DecelerateInterpolator
import android.content.pm.ActivityInfo
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.ScrollView
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.text.method.PasswordTransformationMethod
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.switchmaterial.SwitchMaterial
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.system.exitProcess

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: BotPrefsManager
    private var lastSessionsSignature: String = ""
    private var bgMediaPlayer: MediaPlayer? = null
    private var bgSurface: Surface? = null
    private var latestPairCodeForPip: String = ""
    private var hasPlayedWelcomeThisSession: Boolean = false
    private var cyberRgbAnimator: ValueAnimator? = null
    private val selectedAnnounceJids = mutableSetOf<String>()
    private var currentActiveTab: Int = 0
    private var rinaDialogueJob: Job? = null
    private var rinaIdleJob: Job? = null
    private var rinaFloatAnim: ObjectAnimator? = null
    private var isRinaVisible: Boolean = true
    private var rinaSpeakerCallback: ((Int, String, Boolean) -> Unit)? = null
    private var apiKeyReactIdx: Int = 0
    private val speechAskRinaLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK && result.data != null) {
            val spoken = result.data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.trim() ?: ""
            if (spoken.isNotEmpty()) {
                askRinaDirectly(spoken)
            }
        }
    }

    private val backupCreateLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            lifecycleScope.launch {
                val jsonStr = BotEngineClient.exportBackupJson(this@MainActivity)
                if (jsonStr != null) {
                    try {
                        contentResolver.openOutputStream(uri)?.use { it.write(jsonStr.toByteArray()) }
                        Toast.makeText(this@MainActivity, "✅ Backup berhasil disimpan!", Toast.LENGTH_LONG).show()
                    } catch (e: Exception) {
                        Toast.makeText(this@MainActivity, "❌ Gagal simpan backup: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                } else {
                    Toast.makeText(this@MainActivity, "❌ Mesin bot belum merespons", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private val backupRestoreLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            lifecycleScope.launch {
                try {
                    val raw = contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: ""
                    if (raw.isNotEmpty() && BotEngineClient.importBackupJson(this@MainActivity, raw)) {
                        Toast.makeText(this@MainActivity, "✅ Data berhasil dipulihkan! Restart aplikasi...", Toast.LENGTH_LONG).show()
                        recreate()
                    } else {
                        Toast.makeText(this@MainActivity, "❌ File backup tidak valid", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "❌ Error restore: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private val modelList = listOf(
        "gemini-2.5-flash",
        "gemini-2.5-pro",
        "gemini-2.5-flash-lite",
        "gemini-3.8-flash",
        "gemini-3.5-flash-lite",
        "gemini-4-argon"
    )

    private val scopeLabels = listOf(
        "Chat Pribadi Otomatis + Grup via /bot-active",
        "Hanya Chat Pribadi (Grup Nonaktif)",
        "Hanya Grup yang Diaktifkan (/bot-active)"
    )
    private val scopeValues = listOf("all", "private", "group")
    private val menuStyleLabels = listOf(
        "🗂️ Menu List Interaktif + Teks (Keduanya Aktif)",
        "🗂️ Khusus Popup Menu List Interaktif (Tombol Pilih)",
        "📝 Khusus Menu Teks Biasa"
    )
    private val menuStyleValues = listOf("both", "list", "text")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = BotPrefsManager(this)

        if (prefs.loggedInEmail.isEmpty()) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        setContentView(R.layout.activity_main)

        val textureVideoBg: TextureView = findViewById(R.id.textureVideoBg)
        val switchUnsafeScreenShare: SwitchMaterial = findViewById(R.id.switchUnsafeScreenShare)
        val btnToggleBgAudio: Button = findViewById(R.id.btnToggleBgAudio)

        setupVideoBackgroundLoop(textureVideoBg, btnToggleBgAudio)

        switchUnsafeScreenShare.isChecked = prefs.isUnsafeScreenShare
        applyScreenShareMode(prefs.isUnsafeScreenShare)
        switchUnsafeScreenShare.setOnCheckedChangeListener { _, isUnsafe ->
            prefs.isUnsafeScreenShare = isUnsafe
            applyScreenShareMode(isUnsafe)
            val msg = if (isUnsafe) {
                "🔓 Mode Tidak Aman AKTIF: Layar & Video sekarang tetap terlihat saat Berbagi Layar (Screen Share)!"
            } else {
                "🔒 Mode Aman AKTIF: Layar disembunyikan saat Berbagi Layar."
            }
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        }

        val tvLoggedInAccount: TextView = findViewById(R.id.tvLoggedInAccount)
        val btnSwitchAccount: Button = findViewById(R.id.btnSwitchAccount)
        val btnExitApp: Button = findViewById(R.id.btnExitApp)

        val tvEngineStatus: TextView = findViewById(R.id.tvEngineStatus)
        val tvStatsBadge: TextView = findViewById(R.id.tvStatsBadge)
        val switchMasterBot: SwitchMaterial = findViewById(R.id.switchMasterBot)
        val rgConnectionMode: RadioGroup = findViewById(R.id.rgConnectionMode)
        val rbModeLocal: RadioButton = findViewById(R.id.rbModeLocal)
        val rbModeVps: RadioButton = findViewById(R.id.rbModeVps)
        val layoutVpsConfig: LinearLayout = findViewById(R.id.layoutVpsConfig)
        val etVpsUrl: EditText = findViewById(R.id.etVpsUrl)
        val etVpsUser: EditText = findViewById(R.id.etVpsUser)
        val etVpsSshPort: EditText = findViewById(R.id.etVpsSshPort)
        val etVpsSecret: EditText = findViewById(R.id.etVpsSecret)
        val btnConnectVpsNow: Button = findViewById(R.id.btnConnectVpsNow)
        val btnCheckVpsSsh: Button = findViewById(R.id.btnCheckVpsSsh)
        val btnRestartVpsSsh: Button = findViewById(R.id.btnRestartVpsSsh)
        val btnDisableBatteryOpt: Button = findViewById(R.id.btnDisableBatteryOpt)

        val etPhoneNumber: EditText = findViewById(R.id.etPhoneNumber)
        val btnGetPairingCode: Button = findViewById(R.id.btnGetPairingCode)
        val tvPairingCodeResult: TextView = findViewById(R.id.tvPairingCodeResult)
        val btnCopyPairingCode: Button = findViewById(R.id.btnCopyPairingCode)
        val btnEnterPipMode: Button = findViewById(R.id.btnEnterPipMode)
        val layoutPairedSessionsList: LinearLayout = findViewById(R.id.layoutPairedSessionsList)
        val btnOpenWaWeb: Button = findViewById(R.id.btnOpenWaWeb)

        val switchLockApiKey: SwitchMaterial = findViewById(R.id.switchLockApiKey)
        val etBotName: EditText = findViewById(R.id.etBotName)
        val etGeminiApiKey: EditText = findViewById(R.id.etGeminiApiKey)
        val tvApiKeyLockHint: TextView = findViewById(R.id.tvApiKeyLockHint)
        val spinnerGeminiModel: Spinner = findViewById(R.id.spinnerGeminiModel)
        val btnPresetSantai: Button = findViewById(R.id.btnPresetSantai)
        val btnPresetToko: Button = findViewById(R.id.btnPresetToko)
        val btnPresetPintar: Button = findViewById(R.id.btnPresetPintar)
        val etSystemPrompt: EditText = findViewById(R.id.etSystemPrompt)

        val spinnerReplyScope: Spinner = findViewById(R.id.spinnerReplyScope)
        val spinnerMenuStyle: Spinner = findViewById(R.id.spinnerMenuStyle)
        val etGroupTrigger: EditText = findViewById(R.id.etGroupTrigger)
        val etBlacklistNumbers: EditText = findViewById(R.id.etBlacklistNumbers)
        val btnSaveConfig: Button = findViewById(R.id.btnSaveConfig)
        val btnTestGemini: Button = findViewById(R.id.btnTestGemini)
        val btnResetMemory: Button = findViewById(R.id.btnResetMemory)
        val tvLiveLogs: TextView = findViewById(R.id.tvLiveLogs)

        val switchPowerSaver: SwitchMaterial = findViewById(R.id.switchPowerSaver)
        val switchAutoWelcome: SwitchMaterial = findViewById(R.id.switchAutoWelcome)
        val switchAntiLink: SwitchMaterial = findViewById(R.id.switchAntiLink)
        val switchAntiSpam: SwitchMaterial = findViewById(R.id.switchAntiSpam)
        val switchCyberTheme: SwitchMaterial = findViewById(R.id.switchCyberTheme)
        val btnBackupConfig: Button = findViewById(R.id.btnBackupConfig)
        val btnRestoreConfig: Button = findViewById(R.id.btnRestoreConfig)
        val etUpdateRepo: EditText = findViewById(R.id.etUpdateRepo)
        val btnCheckUpdateNow: Button = findViewById(R.id.btnCheckUpdateNow)

        val btnTabBot: Button = findViewById(R.id.btnTabBot)
        val btnTabAnnounce: Button = findViewById(R.id.btnTabAnnounce)
        val btnTabTerminal: Button = findViewById(R.id.btnTabTerminal)
        val btnTabMcServer: Button = findViewById(R.id.btnTabMcServer)
        val tabContentBot: LinearLayout = findViewById(R.id.tabContentBot)
        val tabContentAnnounce: LinearLayout = findViewById(R.id.tabContentAnnounce)
        val tabContentTerminal: LinearLayout = findViewById(R.id.tabContentTerminal)
        val tabContentMcServer: LinearLayout = findViewById(R.id.tabContentMcServer)

        val btnLoadGroups: Button = findViewById(R.id.btnLoadGroups)
        val cbSelectAllGroups: CheckBox = findViewById(R.id.cbSelectAllGroups)
        val layoutGroupCheckList: LinearLayout = findViewById(R.id.layoutGroupCheckList)
        val etAnnounceMessage: EditText = findViewById(R.id.etAnnounceMessage)
        val etAnnounceHashtags: EditText = findViewById(R.id.etAnnounceHashtags)
        val switchAnnounceHidetag: SwitchMaterial = findViewById(R.id.switchAnnounceHidetag)
        val btnSendAnnouncement: Button = findViewById(R.id.btnSendAnnouncement)

        val tvTerminalOutput: TextView = findViewById(R.id.tvTerminalOutput)
        val etTerminalInput: EditText = findViewById(R.id.etTerminalInput)
        val btnTerminalRun: Button = findViewById(R.id.btnTerminalRun)
        val btnTermQuickLs: Button = findViewById(R.id.btnTermQuickLs)
        val btnTermQuickSys: Button = findViewById(R.id.btnTermQuickSys)
        val btnTermQuickDisk: Button = findViewById(R.id.btnTermQuickDisk)
        val btnTermClear: Button = findViewById(R.id.btnTermClear)

        val cardMcLocked: MaterialCardView = findViewById(R.id.cardMcLocked)
        val cardMcPanel: MaterialCardView = findViewById(R.id.cardMcPanel)
        val tvMcStatusBadge: TextView = findViewById(R.id.tvMcStatusBadge)
        val btnMcStart: Button = findViewById(R.id.btnMcStart)
        val btnMcStop: Button = findViewById(R.id.btnMcStop)
        val btnMcStatus: Button = findViewById(R.id.btnMcStatus)
        val btnMcInstallBedrock: Button = findViewById(R.id.btnMcInstallBedrock)
        val btnMcInstallPaper: Button = findViewById(R.id.btnMcInstallPaper)
        val etMcServerName: EditText = findViewById(R.id.etMcServerName)
        val etMcMaxPlayers: EditText = findViewById(R.id.etMcMaxPlayers)
        val btnMcSaveProps: Button = findViewById(R.id.btnMcSaveProps)
        val tvMcConsoleLog: TextView = findViewById(R.id.tvMcConsoleLog)
        val etMcCommand: EditText = findViewById(R.id.etMcCommand)
        val btnMcSendCmd: Button = findViewById(R.id.btnMcSendCmd)

        switchPowerSaver.isChecked = prefs.isPowerSaverMode
        switchAutoWelcome.isChecked = prefs.autoWelcome
        switchAntiLink.isChecked = prefs.antiLink
        switchAntiSpam.isChecked = prefs.antiSpam
        switchCyberTheme.isChecked = prefs.uiThemeMode == "cyber"
        etUpdateRepo.setText(prefs.updateRepo)

        applyCyberThemeState(prefs.uiThemeMode == "cyber")
        if (prefs.updateRepo.isNotEmpty()) {
            lifecycleScope.launch { checkAndPromptForceUpdate(prefs.updateRepo, silentIfLatest = true) }
        }

        fun refreshMcServerLock() {
            val isVps = prefs.connectionMode == "VPS"
            cardMcLocked.visibility = if (isVps) View.GONE else View.VISIBLE
            cardMcPanel.visibility = if (isVps) View.VISIBLE else View.GONE
        }
        refreshMcServerLock()



        fun switchSlideTab(targetIdx: Int) {
            if (currentActiveTab == targetIdx) return
            val dir = if (targetIdx > currentActiveTab) 1f else -1f
            currentActiveTab = targetIdx
            val tabs = listOf(tabContentBot, tabContentAnnounce, tabContentTerminal, tabContentMcServer)
            val btns = listOf(btnTabBot, btnTabAnnounce, btnTabTerminal, btnTabMcServer)
            btns.forEachIndexed { idx, b ->
                animateBounce(b)
                if (idx == targetIdx) {
                    b.setBackgroundColor(Color.parseColor("#10B981"))
                    b.setTextColor(Color.parseColor("#0F172A"))
                } else {
                    b.setBackgroundColor(Color.parseColor("#1E293B"))
                    b.setTextColor(Color.parseColor("#F8FAFC"))
                }
            }
            tabs.forEachIndexed { idx, layout ->
                if (idx == targetIdx) {
                    layout.visibility = View.VISIBLE
                    layout.alpha = 0f
                    layout.translationX = 90f * dir
                    layout.animate().alpha(1f).translationX(0f).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
                } else {
                    layout.visibility = View.GONE
                }
            }
            if (targetIdx == 3) refreshMcServerLock()
        }

        btnTabBot.setOnClickListener { switchSlideTab(0) }
        btnTabAnnounce.setOnClickListener { switchSlideTab(1) }
        btnTabTerminal.setOnClickListener { switchSlideTab(2) }
        btnTabMcServer.setOnClickListener { switchSlideTab(3) }

        val btnPerfEco: Button = findViewById(R.id.btnPerfEco)
        val btnPerfBalance: Button = findViewById(R.id.btnPerfBalance)
        val btnPerfTurbo: Button = findViewById(R.id.btnPerfTurbo)

        fun updatePerfButtons(mode: String) {
            prefs.perfMode = mode
            val list = listOf(btnPerfEco to "eco", btnPerfBalance to "balance", btnPerfTurbo to "turbo")
            for ((b, key) in list) {
                if (key == mode) {
                    val activeColor = when (key) {
                        "eco" -> "#10B981"
                        "turbo" -> "#FF1744"
                        else -> "#38BDF8"
                    }
                    b.setBackgroundColor(Color.parseColor(activeColor))
                    b.setTextColor(Color.parseColor("#0F172A"))
                } else {
                    b.setBackgroundColor(Color.parseColor("#1E293B"))
                    b.setTextColor(Color.parseColor("#CBD5E1"))
                }
            }
            if (mode == "eco") {
                prefs.isPowerSaverMode = true
                switchPowerSaver.isChecked = true
            } else {
                prefs.isPowerSaverMode = false
                switchPowerSaver.isChecked = false
            }
        }
        updatePerfButtons(prefs.perfMode)

        btnPerfEco.setOnClickListener { animateBounce(it); updatePerfButtons("eco"); Toast.makeText(this, "🔋 CyberX ECO: Mode Hemat Daya Aktif", Toast.LENGTH_SHORT).show() }
        btnPerfBalance.setOnClickListener { animateBounce(it); updatePerfButtons("balance"); Toast.makeText(this, "⚡ CyberX BALANCE: Seimbang", Toast.LENGTH_SHORT).show() }
        btnPerfTurbo.setOnClickListener { animateBounce(it); updatePerfButtons("turbo"); Toast.makeText(this, "🔥 CyberX TURBO: Respons Maksimal!", Toast.LENGTH_SHORT).show() }

        switchPowerSaver.setOnCheckedChangeListener { _, isChecked ->
            prefs.isPowerSaverMode = isChecked
            if (isChecked && prefs.perfMode != "eco") updatePerfButtons("eco")
            else if (!isChecked && prefs.perfMode == "eco") updatePerfButtons("balance")
        }

        switchAutoWelcome.setOnCheckedChangeListener { _, isChecked ->
            prefs.autoWelcome = isChecked
            lifecycleScope.launch { BotEngineClient.syncConfig(this@MainActivity) }
        }
        switchAntiLink.setOnCheckedChangeListener { _, isChecked ->
            prefs.antiLink = isChecked
            lifecycleScope.launch { BotEngineClient.syncConfig(this@MainActivity) }
        }
        switchAntiSpam.setOnCheckedChangeListener { _, isChecked ->
            prefs.antiSpam = isChecked
            lifecycleScope.launch { BotEngineClient.syncConfig(this@MainActivity) }
        }
        switchCyberTheme.setOnCheckedChangeListener { _, isCyber ->
            prefs.uiThemeMode = if (isCyber) "cyber" else "normal"
            applyCyberThemeState(isCyber)
        }

        btnBackupConfig.setOnClickListener {
            animateBounce(it)
            backupCreateLauncher.launch("dodosbot_backup_${System.currentTimeMillis() / 1000}.json")
        }
        btnRestoreConfig.setOnClickListener {
            animateBounce(it)
            backupRestoreLauncher.launch(arrayOf("application/json", "*/*"))
        }

        btnCheckUpdateNow.setOnClickListener {
            animateBounce(it)
            val repo = etUpdateRepo.text.toString().trim()
            prefs.updateRepo = repo
            if (repo.isEmpty()) {
                Toast.makeText(this, "Isi nama repo GitHub (contoh: dodosadventure/dodosbot)", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            lifecycleScope.launch { checkAndPromptForceUpdate(repo, silentIfLatest = false) }
        }

        val groupCheckBoxes = mutableListOf<CheckBox>()
        btnLoadGroups.setOnClickListener {
            animateBounce(it)
            Toast.makeText(this, "Memuat daftar grup...", Toast.LENGTH_SHORT).show()
            lifecycleScope.launch {
                val groups = BotEngineClient.fetchJoinedGroups(this@MainActivity)
                layoutGroupCheckList.removeAllViews()
                groupCheckBoxes.clear()
                selectedAnnounceJids.clear()
                if (groups.isEmpty()) {
                    val tv = TextView(this@MainActivity).apply {
                        text = "Belum ada grup atau nomor WA belum aktif."
                        setTextColor(Color.parseColor("#94A3B8"))
                    }
                    layoutGroupCheckList.addView(tv)
                } else {
                    for ((jid, name, count) in groups) {
                        val cb = CheckBox(this@MainActivity).apply {
                            text = "$name ($count anggota)"
                            setTextColor(Color.parseColor("#F8FAFC"))
                            setOnCheckedChangeListener { _, chk ->
                                if (chk) selectedAnnounceJids.add(jid) else selectedAnnounceJids.remove(jid)
                            }
                        }
                        groupCheckBoxes.add(cb)
                        layoutGroupCheckList.addView(cb)
                    }
                }
            }
        }

        cbSelectAllGroups.setOnCheckedChangeListener { _, isChecked ->
            groupCheckBoxes.forEach { it.isChecked = isChecked }
        }

        btnSendAnnouncement.setOnClickListener {
            animateBounce(it)
            val msg = etAnnounceMessage.text.toString().trim()
            if (selectedAnnounceJids.isEmpty() || msg.isEmpty()) {
                Toast.makeText(this, "Pilih minimal 1 grup dan tulis isi pengumuman!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            btnSendAnnouncement.isEnabled = false
            lifecycleScope.launch {
                val (ok, resMsg) = BotEngineClient.sendGroupAnnouncement(
                    this@MainActivity,
                    selectedAnnounceJids.toList(),
                    msg,
                    switchAnnounceHidetag.isChecked,
                    etAnnounceHashtags.text.toString()
                )
                btnSendAnnouncement.isEnabled = true
                Toast.makeText(this@MainActivity, if (ok) "✅ $resMsg" else "❌ $resMsg", Toast.LENGTH_LONG).show()
            }
        }

        fun runTermCmd(cmd: String) {
            if (cmd.isBlank()) return
            tvTerminalOutput.append("\n$ $cmd\n")
            lifecycleScope.launch {
                val out = BotEngineClient.execTerminalCommand(this@MainActivity, cmd)
                if (out.isNotBlank()) tvTerminalOutput.append("$out\n")
            }
        }
        btnTerminalRun.setOnClickListener {
            animateBounce(it)
            val c = etTerminalInput.text.toString().trim()
            etTerminalInput.setText("")
            runTermCmd(c)
        }
        btnTermQuickLs.setOnClickListener { animateBounce(it); runTermCmd("ls -la") }
        btnTermQuickSys.setOnClickListener { animateBounce(it); runTermCmd("free -m") }
        btnTermQuickDisk.setOnClickListener { animateBounce(it); runTermCmd("df -h") }
        btnTermClear.setOnClickListener { animateBounce(it); tvTerminalOutput.text = "[Session 2 Cleared]\n" }

        fun runMcAction(action: String, cmdStr: String = "") {
            lifecycleScope.launch {
                tvMcConsoleLog.text = "⏳ Menjalankan '$action' di VPS..."
                val (ok, out) = BotEngineClient.mcServerAction(
                    this@MainActivity,
                    action,
                    cmdStr,
                    etMcServerName.text.toString(),
                    etMcMaxPlayers.text.toString()
                )
                if (action == "status" && out.contains("STATUS:")) {
                    val firstLine = out.lineSequence().firstOrNull() ?: ""
                    tvMcStatusBadge.text = firstLine.replace("|", " • ")
                    tvMcConsoleLog.text = out.substringAfter("\n", out)
                } else {
                    tvMcConsoleLog.text = if (out.isNotBlank()) out else if (ok) "✅ Selesai" else "❌ Gagal"
                }
            }
        }
        btnMcStatus.setOnClickListener { animateBounce(it); runMcAction("status") }
        btnMcStart.setOnClickListener { animateBounce(it); runMcAction("start") }
        btnMcStop.setOnClickListener { animateBounce(it); runMcAction("stop") }
        btnMcInstallBedrock.setOnClickListener { animateBounce(it); runMcAction("install_bedrock") }
        btnMcInstallPaper.setOnClickListener { animateBounce(it); runMcAction("install_paper") }
        btnMcSaveProps.setOnClickListener { animateBounce(it); runMcAction("save_props") }
        btnMcSendCmd.setOnClickListener {
            animateBounce(it)
            val c = etMcCommand.text.toString().trim()
            etMcCommand.setText("")
            if (c.isNotEmpty()) runMcAction("cmd", c)
        }

        val lockBadge = if (prefs.ownerLockedEmail.isNotEmpty()) " 🔒" else ""
        tvLoggedInAccount.text = "👤 ${prefs.loggedInEmail}$lockBadge"

        btnSwitchAccount.setOnClickListener {
            prefs.loggedInEmail = ""
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        btnExitApp.setOnClickListener {
            showExitOptionsDialog()
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val drawerOverlay = findViewById<LinearLayout>(R.id.layoutRmDrawerOverlay)
                if (prefs.uiThemeMode == "cyber" && drawerOverlay?.visibility == View.VISIBLE) {
                    findViewById<Button>(R.id.btnRmDrawerBack)?.performClick()
                    return
                }
                showExitOptionsDialog()
            }
        })

        spinnerGeminiModel.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            modelList
        )
        spinnerReplyScope.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            scopeLabels
        )
        spinnerMenuStyle.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            menuStyleLabels
        )

        switchMasterBot.isChecked = prefs.isBotEnabled
        if (prefs.connectionMode == "VPS") {
            rbModeVps.isChecked = true
            layoutVpsConfig.visibility = View.VISIBLE
        } else {
            rbModeLocal.isChecked = true
            layoutVpsConfig.visibility = View.GONE
        }

        etVpsUrl.setText(BotEngineClient.extractHostFromUrl(prefs.vpsUrl))
        etVpsUser.setText(prefs.vpsUser)
        etVpsSshPort.setText(prefs.vpsSshPort)
        etVpsSecret.setText(prefs.vpsSecret)
        etPhoneNumber.setText(prefs.phoneNumber)
        etBotName.setText(prefs.botName)
        etGeminiApiKey.setText(prefs.geminiApiKey)
        playWelcomeCinematicIfNeeded()
        etSystemPrompt.setText(prefs.systemPrompt)
        etGroupTrigger.setText(prefs.groupTrigger)
        etBlacklistNumbers.setText(prefs.blacklistNumbers)

        val savedModel = prefs.geminiModel
        val modelIdx = modelList.indexOf(savedModel).let { if (it >= 0) it else 0 }
        if (prefs.geminiModel != modelList[modelIdx]) {
            prefs.geminiModel = modelList[modelIdx]
        }
        spinnerGeminiModel.setSelection(modelIdx, false)

        val scopeIdx = scopeValues.indexOf(prefs.replyScope).coerceAtLeast(0)
        spinnerReplyScope.setSelection(scopeIdx, false)
        val menuIdx = menuStyleValues.indexOf(prefs.menuStyle).coerceAtLeast(0)
        spinnerMenuStyle.setSelection(menuIdx, false)

        spinnerGeminiModel.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val chosenModel = modelList.getOrElse(position) { "gemini-2.5-flash" }
                if (prefs.geminiModel != chosenModel) {
                    prefs.geminiModel = chosenModel
                    startBotService()
                    lifecycleScope.launch {
                        BotEngineClient.syncConfig(this@MainActivity)
                    }
                    Toast.makeText(this@MainActivity, "✅ Model AI diubah ke: $chosenModel", Toast.LENGTH_SHORT).show()
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        spinnerReplyScope.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val chosenScope = scopeValues.getOrElse(position) { "all" }
                if (prefs.replyScope != chosenScope) {
                    prefs.replyScope = chosenScope
                    lifecycleScope.launch {
                        BotEngineClient.syncConfig(this@MainActivity)
                    }
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        spinnerMenuStyle.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val chosenStyle = menuStyleValues.getOrElse(position) { "both" }
                if (prefs.menuStyle != chosenStyle) {
                    prefs.menuStyle = chosenStyle
                    lifecycleScope.launch {
                        BotEngineClient.syncConfig(this@MainActivity)
                    }
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        switchLockApiKey.isChecked = prefs.isApiKeyLocked
        applyApiKeyLockState(prefs.isApiKeyLocked, etGeminiApiKey, tvApiKeyLockHint)

        switchLockApiKey.setOnCheckedChangeListener { _, isLocked ->
            if (isLocked && etGeminiApiKey.text.toString().trim().isNotEmpty()) {
                prefs.geminiApiKey = etGeminiApiKey.text.toString().trim()
            }
            prefs.isApiKeyLocked = isLocked
            applyApiKeyLockState(isLocked, etGeminiApiKey, tvApiKeyLockHint)
            val lockToast = if (isLocked) "🔒 API Key dikunci & diamankan!" else "🔓 Kunci API Key dibuka, silakan edit."
            if (isLocked) {
                rinaSpeakerCallback?.invoke(R.drawable.rina_tsundere, "API Key udah dikunci! Aman dari mata-mata... b-bukan karena aku jagain ya!", false)
            } else {
                rinaSpeakerCallback?.invoke(R.drawable.rina_explain, "Kunci dibuka! Cepetan ganti key-nya terus kunci lagi.", false)
            }
            Toast.makeText(this, lockToast, Toast.LENGTH_SHORT).show()
        }

        btnConnectVpsNow.setOnClickListener {
            val rawHost = etVpsUrl.text.toString().trim()
            val sshUser = etVpsUser.text.toString().trim().ifEmpty { "root" }
            val sshPort = etVpsSshPort.text.toString().trim().ifEmpty { "22" }
            val sshPass = etVpsSecret.text.toString().trim()
            if (rawHost.isEmpty()) {
                Toast.makeText(this, "Masukkan IP Public VPS terlebih dahulu!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            btnConnectVpsNow.isEnabled = false
            btnConnectVpsNow.text = "⏳ Menyambungkan & Memasang Bot di VPS..."
            Toast.makeText(this, "Menghubungi VPS & menyiapkan mesin bot 24 jam...", Toast.LENGTH_SHORT).show()
            lifecycleScope.launch {
                val (ok, msg) = BotEngineClient.connectAndSetupVpsFromApk(
                    this@MainActivity,
                    rawHost,
                    sshPort,
                    sshUser,
                    sshPass,
                    false
                )
                btnConnectVpsNow.isEnabled = true
                btnConnectVpsNow.text = "🔌 Sambungkan & Pasang Bot ke VPS"
                if (ok) {
                    prefs.geminiModel = modelList[spinnerGeminiModel.selectedItemPosition]
                    if (etGeminiApiKey.text.toString().trim().isNotEmpty()) {
                        prefs.geminiApiKey = etGeminiApiKey.text.toString().trim()
                    }
                    rbModeVps.isChecked = true
                    BotEngineClient.syncConfig(this@MainActivity)
                    lastSessionsSignature = ""
                    tvEngineStatus.text = "Status: 🟢 Terhubung ke VPS (${BotEngineClient.extractHostFromUrl(rawHost)}:8765)"
                    Toast.makeText(this@MainActivity, "✅ $msg", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this@MainActivity, "❌ $msg", Toast.LENGTH_LONG).show()
                }
            }
        }

        btnCheckVpsSsh.setOnClickListener {
            prefs.vpsUrl = BotEngineClient.formatVpsBaseUrl(etVpsUrl.text.toString())
            prefs.vpsUser = etVpsUser.text.toString().trim().ifEmpty { "root" }
            prefs.vpsSshPort = etVpsSshPort.text.toString().trim().ifEmpty { "22" }
            prefs.vpsSecret = etVpsSecret.text.toString().trim()
            lifecycleScope.launch {
                val res = BotEngineClient.checkOrRestartVpsViaSsh(this@MainActivity, "status")
                Toast.makeText(this@MainActivity, res, Toast.LENGTH_LONG).show()
            }
        }

        btnRestartVpsSsh.setOnClickListener {
            val rawHost = etVpsUrl.text.toString().trim()
            val sshUser = etVpsUser.text.toString().trim().ifEmpty { "root" }
            val sshPort = etVpsSshPort.text.toString().trim().ifEmpty { "22" }
            val sshPass = etVpsSecret.text.toString().trim()
            prefs.vpsUrl = BotEngineClient.formatVpsBaseUrl(rawHost)
            prefs.vpsUser = sshUser
            prefs.vpsSshPort = sshPort
            prefs.vpsSecret = sshPass
            prefs.geminiModel = modelList[spinnerGeminiModel.selectedItemPosition]
            if (etGeminiApiKey.text.toString().trim().isNotEmpty()) {
                prefs.geminiApiKey = etGeminiApiKey.text.toString().trim()
            }
            Toast.makeText(this, "Memperbarui & me-restart mesin bot v5.8 di VPS via SSH...", Toast.LENGTH_SHORT).show()
            lifecycleScope.launch {
                val (ok, msg) = BotEngineClient.connectAndSetupVpsFromApk(
                    this@MainActivity,
                    rawHost,
                    sshPort,
                    sshUser,
                    sshPass,
                    true
                )
                BotEngineClient.syncConfig(this@MainActivity)
                val toastMsg = if (ok) "✅ Mesin VPS berhasil di-update ke v5.8 & di-restart: $msg" else "❌ $msg"
                Toast.makeText(this@MainActivity, toastMsg, Toast.LENGTH_LONG).show()
            }
        }

        btnPresetSantai.setOnClickListener {
            etSystemPrompt.setText("Kamu adalah asisten AI pribadi yang asyik, ramah, dan santai di WhatsApp. Gunakan bahasa Indonesia sehari-hari yang akrab, sopan, dan to-the-point.")
            Toast.makeText(this, "Preset 'Teman Santai' diterapkan!", Toast.LENGTH_SHORT).show()
        }
        btnPresetToko.setOnClickListener {
            etSystemPrompt.setText("Kamu adalah Customer Service & Admin Toko yang ramah, sopan, dan responsif. Bantu pelanggan dengan jelas, informatif, dan profesional.")
            Toast.makeText(this, "Preset 'Admin Toko' diterapkan!", Toast.LENGTH_SHORT).show()
        }
        btnPresetPintar.setOnClickListener {
            etSystemPrompt.setText("Kamu adalah Asisten Ahli & Riset Pintar. Jawab setiap pertanyaan dengan akurat, terstruktur, dan mudah dipahami.")
            Toast.makeText(this, "Preset 'Asisten Ahli' diterapkan!", Toast.LENGTH_SHORT).show()
        }

        startBotService()

        rgConnectionMode.setOnCheckedChangeListener { _, checkedId ->
            if (checkedId == R.id.rbModeVps) {
                prefs.connectionMode = "VPS"
                layoutVpsConfig.visibility = View.VISIBLE
                tvEngineStatus.text = "Status: Mode Server VPS (${prefs.vpsUrl})"
            } else {
                prefs.connectionMode = "LOCAL"
                layoutVpsConfig.visibility = View.GONE
                tvEngineStatus.text = "Status: Mesin Lokal di HP (Aktif)"
                startBotService()
            }
            lastSessionsSignature = ""
            lifecycleScope.launch {
                BotEngineClient.syncConfig(this@MainActivity)
            }
        }

        switchMasterBot.setOnCheckedChangeListener { _, isChecked ->
            prefs.isBotEnabled = isChecked
            lifecycleScope.launch {
                BotEngineClient.syncConfig(this@MainActivity)
            }
            val msg = if (isChecked) "Semua Bot Diaktifkan" else "Semua Bot Dijeda"
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }

        btnSaveConfig.setOnClickListener {
            prefs.botName = etBotName.text.toString().trim().ifEmpty { "DodosBot" }
            prefs.menuStyle = menuStyleValues[spinnerMenuStyle.selectedItemPosition]
            saveFormToPrefs(
                rbModeVps.isChecked,
                etVpsUrl.text.toString(),
                etVpsSecret.text.toString(),
                etPhoneNumber.text.toString(),
                etGeminiApiKey.text.toString(),
                modelList[spinnerGeminiModel.selectedItemPosition],
                etSystemPrompt.text.toString(),
                scopeValues[spinnerReplyScope.selectedItemPosition],
                etGroupTrigger.text.toString(),
                etBlacklistNumbers.text.toString()
            )
            val keyVal = etGeminiApiKey.text.toString().trim()
            if (keyVal.isNotEmpty()) {
                val keyReactions = listOf(
                    R.drawable.rina_excited to "Ooh! API Key dipasang! Akhirnya otak naga ku nyala penuh, Master!",
                    R.drawable.rina_tsundere to "H-hmph! Baru pasang API Key sekarang? Ya udah deh, aku bantu jawab chat WA-nya!",
                    R.drawable.rina_explain to "API Key tersimpan! Jangan lupa kunci biar gak bocor pas Share Screen!",
                    R.drawable.rina_excited to "Mantap! Tenaga Gemini aktif—siap bakar server... eh maksudnya balas chat!"
                )
                val (ex, ln) = keyReactions[apiKeyReactIdx % keyReactions.size]
                apiKeyReactIdx++
                rinaSpeakerCallback?.invoke(ex, ln, false)
            } else {
                rinaSpeakerCallback?.invoke(R.drawable.rina_angry, "Loh, API Key-nya masih kosong?! Aku gak bisa mikir tanpa bensin tau!", false)
            }
            if (keyVal.isNotEmpty() && !switchLockApiKey.isChecked) {
                switchLockApiKey.isChecked = true
            }
            startBotService()
            lifecycleScope.launch {
                val ok = BotEngineClient.syncConfig(this@MainActivity)
                val targetName = if (rbModeVps.isChecked) "VPS (${prefs.vpsUrl})" else "Mesin Lokal HP"
                val msg = if (ok) "✅ Konfigurasi disimpan & disinkronkan ke $targetName!" else "Konfigurasi disimpan!"
                Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show()
            }
        }

        btnGetPairingCode.setOnClickListener {
            saveFormToPrefs(
                rbModeVps.isChecked,
                etVpsUrl.text.toString(),
                etVpsSecret.text.toString(),
                etPhoneNumber.text.toString(),
                etGeminiApiKey.text.toString(),
                modelList[spinnerGeminiModel.selectedItemPosition],
                etSystemPrompt.text.toString(),
                scopeValues[spinnerReplyScope.selectedItemPosition],
                etGroupTrigger.text.toString(),
                etBlacklistNumbers.text.toString()
            )
            val rawPhone = etPhoneNumber.text.toString().trim()
            val cleanPhone = BotEngineClient.normalizePhone(rawPhone)
            if (cleanPhone.length < 9) {
                Toast.makeText(this, "Masukkan nomor WA yang valid (contoh: 62812... atau 0812...)", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val targetStr = if (prefs.connectionMode == "VPS") "VPS (${BotEngineClient.extractHostFromUrl(prefs.vpsUrl)})" else "Mesin Lokal HP"
            rinaSpeakerCallback?.invoke(R.drawable.rina_explain, "Sebentar ya, aku lagi mintain kode pairing ke WhatsApp...", false)
            tvPairingCodeResult.text = "⚡ Meminta Kode dari $targetStr..."
            lifecycleScope.launch {
                BotEngineClient.syncConfig(this@MainActivity)
                val code = BotEngineClient.requestPairingCode(this@MainActivity, cleanPhone)
                if (code.startsWith("ERROR:") || code.startsWith("GAGAL:")) {
                    tvPairingCodeResult.text = code
                } else {
                    latestPairCodeForPip = code
                    tvPairingCodeResult.text = "KODE ($cleanPhone): $code"
                    findViewById<TextView>(R.id.tvPipPairingCode)?.text = code
                    val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("WA Pairing Code", code.replace("-", "")))
                    Toast.makeText(this@MainActivity, "✅ Kode $code otomatis disalin! Klik '🪟 Mode Jendela Kecil' untuk membuka WA.", Toast.LENGTH_LONG).show()
                }
                lastSessionsSignature = ""
            }
        }

        btnEnterPipMode.setOnClickListener {
            prefs.botName = etBotName.text.toString().trim().ifEmpty { "DodosBot" }
            startBotService()
            enterFloatingPipPairingMode()
        }

        btnCopyPairingCode.setOnClickListener {
            val raw = tvPairingCodeResult.text.toString()
            val codeOnly = raw.substringAfterLast(":").trim().replace("-", "")
            if (codeOnly.isEmpty() || codeOnly == "-" || raw.contains("ERROR") || raw.contains("GAGAL")) {
                Toast.makeText(this, "Belum ada kode pairing untuk disalin", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("WA Pairing Code", codeOnly))
            Toast.makeText(this, "Kode '$codeOnly' disalin! Tempel di WA -> Perangkat Tertaut.", Toast.LENGTH_LONG).show()
        }

        btnOpenWaWeb.setOnClickListener {
            startActivity(Intent(this, WaWebActivity::class.java))
        }

        btnDisableBatteryOpt.setOnClickListener {
            requestIgnoreBatteryOptimization()
        }

        btnTestGemini.setOnClickListener {
            saveFormToPrefs(
                rbModeVps.isChecked,
                etVpsUrl.text.toString(),
                etVpsSecret.text.toString(),
                etPhoneNumber.text.toString(),
                etGeminiApiKey.text.toString(),
                modelList[spinnerGeminiModel.selectedItemPosition],
                etSystemPrompt.text.toString(),
                scopeValues[spinnerReplyScope.selectedItemPosition],
                etGroupTrigger.text.toString(),
                etBlacklistNumbers.text.toString()
            )
            if (prefs.geminiApiKey.isEmpty()) {
                Toast.makeText(this, "Isi Gemini API Key (AQ...) terlebih dahulu!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            Toast.makeText(this, "Mengetes koneksi ke Gemini...", Toast.LENGTH_SHORT).show()
            lifecycleScope.launch {
                BotEngineClient.syncConfig(this@MainActivity)
                val reply = BotEngineClient.callGeminiDirect(
                    prefs,
                    "test_user",
                    "Halo! Perkenalkan dirimu secara singkat dalam 1 kalimat."
                )
                if (reply != null) {
                    rinaSpeakerCallback?.invoke(R.drawable.rina_excited, "Tes API Key sukses! Tuh kan, gak salah pilih asisten naga!", false)
                    Toast.makeText(this@MainActivity, "✅ Sukses: $reply", Toast.LENGTH_LONG).show()
                } else {
                    rinaSpeakerCallback?.invoke(R.drawable.rina_angry, "Aduh! API Key-nya ditolak tuh, cek lagi key-nya ya Master!", false)
                    Toast.makeText(this@MainActivity, "❌ Gagal memanggil Gemini. Cek log di bawah.", Toast.LENGTH_LONG).show()
                }
            }
        }

        btnResetMemory.setOnClickListener {
            lifecycleScope.launch {
                BotEngineClient.resetMemory(this@MainActivity)
                Toast.makeText(this@MainActivity, "Memori riwayat chat di-reset!", Toast.LENGTH_SHORT).show()
            }
        }

        lifecycleScope.launch {
            while (isActive) {
                val status = BotEngineClient.fetchStatus(this@MainActivity)
                if (BotEngineClient.appLogs.isNotEmpty()) {
                    tvLiveLogs.text = BotEngineClient.appLogs.takeLast(18).joinToString(System.lineSeparator())
                }
                val modePrefix = if (prefs.connectionMode == "VPS") "☁️ VPS (${BotEngineClient.extractHostFromUrl(prefs.vpsUrl).ifEmpty { "Belum Diisi" }})" else "📱 Lokal HP"
                if (status != null) {
                    val activeCount = status.sessions.count { it.loggedIn && it.active }
                    val totalPaired = status.sessions.size
                    if (activeCount > 0 && latestPairCodeForPip.isNotEmpty()) {
                        findViewById<TextView>(R.id.tvPipPairingCode)?.text = "✅ TERTAUT!"
                        findViewById<TextView>(R.id.tvPipStatusHint)?.text = "Nomor WA berhasil terhubung!"
                    }
                    val waConn = if (activeCount > 0) "🟢 $activeCount/$totalPaired Nomor Bot Aktif" else "🟡 $totalPaired Sesi Terdaftar"
                    tvStatsBadge.text = "📊 $modePrefix • $waConn • ${status.totalReplied} Balasan AI • ${status.activeGroups} Grup"
                    findViewById<TextView>(R.id.tvRmLiveTelemetry)?.text = "${if (prefs.connectionMode == "VPS") "VPS" else "LOKAL"} • $activeCount/$totalPaired WA • ${status.totalReplied} AI"
                    tvEngineStatus.text = "$modePrefix • $waConn"
                    renderPairedSessions(layoutPairedSessionsList, status.sessions)
                } else {
                    tvEngineStatus.text = "$modePrefix • Menunggu Koneksi Server..."
                }
                delay(2000)
            }
        }
    }

    private fun showAskRinaDialog() {
        val input = EditText(this).apply {
            hint = "Ketik pertanyaan untuk Rina..."
            setPadding(36, 24, 36, 24)
        }
        AlertDialog.Builder(this)
            .setTitle("Tanya Rina (Dragon AI)")
            .setMessage("Ketik chat atau tekan Bicara (Mic) untuk ngobrol langsung dengan Rina:")
            .setView(input)
            .setPositiveButton("Kirim") { _, _ ->
                val q = input.text.toString().trim()
                if (q.isNotEmpty()) askRinaDirectly(q)
            }
            .setNeutralButton("Mic (Bicara)") { _, _ ->
                try {
                    val intent = Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
                        putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "Bicara ke Rina sekarang...")
                    }
                    speechAskRinaLauncher.launch(intent)
                } catch (_: Exception) {
                    Toast.makeText(this, "Perangkat tidak mendukung input suara", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun askRinaDirectly(question: String) {
        if (!isRinaVisible) {
            isRinaVisible = true
            findViewById<LinearLayout>(R.id.layoutRinaMascot)?.visibility = View.VISIBLE
        }
        if (prefs.geminiApiKey.isBlank()) {
            val offline = if (prefs.rinaMood == "ANGRY") {
                "Hmph! API Key aja belum diisi, masih marah nih! Isi dulu sana!"
            } else {
                "B-belum ada API Key Gemini nih! Isi dulu di menu AI & Moderasi baru tanya aku lagi!"
            }
            rinaSpeakerCallback?.invoke(R.drawable.rina_tsundere, offline, false)
            return
        }
        rinaSpeakerCallback?.invoke(R.drawable.rina_explain, "Hmm... bentar ya, aku mikir dulu...", false)
        lifecycleScope.launch {
            val rinaPrompt = "Kamu adalah Rina, gadis naga anime chibi yang tsundere, imut, dan cerdas sebagai asisten di aplikasi DodosBot CyberX. Mood kamu sekarang: ${prefs.rinaMood}. Jawab pertanyaan user berikut dalam bahasa Indonesia maksimal 2 kalimat pendek dengan gaya tsundere: $question"
            val ans = BotEngineClient.callGeminiDirect(prefs, "rina_companion_chat", rinaPrompt)
            if (ans != null) {
                val expr = if (prefs.rinaMood == "ANGRY") R.drawable.rina_angry else R.drawable.rina_tsundere
                rinaSpeakerCallback?.invoke(expr, ans.take(150), false)
            } else {
                rinaSpeakerCallback?.invoke(R.drawable.rina_angry, "Aduh, koneksi Gemini gagal! Cek API Key atau internetmu ya!", false)
            }
        }
    }

    private fun showExitOptionsDialog() {
        val options = arrayOf(
            "🟢 Keluar & Tetap Berjalan di Latar Belakang (VPS / Layanan tetap aktif)",
            "🔴 Keluar & Matikan Semua Proses di HP (Hentikan proses lokal di HP)",
            "Batal (Tetap di aplikasi)"
        )
        AlertDialog.Builder(this)
            .setTitle("Keluar dari Gemini WA Bot?")
            .setItems(options) { dialog, which ->
                when (which) {
                    0 -> {
                        startBotService()
                        Toast.makeText(this, "Aplikasi ditutup. Bot tetap berjalan 24 jam!", Toast.LENGTH_SHORT).show()
                        finishAffinity()
                    }
                    1 -> {
                        Toast.makeText(this, "Mematikan layanan lokal di HP...", Toast.LENGTH_SHORT).show()
                        lifecycleScope.launch {
                            BotEngineClient.shutdownLocalEngine()
                            val stopIntent = Intent(this@MainActivity, BotForegroundService::class.java).apply {
                                action = BotForegroundService.ACTION_STOP_ALL
                            }
                            stopService(stopIntent)
                            delay(250)
                            finishAffinity()
                            exitProcess(0)
                        }
                    }
                    else -> dialog.dismiss()
                }
            }
            .show()
    }

    private fun playWelcomeCinematicIfNeeded() {
        val shouldPlay = intent?.getBooleanExtra("play_welcome_cinematic", false) == true || !hasPlayedWelcomeThisSession
        if (!shouldPlay) return
        hasPlayedWelcomeThisSession = true
        intent?.removeExtra("play_welcome_cinematic")

        val overlay = findViewById<FrameLayout>(R.id.layoutWelcomeCinematic) ?: return
        val inner = findViewById<LinearLayout>(R.id.layoutWelcomeInner)
        val portalCanvas = findViewById<RedMagicPortalView>(R.id.viewCyberPortalCanvas)
        val rmOverlay = findViewById<RelativeLayout>(R.id.layoutRedMagicGameSpace)
        val badge = findViewById<TextView>(R.id.tvWelcomeBadge)
        val title = findViewById<TextView>(R.id.tvWelcomeTitle)
        val subtitle = findViewById<TextView>(R.id.tvWelcomeSubtitle)
        val bar = findViewById<ProgressBar>(R.id.progressWelcomeBar)
        val statusTv = findViewById<TextView>(R.id.tvWelcomeStatus)

        overlay.visibility = View.VISIBLE
        overlay.alpha = 1f
        inner?.alpha = 1f
        inner?.scaleX = 1f
        inner?.scaleY = 1f
        portalCanvas?.startPortal()
        subtitle?.text = "CYBERX GAME SPACE • ${prefs.botName.uppercase()} v5.8"

        badge?.alpha = 0f
        badge?.translationY = -30f
        title?.alpha = 0f
        title?.scaleX = 0.4f
        title?.scaleY = 0.4f
        subtitle?.alpha = 0f
        subtitle?.translationY = 30f

        val crest = findViewById<ImageView>(R.id.ivWelcomeCrest)
        crest?.alpha = 0f
        crest?.scaleX = 0.65f
        crest?.scaleY = 0.65f
        crest?.animate()?.alpha(1f)?.scaleX(1f)?.scaleY(1f)?.setDuration(750)?.setInterpolator(OvershootInterpolator(1.6f))?.start()

        val scanner = findViewById<View>(R.id.viewWelcomeScanner)
        scanner?.scaleX = 0.1f
        scanner?.animate()?.scaleX(1f)?.setDuration(900)?.setInterpolator(DecelerateInterpolator())?.start()
        badge?.animate()?.alpha(1f)?.translationY(0f)?.setDuration(450)?.setInterpolator(DecelerateInterpolator())?.start()
        title?.animate()?.alpha(1f)?.scaleX(1.05f)?.scaleY(1.05f)?.setStartDelay(150)?.setDuration(650)?.setInterpolator(OvershootInterpolator(2.2f))?.withEndAction {
            title.animate().scaleX(1f).scaleY(1f).setDuration(300).start()
        }?.start()
        subtitle?.animate()?.alpha(1f)?.translationY(0f)?.setStartDelay(350)?.setDuration(500)?.setInterpolator(DecelerateInterpolator())?.start()

        lifecycleScope.launch {
            val steps = listOf(
                20 to "Memuat Sertifikat TLS & Mesin Lokal...",
                50 to "Menyiapkan 20 Banner Ekspresi Anime...",
                80 to "Mengaktifkan Video Background Loop...",
                100 to "WELCOME TO ${prefs.botName.uppercase()}!"
            )
            for ((prog, label) in steps) {
                bar?.progress = prog
                statusTv?.text = label
                delay(480)
            }
            // Efek Warp Hyperspace 60 FPS: Bintang & Cincin Portal meledak menembus masuk ke kokpit Game Space!
            portalCanvas?.triggerWarpExplosion()
            inner?.animate()?.alpha(0f)?.scaleX(2.6f)?.scaleY(2.6f)?.setDuration(440)?.setInterpolator(DecelerateInterpolator())?.start()
            if (rmOverlay?.visibility == View.VISIBLE) {
                rmOverlay.scaleX = 0.88f
                rmOverlay.scaleY = 0.88f
                rmOverlay.animate()?.scaleX(1f)?.scaleY(1f)?.setStartDelay(140)?.setDuration(480)?.setInterpolator(DecelerateInterpolator())?.start()
            }
            overlay.animate()?.alpha(0f)?.setStartDelay(160)?.setDuration(380)?.withEndAction {
                portalCanvas?.stopPortal()
                overlay.visibility = View.GONE
                overlay.alpha = 1f
                inner?.scaleX = 1f
                inner?.scaleY = 1f
                inner?.alpha = 1f
            }?.start()
        }
    }

    private fun enterFloatingPipPairingMode() {
        val codeText = if (latestPairCodeForPip.isNotEmpty()) {
            latestPairCodeForPip
        } else {
            val raw = findViewById<TextView>(R.id.tvPairingCodeResult)?.text?.toString() ?: ""
            raw.substringAfterLast(":").trim().ifEmpty { "MINTA KODE DULU" }
        }
        findViewById<TextView>(R.id.tvPipPairingCode)?.text = codeText

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val params = PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .build()
                enterPictureInPictureMode(params)
                return
            } catch (e: Exception) {
                Toast.makeText(this, "Info Jendela Kecil: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        val pipHud = findViewById<LinearLayout>(R.id.layoutPipMiniHud)
        if (isInPictureInPictureMode) {
            pipHud?.visibility = View.VISIBLE
        } else {
            pipHud?.visibility = View.GONE
        }
    }

    private fun animateBounce(v: View) {
        v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(80).withEndAction {
            v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        }.start()
    }

    private fun collectAllMaterialCards(view: View?, out: MutableList<MaterialCardView>) {
        if (view is MaterialCardView) {
            out.add(view)
        } else if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                collectAllMaterialCards(view.getChildAt(i), out)
            }
        }
    }

    private data class RmFeatureItem(
        val key: String,
        val title: String,
        val subtitle: String,
        val tag: String,
        val desc: String,
        val iconRes: Int,
        val targetTab: Int
    )

    private var selectedRmIndex: Int = 0

    private fun applyCyberThemeState(isRedMagic: Boolean) {
        val rgbBar = findViewById<View>(R.id.viewCyberRgbBar)
        val perfBar = findViewById<LinearLayout>(R.id.layoutRedMagicPerfBar)
        val navTabs = findViewById<LinearLayout>(R.id.layoutBottomNavTabs)
        val scrollDash = findViewById<ScrollView>(R.id.scrollNormalDashboard)
        val rmOverlay = findViewById<RelativeLayout>(R.id.layoutRedMagicGameSpace)
        val btnCloseDrawer = findViewById<Button>(R.id.btnRmDockCloseDrawer)
        cyberRgbAnimator?.cancel()
        cyberRgbAnimator = null

        val cards = mutableListOf<MaterialCardView>()
        collectAllMaterialCards(window.decorView, cards)

        if (!isRedMagic) {
            if (requestedOrientation != ActivityInfo.SCREEN_ORIENTATION_PORTRAIT) {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            }
            rmOverlay?.visibility = View.GONE
            findViewById<Button>(R.id.btnBackToRedMagicSpace)?.visibility = View.GONE
            scrollDash?.visibility = View.VISIBLE
            scrollDash?.setPadding(0, 0, 0, 0)
            rgbBar?.setBackgroundColor(Color.parseColor("#1E293B"))
            perfBar?.visibility = View.GONE
            navTabs?.setBackgroundColor(Color.parseColor("#CC0F172A"))
            for (card in cards) {
                card.background = null
                card.setCardBackgroundColor(Color.parseColor("#BF1E293B"))
            }
            return
        }

        // Otomatis miring ke Landscape ala RedMagic Game Space!
        if (requestedOrientation != ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }

        rmOverlay?.visibility = View.VISIBLE
        scrollDash?.visibility = View.GONE
        btnCloseDrawer?.visibility = View.GONE
        perfBar?.visibility = View.VISIBLE

        val cardDrawables = mutableListOf<MechaChamferDrawable>()
        for (card in cards) {
            val d = MechaChamferDrawable(
                fillColor = Color.parseColor("#EE0B101D"),
                strokeColorStart = Color.parseColor("#FF1744"),
                strokeColorEnd = Color.parseColor("#00E5FF"),
                chamferPx = 24f,
                strokePx = 3f
            )
            card.setCardBackgroundColor(Color.TRANSPARENT)
            card.background = d
            cardDrawables.add(d)
        }

        setupRedMagicGameSpaceShowcase(scrollDash, rmOverlay, btnCloseDrawer)

        val anim = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 2800L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { va ->
                val hue = va.animatedValue as Float
                val c1 = Color.HSVToColor(floatArrayOf(hue, 0.95f, 1f))
                val c2 = Color.HSVToColor(floatArrayOf((hue + 140f) % 360f, 0.95f, 1f))
                val grad = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(c1, c2))
                rgbBar?.background = grad
                for (d in cardDrawables) {
                    d.updateNeonColors(c1, c2)
                }
                findViewById<TextView>(R.id.tvWelcomeTitle)?.setTextColor(Color.WHITE)
                findViewById<View>(R.id.viewWelcomeScanner)?.setBackgroundColor(c2)
            }
            start()
        }
        cyberRgbAnimator = anim
    }

    private fun setupRedMagicGameSpaceShowcase(
        scrollDash: ScrollView?,
        rmOverlay: RelativeLayout?,
        btnCloseDrawer: Button?
    ) {
        val listContainer = findViewById<LinearLayout>(R.id.layoutRmFeatureList) ?: return
        val rightStage = findViewById<RelativeLayout>(R.id.rmRightStage)
        val drawerOverlay = findViewById<LinearLayout>(R.id.layoutRmDrawerOverlay)
        val drawerSlot = findViewById<FrameLayout>(R.id.frameRmDrawerSlot)
        val drawerTitle = findViewById<TextView>(R.id.tvRmDrawerTitle)
        val btnDrawerBack = findViewById<Button>(R.id.btnRmDrawerBack)

        val tvTag = findViewById<TextView>(R.id.tvRmFeatureTag)
        val tvTitle = findViewById<TextView>(R.id.tvRmFeatureTitle)
        val tvDesc = findViewById<TextView>(R.id.tvRmFeatureDesc)
        val btnOpen = findViewById<Button>(R.id.btnRmOpenSelectedPanel)
        val btnExitNormal = findViewById<ImageButton>(R.id.btnRmExitToNormal)
        val btnTopAudio = findViewById<ImageButton>(R.id.btnRmTopAudio)
        val btnDockPerf = findViewById<Button>(R.id.btnRmDockPerf)
        val btnDockShare = findViewById<Button>(R.id.btnRmDockScreenShare)

        val navTabs = findViewById<LinearLayout>(R.id.layoutBottomNavTabs)
        val perfBar = findViewById<LinearLayout>(R.id.layoutRedMagicPerfBar)
        val rgbBar = findViewById<View>(R.id.viewCyberRgbBar)

        val cardVps = findViewById<MaterialCardView>(R.id.cardVpsSection)
        val cardWa = findViewById<MaterialCardView>(R.id.cardWaPairingSection)
        val cardAi = findViewById<MaterialCardView>(R.id.cardAiSection)
        val cardBackup = findViewById<MaterialCardView>(R.id.cardBackupUpdateSection)

        val layoutRina = findViewById<LinearLayout>(R.id.layoutRinaMascot)
        val layoutRinaBubble = findViewById<LinearLayout>(R.id.layoutRinaBubble)
        val ivRina = findViewById<ImageView>(R.id.ivRinaMascot)
        val tvRinaName = findViewById<TextView>(R.id.tvRinaName)
        val tvRinaDialogue = findViewById<TextView>(R.id.tvRinaDialogue)
        val btnToggleRina = findViewById<ImageButton>(R.id.btnRmToggleRina)
        var headpatCount = 0
        var bodyPokeCount = 0

        fun updateRinaMoodHeader() {
            when (prefs.rinaMood) {
                "ANGRY" -> {
                    tvRinaName?.text = "RINA // DRAGON AI [MARAH]"
                    tvRinaName?.setTextColor(Color.parseColor("#FF1744"))
                }
                "HAPPY" -> {
                    tvRinaName?.text = "RINA // DRAGON AI [SENANG]"
                    tvRinaName?.setTextColor(Color.parseColor("#00E5FF"))
                }
                else -> {
                    tvRinaName?.text = "RINA // DRAGON AI"
                    tvRinaName?.setTextColor(Color.parseColor("#FF4D6D"))
                }
            }
        }
        updateRinaMoodHeader()

        layoutRinaBubble?.background = MechaChamferDrawable(
            fillColor = Color.parseColor("#E6090C14"),
            strokeColorStart = Color.parseColor("#FF1744"),
            strokeColorEnd = Color.parseColor("#FF80AB"),
            chamferPx = 14f,
            strokePx = 2f
        )

        rinaFloatAnim?.cancel()
        if (ivRina != null) {
            rinaFloatAnim = ObjectAnimator.ofFloat(ivRina, "translationY", 0f, -7f, 0f).apply {
                duration = 2200L
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                start()
            }
        }

        fun showRinaSpeak(exprRes: Int, line: String, overrideMoodCheck: Boolean = false) {
            if (!isRinaVisible) return
            updateRinaMoodHeader()
            val finalExpr = if (!overrideMoodCheck && prefs.rinaMood == "ANGRY") R.drawable.rina_angry else exprRes
            ivRina?.let { img ->
                img.setImageResource(finalExpr)
                img.scaleX = 0.88f
                img.scaleY = 0.88f
                img.animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(OvershootInterpolator(1.8f)).start()
            }
            rinaDialogueJob?.cancel()
            rinaDialogueJob = lifecycleScope.launch {
                tvRinaDialogue?.text = ""
                val sb = StringBuilder()
                for (ch in line) {
                    sb.append(ch)
                    tvRinaDialogue?.text = sb.toString()
                    delay(18)
                }
            }
        }
        rinaSpeakerCallback = { expr, line, ov -> showRinaSpeak(expr, line, ov) }

        findViewById<ImageButton>(R.id.btnRmAskRina)?.setOnClickListener {
            animateBounce(it)
            showAskRinaDialog()
        }

        drawerOverlay?.background = MechaChamferDrawable(
            fillColor = Color.parseColor("#F5060810"),
            strokeColorStart = Color.parseColor("#FF1744"),
            strokeColorEnd = Color.parseColor("#990000"),
            chamferPx = 22f,
            strokePx = 3f
        )

        val features = listOf(
            RmFeatureItem(
                "bot", "WhatsApp Bot", "Pairing & PiP", "CORE ENGINE",
                "Tautkan banyak nomor WA sekaligus, Mode Jendela Kecil (PiP), dan kelola status aktif bot.",
                R.drawable.ic_rm_bot, 0
            ),
            RmFeatureItem(
                "vps", "Konektor VPS", "SSH 24 Jam", "CLOUD SERVER",
                "Pasang dan jalankan mesin bot 24 jam nonstop di server Ubuntu VPS langsung via SSH.",
                R.drawable.ic_rm_vps, 0
            ),
            RmFeatureItem(
                "ai", "AI & Moderasi", "Vision & Grup", "GEMINI 2.5",
                "Atur API Key AQ, AI Vision gratis, serta toggle Auto-Welcome, Anti-Link, dan Anti-Spam.",
                R.drawable.ic_rm_ai, 0
            ),
            RmFeatureItem(
                "announce", "Pengumuman", "Broadcast Grup", "MULTI GROUP",
                "Ceklis daftar grup yang sudah dimasuki lalu kirim pengumuman otomatis dengan hashtag keren.",
                R.drawable.ic_rm_announce, 1
            ),
            RmFeatureItem(
                "term", "Terminal Sesi 2", "Shell Terisolasi", "SESSION 2",
                "Terminal minimalis interaktif yang berjalan terpisah tanpa mengganggu bot WhatsApp aktif.",
                R.drawable.ic_rm_terminal, 2
            ),
            RmFeatureItem(
                "server", "Minecraft Server", "Panel Khusus VPS", if (prefs.connectionMode == "VPS") "VPS UNLOCKED" else "TERKUNCI (HP)",
                "Panel minimalis anti-slop untuk mengelola server Bedrock BDS atau PaperMC di VPS Anda.",
                R.drawable.ic_rm_server, 3
            ),
            RmFeatureItem(
                "backup", "Backup & Update", "Restore & OTA", "MAINTENANCE",
                "Cadangkan pengaturan bot ke file JSON serta cek dan pasang pembaruan langsung dari APK.",
                R.drawable.ic_rm_backup, 0
            )
        )

        val rowViews = mutableListOf<LinearLayout>()

        fun closeRmDrawer() {
            if (drawerOverlay?.visibility != View.VISIBLE) return
            drawerOverlay.animate()
                .alpha(0f)
                .translationX(260f)
                .setDuration(200)
                .withEndAction {
                    drawerOverlay.visibility = View.GONE
                    drawerOverlay.translationX = 0f
                    tvTitle?.visibility = View.VISIBLE
                    tvDesc?.visibility = View.VISIBLE
                    btnOpen?.visibility = View.VISIBLE
                    rightStage?.visibility = View.VISIBLE
                }
                .start()
            btnCloseDrawer?.visibility = View.GONE
        }

        fun openRmDrawerFor(item: RmFeatureItem) {
            val btns = listOf<Button?>(
                findViewById(R.id.btnTabBot),
                findViewById(R.id.btnTabAnnounce),
                findViewById(R.id.btnTabTerminal),
                findViewById(R.id.btnTabMcServer)
            )
            btns.getOrNull(item.targetTab)?.performClick()

            // Opsi 1: Fokuskan hanya kartu milik menu yang dipilih agar rapi & tidak bercampur!
            if (item.targetTab == 0) {
                cardWa?.visibility = if (item.key == "bot") View.VISIBLE else View.GONE
                cardVps?.visibility = if (item.key == "vps") View.VISIBLE else View.GONE
                cardAi?.visibility = if (item.key == "ai") View.VISIBLE else View.GONE
                cardBackup?.visibility = if (item.key == "backup") View.VISIBLE else View.GONE
            } else {
                cardWa?.visibility = View.VISIBLE
                cardVps?.visibility = View.VISIBLE
                cardAi?.visibility = View.VISIBLE
                cardBackup?.visibility = View.VISIBLE
            }

            // Sembunyikan bar tab emoji & perf bar ganda di dalam drawer agar tampilan bersih murni RedMagic!
            navTabs?.visibility = View.GONE
            perfBar?.visibility = View.GONE
            rgbBar?.visibility = View.GONE

            // Pindahkan scrollNormalDashboard dengan aman ke dalam drawerSlot
            if (scrollDash != null && drawerSlot != null && scrollDash.parent !== drawerSlot) {
                (scrollDash.parent as? ViewGroup)?.removeView(scrollDash)
                drawerSlot.addView(scrollDash)
            }
            scrollDash?.visibility = View.VISIBLE
            scrollDash?.scrollTo(0, 0)
            drawerTitle?.text = "${item.title.uppercase()}  //  ${item.tag}"

            tvTitle?.visibility = View.GONE
            tvDesc?.visibility = View.GONE
            btnOpen?.visibility = View.GONE
            rightStage?.visibility = View.VISIBLE
            drawerOverlay?.visibility = View.VISIBLE
            drawerOverlay?.alpha = 0f
            drawerOverlay?.scaleX = 0.86f
            drawerOverlay?.scaleY = 0.86f
            drawerOverlay?.translationY = 40f
            drawerOverlay?.animate()
                ?.alpha(1f)
                ?.scaleX(1f)
                ?.scaleY(1f)
                ?.translationY(0f)
                ?.setDuration(300)
                ?.setInterpolator(OvershootInterpolator(1.15f))
                ?.start()
            btnCloseDrawer?.visibility = View.VISIBLE
        }

        fun refreshShowcase(idx: Int) {
            selectedRmIndex = idx
            val item = features[idx]
            tvTag?.text = item.tag
            tvTitle?.text = item.title
            tvDesc?.text = item.desc

            tvTitle?.alpha = 0f
            tvTitle?.translationX = 40f
            tvTitle?.animate()?.alpha(1f)?.translationX(0f)?.setDuration(220)?.start()

            rowViews.forEachIndexed { rIdx, row ->
                if (rIdx == idx) {
                    row.background = MechaChamferDrawable(
                        fillColor = Color.parseColor("#D9260B14"),
                        strokeColorStart = Color.parseColor("#FF1744"),
                        strokeColorEnd = Color.parseColor("#FF6B6B"),
                        chamferPx = 14f,
                        strokePx = 2.5f
                    )
                } else {
                    row.setBackgroundColor(Color.parseColor("#880A0D16"))
                }
            }

            val (expr, rinaLine) = if (prefs.rinaMood == "ANGRY") {
                val angryMenuLine = when (item.key) {
                    "bot" -> "Hmph! Masih marah nih! Urus sendiri pairing WA-nya di tombol bawah, dasar Master menyebalkan!"
                    "vps" -> "Lagi ngambek! Tapi kalau mau pasang bot di VPS, pencet aja sendiri tombolnya!"
                    "ai" -> "Gak mau jelasin banyak-banyak! Itu pengaturan AI & grup... elus kepalaku dulu baru baikan!"
                    "announce" -> "Hmph! Itu menu pengumuman grup. Jangan nyuruh-nyuruh kalau belum minta maaf!"
                    "term" -> "Terminal Sesi 2! Awas kalau bikin error lagi, aku gak bakal bantu!"
                    "server" -> "Lagi kesal! Server Minecraft itu cuma buat VPS, ngerti?!"
                    else -> "Backup & Restore ada di situ! Sana urus sendiri... hmph!"
                }
                R.drawable.rina_angry to angryMenuLine
            } else {
                when (item.key) {
                    "bot" -> R.drawable.rina_explain to "Hmph! Di sini buat pairing WA & atur bot aktif. Jangan sampai salah ketik kodenya ya!"
                    "vps" -> R.drawable.rina_excited to "Kalau pakai VPS, aku bisa jaga bot kamu 24 jam nonstop! Keren kan? B-bukan buat pamer sih!"
                    "ai" -> R.drawable.rina_explain to "Ini otak Gemini AI & moderasi grup. Kalau API Key-nya kosong, aku ngambek loh!"
                    "announce" -> R.drawable.rina_excited to "Mau kirim pengumuman ke banyak grup sekaligus? Tinggal ceklis aja, gampang!"
                    "term" -> R.drawable.rina_tsundere to "Terminal Sesi 2 ini terpisah dari bot... J-jangan ketik perintah aneh-aneh di situ ya, Master!"
                    "server" -> if (prefs.connectionMode == "VPS") {
                        R.drawable.rina_excited to "Mode Server Minecraft kebuka tuh! Ayo nyalain servernya!"
                    } else {
                        R.drawable.rina_tsundere to "Eh? Server Minecraft masih terkunci! Pindah ke Mode VPS dulu baru aku bukain!"
                    }
                    else -> R.drawable.rina_tsundere to "Backup, Restore, dan Cek Update ada di sini semua. Rajin backup biar datamu aman, dasar pelupa!"
                }
            }
            showRinaSpeak(expr, rinaLine)

            // Jika drawer sedang terbuka, langsung ganti isi panel dengan mulus!
            if (drawerOverlay?.visibility == View.VISIBLE) {
                openRmDrawerFor(item)
            }
        }

        listContainer.removeAllViews()
        features.forEachIndexed { idx, item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(12, 10, 12, 10)
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.bottomMargin = 8
                layoutParams = lp
                setOnClickListener {
                    animateBounce(this)
                    refreshShowcase(idx)
                }
            }

            val iconView = ImageView(this).apply {
                setImageResource(item.iconRes)
                // Dual-tone CyberX icon colors preserved
                val lp = LinearLayout.LayoutParams(38, 38)
                lp.marginEnd = 14
                layoutParams = lp
            }

            val textCol = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }

            val tTitle = TextView(this).apply {
                text = item.title
                setTextColor(Color.WHITE)
                textSize = 11.5f
                setTypeface(null, android.graphics.Typeface.BOLD)
            }

            val tSub = TextView(this).apply {
                text = item.subtitle
                setTextColor(Color.parseColor("#94A3B8"))
                textSize = 9.5f
            }

            textCol.addView(tTitle)
            textCol.addView(tSub)
            row.addView(iconView)
            row.addView(textCol)
            row.alpha = 0f
            row.translationX = -70f
            row.animate().alpha(1f).translationX(0f).setStartDelay((idx * 45).toLong()).setDuration(320).setInterpolator(DecelerateInterpolator()).start()
            rowViews.add(row)
            listContainer.addView(row)
        }

        refreshShowcase(selectedRmIndex.coerceIn(0, features.lastIndex))

        btnOpen?.setOnClickListener {
            animateBounce(it)
            openRmDrawerFor(features[selectedRmIndex])
        }

        btnDrawerBack?.setOnClickListener {
            animateBounce(it)
            closeRmDrawer()
        }

        btnCloseDrawer?.setOnClickListener {
            animateBounce(it)
            closeRmDrawer()
        }

        layoutRina?.visibility = if (isRinaVisible) View.VISIBLE else View.GONE
        btnToggleRina?.setOnClickListener {
            animateBounce(it)
            if (isRinaVisible) {
                // Ditutup tiba-tiba -> Rina langsung marah & mengingatnya!
                prefs.rinaMood = "ANGRY"
                headpatCount = 0
                isRinaVisible = false
                layoutRina?.visibility = View.GONE
                Toast.makeText(this, "💢 Rina ngambek karena kamu tutup tiba-tiba!", Toast.LENGTH_SHORT).show()
            } else {
                isRinaVisible = true
                layoutRina?.visibility = View.VISIBLE
                if (prefs.rinaMood == "ANGRY") {
                    showRinaSpeak(R.drawable.rina_angry, "Hmph!! Enak aja main tutup-tutup aku tiba-tiba! Aku masih MARAH! Elus kepalaku dulu sana!", true)
                } else {
                    showRinaSpeak(R.drawable.rina_tsundere, "K-kenapa manggil lagi?! Aku gak ke mana-mana kok!")
                }
            }
        }

        val pokeLines = listOf(
            R.drawable.rina_tsundere to "H-hei! Jangan asal colek badan aku dong!",
            R.drawable.rina_tsundere to "D-dibilangin jangan dicolek terus... nanti aku marah beneran loh!"
        )
        var pokeIdx = 0

        @Suppress("ClickableViewAccessibility")
        ivRina?.setOnTouchListener { v, event ->
            if (event.action == android.view.MotionEvent.ACTION_UP) {
                animateBounce(v)
                val isHeadArea = v.height > 0 && event.y < v.height * 0.48f
                if (isHeadArea) {
                    // Elus kepala (tap-tap area kepala/tanduk atas)!
                    bodyPokeCount = 0
                    if (prefs.rinaMood == "ANGRY") {
                        headpatCount++
                        when {
                            headpatCount == 1 -> showRinaSpeak(R.drawable.rina_angry, "Eh?! J-jangan pegang-pegang kepalaku... aku masih marah nih!", true)
                            headpatCount == 2 -> showRinaSpeak(R.drawable.rina_tsundere, "U-ugh... dibilangin jangan dielus terus... hmph, tapi agak hangat sih...", true)
                            else -> {
                                prefs.rinaMood = "HAPPY"
                                headpatCount = 0
                                showRinaSpeak(R.drawable.rina_excited, "Y-ya udah deh! Aku maafin kali ini aja... tapi jangan tutup aku tiba-tiba lagi ya, Master!", true)
                            }
                        }
                    } else {
                        prefs.rinaMood = "HAPPY"
                        showRinaSpeak(R.drawable.rina_tsundere, "Nyaa~?! J-jangan terus-terusan elus kepalaku, Master... nanti tandukku kepanasan!", true)
                    }
                } else {
                    // Colek badan/bawah terlalu sering bikin dia marah
                    bodyPokeCount++
                    if (prefs.rinaMood == "ANGRY" || bodyPokeCount >= 3) {
                        prefs.rinaMood = "ANGRY"
                        headpatCount = 0
                        showRinaSpeak(R.drawable.rina_angry, "HMPH! Dibilangin jangan colek-colek sembarangan! Elus kepalaku baik-baik kalau mau aku baikan!", true)
                    } else {
                        val (ex, ln) = pokeLines[pokeIdx % pokeLines.size]
                        pokeIdx++
                        showRinaSpeak(ex, ln)
                    }
                }
            }
            true
        }

        rinaIdleJob?.cancel()
        rinaIdleJob = lifecycleScope.launch {
            val idleLines = listOf(
                R.drawable.rina_idle to "Hmm... Master lagi mikirin apa sih? Cepat pilih menunya sana.",
                R.drawable.rina_tsundere to "D-duduk di sini lumayan nyaman juga... jangan diusir ya!",
                R.drawable.rina_excited to "Semua sistem naga siap! Tinggal klik 'MULAI / BUKA PANEL' aja."
            )
            val angryIdleLines = listOf(
                R.drawable.rina_angry to "Hmph... masih cuek aja nih? Tap-tap kepalaku dong kalau mau aku maafin!",
                R.drawable.rina_angry to "Aku masih ngambek ya, Master! Jangan kira aku gampang lupa!"
            )
            var iIdx = 0
            while (true) {
                delay(16000)
                if (isRinaVisible && prefs.uiThemeMode == "cyber" && drawerOverlay?.visibility != View.VISIBLE) {
                    if (prefs.rinaMood == "ANGRY") {
                        val (ex, ln) = angryIdleLines[iIdx % angryIdleLines.size]
                        showRinaSpeak(ex, ln, true)
                    } else {
                        val (ex, ln) = idleLines[iIdx % idleLines.size]
                        showRinaSpeak(ex, ln)
                    }
                    iIdx++
                }
            }
        }

        btnExitNormal?.setOnClickListener {
            cardWa?.visibility = View.VISIBLE
            cardVps?.visibility = View.VISIBLE
            cardAi?.visibility = View.VISIBLE
            cardBackup?.visibility = View.VISIBLE
            // Kembalikan scrollDash ke root FrameLayout sebelum beralih ke Mode Normal
            val rootFrame = rmOverlay?.parent as? ViewGroup
            if (scrollDash != null && rootFrame != null && scrollDash.parent !== rootFrame) {
                (scrollDash.parent as? ViewGroup)?.removeView(scrollDash)
                rootFrame.addView(scrollDash, 2)
            }
            navTabs?.visibility = View.VISIBLE
            rgbBar?.visibility = View.VISIBLE
            prefs.uiThemeMode = "normal"
            findViewById<SwitchMaterial>(R.id.switchCyberTheme)?.isChecked = false
            applyCyberThemeState(false)
            Toast.makeText(this, "Kembali ke Mode Normal (Potret)", Toast.LENGTH_SHORT).show()
        }

        btnTopAudio?.setOnClickListener {
            findViewById<Button>(R.id.btnToggleBgAudio)?.performClick()
        }

        fun updateDockLabels() {
            btnDockPerf?.text = "MODE: ${prefs.perfMode.uppercase()}"
            btnDockShare?.text = if (prefs.isUnsafeScreenShare) "BAGI LAYAR: TERLIHAT" else "BAGI LAYAR: TERSEMBUNYI"
        }
        updateDockLabels()

        btnDockPerf?.setOnClickListener {
            animateBounce(it)
            val next = when (prefs.perfMode) {
                "eco" -> "balance"
                "balance" -> "turbo"
                else -> "eco"
            }
            when (next) {
                "eco" -> findViewById<Button>(R.id.btnPerfEco)?.performClick()
                "turbo" -> findViewById<Button>(R.id.btnPerfTurbo)?.performClick()
                else -> findViewById<Button>(R.id.btnPerfBalance)?.performClick()
            }
            updateDockLabels()
        }

        btnDockShare?.setOnClickListener {
            animateBounce(it)
            val sw = findViewById<SwitchMaterial>(R.id.switchUnsafeScreenShare)
            sw?.isChecked = !(sw?.isChecked ?: true)
            updateDockLabels()
        }
    }

    private suspend fun checkAndPromptForceUpdate(repo: String, silentIfLatest: Boolean) {
        val latest = BotEngineClient.checkLatestGithubRelease(repo)
        if (latest == null) {
            if (!silentIfLatest) {
                Toast.makeText(this, "Belum ada rilis APK ditemukan di $repo", Toast.LENGTH_SHORT).show()
            }
            return
        }
        val (tag, apkUrl, notes) = latest
        val curVer = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: "5.0.0"
        } catch (_: Exception) {
            "5.0.0"
        }
        val cleanTag = tag.removePrefix("v").trim()
        if (cleanTag == curVer || cleanTag.startsWith("5.0.") && curVer.startsWith("5.0.")) {
            if (!silentIfLatest) {
                Toast.makeText(this, "✅ Aplikasi sudah versi terbaru ($curVer)", Toast.LENGTH_SHORT).show()
            }
            return
        }
        // Popup Wajib Update (Force Update) yang langsung download & install dari dalam APK!
        AlertDialog.Builder(this)
            .setTitle("🚀 Wajib Update ke $tag")
            .setMessage("Versi baru tersedia!\n\n$notes\n\nTekan Update Sekarang untuk mengunduh & memasang langsung dari aplikasi tanpa uninstall.")
            .setCancelable(false)
            .setPositiveButton("⬇ Update Sekarang") { _, _ ->
                downloadAndInstallApk(apkUrl)
            }
            .show()
    }

    private fun downloadAndInstallApk(apkUrl: String) {
        val progDialog = AlertDialog.Builder(this)
            .setTitle("⏳ Mengunduh Pembaruan...")
            .setMessage("Sedang mengunduh APK terbaru langsung ke HP kamu...")
            .setCancelable(false)
            .show()
        lifecycleScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val client = okhttp3.OkHttpClient()
                val req = okhttp3.Request.Builder().url(apkUrl).build()
                client.newCall(req).execute().use { resp ->
                    val bytes = resp.body?.bytes()
                    if (bytes != null && bytes.size > 100_000) {
                        val outFile = java.io.File(cacheDir, "dodosbot_update.apk")
                        outFile.writeBytes(bytes)
                        val apkUri = FileProvider.getUriForFile(
                            this@MainActivity,
                            "${packageName}.fileprovider",
                            outFile
                        )
                        val installIntent = Intent(Intent.ACTION_VIEW).apply {
                            setDataAndType(apkUri, "application/vnd.android.package-archive")
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        runOnUiThread {
                            progDialog.dismiss()
                            startActivity(installIntent)
                        }
                        return@launch
                    }
                }
            } catch (_: Exception) {}
            runOnUiThread {
                progDialog.dismiss()
                Toast.makeText(this@MainActivity, "❌ Gagal mengunduh pembaruan. Cek koneksi internet.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun applyScreenShareMode(isUnsafe: Boolean) {
        if (isUnsafe) {
            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
            if (Build.VERSION.SDK_INT >= 33) {
                try {
                    setRecentsScreenshotEnabled(true)
                } catch (_: Exception) {}
            }
            markViewTreeNotSensitive(window.decorView)
        } else {
            window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }

    private fun markViewTreeNotSensitive(view: View?) {
        if (view == null) return
        if (Build.VERSION.SDK_INT >= 34) {
            try {
                // View.CONTENT_SENSITIVITY_NOT_SENSITIVE = 2 (mencegah Android 14/15 menghitamkan layar saat Share Screen WA!)
                val m = View::class.java.getMethod("setContentSensitivity", Int::class.javaPrimitiveType)
                m.invoke(view, 2)
            } catch (_: Exception) {}
        }
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                markViewTreeNotSensitive(view.getChildAt(i))
            }
        }
    }

    private fun setupVideoBackgroundLoop(textureView: TextureView, btnAudio: Button) {
        fun updateAudioButtonLabel() {
            btnAudio.text = if (prefs.isBgMusicMuted) "🔇 Musik OFF" else "🔊 Musik ON"
        }
        updateAudioButtonLabel()

        btnAudio.setOnClickListener {
            prefs.isBgMusicMuted = !prefs.isBgMusicMuted
            val vol = if (prefs.isBgMusicMuted) 0f else 1f
            try {
                bgMediaPlayer?.setVolume(vol, vol)
            } catch (_: Exception) {}
            updateAudioButtonLabel()
        }

        textureView.isOpaque = false
        textureView.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(surfaceTexture: SurfaceTexture, width: Int, height: Int) {
                startBackgroundVideo(surfaceTexture, textureView, width, height)
            }
            override fun onSurfaceTextureSizeChanged(surfaceTexture: SurfaceTexture, width: Int, height: Int) {
                adjustTextureAspectRatio(textureView, width, height)
            }
            override fun onSurfaceTextureDestroyed(surfaceTexture: SurfaceTexture): Boolean {
                releaseBackgroundVideo()
                return true
            }
            override fun onSurfaceTextureUpdated(surfaceTexture: SurfaceTexture) {}
        }
    }

    private fun startBackgroundVideo(surfaceTexture: SurfaceTexture, textureView: TextureView, viewW: Int, viewH: Int) {
        releaseBackgroundVideo()
        try {
            val surface = Surface(surfaceTexture)
            bgSurface = surface
            val mp = MediaPlayer()
            bgMediaPlayer = mp
            val rawId = resources.getIdentifier("bg_loop", "raw", packageName)
            if (rawId == 0) return
            val afd = resources.openRawResourceFd(rawId) ?: return
            mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
            mp.setSurface(surface)
            mp.isLooping = true
            val vol = if (prefs.isBgMusicMuted) 0f else 1f
            mp.setVolume(vol, vol)
            mp.setOnPreparedListener { player ->
                adjustTextureAspectRatio(textureView, viewW, viewH)
                player.start()
            }
            mp.prepareAsync()
        } catch (_: Exception) {
        }
    }

    private fun adjustTextureAspectRatio(textureView: TextureView, viewWidth: Int, viewHeight: Int) {
        val mp = bgMediaPlayer ?: return
        val videoWidth = mp.videoWidth.toFloat()
        val videoHeight = mp.videoHeight.toFloat()
        if (videoWidth <= 0f || videoHeight <= 0f || viewWidth <= 0 || viewHeight <= 0) return

        val scaleX = viewWidth.toFloat() / videoWidth
        val scaleY = viewHeight.toFloat() / videoHeight
        val maxScale = maxOf(scaleX, scaleY)

        val scaledWidth = videoWidth * maxScale
        val scaledHeight = videoHeight * maxScale

        val matrix = Matrix()
        matrix.setScale(scaledWidth / viewWidth, scaledHeight / viewHeight, viewWidth / 2f, viewHeight / 2f)
        textureView.setTransform(matrix)
    }

    private fun releaseBackgroundVideo() {
        try {
            bgMediaPlayer?.stop()
        } catch (_: Exception) {}
        try {
            bgMediaPlayer?.release()
        } catch (_: Exception) {}
        bgMediaPlayer = null
        try {
            bgSurface?.release()
        } catch (_: Exception) {}
        bgSurface = null
    }

    override fun onResume() {
        super.onResume()
        applyScreenShareMode(prefs.isUnsafeScreenShare)
        try {
            if (bgMediaPlayer != null && !bgMediaPlayer!!.isPlaying) {
                bgMediaPlayer?.start()
            }
        } catch (_: Exception) {}
    }

    override fun onPause() {
        super.onPause()
        try {
            if (bgMediaPlayer?.isPlaying == true) {
                bgMediaPlayer?.pause()
            }
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        cyberRgbAnimator?.cancel()
        releaseBackgroundVideo()
        super.onDestroy()
    }

    private fun applyApiKeyLockState(isLocked: Boolean, etApiKey: EditText, tvHint: TextView) {
        // Gunakan inputType biasa (bukan TYPE_TEXT_VARIATION_PASSWORD) agar Android 14/15 tidak menghitamkan layar saat Share Screen!
        etApiKey.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        if (isLocked) {
            etApiKey.isEnabled = false
            etApiKey.alpha = 0.65f
            tvHint.text = "🔒 API Key terkunci aman."
            tvHint.setTextColor(Color.parseColor("#10B981"))
        } else {
            etApiKey.isEnabled = true
            etApiKey.alpha = 1.0f
            tvHint.text = "🔓 Silakan masukkan / edit API Key lalu aktifkan Kunci Key."
            tvHint.setTextColor(Color.parseColor("#94A3B8"))
        }
        markViewTreeNotSensitive(etApiKey)
    }

    private fun renderPairedSessions(container: LinearLayout, sessions: List<PairedSessionItem>) {
        val sig = sessions.joinToString("|") { "${it.id}:${it.phone}:${it.active}:${it.loggedIn}:${it.connected}:${it.state}" }
        if (sig == lastSessionsSignature) return
        lastSessionsSignature = sig

        container.removeAllViews()
        if (sessions.isEmpty()) {
            val emptyTv = TextView(this).apply {
                text = "Belum ada nomor WA yang tertaut."
                setTextColor(Color.parseColor("#94A3B8"))
                textSize = 12f
                setPadding(4, 6, 4, 6)
            }
            container.addView(emptyTv)
            return
        }

        for (item in sessions) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundColor(Color.parseColor("#1E293B"))
                setPadding(20, 14, 20, 14)
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.topMargin = 10
                layoutParams = lp
            }

            val statusDot = when {
                item.loggedIn && item.active -> "🟢 Bot AI Aktif"
                item.loggedIn && !item.active -> "📸 Khusus Status HD (AI Mati)"
                else -> "⏳ Menunggu Kode (${item.state})"
            }

            val infoTv = TextView(this).apply {
                val phoneDisp = if (item.phone.isNotEmpty()) "+${item.phone}" else item.id
                text = "$phoneDisp\n$statusDot"
                setTextColor(Color.parseColor("#F8FAFC"))
                textSize = 12.5f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }

            val toggleSw = SwitchMaterial(this).apply {
                isChecked = item.active
                text = if (item.active) "ON" else "OFF"
                setTextColor(Color.parseColor("#CBD5E1"))
                textSize = 11f
                setOnCheckedChangeListener { _, isChecked ->
                    text = if (isChecked) "ON" else "OFF"
                    lifecycleScope.launch {
                        BotEngineClient.toggleSessionActive(this@MainActivity, item.id, isChecked)
                        lastSessionsSignature = ""
                    }
                }
            }

            val delBtn = Button(this).apply {
                text = "Hapus"
                textSize = 11f
                isAllCaps = false
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.parseColor("#EF4444"))
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.marginStart = 12
                layoutParams = lp
                setOnClickListener {
                    lifecycleScope.launch {
                        BotEngineClient.deleteSession(this@MainActivity, item.id)
                        lastSessionsSignature = ""
                        Toast.makeText(this@MainActivity, "Nomor ${item.phone} dihapus", Toast.LENGTH_SHORT).show()
                    }
                }
            }

            row.addView(infoTv)
            row.addView(toggleSw)
            row.addView(delBtn)
            container.addView(row)
        }
    }

    private fun saveFormToPrefs(
        isVps: Boolean,
        vpsUrl: String,
        vpsSecret: String,
        phone: String,
        apiKey: String,
        model: String,
        sysPrompt: String,
        scope: String,
        trigger: String,
        blacklist: String
    ) {
        prefs.connectionMode = if (isVps) "VPS" else "LOCAL"
        prefs.vpsUrl = BotEngineClient.formatVpsBaseUrl(vpsUrl)
        prefs.vpsSecret = vpsSecret
        prefs.phoneNumber = BotEngineClient.normalizePhone(phone)
        if (apiKey.trim().isNotEmpty()) {
            prefs.geminiApiKey = apiKey.trim()
        }
        prefs.geminiModel = model
        prefs.systemPrompt = sysPrompt
        prefs.replyScope = scope
        prefs.groupTrigger = trigger
        prefs.blacklistNumbers = blacklist
    }

    private fun startBotService() {
        val serviceIntent = Intent(this, BotForegroundService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }

    private fun requestIgnoreBatteryOptimization() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                try {
                    val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                        data = Uri.parse("package:$packageName")
                    }
                    startActivity(intent)
                } catch (_: Exception) {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }
            } else {
                Toast.makeText(this, "Aplikasi sudah bebas pembatasan baterai!", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
