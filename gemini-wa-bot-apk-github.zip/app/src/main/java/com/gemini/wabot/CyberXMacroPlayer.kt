package com.gemini.wabot

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class MacroEngineState {
    IDLE, RECORDING, PLAYING, PAUSED, ERROR
}

object CyberXMacroPlayer {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var playJob: Job? = null

    @Volatile var state: MacroEngineState = MacroEngineState.IDLE
    @Volatile var statusText: String = "Siap"
    @Volatile var currentLoop: Int = 0
    @Volatile var currentStepIndex: Int = 0
    @Volatile var activeMacroName: String = ""
    @Volatile var onStateChanged: (() -> Unit)? = null

    private fun notifyListener() {
        onStateChanged?.invoke()
    }

    fun play(context: Context, macro: CyberXMacroProfile) {
        if (macro.steps.isEmpty()) {
            state = MacroEngineState.ERROR
            statusText = "Gagal: Macro '${macro.name}' belum memiliki langkah sentuhan."
            notifyListener()
            return
        }
        val st = CyberXShizukuBackend.getStatus(context)
        if (!st.binderAlive || !st.permissionGranted) {
            state = MacroEngineState.ERROR
            statusText = st.detail
            notifyListener()
            return
        }

        playJob?.cancel()
        activeMacroName = macro.name
        state = MacroEngineState.PLAYING
        currentLoop = 0
        currentStepIndex = 0
        statusText = "Memutar '${macro.name}' via Shizuku..."
        notifyListener()

        playJob = scope.launch {
            val totalLoops = macro.loopCount // 0 = Infinite
            var loopIdx = 1
            while (isActive && (totalLoops == 0 || loopIdx <= totalLoops)) {
                currentLoop = loopIdx
                val sortedSteps = macro.steps.sortedBy { it.order }
                for ((idx, step) in sortedSteps.withIndex()) {
                    while (state == MacroEngineState.PAUSED && isActive) {
                        delay(80)
                    }
                    if (!isActive || state == MacroEngineState.IDLE || state == MacroEngineState.ERROR) {
                        return@launch
                    }
                    currentStepIndex = idx + 1
                    val spd = macro.speedMultiplier.coerceIn(0.25f, 4.0f)
                    val waitMs = (step.delayFromPrevMs / spd).toLong().coerceAtLeast(15L)
                    if (idx > 0 || loopIdx > 1) {
                        delay(waitMs)
                    }
                    while (state == MacroEngineState.PAUSED && isActive) {
                        delay(80)
                    }
                    if (!isActive || state == MacroEngineState.IDLE) return@launch

                    statusText = "Loop ${loopIdx}/${if (totalLoops == 0) "∞" else totalLoops} • Step ${idx + 1}/${sortedSteps.size} (${step.type.label})"
                    notifyListener()

                    val (ok, msg) = CyberXShizukuBackend.injectTouchStep(step, spd)
                    if (!ok) {
                        state = MacroEngineState.ERROR
                        statusText = "Input Gagal: $msg"
                        notifyListener()
                        return@launch
                    }
                }
                loopIdx++
            }
            state = MacroEngineState.IDLE
            statusText = "Selesai memutar '${macro.name}'."
            notifyListener()
        }
    }

    fun pause() {
        if (state == MacroEngineState.PLAYING) {
            state = MacroEngineState.PAUSED
            statusText = "Dijeda pada Step $currentStepIndex"
            notifyListener()
        }
    }

    fun resume() {
        if (state == MacroEngineState.PAUSED) {
            state = MacroEngineState.PLAYING
            statusText = "Melanjutkan '$activeMacroName'..."
            notifyListener()
        }
    }

    fun stop() {
        playJob?.cancel()
        playJob = null
        state = MacroEngineState.IDLE
        statusText = "Dihentikan"
        notifyListener()
    }
}
