package com.gemini.wabot

import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

enum class MacroEngineState {
    IDLE, RECORDING, PLAYING, PAUSED, ERROR
}

object CyberXMacroPlayer {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val activeJobs = ConcurrentHashMap<String, Job>()
    private val activeNames = ConcurrentHashMap<String, String>()
    private val activeLoops = ConcurrentHashMap<String, Int>()
    private val activeSteps = ConcurrentHashMap<String, Int>()

    @Volatile var state: MacroEngineState = MacroEngineState.IDLE
    @Volatile var statusText: String = "Siap"
    @Volatile var currentLoop: Int = 0
    @Volatile var currentStepIndex: Int = 0
    @Volatile var activeMacroName: String = ""
    @Volatile var onStateChanged: (() -> Unit)? = null

    private fun notifyListener() {
        mainHandler.post { onStateChanged?.invoke() }
    }

    fun isMacroRunning(macroId: String): Boolean {
        val j = activeJobs[macroId]
        return j != null && j.isActive
    }

    fun isAnyRunning(): Boolean = activeJobs.values.any { it.isActive }

    fun runningCount(): Int = activeJobs.values.count { it.isActive }

    fun getRunningMacroIds(): Set<String> = activeJobs.filterValues { it.isActive }.keys.toSet()

    fun vibrateFeedback(context: Context?, durationMs: Long = 35L) {
        if (context == null) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val v = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    v?.vibrate(durationMs)
                }
            }
        } catch (_: Exception) {}
    }

    fun toggle(context: Context, macro: CyberXMacroProfile) {
        if (isMacroRunning(macro.id)) {
            stopMacro(context, macro.id, macro.vibrateOnTrigger)
        } else {
            play(context, macro)
        }
    }

    fun play(context: Context, macro: CyberXMacroProfile) {
        if (!macro.enabled) {
            state = MacroEngineState.ERROR
            statusText = "Macro '${macro.name}' sedang dinonaktifkan."
            notifyListener()
            return
        }
        if (macro.steps.isEmpty()) {
            state = MacroEngineState.ERROR
            statusText = "Gagal: Macro '${macro.name}' belum memiliki langkah sentuhan."
            notifyListener()
            return
        }
        val st = CyberXShizukuBackend.getStatus(context)
        if (!st.binderAlive || !st.permissionGranted) {
            state = MacroEngineState.ERROR
            statusText = st.detail
            notifyListener()
            return
        }

        activeJobs.remove(macro.id)?.cancel()
        activeNames[macro.id] = macro.name
        activeLoops[macro.id] = 0
        activeSteps[macro.id] = 0

        if (macro.vibrateOnTrigger) vibrateFeedback(context, 40L)

        activeMacroName = macro.name
        state = MacroEngineState.PLAYING
        currentLoop = 0
        currentStepIndex = 0
        statusText = "Menjalankan '${macro.name}' (${runningCount() + 1} aktif)..."
        notifyListener()

        val job = scope.launch {
            try {
                val totalLoops = macro.loopCount // 0 = Infinite
                var loopIdx = 1
                while (isActive && (totalLoops == 0 || loopIdx <= totalLoops)) {
                    currentLoop = loopIdx
                    activeLoops[macro.id] = loopIdx
                    val sortedSteps = macro.steps.sortedBy { it.order }
                    for ((idx, step) in sortedSteps.withIndex()) {
                        while (state == MacroEngineState.PAUSED && isActive) {
                            delay(80)
                        }
                        if (!isActive || state == MacroEngineState.IDLE || state == MacroEngineState.ERROR) {
                            return@launch
                        }
                        currentStepIndex = idx + 1
                        activeSteps[macro.id] = idx + 1
                        val spd = macro.speedMultiplier.coerceIn(0.25f, 4.0f)
                        val waitMs = ((step.delayFromPrevMs + macro.extraDelayMs) / spd).toLong().coerceAtLeast(15L)
                        if (idx > 0 || loopIdx > 1) {
                            delay(waitMs)
                        }
                        while (state == MacroEngineState.PAUSED && isActive) {
                            delay(80)
                        }
                        if (!isActive || state == MacroEngineState.IDLE) return@launch

                        statusText = "${macro.name}: Loop ${loopIdx}/${if (totalLoops == 0) "∞" else totalLoops} • Step ${idx + 1}/${sortedSteps.size}"
                        notifyListener()

                        val (ok, msg) = CyberXShizukuBackend.injectTouchStep(step, spd)
                        if (!ok) {
                            state = MacroEngineState.ERROR
                            statusText = "Input Gagal: $msg"
                            notifyListener()
                            return@launch
                        }
                    }
                    loopIdx++
                }
            } finally {
                activeJobs.remove(macro.id)
                activeNames.remove(macro.id)
                activeLoops.remove(macro.id)
                activeSteps.remove(macro.id)
                if (!isAnyRunning() && state != MacroEngineState.ERROR && state != MacroEngineState.RECORDING) {
                    state = MacroEngineState.IDLE
                    statusText = "Selesai memutar '${macro.name}'."
                } else if (isAnyRunning()) {
                    activeMacroName = activeNames.values.firstOrNull() ?: ""
                    statusText = "${runningCount()} Macro masih berjalan..."
                }
                notifyListener()
            }
        }
        activeJobs[macro.id] = job
        notifyListener()
    }

    fun stopMacro(context: Context? = null, macroId: String, vibrate: Boolean = false) {
        activeJobs.remove(macroId)?.cancel()
        activeNames.remove(macroId)
        activeLoops.remove(macroId)
        activeSteps.remove(macroId)
        if (vibrate) vibrateFeedback(context, 25L)
        if (!isAnyRunning()) {
            state = MacroEngineState.IDLE
            statusText = "Dihentikan"
        } else {
            activeMacroName = activeNames.values.firstOrNull() ?: ""
            statusText = "${runningCount()} Macro masih berjalan..."
        }
        notifyListener()
    }

    fun pause() {
        if (state == MacroEngineState.PLAYING) {
            state = MacroEngineState.PAUSED
            statusText = "Dijeda pada Step $currentStepIndex"
            notifyListener()
        }
    }

    fun resume() {
        if (state == MacroEngineState.PAUSED) {
            state = MacroEngineState.PLAYING
            statusText = "Melanjutkan '$activeMacroName'..."
            notifyListener()
        }
    }

    fun stopAll(context: Context? = null) {
        val hadRunning = isAnyRunning()
        activeJobs.values.forEach { it.cancel() }
        activeJobs.clear()
        activeNames.clear()
        activeLoops.clear()
        activeSteps.clear()
        if (hadRunning) vibrateFeedback(context, 30L)
        state = MacroEngineState.IDLE
        statusText = "Semua Macro dihentikan"
        notifyListener()
    }

    fun stop() = stopAll(null)
}
