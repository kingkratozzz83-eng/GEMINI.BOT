package com.gemini.wabot

import android.content.Context
import android.content.SharedPreferences

class BotPrefsManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("gemini_wa_bot_prefs", Context.MODE_PRIVATE)

    var loggedInEmail: String
        get() = prefs.getString("logged_in_email", "") ?: ""
        set(value) = prefs.edit().putString("logged_in_email", value.trim()).apply()

    var ownerLockedEmail: String
        get() = prefs.getString("owner_locked_email", "") ?: ""
        set(value) = prefs.edit().putString("owner_locked_email", value.trim()).apply()

    var appPin: String
        get() = prefs.getString("app_pin", "") ?: ""
        set(value) = prefs.edit().putString("app_pin", value.trim()).apply()

    var isBotEnabled: Boolean
        get() = prefs.getBoolean("bot_enabled", true)
        set(value) = prefs.edit().putBoolean("bot_enabled", value).apply()

    var isApiKeyLocked: Boolean
        get() = prefs.getBoolean("api_key_locked", false)
        set(value) = prefs.edit().putBoolean("api_key_locked", value).apply()

    var connectionMode: String
        get() = prefs.getString("connection_mode_v28", "LOCAL") ?: "LOCAL"
        set(value) = prefs.edit().putString("connection_mode_v28", value).apply()

    var vpsUrl: String
        get() = prefs.getString("vps_url_v28", "") ?: ""
        set(value) = prefs.edit().putString("vps_url_v28", value.trim()).apply()

    var vpsUser: String
        get() = prefs.getString("vps_user_v28", "root") ?: "root"
        set(value) = prefs.edit().putString("vps_user_v28", value.trim().ifEmpty { "root" }).apply()

    var vpsSshPort: String
        get() = prefs.getString("vps_ssh_port_v28", "22") ?: "22"
        set(value) = prefs.edit().putString("vps_ssh_port_v28", value.trim().ifEmpty { "22" }).apply()

    var vpsSecret: String
        get() = prefs.getString("vps_secret_v28", "") ?: ""
        set(value) = prefs.edit().putString("vps_secret_v28", value.trim()).apply()

    var phoneNumber: String
        get() = prefs.getString("phone_number", "") ?: ""
        set(value) = prefs.edit().putString("phone_number", value.trim()).apply()

    var botName: String
        get() = prefs.getString("custom_bot_name_v46", "DodosBot")?.trim()?.ifEmpty { "DodosBot" } ?: "DodosBot"
        set(value) = prefs.edit().putString("custom_bot_name_v46", value.trim().ifEmpty { "DodosBot" }).apply()

    var geminiApiKey: String
        get() = prefs.getString("gemini_api_key", "") ?: ""
        set(value) = prefs.edit().putString("gemini_api_key", value.trim()).apply()

    var geminiModel: String
        get() {
            val raw = prefs.getString("gemini_model_v37", null)
                ?: prefs.getString("gemini_model", "gemini-2.5-flash")
                ?: "gemini-2.5-flash"
            if (raw.contains("1.5") || raw.isBlank()) {
                prefs.edit()
                    .putString("gemini_model_v37", "gemini-2.5-flash")
                    .putString("gemini_model", "gemini-2.5-flash")
                    .apply()
                return "gemini-2.5-flash"
            }
            return raw.trim()
        }
        set(value) {
            val clean = if (value.contains("1.5") || value.isBlank()) "gemini-2.5-flash" else value.trim()
            prefs.edit()
                .putString("gemini_model_v37", clean)
                .putString("gemini_model", clean)
                .apply()
        }

    var systemPrompt: String
        get() = prefs.getString(
            "system_prompt",
            "Kamu adalah asisten AI pribadi yang ramah, cerdas, dan sopan di WhatsApp. Jawab dengan bahasa Indonesia yang santai, jelas, dan ringkas."
        ) ?: ""
        set(value) = prefs.edit().putString("system_prompt", value).apply()

    var replyScope: String
        get() = prefs.getString("reply_scope", "all") ?: "all"
        set(value) = prefs.edit().putString("reply_scope", value).apply()

    var groupTrigger: String
        get() = prefs.getString("group_trigger", "@bot") ?: "@bot"
        set(value) = prefs.edit().putString("group_trigger", value.trim()).apply()

    var blacklistNumbers: String
        get() = prefs.getString("blacklist_numbers", "") ?: ""
        set(value) = prefs.edit().putString("blacklist_numbers", value.trim()).apply()

    var menuStyle: String
        get() = prefs.getString("menu_style_v31", "both") ?: "both"
        set(value) = prefs.edit().putString("menu_style_v31", value).apply()

    var lastExtractedApkTime: Long
        get() = prefs.getLong("last_extracted_apk_time", 0L)
        set(value) = prefs.edit().putLong("last_extracted_apk_time", value).apply()

    var isUnsafeScreenShare: Boolean
        get() = prefs.getBoolean("unsafe_screen_share_v45", true)
        set(value) = prefs.edit().putBoolean("unsafe_screen_share_v45", value).apply()

    var isBgMusicMuted: Boolean
        get() = prefs.getBoolean("bg_music_muted_v45", false)
        set(value) = prefs.edit().putBoolean("bg_music_muted_v45", value).apply()

    var uiThemeMode: String
        get() = prefs.getString("ui_theme_mode_v50", "cyber") ?: "cyber"
        set(value) = prefs.edit().putString("ui_theme_mode_v50", value).apply()

    var isPowerSaverMode: Boolean
        get() = prefs.getBoolean("power_saver_mode_v50", false)
        set(value) = prefs.edit().putBoolean("power_saver_mode_v50", value).apply()

    var autoWelcome: Boolean
        get() = prefs.getBoolean("auto_welcome_v50", true)
        set(value) = prefs.edit().putBoolean("auto_welcome_v50", value).apply()

    var antiLink: Boolean
        get() = prefs.getBoolean("anti_link_v50", true)
        set(value) = prefs.edit().putBoolean("anti_link_v50", value).apply()

    var antiSpam: Boolean
        get() = prefs.getBoolean("anti_spam_v50", true)
        set(value) = prefs.edit().putBoolean("anti_spam_v50", value).apply()

    var updateRepo: String
        get() = prefs.getString("github_update_repo_v50", "") ?: ""
        set(value) = prefs.edit().putString("github_update_repo_v50", value.trim()).apply()
}
