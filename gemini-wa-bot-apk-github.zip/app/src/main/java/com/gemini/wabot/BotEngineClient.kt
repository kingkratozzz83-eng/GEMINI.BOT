package com.gemini.wabot

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.TimeUnit

data class PairedSessionItem(
    val id: String,
    val phone: String,
    val jid: String,
    val active: Boolean,
    val loggedIn: Boolean,
    val connected: Boolean,
    val state: String
)

data class EngineLiveStatus(
    val loggedIn: Boolean,
    val totalReplied: Int,
    val activeGroups: Int,
    val state: String,
    val sessions: List<PairedSessionItem>
)

object BotEngineClient {

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()
    val appLogs = CopyOnWriteArrayList<String>()
    private val fallbackMemory = mutableMapOf<String, MutableList<Pair<String, String>>>()

    @Volatile private var autoUpgradedVpsHost: String = ""

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(45, TimeUnit.SECONDS)
        .build()

    fun log(msg: String) {
        val ts = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        appLogs.add("[$ts] $msg")
        while (appLogs.size > 120) {
            appLogs.removeAt(0)
        }
    }

    fun formatVpsBaseUrl(raw: String): String {
        val clean = raw.trim().removeSuffix("/")
        if (clean.isEmpty()) return ""
        val withProto = if (clean.startsWith("http://") || clean.startsWith("https://")) {
            clean
        } else {
            "http://$clean"
        }
        val afterProto = withProto.substringAfter("://")
        return if (afterProto.contains(":")) {
            withProto
        } else {
            "$withProto:8765"
        }
    }

    private fun getBaseUrl(prefs: BotPrefsManager): String {
        return if (prefs.connectionMode == "VPS") {
            val formatted = formatVpsBaseUrl(prefs.vpsUrl)
            if (formatted.isEmpty()) "http://127.0.0.1:8765" else formatted
        } else {
            "http://127.0.0.1:8765"
        }
    }

    fun extractHostFromUrl(urlStr: String): String {
        val s = urlStr.trim().removePrefix("http://").removePrefix("https://").substringBefore("/").substringBefore(":")
        return s.trim()
    }

    fun normalizePhone(raw: String): String {
        val digits = raw.filter { it in '0'..'9' }
        return when {
            digits.startsWith("08") -> "62" + digits.substring(1)
            digits.startsWith("8") && digits.length >= 9 -> "62$digits"
            else -> digits
        }
    }

    suspend fun isLocalEngineRunning(): Boolean = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url("http://127.0.0.1:8765/status").get().build()
            httpClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                if (resp.isSuccessful && body.contains("\"engineVersion\":\"9.3\"")) {
                    return@withContext true
                }
                if (resp.isSuccessful) {
                    shutdownLocalEngine()
                    delay(400)
                }
                return@withContext false
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun ensureVpsInstallerExtracted(context: Context): String {
        val prefs = BotPrefsManager(context)
        val apkFile = java.io.File(context.applicationInfo.sourceDir)
        val currentApkTime = if (apkFile.exists()) apkFile.lastModified() else 0L
        val outBin = java.io.File(context.filesDir, "wabot_vps_installer.bin")
        val outGz = java.io.File(context.filesDir, "wabot_vps_amd64.gz")
        if (currentApkTime > 0L && prefs.lastExtractedApkTime == currentApkTime &&
            outGz.exists() && outGz.length() > 100_000L && outBin.exists() && outBin.length() > 100_000L
        ) {
            return outGz.absolutePath
        }
        try {
            java.util.zip.ZipFile(context.applicationInfo.sourceDir).use { apkZip ->
                val entry = apkZip.getEntry("lib/x86_64/libwabot_engine.so")
                    ?: apkZip.getEntry("lib/arm64-v8a/libwabot_vps.so")
                if (entry != null) {
                    apkZip.getInputStream(entry).use { rawIn ->
                        java.util.zip.GZIPOutputStream(outGz.outputStream()).use { gzOut ->
                            rawIn.copyTo(gzOut)
                        }
                    }
                    if (outGz.exists() && outGz.length() > 100_000L) {
                        outGz.copyTo(outBin, overwrite = true)
                        prefs.lastExtractedApkTime = currentApkTime
                        log("Installer VPS Linux amd64 v9.3 diekstrak (${outGz.length() / 1024} KB)")
                        return outGz.absolutePath
                    }
                }
            }
        } catch (e: Exception) {
            log("Info ekstrak APK: ${e.message}")
        }
        return outGz.absolutePath
    }

    suspend fun connectAndSetupVpsFromApk(
        context: Context,
        rawHost: String,
        sshPort: String,
        user: String,
        pass: String,
        forceInstall: Boolean = false
    ): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val cleanHost = extractHostFromUrl(rawHost)
        if (cleanHost.isEmpty()) {
            return@withContext false to "Masukkan Public IP VPS terlebih dahulu!"
        }
        val gzPath = ensureVpsInstallerExtracted(context)
        val payload = JSONObject().apply {
            put("host", cleanHost)
            put("sshPort", sshPort.trim().ifEmpty { "22" })
            put("user", user.trim().ifEmpty { "root" })
            put("pass", pass)
            put("botPort", "8765")
            put("gzPath", gzPath)
            put("forceInstall", forceInstall)
        }
        val setupClient = OkHttpClient.Builder()
            .connectTimeout(25, TimeUnit.SECONDS)
            .readTimeout(90, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .build()
        try {
            val req = Request.Builder()
                .url("http://127.0.0.1:8765/vps/connect")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()
            setupClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                if (body.isNotEmpty()) {
                    val json = JSONObject(body)
                    if (json.optBoolean("ok", false)) {
                        val vpsUrl = json.optString("vpsUrl", "http://$cleanHost:8765")
                        val msg = json.optString("message", "Berhasil terhubung ke VPS $cleanHost!")
                        val prefs = BotPrefsManager(context)
                        prefs.connectionMode = "VPS"
                        prefs.vpsUrl = formatVpsBaseUrl(vpsUrl)
                        prefs.vpsUser = user.trim().ifEmpty { "root" }
                        prefs.vpsSshPort = sshPort.trim().ifEmpty { "22" }
                        prefs.vpsSecret = pass
                        log(msg)
                        return@withContext true to msg
                    } else {
                        val err = json.optString("error", "Gagal menyambungkan ke VPS")
                        log("Gagal Konek VPS: $err")
                        return@withContext false to err
                    }
                }
            }
        } catch (e: Exception) {
            return@withContext false to "Gagal menghubungi modul installer lokal: ${e.message}"
        }
        false to "Tidak ada respons dari modul SSH lokal"
    }

    suspend fun checkOrRestartVpsViaSsh(context: Context, action: String): String = withContext(Dispatchers.IO) {
        val prefs = BotPrefsManager(context)
        val host = extractHostFromUrl(prefs.vpsUrl)
        if (host.isEmpty()) {
            return@withContext "Masukkan IP Public VPS terlebih dahulu!"
        }
        val payload = JSONObject().apply {
            put("host", host)
            put("sshPort", prefs.vpsSshPort.ifEmpty { "22" })
            put("user", prefs.vpsUser.ifEmpty { "root" })
            put("pass", prefs.vpsSecret)
            put("action", action)
        }
        try {
            val req = Request.Builder()
                .url("http://127.0.0.1:8765/vps/ssh-check")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()
            httpClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                if (body.isNotEmpty()) {
                    val json = JSONObject(body)
                    if (json.optBoolean("ok", false)) {
                        val out = json.optString("output", "active")
                        return@withContext "VPS ($host) Status: $out"
                    } else {
                        return@withContext "SSH Gagal: ${json.optString("error")}"
                    }
                }
            }
        } catch (e: Exception) {
            return@withContext "Error SSH: ${e.message}"
        }
        "Tidak dapat memeriksa status VPS"
    }

    suspend fun shutdownLocalEngine(): Boolean = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url("http://127.0.0.1:8765/shutdown")
                .post("{}".toRequestBody(jsonMediaType))
                .build()
            httpClient.newCall(req).execute().use { resp ->
                return@withContext resp.isSuccessful
            }
        } catch (_: Exception) {
            false
        }
    }

    suspend fun syncConfig(context: Context): Boolean = withContext(Dispatchers.IO) {
        val prefs = BotPrefsManager(context)
        val baseUrl = getBaseUrl(prefs)
        val payload = JSONObject().apply {
            put("apiKey", prefs.geminiApiKey)
            put("model", prefs.geminiModel)
            put("systemPrompt", prefs.systemPrompt)
            put("replyScope", prefs.replyScope)
            put("groupTrigger", prefs.groupTrigger)
            put("blacklistNumbers", prefs.blacklistNumbers)
            put("minDelayMs", 1500)
            put("maxDelayMs", 3000)
            put("phoneNumber", normalizePhone(prefs.phoneNumber))
            put("botEnabled", prefs.isBotEnabled)
            put("menuStyle", prefs.menuStyle)
            put("botName", prefs.botName)
            put("autoWelcome", prefs.autoWelcome)
            put("antiLink", prefs.antiLink)
            put("antiSpam", prefs.antiSpam)
        }
        try {
            val reqBuilder = Request.Builder()
                .url("$baseUrl/config")
                .post(payload.toString().toRequestBody(jsonMediaType))
            httpClient.newCall(reqBuilder.build()).execute().use { resp ->
                if (resp.isSuccessful) {
                    log("Konfigurasi disinkronkan ke server ($baseUrl)")
                    return@withContext true
                }
            }
        } catch (e: Exception) {
            log("Info Sinkronisasi: ${e.message}")
        }
        false
    }

    suspend fun requestPairingCode(context: Context, rawPhone: String): String = withContext(Dispatchers.IO) {
        val prefs = BotPrefsManager(context)
        val baseUrl = getBaseUrl(prefs)
        val cleanPhone = normalizePhone(rawPhone)
        try {
            val req = Request.Builder()
                .url("$baseUrl/pair?phone=$cleanPhone")
                .get()
                .build()
            httpClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                if (body.isNotEmpty()) {
                    val json = JSONObject(body)
                    if (json.optBoolean("ok", false)) {
                        val code = json.optString("pairingCode", "")
                        if (code.isNotEmpty()) {
                            log("Kode Pairing diterima untuk $cleanPhone: $code")
                            return@withContext code
                        }
                    } else {
                        val err = json.optString("error", "Gagal meminta kode pairing")
                        log("Gagal Pairing: $err")
                        return@withContext "GAGAL: $err"
                    }
                }
            }
        } catch (e: Exception) {
            return@withContext "ERROR: ${e.message}"
        }
        "GAGAL: Server belum siap"
    }

    suspend fun toggleSessionActive(context: Context, sessionId: String, active: Boolean): Boolean = withContext(Dispatchers.IO) {
        val prefs = BotPrefsManager(context)
        val baseUrl = getBaseUrl(prefs)
        try {
            val req = Request.Builder()
                .url("$baseUrl/session/toggle?id=$sessionId&active=$active")
                .get()
                .build()
            httpClient.newCall(req).execute().use { resp ->
                return@withContext resp.isSuccessful
            }
        } catch (_: Exception) {
            false
        }
    }

    suspend fun deleteSession(context: Context, sessionId: String): Boolean = withContext(Dispatchers.IO) {
        val prefs = BotPrefsManager(context)
        val baseUrl = getBaseUrl(prefs)
        try {
            val req = Request.Builder()
                .url("$baseUrl/session/delete?id=$sessionId")
                .get()
                .build()
            httpClient.newCall(req).execute().use { resp ->
                return@withContext resp.isSuccessful
            }
        } catch (_: Exception) {
            false
        }
    }

    suspend fun fetchJoinedGroups(context: Context): List<Triple<String, String, Int>> = withContext(Dispatchers.IO) {
        val prefs = BotPrefsManager(context)
        val baseUrl = getBaseUrl(prefs)
        val out = mutableListOf<Triple<String, String, Int>>()
        try {
            val req = Request.Builder().url("$baseUrl/groups/list").get().build()
            httpClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                if (resp.isSuccessful && body.isNotEmpty()) {
                    val json = JSONObject(body)
                    val arr = json.optJSONArray("groups")
                    if (arr != null) {
                        for (i in 0 until arr.length()) {
                            val obj = arr.optJSONObject(i) ?: continue
                            out.add(Triple(obj.optString("jid"), obj.optString("name"), obj.optInt("count", 0)))
                        }
                    }
                }
            }
        } catch (_: Exception) {}
        out
    }

    suspend fun sendGroupAnnouncement(
        context: Context,
        groupJids: List<String>,
        message: String,
        hidetag: Boolean,
        hashtags: String
    ): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val prefs = BotPrefsManager(context)
        val baseUrl = getBaseUrl(prefs)
        val payload = JSONObject().apply {
            put("groupJids", JSONArray(groupJids))
            put("message", message)
            put("hidetag", hidetag)
            put("hashtags", hashtags)
        }
        try {
            val req = Request.Builder()
                .url("$baseUrl/groups/announce")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()
            httpClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                val json = JSONObject(body)
                if (json.optBoolean("ok", false)) {
                    val sent = json.optInt("sent", 0)
                    val total = json.optInt("total", groupJids.size)
                    return@withContext true to "Terkirim ke $sent/$total grup!"
                }
                return@withContext false to json.optString("error", "Gagal mengirim pengumuman")
            }
        } catch (e: Exception) {
            return@withContext false to (e.message ?: "Error koneksi")
        }
    }

    private const val STCAUDIO_ENGINE_B64 = "Y29uc3QgaHR0cCA9IHJlcXVpcmUoImh0dHAiKTsKY29uc3QgZnMgPSByZXF1aXJlKCJmcyIpOwpjb25zdCBwYXRoID0gcmVxdWlyZSgicGF0aCIpOwpjb25zdCB7IGV4ZWNGaWxlIH0gPSByZXF1aXJlKCJjaGlsZF9wcm9jZXNzIik7CmNvbnN0IHsKICBkZWZhdWx0OiBtYWtlV0FTb2NrZXQsCiAgdXNlTXVsdGlGaWxlQXV0aFN0YXRlLAogIGRvd25sb2FkTWVkaWFNZXNzYWdlLAogIGZldGNoTGF0ZXN0QmFpbGV5c1ZlcnNpb24sCiAgcHJlcGFyZVdBTWVzc2FnZU1lZGlhLAogIGdlbmVyYXRlV0FNZXNzYWdlRnJvbUNvbnRlbnQsCiAgRGlzY29ubmVjdFJlYXNvbiwKICBwcm90bwp9ID0gcmVxdWlyZSgiQHdoaXNrZXlzb2NrZXRzL2JhaWxleXMiKTsKY29uc3QgcGlubyA9IHJlcXVpcmUoInBpbm8iKTsKCmNvbnN0IFBPUlQgPSA4NzY2Owpjb25zdCBBVVRIX0RJUiA9IHBhdGguam9pbihfX2Rpcm5hbWUsICJhdXRoX3N0Y2F1ZGlvIik7CmNvbnN0IFRNUF9ESVIgPSBwYXRoLmpvaW4oX19kaXJuYW1lLCAidG1wX3N0Y2F1ZGlvIik7CmZzLm1rZGlyU3luYyhBVVRIX0RJUiwgeyByZWN1cnNpdmU6IHRydWUgfSk7CmZzLm1rZGlyU3luYyhUTVBfRElSLCB7IHJlY3Vyc2l2ZTogdHJ1ZSB9KTsKCmxldCBzb2NrID0gbnVsbDsKbGV0IGNvbm5TdGF0ZSA9ICJESVNDT05ORUNURUQiOwpsZXQgcGFpcmVkUGhvbmUgPSAiIjsKbGV0IGxhc3RQYWlyQ29kZSA9ICIiOwpjb25zdCBsb2dzID0gW107CmNvbnN0IHBlbmRpbmdBdWRpb0J5S2V5ID0gbmV3IE1hcCgpOwpjb25zdCBwZW5kaW5nTWVkaWFCeUtleSA9IG5ldyBNYXAoKTsKCi8vIFByb3RvYnVmIHdpcmUtbGV2ZWwgZW5jb2RlciBwYXRjaCBmb3IgTmF0aXZlIFdoYXRzQXBwIFNvdW5kIFN0aWNrZXJzOgovLyBNZXNzYWdlLjEzNCAoRnV0dXJlUHJvb2ZNZXNzYWdlKSAtPiAxIChNZXNzYWdlKSAtPiAyNiAoU3RpY2tlck1lc3NhZ2UpIC0+IDI2IChBdWRpb01lc3NhZ2UpCmNvbnN0IHNvdW5kU3RpY2tlclBheWxvYWRzID0gbmV3IFdlYWtNYXAoKTsKZnVuY3Rpb24gZW5jb2RlVmFyaW50KG4pIHsKICBjb25zdCBieXRlcyA9IFtdOwogIGxldCB2ID0gbiA+Pj4gMDsKICB3aGlsZSAodiA+PSAweDgwKSB7CiAgICBieXRlcy5wdXNoKCh2ICYgMHg3ZikgfCAweDgwKTsKICAgIHYgPj4+PSA3OwogIH0KICBieXRlcy5wdXNoKHYpOwogIHJldHVybiBCdWZmZXIuZnJvbShieXRlcyk7Cn0KZnVuY3Rpb24gbGRGaWVsZChmaWVsZE51bSwgYnVmKSB7CiAgY29uc3QgdGFnID0gZW5jb2RlVmFyaW50KChmaWVsZE51bSA8PCAzKSB8IDIpOwogIGNvbnN0IGxlbiA9IGVuY29kZVZhcmludChidWYubGVuZ3RoKTsKICByZXR1cm4gQnVmZmVyLmNvbmNhdChbdGFnLCBsZW4sIGJ1Zl0pOwp9Cgpjb25zdCBvcmlnTWVzc2FnZUVuY29kZSA9IHByb3RvLk1lc3NhZ2UuZW5jb2RlLmJpbmQocHJvdG8uTWVzc2FnZSk7CnByb3RvLk1lc3NhZ2UuZW5jb2RlID0gZnVuY3Rpb24gKG1lc3NhZ2UsIHdyaXRlcikgewogIGNvbnN0IG1ldGEgPSBtZXNzYWdlICYmIHNvdW5kU3RpY2tlclBheWxvYWRzLmdldChtZXNzYWdlKTsKICBpZiAoIW1ldGEpIHsKICAgIHJldHVybiBvcmlnTWVzc2FnZUVuY29kZShtZXNzYWdlLCB3cml0ZXIpOwogIH0KICBjb25zdCBzdGtCeXRlcyA9IEJ1ZmZlci5mcm9tKHByb3RvLk1lc3NhZ2UuU3RpY2tlck1lc3NhZ2UuZW5jb2RlKG1ldGEuc3RpY2tlck1zZykuZmluaXNoKCkpOwogIGNvbnN0IGF1ZEJ5dGVzID0gQnVmZmVyLmZyb20ocHJvdG8uTWVzc2FnZS5BdWRpb01lc3NhZ2UuZW5jb2RlKG1ldGEuYXVkaW9Nc2cpLmZpbmlzaCgpKTsKICBjb25zdCBjb21iaW5lZFN0ayA9IEJ1ZmZlci5jb25jYXQoW3N0a0J5dGVzLCBsZEZpZWxkKDI2LCBhdWRCeXRlcyldKTsKICBjb25zdCBpbm5lck1zZyA9IGxkRmllbGQoMjYsIGNvbWJpbmVkU3RrKTsKICBjb25zdCBmdXR1cmVQcm9vZiA9IGxkRmllbGQoMSwgaW5uZXJNc2cpOwogIGNvbnN0IHRvcE1zZyA9IGxkRmllbGQoMTM0LCBmdXR1cmVQcm9vZik7CiAgcmV0dXJuIHsKICAgIGZpbmlzaCgpIHsKICAgICAgcmV0dXJuIHRvcE1zZzsKICAgIH0KICB9Owp9OwoKZnVuY3Rpb24gYWRkTG9nKG1zZykgewogIGNvbnN0IHRzID0gbmV3IERhdGUoKS50b1RpbWVTdHJpbmcoKS5zbGljZSgwLCA4KTsKICBsb2dzLnB1c2goYFske3RzfV0gJHttc2d9YCk7CiAgd2hpbGUgKGxvZ3MubGVuZ3RoID4gNTApIGxvZ3Muc2hpZnQoKTsKICBjb25zb2xlLmxvZyhgW1NUQ0FVRElPICR7dHN9XSAke21zZ31gKTsKfQoKZnVuY3Rpb24gcnVuRmZtcGVnKGFyZ3MpIHsKICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4gewogICAgZXhlY0ZpbGUoImZmbXBlZyIsIGFyZ3MsIHsgdGltZW91dDogNDUwMDAgfSwgKGVyciwgc3Rkb3V0LCBzdGRlcnIpID0+IHsKICAgICAgaWYgKGVycikgcmV0dXJuIHJlamVjdChuZXcgRXJyb3Ioc3RkZXJyIHx8IGVyci5tZXNzYWdlKSk7CiAgICAgIHJlc29sdmUoc3Rkb3V0KTsKICAgIH0pOwogIH0pOwp9Cgphc3luYyBmdW5jdGlvbiBidWlsZFdlYnBBbmRBdWRpbyhtZWRpYUJ1ZiwgaXNWaWRlbywgYXVkaW9CdWYsIHRtcElkKSB7CiAgY29uc3QgaW5NZWRpYSA9IHBhdGguam9pbihUTVBfRElSLCBgJHt0bXBJZH1faW4uJHtpc1ZpZGVvID8gIm1wNCIgOiAianBnIn1gKTsKICBjb25zdCBvdXRXZWJwID0gcGF0aC5qb2luKFRNUF9ESVIsIGAke3RtcElkfV9zdGsud2VicGApOwogIGNvbnN0IG91dE9nZyA9IHBhdGguam9pbihUTVBfRElSLCBgJHt0bXBJZH1fYXVkLm9nZ2ApOwogIGZzLndyaXRlRmlsZVN5bmMoaW5NZWRpYSwgbWVkaWFCdWYpOwoKICB0cnkgewogICAgaWYgKGlzVmlkZW8pIHsKICAgICAgYXdhaXQgcnVuRmZtcGVnKFsKICAgICAgICAiLXkiLCAiLWkiLCBpbk1lZGlhLCAiLXQiLCAiMTAiLAogICAgICAgICItdmYiLCAiZnBzPTE0LHNjYWxlPTUxMjo1MTI6Zm9yY2Vfb3JpZ2luYWxfYXNwZWN0X3JhdGlvPWRlY3JlYXNlLHBhZD01MTI6NTEyOihvdy1pdykvMjoob2gtaWgpLzI6Y29sb3I9MHgwMDAwMDAwMCIsCiAgICAgICAgIi12Y29kZWMiLCAibGlid2VicCIsICItbG9zc2xlc3MiLCAiMCIsICItY29tcHJlc3Npb25fbGV2ZWwiLCAiNiIsICItcTp2IiwgIjQyIiwgIi1sb29wIiwgIjAiLCAiLWFuIiwKICAgICAgICBvdXRXZWJwCiAgICAgIF0pOwogICAgfSBlbHNlIHsKICAgICAgYXdhaXQgcnVuRmZtcGVnKFsKICAgICAgICAiLXkiLCAiLWkiLCBpbk1lZGlhLAogICAgICAgICItdmYiLCAic2NhbGU9NTEyOjUxMjpmb3JjZV9vcmlnaW5hbF9hc3BlY3RfcmF0aW89ZGVjcmVhc2UscGFkPTUxMjo1MTI6KG93LWl3KS8yOihvaC1paCkvMjpjb2xvcj0weDAwMDAwMDAwIiwKICAgICAgICAiLXZjb2RlYyIsICJsaWJ3ZWJwIiwgIi1sb3NzbGVzcyIsICIwIiwgIi1xOnYiLCAiNzUiLAogICAgICAgIG91dFdlYnAKICAgICAgXSk7CiAgICB9CgogICAgaWYgKGF1ZGlvQnVmKSB7CiAgICAgIGNvbnN0IGluQXVkID0gcGF0aC5qb2luKFRNUF9ESVIsIGAke3RtcElkfV9hdWRfaW5gKTsKICAgICAgZnMud3JpdGVGaWxlU3luYyhpbkF1ZCwgYXVkaW9CdWYpOwogICAgICBhd2FpdCBydW5GZm1wZWcoWwogICAgICAgICIteSIsICItaSIsIGluQXVkLCAiLXQiLCAiMTAiLCAiLXZuIiwKICAgICAgICAiLWFmIiwgImFmYWRlPXQ9aW46c3Q9MDpkPTAuMDIiLAogICAgICAgICItYzphIiwgImxpYm9wdXMiLCAiLWI6YSIsICI0OGsiLCAiLWFyIiwgIjQ4MDAwIiwgIi1hYyIsICIxIiwKICAgICAgICBvdXRPZ2cKICAgICAgXSk7CiAgICAgIHRyeSB7IGZzLnVubGlua1N5bmMoaW5BdWQpOyB9IGNhdGNoIChfKSB7fQogICAgfSBlbHNlIGlmIChpc1ZpZGVvKSB7CiAgICAgIGF3YWl0IHJ1bkZmbXBlZyhbCiAgICAgICAgIi15IiwgIi1pIiwgaW5NZWRpYSwgIi10IiwgIjEwIiwgIi12biIsCiAgICAgICAgIi1hZiIsICJhZmFkZT10PWluOnN0PTA6ZD0wLjAyIiwKICAgICAgICAiLWM6YSIsICJsaWJvcHVzIiwgIi1iOmEiLCAiNDhrIiwgIi1hciIsICI0ODAwMCIsICItYWMiLCAiMSIsCiAgICAgICAgb3V0T2dnCiAgICAgIF0pLmNhdGNoKCgpID0+IHt9KTsKICAgIH0KCiAgICBjb25zdCB3ZWJwQnVmID0gZnMuZXhpc3RzU3luYyhvdXRXZWJwKSA/IGZzLnJlYWRGaWxlU3luYyhvdXRXZWJwKSA6IG51bGw7CiAgICBjb25zdCBvZ2dCdWYgPSBmcy5leGlzdHNTeW5jKG91dE9nZykgJiYgZnMuc3RhdFN5bmMob3V0T2dnKS5zaXplID4gMjAwID8gZnMucmVhZEZpbGVTeW5jKG91dE9nZykgOiBudWxsOwogICAgcmV0dXJuIHsgd2VicEJ1Ziwgb2dnQnVmIH07CiAgfSBmaW5hbGx5IHsKICAgIHRyeSB7IGZzLnVubGlua1N5bmMoaW5NZWRpYSk7IH0gY2F0Y2ggKF8pIHt9CiAgICB0cnkgeyBmcy51bmxpbmtTeW5jKG91dFdlYnApOyB9IGNhdGNoIChfKSB7fQogICAgdHJ5IHsgZnMudW5saW5rU3luYyhvdXRPZ2cpOyB9IGNhdGNoIChfKSB7fQogIH0KfQoKYXN5bmMgZnVuY3Rpb24gc2VuZE5hdGl2ZVNvdW5kU3RpY2tlcihqaWQsIHF1b3RlZE1zZywgbWVkaWFCdWYsIGlzVmlkZW8sIGF1ZGlvQnVmKSB7CiAgY29uc3QgeyB3ZWJwQnVmLCBvZ2dCdWYgfSA9IGF3YWl0IGJ1aWxkV2VicEFuZEF1ZGlvKG1lZGlhQnVmLCBpc1ZpZGVvLCBhdWRpb0J1ZiwgRGF0ZS5ub3coKS50b1N0cmluZygpKTsKICBpZiAoIXdlYnBCdWYpIHRocm93IG5ldyBFcnJvcigiR2FnYWwgbWVuZ29udmVyc2kgbWVkaWEga2Ugc3Rpa2VyIFdlYlAiKTsKCiAgaWYgKCFvZ2dCdWYpIHsKICAgIGF3YWl0IHNvY2suc2VuZE1lc3NhZ2UoamlkLCB7IHN0aWNrZXI6IHdlYnBCdWYgfSwgeyBxdW90ZWQ6IHF1b3RlZE1zZyB9KTsKICAgIGFkZExvZyhgU3Rpa2VyIHRhbnBhIGF1ZGlvIHRlcmtpcmltIGtlICR7amlkfSAobWVkaWEgdGlkYWsgbWVtaWxpa2kgc3VhcmEpYCk7CiAgICByZXR1cm47CiAgfQoKICB0cnkgewogICAgY29uc3Qgc3RrUHJlcCA9IGF3YWl0IHByZXBhcmVXQU1lc3NhZ2VNZWRpYSh7IHN0aWNrZXI6IHdlYnBCdWYgfSwgeyB1cGxvYWQ6IHNvY2sud2FVcGxvYWRUb1NlcnZlciB9KTsKICAgIGNvbnN0IGF1ZFByZXAgPSBhd2FpdCBwcmVwYXJlV0FNZXNzYWdlTWVkaWEoCiAgICAgIHsgYXVkaW86IG9nZ0J1ZiwgbWltZXR5cGU6ICJhdWRpby9vZ2c7IGNvZGVjcz1vcHVzIiwgcHR0OiB0cnVlIH0sCiAgICAgIHsgdXBsb2FkOiBzb2NrLndhVXBsb2FkVG9TZXJ2ZXIgfQogICAgKTsKICAgIGlmIChzdGtQcmVwPy5zdGlja2VyTWVzc2FnZSAmJiBhdWRQcmVwPy5hdWRpb01lc3NhZ2UpIHsKICAgICAgc3RrUHJlcC5zdGlja2VyTWVzc2FnZS5pc0FuaW1hdGVkID0gaXNWaWRlbzsKICAgICAgc3RrUHJlcC5zdGlja2VyTWVzc2FnZS53aWR0aCA9IDUxMjsKICAgICAgc3RrUHJlcC5zdGlja2VyTWVzc2FnZS5oZWlnaHQgPSA1MTI7CiAgICAgIGNvbnN0IG1zZ09iaiA9IHByb3RvLk1lc3NhZ2UuZnJvbU9iamVjdCh7fSk7CiAgICAgIHNvdW5kU3RpY2tlclBheWxvYWRzLnNldChtc2dPYmosIHsKICAgICAgICBzdGlja2VyTXNnOiBzdGtQcmVwLnN0aWNrZXJNZXNzYWdlLAogICAgICAgIGF1ZGlvTXNnOiBhdWRQcmVwLmF1ZGlvTWVzc2FnZQogICAgICB9KTsKICAgICAgY29uc3QgZnVsbE1zZyA9IGdlbmVyYXRlV0FNZXNzYWdlRnJvbUNvbnRlbnQoamlkLCBtc2dPYmosIHsgdXNlckppZDogc29jay51c2VyPy5pZCwgcXVvdGVkOiBxdW90ZWRNc2cgfSk7CiAgICAgIGF3YWl0IHNvY2sucmVsYXlNZXNzYWdlKGppZCwgZnVsbE1zZy5tZXNzYWdlLCB7IG1lc3NhZ2VJZDogZnVsbE1zZy5rZXkuaWQgfSk7CiAgICAgIGFkZExvZyhg8J+UiiBOYXRpdmUgU291bmQgU3RpY2tlciB0ZXJraXJpbSBrZSAke2ppZH0hYCk7CiAgICAgIHJldHVybjsKICAgIH0KICB9IGNhdGNoIChlKSB7CiAgICBhZGRMb2coYEZhbGxiYWNrIChnYWdhbCBuYXRpdmUgc291bmQgc3RpY2tlcjogJHtlLm1lc3NhZ2V9KWApOwogIH0KCiAgYXdhaXQgc29jay5zZW5kTWVzc2FnZShqaWQsIHsgc3RpY2tlcjogd2VicEJ1ZiB9LCB7IHF1b3RlZDogcXVvdGVkTXNnIH0pOwogIGF3YWl0IHNvY2suc2VuZE1lc3NhZ2UoamlkLCB7IGF1ZGlvOiBvZ2dCdWYsIG1pbWV0eXBlOiAiYXVkaW8vb2dnOyBjb2RlY3M9b3B1cyIsIHB0dDogdHJ1ZSB9LCB7IHF1b3RlZDogcXVvdGVkTXNnIH0pOwogIGFkZExvZyhgU3Rpa2VyICsgQXVkaW8gZmFsbGJhY2sgdGVya2lyaW0ga2UgJHtqaWR9YCk7Cn0KCmZ1bmN0aW9uIGdldFRleHRGcm9tTXNnKG0pIHsKICBpZiAoIW0pIHJldHVybiAiIjsKICByZXR1cm4gKAogICAgbS5jb252ZXJzYXRpb24gfHwKICAgIG0uZXh0ZW5kZWRUZXh0TWVzc2FnZT8udGV4dCB8fAogICAgbS5pbWFnZU1lc3NhZ2U/LmNhcHRpb24gfHwKICAgIG0udmlkZW9NZXNzYWdlPy5jYXB0aW9uIHx8CiAgICAiIgogICkudHJpbSgpOwp9CgpmdW5jdGlvbiB1bndyYXBNc2cobSkgewogIGlmICghbSkgcmV0dXJuIG51bGw7CiAgaWYgKG0uZXBoZW1lcmFsTWVzc2FnZT8ubWVzc2FnZSkgcmV0dXJuIHVud3JhcE1zZyhtLmVwaGVtZXJhbE1lc3NhZ2UubWVzc2FnZSk7CiAgaWYgKG0udmlld09uY2VNZXNzYWdlPy5tZXNzYWdlKSByZXR1cm4gdW53cmFwTXNnKG0udmlld09uY2VNZXNzYWdlLm1lc3NhZ2UpOwogIGlmIChtLnZpZXdPbmNlTWVzc2FnZVYyPy5tZXNzYWdlKSByZXR1cm4gdW53cmFwTXNnKG0udmlld09uY2VNZXNzYWdlVjIubWVzc2FnZSk7CiAgcmV0dXJuIG07Cn0KCmFzeW5jIGZ1bmN0aW9uIHN0YXJ0U29ja2V0KHBob25lRm9yUGFpcikgewogIGNvbnN0IHsgc3RhdGUsIHNhdmVDcmVkcyB9ID0gYXdhaXQgdXNlTXVsdGlGaWxlQXV0aFN0YXRlKEFVVEhfRElSKTsKICBjb25zdCB7IHZlcnNpb24gfSA9IGF3YWl0IGZldGNoTGF0ZXN0QmFpbGV5c1ZlcnNpb24oKS5jYXRjaCgoKSA9PiAoeyB2ZXJzaW9uOiBbMiwgMzAwMCwgMTAyNzkzNDcwMV0gfSkpOwogIGNvbm5TdGF0ZSA9ICJDT05ORUNUSU5HIjsKICBzb2NrID0gbWFrZVdBU29ja2V0KHsKICAgIHZlcnNpb24sCiAgICBhdXRoOiBzdGF0ZSwKICAgIGxvZ2dlcjogcGlubyh7IGxldmVsOiAic2lsZW50IiB9KSwKICAgIGJyb3dzZXI6IFsiQ2hyb21lIChMaW51eCkiLCAiQ2hyb21lIiwgIjEyMi4wLjAiXSwKICAgIHByaW50UVJJblRlcm1pbmFsOiBmYWxzZQogIH0pOwoKICBzb2NrLmV2Lm9uKCJjcmVkcy51cGRhdGUiLCBzYXZlQ3JlZHMpOwoKICBzb2NrLmV2Lm9uKCJjb25uZWN0aW9uLnVwZGF0ZSIsIGFzeW5jICh1KSA9PiB7CiAgICBjb25zdCB7IGNvbm5lY3Rpb24sIGxhc3REaXNjb25uZWN0IH0gPSB1OwogICAgaWYgKGNvbm5lY3Rpb24gPT09ICJvcGVuIikgewogICAgICBjb25uU3RhdGUgPSAiQ09OTkVDVEVEIjsKICAgICAgcGFpcmVkUGhvbmUgPSBzb2NrLnVzZXI/LmlkPy5zcGxpdCgiOiIpWzBdIHx8IHBhaXJlZFBob25lOwogICAgICBhZGRMb2coYFRlcmh1YnVuZyBrZSBXaGF0c0FwcCAoJHtwYWlyZWRQaG9uZX0pYCk7CiAgICB9IGVsc2UgaWYgKGNvbm5lY3Rpb24gPT09ICJjbG9zZSIpIHsKICAgICAgY29uc3QgY29kZSA9IGxhc3REaXNjb25uZWN0Py5lcnJvcj8ub3V0cHV0Py5zdGF0dXNDb2RlOwogICAgICBjb25uU3RhdGUgPSAiRElTQ09OTkVDVEVEIjsKICAgICAgYWRkTG9nKGBLb25la3NpIHRlcnB1dHVzIChjb2RlICR7Y29kZSB8fCAiPyJ9KWApOwogICAgICBpZiAoY29kZSAhPT0gRGlzY29ubmVjdFJlYXNvbi5sb2dnZWRPdXQpIHsKICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHN0YXJ0U29ja2V0KG51bGwpLCAzNTAwKTsKICAgICAgfQogICAgfQogIH0pOwoKICBzb2NrLmV2Lm9uKCJtZXNzYWdlcy51cHNlcnQiLCBhc3luYyAoeyBtZXNzYWdlcywgdHlwZSB9KSA9PiB7CiAgICBpZiAodHlwZSAhPT0gIm5vdGlmeSIpIHJldHVybjsKICAgIGZvciAoY29uc3QgcmF3TXNnIG9mIG1lc3NhZ2VzKSB7CiAgICAgIHRyeSB7CiAgICAgICAgaWYgKCFyYXdNc2cubWVzc2FnZSB8fCByYXdNc2cua2V5LmZyb21NZSkgY29udGludWU7CiAgICAgICAgY29uc3QgamlkID0gcmF3TXNnLmtleS5yZW1vdGVKaWQ7CiAgICAgICAgY29uc3Qgc2VuZGVyID0gcmF3TXNnLmtleS5wYXJ0aWNpcGFudCB8fCBqaWQ7CiAgICAgICAgY29uc3Qga2V5ID0gYCR7amlkfXwke3NlbmRlcn1gOwogICAgICAgIGNvbnN0IG0gPSB1bndyYXBNc2cocmF3TXNnLm1lc3NhZ2UpOwogICAgICAgIGlmICghbSkgY29udGludWU7CgogICAgICAgIGNvbnN0IHR4dCA9IGdldFRleHRGcm9tTXNnKG0pOwogICAgICAgIGNvbnN0IGNtZCA9IHR4dC50b0xvd2VyQ2FzZSgpOwogICAgICAgIGNvbnN0IGlzRGlyZWN0VmlkZW9BdWRpb0NtZCA9IGNtZC5zdGFydHNXaXRoKCIucyAtYXVkaW8iKSB8fCBjbWQuc3RhcnRzV2l0aCgiL3MgLWF1ZGlvIikgfHwgY21kLnN0YXJ0c1dpdGgoIiFzb20iKTsKICAgICAgICBjb25zdCBpc1N0Y0F1ZGlvQ21kID0gY21kLnN0YXJ0c1dpdGgoIi9zdGNhdWRpbyIpIHx8IGNtZC5zdGFydHNXaXRoKCIuc3RjYXVkaW8iKTsKICAgICAgICBjb25zdCBpc0NtZCA9IGlzRGlyZWN0VmlkZW9BdWRpb0NtZCB8fCBpc1N0Y0F1ZGlvQ21kOwoKICAgICAgICBjb25zdCBxdW90ZWQgPSBtLmV4dGVuZGVkVGV4dE1lc3NhZ2U/LmNvbnRleHRJbmZvPy5xdW90ZWRNZXNzYWdlCiAgICAgICAgICA/IHVud3JhcE1zZyhtLmV4dGVuZGVkVGV4dE1lc3NhZ2UuY29udGV4dEluZm8ucXVvdGVkTWVzc2FnZSkKICAgICAgICAgIDogbnVsbDsKCiAgICAgICAgLy8gRmxvdyAyIGNvbXBsZXRpb246IGluY29taW5nIEF1ZGlvL1ZOIG1hdGNoZXMgcGVuZGluZyAvc3RjYXVkaW8gbWVkaWEKICAgICAgICBpZiAobS5hdWRpb01lc3NhZ2UpIHsKICAgICAgICAgIGNvbnN0IGF1ZEJ1ZiA9IGF3YWl0IGRvd25sb2FkTWVkaWFNZXNzYWdlKHJhd01zZywgImJ1ZmZlciIsIHt9KTsKICAgICAgICAgIGNvbnN0IHBlbmRNZWRpYSA9IHBlbmRpbmdNZWRpYUJ5S2V5LmdldChrZXkpOwogICAgICAgICAgaWYgKHBlbmRNZWRpYSAmJiBEYXRlLm5vdygpIC0gcGVuZE1lZGlhLnRzIDwgMTIwMDAwKSB7CiAgICAgICAgICAgIHBlbmRpbmdNZWRpYUJ5S2V5LmRlbGV0ZShrZXkpOwogICAgICAgICAgICBhZGRMb2coYE1lbXByb3NlcyBGbG93IDIgKE1lZGlhIC0+IEF1ZGlvKSB1bnR1ayAke3NlbmRlcn1gKTsKICAgICAgICAgICAgYXdhaXQgc2VuZE5hdGl2ZVNvdW5kU3RpY2tlcihqaWQsIHJhd01zZywgcGVuZE1lZGlhLmJ1ZiwgcGVuZE1lZGlhLmlzVmlkZW8sIGF1ZEJ1Zik7CiAgICAgICAgICB9IGVsc2UgewogICAgICAgICAgICBwZW5kaW5nQXVkaW9CeUtleS5zZXQoa2V5LCB7IGJ1ZjogYXVkQnVmLCB0czogRGF0ZS5ub3coKSB9KTsKICAgICAgICAgICAgYWRkTG9nKGBBdWRpbyBkaXNpbXBhbiAoJHtzZW5kZXJ9KSwgbWVudW5nZ3UgL3N0Y2F1ZGlvICsgZ2FtYmFyL3ZpZGVvLi4uYCk7CiAgICAgICAgICB9CiAgICAgICAgICBjb250aW51ZTsKICAgICAgICB9CgogICAgICAgIGlmICghaXNDbWQpIGNvbnRpbnVlOwoKICAgICAgICBjb25zdCBoYXNEaXJlY3RNZWRpYSA9ICEhKG0uaW1hZ2VNZXNzYWdlIHx8IG0udmlkZW9NZXNzYWdlKTsKICAgICAgICBjb25zdCBoYXNRdW90ZWRNZWRpYSA9ICEhKHF1b3RlZCAmJiAocXVvdGVkLmltYWdlTWVzc2FnZSB8fCBxdW90ZWQudmlkZW9NZXNzYWdlKSk7CiAgICAgICAgY29uc3QgaGFzUXVvdGVkQXVkaW8gPSAhIShxdW90ZWQgJiYgcXVvdGVkLmF1ZGlvTWVzc2FnZSk7CgogICAgICAgIGlmIChoYXNEaXJlY3RNZWRpYSkgewogICAgICAgICAgY29uc3QgaXNWaWRlbyA9ICEhbS52aWRlb01lc3NhZ2U7CiAgICAgICAgICBjb25zdCBtZWRpYUJ1ZiA9IGF3YWl0IGRvd25sb2FkTWVkaWFNZXNzYWdlKHJhd01zZywgImJ1ZmZlciIsIHt9KTsKICAgICAgICAgIGNvbnN0IHBlbmRBdWQgPSBwZW5kaW5nQXVkaW9CeUtleS5nZXQoa2V5KTsKICAgICAgICAgIGlmIChwZW5kQXVkICYmIERhdGUubm93KCkgLSBwZW5kQXVkLnRzIDwgMTIwMDAwKSB7CiAgICAgICAgICAgIHBlbmRpbmdBdWRpb0J5S2V5LmRlbGV0ZShrZXkpOwogICAgICAgICAgICBhd2FpdCBzZW5kTmF0aXZlU291bmRTdGlja2VyKGppZCwgcmF3TXNnLCBtZWRpYUJ1ZiwgaXNWaWRlbywgcGVuZEF1ZC5idWYpOwogICAgICAgICAgfSBlbHNlIGlmIChpc0RpcmVjdFZpZGVvQXVkaW9DbWQgJiYgaXNWaWRlbykgewogICAgICAgICAgICBhd2FpdCBzZW5kTmF0aXZlU291bmRTdGlja2VyKGppZCwgcmF3TXNnLCBtZWRpYUJ1ZiwgdHJ1ZSwgbnVsbCk7CiAgICAgICAgICB9IGVsc2UgewogICAgICAgICAgICBwZW5kaW5nTWVkaWFCeUtleS5zZXQoa2V5LCB7IGJ1ZjogbWVkaWFCdWYsIGlzVmlkZW8sIHRzOiBEYXRlLm5vdygpIH0pOwogICAgICAgICAgICBhd2FpdCBzb2NrLnNlbmRNZXNzYWdlKGppZCwgeyB0ZXh0OiAi8J+OtSBLaXJpbSAqQXVkaW8gLyBWb2ljZSBOb3RlKiAobWFrcyAxMCBkZXRpaykgZGFsYW0gMiBtZW5pdCB1bnR1ayBkaWdhYnVuZyBrZSBzdGlrZXIsIGF0YXUga2V0aWsgYC5zIC1hdWRpb2AgcGFkYSB2aWRlbyB1bnR1ayBwYWthaSBzdWFyYSBhc2xpIHZpZGVvLiIgfSwgeyBxdW90ZWQ6IHJhd01zZyB9KTsKICAgICAgICAgIH0KICAgICAgICB9IGVsc2UgaWYgKGhhc1F1b3RlZE1lZGlhKSB7CiAgICAgICAgICBjb25zdCBpc1ZpZGVvID0gISFxdW90ZWQudmlkZW9NZXNzYWdlOwogICAgICAgICAgY29uc3QgZmFrZU1zZyA9IHsga2V5OiByYXdNc2cua2V5LCBtZXNzYWdlOiBxdW90ZWQgfTsKICAgICAgICAgIGNvbnN0IG1lZGlhQnVmID0gYXdhaXQgZG93bmxvYWRNZWRpYU1lc3NhZ2UoZmFrZU1zZywgImJ1ZmZlciIsIHt9KTsKICAgICAgICAgIGNvbnN0IHBlbmRBdWQgPSBwZW5kaW5nQXVkaW9CeUtleS5nZXQoa2V5KTsKICAgICAgICAgIGlmIChwZW5kQXVkICYmIERhdGUubm93KCkgLSBwZW5kQXVkLnRzIDwgMTIwMDAwKSB7CiAgICAgICAgICAgIHBlbmRpbmdBdWRpb0J5S2V5LmRlbGV0ZShrZXkpOwogICAgICAgICAgICBhd2FpdCBzZW5kTmF0aXZlU291bmRTdGlja2VyKGppZCwgcmF3TXNnLCBtZWRpYUJ1ZiwgaXNWaWRlbywgcGVuZEF1ZC5idWYpOwogICAgICAgICAgfSBlbHNlIGlmIChpc0RpcmVjdFZpZGVvQXVkaW9DbWQgJiYgaXNWaWRlbykgewogICAgICAgICAgICBhd2FpdCBzZW5kTmF0aXZlU291bmRTdGlja2VyKGppZCwgcmF3TXNnLCBtZWRpYUJ1ZiwgdHJ1ZSwgbnVsbCk7CiAgICAgICAgICB9IGVsc2UgewogICAgICAgICAgICBwZW5kaW5nTWVkaWFCeUtleS5zZXQoa2V5LCB7IGJ1ZjogbWVkaWFCdWYsIGlzVmlkZW8sIHRzOiBEYXRlLm5vdygpIH0pOwogICAgICAgICAgICBhd2FpdCBzb2NrLnNlbmRNZXNzYWdlKGppZCwgeyB0ZXh0OiAi8J+OtSBNZWRpYSBkaS1yZXBseSBkaXRlcmltYSEgU2VrYXJhbmcga2lyaW0gKkF1ZGlvIC8gVm9pY2UgTm90ZSogKG1ha3MgMTAgZGV0aWspLiIgfSwgeyBxdW90ZWQ6IHJhd01zZyB9KTsKICAgICAgICAgIH0KICAgICAgICB9IGVsc2UgaWYgKGhhc1F1b3RlZEF1ZGlvKSB7CiAgICAgICAgICBjb25zdCBmYWtlTXNnID0geyBrZXk6IHJhd01zZy5rZXksIG1lc3NhZ2U6IHF1b3RlZCB9OwogICAgICAgICAgY29uc3QgYXVkQnVmID0gYXdhaXQgZG93bmxvYWRNZWRpYU1lc3NhZ2UoZmFrZU1zZywgImJ1ZmZlciIsIHt9KTsKICAgICAgICAgIHBlbmRpbmdBdWRpb0J5S2V5LnNldChrZXksIHsgYnVmOiBhdWRCdWYsIHRzOiBEYXRlLm5vdygpIH0pOwogICAgICAgICAgYXdhaXQgc29jay5zZW5kTWVzc2FnZShqaWQsIHsgdGV4dDogIvCfjqwgQXVkaW8gdGVyc2ltcGFuISBTZWthcmFuZyBraXJpbSAqVmlkZW8gLyBHYW1iYXIqIChtYWtzIDEwIGRldGlrKSBkZW5nYW4gY2FwdGlvbiBgL3N0Y2F1ZGlvYCBhdGF1IGAucyAtYXVkaW9gLiIgfSwgeyBxdW90ZWQ6IHJhd01zZyB9KTsKICAgICAgICB9IGVsc2UgewogICAgICAgICAgYXdhaXQgc29jay5zZW5kTWVzc2FnZShqaWQsIHsgdGV4dDogIvCfk4wgQ2FyYSBwYWthaSBTdGlrZXIgQmVyc3VhcmE6XG7igKIgKlZpZGVvIGxhbmdzdW5nOioga2lyaW0vcmVwbHkgdmlkZW8gZGVuZ2FuIGAucyAtYXVkaW9gXG7igKIgKjItQXJhaCAoYC9zdGNhdWRpb2ApOioga2lyaW0gQXVkaW8vVk4gbGFsdSBWaWRlby9HYW1iYXIgKyBgL3N0Y2F1ZGlvYCAoYXRhdSBzZWJhbGlrbnlhLCBtYWtzIDEwIGRldGlrKS4iIH0sIHsgcXVvdGVkOiByYXdNc2cgfSk7CiAgICAgICAgfQogICAgICB9IGNhdGNoIChlKSB7CiAgICAgICAgYWRkTG9nKGBFcnJvciBwcm9zZXMgcGVzYW46ICR7ZS5tZXNzYWdlfWApOwogICAgICB9CiAgICB9CiAgfSk7CgogIGlmIChwaG9uZUZvclBhaXIgJiYgIXN0YXRlLmNyZWRzLnJlZ2lzdGVyZWQpIHsKICAgIGF3YWl0IG5ldyBQcm9taXNlKChyKSA9PiBzZXRUaW1lb3V0KHIsIDIyMDApKTsKICAgIGNvbnN0IGNvZGUgPSBhd2FpdCBzb2NrLnJlcXVlc3RQYWlyaW5nQ29kZShwaG9uZUZvclBhaXIpOwogICAgbGFzdFBhaXJDb2RlID0gY29kZTsKICAgIHBhaXJlZFBob25lID0gcGhvbmVGb3JQYWlyOwogICAgYWRkTG9nKGBQYWlyaW5nIENvZGUgWyR7cGhvbmVGb3JQYWlyfV06ICR7Y29kZX1gKTsKICAgIHJldHVybiBjb2RlOwogIH0KICByZXR1cm4gc3RhdGUuY3JlZHMucmVnaXN0ZXJlZCA/ICJTVURBSC1URVJUQVVUIiA6ICIiOwp9CgpodHRwLmNyZWF0ZVNlcnZlcihhc3luYyAocmVxLCByZXMpID0+IHsKICByZXMuc2V0SGVhZGVyKCJDb250ZW50LVR5cGUiLCAiYXBwbGljYXRpb24vanNvbiIpOwogIGNvbnN0IHUgPSBuZXcgVVJMKHJlcS51cmwsIGBodHRwOi8vMTI3LjAuMC4xOiR7UE9SVH1gKTsKICBpZiAodS5wYXRobmFtZSA9PT0gIi9zdGF0dXMiKSB7CiAgICByZXR1cm4gcmVzLmVuZChKU09OLnN0cmluZ2lmeSh7IG9rOiB0cnVlLCBlbmdpbmU6ICJzdGNhdWRpby1iYWlsZXlzIiwgc3RhdGU6IGNvbm5TdGF0ZSwgcGhvbmU6IHBhaXJlZFBob25lLCBwYWlyQ29kZTogbGFzdFBhaXJDb2RlLCBsb2dzIH0pKTsKICB9CiAgaWYgKHUucGF0aG5hbWUgPT09ICIvcGFpciIpIHsKICAgIGNvbnN0IHBob25lID0gKHUuc2VhcmNoUGFyYW1zLmdldCgicGhvbmUiKSB8fCAiIikucmVwbGFjZSgvW14wLTldL2csICIiKTsKICAgIGlmIChwaG9uZS5sZW5ndGggPCA5KSByZXR1cm4gcmVzLmVuZChKU09OLnN0cmluZ2lmeSh7IG9rOiBmYWxzZSwgZXJyb3I6ICJOb21vciBXQSB0aWRhayB2YWxpZCIgfSkpOwogICAgdHJ5IHsKICAgICAgY29uc3QgY29kZSA9IGF3YWl0IHN0YXJ0U29ja2V0KHBob25lKTsKICAgICAgcmV0dXJuIHJlcy5lbmQoSlNPTi5zdHJpbmdpZnkoeyBvazogdHJ1ZSwgcGFpcmluZ0NvZGU6IGNvZGUgfSkpOwogICAgfSBjYXRjaCAoZSkgewogICAgICByZXR1cm4gcmVzLmVuZChKU09OLnN0cmluZ2lmeSh7IG9rOiBmYWxzZSwgZXJyb3I6IGUubWVzc2FnZSB9KSk7CiAgICB9CiAgfQogIGlmICh1LnBhdGhuYW1lID09PSAiL3N0b3AiKSB7CiAgICB0cnkgeyBzb2NrPy5lbmQoKTsgfSBjYXRjaCAoXykge30KICAgIGNvbm5TdGF0ZSA9ICJTVE9QUEVEIjsKICAgIHJlcy5lbmQoSlNPTi5zdHJpbmdpZnkoeyBvazogdHJ1ZSB9KSk7CiAgICBzZXRUaW1lb3V0KCgpID0+IHByb2Nlc3MuZXhpdCgwKSwgMzAwKTsKICAgIHJldHVybjsKICB9CiAgcmVzLmVuZChKU09OLnN0cmluZ2lmeSh7IG9rOiB0cnVlLCBpbmZvOiAiRG9kb3NCb3QgU3RjQXVkaW8gQmFpbGV5cyBFbmdpbmUiIH0pKTsKfSkubGlzdGVuKFBPUlQsICIwLjAuMC4wIiwgKCkgPT4gewogIGFkZExvZyhgRW5naW5lIFN0Y0F1ZGlvIEJhaWxleXMgYWt0aWYgZGkgcG9ydCAke1BPUlR9YCk7CiAgaWYgKGZzLmV4aXN0c1N5bmMocGF0aC5qb2luKEFVVEhfRElSLCAiY3JlZHMuanNvbiIpKSkgewogICAgc3RhcnRTb2NrZXQobnVsbCkuY2F0Y2goKGUpID0+IGFkZExvZyhgQXV0by1zdGFydCBnYWdhbDogJHtlLm1lc3NhZ2V9YCkpOwogIH0KfSk7Cg=="

    fun getStcAudioBaseUrl(prefs: BotPrefsManager): String {
        return if (prefs.stcAudioMode == "VPS") {
            val host = extractHostFromUrl(prefs.stcAudioVpsHost.ifBlank { prefs.vpsUrl })
            if (host.isBlank()) "http://127.0.0.1:8766" else "http://$host:8766"
        } else {
            "http://127.0.0.1:8766"
        }
    }

    fun getStcAudioTermuxCommand(): String {
        return "pkg update -y && pkg install -y nodejs ffmpeg && mkdir -p ~/dodos-stcaudio && cd ~/dodos-stcaudio && echo '{\"name\":\"dodos-stcaudio\",\"version\":\"1.0.0\",\"dependencies\":{\"@whiskeysockets/baileys\":\"latest\",\"pino\":\"latest\"}}' > package.json && npm install --no-audit --no-fund && echo '$STCAUDIO_ENGINE_B64' | base64 -d > stcaudio_engine.js && node stcaudio_engine.js"
    }

    suspend fun getStcAudioStatus(prefs: BotPrefsManager): JSONObject? = withContext(Dispatchers.IO) {
        val url = getStcAudioBaseUrl(prefs)
        try {
            val req = Request.Builder().url("$url/status").get().build()
            httpClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                if (resp.isSuccessful && body.isNotEmpty()) return@withContext JSONObject(body)
            }
        } catch (_: Exception) {}
        null
    }

    suspend fun requestStcAudioPair(prefs: BotPrefsManager, rawPhone: String): String = withContext(Dispatchers.IO) {
        val url = getStcAudioBaseUrl(prefs)
        val clean = normalizePhone(rawPhone)
        try {
            val req = Request.Builder().url("$url/pair?phone=$clean").get().build()
            httpClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                if (body.isNotEmpty()) {
                    val j = JSONObject(body)
                    if (j.optBoolean("ok", false)) return@withContext j.optString("pairingCode", "OK")
                    return@withContext "GAGAL: ${j.optString("error", "Error")}"
                }
            }
        } catch (e: Exception) {
            return@withContext "ERROR: ${e.message}"
        }
        "GAGAL: Engine StcAudio belum aktif"
    }

    suspend fun stopStcAudio(prefs: BotPrefsManager): Boolean = withContext(Dispatchers.IO) {
        val url = getStcAudioBaseUrl(prefs)
        try {
            val req = Request.Builder().url("$url/stop").get().build()
            httpClient.newCall(req).execute().use { it.isSuccessful }
        } catch (_: Exception) { false }
    }

    suspend fun deployStcAudioVps(host: String, sshPort: Int, user: String, pass: String): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val cmd = "mkdir -p /root/dodos-stcaudio && cd /root/dodos-stcaudio && " +
            "(command -v node >/dev/null 2>&1 || (curl -fsSL https://deb.nodesource.com/setup_20.x | bash - && apt-get install -y nodejs)) && " +
            "(command -v ffmpeg >/dev/null 2>&1 || apt-get install -y ffmpeg) && " +
            "echo '{\"name\":\"dodos-stcaudio\",\"version\":\"1.0.0\",\"dependencies\":{\"@whiskeysockets/baileys\":\"latest\",\"pino\":\"latest\"}}' > package.json && " +
            "npm install --no-audit --no-fund && " +
            "echo '$STCAUDIO_ENGINE_B64' | base64 -d > stcaudio_engine.js && " +
            "pkill -f stcaudio_engine.js || true; nohup node stcaudio_engine.js > stcaudio.log 2>&1 &"
        val payload = JSONObject().apply {
            put("mode", "VPS")
            put("command", cmd)
            put("host", extractHostFromUrl(host))
            put("sshPort", sshPort)
            put("user", user)
            put("pass", pass)
        }
        try {
            val req = Request.Builder()
                .url("http://127.0.0.1:8765/terminal/exec")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()
            httpClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                val j = JSONObject(body)
                val out = j.optString("output", "")
                val ok = resp.isSuccessful && !out.lowercase().contains("error:")
                return@withContext ok to out.ifEmpty { "Perintah deploy dikirim ke VPS!" }
            }
        } catch (e: Exception) {
            return@withContext false to (e.message ?: "Gagal SSH ke VPS")
        }
    }

    suspend fun execTerminalCommand(context: Context, command: String): String = withContext(Dispatchers.IO) {
        val prefs = BotPrefsManager(context)
        val payload = JSONObject().apply {
            put("mode", prefs.connectionMode)
            put("command", command)
            put("host", extractHostFromUrl(prefs.vpsUrl))
            put("sshPort", prefs.vpsSshPort)
            put("user", prefs.vpsUser)
            put("pass", prefs.vpsSecret)
        }
        try {
            val req = Request.Builder()
                .url("http://127.0.0.1:8765/terminal/exec")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()
            httpClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                if (body.isNotEmpty()) {
                    val json = JSONObject(body)
                    return@withContext json.optString("output", "")
                }
            }
        } catch (e: Exception) {
            return@withContext "Error: ${e.message}"
        }
        ""
    }

    suspend fun exportBackupJson(context: Context): String? = withContext(Dispatchers.IO) {
        val prefs = BotPrefsManager(context)
        val baseUrl = getBaseUrl(prefs)
        try {
            val req = Request.Builder().url("$baseUrl/backup/export").get().build()
            httpClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                if (resp.isSuccessful && body.isNotEmpty()) {
                    return@withContext body
                }
            }
        } catch (_: Exception) {}
        null
    }

    suspend fun importBackupJson(context: Context, rawJson: String): Boolean = withContext(Dispatchers.IO) {
        val prefs = BotPrefsManager(context)
        val baseUrl = getBaseUrl(prefs)
        try {
            val root = JSONObject(rawJson)
            val cfg = root.optJSONObject("config")
            if (cfg != null) {
                if (cfg.optString("apiKey").isNotEmpty()) prefs.geminiApiKey = cfg.optString("apiKey")
                if (cfg.optString("model").isNotEmpty()) prefs.geminiModel = cfg.optString("model")
                if (cfg.optString("botName").isNotEmpty()) prefs.botName = cfg.optString("botName")
                if (cfg.optString("systemPrompt").isNotEmpty()) prefs.systemPrompt = cfg.optString("systemPrompt")
                if (cfg.optString("replyScope").isNotEmpty()) prefs.replyScope = cfg.optString("replyScope")
                if (cfg.optString("groupTrigger").isNotEmpty()) prefs.groupTrigger = cfg.optString("groupTrigger")
                prefs.blacklistNumbers = cfg.optString("blacklistNumbers", "")
                prefs.autoWelcome = cfg.optBoolean("autoWelcome", true)
                prefs.antiLink = cfg.optBoolean("antiLink", true)
                prefs.antiSpam = cfg.optBoolean("antiSpam", true)
            }
            val req = Request.Builder()
                .url("$baseUrl/backup/import")
                .post(rawJson.toRequestBody(jsonMediaType))
                .build()
            httpClient.newCall(req).execute().use { resp ->
                return@withContext resp.isSuccessful
            }
        } catch (_: Exception) {
            false
        }
    }

    suspend fun mcServerAction(
        context: Context,
        action: String,
        command: String = "",
        serverName: String = "",
        maxPlayers: String = "20",
        gamemode: String = "survival"
    ): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val prefs = BotPrefsManager(context)
        if (prefs.connectionMode != "VPS") {
            return@withContext false to "Mode Server Minecraft hanya tersedia di Mode VPS!"
        }
        val payload = JSONObject().apply {
            put("host", extractHostFromUrl(prefs.vpsUrl))
            put("sshPort", prefs.vpsSshPort)
            put("user", prefs.vpsUser)
            put("pass", prefs.vpsSecret)
            put("action", action)
            put("command", command)
            put("serverName", serverName)
            put("maxPlayers", maxPlayers)
            put("gamemode", gamemode)
        }
        val mcClient = OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
        try {
            val req = Request.Builder()
                .url("http://127.0.0.1:8765/mc/action")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()
            mcClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                if (body.isNotEmpty()) {
                    val json = JSONObject(body)
                    return@withContext json.optBoolean("ok", false) to json.optString("output", json.optString("error", ""))
                }
            }
        } catch (e: Exception) {
            return@withContext false to "Error: ${e.message}"
        }
        false to "Tidak ada respons server"
    }

    suspend fun checkLatestGithubRelease(repo: String): Triple<String, String, String>? = withContext(Dispatchers.IO) {
        val cleanRepo = repo.trim().removePrefix("https://github.com/").trim('/')
        if (!cleanRepo.contains("/")) return@withContext null
        try {
            val req = Request.Builder()
                .url("https://api.github.com/repos/$cleanRepo/releases/latest")
                .addHeader("Accept", "application/vnd.github+json")
                .get()
                .build()
            httpClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                if (!resp.isSuccessful || body.isEmpty()) return@withContext null
                val json = JSONObject(body)
                val tag = json.optString("tag_name", "")
                val notes = json.optString("body", "Pembaruan versi terbaru tersedia.")
                val assets = json.optJSONArray("assets")
                var apkUrl = ""
                if (assets != null) {
                    for (i in 0 until assets.length()) {
                        val a = assets.optJSONObject(i) ?: continue
                        val u = a.optString("browser_download_url", "")
                        if (u.endsWith(".apk", ignoreCase = true)) {
                            apkUrl = u
                            break
                        }
                    }
                }
                if (tag.isNotEmpty() && apkUrl.isNotEmpty()) {
                    return@withContext Triple(tag, apkUrl, notes)
                }
            }
        } catch (_: Exception) {}
        null
    }

    suspend fun switchMascotToRina(context: Context): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val prefs = BotPrefsManager(context)
        val baseUrl = getBaseUrl(prefs)
        try {
            if (prefs.connectionMode == "VPS" && prefs.vpsSecret.isNotEmpty()) {
                val h = extractHostFromUrl(prefs.vpsUrl)
                if (h.isNotEmpty()) {
                    connectAndSetupVpsFromApk(context, h, prefs.vpsSshPort, prefs.vpsUser, prefs.vpsSecret, true)
                }
            }
            val req = Request.Builder()
                .url("$baseUrl/reset-banner-cache")
                .post("{}".toRequestBody(jsonMediaType))
                .build()
            httpClient.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    return@withContext true to "Maskot WhatsApp diubah ke Rina! Ketik .menu di WA."
                }
            }
        } catch (e: Exception) {
            return@withContext false to "Gagal reset banner: ${e.message}"
        }
        false to "Mesin bot belum merespons. Coba restart bot terlebih dahulu."
    }

    suspend fun resetMemory(context: Context): Boolean = withContext(Dispatchers.IO) {
        val prefs = BotPrefsManager(context)
        val baseUrl = getBaseUrl(prefs)
        fallbackMemory.clear()
        try {
            val req = Request.Builder()
                .url("$baseUrl/reset-memory")
                .post("{}".toRequestBody(jsonMediaType))
                .build()
            httpClient.newCall(req).execute().use { resp ->
                return@withContext resp.isSuccessful
            }
        } catch (_: Exception) {
            false
        }
    }

    suspend fun fetchStatus(context: Context): EngineLiveStatus? = withContext(Dispatchers.IO) {
        val prefs = BotPrefsManager(context)
        val baseUrl = getBaseUrl(prefs)
        try {
            val req = Request.Builder().url("$baseUrl/status").get().build()
            httpClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                if (resp.isSuccessful && body.isNotEmpty()) {
                    val json = JSONObject(body)
                    val ver = json.optString("engineVersion", "")
                    if (prefs.connectionMode == "VPS" && ver != "8.0" && prefs.vpsSecret.isNotEmpty()) {
                        val h = extractHostFromUrl(prefs.vpsUrl)
                        if (h.isNotEmpty() && autoUpgradedVpsHost != h) {
                            autoUpgradedVpsHost = h
                            log("Mendeteksi mesin VPS versi lama ($ver), meng-upgrade otomatis ke v9.3...")
                            connectAndSetupVpsFromApk(context, h, prefs.vpsSshPort, prefs.vpsUser, prefs.vpsSecret, true)
                        }
                    }
                    val logsArr = json.optJSONArray("logs")
                    if (logsArr != null && logsArr.length() > 0) {
                        val latestList = mutableListOf<String>()
                        val startIdx = (logsArr.length() - 20).coerceAtLeast(0)
                        for (i in startIdx until logsArr.length()) {
                            latestList.add(logsArr.optString(i))
                        }
                        appLogs.clear()
                        appLogs.addAll(latestList)
                    }
                    val parsedSessions = mutableListOf<PairedSessionItem>()
                    val sessArr = json.optJSONArray("sessions")
                    if (sessArr != null) {
                        for (i in 0 until sessArr.length()) {
                            val obj = sessArr.optJSONObject(i) ?: continue
                            parsedSessions.add(
                                PairedSessionItem(
                                    id = obj.optString("id", ""),
                                    phone = obj.optString("phone", ""),
                                    jid = obj.optString("jid", ""),
                                    active = obj.optBoolean("active", true),
                                    loggedIn = obj.optBoolean("loggedIn", false),
                                    connected = obj.optBoolean("connected", false),
                                    state = obj.optString("state", "")
                                )
                            )
                        }
                    }
                    return@withContext EngineLiveStatus(
                        loggedIn = json.optBoolean("loggedIn", false),
                        totalReplied = json.optInt("totalReplied", 0),
                        activeGroups = json.optInt("activeGroups", 0),
                        state = json.optString("state", "READY"),
                        sessions = parsedSessions
                    )
                }
            }
        } catch (_: Exception) {
        }
        null
    }

    suspend fun callGeminiDirect(
        prefs: BotPrefsManager,
        senderJid: String,
        userMessage: String
    ): String? = withContext(Dispatchers.IO) {
        val apiKey = prefs.geminiApiKey.trim()
        if (apiKey.isEmpty()) {
            log("Gagal membalas: API Key Gemini belum diisi!")
            return@withContext null
        }
        val rawPref = prefs.geminiModel.ifEmpty { "gemini-3.8-flash" }
        val modelsToTry = listOf(rawPref, "gemini-3.8-flash", "gemini-3.5-flash", "gemini-3.5-flash-lite", "gemini-2.5-flash", "gemini-2.5-flash-lite").distinct()
        val history = fallbackMemory.getOrPut(senderJid) { mutableListOf() }

        val contentsArray = JSONArray()
        synchronized(history) {
            for ((role, text) in history) {
                val part = JSONObject().put("text", text)
                val parts = JSONArray().put(part)
                contentsArray.put(JSONObject().put("role", role).put("parts", parts))
            }
        }
        val userPart = JSONObject().put("text", userMessage)
        contentsArray.put(
            JSONObject()
                .put("role", "user")
                .put("parts", JSONArray().put(userPart))
        )

        val requestJson = JSONObject().apply {
            put("contents", contentsArray)
            if (prefs.systemPrompt.isNotBlank()) {
                put(
                    "systemInstruction",
                    JSONObject()
                        .put("role", "system")
                        .put("parts", JSONArray().put(JSONObject().put("text", prefs.systemPrompt)))
                )
            }
        }

        for (model in modelsToTry) {
            val endpoints = if (apiKey.startsWith("AQ.", ignoreCase = true)) {
                listOf(
                    "https://aiplatform.googleapis.com/v1/publishers/google/models/$model:generateContent?key=$apiKey",
                    "https://aiplatform.googleapis.com/v1beta1/publishers/google/models/$model:generateContent?key=$apiKey",
                    "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
                )
            } else {
                listOf(
                    "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey",
                    "https://aiplatform.googleapis.com/v1/publishers/google/models/$model:generateContent?key=$apiKey"
                )
            }
            for (url in endpoints) {
                try {
                    val req = Request.Builder()
                        .url(url)
                        .addHeader("Content-Type", "application/json")
                        .addHeader("x-goog-api-key", apiKey)
                        .post(requestJson.toString().toRequestBody(jsonMediaType))
                        .build()

                    httpClient.newCall(req).execute().use { resp ->
                        val respBody = resp.body?.string() ?: ""
                        if (resp.isSuccessful) {
                            val parsed = JSONObject(respBody)
                            val candidates = parsed.optJSONArray("candidates")
                            if (candidates != null && candidates.length() > 0) {
                                val content = candidates.getJSONObject(0).optJSONObject("content")
                                val parts = content?.optJSONArray("parts")
                                val replyText = parts?.optJSONObject(0)?.optString("text")?.trim()
                                if (!replyText.isNullOrEmpty()) {
                                    synchronized(history) {
                                        history.add("user" to userMessage)
                                        history.add("model" to replyText)
                                        while (history.size > 20) {
                                            history.removeAt(0)
                                        }
                                    }
                                    log("Gemini ($model) membalas: ${replyText.take(60)}...")
                                    return@withContext replyText
                                }
                            }
                        }
                    }
                } catch (_: Exception) {
                }
            }
        }
        null
    }
}
