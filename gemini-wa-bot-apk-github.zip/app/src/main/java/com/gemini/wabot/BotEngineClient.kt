package com.gemini.wabot

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.TimeUnit

data class PairedSessionItem(
    val id: String,
    val phone: String,
    val jid: String,
    val active: Boolean,
    val loggedIn: Boolean,
    val connected: Boolean,
    val state: String
)

data class EngineLiveStatus(
    val loggedIn: Boolean,
    val totalReplied: Int,
    val activeGroups: Int,
    val state: String,
    val sessions: List<PairedSessionItem>
)

object BotEngineClient {

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()
    val appLogs = CopyOnWriteArrayList<String>()
    private val fallbackMemory = mutableMapOf<String, MutableList<Pair<String, String>>>()

    @Volatile private var autoUpgradedVpsHost: String = ""

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(45, TimeUnit.SECONDS)
        .build()

    fun log(msg: String) {
        val ts = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        appLogs.add("[$ts] $msg")
        while (appLogs.size > 120) {
            appLogs.removeAt(0)
        }
    }

    fun formatVpsBaseUrl(raw: String): String {
        val clean = raw.trim().removeSuffix("/")
        if (clean.isEmpty()) return ""
        val withProto = if (clean.startsWith("http://") || clean.startsWith("https://")) {
            clean
        } else {
            "http://$clean"
        }
        val afterProto = withProto.substringAfter("://")
        return if (afterProto.contains(":")) {
            withProto
        } else {
            "$withProto:8765"
        }
    }

    private fun getBaseUrl(prefs: BotPrefsManager): String {
        return if (prefs.connectionMode == "VPS") {
            val formatted = formatVpsBaseUrl(prefs.vpsUrl)
            if (formatted.isEmpty()) "http://127.0.0.1:8765" else formatted
        } else {
            "http://127.0.0.1:8765"
        }
    }

    fun extractHostFromUrl(urlStr: String): String {
        val s = urlStr.trim().removePrefix("http://").removePrefix("https://").substringBefore("/").substringBefore(":")
        return s.trim()
    }

    fun normalizePhone(raw: String): String {
        val digits = raw.filter { it in '0'..'9' }
        return when {
            digits.startsWith("08") -> "62" + digits.substring(1)
            digits.startsWith("8") && digits.length >= 9 -> "62$digits"
            else -> digits
        }
    }

    suspend fun isLocalEngineRunning(): Boolean = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url("http://127.0.0.1:8765/status").get().build()
            httpClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                if (resp.isSuccessful && body.contains("\"engineVersion\":\"5.4\"")) {
                    return@withContext true
                }
                if (resp.isSuccessful) {
                    shutdownLocalEngine()
                    delay(400)
                }
                return@withContext false
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun ensureVpsInstallerExtracted(context: Context): String {
        val prefs = BotPrefsManager(context)
        val apkFile = java.io.File(context.applicationInfo.sourceDir)
        val currentApkTime = if (apkFile.exists()) apkFile.lastModified() else 0L
        val outBin = java.io.File(context.filesDir, "wabot_vps_installer.bin")
        val outGz = java.io.File(context.filesDir, "wabot_vps_amd64.gz")
        if (currentApkTime > 0L && prefs.lastExtractedApkTime == currentApkTime &&
            outGz.exists() && outGz.length() > 100_000L && outBin.exists() && outBin.length() > 100_000L
        ) {
            return outGz.absolutePath
        }
        try {
            java.util.zip.ZipFile(context.applicationInfo.sourceDir).use { apkZip ->
                val entry = apkZip.getEntry("lib/x86_64/libwabot_engine.so")
                    ?: apkZip.getEntry("lib/arm64-v8a/libwabot_vps.so")
                if (entry != null) {
                    apkZip.getInputStream(entry).use { rawIn ->
                        java.util.zip.GZIPOutputStream(outGz.outputStream()).use { gzOut ->
                            rawIn.copyTo(gzOut)
                        }
                    }
                    if (outGz.exists() && outGz.length() > 100_000L) {
                        outGz.copyTo(outBin, overwrite = true)
                        prefs.lastExtractedApkTime = currentApkTime
                        log("Installer VPS Linux amd64 v5.4 diekstrak (${outGz.length() / 1024} KB)")
                        return outGz.absolutePath
                    }
                }
            }
        } catch (e: Exception) {
            log("Info ekstrak APK: ${e.message}")
        }
        return outGz.absolutePath
    }

    suspend fun connectAndSetupVpsFromApk(
        context: Context,
        rawHost: String,
        sshPort: String,
        user: String,
        pass: String,
        forceInstall: Boolean = false
    ): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val cleanHost = extractHostFromUrl(rawHost)
        if (cleanHost.isEmpty()) {
            return@withContext false to "Masukkan Public IP VPS terlebih dahulu!"
        }
        val gzPath = ensureVpsInstallerExtracted(context)
        val payload = JSONObject().apply {
            put("host", cleanHost)
            put("sshPort", sshPort.trim().ifEmpty { "22" })
            put("user", user.trim().ifEmpty { "root" })
            put("pass", pass)
            put("botPort", "8765")
            put("gzPath", gzPath)
            put("forceInstall", forceInstall)
        }
        val setupClient = OkHttpClient.Builder()
            .connectTimeout(25, TimeUnit.SECONDS)
            .readTimeout(90, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .build()
        try {
            val req = Request.Builder()
                .url("http://127.0.0.1:8765/vps/connect")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()
            setupClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                if (body.isNotEmpty()) {
                    val json = JSONObject(body)
                    if (json.optBoolean("ok", false)) {
                        val vpsUrl = json.optString("vpsUrl", "http://$cleanHost:8765")
                        val msg = json.optString("message", "Berhasil terhubung ke VPS $cleanHost!")
                        val prefs = BotPrefsManager(context)
                        prefs.connectionMode = "VPS"
                        prefs.vpsUrl = formatVpsBaseUrl(vpsUrl)
                        prefs.vpsUser = user.trim().ifEmpty { "root" }
                        prefs.vpsSshPort = sshPort.trim().ifEmpty { "22" }
                        prefs.vpsSecret = pass
                        log(msg)
                        return@withContext true to msg
                    } else {
                        val err = json.optString("error", "Gagal menyambungkan ke VPS")
                        log("Gagal Konek VPS: $err")
                        return@withContext false to err
                    }
                }
            }
        } catch (e: Exception) {
            return@withContext false to "Gagal menghubungi modul installer lokal: ${e.message}"
        }
        false to "Tidak ada respons dari modul SSH lokal"
    }

    suspend fun checkOrRestartVpsViaSsh(context: Context, action: String): String = withContext(Dispatchers.IO) {
        val prefs = BotPrefsManager(context)
        val host = extractHostFromUrl(prefs.vpsUrl)
        if (host.isEmpty()) {
            return@withContext "Masukkan IP Public VPS terlebih dahulu!"
        }
        val payload = JSONObject().apply {
            put("host", host)
            put("sshPort", prefs.vpsSshPort.ifEmpty { "22" })
            put("user", prefs.vpsUser.ifEmpty { "root" })
            put("pass", prefs.vpsSecret)
            put("action", action)
        }
        try {
            val req = Request.Builder()
                .url("http://127.0.0.1:8765/vps/ssh-check")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()
            httpClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                if (body.isNotEmpty()) {
                    val json = JSONObject(body)
                    if (json.optBoolean("ok", false)) {
                        val out = json.optString("output", "active")
                        return@withContext "VPS ($host) Status: $out"
                    } else {
                        return@withContext "SSH Gagal: ${json.optString("error")}"
                    }
                }
            }
        } catch (e: Exception) {
            return@withContext "Error SSH: ${e.message}"
        }
        "Tidak dapat memeriksa status VPS"
    }

    suspend fun shutdownLocalEngine(): Boolean = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url("http://127.0.0.1:8765/shutdown")
                .post("{}".toRequestBody(jsonMediaType))
                .build()
            httpClient.newCall(req).execute().use { resp ->
                return@withContext resp.isSuccessful
            }
        } catch (_: Exception) {
            false
        }
    }

    suspend fun syncConfig(context: Context): Boolean = withContext(Dispatchers.IO) {
        val prefs = BotPrefsManager(context)
        val baseUrl = getBaseUrl(prefs)
        val payload = JSONObject().apply {
            put("apiKey", prefs.geminiApiKey)
            put("model", prefs.geminiModel)
            put("systemPrompt", prefs.systemPrompt)
            put("replyScope", prefs.replyScope)
            put("groupTrigger", prefs.groupTrigger)
            put("blacklistNumbers", prefs.blacklistNumbers)
            put("minDelayMs", 1500)
            put("maxDelayMs", 3000)
            put("phoneNumber", normalizePhone(prefs.phoneNumber))
            put("botEnabled", prefs.isBotEnabled)
            put("menuStyle", prefs.menuStyle)
            put("botName", prefs.botName)
            put("autoWelcome", prefs.autoWelcome)
            put("antiLink", prefs.antiLink)
            put("antiSpam", prefs.antiSpam)
        }
        try {
            val reqBuilder = Request.Builder()
                .url("$baseUrl/config")
                .post(payload.toString().toRequestBody(jsonMediaType))
            httpClient.newCall(reqBuilder.build()).execute().use { resp ->
                if (resp.isSuccessful) {
                    log("Konfigurasi disinkronkan ke server ($baseUrl)")
                    return@withContext true
                }
            }
        } catch (e: Exception) {
            log("Info Sinkronisasi: ${e.message}")
        }
        false
    }

    suspend fun requestPairingCode(context: Context, rawPhone: String): String = withContext(Dispatchers.IO) {
        val prefs = BotPrefsManager(context)
        val baseUrl = getBaseUrl(prefs)
        val cleanPhone = normalizePhone(rawPhone)
        try {
            val req = Request.Builder()
                .url("$baseUrl/pair?phone=$cleanPhone")
                .get()
                .build()
            httpClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                if (body.isNotEmpty()) {
                    val json = JSONObject(body)
                    if (json.optBoolean("ok", false)) {
                        val code = json.optString("pairingCode", "")
                        if (code.isNotEmpty()) {
                            log("Kode Pairing diterima untuk $cleanPhone: $code")
                            return@withContext code
                        }
                    } else {
                        val err = json.optString("error", "Gagal meminta kode pairing")
                        log("Gagal Pairing: $err")
                        return@withContext "GAGAL: $err"
                    }
                }
            }
        } catch (e: Exception) {
            return@withContext "ERROR: ${e.message}"
        }
        "GAGAL: Server belum siap"
    }

    suspend fun toggleSessionActive(context: Context, sessionId: String, active: Boolean): Boolean = withContext(Dispatchers.IO) {
        val prefs = BotPrefsManager(context)
        val baseUrl = getBaseUrl(prefs)
        try {
            val req = Request.Builder()
                .url("$baseUrl/session/toggle?id=$sessionId&active=$active")
                .get()
                .build()
            httpClient.newCall(req).execute().use { resp ->
                return@withContext resp.isSuccessful
            }
        } catch (_: Exception) {
            false
        }
    }

    suspend fun deleteSession(context: Context, sessionId: String): Boolean = withContext(Dispatchers.IO) {
        val prefs = BotPrefsManager(context)
        val baseUrl = getBaseUrl(prefs)
        try {
            val req = Request.Builder()
                .url("$baseUrl/session/delete?id=$sessionId")
                .get()
                .build()
            httpClient.newCall(req).execute().use { resp ->
                return@withContext resp.isSuccessful
            }
        } catch (_: Exception) {
            false
        }
    }

    suspend fun fetchJoinedGroups(context: Context): List<Triple<String, String, Int>> = withContext(Dispatchers.IO) {
        val prefs = BotPrefsManager(context)
        val baseUrl = getBaseUrl(prefs)
        val out = mutableListOf<Triple<String, String, Int>>()
        try {
            val req = Request.Builder().url("$baseUrl/groups/list").get().build()
            httpClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                if (resp.isSuccessful && body.isNotEmpty()) {
                    val json = JSONObject(body)
                    val arr = json.optJSONArray("groups")
                    if (arr != null) {
                        for (i in 0 until arr.length()) {
                            val obj = arr.optJSONObject(i) ?: continue
                            out.add(Triple(obj.optString("jid"), obj.optString("name"), obj.optInt("count", 0)))
                        }
                    }
                }
            }
        } catch (_: Exception) {}
        out
    }

    suspend fun sendGroupAnnouncement(
        context: Context,
        groupJids: List<String>,
        message: String,
        hidetag: Boolean,
        hashtags: String
    ): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val prefs = BotPrefsManager(context)
        val baseUrl = getBaseUrl(prefs)
        val payload = JSONObject().apply {
            put("groupJids", JSONArray(groupJids))
            put("message", message)
            put("hidetag", hidetag)
            put("hashtags", hashtags)
        }
        try {
            val req = Request.Builder()
                .url("$baseUrl/groups/announce")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()
            httpClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                val json = JSONObject(body)
                if (json.optBoolean("ok", false)) {
                    val sent = json.optInt("sent", 0)
                    val total = json.optInt("total", groupJids.size)
                    return@withContext true to "Terkirim ke $sent/$total grup!"
                }
                return@withContext false to json.optString("error", "Gagal mengirim pengumuman")
            }
        } catch (e: Exception) {
            return@withContext false to (e.message ?: "Error koneksi")
        }
    }

    suspend fun execTerminalCommand(context: Context, command: String): String = withContext(Dispatchers.IO) {
        val prefs = BotPrefsManager(context)
        val payload = JSONObject().apply {
            put("mode", prefs.connectionMode)
            put("command", command)
            put("host", extractHostFromUrl(prefs.vpsUrl))
            put("sshPort", prefs.vpsSshPort)
            put("user", prefs.vpsUser)
            put("pass", prefs.vpsSecret)
        }
        try {
            val req = Request.Builder()
                .url("http://127.0.0.1:8765/terminal/exec")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()
            httpClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                if (body.isNotEmpty()) {
                    val json = JSONObject(body)
                    return@withContext json.optString("output", "")
                }
            }
        } catch (e: Exception) {
            return@withContext "Error: ${e.message}"
        }
        ""
    }

    suspend fun exportBackupJson(context: Context): String? = withContext(Dispatchers.IO) {
        val prefs = BotPrefsManager(context)
        val baseUrl = getBaseUrl(prefs)
        try {
            val req = Request.Builder().url("$baseUrl/backup/export").get().build()
            httpClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                if (resp.isSuccessful && body.isNotEmpty()) {
                    return@withContext body
                }
            }
        } catch (_: Exception) {}
        null
    }

    suspend fun importBackupJson(context: Context, rawJson: String): Boolean = withContext(Dispatchers.IO) {
        val prefs = BotPrefsManager(context)
        val baseUrl = getBaseUrl(prefs)
        try {
            val root = JSONObject(rawJson)
            val cfg = root.optJSONObject("config")
            if (cfg != null) {
                if (cfg.optString("apiKey").isNotEmpty()) prefs.geminiApiKey = cfg.optString("apiKey")
                if (cfg.optString("model").isNotEmpty()) prefs.geminiModel = cfg.optString("model")
                if (cfg.optString("botName").isNotEmpty()) prefs.botName = cfg.optString("botName")
                if (cfg.optString("systemPrompt").isNotEmpty()) prefs.systemPrompt = cfg.optString("systemPrompt")
                if (cfg.optString("replyScope").isNotEmpty()) prefs.replyScope = cfg.optString("replyScope")
                if (cfg.optString("groupTrigger").isNotEmpty()) prefs.groupTrigger = cfg.optString("groupTrigger")
                prefs.blacklistNumbers = cfg.optString("blacklistNumbers", "")
                prefs.autoWelcome = cfg.optBoolean("autoWelcome", true)
                prefs.antiLink = cfg.optBoolean("antiLink", true)
                prefs.antiSpam = cfg.optBoolean("antiSpam", true)
            }
            val req = Request.Builder()
                .url("$baseUrl/backup/import")
                .post(rawJson.toRequestBody(jsonMediaType))
                .build()
            httpClient.newCall(req).execute().use { resp ->
                return@withContext resp.isSuccessful
            }
        } catch (_: Exception) {
            false
        }
    }

    suspend fun mcServerAction(
        context: Context,
        action: String,
        command: String = "",
        serverName: String = "",
        maxPlayers: String = "20",
        gamemode: String = "survival"
    ): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val prefs = BotPrefsManager(context)
        if (prefs.connectionMode != "VPS") {
            return@withContext false to "Mode Server Minecraft hanya tersedia di Mode VPS!"
        }
        val payload = JSONObject().apply {
            put("host", extractHostFromUrl(prefs.vpsUrl))
            put("sshPort", prefs.vpsSshPort)
            put("user", prefs.vpsUser)
            put("pass", prefs.vpsSecret)
            put("action", action)
            put("command", command)
            put("serverName", serverName)
            put("maxPlayers", maxPlayers)
            put("gamemode", gamemode)
        }
        val mcClient = OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
        try {
            val req = Request.Builder()
                .url("http://127.0.0.1:8765/mc/action")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()
            mcClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                if (body.isNotEmpty()) {
                    val json = JSONObject(body)
                    return@withContext json.optBoolean("ok", false) to json.optString("output", json.optString("error", ""))
                }
            }
        } catch (e: Exception) {
            return@withContext false to "Error: ${e.message}"
        }
        false to "Tidak ada respons server"
    }

    suspend fun checkLatestGithubRelease(repo: String): Triple<String, String, String>? = withContext(Dispatchers.IO) {
        val cleanRepo = repo.trim().removePrefix("https://github.com/").trim('/')
        if (!cleanRepo.contains("/")) return@withContext null
        try {
            val req = Request.Builder()
                .url("https://api.github.com/repos/$cleanRepo/releases/latest")
                .addHeader("Accept", "application/vnd.github+json")
                .get()
                .build()
            httpClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                if (!resp.isSuccessful || body.isEmpty()) return@withContext null
                val json = JSONObject(body)
                val tag = json.optString("tag_name", "")
                val notes = json.optString("body", "Pembaruan versi terbaru tersedia.")
                val assets = json.optJSONArray("assets")
                var apkUrl = ""
                if (assets != null) {
                    for (i in 0 until assets.length()) {
                        val a = assets.optJSONObject(i) ?: continue
                        val u = a.optString("browser_download_url", "")
                        if (u.endsWith(".apk", ignoreCase = true)) {
                            apkUrl = u
                            break
                        }
                    }
                }
                if (tag.isNotEmpty() && apkUrl.isNotEmpty()) {
                    return@withContext Triple(tag, apkUrl, notes)
                }
            }
        } catch (_: Exception) {}
        null
    }

    suspend fun resetMemory(context: Context): Boolean = withContext(Dispatchers.IO) {
        val prefs = BotPrefsManager(context)
        val baseUrl = getBaseUrl(prefs)
        fallbackMemory.clear()
        try {
            val req = Request.Builder()
                .url("$baseUrl/reset-memory")
                .post("{}".toRequestBody(jsonMediaType))
                .build()
            httpClient.newCall(req).execute().use { resp ->
                return@withContext resp.isSuccessful
            }
        } catch (_: Exception) {
            false
        }
    }

    suspend fun fetchStatus(context: Context): EngineLiveStatus? = withContext(Dispatchers.IO) {
        val prefs = BotPrefsManager(context)
        val baseUrl = getBaseUrl(prefs)
        try {
            val req = Request.Builder().url("$baseUrl/status").get().build()
            httpClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                if (resp.isSuccessful && body.isNotEmpty()) {
                    val json = JSONObject(body)
                    val ver = json.optString("engineVersion", "")
                    if (prefs.connectionMode == "VPS" && ver != "5.4" && prefs.vpsSecret.isNotEmpty()) {
                        val h = extractHostFromUrl(prefs.vpsUrl)
                        if (h.isNotEmpty() && autoUpgradedVpsHost != h) {
                            autoUpgradedVpsHost = h
                            log("Mendeteksi mesin VPS versi lama ($ver), meng-upgrade otomatis ke v5.4...")
                            connectAndSetupVpsFromApk(context, h, prefs.vpsSshPort, prefs.vpsUser, prefs.vpsSecret, true)
                        }
                    }
                    val logsArr = json.optJSONArray("logs")
                    if (logsArr != null && logsArr.length() > 0) {
                        val latestList = mutableListOf<String>()
                        val startIdx = (logsArr.length() - 20).coerceAtLeast(0)
                        for (i in startIdx until logsArr.length()) {
                            latestList.add(logsArr.optString(i))
                        }
                        appLogs.clear()
                        appLogs.addAll(latestList)
                    }
                    val parsedSessions = mutableListOf<PairedSessionItem>()
                    val sessArr = json.optJSONArray("sessions")
                    if (sessArr != null) {
                        for (i in 0 until sessArr.length()) {
                            val obj = sessArr.optJSONObject(i) ?: continue
                            parsedSessions.add(
                                PairedSessionItem(
                                    id = obj.optString("id", ""),
                                    phone = obj.optString("phone", ""),
                                    jid = obj.optString("jid", ""),
                                    active = obj.optBoolean("active", true),
                                    loggedIn = obj.optBoolean("loggedIn", false),
                                    connected = obj.optBoolean("connected", false),
                                    state = obj.optString("state", "")
                                )
                            )
                        }
                    }
                    return@withContext EngineLiveStatus(
                        loggedIn = json.optBoolean("loggedIn", false),
                        totalReplied = json.optInt("totalReplied", 0),
                        activeGroups = json.optInt("activeGroups", 0),
                        state = json.optString("state", "READY"),
                        sessions = parsedSessions
                    )
                }
            }
        } catch (_: Exception) {
        }
        null
    }

    suspend fun callGeminiDirect(
        prefs: BotPrefsManager,
        senderJid: String,
        userMessage: String
    ): String? = withContext(Dispatchers.IO) {
        val apiKey = prefs.geminiApiKey.trim()
        if (apiKey.isEmpty()) {
            log("Gagal membalas: API Key Gemini belum diisi!")
            return@withContext null
        }
        val rawPref = prefs.geminiModel.ifEmpty { "gemini-3.8-flash" }
        val modelsToTry = listOf(rawPref, "gemini-3.8-flash", "gemini-3.5-flash", "gemini-3.5-flash-lite", "gemini-2.5-flash", "gemini-2.5-flash-lite").distinct()
        val history = fallbackMemory.getOrPut(senderJid) { mutableListOf() }

        val contentsArray = JSONArray()
        synchronized(history) {
            for ((role, text) in history) {
                val part = JSONObject().put("text", text)
                val parts = JSONArray().put(part)
                contentsArray.put(JSONObject().put("role", role).put("parts", parts))
            }
        }
        val userPart = JSONObject().put("text", userMessage)
        contentsArray.put(
            JSONObject()
                .put("role", "user")
                .put("parts", JSONArray().put(userPart))
        )

        val requestJson = JSONObject().apply {
            put("contents", contentsArray)
            if (prefs.systemPrompt.isNotBlank()) {
                put(
                    "systemInstruction",
                    JSONObject()
                        .put("role", "system")
                        .put("parts", JSONArray().put(JSONObject().put("text", prefs.systemPrompt)))
                )
            }
        }

        for (model in modelsToTry) {
            val endpoints = if (apiKey.startsWith("AQ.", ignoreCase = true)) {
                listOf(
                    "https://aiplatform.googleapis.com/v1/publishers/google/models/$model:generateContent?key=$apiKey",
                    "https://aiplatform.googleapis.com/v1beta1/publishers/google/models/$model:generateContent?key=$apiKey",
                    "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
                )
            } else {
                listOf(
                    "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey",
                    "https://aiplatform.googleapis.com/v1/publishers/google/models/$model:generateContent?key=$apiKey"
                )
            }
            for (url in endpoints) {
                try {
                    val req = Request.Builder()
                        .url(url)
                        .addHeader("Content-Type", "application/json")
                        .addHeader("x-goog-api-key", apiKey)
                        .post(requestJson.toString().toRequestBody(jsonMediaType))
                        .build()

                    httpClient.newCall(req).execute().use { resp ->
                        val respBody = resp.body?.string() ?: ""
                        if (resp.isSuccessful) {
                            val parsed = JSONObject(respBody)
                            val candidates = parsed.optJSONArray("candidates")
                            if (candidates != null && candidates.length() > 0) {
                                val content = candidates.getJSONObject(0).optJSONObject("content")
                                val parts = content?.optJSONArray("parts")
                                val replyText = parts?.optJSONObject(0)?.optString("text")?.trim()
                                if (!replyText.isNullOrEmpty()) {
                                    synchronized(history) {
                                        history.add("user" to userMessage)
                                        history.add("model" to replyText)
                                        while (history.size > 20) {
                                            history.removeAt(0)
                                        }
                                    }
                                    log("Gemini ($model) membalas: ${replyText.take(60)}...")
                                    return@withContext replyText
                                }
                            }
                        }
                    }
                } catch (_: Exception) {
                }
            }
        }
        null
    }
}
