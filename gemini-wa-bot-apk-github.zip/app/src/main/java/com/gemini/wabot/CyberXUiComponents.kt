package com.gemini.wabot

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable

class CyberXGlassCardDrawable(
    private val fillColor: Int = Color.parseColor("#E60B0E17"),
    private val borderColor: Int = Color.parseColor("#33FF1744"),
    private val cornerPx: Float = 22f,
    private val strokePx: Float = 2f
) : Drawable() {
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = fillColor }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = borderColor; strokeWidth = strokePx }
    private val rect = RectF()

    override fun draw(canvas: Canvas) {
        val ins = strokePx / 2f
        rect.set(ins, ins, bounds.width().toFloat() - ins, bounds.height().toFloat() - ins)
        canvas.drawRoundRect(rect, cornerPx, cornerPx, fillPaint)
        canvas.drawRoundRect(rect, cornerPx, cornerPx, borderPaint)
    }

    override fun setAlpha(alpha: Int) { fillPaint.alpha = alpha; borderPaint.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) { fillPaint.colorFilter = cf; borderPaint.colorFilter = cf }
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

object CyberXIconMapper {
    val availableIcons = listOf(
        "ic_rm_ai" to "Neural",
        "ic_rm_shield" to "Shield",
        "ic_rm_server" to "Cube",
        "ic_rm_bot" to "Bot",
        "ic_rm_terminal" to "Term",
        "ic_rm_key" to "Key",
        "ic_rm_play" to "Play",
        "ic_rm_mic" to "Mic"
    )

    fun resolveIconRes(key: String): Int = when (key) {
        "ic_rm_shield" -> R.drawable.ic_rm_shield
        "ic_rm_server" -> R.drawable.ic_rm_server
        "ic_rm_bot" -> R.drawable.ic_rm_bot
        "ic_rm_terminal" -> R.drawable.ic_rm_terminal
        "ic_rm_key" -> R.drawable.ic_rm_key
        "ic_rm_play" -> R.drawable.ic_rm_play
        "ic_rm_mic" -> R.drawable.ic_rm_mic
        else -> R.drawable.ic_rm_ai
    }
}
