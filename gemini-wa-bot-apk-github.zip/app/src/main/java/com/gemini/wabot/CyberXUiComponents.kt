package com.gemini.wabot

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable

class CyberXGlassCardDrawable(
    private val fillColor: Int = Color.parseColor("#E60B0E17"),
    private val borderColor: Int = Color.parseColor("#33FF1744"),
    private val cornerPx: Float = 22f,
    private val strokePx: Float = 2f
) : Drawable() {
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = fillColor }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = borderColor; strokeWidth = strokePx }
    private val rect = RectF()

    override fun draw(canvas: Canvas) {
        val ins = strokePx / 2f
        rect.set(ins, ins, bounds.width().toFloat() - ins, bounds.height().toFloat() - ins)
        canvas.drawRoundRect(rect, cornerPx, cornerPx, fillPaint)
        canvas.drawRoundRect(rect, cornerPx, cornerPx, borderPaint)
    }

    override fun setAlpha(alpha: Int) { fillPaint.alpha = alpha; borderPaint.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) { fillPaint.colorFilter = cf; borderPaint.colorFilter = cf }
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

object CyberXIconMapper {
    val availableIcons = listOf(
        "ic_rm_ai" to "Neural",
        "ic_rm_shield" to "Shield",
        "ic_rm_server" to "Cube",
        "ic_rm_bot" to "Bot",
        "ic_rm_terminal" to "Term",
        "ic_rm_key" to "Key",
        "ic_rm_play" to "Play",
        "ic_rm_mic" to "Mic"
    )

    fun resolveIconRes(key: String): Int = when (key) {
        "ic_rm_shield" -> R.drawable.ic_rm_shield
        "ic_rm_server" -> R.drawable.ic_rm_server
        "ic_rm_bot" -> R.drawable.ic_rm_bot
        "ic_rm_terminal" -> R.drawable.ic_rm_terminal
        "ic_rm_key" -> R.drawable.ic_rm_key
        "ic_rm_play" -> R.drawable.ic_rm_play
        "ic_rm_mic" -> R.drawable.ic_rm_mic
        else -> R.drawable.ic_rm_ai
    }
}

class CyberXShapeDrawable(
    private val shape: CyberXTriggerShape,
    private val fillColor: Int,
    private val borderColor: Int,
    private val strokePx: Float = 3f
) : Drawable() {
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = fillColor }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = borderColor; strokeWidth = strokePx }
    private val rect = RectF()
    private val triPath = android.graphics.Path()

    override fun draw(canvas: Canvas) {
        val w = bounds.width().toFloat()
        val h = bounds.height().toFloat()
        val ins = strokePx / 2f
        when (shape) {
            CyberXTriggerShape.CIRCLE -> {
                val r = (minOf(w, h) / 2f) - ins
                canvas.drawCircle(w / 2f, h / 2f, r, fillPaint)
                canvas.drawCircle(w / 2f, h / 2f, r, borderPaint)
            }
            CyberXTriggerShape.TRIANGLE -> {
                triPath.reset()
                triPath.moveTo(w / 2f, ins)
                triPath.lineTo(w - ins, h - ins)
                triPath.lineTo(ins, h - ins)
                triPath.close()
                canvas.drawPath(triPath, fillPaint)
                canvas.drawPath(triPath, borderPaint)
            }
            CyberXTriggerShape.SQUARE -> {
                rect.set(ins, ins, w - ins, h - ins)
                canvas.drawRoundRect(rect, 16f, 16f, fillPaint)
                canvas.drawRoundRect(rect, 16f, 16f, borderPaint)
            }
        }
    }

    override fun setAlpha(alpha: Int) { fillPaint.alpha = alpha; borderPaint.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) { fillPaint.colorFilter = cf; borderPaint.colorFilter = cf }
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

class CyberXWaitingMechaView(context: Context) : android.view.View(context) {
    private var angle = 0f
    private var anim: android.animation.ValueAnimator? = null
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 5f }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 28f
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD)
    }
    private val rect = RectF()

    fun startAnim() {
        anim?.cancel()
        anim = android.animation.ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 2000L
            repeatCount = android.animation.ValueAnimator.INFINITE
            interpolator = android.view.animation.LinearInterpolator()
            addUpdateListener { angle = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    fun stopAnim() { anim?.cancel(); anim = null }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2f; val cy = h / 2f - 18f
        val r = minOf(w, h) * 0.25f
        ringPaint.color = Color.parseColor("#FF1744")
        rect.set(cx - r, cy - r, cx + r, cy + r)
        for (i in 0 until 3) canvas.drawArc(rect, angle + i * 120f, 70f, false, ringPaint)
        ringPaint.color = Color.parseColor("#00E5FF")
        val r2 = r * 0.72f
        rect.set(cx - r2, cy - r2, cx + r2, cy + r2)
        for (i in 0 until 4) canvas.drawArc(rect, -angle * 1.4f + i * 90f, 45f, false, ringPaint)
        canvas.drawText("MENUNGGU GAME...", cx, cy + r + 48f, textPaint)
    }
}

object CyberXSoundFx {
    fun playClick(enabled: Boolean) {
        if (!enabled) return
        try {
            val tg = android.media.ToneGenerator(android.media.AudioManager.STREAM_SYSTEM, 35)
            tg.startTone(android.media.ToneGenerator.TONE_PROP_BEEP, 35)
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ try { tg.release() } catch (_: Exception) {} }, 90)
        } catch (_: Exception) {}
    }
}
