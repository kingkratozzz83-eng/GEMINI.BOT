package com.gemini.wabot

import android.app.ActivityManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.util.UUID

class CyberXDashboardManager(
    private val activity: AppCompatActivity,
    private val prefs: BotPrefsManager,
    private val onSwitchToBotMode: () -> Unit,
    private val onStartBotService: () -> Unit,
    private val onStopBotService: () -> Unit
) {
    private val storage = CyberXStorageManager(activity)
    private var activeTab = "HOME"
    private lateinit var contentContainer: FrameLayout
    private lateinit var tvHeaderService: TextView
    private val navButtons = mutableMapOf<String, Button>()

    fun buildInto(container: FrameLayout) {
        container.removeAllViews()
        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#05070D"))
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        }

        // === COMPACT CYBERX RGB HEADER ===
        val rgbTopBar = View(activity).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 4)
        }
        root.addView(rgbTopBar)
        val header = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#0B0E17"))
            setPadding(20, 12, 20, 12)
        }
        val logo = ImageView(activity).apply {
            setImageResource(R.drawable.ic_bot_logo)
            layoutParams = LinearLayout.LayoutParams(52, 52).apply { marginEnd = 14 }
        }
        val titleCol = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val tvBrand = TextView(activity).apply {
            text = "CYBERX GAME SPACE"
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = android.graphics.Typeface.MONOSPACE
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        tvHeaderService = TextView(activity).apply {
            text = "Memeriksa status layanan..."
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 10f
            typeface = android.graphics.Typeface.MONOSPACE
        }
        titleCol.addView(tvBrand); titleCol.addView(tvHeaderService)

        val btnSettingsShortcut = makePillBtn("Settings", "#1E293B") { selectTab("SETTINGS") }
        val btnBotMode = makePillBtn("Mode Bot", "#0284C7") { onSwitchToBotMode() }

        header.addView(logo)
        header.addView(titleCol)
        header.addView(btnSettingsShortcut)
        header.addView(btnBotMode)
        root.addView(header)

        // === PAGE CONTENT CONTAINER ===
        contentContainer = FrameLayout(activity).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        root.addView(contentContainer)

        // === 5-TAB BOTTOM NAVIGATION ===
        val navBar = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#0B0E17"))
            setPadding(12, 8, 12, 8)
        }
        val tabs = listOf("HOME" to "Home", "GAMES" to "Games", "TOOLS" to "Tools", "MACROS" to "Macros", "SETTINGS" to "Settings")
        for ((key, label) in tabs) {
            val b = Button(activity).apply {
                text = label
                textSize = 11f
                isAllCaps = false
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.TRANSPARENT)
                minHeight = 0; minimumHeight = 0
                setPadding(8, 12, 8, 12)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 4 }
                setOnClickListener { selectTab(key) }
            }
            navButtons[key] = b
            navBar.addView(b)
        }
        root.addView(navBar)
        container.addView(root)

        val rgbBotBar = View(activity).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 3)
        }
        root.addView(rgbBotBar)
        android.animation.ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 2800L
            repeatCount = android.animation.ValueAnimator.INFINITE
            interpolator = android.view.animation.LinearInterpolator()
            addUpdateListener { va ->
                val hue = va.animatedValue as Float
                val c1 = Color.HSVToColor(floatArrayOf(hue, 0.95f, 1f))
                val c2 = Color.HSVToColor(floatArrayOf((hue + 140f) % 360f, 0.95f, 1f))
                val g = android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(c1, c2))
                rgbTopBar.background = g
                rgbBotBar.background = g
            }
            start()
        }
        refreshHeaderStatus()
        selectTab(activeTab)
    }

    fun refreshHeaderStatus() {
        val ovOn = if (CyberXGameOverlayService.isServiceRunning) "Overlay: AKTIF" else "Overlay: MATI"
        val botOn = if (prefs.gameSpaceBatterySaver) "Bot: NONAKTIF (Hemat)" else "Bot: AKTIF"
        if (::tvHeaderService.isInitialized) {
            tvHeaderService.text = "$ovOn  •  $botOn"
        }
    }

    fun selectTab(tabKey: String) {
        activeTab = tabKey
        for ((k, b) in navButtons) {
            b.setBackgroundColor(if (k == tabKey) Color.parseColor("#E11D48") else Color.parseColor("#141926"))
        }
        contentContainer.removeAllViews()
        val scroll = ScrollView(activity).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        }
        val page = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 16, 22, 24)
        }
        when (tabKey) {
            "HOME" -> renderHomePage(page)
            "GAMES" -> renderGamesPage(page)
            "TOOLS" -> renderToolsPage(page)
            "MACROS" -> renderMacrosPage(page)
            "SETTINGS" -> renderSettingsPage(page)
        }
        scroll.addView(page)
        scroll.alpha = 0f
        contentContainer.addView(scroll)
        scroll.animate().alpha(1f).setDuration(180).start()
        refreshHeaderStatus()
    }

    // === 1. HOME PAGE ===
    private fun renderHomePage(page: LinearLayout) {
        page.addView(makeSectionTitle("Selamat Datang di CYBERX"))
        page.addView(makeSubText("Ruang gaming gelap & ringkas dengan edge-gesture overlay, Macro Library, dan HUD Editor terpadu."))

        // Telemetry Card
        val bm = activity.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = (bm?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val lvl = bm?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val am = activity.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val freeMb = mi.availMem / (1024 * 1024)
        val totalMb = mi.totalMem / (1024 * 1024)

        val telCard = makeGlassCard().apply {
            addView(makeCardTitle("Telemetri Perangkat"))
            addView(makeSubText("Suhu Baterai: ${temp}°C  •  Baterai: ${lvl}%  •  RAM Tersedia: ${freeMb} / ${totalMb} MB"))
            addView(makeSubText("FPS Monitor: Hanya tersedia untuk aplikasi internal; Android membatasi pembacaan FPS game eksternal tanpa akses root/Shizuku."))
        }
        page.addView(telCard)

        // Quick Service Control Card
        val svcCard = makeGlassCard().apply {
            addView(makeCardTitle("Kontrol Layanan Overlay"))
            val row = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 0) }
            row.addView(makeActionBtn("Start Overlay", "#10B981", Color.BLACK) { startOverlayServiceSafe() })
            row.addView(makeActionBtn("Stop Overlay", "#991B1B", Color.WHITE) { stopOverlayServiceSafe() })
            row.addView(makeActionBtn("HUD Editor", "#0284C7", Color.WHITE) {
                activity.startActivity(Intent(activity, CyberXHudEditorActivity::class.java))
            })
            addView(row)
        }
        page.addView(svcCard)

        // Recently Played
        page.addView(makeSectionTitle("Recently Played"))
        val stats = storage.getGameStats()
        val pm = activity.packageManager
        val recentApps = getDetectedGames().filter { stats.containsKey(it.packageName) }
            .sortedByDescending { stats[it.packageName]?.lastPlayedMs ?: 0L }
            .take(6)

        if (recentApps.isEmpty()) {
            page.addView(makeSubText("Belum ada riwayat game. Buka tab Games untuk meluncurkan game pertamamu."))
        } else {
            val hScroll = HorizontalScrollView(activity)
            val hRow = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
            for (app in recentApps) {
                val card = LinearLayout(activity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    background = CyberXGlassCardDrawable(Color.parseColor("#D90C101C"), Color.parseColor("#33FFFFFF"), 18f, 1.5f)
                    setPadding(18, 14, 18, 14)
                    layoutParams = LinearLayout.LayoutParams(220, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginEnd = 12 }
                    setOnClickListener { launchGameWithOverlay(app.packageName) }
                }
                val iv = ImageView(activity).apply {
                    try { setImageDrawable(pm.getApplicationIcon(app)) } catch (_: Exception) {}
                    layoutParams = LinearLayout.LayoutParams(72, 72)
                }
                val tv = TextView(activity).apply {
                    text = pm.getApplicationLabel(app).toString()
                    setTextColor(Color.WHITE)
                    textSize = 11f
                    maxLines = 1
                    gravity = Gravity.CENTER
                    setPadding(0, 8, 0, 0)
                }
                card.addView(iv); card.addView(tv)
                hRow.addView(card)
            }
            hScroll.addView(hRow)
            page.addView(hScroll)
        }
    }

    // === 2. GAMES PAGE ===
    private fun renderGamesPage(page: LinearLayout) {
        val topRow = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = makeSectionTitle("My Games & Game Library").apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val btnAdd = makePillBtn("+ Add Games", "#E11D48") { showAddGamesDialog() }
        topRow.addView(title); topRow.addView(btnAdd)
        page.addView(topRow)

        val pm = activity.packageManager
        val stats = storage.getGameStats()
        val games = getDetectedGames()
        if (games.isEmpty()) {
            page.addView(makeSubText("Belum ada game terdeteksi. Ketuk '+ Add Games' untuk menambahkan game secara manual."))
            return
        }
        for (app in games) {
            val label = pm.getApplicationLabel(app).toString()
            val cnt = stats[app.packageName]?.playCount ?: 0
            val card = makeGlassCard().apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val iv = ImageView(activity).apply {
                try { setImageDrawable(pm.getApplicationIcon(app)) } catch (_: Exception) {}
                layoutParams = LinearLayout.LayoutParams(76, 76).apply { marginEnd = 16 }
            }
            val infoCol = LinearLayout(activity).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val tvName = TextView(activity).apply {
                text = label; setTextColor(Color.WHITE); textSize = 13.5f; setTypeface(null, android.graphics.Typeface.BOLD)
            }
            val tvMeta = TextView(activity).apply {
                text = "${app.packageName} • Dimainkan ${cnt}x"
                setTextColor(Color.parseColor("#94A3B8")); textSize = 10f
            }
            infoCol.addView(tvName); infoCol.addView(tvMeta)
            val btnPlay = makePillBtn("Main", "#10B981", Color.BLACK) { launchGameWithOverlay(app.packageName) }
            card.addView(iv); card.addView(infoCol); card.addView(btnPlay)
            page.addView(card)
        }
    }

    // === 3. TOOLS PAGE ===
    private fun renderToolsPage(page: LinearLayout) {
        page.addView(makeSectionTitle("Gaming Tools & Edge Gesture"))

        val perfCard = makeGlassCard().apply {
            addView(makeCardTitle("Profil Performa & Crosshair"))
            val row = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 0) }
            row.addView(makeActionBtn("Performa: ${prefs.perfMode.uppercase()}", "#1E293B", Color.WHITE) { b ->
                val next = when (prefs.perfMode) { "eco" -> "balance"; "balance" -> "turbo"; else -> "eco" }
                prefs.perfMode = next
                b.text = "Performa: ${next.uppercase()}"
            })
            row.addView(makeActionBtn("Crosshair: ${prefs.crosshairStyle}", "#1E293B", Color.WHITE) { b ->
                val next = when (prefs.crosshairStyle) { "OFF" -> "DOT"; "DOT" -> "CROSS"; "CROSS" -> "CIRCLE"; else -> "OFF" }
                prefs.crosshairStyle = next
                b.text = "Crosshair: $next"
            })
            addView(row)
        }
        page.addView(perfCard)

        val edgeCard = makeGlassCard().apply {
            addView(makeCardTitle("Area Edge Gesture In-Game Overlay"))
            addView(makeSubText("Panggil overlay di dalam game lewat usapan tepi layar tanpa floating bubble permanen."))
            val row = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 0) }
            row.addView(makeActionBtn("Sisi: ${storage.edgeSide}", "#1E293B", Color.WHITE) { b ->
                val next = when (storage.edgeSide) { "RIGHT" -> "LEFT"; "LEFT" -> "BOTH"; else -> "RIGHT" }
                storage.edgeSide = next
                b.text = "Sisi: $next"
                if (CyberXGameOverlayService.isServiceRunning) startOverlayServiceSafe()
            })
            row.addView(makeActionBtn("Tinggi: ${storage.edgeHeightPct}%", "#1E293B", Color.WHITE) { b ->
                val next = if (storage.edgeHeightPct >= 60) 25 else storage.edgeHeightPct + 15
                storage.edgeHeightPct = next
                b.text = "Tinggi: ${next}%"
                if (CyberXGameOverlayService.isServiceRunning) startOverlayServiceSafe()
            })
            addView(row)
        }
        page.addView(edgeCard)

        val hudCard = makeGlassCard().apply {
            addView(makeCardTitle("HUD Editor & Sistem"))
            val row = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 0) }
            row.addView(makeActionBtn("Buka HUD Editor", "#E11D48", Color.WHITE) {
                activity.startActivity(Intent(activity, CyberXHudEditorActivity::class.java))
            })
            row.addView(makeActionBtn("Mode Fokus (DND)", "#1E293B", Color.WHITE) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    activity.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                }
            })
            addView(row)
        }
        page.addView(hudCard)
    }

    // === 4. MACROS PAGE (GG GAME SPACE TOOLBOX + SHIZUKU/ADB BACKEND + TOUCH TIMELINE) ===
    private fun renderMacrosPage(page: LinearLayout) {
        val shizuku = CyberXShizukuBackend.getStatus(activity)

        // 1. Shizuku / ADB Backend Status & Diagnostics Card
        val backendCard = makeGlassCard().apply {
            addView(makeCardTitle("Backend Eksekusi: ADB / Shizuku (Tanpa Root)"))
            val statusColor = if (shizuku.binderAlive && shizuku.permissionGranted) "#10B981" else "#FF4D6D"
            addView(TextView(activity).apply {
                text = "Status: ${shizuku.summary}"
                setTextColor(Color.parseColor(statusColor))
                textSize = 12f
                setTypeface(null, android.graphics.Typeface.BOLD)
            })
            addView(makeSubText(shizuku.detail))
            if (CyberXShizukuBackend.lastDiagnosticError.isNotEmpty()) {
                addView(TextView(activity).apply {
                    text = "Diagnostik Terakhir: ${CyberXShizukuBackend.lastDiagnosticError}"
                    setTextColor(Color.parseColor("#FDE047"))
                    textSize = 10f
                })
            }
            val row = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 0) }
            row.addView(makeActionBtn("Minta Izin Shizuku", "#0284C7", Color.WHITE) {
                if (!CyberXShizukuBackend.requestPermission()) {
                    Toast.makeText(activity, "Shizuku belum aktif! Buka aplikasi Shizuku dulu.", Toast.LENGTH_LONG).show()
                } else {
                    selectTab("MACROS")
                }
            })
            row.addView(makeActionBtn("Tes Input", "#1E293B", Color.WHITE) {
                val (ok, msg) = CyberXShizukuBackend.execShell("input tap 10 10")
                Toast.makeText(activity, if (ok) "Tes Input Shizuku BERHASIL!" else "Gagal: $msg", Toast.LENGTH_LONG).show()
                selectTab("MACROS")
            })
            row.addView(makeActionBtn("Panduan Setup", "#1E293B", Color.WHITE) {
                AlertDialog.Builder(activity)
                    .setTitle("Panduan Setup Shizuku (Tanpa Root)")
                    .setMessage("1. Pasang aplikasi Shizuku di HP.\n2. Aktifkan Opsi Pengembang & Wireless Debugging.\n3. Jalankan Shizuku via Wireless Debugging.\n4. Kembali ke CYBERX, tekan 'Minta Izin Shizuku' lalu pilih Izinkan.")
                    .setPositiveButton("Mengerti", null)
                    .show()
            })
            addView(row)
        }
        page.addView(backendCard)

        // 2. Macro Status & Big Record / Playback Controls
        val macros = storage.getMacros()
        val activeMacro = macros.firstOrNull { it.id == storage.activeMacroId } ?: macros.firstOrNull()
        val ctrlCard = makeGlassCard().apply {
            addView(makeCardTitle("Kontrol Macro (${CyberXMacroPlayer.state.name})"))
            addView(makeSubText(CyberXMacroPlayer.statusText))

            val bigRecBtn = Button(activity).apply {
                text = "● REKAM SENTUHAN DI LAYAR (RECORD)"
                textSize = 12f
                isAllCaps = false
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.parseColor("#E11D48"))
                setPadding(16, 16, 16, 16)
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = 6; bottomMargin = 8 }
                setOnClickListener {
                    if (!Settings.canDrawOverlays(activity)) {
                        activity.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${activity.packageName}")))
                        Toast.makeText(activity, "Izinkan Overlay untuk merekam sentuhan di atas layar!", Toast.LENGTH_LONG).show()
                        return@setOnClickListener
                    }
                    startOverlayServiceSafe()
                    Toast.makeText(activity, "Usap tepi layar -> tab MACROS -> tekan Rekam Sentuhan Baru!", Toast.LENGTH_LONG).show()
                }
            }
            addView(bigRecBtn)

            val playRow = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
            playRow.addView(makeActionBtn("▶ Play", "#10B981", Color.BLACK) {
                if (activeMacro == null) {
                    Toast.makeText(activity, "Belum ada macro tersimpan!", Toast.LENGTH_SHORT).show()
                } else {
                    CyberXMacroPlayer.play(activity, activeMacro)
                    selectTab("MACROS")
                }
            })
            playRow.addView(makeActionBtn(if (CyberXMacroPlayer.state == MacroEngineState.PAUSED) "▶ Resume" else "⏸ Pause", "#0284C7", Color.WHITE) {
                if (CyberXMacroPlayer.state == MacroEngineState.PAUSED) CyberXMacroPlayer.resume() else CyberXMacroPlayer.pause()
                selectTab("MACROS")
            })
            playRow.addView(makeActionBtn("■ Stop", "#991B1B", Color.WHITE) {
                CyberXMacroPlayer.stop()
                selectTab("MACROS")
            })
            addView(playRow)
        }
        page.addView(ctrlCard)

        // 3. Macro Library + Import/Export JSON
        val topRow = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = makeSectionTitle("Daftar Macro Tersimpan (${macros.size})").apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val btnImport = makePillBtn("Import JSON", "#1E293B") {
            val inp = EditText(activity).apply { hint = "Tempel JSON Macro di sini..." }
            AlertDialog.Builder(activity).setTitle("Import Macro JSON").setView(inp)
                .setPositiveButton("Import") { _, _ ->
                    val res = storage.importMacroJson(inp.text.toString())
                    Toast.makeText(activity, if (res != null) "Macro '${res.name}' di-import!" else "JSON tidak valid", Toast.LENGTH_SHORT).show()
                    selectTab("MACROS")
                }.setNegativeButton("Batal", null).show()
        }
        val btnNew = makePillBtn("+ Buat Kosong", "#E11D48") {
            val inp = EditText(activity).apply { hint = "Nama Macro Baru" }
            AlertDialog.Builder(activity).setTitle("Buat Profil Macro").setView(inp)
                .setPositiveButton("Buat") { _, _ ->
                    val nm = CyberXMacroProfile(UUID.randomUUID().toString(), inp.text.toString().trim().ifEmpty { "Macro ${macros.size + 1}" })
                    macros.add(nm)
                    storage.saveMacros(macros)
                    storage.activeMacroId = nm.id
                    selectTab("MACROS")
                }.setNegativeButton("Batal", null).show()
        }
        topRow.addView(title); topRow.addView(btnImport); topRow.addView(btnNew)
        page.addView(topRow)

        for (m in macros) {
            val isAct = (activeMacro?.id == m.id)
            val card = makeGlassCard().apply {
                val head = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val tvTitle = TextView(activity).apply {
                    val loopTxt = if (m.loopCount == 0) "∞" else "${m.loopCount}x"
                    text = "${if (isAct) "★ " else ""}${m.name} (${m.steps.size} step • ${m.speedMultiplier}x • Loop $loopTxt)"
                    setTextColor(Color.WHITE); textSize = 12.5f; setTypeface(null, android.graphics.Typeface.BOLD)
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                val btnSelect = makePillBtn(if (isAct) "Aktif" else "Pilih", if (isAct) "#10B981" else "#334155", if (isAct) Color.BLACK else Color.WHITE) {
                    storage.activeMacroId = m.id
                    selectTab("MACROS")
                }
                head.addView(tvTitle); head.addView(btnSelect)
                addView(head)

                // Visual Timeline of Touch Steps
                if (m.steps.isNotEmpty()) {
                    val tl = HorizontalScrollView(activity)
                    val tlRow = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 8) }
                    for (st in m.steps.sortedBy { it.order }) {
                        val chip = TextView(activity).apply {
                            text = "#${st.order} ${st.type.label} (${st.xPx.toInt()},${st.yPx.toInt()}) • +${st.delayFromPrevMs}ms • ${st.durationMs}ms"
                            setTextColor(Color.parseColor("#00E5FF"))
                            textSize = 9.5f
                            setBackgroundColor(Color.parseColor("#182238"))
                            setPadding(12, 6, 12, 6)
                            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginEnd = 6 }
                        }
                        tlRow.addView(chip)
                    }
                    tl.addView(tlRow)
                    addView(tl)
                }

                // Speed, Loop, Edit Timeline, Export, Rename, Delete
                val row1 = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 4, 0, 4) }
                row1.addView(makeActionBtn("Speed: ${m.speedMultiplier}x", "#1E293B", Color.WHITE) {
                    m.speedMultiplier = when (m.speedMultiplier) { 0.5f -> 1.0f; 1.0f -> 1.5f; 1.5f -> 2.0f; else -> 0.5f }
                    storage.saveMacros(macros); selectTab("MACROS")
                })
                row1.addView(makeActionBtn("Loop: ${if (m.loopCount == 0) "∞" else "${m.loopCount}x"}", "#1E293B", Color.WHITE) {
                    m.loopCount = when (m.loopCount) { 1 -> 3; 3 -> 5; 5 -> 10; 10 -> 0; else -> 1 }
                    storage.saveMacros(macros); selectTab("MACROS")
                })
                row1.addView(makeActionBtn("Edit Timeline", "#0284C7", Color.WHITE) { showMacroTimelineEditor(m, macros) })
                addView(row1)

                val row2 = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
                row2.addView(makeActionBtn("Export JSON", "#1E293B", Color.WHITE) {
                    val cm = activity.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("CyberX Macro", storage.exportMacroJson(m)))
                    Toast.makeText(activity, "JSON Macro disalin ke clipboard!", Toast.LENGTH_SHORT).show()
                })
                row2.addView(makeActionBtn("Rename", "#1E293B", Color.WHITE) {
                    val inp = EditText(activity).apply { setText(m.name) }
                    AlertDialog.Builder(activity).setTitle("Ganti Nama Macro").setView(inp)
                        .setPositiveButton("Simpan") { _, _ ->
                            m.name = inp.text.toString().trim().ifEmpty { m.name }
                            storage.saveMacros(macros); selectTab("MACROS")
                        }.show()
                })
                row2.addView(makeActionBtn("Hapus", "#991B1B", Color.WHITE) {
                    AlertDialog.Builder(activity).setTitle("Hapus Macro?").setMessage("Yakin hapus '${m.name}'?")
                        .setPositiveButton("Hapus") { _, _ ->
                            macros.removeAll { it.id == m.id }
                            storage.saveMacros(macros); selectTab("MACROS")
                        }.setNegativeButton("Batal", null).show()
                })
                addView(row2)
            }
            page.addView(card)
        }
    }

    private fun showMacroTimelineEditor(m: CyberXMacroProfile, allMacros: MutableList<CyberXMacroProfile>) {
        val types = CyberXTouchType.values()
        val msg = if (m.steps.isEmpty()) "Belum ada langkah sentuhan." else m.steps.sortedBy { it.order }.joinToString("\n") {
            "#${it.order} ${it.type.label} (${it.xPx.toInt()},${it.yPx.toInt()}) | Jeda ${it.delayFromPrevMs}ms | Hold ${it.durationMs}ms"
        }
        AlertDialog.Builder(activity)
            .setTitle("Timeline Editor: ${m.name}")
            .setMessage(msg)
            .setPositiveButton("+ Tambah Step Manual") { _, _ ->
                val xIn = EditText(activity).apply { hint = "Koordinat X (misal 500)" }
                val yIn = EditText(activity).apply { hint = "Koordinat Y (misal 500)" }
                val dIn = EditText(activity).apply { hint = "Jeda dari sebelumnya ms (misal 100)" }
                val hIn = EditText(activity).apply { hint = "Durasi Hold ms (misal 50)" }
                val box = LinearLayout(activity).apply {
                    orientation = LinearLayout.VERTICAL; setPadding(36, 16, 36, 8)
                    addView(xIn); addView(yIn); addView(dIn); addView(hIn)
                }
                AlertDialog.Builder(activity).setTitle("Tambah Langkah Sentuhan").setView(box)
                    .setPositiveButton("Simpan Step") { _, _ ->
                        val xp = xIn.text.toString().toFloatOrNull() ?: 500f
                        val yp = yIn.text.toString().toFloatOrNull() ?: 500f
                        val dl = dIn.text.toString().toLongOrNull() ?: 100L
                        val hd = hIn.text.toString().toLongOrNull() ?: 50L
                        val tp = if (hd >= 240L) CyberXTouchType.HOLD else CyberXTouchType.TAP
                        m.steps.add(CyberXTouchStep(UUID.randomUUID().toString(), m.steps.size + 1, tp, xp, yp, xp, yp, System.currentTimeMillis(), dl, hd))
                        storage.saveMacros(allMacros); selectTab("MACROS")
                    }.show()
            }
            .setNeutralButton("Hapus Step Terakhir") { _, _ ->
                if (m.steps.isNotEmpty()) {
                    m.steps.removeAt(m.steps.lastIndex)
                    storage.saveMacros(allMacros); selectTab("MACROS")
                }
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    // === 5. SETTINGS & LIFECYCLE PAGE ===
    private fun renderSettingsPage(page: LinearLayout) {
        page.addView(makeSectionTitle("Layanan & Lifecycle Aplikasi"))

        val svcCard = makeGlassCard().apply {
            addView(makeCardTitle("Kontrol Background & Overlay Service"))
            addView(makeSubText("Menutup overlay tidak mematikan service. Gunakan tombol di bawah untuk Start/Stop service tanpa perlu Force Stop."))
            val row1 = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 6) }
            row1.addView(makeActionBtn("Start Overlay Service", "#10B981", Color.BLACK) { startOverlayServiceSafe() })
            row1.addView(makeActionBtn("Stop Overlay Service", "#991B1B", Color.WHITE) { stopOverlayServiceSafe() })
            addView(row1)

            val row2 = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
            row2.addView(makeActionBtn(if (prefs.gameSpaceBatterySaver) "Hemat Baterai: ON (Bot Mati)" else "Hemat Baterai: OFF (Bot Aktif)", "#1E293B", Color.WHITE) { b ->
                prefs.gameSpaceBatterySaver = !prefs.gameSpaceBatterySaver
                if (prefs.gameSpaceBatterySaver) onStopBotService() else onStartBotService()
                b.text = if (prefs.gameSpaceBatterySaver) "Hemat Baterai: ON (Bot Mati)" else "Hemat Baterai: OFF (Bot Aktif)"
                refreshHeaderStatus()
            })
            addView(row2)
        }
        page.addView(svcCard)

        val permCard = makeGlassCard().apply {
            addView(makeCardTitle("Izin Android"))
            val ovStatus = if (Settings.canDrawOverlays(activity)) "Diberikan" else "Belum"
            val accStatus = if (CyberXMacroService.instance != null) "Aktif" else "Belum"
            addView(makeSubText("Overlay: $ovStatus  •  Aksesibilitas Macro: $accStatus"))
            val row = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 0) }
            row.addView(makeActionBtn("Izin Overlay", "#0284C7", Color.WHITE) {
                activity.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${activity.packageName}")))
            })
            row.addView(makeActionBtn("Aksesibilitas", "#1E293B", Color.WHITE) {
                activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            })
            addView(row)
        }
        page.addView(permCard)

        val creditCard = makeGlassCard().apply {
            addView(makeCardTitle("Tentang CYBERX"))
            addView(TextView(activity).apply {
                text = "CYBERX Game Space v8.0\nCredit: https://tiktok.com/@newdodosadventure"
                autoLinkMask = android.text.util.Linkify.WEB_URLS
                setTextColor(Color.parseColor("#CBD5E1"))
                setLinkTextColor(Color.parseColor("#00E5FF"))
                textSize = 11f
            })
        }
        page.addView(creditCard)
    }

    private fun startOverlayServiceSafe() {
        if (!Settings.canDrawOverlays(activity)) {
            activity.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${activity.packageName}")))
            Toast.makeText(activity, "Izinkan tampilan di atas aplikasi lain terlebih dahulu", Toast.LENGTH_LONG).show()
            return
        }
        activity.startService(Intent(activity, CyberXGameOverlayService::class.java))
        Toast.makeText(activity, "Overlay Service diaktifkan! Usap tepi layar saat di game.", Toast.LENGTH_SHORT).show()
        refreshHeaderStatus()
    }

    private fun stopOverlayServiceSafe() {
        activity.stopService(Intent(activity, CyberXGameOverlayService::class.java))
        Toast.makeText(activity, "Overlay Service dihentikan dengan aman.", Toast.LENGTH_SHORT).show()
        refreshHeaderStatus()
    }

    private fun launchGameWithOverlay(pkg: String) {
        storage.recordGameLaunch(pkg)
        if (Settings.canDrawOverlays(activity)) {
            activity.startService(Intent(activity, CyberXGameOverlayService::class.java))
        }
        val launch = activity.packageManager.getLaunchIntentForPackage(pkg)
        if (launch != null) activity.startActivity(launch)
    }

    private fun getDetectedGames(): List<ApplicationInfo> {
        val pm = activity.packageManager
        val pinned = mutableSetOf<String>()
        try {
            val arr = org.json.JSONArray(prefs.pinnedGamesJson)
            for (i in 0 until arr.length()) pinned.add(arr.getString(i))
        } catch (_: Exception) {}
        return pm.getInstalledApplications(0).filter { app ->
            val isGameCat = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && app.category == ApplicationInfo.CATEGORY_GAME) ||
                ((app.flags and ApplicationInfo.FLAG_IS_GAME) != 0) ||
                app.packageName.contains("freefire", true) ||
                app.packageName.contains("roblox", true) ||
                app.packageName.contains("mobile.legends", true) ||
                app.packageName.contains("pubg", true) ||
                app.packageName.contains("minecraft", true) ||
                pinned.contains(app.packageName)
            isGameCat && pm.getLaunchIntentForPackage(app.packageName) != null
        }.sortedBy { pm.getApplicationLabel(it).toString() }
    }

    private fun showAddGamesDialog() {
        val pm = activity.packageManager
        val userApps = pm.getInstalledApplications(0)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .sortedBy { pm.getApplicationLabel(it).toString() }
        val labels = userApps.map { pm.getApplicationLabel(it).toString() }.toTypedArray()
        AlertDialog.Builder(activity)
            .setTitle("Tambahkan Game ke Library")
            .setItems(labels) { _, idx ->
                val pkg = userApps[idx].packageName
                val arr = try { org.json.JSONArray(prefs.pinnedGamesJson) } catch (_: Exception) { org.json.JSONArray() }
                arr.put(pkg)
                prefs.pinnedGamesJson = arr.toString()
                selectTab("GAMES")
                Toast.makeText(activity, "${labels[idx]} ditambahkan!", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun makeSectionTitle(t: String): TextView = TextView(activity).apply {
        text = t; setTextColor(Color.WHITE); textSize = 15f; setTypeface(null, android.graphics.Typeface.BOLD)
        setPadding(0, 6, 0, 8)
    }

    private fun makeCardTitle(t: String): TextView = TextView(activity).apply {
        text = t; setTextColor(Color.parseColor("#FF4D6D")); textSize = 12.5f; setTypeface(null, android.graphics.Typeface.BOLD)
        setPadding(0, 0, 0, 4)
    }

    private fun makeSubText(t: String): TextView = TextView(activity).apply {
        text = t; setTextColor(Color.parseColor("#94A3B8")); textSize = 11f
        setPadding(0, 2, 0, 4)
    }

    private fun makeGlassCard(): LinearLayout = LinearLayout(activity).apply {
        orientation = LinearLayout.VERTICAL
        background = MechaChamferDrawable(Color.parseColor("#D90A0D18"), Color.parseColor("#80FF1744"), Color.parseColor("#8000E5FF"), 18f, 2f)
        setPadding(20, 16, 20, 16)
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 14 }
    }

    private fun makePillBtn(label: String, bgHex: String, txtColor: Int = Color.WHITE, onClick: () -> Unit): Button = Button(activity).apply {
        text = label; textSize = 10.5f; isAllCaps = false; setTextColor(txtColor)
        setBackgroundColor(Color.parseColor(bgHex))
        setPadding(20, 8, 20, 8); minHeight = 0; minimumHeight = 0
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginStart = 8 }
        setOnClickListener { onClick() }
    }

    private fun makeActionBtn(label: String, bgHex: String, txtColor: Int, onClick: (Button) -> Unit): Button = Button(activity).apply {
        text = label; textSize = 10.5f; isAllCaps = false; setTextColor(txtColor)
        setBackgroundColor(Color.parseColor(bgHex))
        setPadding(16, 10, 16, 10); minHeight = 0; minimumHeight = 0
        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 8 }
        setOnClickListener { onClick(this) }
    }
}
