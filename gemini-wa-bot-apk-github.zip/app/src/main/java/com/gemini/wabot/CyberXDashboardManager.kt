package com.gemini.wabot

import android.app.ActivityManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.SeekBar
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.util.UUID

class CyberXDashboardManager(
    private val activity: AppCompatActivity,
    private val prefs: BotPrefsManager,
    private val onSwitchToBotMode: () -> Unit,
    private val onStartBotService: () -> Unit,
    private val onStopBotService: () -> Unit
) {
    private val storage = CyberXStorageManager(activity)
    private var activeTab = "HOME"
    private lateinit var contentContainer: FrameLayout
    private lateinit var tvHeaderService: TextView
    private val navButtons = mutableMapOf<String, Button>()
    private var adaptiveColor1: Int = Color.parseColor("#FF1744")
    private var adaptiveColor2: Int = Color.parseColor("#FF8A80")
    private var bgImageRef: ImageView? = null
    private val wallpaperThemes = listOf(
        Triple(R.drawable.gs_bg_1, "#FF1744", "#FF8A80"),
        Triple(R.drawable.gs_bg_2, "#00E5FF", "#A855F7"),
        Triple(R.drawable.gs_bg_3, "#FBBF24", "#38BDF8"),
        Triple(R.drawable.gs_bg_4, "#10B981", "#00E5FF"),
        Triple(R.drawable.gs_bg_5, "#EC4899", "#6366F1")
    )

    private fun applyWallpaperForIndex(idx: Int) {
        val (resId, c1Hex, c2Hex) = wallpaperThemes[idx % wallpaperThemes.size]
        adaptiveColor1 = Color.parseColor(c1Hex)
        adaptiveColor2 = Color.parseColor(c2Hex)
        bgImageRef?.let { iv ->
            iv.animate().alpha(0.35f).setDuration(140).withEndAction {
                iv.setImageResource(resId)
                iv.animate().alpha(1f).setDuration(240).start()
            }.start()
        }
    }

    fun buildInto(container: FrameLayout) {
        container.removeAllViews()
        val bgImageView = ImageView(activity).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setImageResource(R.drawable.gs_bg_1)
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        }
        val bgScrim = View(activity).apply {
            setBackgroundColor(Color.parseColor("#B805070D"))
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        }
        bgImageRef = bgImageView
        container.addView(bgImageView)
        container.addView(bgScrim)

        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.TRANSPARENT)
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        }

        // === COMPACT CYBERX RGB HEADER ===
        val rgbTopBar = View(activity).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 4)
        }
        root.addView(rgbTopBar)
        val header = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#0B0E17"))
            setPadding(20, 12, 20, 12)
        }
        val logo = ImageView(activity).apply {
            setImageResource(R.drawable.ic_bot_logo)
            layoutParams = LinearLayout.LayoutParams(52, 52).apply { marginEnd = 14 }
        }
        val titleCol = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val tvBrand = TextView(activity).apply {
            text = "CYBERX GAME SPACE"
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = android.graphics.Typeface.MONOSPACE
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        tvHeaderService = TextView(activity).apply {
            text = "Memeriksa status layanan..."
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 10f
            typeface = android.graphics.Typeface.MONOSPACE
        }
        titleCol.addView(tvBrand); titleCol.addView(tvHeaderService)

        val btnSettingsShortcut = makePillBtn("Settings", "#1E293B") { selectTab("SETTINGS") }
        val btnBotMode = makePillBtn("Mode Bot", "#0284C7") { onSwitchToBotMode() }

        header.addView(logo)
        header.addView(titleCol)
        header.addView(btnSettingsShortcut)
        header.addView(btnBotMode)
        root.addView(header)

        // === PAGE CONTENT CONTAINER ===
        contentContainer = FrameLayout(activity).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        root.addView(contentContainer)

        // === 5-TAB BOTTOM NAVIGATION ===
        val navBar = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#0B0E17"))
            setPadding(12, 8, 12, 8)
        }
        val tabs = listOf("HOME" to "Home", "GAMES" to "Games", "TOOLS" to "Tools", "MACROS" to "Macros", "SETTINGS" to "Settings")
        for ((key, label) in tabs) {
            val b = Button(activity).apply {
                text = label
                textSize = 11f
                isAllCaps = false
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.TRANSPARENT)
                minHeight = 0; minimumHeight = 0
                setPadding(8, 12, 8, 12)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 4 }
                setOnClickListener { selectTab(key) }
            }
            navButtons[key] = b
            navBar.addView(b)
        }
        root.addView(navBar)
        container.addView(root)

        val rgbBotBar = View(activity).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 3)
        }
        root.addView(rgbBotBar)
        android.animation.ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 2800L
            repeatCount = android.animation.ValueAnimator.INFINITE
            interpolator = android.view.animation.LinearInterpolator()
            addUpdateListener { va ->
                val t = ((kotlin.math.sin(Math.toRadians((va.animatedValue as Float).toDouble())) + 1.0) / 2.0).toFloat()
                val blend1 = android.animation.ArgbEvaluator().evaluate(t, adaptiveColor1, adaptiveColor2) as Int
                val blend2 = android.animation.ArgbEvaluator().evaluate(t, adaptiveColor2, adaptiveColor1) as Int
                val g = android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(blend1, blend2))
                rgbTopBar.background = g
                rgbBotBar.background = g
                for (d in adaptiveDrawables) {
                    d.updateNeonColors(blend1, blend2)
                }
            }
            start()
        }
        refreshHeaderStatus()
        selectTab(activeTab)
    }

    fun refreshHeaderStatus() {
        val ovOn = if (CyberXGameOverlayService.isServiceRunning) "Overlay: AKTIF" else "Overlay: MATI"
        val botOn = if (prefs.gameSpaceBatterySaver) "Bot: NONAKTIF (Hemat)" else "Bot: AKTIF"
        if (::tvHeaderService.isInitialized) {
            tvHeaderService.text = "$ovOn  •  $botOn"
        }
    }

    private var selectedGamePkg: String? = null
    private val adaptiveDrawables = mutableListOf<MechaChamferDrawable>()

    fun selectTab(tabKey: String) {
        CyberXSoundFx.playClick(storage.mechaSoundEnabled)
        activeTab = tabKey
        for ((k, b) in navButtons) {
            b.setBackgroundColor(if (k == tabKey) adaptiveColor1 else Color.parseColor("#141926"))
        }
        contentContainer.removeAllViews()
        adaptiveDrawables.clear()

        if (tabKey == "HOME" || tabKey == "GAMES") {
            renderRedMagicStyleGameLobby(showTelemetry = (tabKey == "HOME"))
        } else {
            val scroll = ScrollView(activity).apply {
                layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            }
            val page = LinearLayout(activity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(22, 16, 22, 24)
            }
            when (tabKey) {
                "TOOLS" -> renderToolsPage(page)
                "MACROS" -> renderMacrosPage(page)
                "SETTINGS" -> renderSettingsPage(page)
            }
            scroll.addView(page)
            scroll.alpha = 0f
            contentContainer.addView(scroll)
            scroll.animate().alpha(1f).setDuration(180).start()
        }
        refreshHeaderStatus()
    }

    private fun renderRedMagicStyleGameLobby(showTelemetry: Boolean) {
        val pm = activity.packageManager
        val stats = storage.getGameStats()
        val games = getDetectedGames()
        if (selectedGamePkg == null && games.isNotEmpty()) {
            selectedGamePkg = games.first().packageName
        }

        val split = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(16, 12, 16, 12)
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        }

        // === LEFT SCROLLABLE GAME LIST (MIRIP MODE BOT & REDMAGIC 566.mp4) ===
        val leftCol = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(420, LinearLayout.LayoutParams.MATCH_PARENT)
        }
        val listScroll = ScrollView(activity).apply {
            isVerticalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        val listInner = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }

        if (games.isEmpty()) {
            listInner.addView(makeSubText("Belum ada game. Ketuk '+ Add Games' di bawah!"))
        } else {
            for ((gIdx, app) in games.withIndex()) {
                val label = pm.getApplicationLabel(app).toString()
                val st = stats[app.packageName]
                val cnt = st?.playCount ?: 0
                val mins = ((st?.totalPlaytimeMs ?: 0L) / 60_000L).toInt()
                val ptText = "${mins / 60}j ${mins % 60}m"
                val isSel = (app.packageName == selectedGamePkg)

                val rowDrawable = if (isSel) {
                    MechaChamferDrawable(Color.parseColor("#E6160A14"), adaptiveColor1, adaptiveColor2, 16f, 3f).also {
                        adaptiveDrawables.add(it)
                    }
                } else {
                    MechaChamferDrawable(Color.parseColor("#B30A0D18"), Color.parseColor("#33FFFFFF"), Color.parseColor("#22FFFFFF"), 14f, 1.5f)
                }

                val row = LinearLayout(activity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    background = rowDrawable
                    setPadding(14, 12, 14, 12)
                    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 8 }
                    setOnClickListener {
                        CyberXSoundFx.playClick(storage.mechaSoundEnabled)
                        selectedGamePkg = app.packageName
                        applyWallpaperForIndex(gIdx)
                        selectTab(activeTab)
                    }
                }
                val iv = ImageView(activity).apply {
                    try { setImageDrawable(pm.getApplicationIcon(app)) } catch (_: Exception) {}
                    layoutParams = LinearLayout.LayoutParams(62, 62).apply { marginEnd = 12 }
                }
                val txtCol = LinearLayout(activity).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                txtCol.addView(TextView(activity).apply {
                    text = label; setTextColor(Color.WHITE); textSize = 12f; maxLines = 1
                    setTypeface(null, android.graphics.Typeface.BOLD)
                })
                txtCol.addView(TextView(activity).apply {
                    text = "$ptText • ${cnt}x main"
                    setTextColor(Color.parseColor("#94A3B8")); textSize = 9.5f
                })
                row.addView(iv); row.addView(txtCol)
                listInner.addView(row)
            }
        }
        listScroll.addView(listInner)
        leftCol.addView(listScroll)

        val btnAdd = Button(activity).apply {
            text = "+ Add Games"
            textSize = 11.5f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = MechaChamferDrawable(Color.parseColor("#CC141B2D"), adaptiveColor1, adaptiveColor2, 14f, 2f).also {
                adaptiveDrawables.add(it)
            }
            minHeight = 0; minimumHeight = 0
            setPadding(16, 12, 16, 12)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = 8 }
            setOnClickListener { showAddGamesDialog() }
        }
        leftCol.addView(btnAdd)
        split.addView(leftCol)

        // === RIGHT OPEN STAGE (WALLPAPER ANIME TERLIHAT PENUH + HERO CARD DI KANAN BAWAH) ===
        val rightStage = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
            setPadding(20, 4, 4, 4)
        }

        if (showTelemetry) {
            val bm = activity.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val temp = (bm?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
            val lvl = bm?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
            val am = activity.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            val freeMb = mi.availMem / (1024 * 1024)
            val telPill = TextView(activity).apply {
                text = "TEMP ${temp}°C  •  BAT ${lvl}%  •  RAM ${freeMb} MB"
                setTextColor(Color.parseColor("#00E5FF"))
                textSize = 10.5f
                typeface = android.graphics.Typeface.MONOSPACE
                background = MechaChamferDrawable(Color.parseColor("#CC080B14"), adaptiveColor1, adaptiveColor2, 12f, 1.5f).also {
                    adaptiveDrawables.add(it)
                }
                setPadding(18, 8, 18, 8)
            }
            rightStage.addView(telPill)
        }

        val spacer = View(activity).apply {
            layoutParams = LinearLayout.LayoutParams(1, 0, 1f)
        }
        rightStage.addView(spacer)

        val selApp = games.firstOrNull { it.packageName == selectedGamePkg } ?: games.firstOrNull()
        if (selApp != null) {
            val selLabel = pm.getApplicationLabel(selApp).toString()
            val selStat = stats[selApp.packageName]
            val heroBox = LinearLayout(activity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.END
                background = MechaChamferDrawable(Color.parseColor("#CC070A14"), adaptiveColor1, adaptiveColor2, 20f, 2f).also {
                    adaptiveDrawables.add(it)
                }
                setPadding(24, 16, 24, 16)
            }
            heroBox.addView(TextView(activity).apply {
                text = selLabel
                setTextColor(Color.WHITE)
                textSize = 22f
                setTypeface(null, android.graphics.Typeface.BOLD)
            })
            heroBox.addView(TextView(activity).apply {
                text = "Crosshair: ${selStat?.crosshairStyle ?: prefs.crosshairStyle}  •  Mode: ${(selStat?.perfMode ?: prefs.perfMode).uppercase()}"
                setTextColor(Color.parseColor("#CBD5E1"))
                textSize = 10.5f
                setPadding(0, 2, 0, 10)
            })
            val btnRow = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
            val btnOverlayQuick = makePillBtn(if (CyberXGameOverlayService.isServiceRunning) "Overlay: ON" else "Aktifkan Overlay", "#1E293B") {
                if (CyberXGameOverlayService.isServiceRunning) stopOverlayServiceSafe() else startOverlayServiceSafe()
                selectTab(activeTab)
            }
            val btnStart = Button(activity).apply {
                text = ">  Start Game"
                textSize = 13f
                isAllCaps = false
                setTextColor(Color.WHITE)
                background = MechaChamferDrawable(adaptiveColor1, adaptiveColor2, Color.WHITE, 16f, 2f).also {
                    adaptiveDrawables.add(it)
                }
                minHeight = 0; minimumHeight = 0
                setPadding(32, 12, 32, 12)
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginStart = 10 }
                setOnClickListener { launchGameWithOverlay(selApp.packageName) }
            }
            btnRow.addView(btnOverlayQuick)
            btnRow.addView(btnStart)
            heroBox.addView(btnRow)
            rightStage.addView(heroBox)
        }

        split.addView(rightStage)
        split.alpha = 0f
        contentContainer.addView(split)
        split.animate().alpha(1f).setDuration(200).start()
    }

    // === 3. TOOLS PAGE ===
    private fun renderToolsPage(page: LinearLayout) {
        page.addView(makeSectionTitle("Gaming Tools & Edge Gesture"))

        val perfCard = makeGlassCard().apply {
            addView(makeCardTitle("Profil Performa & Crosshair"))
            val row = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 0) }
            row.addView(makeActionBtn("Performa: ${prefs.perfMode.uppercase()}", "#1E293B", Color.WHITE) { b ->
                val next = when (prefs.perfMode) { "eco" -> "balance"; "balance" -> "turbo"; else -> "eco" }
                prefs.perfMode = next
                b.text = "Performa: ${next.uppercase()}"
            })
            row.addView(makeActionBtn("Crosshair: ${prefs.crosshairStyle}", "#1E293B", Color.WHITE) { b ->
                val next = when (prefs.crosshairStyle) { "OFF" -> "DOT"; "DOT" -> "CROSS"; "CROSS" -> "CIRCLE"; else -> "OFF" }
                prefs.crosshairStyle = next
                b.text = "Crosshair: $next"
            })
            addView(row)
        }
        page.addView(perfCard)

        val edgeCard = makeGlassCard().apply {
            addView(makeCardTitle("Area Edge Gesture In-Game Overlay"))
            addView(makeSubText("Panggil overlay di dalam game lewat usapan tepi layar tanpa floating bubble permanen."))
            val row = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 0) }
            row.addView(makeActionBtn("Sisi: ${storage.edgeSide}", "#1E293B", Color.WHITE) { b ->
                val next = when (storage.edgeSide) { "RIGHT" -> "LEFT"; "LEFT" -> "BOTH"; else -> "RIGHT" }
                storage.edgeSide = next
                b.text = "Sisi: $next"
                if (CyberXGameOverlayService.isServiceRunning) startOverlayServiceSafe()
            })
            row.addView(makeActionBtn("Tinggi: ${storage.edgeHeightPct}%", "#1E293B", Color.WHITE) { b ->
                val next = if (storage.edgeHeightPct >= 60) 25 else storage.edgeHeightPct + 15
                storage.edgeHeightPct = next
                b.text = "Tinggi: ${next}%"
                if (CyberXGameOverlayService.isServiceRunning) startOverlayServiceSafe()
            })
            addView(row)
        }
        page.addView(edgeCard)

        val hudCard = makeGlassCard().apply {
            addView(makeCardTitle("HUD Editor & Sistem"))
            val row = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 0) }
            row.addView(makeActionBtn("Buka HUD Editor", "#E11D48", Color.WHITE) {
                activity.startActivity(Intent(activity, CyberXHudEditorActivity::class.java))
            })
            row.addView(makeActionBtn("Mode Fokus (DND)", "#1E293B", Color.WHITE) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    activity.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                }
            })
            addView(row)
        }
        page.addView(hudCard)
    }

    // === 4. MACROS PAGE (GG GAME SPACE TOOLBOX + SHIZUKU/ADB BACKEND + TOUCH TIMELINE) ===
    private fun notifyOverlayTriggersChanged() {
        if (CyberXGameOverlayService.isServiceRunning) {
            try {
                activity.startService(Intent(activity, CyberXGameOverlayService::class.java).apply {
                    action = CyberXGameOverlayService.ACTION_REFRESH_TRIGGERS
                })
            } catch (_: Exception) {}
        }
    }

    private fun renderMacrosPage(page: LinearLayout) {
        val shizuku = CyberXShizukuBackend.getStatus(activity)
        val macros = storage.getMacros()

        // 1. Minimalist Header: Macro Studio + Shizuku Pill + Stop All + Buat Macro
        val header = makeGlassCard().apply {
            val topRow = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val titleCol = LinearLayout(activity).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            titleCol.addView(TextView(activity).apply {
                text = "Macro Studio"
                setTextColor(Color.WHITE)
                textSize = 16f
                setTypeface(null, android.graphics.Typeface.BOLD)
            })
            titleCol.addView(TextView(activity).apply {
                text = if (shizuku.binderAlive && shizuku.permissionGranted) "● ${shizuku.summary}" else "● ${shizuku.summary} (Ketuk untuk Setup)"
                setTextColor(Color.parseColor(if (shizuku.binderAlive && shizuku.permissionGranted) "#10B981" else "#F59E0B"))
                textSize = 11f
                setOnClickListener { openShizukuSetupDialog(shizuku) }
            })
            topRow.addView(titleCol)

            if (CyberXMacroPlayer.isAnyRunning()) {
                topRow.addView(makePillBtn("■ Stop All (${CyberXMacroPlayer.runningCount()})", "#991B1B") {
                    CyberXMacroPlayer.stopAll(activity)
                    selectTab("MACROS")
                })
            }
            topRow.addView(makePillBtn("Uji", "#1E293B") { openMacroTestLabDialog(macros) })
            topRow.addView(makePillBtn("+ Buat", "#E11D48") { openCreateMacroDialog(macros) })
            addView(topRow)

            if (CyberXMacroPlayer.isAnyRunning() || CyberXMacroPlayer.state == MacroEngineState.ERROR) {
                addView(TextView(activity).apply {
                    text = CyberXMacroPlayer.statusText
                    setTextColor(Color.parseColor(if (CyberXMacroPlayer.state == MacroEngineState.ERROR) "#FCA5A5" else "#38BDF8"))
                    textSize = 11f
                    setPadding(0, 6, 0, 0)
                })
            }
        }
        page.addView(header)

        // 2. Simple Macro Cards List
        if (macros.isEmpty()) {
            page.addView(makeGlassCard().apply {
                addView(makeCardTitle("Belum Ada Macro"))
                addView(makeSubText("Tekan '+ Buat' untuk merekam sentuhan di layar atau membuat Macro baru secara manual."))
            })
            return
        }

        for (m in macros) {
            val isRunning = CyberXMacroPlayer.isMacroRunning(m.id)
            val card = makeGlassCard().apply {
                val row1 = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val infoCol = LinearLayout(activity).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                infoCol.addView(TextView(activity).apply {
                    text = m.name
                    setTextColor(Color.WHITE)
                    textSize = 13.5f
                    setTypeface(null, android.graphics.Typeface.BOLD)
                })
                val loopTxt = if (m.loopCount == 0) "∞ Loop" else "${m.loopCount}x Loop"
                val statusLabel = when {
                    isRunning -> "BERJALAN"
                    m.enabled -> "AKTIF"
                    else -> "NONAKTIF"
                }
                val statusCol = when {
                    isRunning -> "#10B981"
                    m.enabled -> "#38BDF8"
                    else -> "#64748B"
                }
                infoCol.addView(TextView(activity).apply {
                    text = "$statusLabel • ${m.steps.size} langkah • $loopTxt • ${m.speedMultiplier}x • Trigger: ${if (m.showOnHud) "ON (${m.triggerMode.name})" else "OFF"}"
                    setTextColor(Color.parseColor(statusCol))
                    textSize = 10.5f
                })
                row1.addView(infoCol)

                row1.addView(makePillBtn(if (isRunning) "■ Stop" else "▶ Play", if (isRunning) "#991B1B" else "#10B981") {
                    if (isRunning) {
                        CyberXMacroPlayer.stopMacro(activity, m.id, m.vibrateOnTrigger)
                    } else {
                        CyberXMacroPlayer.play(activity, m)
                        if (CyberXMacroPlayer.state == MacroEngineState.ERROR) {
                            Toast.makeText(activity, CyberXMacroPlayer.statusText, Toast.LENGTH_LONG).show()
                        }
                    }
                    selectTab("MACROS")
                })
                row1.addView(makePillBtn("Edit", "#0284C7") { openMacroSubmenuDialog(m) })
                row1.addView(makePillBtn("Hapus", "#334155") {
                    AlertDialog.Builder(activity)
                        .setTitle("Hapus Macro '${m.name}'?")
                        .setPositiveButton("Hapus") { _, _ ->
                            CyberXMacroPlayer.stopMacro(activity, m.id, false)
                            val cur = storage.getMacros()
                            cur.removeAll { it.id == m.id }
                            storage.saveMacros(cur)
                            notifyOverlayTriggersChanged()
                            selectTab("MACROS")
                        }
                        .setNegativeButton("Batal", null)
                        .show()
                })
                addView(row1)
            }
            page.addView(card)
        }
    }

    private fun openShizukuSetupDialog(shizuku: ShizukuStatusReport) {
        val box = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 16, 28, 16) }
        box.addView(TextView(activity).apply {
            text = "${shizuku.summary}\n${shizuku.detail}"
            textSize = 12f
        })
        AlertDialog.Builder(activity)
            .setTitle("Backend Input ADB / Shizuku")
            .setView(box)
            .setPositiveButton("Minta Izin Shizuku") { _, _ ->
                if (!CyberXShizukuBackend.requestPermission()) {
                    Toast.makeText(activity, "Buka aplikasi Shizuku lalu jalankan dulu.", Toast.LENGTH_LONG).show()
                }
                selectTab("MACROS")
            }
            .setNeutralButton("Tes Input") { _, _ ->
                val (ok, msg) = CyberXShizukuBackend.execFastInput("input tap 10 10")
                Toast.makeText(activity, if (ok) "Tes Input Shizuku BERHASIL!" else "Gagal: $msg", Toast.LENGTH_LONG).show()
                selectTab("MACROS")
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    private fun openCreateMacroDialog(macros: MutableList<CyberXMacroProfile>) {
        val opts = arrayOf("● Rekam Sentuhan di Layar (Overlay)", "+ Buat Macro Kosong (Manual)", "Import Macro dari JSON")
        AlertDialog.Builder(activity)
            .setTitle("Buat Macro Baru")
            .setItems(opts) { _, idx ->
                when (idx) {
                    0 -> {
                        if (!Settings.canDrawOverlays(activity)) {
                            activity.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${activity.packageName}")))
                            Toast.makeText(activity, "Izinkan Overlay untuk merekam sentuhan!", Toast.LENGTH_LONG).show()
                        } else {
                            startOverlayServiceSafe()
                            Toast.makeText(activity, "Usap tepi layar -> tab MACROS -> tekan Rekam Sentuhan Baru!", Toast.LENGTH_LONG).show()
                        }
                    }
                    1 -> {
                        val inp = EditText(activity).apply { hint = "Nama Macro Baru" }
                        AlertDialog.Builder(activity).setTitle("Nama Macro").setView(inp)
                            .setPositiveButton("Buat") { _, _ ->
                                val nm = CyberXMacroProfile(
                                    id = UUID.randomUUID().toString(),
                                    name = inp.text.toString().trim().ifEmpty { "Macro ${macros.size + 1}" },
                                    buttonLabel = "M${macros.size + 1}"
                                )
                                macros.add(nm)
                                storage.saveMacros(macros)
                                storage.activeMacroId = nm.id
                                notifyOverlayTriggersChanged()
                                selectTab("MACROS")
                            }.setNegativeButton("Batal", null).show()
                    }
                    2 -> {
                        val inp = EditText(activity).apply { hint = "Tempel JSON Macro di sini..." }
                        AlertDialog.Builder(activity).setTitle("Import Macro JSON").setView(inp)
                            .setPositiveButton("Import") { _, _ ->
                                val res = storage.importMacroJson(inp.text.toString())
                                Toast.makeText(activity, if (res != null) "Macro '${res.name}' di-import!" else "JSON tidak valid", Toast.LENGTH_SHORT).show()
                                notifyOverlayTriggersChanged()
                                selectTab("MACROS")
                            }.setNegativeButton("Batal", null).show()
                    }
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun openMacroSubmenuDialog(m: CyberXMacroProfile) {
        val opts = arrayOf(
            "1. Edit Langkah Sentuhan (${m.steps.size} step)",
            "2. Pengaturan Macro (Loop, Speed, Delay, Status)",
            "3. Pengaturan Tombol Pemicu (Floating Trigger)",
            "4. Export JSON Macro"
        )
        AlertDialog.Builder(activity)
            .setTitle("Studio: ${m.name}")
            .setItems(opts) { _, which ->
                when (which) {
                    0 -> openMacroStepsEditorDialog(m)
                    1 -> openMacroSettingsDialog(m)
                    2 -> openMacroTriggerSettingsDialog(m)
                    3 -> {
                        val cm = activity.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("CyberX Macro", storage.exportMacroJson(m)))
                        Toast.makeText(activity, "JSON Macro disalin ke clipboard!", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    private fun openMacroStepsEditorDialog(m: CyberXMacroProfile) {
        val list = storage.getMacros()
        val target = list.firstOrNull { it.id == m.id } ?: return
        val box = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 12, 20, 12) }
        val scroll = ScrollView(activity).apply { layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 460) }
        val itemsCol = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }

        fun rebuild() {
            itemsCol.removeAllViews()
            target.steps.sortBy { it.order }
            for ((idx, s) in target.steps.withIndex()) {
                val row = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(4, 6, 4, 6) }
                row.addView(TextView(activity).apply {
                    text = "#${idx + 1} ${s.type.label} (${s.xPx.toInt()},${s.yPx.toInt()}) • Jeda ${s.delayFromPrevMs}ms • Dur ${s.durationMs}ms"
                    textSize = 11.5f
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                })
                row.addView(makePillBtn("Ubah", "#0284C7") {
                    val edBox = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 12, 24, 12) }
                    val edX = EditText(activity).apply { hint = "X (px)"; setText(s.xPx.toInt().toString()); inputType = android.text.InputType.TYPE_CLASS_NUMBER }
                    val edY = EditText(activity).apply { hint = "Y (px)"; setText(s.yPx.toInt().toString()); inputType = android.text.InputType.TYPE_CLASS_NUMBER }
                    val edDelay = EditText(activity).apply { hint = "Jeda (ms)"; setText(s.delayFromPrevMs.toString()); inputType = android.text.InputType.TYPE_CLASS_NUMBER }
                    val edDur = EditText(activity).apply { hint = "Durasi (ms)"; setText(s.durationMs.toString()); inputType = android.text.InputType.TYPE_CLASS_NUMBER }
                    edBox.addView(edX); edBox.addView(edY); edBox.addView(edDelay); edBox.addView(edDur)
                    AlertDialog.Builder(activity).setTitle("Edit Step #${idx + 1}").setView(edBox)
                        .setPositiveButton("Simpan") { _, _ ->
                            s.xPx = edX.text.toString().toFloatOrNull() ?: s.xPx
                            s.yPx = edY.text.toString().toFloatOrNull() ?: s.yPx
                            s.delayFromPrevMs = edDelay.text.toString().toLongOrNull() ?: s.delayFromPrevMs
                            s.durationMs = edDur.text.toString().toLongOrNull() ?: s.durationMs
                            storage.saveMacros(list)
                            rebuild()
                        }.setNegativeButton("Batal", null).show()
                })
                row.addView(makePillBtn("X", "#991B1B") {
                    target.steps.removeAt(idx)
                    target.steps.forEachIndexed { i, st -> st.order = i + 1 }
                    storage.saveMacros(list)
                    rebuild()
                })
                itemsCol.addView(row)
            }
        }
        rebuild()
        scroll.addView(itemsCol)
        box.addView(scroll)

        AlertDialog.Builder(activity)
            .setTitle("Edit Langkah: ${target.name}")
            .setView(box)
            .setPositiveButton("+ Tambah Tap") { _, _ ->
                target.steps.add(CyberXTouchStep(UUID.randomUUID().toString(), target.steps.size + 1, CyberXTouchType.TAP, 540f, 540f, 540f, 540f, 0L, 120L, 45L))
                storage.saveMacros(list)
                openMacroStepsEditorDialog(target)
            }
            .setNeutralButton("+ Tambah Swipe") { _, _ ->
                target.steps.add(CyberXTouchStep(UUID.randomUUID().toString(), target.steps.size + 1, CyberXTouchType.SWIPE, 400f, 600f, 700f, 600f, 0L, 120L, 180L))
                storage.saveMacros(list)
                openMacroStepsEditorDialog(target)
            }
            .setNegativeButton("Selesai") { _, _ -> selectTab("MACROS") }
            .show()
    }

    private fun openMacroSettingsDialog(m: CyberXMacroProfile) {
        val list = storage.getMacros()
        val target = list.firstOrNull { it.id == m.id } ?: return
        val box = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 14, 24, 14) }
        val edName = EditText(activity).apply { hint = "Nama Macro"; setText(target.name) }
        val cbEnabled = CheckBox(activity).apply { text = "Macro Aktif"; isChecked = target.enabled }
        val btnLoop = makeActionBtn("Loop: ${if (target.loopCount == 0) "∞ (Tak Terbatas)" else "${target.loopCount}x"}", "#1E293B", Color.WHITE) { b ->
            target.loopCount = when (target.loopCount) { 1 -> 3; 3 -> 5; 5 -> 10; 10 -> 0; else -> 1 }
            b.text = "Loop: ${if (target.loopCount == 0) "∞ (Tak Terbatas)" else "${target.loopCount}x"}"
        }
        val btnSpeed = makeActionBtn("Kecepatan: ${target.speedMultiplier}x", "#1E293B", Color.WHITE) { b ->
            target.speedMultiplier = when { target.speedMultiplier < 0.8f -> 1.0f; target.speedMultiplier < 1.2f -> 1.5f; target.speedMultiplier < 1.8f -> 2.0f; else -> 0.5f }
            b.text = "Kecepatan: ${target.speedMultiplier}x"
        }
        val btnDelay = makeActionBtn("Jeda Tambahan: +${target.extraDelayMs}ms", "#1E293B", Color.WHITE) { b ->
            target.extraDelayMs = when (target.extraDelayMs) { 0L -> 50L; 50L -> 150L; 150L -> 300L; else -> 0L }
            b.text = "Jeda Tambahan: +${target.extraDelayMs}ms"
        }
        box.addView(edName); box.addView(cbEnabled); box.addView(btnLoop); box.addView(btnSpeed); box.addView(btnDelay)

        AlertDialog.Builder(activity)
            .setTitle("Pengaturan Macro")
            .setView(box)
            .setPositiveButton("Simpan") { _, _ ->
                target.name = edName.text.toString().trim().ifEmpty { target.name }
                target.enabled = cbEnabled.isChecked
                storage.saveMacros(list)
                notifyOverlayTriggersChanged()
                selectTab("MACROS")
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun openMacroTriggerSettingsDialog(m: CyberXMacroProfile) {
        val list = storage.getMacros()
        val target = list.firstOrNull { it.id == m.id } ?: return
        val box = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 14, 24, 14) }
        val cbShow = CheckBox(activity).apply { text = "Tampilkan Tombol Pemicu Melayang"; isChecked = target.showOnHud }
        val cbVib = CheckBox(activity).apply { text = "Getaran Saat Mulai / Berhenti"; isChecked = target.vibrateOnTrigger }
        val edLabel = EditText(activity).apply { hint = "Label Pendek (maks 4 huruf)"; setText(target.buttonLabel) }

        val btnMode = makeActionBtn("Mode: ${target.triggerMode.label}", "#1E293B", Color.WHITE) { b ->
            target.triggerMode = if (target.triggerMode == MacroTriggerMode.TOGGLE) MacroTriggerMode.HOLD else MacroTriggerMode.TOGGLE
            b.text = "Mode: ${target.triggerMode.label}"
        }
        val icons = listOf("PLAY", "BOLT", "CROSSHAIR", "SHIELD", "FIRE", "STAR")
        val btnIcon = makeActionBtn("Ikon: ${target.triggerIconKey}", "#1E293B", Color.WHITE) { b ->
            val nxt = icons[(icons.indexOf(target.triggerIconKey) + 1) % icons.size]
            target.triggerIconKey = nxt
            b.text = "Ikon: $nxt"
        }
        val colors = listOf("#FF1744", "#00E5FF", "#10B981", "#F59E0B", "#A855F7", "#EC4899")
        val btnColor = makeActionBtn("Warna: ${target.colorHex}", target.colorHex, Color.WHITE) { b ->
            val nxt = colors[(colors.indexOf(target.colorHex) + 1) % colors.size]
            target.colorHex = nxt
            b.text = "Warna: $nxt"
            b.setBackgroundColor(Color.parseColor(nxt))
        }

        val tvSize = TextView(activity).apply { text = "Ukuran Tombol: ${target.sizeDp}dp"; textSize = 11.5f; setPadding(0, 8, 0, 2) }
        val sbSize = SeekBar(activity).apply {
            max = 60; progress = (target.sizeDp - 36).coerceIn(0, 60)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { target.sizeDp = 36 + p; tvSize.text = "Ukuran Tombol: ${target.sizeDp}dp" }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }

        val tvAlpha = TextView(activity).apply { text = "Transparansi: ${(target.alpha * 100).toInt()}%"; textSize = 11.5f; setPadding(0, 8, 0, 2) }
        val sbAlpha = SeekBar(activity).apply {
            max = 80; progress = ((target.alpha - 0.2f) * 100).toInt().coerceIn(0, 80)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { target.alpha = 0.2f + p / 100f; tvAlpha.text = "Transparansi: ${(target.alpha * 100).toInt()}%" }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }

        val tvPos = TextView(activity).apply { text = "Posisi: X=${(target.xNorm * 100).toInt()}% Y=${(target.yNorm * 100).toInt()}% (Bisa juga digeser langsung di game)"; textSize = 11f; setPadding(0, 6, 0, 2) }

        box.addView(cbShow); box.addView(cbVib); box.addView(edLabel)
        box.addView(btnMode); box.addView(btnIcon); box.addView(btnColor)
        box.addView(tvSize); box.addView(sbSize)
        box.addView(tvAlpha); box.addView(sbAlpha)
        box.addView(tvPos)

        val scroll = ScrollView(activity).apply { addView(box) }
        AlertDialog.Builder(activity)
            .setTitle("Pengaturan Tombol Pemicu")
            .setView(scroll)
            .setPositiveButton("Simpan & Terapkan") { _, _ ->
                target.showOnHud = cbShow.isChecked
                target.vibrateOnTrigger = cbVib.isChecked
                target.buttonLabel = edLabel.text.toString().trim().ifEmpty { "M" }
                storage.saveMacros(list)
                notifyOverlayTriggersChanged()
                selectTab("MACROS")
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun openMacroTestLabDialog(macros: List<CyberXMacroProfile>) {
        val box = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 14, 20, 14) }
        val tvLog = TextView(activity).apply {
            text = "Sentuh & geser area uji di bawah sambil menjalankan Macro untuk menguji input manual tidak terkunci."
            textSize = 11.5f
            setPadding(0, 0, 0, 8)
        }
        var touchMoves = 0
        val pad = TextView(activity).apply {
            text = "AREA UJI GESER & SENTUH MANUAL\n(Geser jari di sini)"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#1E293B"))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 240)
            setOnTouchListener { v, ev ->
                when (ev.action) {
                    MotionEvent.ACTION_DOWN -> {
                        v.setBackgroundColor(Color.parseColor("#0F3D3E"))
                        tvLog.text = "Manual DOWN (${ev.x.toInt()}, ${ev.y.toInt()}) • Macro aktif: ${CyberXMacroPlayer.runningCount()}"
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        touchMoves++
                        tvLog.text = "Manual GESER #$touchMoves (${ev.x.toInt()}, ${ev.y.toInt()}) • Macro aktif: ${CyberXMacroPlayer.runningCount()}"
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        v.setBackgroundColor(Color.parseColor("#1E293B"))
                        true
                    }
                    else -> false
                }
            }
        }
        val row = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 0) }
        val testMacro = macros.firstOrNull { it.enabled && it.steps.isNotEmpty() }
        row.addView(makeActionBtn("▶ Tes Macro", "#10B981", Color.BLACK) {
            if (testMacro == null) {
                Toast.makeText(activity, "Buat macro dengan minimal 1 langkah dulu!", Toast.LENGTH_SHORT).show()
            } else {
                CyberXMacroPlayer.play(activity, testMacro)
                tvLog.text = "Menjalankan '${testMacro.name}'... coba geser area di bawah!"
            }
        })
        row.addView(makeActionBtn("■ Stop All", "#991B1B", Color.WHITE) {
            CyberXMacroPlayer.stopAll(activity)
            tvLog.text = "Semua Macro dihentikan."
        })
        box.addView(tvLog); box.addView(pad); box.addView(row)
        AlertDialog.Builder(activity)
            .setTitle("Pengujian Macro (Non-Blocking)")
            .setView(box)
            .setNegativeButton("Tutup") { _, _ -> selectTab("MACROS") }
            .show()
    }

    private fun renderSettingsPage(page: LinearLayout) {
        page.addView(makeSectionTitle("Layanan & Lifecycle Aplikasi"))

        val svcCard = makeGlassCard().apply {
            addView(makeCardTitle("Kontrol Background & Overlay Service"))
            addView(makeSubText("Menutup overlay tidak mematikan service. Gunakan tombol di bawah untuk Start/Stop service tanpa perlu Force Stop."))
            val row1 = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 6) }
            row1.addView(makeActionBtn("Start Overlay Service", "#10B981", Color.BLACK) { startOverlayServiceSafe() })
            row1.addView(makeActionBtn("Stop Overlay Service", "#991B1B", Color.WHITE) { stopOverlayServiceSafe() })
            addView(row1)

            val row2 = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
            row2.addView(makeActionBtn(if (prefs.gameSpaceBatterySaver) "Hemat Baterai: ON (Bot Mati)" else "Hemat Baterai: OFF (Bot Aktif)", "#1E293B", Color.WHITE) { b ->
                prefs.gameSpaceBatterySaver = !prefs.gameSpaceBatterySaver
                if (prefs.gameSpaceBatterySaver) onStopBotService() else onStartBotService()
                b.text = if (prefs.gameSpaceBatterySaver) "Hemat Baterai: ON (Bot Mati)" else "Hemat Baterai: OFF (Bot Aktif)"
                refreshHeaderStatus()
            })
            addView(row2)
        }
        page.addView(svcCard)

        val soundCard = makeGlassCard().apply {
            addView(makeCardTitle("Efek Suara Mecha HUD"))
            addView(makeActionBtn(if (storage.mechaSoundEnabled) "Mecha Sound FX: ON" else "Mecha Sound FX: OFF", "#1E293B", Color.WHITE) { b ->
                storage.mechaSoundEnabled = !storage.mechaSoundEnabled
                CyberXSoundFx.playClick(storage.mechaSoundEnabled)
                b.text = if (storage.mechaSoundEnabled) "Mecha Sound FX: ON" else "Mecha Sound FX: OFF"
            })
        }
        page.addView(soundCard)

        val permCard = makeGlassCard().apply {
            addView(makeCardTitle("Izin Android"))
            val ovStatus = if (Settings.canDrawOverlays(activity)) "Diberikan" else "Belum"
            val accStatus = if (CyberXMacroService.instance != null) "Aktif" else "Belum"
            addView(makeSubText("Overlay: $ovStatus  •  Aksesibilitas Macro: $accStatus"))
            val row = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 0) }
            row.addView(makeActionBtn("Izin Overlay", "#0284C7", Color.WHITE) {
                activity.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${activity.packageName}")))
            })
            row.addView(makeActionBtn("Aksesibilitas", "#1E293B", Color.WHITE) {
                activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            })
            addView(row)
        }
        page.addView(permCard)

        val creditCard = makeGlassCard().apply {
            addView(makeCardTitle("Tentang CYBERX"))
            addView(TextView(activity).apply {
                text = "CYBERX Game Space v9.0\nCredit: https://tiktok.com/@newdodosadventure"
                autoLinkMask = android.text.util.Linkify.WEB_URLS
                setTextColor(Color.parseColor("#CBD5E1"))
                setLinkTextColor(Color.parseColor("#00E5FF"))
                textSize = 11f
            })
        }
        page.addView(creditCard)
    }

    private fun startOverlayServiceSafe() {
        if (!Settings.canDrawOverlays(activity)) {
            activity.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${activity.packageName}")))
            Toast.makeText(activity, "Izinkan tampilan di atas aplikasi lain terlebih dahulu", Toast.LENGTH_LONG).show()
            return
        }
        activity.startService(Intent(activity, CyberXGameOverlayService::class.java))
        Toast.makeText(activity, "Overlay Service diaktifkan! Usap tepi layar saat di game.", Toast.LENGTH_SHORT).show()
        refreshHeaderStatus()
    }

    private fun stopOverlayServiceSafe() {
        activity.stopService(Intent(activity, CyberXGameOverlayService::class.java))
        Toast.makeText(activity, "Overlay Service dihentikan dengan aman.", Toast.LENGTH_SHORT).show()
        refreshHeaderStatus()
    }

    private fun launchGameWithOverlay(pkg: String) {
        CyberXSoundFx.playClick(storage.mechaSoundEnabled)
        storage.recordGameLaunch(pkg)
        val st = storage.getGameStats()[pkg]
        if (st != null) {
            prefs.crosshairStyle = st.crosshairStyle
            prefs.perfMode = st.perfMode
            storage.activeHudProfileId = st.hudProfileId
        }
        if (Settings.canDrawOverlays(activity)) {
            activity.startService(Intent(activity, CyberXGameOverlayService::class.java))
        }
        val launch = activity.packageManager.getLaunchIntentForPackage(pkg)
        if (launch != null) activity.startActivity(launch)
    }

    private fun getDetectedGames(): List<ApplicationInfo> {
        val pm = activity.packageManager
        val pinned = mutableSetOf<String>()
        try {
            val arr = org.json.JSONArray(prefs.pinnedGamesJson)
            for (i in 0 until arr.length()) pinned.add(arr.getString(i))
        } catch (_: Exception) {}
        return pm.getInstalledApplications(0).filter { app ->
            val isGameCat = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && app.category == ApplicationInfo.CATEGORY_GAME) ||
                ((app.flags and ApplicationInfo.FLAG_IS_GAME) != 0) ||
                app.packageName.contains("freefire", true) ||
                app.packageName.contains("roblox", true) ||
                app.packageName.contains("mobile.legends", true) ||
                app.packageName.contains("pubg", true) ||
                app.packageName.contains("minecraft", true) ||
                pinned.contains(app.packageName)
            isGameCat && pm.getLaunchIntentForPackage(app.packageName) != null
        }.sortedBy { pm.getApplicationLabel(it).toString() }
    }

    private fun showAddGamesDialog() {
        val pm = activity.packageManager
        val userApps = pm.getInstalledApplications(0)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .sortedBy { pm.getApplicationLabel(it).toString() }
        val labels = userApps.map { pm.getApplicationLabel(it).toString() }.toTypedArray()
        AlertDialog.Builder(activity)
            .setTitle("Tambahkan Game ke Library")
            .setItems(labels) { _, idx ->
                val pkg = userApps[idx].packageName
                val arr = try { org.json.JSONArray(prefs.pinnedGamesJson) } catch (_: Exception) { org.json.JSONArray() }
                arr.put(pkg)
                prefs.pinnedGamesJson = arr.toString()
                selectTab("GAMES")
                Toast.makeText(activity, "${labels[idx]} ditambahkan!", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun makeSectionTitle(t: String): TextView = TextView(activity).apply {
        text = t; setTextColor(Color.WHITE); textSize = 15f; setTypeface(null, android.graphics.Typeface.BOLD)
        setPadding(0, 6, 0, 8)
    }

    private fun makeCardTitle(t: String): TextView = TextView(activity).apply {
        text = t; setTextColor(Color.parseColor("#FF4D6D")); textSize = 12.5f; setTypeface(null, android.graphics.Typeface.BOLD)
        setPadding(0, 0, 0, 4)
    }

    private fun makeSubText(t: String): TextView = TextView(activity).apply {
        text = t; setTextColor(Color.parseColor("#94A3B8")); textSize = 11f
        setPadding(0, 2, 0, 4)
    }

    private fun makeGlassCard(): LinearLayout = LinearLayout(activity).apply {
        orientation = LinearLayout.VERTICAL
        background = MechaChamferDrawable(Color.parseColor("#D90A0D18"), Color.parseColor("#80FF1744"), Color.parseColor("#8000E5FF"), 18f, 2f)
        setPadding(20, 16, 20, 16)
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 14 }
    }

    private fun makePillBtn(label: String, bgHex: String, txtColor: Int = Color.WHITE, onClick: () -> Unit): Button = Button(activity).apply {
        text = label; textSize = 10.5f; isAllCaps = false; setTextColor(txtColor)
        setBackgroundColor(Color.parseColor(bgHex))
        setPadding(20, 8, 20, 8); minHeight = 0; minimumHeight = 0
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginStart = 8 }
        setOnClickListener { onClick() }
    }

    private fun makeActionBtn(label: String, bgHex: String, txtColor: Int, onClick: (Button) -> Unit): Button = Button(activity).apply {
        text = label; textSize = 10.5f; isAllCaps = false; setTextColor(txtColor)
        setBackgroundColor(Color.parseColor(bgHex))
        setPadding(16, 10, 16, 10); minHeight = 0; minimumHeight = 0
        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 8 }
        setOnClickListener { onClick(this) }
    }
}
