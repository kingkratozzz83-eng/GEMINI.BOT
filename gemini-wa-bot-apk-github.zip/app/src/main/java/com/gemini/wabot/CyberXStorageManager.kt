package com.gemini.wabot

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

class CyberXStorageManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("cyberx_gamespace_v70", Context.MODE_PRIVATE)

    var edgeSide: String
        get() = prefs.getString("edge_side", "RIGHT") ?: "RIGHT"
        set(value) = prefs.edit().putString("edge_side", value).apply()

    var edgeHeightPct: Int
        get() = prefs.getInt("edge_height_pct", 22)
        set(value) = prefs.edit().putInt("edge_height_pct", value.coerceIn(15, 75)).apply()

    var edgeAlpha: Float
        get() = prefs.getFloat("edge_alpha", 0.28f)
        set(value) = prefs.edit().putFloat("edge_alpha", value.coerceIn(0.1f, 1.0f)).apply()

    var activeHudProfileId: String
        get() = prefs.getString("active_hud_profile", "default_hud") ?: "default_hud"
        set(value) = prefs.edit().putString("active_hud_profile", value).apply()

    var activeMacroId: String
        get() = prefs.getString("active_macro_id", "") ?: ""
        set(value) = prefs.edit().putString("active_macro_id", value).apply()

    var hudButtonsVisibleInGame: Boolean
        get() = prefs.getBoolean("hud_buttons_visible", false)
        set(value) = prefs.edit().putBoolean("hud_buttons_visible", value).apply()

    fun getGameStats(): MutableMap<String, CyberXGameStat> {
        val map = mutableMapOf<String, CyberXGameStat>()
        try {
            val arr = JSONArray(prefs.getString("game_stats", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val pkg = o.optString("pkg", "")
                if (pkg.isNotEmpty()) {
                    map[pkg] = CyberXGameStat(pkg, o.optLong("last", 0L), o.optInt("cnt", 0))
                }
            }
        } catch (_: Exception) {}
        return map
    }

    fun recordGameLaunch(pkg: String) {
        val map = getGameStats()
        val cur = map[pkg] ?: CyberXGameStat(pkg)
        cur.lastPlayedMs = System.currentTimeMillis()
        cur.playCount += 1
        map[pkg] = cur
        val arr = JSONArray()
        for (v in map.values) {
            arr.put(JSONObject().put("pkg", v.packageName).put("last", v.lastPlayedMs).put("cnt", v.playCount))
        }
        prefs.edit().putString("game_stats", arr.toString()).apply()
    }

    fun getMacros(): MutableList<CyberXMacroProfile> {
        val list = mutableListOf<CyberXMacroProfile>()
        try {
            val arr = JSONArray(prefs.getString("macros_list", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                list.add(CyberXMacroProfile.fromJson(arr.getJSONObject(i)))
            }
        } catch (_: Exception) {}
        if (list.isEmpty()) {
            // Tidak membuat tombol makro palsu; biarkan kosong sampai user merekam sendiri atau impor JSON!
            saveMacros(list)
        }
        return list
    }

    fun saveMacros(list: List<CyberXMacroProfile>) {
        val arr = JSONArray()
        for (m in list) arr.put(m.toJson())
        prefs.edit().putString("macros_list", arr.toString()).apply()
    }

    fun getHudProfiles(): MutableList<CyberXHudProfile> {
        val list = mutableListOf<CyberXHudProfile>()
        try {
            val arr = JSONArray(prefs.getString("hud_profiles", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                list.add(CyberXHudProfile.fromJson(arr.getJSONObject(i)))
            }
        } catch (_: Exception) {}
        if (list.isEmpty()) {
            list.add(
                CyberXHudProfile(
                    id = "default_hud",
                    name = "Preset Taktis 1",
                    buttons = mutableListOf(
                        CyberXHudButton("b1", "AIM", "ic_rm_ai", "#FF1744", 0.85f, 48, 0.14f, 0.30f, false, ""),
                        CyberXHudButton("b2", "FOKUS", "ic_rm_shield", "#00E5FF", 0.85f, 48, 0.14f, 0.46f, false, "macro_quick_dnd")
                    )
                )
            )
            saveHudProfiles(list)
        }
        return list
    }

    fun saveHudProfiles(list: List<CyberXHudProfile>) {
        val arr = JSONArray()
        for (p in list) arr.put(p.toJson())
        prefs.edit().putString("hud_profiles", arr.toString()).apply()
    }

    fun getActiveHudProfile(): CyberXHudProfile {
        val all = getHudProfiles()
        return all.firstOrNull { it.id == activeHudProfileId } ?: all.first()
    }

    fun exportActiveHudJson(): String = getActiveHudProfile().toJson().toString(2)

    fun exportMacroJson(macro: CyberXMacroProfile): String = macro.toJson().toString(2)

    fun importMacroJson(raw: String): CyberXMacroProfile? {
        return try {
            val obj = JSONObject(raw)
            val m = CyberXMacroProfile.fromJson(obj).deepCopy(
                newId = "macro_${System.currentTimeMillis()}",
                newName = obj.optString("name", "Imported Macro")
            )
            val all = getMacros()
            all.add(m)
            saveMacros(all)
            activeMacroId = m.id
            m
        } catch (_: Exception) {
            null
        }
    }

    fun importHudProfileJson(raw: String): Boolean {
        return try {
            val obj = JSONObject(raw)
            val imported = CyberXHudProfile.fromJson(obj).copy(
                id = "hud_${System.currentTimeMillis()}",
                name = obj.optString("name", "Imported HUD") + " (Import)"
            )
            val all = getHudProfiles()
            all.add(imported)
            saveHudProfiles(all)
            activeHudProfileId = imported.id
            true
        } catch (_: Exception) {
            false
        }
    }
}
