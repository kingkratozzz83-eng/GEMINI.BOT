package com.gemini.wabot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

class BotForegroundService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var nativeProcess: Process? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: android.net.wifi.WifiManager.WifiLock? = null

    companion object {
        const val ACTION_STOP_ALL = "com.gemini.wabot.ACTION_STOP_ALL"
    }

    override fun onCreate() {
        super.onCreate()
        acquireWakeLock()
        startForegroundWithNotification()
        startEmbeddedEngine()
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GeminiWaBot::EngineWakeLock").apply {
            setReferenceCounted(false)
            acquire(24 * 60 * 60 * 1000L)
        }
        val prefs = BotPrefsManager(this)
        if (!prefs.isPowerSaverMode) {
            try {
                val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as android.net.wifi.WifiManager
                @Suppress("DEPRECATION")
                wifiLock = wm.createWifiLock(android.net.wifi.WifiManager.WIFI_MODE_FULL_HIGH_PERF, "GeminiWaBot::EngineWifiLock").apply {
                    setReferenceCounted(false)
                    acquire()
                }
            } catch (_: Exception) {}
        }
        serviceScope.launch {
            while (true) {
                val p = BotPrefsManager(this@BotForegroundService)
                if (!p.isPowerSaverMode) {
                    try {
                        BotEngineClient.fetchStatus(this@BotForegroundService)
                    } catch (_: Exception) {}
                    delay(1500)
                } else {
                    // Mode Hemat Daya: Cukup andalkan WebSocket idle whatsmeow, tanpa polling agresif
                    delay(15000)
                }
            }
        }
    }

    private fun startForegroundWithNotification() {
        val channelId = "gemini_wa_bot_channel"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Gemini WhatsApp Bot Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Menjaga koneksi bot Multi-WA tetap berjalan"
            }
            nm.createNotificationChannel(channel)
        }

        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val prefs = BotPrefsManager(this)
        val modeLabel = if (prefs.connectionMode == "VPS") "Mode Cloud VPS Aktif" else "Mesin Lokal v6.1 Aktif"

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Gemini WhatsApp Bot ($modeLabel)")
            .setContentText("Model: ${prefs.geminiModel} • Siap membalas 24 Jam")
            .setSmallIcon(R.drawable.ic_bot_logo)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(1001, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(1001, notification)
        }
    }

    private fun startEmbeddedEngine() {
        serviceScope.launch {
            if (BotEngineClient.isLocalEngineRunning()) {
                BotEngineClient.syncConfig(this@BotForegroundService)
                return@launch
            }
            val nativeLibDir = applicationInfo.nativeLibraryDir
            val engineBinary = File(nativeLibDir, "libwabot_engine.so")
            if (engineBinary.exists()) {
                try {
                    engineBinary.setExecutable(true)
                    val caFile = prepareAndroidCaBundle()
                    val pb = ProcessBuilder(engineBinary.absolutePath, "8765")
                    pb.directory(filesDir)
                    val env = pb.environment()
                    env["SSL_CERT_DIR"] = "/system/etc/security/cacerts:/apex/com.android.conscrypt/cacerts"
                    if (caFile != null && caFile.exists() && caFile.length() > 1024L) {
                        env["SSL_CERT_FILE"] = caFile.absolutePath
                    }
                    pb.redirectErrorStream(true)
                    val proc = pb.start()
                    nativeProcess = proc
                    launch(Dispatchers.IO) {
                        try {
                            proc.inputStream.bufferedReader().useLines { lines ->
                                lines.forEach { line ->
                                    if (line.isNotBlank()) {
                                        BotEngineClient.log(line)
                                    }
                                }
                            }
                        } catch (_: Exception) {
                        }
                    }
                    delay(800)
                    BotEngineClient.syncConfig(this@BotForegroundService)
                } catch (e: Exception) {
                    BotEngineClient.log("Info Engine: ${e.message}")
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_ALL) {
            stopEverythingInternal()
            return START_NOT_STICKY
        }
        startForegroundWithNotification()
        startEmbeddedEngine()
        return START_STICKY
    }

    private fun prepareAndroidCaBundle(): File? {
        val outPem = File(filesDir, "cacert.pem")
        if (outPem.exists() && outPem.length() > 20_000L) {
            return outPem
        }
        return try {
            val sb = StringBuilder()
            val ks = java.security.KeyStore.getInstance("AndroidCAStore")
            ks.load(null, null)
            val aliases = ks.aliases()
            while (aliases.hasMoreElements()) {
                val alias = aliases.nextElement()
                val cert = ks.getCertificate(alias)
                if (cert != null) {
                    val b64 = android.util.Base64.encodeToString(cert.encoded, android.util.Base64.DEFAULT)
                    sb.append("-----BEGIN CERTIFICATE-----\n")
                    sb.append(b64)
                    if (!b64.endsWith("\n")) sb.append("\n")
                    sb.append("-----END CERTIFICATE-----\n")
                }
            }
            if (sb.length > 1024) {
                outPem.writeText(sb.toString())
                outPem
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun stopEverythingInternal() {
        try {
            nativeProcess?.destroyForcibly()
            nativeProcess = null
        } catch (_: Exception) {
        }
        wakeLock?.let {
            if (it.isHeld) it.release()
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopEverythingInternal()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
