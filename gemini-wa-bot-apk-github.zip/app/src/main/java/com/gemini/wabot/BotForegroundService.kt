package com.gemini.wabot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

class BotForegroundService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var nativeProcess: Process? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: android.net.wifi.WifiManager.WifiLock? = null
    private var lastLiveLine: String = "Menyiapkan koneksi bot..."
    private var failStreak: Int = 0

    companion object {
        const val ACTION_STOP_ALL = "com.gemini.wabot.ACTION_STOP_ALL"
        const val ACTION_TOGGLE_BOT = "com.gemini.wabot.ACTION_TOGGLE_BOT"
    }

    override fun onCreate() {
        super.onCreate()
        acquireWakeLock()
        startForegroundWithNotification()
        startEmbeddedEngine()
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GeminiWaBot::EngineWakeLock").apply {
            setReferenceCounted(false)
            acquire(24 * 60 * 60 * 1000L)
        }
        val prefs = BotPrefsManager(this)
        if (!prefs.isPowerSaverMode) {
            try {
                val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as android.net.wifi.WifiManager
                @Suppress("DEPRECATION")
                wifiLock = wm.createWifiLock(android.net.wifi.WifiManager.WIFI_MODE_FULL_HIGH_PERF, "GeminiWaBot::EngineWifiLock").apply {
                    setReferenceCounted(false)
                    acquire()
                }
            } catch (_: Exception) {}
        }
        serviceScope.launch {
            while (isActive) {
                val p = BotPrefsManager(this@BotForegroundService)
                try {
                    val st = BotEngineClient.fetchStatus(this@BotForegroundService)
                    if (st != null) {
                        failStreak = 0
                        val activeWa = st.sessions.count { it.loggedIn && it.active }
                        val stateBadge = if (p.isBotEnabled) "AKTIF" else "DIJEDA"
                        val modeStr = if (p.connectionMode == "VPS") "VPS" else "Lokal"
                        lastLiveLine = "[$stateBadge • $modeStr] $activeWa/${st.sessions.size} WA • ${st.totalReplied} Balasan AI"
                    } else {
                        failStreak++
                        lastLiveLine = "Watchdog: Mencoba menyambung ulang ($failStreak)..."
                        if (p.connectionMode == "LOCAL" && failStreak >= 3) {
                            failStreak = 0
                            BotEngineClient.log("Watchdog: Mesin lokal terputus, me-restart otomatis...")
                            startEmbeddedEngine()
                        }
                    }
                    updateNotification()
                } catch (_: Exception) {}
                delay(if (p.isPowerSaverMode) 15000L else 3500L)
            }
        }
    }

    private fun buildNotification(): Notification {
        val channelId = "gemini_wa_bot_channel"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "CYBERX Bot Background Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Menjaga koneksi bot Multi-WA tetap berjalan"
            }
            nm.createNotificationChannel(channel)
        }

        val pendingIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val togglePi = PendingIntent.getService(
            this, 1, Intent(this, BotForegroundService::class.java).apply { action = ACTION_TOGGLE_BOT },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopPi = PendingIntent.getService(
            this, 2, Intent(this, BotForegroundService::class.java).apply { action = ACTION_STOP_ALL },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val prefs = BotPrefsManager(this)
        val toggleLabel = if (prefs.isBotEnabled) "Jeda Bot" else "Aktifkan Bot"
        val titleStr = if (prefs.isBotEnabled) "CYBERX Bot Berjalan di Latar Belakang" else "CYBERX Bot Dijeda"

        return NotificationCompat.Builder(this, channelId)
            .setContentTitle(titleStr)
            .setContentText(lastLiveLine)
            .setSmallIcon(R.drawable.ic_bot_logo)
            .setContentIntent(pendingIntent)
            .addAction(0, toggleLabel, togglePi)
            .addAction(0, "Matikan", stopPi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun updateNotification() {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(1001, buildNotification())
        } catch (_: Exception) {}
    }

    private fun startForegroundWithNotification() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(1001, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(1001, notification)
        }
    }

    private fun startEmbeddedEngine() {
        serviceScope.launch {
            if (BotEngineClient.isLocalEngineRunning()) {
                BotEngineClient.syncConfig(this@BotForegroundService)
                return@launch
            }
            val nativeLibDir = applicationInfo.nativeLibraryDir
            val engineBinary = File(nativeLibDir, "libwabot_engine.so")
            if (engineBinary.exists()) {
                try {
                    engineBinary.setExecutable(true)
                    val caFile = prepareAndroidCaBundle()
                    val pb = ProcessBuilder(engineBinary.absolutePath, "8765")
                    pb.directory(filesDir)
                    val env = pb.environment()
                    env["SSL_CERT_DIR"] = "/system/etc/security/cacerts:/apex/com.android.conscrypt/cacerts"
                    if (caFile != null && caFile.exists() && caFile.length() > 1024L) {
                        env["SSL_CERT_FILE"] = caFile.absolutePath
                    }
                    pb.redirectErrorStream(true)
                    val proc = pb.start()
                    nativeProcess = proc
                    launch(Dispatchers.IO) {
                        try {
                            proc.inputStream.bufferedReader().useLines { lines ->
                                lines.forEach { line ->
                                    if (line.isNotBlank()) BotEngineClient.log(line)
                                }
                            }
                        } catch (_: Exception) {}
                    }
                    delay(800)
                    BotEngineClient.syncConfig(this@BotForegroundService)
                } catch (e: Exception) {
                    BotEngineClient.log("Info Engine: ${e.message}")
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_ALL -> {
                stopEverythingInternal()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE_BOT -> {
                val p = BotPrefsManager(this)
                p.isBotEnabled = !p.isBotEnabled
                serviceScope.launch { BotEngineClient.syncConfig(this@BotForegroundService) }
                updateNotification()
                return START_STICKY
            }
        }
        startForegroundWithNotification()
        startEmbeddedEngine()
        return START_STICKY
    }

    private fun prepareAndroidCaBundle(): File? {
        val outPem = File(filesDir, "cacert.pem")
        if (outPem.exists() && outPem.length() > 20_000L) return outPem
        return try {
            val sb = StringBuilder()
            val ks = java.security.KeyStore.getInstance("AndroidCAStore")
            ks.load(null, null)
            val aliases = ks.aliases()
            while (aliases.hasMoreElements()) {
                val alias = aliases.nextElement()
                val cert = ks.getCertificate(alias)
                if (cert != null) {
                    val b64 = android.util.Base64.encodeToString(cert.encoded, android.util.Base64.DEFAULT)
                    sb.append("-----BEGIN CERTIFICATE-----\n")
                    sb.append(b64)
                    if (!b64.endsWith("\n")) sb.append("\n")
                    sb.append("-----END CERTIFICATE-----\n")
                }
            }
            if (sb.length > 1024) { outPem.writeText(sb.toString()); outPem } else null
        } catch (_: Exception) { null }
    }

    private fun stopEverythingInternal() {
        try { nativeProcess?.destroyForcibly(); nativeProcess = null } catch (_: Exception) {}
        wakeLock?.let { if (it.isHeld) it.release() }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopEverythingInternal()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
