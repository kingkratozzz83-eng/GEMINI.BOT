package com.gemini.wabot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class MacroPoint(val label: String, var x: Float, var y: Float)

class CyberXMacroService : AccessibilityService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var macroJob: Job? = null

    companion object {
        @Volatile
        var instance: CyberXMacroService? = null
        @Volatile
        var isRunningMacro: Boolean = false
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        stopMacro()
    }

    override fun onDestroy() {
        stopMacro()
        scope.cancel()
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun startMacro(points: List<MacroPoint>, delayMs: Int) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N || points.isEmpty()) return
        macroJob?.cancel()
        isRunningMacro = true
        val safeDelay = delayMs.coerceIn(35, 1000).toLong()
        macroJob = scope.launch {
            while (isActive && isRunningMacro) {
                for (pt in points) {
                    if (!isActive || !isRunningMacro) break
                    val path = Path().apply { moveTo(pt.x, pt.y) }
                    // Durasi tap ultra-singkat 18ms agar jari tetap bebas menggeser kamera layar!
                    val stroke = GestureDescription.StrokeDescription(path, 0L, 18L)
                    val gesture = GestureDescription.Builder().addStroke(stroke).build()
                    dispatchGesture(gesture, null, null)
                    delay(safeDelay)
                }
            }
        }
    }

    fun dispatchSingleTap(x: Float, y: Float) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 20L)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    fun stopMacro() {
        isRunningMacro = false
        macroJob?.cancel()
        macroJob = null
    }
}
