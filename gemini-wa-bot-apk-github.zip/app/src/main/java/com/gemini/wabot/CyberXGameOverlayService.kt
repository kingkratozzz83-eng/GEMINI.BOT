package com.gemini.wabot

import android.app.ActivityManager
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class CyberXGameOverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var prefs: BotPrefsManager
    private lateinit var storage: CyberXStorageManager
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var hudJob: Job? = null

    private var edgeHandleLeft: View? = null
    private var edgeHandleRight: View? = null
    private var panelView: View? = null
    private var crosshairView: CrosshairOverlayView? = null
    private val activeHudButtonViews = mutableListOf<View>()

    private var isPanelOpen = false
    private var activeCategory = "GAMING"
    private var stopwatchRunning = false
    private var stopwatchSeconds = 0
    private var tvPanelTelemetry: TextView? = null
    private var tvPanelStopwatch: TextView? = null

    companion object {
        @Volatile
        var isServiceRunning = false
    }

    private val overlayType: Int
        get() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isServiceRunning = true
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = BotPrefsManager(this)
        storage = CyberXStorageManager(this)
        if (!Settings.canDrawOverlays(this)) {
            isServiceRunning = false
            stopSelf()
            return
        }
        setupEdgeGestureHandles()
        setupCrosshair()
        refreshCustomHudButtons()
        startTelemetryLoop()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        setupEdgeGestureHandles()
        refreshCustomHudButtons()
        if (isPanelOpen) {
            closePanelImmediate()
            openPanelSlide()
        }
    }

    override fun onDestroy() {
        isServiceRunning = false
        hudJob?.cancel()
        scope.cancel()
        removeViewSafe(edgeHandleLeft); edgeHandleLeft = null
        removeViewSafe(edgeHandleRight); edgeHandleRight = null
        closePanelImmediate()
        removeViewSafe(crosshairView); crosshairView = null
        removeViewSafe(inGameEditBar); inGameEditBar = null; clearCustomHudButtons()
        super.onDestroy()
    }

    private fun removeViewSafe(v: View?) {
        if (v != null) {
            try { wm.removeView(v) } catch (_: Exception) {}
        }
    }

    private fun setupEdgeGestureHandles() {
        removeViewSafe(edgeHandleLeft); edgeHandleLeft = null
        removeViewSafe(edgeHandleRight); edgeHandleRight = null
        val dm = resources.displayMetrics
        val hPx = (dm.heightPixels * (storage.edgeHeightPct / 100f)).toInt().coerceIn(80, 220)
        val wPx = (5 * dm.density).toInt()
        val side = storage.edgeSide

        if (side == "LEFT" || side == "BOTH") {
            val handle = createEdgeStrip(isLeft = true)
            val lp = WindowManager.LayoutParams(
                wPx, hPx, overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.START or Gravity.CENTER_VERTICAL }
            edgeHandleLeft = handle
            wm.addView(handle, lp)
        }
        if (side == "RIGHT" || side == "BOTH") {
            val handle = createEdgeStrip(isLeft = false)
            val lp = WindowManager.LayoutParams(
                wPx, hPx, overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
            edgeHandleRight = handle
            wm.addView(handle, lp)
        }
    }

    private fun createEdgeStrip(isLeft: Boolean): View {
        val v = View(this).apply {
            setBackgroundColor(Color.parseColor("#FF1744"))
            alpha = storage.edgeAlpha
        }
        var downX = 0f
        v.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { downX = ev.rawX; true }
                MotionEvent.ACTION_UP -> {
                    val dx = ev.rawX - downX
                    val swipedInward = if (isLeft) dx > 18f else dx < -18f
                    if (swipedInward || kotlin.math.abs(dx) < 16f) {
                        if (isPanelOpen) closePanelAnimated() else openPanelSlide()
                    }
                    true
                }
                else -> true
            }
        }
        return v
    }

    private fun setupCrosshair() {
        val cv = CrosshairOverlayView(this).apply { style = prefs.crosshairStyle }
        val lp = WindowManager.LayoutParams(
            140, 140, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        crosshairView = cv
        wm.addView(cv, lp)
    }

    private fun startTelemetryLoop() {
        hudJob?.cancel()
        hudJob = scope.launch {
            while (isActive) {
                if (stopwatchRunning) stopwatchSeconds++
                if (isPanelOpen) {
                    val bm = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                    val temp = (bm?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
                    val lvl = bm?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
                    val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                    val mi = ActivityManager.MemoryInfo()
                    am.getMemoryInfo(mi)
                    val freeMb = mi.availMem / (1024 * 1024)
                    tvPanelTelemetry?.text = "TEMP ${temp}°C  •  RAM ${freeMb} MB  •  BAT ${lvl}%"
                    tvPanelStopwatch?.text = "Stopwatch: %02d:%02d".format(stopwatchSeconds / 60, stopwatchSeconds % 60)
                }
                delay(1000)
            }
        }
    }

    private fun clearCustomHudButtons() {
        for (v in activeHudButtonViews) removeViewSafe(v)
        activeHudButtonViews.clear()
    }

    private var inGameEditBar: View? = null

    private fun enterInGameHudEditMode() {
        clearCustomHudButtons()
        removeViewSafe(inGameEditBar); inGameEditBar = null
        storage.hudButtonsVisibleInGame = true
        val profiles = storage.getHudProfiles()
        val profile = (profiles.firstOrNull { it.id == storage.activeHudProfileId } ?: profiles.first()).deepCopy()
        val dm = resources.displayMetrics
        val density = dm.density

        fun renderEditable() {
            clearCustomHudButtons()
            for (b in profile.buttons) {
                val px = (b.sizeDp * density).toInt()
                val box = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    alpha = b.alpha
                    background = CyberXGlassCardDrawable(Color.parseColor("#D90A0E18"), Color.parseColor(b.colorHex), px / 3f, 3f)
                }
                val iv = ImageView(this).apply {
                    setImageResource(CyberXIconMapper.resolveIconRes(b.iconKey))
                    layoutParams = LinearLayout.LayoutParams((px * 0.45f).toInt(), (px * 0.45f).toInt())
                }
                val tv = TextView(this).apply { text = b.label; setTextColor(Color.WHITE); textSize = 8.5f; gravity = Gravity.CENTER }
                box.addView(iv); box.addView(tv)
                val lp = WindowManager.LayoutParams(px, px, overlayType, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
                    gravity = Gravity.TOP or Gravity.START
                    x = (b.xNorm * dm.widthPixels - px / 2f).toInt().coerceIn(0, (dm.widthPixels - px).coerceAtLeast(0))
                    y = (b.yNorm * dm.heightPixels - px / 2f).toInt().coerceIn(0, (dm.heightPixels - px).coerceAtLeast(0))
                }
                var ix = 0; var iy = 0; var tx = 0f; var ty = 0f
                box.setOnTouchListener { _, ev ->
                    when (ev.action) {
                        MotionEvent.ACTION_DOWN -> { ix = lp.x; iy = lp.y; tx = ev.rawX; ty = ev.rawY; true }
                        MotionEvent.ACTION_MOVE -> {
                            lp.x = (ix + (ev.rawX - tx).toInt()).coerceIn(0, (dm.widthPixels - px).coerceAtLeast(0))
                            lp.y = (iy + (ev.rawY - ty).toInt()).coerceIn(0, (dm.heightPixels - px).coerceAtLeast(0))
                            try { wm.updateViewLayout(box, lp) } catch (_: Exception) {}
                            b.xNorm = (lp.x + px / 2f) / dm.widthPixels.toFloat()
                            b.yNorm = (lp.y + px / 2f) / dm.heightPixels.toFloat()
                            true
                        }
                        else -> true
                    }
                }
                activeHudButtonViews.add(box)
                wm.addView(box, lp)
            }
        }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#EB080B13"))
            setPadding(18, 10, 18, 10)
        }
        val btnAdd = Button(this).apply {
            text = "+ Tombol"; textSize = 10.5f; isAllCaps = false; setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#0284C7")); minHeight = 0; minimumHeight = 0
            setOnClickListener {
                profile.buttons.add(CyberXHudButton(java.util.UUID.randomUUID().toString(), "B${profile.buttons.size + 1}"))
                renderEditable()
            }
        }
        val btnSave = Button(this).apply {
            text = "Simpan & Kunci"; textSize = 10.5f; isAllCaps = false; setTextColor(Color.BLACK)
            setBackgroundColor(Color.parseColor("#10B981")); minHeight = 0; minimumHeight = 0
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginStart = 10 }
            setOnClickListener {
                val idx = profiles.indexOfFirst { it.id == profile.id }
                if (idx >= 0) profiles[idx] = profile else profiles.add(profile)
                storage.saveHudProfiles(profiles)
                removeViewSafe(inGameEditBar); inGameEditBar = null
                refreshCustomHudButtons()
                Toast.makeText(this@CyberXGameOverlayService, "HUD disimpan!", Toast.LENGTH_SHORT).show()
            }
        }
        bar.addView(btnAdd); bar.addView(btnSave)
        val blp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, overlayType, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 24
        }
        inGameEditBar = bar
        wm.addView(bar, blp)
        renderEditable()
        Toast.makeText(this, "Geser tombol HUD di atas game lalu tekan Simpan & Kunci!", Toast.LENGTH_LONG).show()
    }

    fun refreshCustomHudButtons() {
        clearCustomHudButtons()
        if (!storage.hudButtonsVisibleInGame) return
        val profile = storage.getActiveHudProfile()
        val dm = resources.displayMetrics
        val density = dm.density
        for (b in profile.buttons) {
            val px = (b.sizeDp * density).toInt()
            val container = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                alpha = b.alpha
                background = CyberXGlassCardDrawable(
                    fillColor = Color.parseColor("#BF090C14"),
                    borderColor = Color.parseColor(b.colorHex),
                    cornerPx = px / 3f,
                    strokePx = 2.5f
                )
                setOnClickListener {
                    if (b.linkedMacroId.isNotEmpty()) {
                        executeSafeMacro(b.linkedMacroId)
                    } else {
                        Toast.makeText(this@CyberXGameOverlayService, "Tombol HUD: ${b.label}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            val iv = ImageView(this).apply {
                setImageResource(CyberXIconMapper.resolveIconRes(b.iconKey))
                layoutParams = LinearLayout.LayoutParams((px * 0.45f).toInt(), (px * 0.45f).toInt())
            }
            val tv = TextView(this).apply {
                text = b.label
                setTextColor(Color.WHITE)
                textSize = 8.5f
                gravity = Gravity.CENTER
            }
            container.addView(iv); container.addView(tv)
            val lp = WindowManager.LayoutParams(
                px, px, overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = (b.xNorm * dm.widthPixels - px / 2f).toInt().coerceIn(0, (dm.widthPixels - px).coerceAtLeast(0))
                y = (b.yNorm * dm.heightPixels - px / 2f).toInt().coerceIn(0, (dm.heightPixels - px).coerceAtLeast(0))
            }
            activeHudButtonViews.add(container)
            wm.addView(container, lp)
        }
    }

    private fun executeSafeMacro(macroId: String) {
        val m = storage.getMacros().firstOrNull { it.id == macroId && it.enabled } ?: return
        scope.launch {
            for (act in m.actions) {
                when (act.type) {
                    CyberXActionType.DELAY -> delay(act.delayMs.toLong().coerceIn(20L, 2000L))
                    CyberXActionType.SHORTCUT_DND -> toggleDnd()
                    CyberXActionType.SHORTCUT_CROSSHAIR -> cycleCrosshair()
                    CyberXActionType.SHORTCUT_VOL_UP -> adjustVol(AudioManager.ADJUST_RAISE)
                    CyberXActionType.SHORTCUT_VOL_DOWN -> adjustVol(AudioManager.ADJUST_LOWER)
                    CyberXActionType.TAP_POINT -> {
                        val dm = resources.displayMetrics
                        CyberXMacroService.instance?.dispatchSingleTap(act.xNorm * dm.widthPixels, act.yNorm * dm.heightPixels)
                    }
                }
            }
        }
    }

    private fun closePanelImmediate() {
        isPanelOpen = false
        removeViewSafe(panelView)
        panelView = null
        tvPanelTelemetry = null
        tvPanelStopwatch = null
    }

    private fun closePanelAnimated() {
        isPanelOpen = false
        val p = panelView ?: return
        p.animate().alpha(0f).translationX(120f).setDuration(200).withEndAction {
            closePanelImmediate()
        }.start()
    }

    private fun openPanelSlide() {
        closePanelImmediate()
        isPanelOpen = true
        val dm = resources.displayMetrics
        val isPortrait = resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
        val panelW = if (isPortrait) (dm.widthPixels * 0.86f).toInt() else (dm.widthPixels * 0.44f).toInt().coerceIn(380, 560)
        val panelH = if (isPortrait) (dm.heightPixels * 0.62f).toInt() else (dm.heightPixels * 0.88f).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = CyberXGlassCardDrawable(
                fillColor = Color.parseColor("#EB080B13"),
                borderColor = Color.parseColor("#66FF1744"),
                cornerPx = 28f,
                strokePx = 2.5f
            )
            setPadding(22, 18, 22, 18)
        }

        // Header + Clear Close Button (Closes panel ONLY, keeps service running!)
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleTv = TextView(this).apply {
            text = "CYBERX OVERLAY"
            setTextColor(Color.WHITE)
            textSize = 13.5f
            typeface = android.graphics.Typeface.MONOSPACE
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val btnClose = Button(this).apply {
            text = "Tutup"
            textSize = 11f
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#E11D48"))
            setPadding(18, 6, 18, 6)
            minHeight = 0; minimumHeight = 0
            setOnClickListener { closePanelAnimated() }
        }
        header.addView(titleTv)
        header.addView(btnClose)
        root.addView(header)

        tvPanelTelemetry = TextView(this).apply {
            text = "Memuat telemetri..."
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 10.5f
            typeface = android.graphics.Typeface.MONOSPACE
            setPadding(0, 6, 0, 10)
        }
        root.addView(tvPanelTelemetry)

        // Category Tabs: GAMING | TOOLS | MACROS | HUD
        val tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val cats = listOf("GAMING", "TOOLS", "MACROS", "HUD")
        val contentScroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        val contentCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        contentScroll.addView(contentCol)

        fun renderCategoryContent() {
            contentCol.removeAllViews()
            tvPanelStopwatch = null
            when (activeCategory) {
                "GAMING" -> {
                    contentCol.addView(makeActionBtn("Mode Performa: ${prefs.perfMode.uppercase()}") { b ->
                        val next = when (prefs.perfMode) { "eco" -> "balance"; "balance" -> "turbo"; else -> "eco" }
                        prefs.perfMode = next
                        b.text = "Mode Performa: ${next.uppercase()}"
                    })
                    contentCol.addView(makeInfoNote("FPS Monitor: Android membatasi pembacaan FPS game lain tanpa akses sistem/Shizuku."))
                    contentCol.addView(makeActionBtn("Do Not Disturb (DND)") { toggleDnd() })
                    contentCol.addView(makeActionBtn("Volume +") { adjustVol(AudioManager.ADJUST_RAISE) })
                    contentCol.addView(makeActionBtn("Volume -") { adjustVol(AudioManager.ADJUST_LOWER) })
                    contentCol.addView(makeActionBtn("Pengaturan Kecerahan Layar") {
                        startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    })
                }
                "TOOLS" -> {
                    tvPanelStopwatch = TextView(this).apply {
                        text = "Stopwatch: %02d:%02d".format(stopwatchSeconds / 60, stopwatchSeconds % 60)
                        setTextColor(Color.WHITE)
                        textSize = 12f
                        setPadding(8, 8, 8, 8)
                    }
                    contentCol.addView(tvPanelStopwatch)
                    contentCol.addView(makeActionBtn(if (stopwatchRunning) "Stop Stopwatch" else "Mulai Stopwatch") { b ->
                        stopwatchRunning = !stopwatchRunning
                        if (!stopwatchRunning) stopwatchSeconds = 0
                        b.text = if (stopwatchRunning) "Stop Stopwatch" else "Mulai Stopwatch"
                    })
                    contentCol.addView(makeActionBtn("Crosshair: ${prefs.crosshairStyle}") { b ->
                        cycleCrosshair()
                        b.text = "Crosshair: ${prefs.crosshairStyle}"
                    })
                    contentCol.addView(makeInfoNote("Screenshot & Screen Recorder: Gunakan Quick Settings sistem Android agar aman di semua versi OS."))
                }
                "MACROS" -> {
                    val macros = storage.getMacros()
                    for (m in macros) {
                        contentCol.addView(makeActionBtn("${if (m.enabled) "[ON]" else "[OFF]"} ${m.name} (${m.actions.size} aksi)") {
                            executeSafeMacro(m.id)
                            Toast.makeText(this, "Menjalankan '${m.name}'", Toast.LENGTH_SHORT).show()
                        })
                    }
                    contentCol.addView(makeActionBtn("Buka Macro Manager di CYBERX") {
                        closePanelAnimated()
                        startActivity(Intent(this, MainActivity::class.java).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                            putExtra("cyberx_open_tab", "MACROS")
                        })
                    })
                }
                "HUD" -> {
                    contentCol.addView(makeActionBtn(if (storage.hudButtonsVisibleInGame) "Sembunyikan Tombol HUD" else "Tampilkan Tombol HUD") { b ->
                        storage.hudButtonsVisibleInGame = !storage.hudButtonsVisibleInGame
                        refreshCustomHudButtons()
                        b.text = if (storage.hudButtonsVisibleInGame) "Sembunyikan Tombol HUD" else "Tampilkan Tombol HUD"
                    })
                    contentCol.addView(makeActionBtn("Atur HUD Langsung di Game (Geser)") {
                        closePanelAnimated()
                        enterInGameHudEditMode()
                    })
                    contentCol.addView(makeActionBtn("Buka HUD Editor Lengkap") {
                        closePanelAnimated()
                        startActivity(Intent(this, CyberXHudEditorActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    })
                    val profiles = storage.getHudProfiles()
                    for (p in profiles) {
                        val mark = if (p.id == storage.activeHudProfileId) "✓ " else ""
                        contentCol.addView(makeActionBtn("${mark}Muat Profil: ${p.name}") {
                            storage.activeHudProfileId = p.id
                            refreshCustomHudButtons()
                            renderCategoryContent()
                        })
                    }
                }
            }
        }

        val tabBtns = mutableListOf<Button>()
        for (c in cats) {
            val tb = Button(this).apply {
                text = c
                textSize = 10f
                isAllCaps = false
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.parseColor(if (c == activeCategory) "#E11D48" else "#1E293B"))
                minHeight = 0; minimumHeight = 0
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 4 }
                setOnClickListener {
                    activeCategory = c
                    tabBtns.forEachIndexed { idx, b ->
                        b.setBackgroundColor(Color.parseColor(if (cats[idx] == c) "#E11D48" else "#1E293B"))
                    }
                    renderCategoryContent()
                }
            }
            tabBtns.add(tb)
            tabRow.addView(tb)
        }
        root.addView(tabRow)
        root.addView(contentScroll)
        renderCategoryContent()

        val lp = WindowManager.LayoutParams(
            panelW, panelH, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL; x = 18 }

        panelView = root
        root.alpha = 0f
        root.translationX = 140f
        wm.addView(root, lp)
        root.animate().alpha(1f).translationX(0f).setDuration(240).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun makeActionBtn(label: String, onClick: (Button) -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 11f
            isAllCaps = false
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
            setTextColor(Color.WHITE)
            background = CyberXGlassCardDrawable(Color.parseColor("#CC141B2D"), Color.parseColor("#33FFFFFF"), 14f, 1.5f)
            setPadding(20, 14, 20, 14)
            minHeight = 0; minimumHeight = 0
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = 8 }
            setOnClickListener { onClick(this) }
        }
    }

    private fun makeInfoNote(msg: String): TextView {
        return TextView(this).apply {
            text = msg
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 10f
            setPadding(12, 10, 12, 6)
        }
    }

    private fun toggleDnd() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && nm.isNotificationPolicyAccessGranted) {
            val cur = nm.currentInterruptionFilter
            val target = if (cur == NotificationManager.INTERRUPTION_FILTER_PRIORITY) NotificationManager.INTERRUPTION_FILTER_ALL else NotificationManager.INTERRUPTION_FILTER_PRIORITY
            nm.setInterruptionFilter(target)
            Toast.makeText(this, if (target == NotificationManager.INTERRUPTION_FILTER_PRIORITY) "DND Aktif" else "DND Mati", Toast.LENGTH_SHORT).show()
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun adjustVol(dir: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
    }

    private fun cycleCrosshair() {
        val next = when (prefs.crosshairStyle) { "OFF" -> "DOT"; "DOT" -> "CROSS"; "CROSS" -> "CIRCLE"; else -> "OFF" }
        prefs.crosshairStyle = next
        crosshairView?.style = next
        crosshairView?.invalidate()
    }

    class CrosshairOverlayView(context: Context) : View(context) {
        var style: String = "DOT"
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FF1744")
            strokeWidth = 3.5f
            style = Paint.Style.STROKE
        }
        override fun onDraw(canvas: Canvas) {
            if (style == "OFF") return
            val cx = width / 2f; val cy = height / 2f
            when (style) {
                "DOT" -> { paint.style = Paint.Style.FILL; canvas.drawCircle(cx, cy, 7f, paint) }
                "CROSS" -> {
                    paint.style = Paint.Style.STROKE
                    canvas.drawLine(cx - 22f, cy, cx - 7f, cy, paint)
                    canvas.drawLine(cx + 7f, cy, cx + 22f, cy, paint)
                    canvas.drawLine(cx, cy - 22f, cx, cy - 7f, paint)
                    canvas.drawLine(cx, cy + 7f, cx, cy + 22f, paint)
                    paint.style = Paint.Style.FILL; canvas.drawCircle(cx, cy, 3.5f, paint)
                }
                "CIRCLE" -> {
                    paint.style = Paint.Style.STROKE; canvas.drawCircle(cx, cy, 20f, paint)
                    paint.style = Paint.Style.FILL; canvas.drawCircle(cx, cy, 3.5f, paint)
                }
            }
        }
    }
}
