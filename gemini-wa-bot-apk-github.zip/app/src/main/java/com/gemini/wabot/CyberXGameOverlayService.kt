package com.gemini.wabot

import android.app.ActivityManager
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class CyberXGameOverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var prefs: BotPrefsManager
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var hudJob: Job? = null

    private var triggerView: View? = null
    private var menuView: View? = null
    private var crosshairView: CrosshairOverlayView? = null
    private var telemetryView: TextView? = null
    private val markerViews = mutableListOf<View>()
    private var isEditingHud = false

    private val overlayType: Int
        get() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = BotPrefsManager(this)
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        setupTriggerBubble()
        setupCrosshair()
        setupTelemetryHud()
    }

    override fun onDestroy() {
        hudJob?.cancel()
        scope.cancel()
        CyberXMacroService.instance?.stopMacro()
        removeViewSafe(triggerView)
        removeViewSafe(menuView)
        removeViewSafe(crosshairView)
        removeViewSafe(telemetryView)
        clearMarkers()
        super.onDestroy()
    }

    private fun removeViewSafe(v: View?) {
        if (v != null) {
            try { wm.removeView(v) } catch (_: Exception) {}
        }
    }

    private fun setupTriggerBubble() {
        val iv = ImageView(this).apply {
            setImageResource(R.drawable.ic_rm_server)
            setBackgroundColor(Color.parseColor("#E6090D16"))
            setPadding(18, 18, 18, 18)
        }
        val lp = WindowManager.LayoutParams(
            120, 120, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 220
        }
        var initX = 0; var initY = 0; var touchX = 0f; var touchY = 0f; var moved = false
        iv.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    initX = lp.x; initY = lp.y; touchX = ev.rawX; touchY = ev.rawY; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - touchX).toInt()
                    val dy = (ev.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) > 10 || kotlin.math.abs(dy) > 10) moved = true
                    lp.x = initX + dx; lp.y = initY + dy
                    try { wm.updateViewLayout(iv, lp) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) toggleInGameMenu()
                    true
                }
                else -> false
            }
        }
        triggerView = iv
        wm.addView(iv, lp)
    }

    private fun setupCrosshair() {
        val cv = CrosshairOverlayView(this).apply {
            style = prefs.crosshairStyle
        }
        val lp = WindowManager.LayoutParams(
            160, 160, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }
        crosshairView = cv
        wm.addView(cv, lp)
    }

    private fun setupTelemetryHud() {
        val tv = TextView(this).apply {
            setBackgroundColor(Color.parseColor("#99060810"))
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 10.5f
            setPadding(16, 8, 16, 8)
            typeface = android.graphics.Typeface.MONOSPACE
            visibility = if (prefs.showThermalHud) View.VISIBLE else View.GONE
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 24
            y = 16
        }
        telemetryView = tv
        wm.addView(tv, lp)
        hudJob = scope.launch {
            while (isActive) {
                val bm = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val temp = (bm?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
                val lvl = bm?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
                val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val mi = ActivityManager.MemoryInfo()
                am.getMemoryInfo(mi)
                val freeMb = mi.availMem / (1024 * 1024)
                val macroOn = if (CyberXMacroService.isRunningMacro) "MAKRO: ON" else "MAKRO: OFF"
                val warn = if (temp >= 43f) " PANAS!" else ""
                tv.text = "CYBERX | ${temp}°C$warn | BAT ${lvl}% | RAM ${freeMb}MB | $macroOn"
                tv.setTextColor(if (temp >= 43f) Color.parseColor("#FF1744") else Color.parseColor("#00E5FF"))
                delay(2500)
            }
        }
    }

    private fun toggleInGameMenu() {
        if (menuView != null) {
            removeViewSafe(menuView)
            menuView = null
            return
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F2070A12"))
            setPadding(24, 20, 24, 20)
        }
        val title = TextView(this).apply {
            text = "CYBERX IN-GAME MENU"
            setTextColor(Color.parseColor("#FF1744"))
            textSize = 13f
            typeface = android.graphics.Typeface.MONOSPACE
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val btnMacro = Button(this).apply {
            text = if (CyberXMacroService.isRunningMacro) "STOP MAKRO GLOO WALL" else "MULAI MAKRO GLOO WALL"
            setBackgroundColor(if (CyberXMacroService.isRunningMacro) Color.parseColor("#EF4444") else Color.parseColor("#10B981"))
            setTextColor(Color.BLACK)
            textSize = 11.5f
            setOnClickListener {
                val svc = CyberXMacroService.instance
                if (svc == null) {
                    Toast.makeText(this@CyberXGameOverlayService, "Aktifkan Layanan Aksesibilitas CyberX Macro dulu!", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                if (CyberXMacroService.isRunningMacro) {
                    svc.stopMacro()
                    text = "MULAI MAKRO GLOO WALL"
                    setBackgroundColor(Color.parseColor("#10B981"))
                } else {
                    if (isEditingHud) {
                        isEditingHud = false
                        clearMarkers()
                    }
                    svc.startMacro(loadMacroPoints(), prefs.macroDelayMs)
                    text = "STOP MAKRO GLOO WALL"
                    setBackgroundColor(Color.parseColor("#EF4444"))
                }
            }
        }
        val btnEditHud = Button(this).apply {
            text = if (isEditingHud) "SIMPAN & KUNCI TITIK HUD" else "ATUR TITIK HUD MAKRO (GESER)"
            setBackgroundColor(Color.parseColor("#1E293B"))
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 11f
            setOnClickListener {
                isEditingHud = !isEditingHud
                if (isEditingHud) {
                    CyberXMacroService.instance?.stopMacro()
                    showDraggableMarkers()
                    text = "SIMPAN & KUNCI TITIK HUD"
                    Toast.makeText(this@CyberXGameOverlayService, "Geser titik ke tombol Gloo Wall / Jongkok / Tembak!", Toast.LENGTH_SHORT).show()
                } else {
                    clearMarkers()
                    text = "ATUR TITIK HUD MAKRO (GESER)"
                    Toast.makeText(this@CyberXGameOverlayService, "Posisi titik makro disimpan & dikunci!", Toast.LENGTH_SHORT).show()
                }
            }
        }
        val btnDelay = Button(this).apply {
            text = "JEDA MAKRO: ${prefs.macroDelayMs} ms (TAP UBAH)"
            setBackgroundColor(Color.parseColor("#1E293B"))
            setTextColor(Color.WHITE)
            textSize = 11f
            setOnClickListener {
                val next = when (prefs.macroDelayMs) {
                    45 -> 70
                    70 -> 100
                    100 -> 140
                    else -> 45
                }
                prefs.macroDelayMs = next
                text = "JEDA MAKRO: ${next} ms (TAP UBAH)"
            }
        }
        val btnCross = Button(this).apply {
            text = "CROSSHAIR: ${prefs.crosshairStyle}"
            setBackgroundColor(Color.parseColor("#1E293B"))
            setTextColor(Color.parseColor("#FF4D6D"))
            textSize = 11f
            setOnClickListener {
                val next = when (prefs.crosshairStyle) {
                    "OFF" -> "DOT"
                    "DOT" -> "CROSS"
                    "CROSS" -> "CIRCLE"
                    else -> "OFF"
                }
                prefs.crosshairStyle = next
                crosshairView?.style = next
                crosshairView?.invalidate()
                text = "CROSSHAIR: $next"
            }
        }
        val btnDnd = Button(this).apply {
            text = "MODE FOKUS (DND)"
            setBackgroundColor(Color.parseColor("#1E293B"))
            setTextColor(Color.parseColor("#FDE047"))
            textSize = 11f
            setOnClickListener {
                val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && nm.isNotificationPolicyAccessGranted) {
                    val cur = nm.currentInterruptionFilter
                    val target = if (cur == NotificationManager.INTERRUPTION_FILTER_PRIORITY) NotificationManager.INTERRUPTION_FILTER_ALL else NotificationManager.INTERRUPTION_FILTER_PRIORITY
                    nm.setInterruptionFilter(target)
                    Toast.makeText(this@CyberXGameOverlayService, if (target == NotificationManager.INTERRUPTION_FILTER_PRIORITY) "Mode Fokus DND AKTIF!" else "Mode Fokus DND MATI", Toast.LENGTH_SHORT).show()
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
        }
        val btnClose = Button(this).apply {
            text = "TUTUP MENU"
            setBackgroundColor(Color.parseColor("#E11D48"))
            setTextColor(Color.WHITE)
            textSize = 11f
            setOnClickListener {
                removeViewSafe(menuView)
                menuView = null
            }
        }
        val lpBtn = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = 8 }
        box.addView(title)
        box.addView(btnMacro, lpBtn)
        box.addView(btnEditHud, lpBtn)
        box.addView(btnDelay, lpBtn)
        box.addView(btnCross, lpBtn)
        box.addView(btnDnd, lpBtn)
        box.addView(btnClose, lpBtn)

        val mlp = WindowManager.LayoutParams(
            560, WindowManager.LayoutParams.WRAP_CONTENT, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        menuView = box
        wm.addView(box, mlp)
    }

    private fun loadMacroPoints(): MutableList<MacroPoint> {
        val out = mutableListOf<MacroPoint>()
        try {
            val arr = JSONArray(prefs.macroPointsJson)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(MacroPoint(o.optString("label", "${i+1}"), o.optDouble("x", 600.0).toFloat(), o.optDouble("y", 400.0).toFloat()))
            }
        } catch (_: Exception) {}
        if (out.isEmpty()) {
            out.add(MacroPoint("1:Gloo", 350f, 520f))
            out.add(MacroPoint("2:Jongkok", 1180f, 540f))
            out.add(MacroPoint("3:Pasang", 1320f, 450f))
            saveMacroPoints(out)
        }
        return out
    }

    private fun saveMacroPoints(pts: List<MacroPoint>) {
        val arr = JSONArray()
        for (p in pts) {
            arr.put(JSONObject().put("label", p.label).put("x", p.x.toDouble()).put("y", p.y.toDouble()))
        }
        prefs.macroPointsJson = arr.toString()
    }

    private fun clearMarkers() {
        for (v in markerViews) removeViewSafe(v)
        markerViews.clear()
    }

    private fun showDraggableMarkers() {
        clearMarkers()
        val pts = loadMacroPoints()
        pts.forEachIndexed { idx, pt ->
            val tv = TextView(this).apply {
                text = pt.label
                setTextColor(Color.WHITE)
                textSize = 10f
                gravity = Gravity.CENTER
                setBackgroundColor(Color.parseColor("#CCFF1744"))
                setPadding(14, 14, 14, 14)
            }
            val mlp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = pt.x.toInt() - 40
                y = pt.y.toInt() - 40
            }
            var ix = 0; var iy = 0; var tx = 0f; var ty = 0f
            tv.setOnTouchListener { _, ev ->
                when (ev.action) {
                    MotionEvent.ACTION_DOWN -> { ix = mlp.x; iy = mlp.y; tx = ev.rawX; ty = ev.rawY; true }
                    MotionEvent.ACTION_MOVE -> {
                        mlp.x = ix + (ev.rawX - tx).toInt()
                        mlp.y = iy + (ev.rawY - ty).toInt()
                        try { wm.updateViewLayout(tv, mlp) } catch (_: Exception) {}
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        pts[idx].x = ev.rawX
                        pts[idx].y = ev.rawY
                        saveMacroPoints(pts)
                        true
                    }
                    else -> false
                }
            }
            markerViews.add(tv)
            wm.addView(tv, mlp)
        }
    }

    class CrosshairOverlayView(context: Context) : View(context) {
        var style: String = "DOT"
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FF1744")
            strokeWidth = 4f
            style = Paint.Style.STROKE
        }
        override fun onDraw(canvas: Canvas) {
            if (style == "OFF") return
            val cx = width / 2f
            val cy = height / 2f
            when (style) {
                "DOT" -> {
                    paint.style = Paint.Style.FILL
                    canvas.drawCircle(cx, cy, 8f, paint)
                }
                "CROSS" -> {
                    paint.style = Paint.Style.STROKE
                    canvas.drawLine(cx - 26f, cy, cx - 8f, cy, paint)
                    canvas.drawLine(cx + 8f, cy, cx + 26f, cy, paint)
                    canvas.drawLine(cx, cy - 26f, cx, cy - 8f, paint)
                    canvas.drawLine(cx, cy + 8f, cx, cy + 26f, paint)
                    paint.style = Paint.Style.FILL
                    canvas.drawCircle(cx, cy, 4f, paint)
                }
                "CIRCLE" -> {
                    paint.style = Paint.Style.STROKE
                    canvas.drawCircle(cx, cy, 24f, paint)
                    paint.style = Paint.Style.FILL
                    canvas.drawCircle(cx, cy, 4f, paint)
                }
            }
        }
    }
}
