package com.gemini.wabot

import android.util.DisplayMetrics
import android.app.ActivityManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.pm.ServiceInfo
import androidx.core.app.NotificationCompat
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class CyberXGameOverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var prefs: BotPrefsManager
    private lateinit var storage: CyberXStorageManager
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var hudJob: Job? = null

    private var edgeHandleLeft: View? = null
    private var edgeHandleRight: View? = null
    private var panelView: View? = null
    private var crosshairView: CrosshairOverlayView? = null
    private var crosshairLp: WindowManager.LayoutParams? = null
    private var crosshairStepPx: Int = 4
    private var nightDimmerView: View? = null

    private fun applyNightDimmerOverlay() {
        removeViewSafe(nightDimmerView); nightDimmerView = null
        if (storage.nightDimmerAlpha <= 0.01f) return
        val dv = View(this).apply {
            setBackgroundColor(Color.BLACK)
            alpha = storage.nightDimmerAlpha
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        nightDimmerView = dv
        wm.addView(dv, lp)
    }
    private val activeHudButtonViews = mutableListOf<View>()

    private var isPanelOpen = false
    private var activeCategory = "GAMING"
    private var stopwatchRunning = false
    private var stopwatchSeconds = 0
    private var tvPanelTelemetry: TextView? = null
    private var tvPanelStopwatch: TextView? = null

    private val activeMacroTriggerViews = mutableListOf<View>()
    private var macroStatusPill: View? = null

    companion object {
        @Volatile
        var isServiceRunning = false
        const val ACTION_STOP_ALL_MACROS = "com.gemini.wabot.ACTION_STOP_ALL_MACROS"
        const val ACTION_REFRESH_TRIGGERS = "com.gemini.wabot.ACTION_REFRESH_TRIGGERS"
    }

    private val overlayType: Int
        get() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isServiceRunning = true
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = BotPrefsManager(this)
        storage = CyberXStorageManager(this)
        if (!Settings.canDrawOverlays(this)) {
            isServiceRunning = false
            stopSelf()
            return
        }
        startOverlayForeground()
        setupEdgeGestureHandles()
        setupCrosshair()
        refreshCustomHudButtons()
        refreshMacroFloatingTriggers()
        CyberXMacroPlayer.onStateChanged = {
            refreshMacroFloatingTriggers()
            updateMacroStatusIndicator()
            updateOverlayNotification()
        }
        startTelemetryLoop()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_ALL_MACROS -> CyberXMacroPlayer.stopAll(this)
            ACTION_REFRESH_TRIGGERS -> {
                refreshCustomHudButtons()
                refreshMacroFloatingTriggers()
                updateMacroStatusIndicator()
            }
        }
        return START_STICKY
    }

    private fun startOverlayForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel("cyberx_overlay_ch", "CYBERX Game & Macro Engine", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(ch)
        }
        val notif = buildOverlayNotification()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(1002, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            } else {
                startForeground(1002, notif)
            }
        } catch (_: Exception) {}
    }

    private fun buildOverlayNotification(): android.app.Notification {
        val stopIntent = Intent(this, CyberXGameOverlayService::class.java).apply { action = ACTION_STOP_ALL_MACROS }
        val stopPi = PendingIntent.getService(this, 202, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val runningCnt = CyberXMacroPlayer.runningCount()
        val contentTxt = if (runningCnt > 0) "$runningCnt Macro aktif: ${CyberXMacroPlayer.statusText}" else "Overlay & Macro Studio siap digunakan"
        return NotificationCompat.Builder(this, "cyberx_overlay_ch")
            .setSmallIcon(R.drawable.ic_rm_play)
            .setContentTitle("CYBERX Game Space Engine")
            .setContentText(contentTxt)
            .setOngoing(true)
            .setSilent(true)
            .addAction(0, "Stop All Macro", stopPi)
            .build()
    }

    private fun updateOverlayNotification() {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(1002, buildOverlayNotification())
        } catch (_: Exception) {}
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        setupEdgeGestureHandles()
        updateCrosshairPosition()
        refreshCustomHudButtons()
        refreshMacroFloatingTriggers()
        if (isPanelOpen) {
            closePanelImmediate()
            openPanelSlide()
        }
    }

    override fun onDestroy() {
        isServiceRunning = false
        hudJob?.cancel()
        scope.cancel()
        removeViewSafe(edgeHandleLeft); edgeHandleLeft = null
        removeViewSafe(edgeHandleRight); edgeHandleRight = null
        closePanelImmediate()
        removeViewSafe(crosshairView); removeViewSafe(nightDimmerView); nightDimmerView = null; crosshairView = null; crosshairLp = null
        CyberXMacroPlayer.onStateChanged = null
        removeViewSafe(floatingMacroBar); floatingMacroBar = null
        removeViewSafe(macroStatusPill); macroStatusPill = null
        stopTouchRecordingOverlay(false); removeViewSafe(inGameEditBar); inGameEditBar = null
        clearCustomHudButtons()
        clearMacroFloatingTriggers()
        super.onDestroy()
    }

    private fun removeViewSafe(v: View?) {
        if (v != null) {
            try { wm.removeView(v) } catch (_: Exception) {}
        }
    }

    private fun setupEdgeGestureHandles() {
        removeViewSafe(edgeHandleLeft); edgeHandleLeft = null
        removeViewSafe(edgeHandleRight); edgeHandleRight = null
        val dm = resources.displayMetrics
        val hPx = (dm.heightPixels * (storage.edgeHeightPct / 100f)).toInt().coerceIn(80, 220)
        val wPx = (5 * dm.density).toInt()
        val side = storage.edgeSide

        if (side == "LEFT" || side == "BOTH") {
            val handle = createEdgeStrip(isLeft = true)
            val lp = WindowManager.LayoutParams(
                wPx, hPx, overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.START or Gravity.CENTER_VERTICAL }
            edgeHandleLeft = handle
            wm.addView(handle, lp)
        }
        if (side == "RIGHT" || side == "BOTH") {
            val handle = createEdgeStrip(isLeft = false)
            val lp = WindowManager.LayoutParams(
                wPx, hPx, overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
            edgeHandleRight = handle
            wm.addView(handle, lp)
        }
    }

    private fun createEdgeStrip(isLeft: Boolean): View {
        val v = View(this).apply {
            setBackgroundColor(Color.parseColor("#FF1744"))
            alpha = storage.edgeAlpha
        }
        var downX = 0f
        v.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { downX = ev.rawX; true }
                MotionEvent.ACTION_UP -> {
                    val dx = ev.rawX - downX
                    val swipedInward = if (isLeft) dx > 18f else dx < -18f
                    if (swipedInward || kotlin.math.abs(dx) < 16f) {
                        if (isPanelOpen) closePanelAnimated() else openPanelSlide()
                    }
                    true
                }
                else -> true
            }
        }
        return v
    }

    private fun setupCrosshair() {
        val cv = CrosshairOverlayView(this).apply { style = prefs.crosshairStyle }
        val lp = WindowManager.LayoutParams(
            140, 140, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        crosshairView = cv
        crosshairLp = lp
        computeCrosshairCoords(lp)
        wm.addView(cv, lp)
    }

    private fun computeCrosshairCoords(lp: WindowManager.LayoutParams) {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        lp.x = (dm.widthPixels / 2) - 70 + prefs.crosshairOffsetX
        lp.y = (dm.heightPixels / 2) - 70 + prefs.crosshairOffsetY
    }

    private fun updateCrosshairPosition() {
        val cv = crosshairView ?: return
        val lp = crosshairLp ?: return
        computeCrosshairCoords(lp)
        try { wm.updateViewLayout(cv, lp) } catch (_: Exception) {}
    }

    private fun startTelemetryLoop() {
        hudJob?.cancel()
        hudJob = scope.launch {
            while (isActive) {
                if (stopwatchRunning) stopwatchSeconds++
                if (isPanelOpen) {
                    val bm = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                    val temp = (bm?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
                    val lvl = bm?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
                    val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                    val mi = ActivityManager.MemoryInfo()
                    am.getMemoryInfo(mi)
                    val freeMb = mi.availMem / (1024 * 1024)
                    tvPanelTelemetry?.text = "TEMP ${temp}°C  •  RAM ${freeMb} MB  •  BAT ${lvl}%"
                    tvPanelStopwatch?.text = "Stopwatch: %02d:%02d".format(stopwatchSeconds / 60, stopwatchSeconds % 60)
                }
                delay(1000)
            }
        }
    }

    private fun clearCustomHudButtons() {
        for (v in activeHudButtonViews) removeViewSafe(v)
        activeHudButtonViews.clear()
    }

    private var inGameEditBar: View? = null

    private fun enterInGameHudEditMode() {
        clearCustomHudButtons()
        removeViewSafe(inGameEditBar); inGameEditBar = null
        storage.hudButtonsVisibleInGame = true
        val profiles = storage.getHudProfiles()
        val profile = (profiles.firstOrNull { it.id == storage.activeHudProfileId } ?: profiles.first()).deepCopy()
        val dm = resources.displayMetrics
        val density = dm.density

        fun renderEditable() {
            clearCustomHudButtons()
            for (b in profile.buttons) {
                val px = (b.sizeDp * density).toInt()
                val box = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    alpha = b.alpha
                    background = CyberXGlassCardDrawable(Color.parseColor("#D90A0E18"), Color.parseColor(b.colorHex), px / 3f, 3f)
                }
                val iv = ImageView(this).apply {
                    setImageResource(CyberXIconMapper.resolveIconRes(b.iconKey))
                    layoutParams = LinearLayout.LayoutParams((px * 0.45f).toInt(), (px * 0.45f).toInt())
                }
                val tv = TextView(this).apply { text = b.label; setTextColor(Color.WHITE); textSize = 8.5f; gravity = Gravity.CENTER }
                box.addView(iv); box.addView(tv)
                val lp = WindowManager.LayoutParams(px, px, overlayType, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
                    gravity = Gravity.TOP or Gravity.START
                    x = (b.xNorm * dm.widthPixels - px / 2f).toInt().coerceIn(0, (dm.widthPixels - px).coerceAtLeast(0))
                    y = (b.yNorm * dm.heightPixels - px / 2f).toInt().coerceIn(0, (dm.heightPixels - px).coerceAtLeast(0))
                }
                var ix = 0; var iy = 0; var tx = 0f; var ty = 0f
                box.setOnTouchListener { _, ev ->
                    when (ev.action) {
                        MotionEvent.ACTION_DOWN -> { ix = lp.x; iy = lp.y; tx = ev.rawX; ty = ev.rawY; true }
                        MotionEvent.ACTION_MOVE -> {
                            lp.x = (ix + (ev.rawX - tx).toInt()).coerceIn(0, (dm.widthPixels - px).coerceAtLeast(0))
                            lp.y = (iy + (ev.rawY - ty).toInt()).coerceIn(0, (dm.heightPixels - px).coerceAtLeast(0))
                            try { wm.updateViewLayout(box, lp) } catch (_: Exception) {}
                            b.xNorm = (lp.x + px / 2f) / dm.widthPixels.toFloat()
                            b.yNorm = (lp.y + px / 2f) / dm.heightPixels.toFloat()
                            true
                        }
                        else -> true
                    }
                }
                activeHudButtonViews.add(box)
                wm.addView(box, lp)
            }
        }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#EB080B13"))
            setPadding(18, 10, 18, 10)
        }
        val btnAdd = Button(this).apply {
            text = "+ Tombol"; textSize = 10.5f; isAllCaps = false; setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#0284C7")); minHeight = 0; minimumHeight = 0
            setOnClickListener {
                profile.buttons.add(CyberXHudButton(java.util.UUID.randomUUID().toString(), "B${profile.buttons.size + 1}"))
                renderEditable()
            }
        }
        val btnSave = Button(this).apply {
            text = "Simpan & Kunci"; textSize = 10.5f; isAllCaps = false; setTextColor(Color.BLACK)
            setBackgroundColor(Color.parseColor("#10B981")); minHeight = 0; minimumHeight = 0
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginStart = 10 }
            setOnClickListener {
                val idx = profiles.indexOfFirst { it.id == profile.id }
                if (idx >= 0) profiles[idx] = profile else profiles.add(profile)
                storage.saveHudProfiles(profiles)
                removeViewSafe(inGameEditBar); inGameEditBar = null
                refreshCustomHudButtons()
                Toast.makeText(this@CyberXGameOverlayService, "HUD disimpan!", Toast.LENGTH_SHORT).show()
            }
        }
        bar.addView(btnAdd); bar.addView(btnSave)
        val blp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, overlayType, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 24
        }
        inGameEditBar = bar
        wm.addView(bar, blp)
        renderEditable()
        Toast.makeText(this, "Geser tombol HUD di atas game lalu tekan Simpan & Kunci!", Toast.LENGTH_LONG).show()
    }

    fun refreshCustomHudButtons() {
        clearCustomHudButtons()
        if (!storage.hudButtonsVisibleInGame || resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT) return
        val profile = storage.getActiveHudProfile()
        val dm = resources.displayMetrics
        val density = dm.density
        for (b in profile.buttons) {
            val px = (b.sizeDp * density).toInt()
            val container = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                alpha = b.alpha
                background = CyberXShapeDrawable(
                    shape = b.shape,
                    fillColor = Color.parseColor("#BF090C14"),
                    borderColor = Color.parseColor(b.colorHex),
                    strokePx = 2.5f
                )
                setOnClickListener {
                    when (b.actionType) {
                        CyberXTriggerAction.MACRO_PROFILE -> {
                            if (b.linkedMacroId.isNotEmpty()) executeSafeMacro(b.linkedMacroId)
                            else Toast.makeText(this@CyberXGameOverlayService, "Belum ada Macro terkait pada ${b.label}", Toast.LENGTH_SHORT).show()
                        }
                        CyberXTriggerAction.SINGLE_TAP -> {
                            val step = CyberXTouchStep("t", 1, CyberXTouchType.TAP, b.targetXNorm * dm.widthPixels, b.targetYNorm * dm.heightPixels)
                            scope.launch(Dispatchers.IO) {
                                val (ok, msg) = CyberXShizukuBackend.injectTouchStep(step, 1.0f)
                                if (!ok) launch(Dispatchers.Main) { Toast.makeText(this@CyberXGameOverlayService, "Tap Gagal: $msg", Toast.LENGTH_SHORT).show() }
                            }
                        }
                        CyberXTriggerAction.SWIPE_GESTURE -> {
                            val step = CyberXTouchStep("s", 1, CyberXTouchType.SWIPE, b.targetXNorm * dm.widthPixels, b.targetYNorm * dm.heightPixels, b.targetEndXNorm * dm.widthPixels, b.targetEndYNorm * dm.heightPixels, 0L, 0L, 140L)
                            scope.launch(Dispatchers.IO) {
                                val (ok, msg) = CyberXShizukuBackend.injectTouchStep(step, 1.0f)
                                if (!ok) launch(Dispatchers.Main) { Toast.makeText(this@CyberXGameOverlayService, "Slide Gagal: $msg", Toast.LENGTH_SHORT).show() }
                            }
                        }
                    }
                }
            }
            val iv = ImageView(this).apply {
                setImageResource(CyberXIconMapper.resolveIconRes(b.iconKey))
                layoutParams = LinearLayout.LayoutParams((px * 0.45f).toInt(), (px * 0.45f).toInt())
            }
            val tv = TextView(this).apply {
                text = b.label
                setTextColor(Color.WHITE)
                textSize = 8.5f
                gravity = Gravity.CENTER
            }
            container.addView(iv); container.addView(tv)
            val lp = WindowManager.LayoutParams(
                px, px, overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = (b.xNorm * dm.widthPixels - px / 2f).toInt().coerceIn(0, (dm.widthPixels - px).coerceAtLeast(0))
                y = (b.yNorm * dm.heightPixels - px / 2f).toInt().coerceIn(0, (dm.heightPixels - px).coerceAtLeast(0))
            }
            activeHudButtonViews.add(container)
            wm.addView(container, lp)
        }
    }

    private fun clearMacroFloatingTriggers() {
        for (v in activeMacroTriggerViews) removeViewSafe(v)
        activeMacroTriggerViews.clear()
    }

    private fun updateMacroStatusIndicator() {
        removeViewSafe(macroStatusPill)
        macroStatusPill = null
        if (!CyberXMacroPlayer.isAnyRunning()) return
        val cnt = CyberXMacroPlayer.runningCount()
        val pill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = CyberXGlassCardDrawable(Color.parseColor("#E6140A12"), Color.parseColor("#FF1744"), 24f, 2.5f)
            setPadding(16, 8, 16, 8)
        }
        val tv = TextView(this).apply {
            text = "● $cnt MACRO AKTIF • STOP ALL"
            setTextColor(Color.WHITE)
            textSize = 10f
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        pill.addView(tv)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 18 }
        var ix = 0; var iy = 0; var tx = 0f; var ty = 0f; var moved = false
        pill.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { ix = lp.x; iy = lp.y; tx = ev.rawX; ty = ev.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    if (kotlin.math.hypot((ev.rawX - tx).toDouble(), (ev.rawY - ty).toDouble()) > 12.0) {
                        moved = true
                        lp.x = ix + (ev.rawX - tx).toInt()
                        lp.y = iy + (ev.rawY - ty).toInt()
                        try { wm.updateViewLayout(pill, lp) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) CyberXMacroPlayer.stopAll(this@CyberXGameOverlayService)
                    true
                }
                else -> false
            }
        }
        macroStatusPill = pill
        wm.addView(pill, lp)
    }

    fun refreshMacroFloatingTriggers() {
        clearMacroFloatingTriggers()
        if (!storage.hudButtonsVisibleInGame || resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT) return
        val allMacros = storage.getMacros()
        val dm = resources.displayMetrics
        val density = dm.density
        for (m in allMacros) {
            if (!m.enabled || !m.showOnHud) continue
            val isRunning = CyberXMacroPlayer.isMacroRunning(m.id)
            val px = (m.sizeDp.coerceIn(36, 96) * density).toInt()
            val borderCol = if (isRunning) Color.parseColor("#10B981") else try { Color.parseColor(m.colorHex) } catch (_: Exception) { Color.parseColor("#FF1744") }
            val fillCol = if (isRunning) Color.parseColor("#D906241B") else Color.parseColor("#BF090C14")
            val btnBox = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                alpha = if (isRunning) 1.0f else m.alpha.coerceIn(0.2f, 1.0f)
                background = CyberXShapeDrawable(
                    shape = CyberXButtonShape.CIRCLE,
                    fillColor = fillCol,
                    borderColor = borderCol,
                    strokePx = if (isRunning) 4.0f else 2.5f
                )
            }
            val iv = ImageView(this).apply {
                setImageResource(CyberXIconMapper.resolveIconRes(m.triggerIconKey))
                layoutParams = LinearLayout.LayoutParams((px * 0.42f).toInt(), (px * 0.42f).toInt())
            }
            val tv = TextView(this).apply {
                text = if (isRunning) "■" else m.buttonLabel.take(4)
                setTextColor(if (isRunning) Color.parseColor("#10B981") else Color.WHITE)
                textSize = 8.5f
                setTypeface(null, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
            }
            btnBox.addView(iv); btnBox.addView(tv)
            val lp = WindowManager.LayoutParams(
                px, px, overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = (m.xNorm * dm.widthPixels - px / 2f).toInt().coerceIn(0, (dm.widthPixels - px).coerceAtLeast(0))
                y = (m.yNorm * dm.heightPixels - px / 2f).toInt().coerceIn(0, (dm.heightPixels - px).coerceAtLeast(0))
            }
            var ix = 0; var iy = 0; var tx = 0f; var ty = 0f; var moved = false
            btnBox.setOnTouchListener { _, ev ->
                when (ev.action) {
                    MotionEvent.ACTION_DOWN -> {
                        ix = lp.x; iy = lp.y; tx = ev.rawX; ty = ev.rawY; moved = false
                        if (m.triggerMode == MacroTriggerMode.HOLD) {
                            CyberXMacroPlayer.play(this@CyberXGameOverlayService, m)
                        }
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (kotlin.math.hypot((ev.rawX - tx).toDouble(), (ev.rawY - ty).toDouble()) > 14.0) {
                            moved = true
                            lp.x = (ix + (ev.rawX - tx).toInt()).coerceIn(0, (dm.widthPixels - px).coerceAtLeast(0))
                            lp.y = (iy + (ev.rawY - ty).toInt()).coerceIn(0, (dm.heightPixels - px).coerceAtLeast(0))
                            try { wm.updateViewLayout(btnBox, lp) } catch (_: Exception) {}
                            m.xNorm = (lp.x + px / 2f) / dm.widthPixels.toFloat()
                            m.yNorm = (lp.y + px / 2f) / dm.heightPixels.toFloat()
                        }
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        if (moved) {
                            val list = storage.getMacros()
                            val idx = list.indexOfFirst { it.id == m.id }
                            if (idx >= 0) {
                                list[idx].xNorm = m.xNorm
                                list[idx].yNorm = m.yNorm
                                storage.saveMacros(list)
                            }
                            if (m.triggerMode == MacroTriggerMode.HOLD) {
                                CyberXMacroPlayer.stopMacro(this@CyberXGameOverlayService, m.id, m.vibrateOnTrigger)
                            }
                        } else {
                            if (m.triggerMode == MacroTriggerMode.HOLD) {
                                CyberXMacroPlayer.stopMacro(this@CyberXGameOverlayService, m.id, m.vibrateOnTrigger)
                            } else {
                                CyberXMacroPlayer.toggle(this@CyberXGameOverlayService, m)
                            }
                        }
                        true
                    }
                    else -> false
                }
            }
            activeMacroTriggerViews.add(btnBox)
            wm.addView(btnBox, lp)
        }
    }

    private var floatingMacroBar: View? = null
    private var recordOverlayView: View? = null
    private var recordStopBtnView: View? = null
    private val recordedStepsBuffer = mutableListOf<CyberXTouchStep>()
    private var recLastEventUpMs = 0L

    private fun executeSafeMacro(macroId: String) {
        val m = storage.getMacros().firstOrNull { it.id == macroId && it.enabled }
        if (m == null) {
            Toast.makeText(this, "Macro tidak ditemukan atau nonaktif", Toast.LENGTH_SHORT).show()
            return
        }
        CyberXMacroPlayer.play(this, m)
        if (CyberXMacroPlayer.state == MacroEngineState.ERROR) {
            Toast.makeText(this, CyberXMacroPlayer.statusText, Toast.LENGTH_LONG).show()
        }
    }

    private fun startTouchRecordingOverlay() {
        stopTouchRecordingOverlay(save = false)
        recordedStepsBuffer.clear()
        recLastEventUpMs = System.currentTimeMillis()
        CyberXMacroPlayer.state = MacroEngineState.RECORDING
        CyberXMacroPlayer.statusText = "Merekam sentuhan..."

        var downX = 0f; var downY = 0f; var downMs = 0L
        val capView = View(this).apply {
            setBackgroundColor(Color.parseColor("#18FF1744"))
            setOnTouchListener { _, ev ->
                when (ev.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = ev.rawX; downY = ev.rawY; downMs = System.currentTimeMillis()
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        val upMs = System.currentTimeMillis()
                        val dur = (upMs - downMs).coerceAtLeast(30L)
                        val delayPrev = if (recordedStepsBuffer.isEmpty()) 0L else (downMs - recLastEventUpMs).coerceAtLeast(20L)
                        recLastEventUpMs = upMs
                        val dist = kotlin.math.hypot((ev.rawX - downX).toDouble(), (ev.rawY - downY).toDouble())
                        val tType = when {
                            dist > 38.0 -> CyberXTouchType.SWIPE
                            dur >= 240L -> CyberXTouchType.HOLD
                            else -> CyberXTouchType.TAP
                        }
                        recordedStepsBuffer.add(
                            CyberXTouchStep(
                                id = java.util.UUID.randomUUID().toString(),
                                order = recordedStepsBuffer.size + 1,
                                type = tType,
                                xPx = downX,
                                yPx = downY,
                                endXPx = ev.rawX,
                                endYPx = ev.rawY,
                                timestampMs = downMs,
                                delayFromPrevMs = delayPrev,
                                durationMs = dur
                            )
                        )
                        Toast.makeText(this@CyberXGameOverlayService, "Terekam #${recordedStepsBuffer.size}: ${tType.label} (${downX.toInt()},${downY.toInt()})", Toast.LENGTH_SHORT).show()
                        true
                    }
                    else -> true
                }
            }
        }
        val capLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        recordOverlayView = capView
        wm.addView(capView, capLp)

        val stopBtn = Button(this).apply {
            text = "■ STOP REKAM (Simpan)"
            textSize = 11f
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#E11D48"))
            setPadding(24, 12, 24, 12)
            setOnClickListener { stopTouchRecordingOverlay(save = true) }
        }
        val stopLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 28 }
        recordStopBtnView = stopBtn
        wm.addView(stopBtn, stopLp)
    }

    private fun stopTouchRecordingOverlay(save: Boolean) {
        removeViewSafe(recordOverlayView); recordOverlayView = null
        removeViewSafe(recordStopBtnView); recordStopBtnView = null
        if (CyberXMacroPlayer.state == MacroEngineState.RECORDING) {
            CyberXMacroPlayer.state = MacroEngineState.IDLE
        }
        if (save && recordedStepsBuffer.isNotEmpty()) {
            val all = storage.getMacros()
            val newMacro = CyberXMacroProfile(
                id = "macro_${System.currentTimeMillis()}",
                name = "Rekaman #${all.size + 1}",
                enabled = true,
                steps = recordedStepsBuffer.toMutableList()
            )
            all.add(newMacro)
            storage.saveMacros(all)
            storage.activeMacroId = newMacro.id
            refreshMacroFloatingTriggers()
            Toast.makeText(this, "Macro '${newMacro.name}' (${newMacro.steps.size} langkah) disimpan!", Toast.LENGTH_LONG).show()
        }
    }

    private fun toggleFloatingMacroController() {
        if (floatingMacroBar != null) {
            removeViewSafe(floatingMacroBar); floatingMacroBar = null
            return
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = CyberXGlassCardDrawable(Color.parseColor("#E6080B13"), Color.parseColor("#FF1744"), 20f, 2f)
            setPadding(14, 10, 14, 10)
        }
        val tvStat = TextView(this).apply {
            text = "MACRO"
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 9.5f
            setPadding(0, 0, 10, 0)
        }
        val btnRec = Button(this).apply {
            text = "REC"; textSize = 9.5f; setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#E11D48"))
            minHeight = 0; minimumHeight = 0; setPadding(14, 6, 14, 6)
            setOnClickListener { startTouchRecordingOverlay() }
        }
        val btnPlay = Button(this).apply {
            text = "PLAY"; textSize = 9.5f; setTextColor(Color.BLACK); setBackgroundColor(Color.parseColor("#10B981"))
            minHeight = 0; minimumHeight = 0; setPadding(14, 6, 14, 6)
            setOnClickListener {
                if (CyberXMacroPlayer.state == MacroEngineState.PAUSED) {
                    CyberXMacroPlayer.resume()
                } else {
                    val all = storage.getMacros()
                    val m = all.firstOrNull { it.id == storage.activeMacroId } ?: all.firstOrNull()
                    if (m != null) CyberXMacroPlayer.play(this@CyberXGameOverlayService, m)
                    else Toast.makeText(this@CyberXGameOverlayService, "Belum ada macro. Tekan REC dulu!", Toast.LENGTH_SHORT).show()
                }
                tvStat.text = CyberXMacroPlayer.state.name
            }
        }
        val btnPause = Button(this).apply {
            text = "PAUSE"; textSize = 9.5f; setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#334155"))
            minHeight = 0; minimumHeight = 0; setPadding(12, 6, 12, 6)
            setOnClickListener { CyberXMacroPlayer.pause(); tvStat.text = CyberXMacroPlayer.state.name }
        }
        val btnStop = Button(this).apply {
            text = "STOP"; textSize = 9.5f; setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#991B1B"))
            minHeight = 0; minimumHeight = 0; setPadding(12, 6, 12, 6)
            setOnClickListener { CyberXMacroPlayer.stop(); tvStat.text = "IDLE" }
        }
        bar.addView(tvStat); bar.addView(btnRec); bar.addView(btnPlay); bar.addView(btnPause); bar.addView(btnStop)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 36; y = 90 }
        var ix = 0; var iy = 0; var tx = 0f; var ty = 0f
        bar.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { ix = lp.x; iy = lp.y; tx = ev.rawX; ty = ev.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ix + (ev.rawX - tx).toInt(); lp.y = iy + (ev.rawY - ty).toInt()
                    try { wm.updateViewLayout(bar, lp) } catch (_: Exception) {}
                    true
                }
                else -> false
            }
        }
        floatingMacroBar = bar
        wm.addView(bar, lp)
    }

    private fun closePanelImmediate() {
        isPanelOpen = false
        removeViewSafe(panelView)
        panelView = null
        tvPanelTelemetry = null
        tvPanelStopwatch = null
    }

    private fun closePanelAnimated() {
        isPanelOpen = false
        val p = panelView ?: return
        p.animate().alpha(0f).translationX(120f).setDuration(200).withEndAction {
            closePanelImmediate()
        }.start()
    }

    private fun openPanelSlide() {
        closePanelImmediate()
        isPanelOpen = true
        val dm = resources.displayMetrics
        val isPortrait = resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
        if (isPortrait) {
            val waitBox = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                background = CyberXGlassCardDrawable(Color.parseColor("#EB080B13"), Color.parseColor("#FF1744"), 24f, 2f)
                setPadding(24, 24, 24, 24)
            }
            val mecha = CyberXWaitingMechaView(this).apply {
                layoutParams = LinearLayout.LayoutParams(420, 260)
                startAnim()
            }
            val btnHideWait = Button(this).apply {
                text = "Tutup"
                textSize = 11f
                isAllCaps = false
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.parseColor("#E11D48"))
                setOnClickListener { mecha.stopAnim(); closePanelAnimated() }
            }
            waitBox.addView(mecha)
            waitBox.addView(btnHideWait)
            val wlp = WindowManager.LayoutParams(480, 380, overlayType, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
                gravity = Gravity.CENTER
            }
            panelView = waitBox
            wm.addView(waitBox, wlp)
            return
        }
        val panelW = if (isPortrait) (dm.widthPixels * 0.86f).toInt() else (dm.widthPixels * 0.44f).toInt().coerceIn(380, 560)
        val panelH = if (isPortrait) (dm.heightPixels * 0.62f).toInt() else (dm.heightPixels * 0.88f).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = CyberXGlassCardDrawable(
                fillColor = Color.parseColor("#EB080B13"),
                borderColor = Color.parseColor("#66FF1744"),
                cornerPx = 28f,
                strokePx = 2.5f
            )
            setPadding(22, 18, 22, 18)
        }

        // Header + Clear Close Button (Closes panel ONLY, keeps service running!)
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleTv = TextView(this).apply {
            text = "CYBERX OVERLAY"
            setTextColor(Color.WHITE)
            textSize = 13.5f
            typeface = android.graphics.Typeface.MONOSPACE
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val btnClose = Button(this).apply {
            text = "Tutup"
            textSize = 11f
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#E11D48"))
            setPadding(18, 6, 18, 6)
            minHeight = 0; minimumHeight = 0
            setOnClickListener { closePanelAnimated() }
        }
        header.addView(titleTv)
        header.addView(btnClose)
        root.addView(header)

        tvPanelTelemetry = TextView(this).apply {
            text = "Memuat telemetri..."
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 10.5f
            typeface = android.graphics.Typeface.MONOSPACE
            setPadding(0, 6, 0, 10)
        }
        root.addView(tvPanelTelemetry)

        // Category Tabs: GAMING | TOOLS | MACROS | HUD
        val tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val cats = listOf("GAMING", "TOOLS", "MACROS", "HUD")
        val contentScroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        val contentCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        contentScroll.addView(contentCol)

        fun renderCategoryContent() {
            contentCol.removeAllViews()
            tvPanelStopwatch = null
            when (activeCategory) {
                "GAMING" -> {
                    contentCol.addView(makeActionBtn("Mode Performa: ${prefs.perfMode.uppercase()}") { b ->
                        val next = when (prefs.perfMode) { "eco" -> "balance"; "balance" -> "turbo"; else -> "eco" }
                        prefs.perfMode = next
                        b.text = "Mode Performa: ${next.uppercase()}"
                    })
                    contentCol.addView(makeInfoNote("FPS Monitor: Android membatasi pembacaan FPS game lain tanpa akses sistem/Shizuku."))
                    contentCol.addView(makeActionBtn("Do Not Disturb (DND)") { toggleDnd() })
                    contentCol.addView(makeActionBtn("Volume +") { adjustVol(AudioManager.ADJUST_RAISE) })
                    contentCol.addView(makeActionBtn("Volume -") { adjustVol(AudioManager.ADJUST_LOWER) })
                    contentCol.addView(makeActionBtn("Pengaturan Kecerahan Layar") {
                        startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    })
                }
                "TOOLS" -> {
                    tvPanelStopwatch = TextView(this).apply {
                        text = "Stopwatch: %02d:%02d".format(stopwatchSeconds / 60, stopwatchSeconds % 60)
                        setTextColor(Color.WHITE)
                        textSize = 12f
                        setPadding(8, 8, 8, 8)
                    }
                    contentCol.addView(tvPanelStopwatch)
                    contentCol.addView(makeActionBtn(if (stopwatchRunning) "Stop Stopwatch" else "Mulai Stopwatch") { b ->
                        stopwatchRunning = !stopwatchRunning
                        if (!stopwatchRunning) stopwatchSeconds = 0
                        b.text = if (stopwatchRunning) "Stop Stopwatch" else "Mulai Stopwatch"
                    })
                    contentCol.addView(makeActionBtn("Crosshair: ${prefs.crosshairStyle}") { b ->
                        cycleCrosshair()
                        b.text = "Crosshair: ${prefs.crosshairStyle}"
                    })
                    val tvChPos = TextView(this).apply {
                        text = "Posisi Crosshair: X=${prefs.crosshairOffsetX}px  Y=${prefs.crosshairOffsetY}px"
                        setTextColor(Color.parseColor("#38BDF8"))
                        textSize = 11f
                        setPadding(8, 6, 8, 4)
                    }
                    contentCol.addView(tvChPos)
                    val chRowTop = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                    chRowTop.addView(makeActionBtn("▲ Atas") {
                        prefs.crosshairOffsetY -= crosshairStepPx
                        tvChPos.text = "Posisi Crosshair: X=${prefs.crosshairOffsetX}px  Y=${prefs.crosshairOffsetY}px"
                        updateCrosshairPosition()
                    }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0, 2, 4, 2) })
                    chRowTop.addView(makeActionBtn("Geser: ${crosshairStepPx}px") { b ->
                        crosshairStepPx = when (crosshairStepPx) { 2 -> 4; 4 -> 10; else -> 2 }
                        b.text = "Geser: ${crosshairStepPx}px"
                    }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(4, 2, 0, 2) })
                    contentCol.addView(chRowTop)
                    val chRowMid = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                    chRowMid.addView(makeActionBtn("◀ Kiri") {
                        prefs.crosshairOffsetX -= crosshairStepPx
                        tvChPos.text = "Posisi Crosshair: X=${prefs.crosshairOffsetX}px  Y=${prefs.crosshairOffsetY}px"
                        updateCrosshairPosition()
                    }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0, 2, 3, 2) })
                    chRowMid.addView(makeActionBtn("⌖ Tengah") {
                        prefs.crosshairOffsetX = 0
                        prefs.crosshairOffsetY = 0
                        tvChPos.text = "Posisi Crosshair: X=0px  Y=0px"
                        updateCrosshairPosition()
                    }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(3, 2, 3, 2) })
                    chRowMid.addView(makeActionBtn("Kanan ▶") {
                        prefs.crosshairOffsetX += crosshairStepPx
                        tvChPos.text = "Posisi Crosshair: X=${prefs.crosshairOffsetX}px  Y=${prefs.crosshairOffsetY}px"
                        updateCrosshairPosition()
                    }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(3, 2, 0, 2) })
                    contentCol.addView(chRowMid)
                    contentCol.addView(makeActionBtn("▼ Bawah") {
                        prefs.crosshairOffsetY += crosshairStepPx
                        tvChPos.text = "Posisi Crosshair: X=${prefs.crosshairOffsetX}px  Y=${prefs.crosshairOffsetY}px"
                        updateCrosshairPosition()
                    })
                    contentCol.addView(makeActionBtn("Extra Night Dimmer: ${(storage.nightDimmerAlpha * 100).toInt()}%") { b ->
                        val next = when { storage.nightDimmerAlpha < 0.1f -> 0.30f; storage.nightDimmerAlpha < 0.4f -> 0.55f; else -> 0f }
                        storage.nightDimmerAlpha = next
                        applyNightDimmerOverlay()
                        b.text = "Extra Night Dimmer: ${(next * 100).toInt()}%"
                    })
                    contentCol.addView(makeActionBtn("Tanya Rina (AI Game Coach)") {
                        scope.launch {
                            Toast.makeText(this@CyberXGameOverlayService, "Rina sedang menyiapkan tips...", Toast.LENGTH_SHORT).show()
                            val tip = BotEngineClient.callGeminiDirect(prefs, "rina_game_coach", "Kamu adalah Rina gadis naga tsundere. Berikan 1 kalimat singkat tips pro main game kompetitif di HP agar fokus dan tidak lag.")
                            Toast.makeText(this@CyberXGameOverlayService, tip ?: "Isi Gemini API Key dulu ya Master!", Toast.LENGTH_LONG).show()
                        }
                    })
                    contentCol.addView(makeInfoNote("Screenshot & Screen Recorder: Gunakan Quick Settings sistem Android agar aman di semua versi OS."))
                }
                "MACROS" -> {
                    contentCol.addView(makeActionBtn("● Rekam Sentuhan Baru (Record)") {
                        closePanelAnimated()
                        startTouchRecordingOverlay()
                    })
                    if (CyberXMacroPlayer.isAnyRunning()) {
                        contentCol.addView(makeActionBtn("■ Stop All (${CyberXMacroPlayer.runningCount()} Aktif)") {
                            CyberXMacroPlayer.stopAll(this@CyberXGameOverlayService)
                            openPanelSlide()
                        })
                    }
                    contentCol.addView(makeActionBtn("Floating Trigger: ${if (storage.hudButtonsVisibleInGame) "ON" else "OFF"}") { b ->
                        storage.hudButtonsVisibleInGame = !storage.hudButtonsVisibleInGame
                        refreshMacroFloatingTriggers()
                        refreshCustomHudButtons()
                        b.text = "Floating Trigger: ${if (storage.hudButtonsVisibleInGame) "ON" else "OFF"}"
                    })
                    contentCol.addView(makeActionBtn("Floating Macro Bar (On/Off)") {
                        toggleFloatingMacroController()
                    })
                    val macros = storage.getMacros()
                    for (m in macros) {
                        val run = CyberXMacroPlayer.isMacroRunning(m.id)
                        contentCol.addView(makeActionBtn("${if (run) "■" else if (m.enabled) "▶" else "[OFF]"} ${m.name} (${m.steps.size} step)") {
                            storage.activeMacroId = m.id
                            if (run) CyberXMacroPlayer.stopMacro(this@CyberXGameOverlayService, m.id, m.vibrateOnTrigger)
                            else executeSafeMacro(m.id)
                            closePanelAnimated()
                        })
                    }
                    contentCol.addView(makeActionBtn("Buka Macro Studio di CYBERX") {
                        closePanelAnimated()
                        startActivity(Intent(this, MainActivity::class.java).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                            putExtra("cyberx_open_tab", "MACROS")
                        })
                    })
                }
                "HUD" -> {
                    contentCol.addView(makeActionBtn(if (storage.hudButtonsVisibleInGame) "Sembunyikan Tombol HUD" else "Tampilkan Tombol HUD") { b ->
                        storage.hudButtonsVisibleInGame = !storage.hudButtonsVisibleInGame
                        refreshCustomHudButtons()
                        b.text = if (storage.hudButtonsVisibleInGame) "Sembunyikan Tombol HUD" else "Tampilkan Tombol HUD"
                    })
                    contentCol.addView(makeActionBtn("Atur HUD Langsung di Game (Geser)") {
                        closePanelAnimated()
                        enterInGameHudEditMode()
                    })
                    contentCol.addView(makeActionBtn("Buka HUD Editor Lengkap") {
                        closePanelAnimated()
                        startActivity(Intent(this, CyberXHudEditorActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    })
                    val profiles = storage.getHudProfiles()
                    for (p in profiles) {
                        val mark = if (p.id == storage.activeHudProfileId) "✓ " else ""
                        contentCol.addView(makeActionBtn("${mark}Muat Profil: ${p.name}") {
                            storage.activeHudProfileId = p.id
                            refreshCustomHudButtons()
                            renderCategoryContent()
                        })
                    }
                }
            }
        }

        val tabBtns = mutableListOf<Button>()
        for (c in cats) {
            val tb = Button(this).apply {
                text = c
                textSize = 10f
                isAllCaps = false
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.parseColor(if (c == activeCategory) "#E11D48" else "#1E293B"))
                minHeight = 0; minimumHeight = 0
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 4 }
                setOnClickListener {
                    activeCategory = c
                    tabBtns.forEachIndexed { idx, b ->
                        b.setBackgroundColor(Color.parseColor(if (cats[idx] == c) "#E11D48" else "#1E293B"))
                    }
                    renderCategoryContent()
                }
            }
            tabBtns.add(tb)
            tabRow.addView(tb)
        }
        root.addView(tabRow)
        root.addView(contentScroll)
        renderCategoryContent()

        val lp = WindowManager.LayoutParams(
            panelW, panelH, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL; x = 18 }

        panelView = root
        root.alpha = 0f
        root.translationX = 140f
        wm.addView(root, lp)
        root.animate().alpha(1f).translationX(0f).setDuration(240).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun makeActionBtn(label: String, onClick: (Button) -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 11f
            isAllCaps = false
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
            setTextColor(Color.WHITE)
            background = CyberXGlassCardDrawable(Color.parseColor("#CC141B2D"), Color.parseColor("#33FFFFFF"), 14f, 1.5f)
            setPadding(20, 14, 20, 14)
            minHeight = 0; minimumHeight = 0
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = 8 }
            setOnClickListener { onClick(this) }
        }
    }

    private fun makeInfoNote(msg: String): TextView {
        return TextView(this).apply {
            text = msg
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 10f
            setPadding(12, 10, 12, 6)
        }
    }

    private fun toggleDnd() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && nm.isNotificationPolicyAccessGranted) {
            val cur = nm.currentInterruptionFilter
            val target = if (cur == NotificationManager.INTERRUPTION_FILTER_PRIORITY) NotificationManager.INTERRUPTION_FILTER_ALL else NotificationManager.INTERRUPTION_FILTER_PRIORITY
            nm.setInterruptionFilter(target)
            Toast.makeText(this, if (target == NotificationManager.INTERRUPTION_FILTER_PRIORITY) "DND Aktif" else "DND Mati", Toast.LENGTH_SHORT).show()
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun adjustVol(dir: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
    }

    private fun cycleCrosshair() {
        val next = when (prefs.crosshairStyle) { "OFF" -> "DOT"; "DOT" -> "CROSS"; "CROSS" -> "CIRCLE"; else -> "OFF" }
        prefs.crosshairStyle = next
        crosshairView?.style = next
        crosshairView?.invalidate()
    }

    class CrosshairOverlayView(context: Context) : View(context) {
        var style: String = "DOT"
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FF1744")
            strokeWidth = 3.5f
            style = Paint.Style.STROKE
        }
        override fun onDraw(canvas: Canvas) {
            if (style == "OFF") return
            val cx = width / 2f; val cy = height / 2f
            when (style) {
                "DOT" -> { paint.style = Paint.Style.FILL; canvas.drawCircle(cx, cy, 7f, paint) }
                "CROSS" -> {
                    paint.style = Paint.Style.STROKE
                    canvas.drawLine(cx - 22f, cy, cx - 7f, cy, paint)
                    canvas.drawLine(cx + 7f, cy, cx + 22f, cy, paint)
                    canvas.drawLine(cx, cy - 22f, cx, cy - 7f, paint)
                    canvas.drawLine(cx, cy + 7f, cx, cy + 22f, paint)
                    paint.style = Paint.Style.FILL; canvas.drawCircle(cx, cy, 3.5f, paint)
                }
                "CIRCLE" -> {
                    paint.style = Paint.Style.STROKE; canvas.drawCircle(cx, cy, 20f, paint)
                    paint.style = Paint.Style.FILL; canvas.drawCircle(cx, cy, 3.5f, paint)
                }
            }
        }
    }
}
