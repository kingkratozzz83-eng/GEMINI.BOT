package com.gemini.wabot

import android.app.ActivityManager
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Shader
import android.media.AudioManager
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CyberXGameOverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var prefs: BotPrefsManager
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var hudJob: Job? = null

    private var triggerView: View? = null
    private var leftWingView: View? = null
    private var rightWingView: View? = null
    private var bottomPillView: TextView? = null
    private var crosshairView: CrosshairOverlayView? = null
    private var telemetryView: TextView? = null
    private val markerViews = mutableListOf<View>()
    private var isEditingHud = false
    private var isMenuOpen = false
    private var stopwatchRunning = false
    private var stopwatchSeconds = 0

    private val overlayType: Int
        get() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = BotPrefsManager(this)
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        setupTriggerBubble()
        setupCrosshair()
        setupTelemetryHud()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (isMenuOpen) {
            closeDualWings()
            openDualWings()
        }
    }

    override fun onDestroy() {
        hudJob?.cancel()
        scope.cancel()
        CyberXMacroService.instance?.stopMacro()
        removeViewSafe(triggerView)
        closeDualWings()
        removeViewSafe(crosshairView)
        removeViewSafe(telemetryView)
        clearMarkers()
        super.onDestroy()
    }

    private fun removeViewSafe(v: View?) {
        if (v != null) {
            try { wm.removeView(v) } catch (_: Exception) {}
        }
    }

    private fun setupTriggerBubble() {
        val iv = ImageView(this).apply {
            setImageResource(R.drawable.ic_rm_server)
            setBackgroundColor(Color.parseColor("#E6090D16"))
            setPadding(16, 16, 16, 16)
        }
        val lp = WindowManager.LayoutParams(
            110, 110, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 18
            y = 180
        }
        var initX = 0; var initY = 0; var touchX = 0f; var touchY = 0f; var moved = false
        iv.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    initX = lp.x; initY = lp.y; touchX = ev.rawX; touchY = ev.rawY; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - touchX).toInt()
                    val dy = (ev.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) > 10 || kotlin.math.abs(dy) > 10) moved = true
                    lp.x = initX + dx; lp.y = initY + dy
                    try { wm.updateViewLayout(iv, lp) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        if (isMenuOpen) closeDualWings() else openDualWings()
                    }
                    true
                }
                else -> false
            }
        }
        triggerView = iv
        wm.addView(iv, lp)
    }

    private fun setupCrosshair() {
        val cv = CrosshairOverlayView(this).apply { style = prefs.crosshairStyle }
        val lp = WindowManager.LayoutParams(
            160, 160, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        crosshairView = cv
        wm.addView(cv, lp)
    }

    private fun setupTelemetryHud() {
        val tv = TextView(this).apply {
            setBackgroundColor(Color.parseColor("#99060810"))
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 10f
            setPadding(14, 6, 14, 6)
            typeface = android.graphics.Typeface.MONOSPACE
            visibility = if (prefs.showThermalHud) View.VISIBLE else View.GONE
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 14
        }
        telemetryView = tv
        wm.addView(tv, lp)
        hudJob = scope.launch {
            while (isActive) {
                if (stopwatchRunning) stopwatchSeconds++
                val bm = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val temp = (bm?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
                val lvl = bm?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
                val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val mi = ActivityManager.MemoryInfo()
                am.getMemoryInfo(mi)
                val freeMb = mi.availMem / (1024 * 1024)
                val macroOn = if (CyberXMacroService.isRunningMacro) "MAKRO: ON" else "MAKRO: OFF"
                val warn = if (temp >= 43f) " PANAS!" else ""
                val swTxt = if (stopwatchRunning) " | %02d:%02d".format(stopwatchSeconds / 60, stopwatchSeconds % 60) else ""
                tv.text = "CYBERX | ${temp}°C$warn | ${freeMb}MB | $macroOn$swTxt"
                tv.setTextColor(if (temp >= 43f) Color.parseColor("#FF1744") else Color.parseColor("#00E5FF"))

                val nowStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                val botTxt = if (prefs.gameSpaceBatterySaver) "BOT MATI" else "BOT 24H"
                bottomPillView?.text = "CYBERX   $nowStr   BAT ${lvl}%   $botTxt"
                delay(1000)
            }
        }
    }

    private fun closeDualWings() {
        isMenuOpen = false
        removeViewSafe(leftWingView); leftWingView = null
        removeViewSafe(rightWingView); rightWingView = null
        removeViewSafe(bottomPillView); bottomPillView = null
    }

    private fun makeWingButton(label: String, accentColor: String, onClick: (Button) -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 10f
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#CC141B2D"))
            setPadding(10, 8, 10, 8)
            minHeight = 0
            minimumHeight = 0
            setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0)
            setOnClickListener { onClick(this) }
        }
    }

    private fun openDualWings() {
        closeDualWings()
        isMenuOpen = true
        val dm = resources.displayMetrics
        val isPortrait = resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
        // Adaptasi otomatis Portrait (Roblox Lobby) vs Landscape (In-Game / Free Fire)!
        val wingW = if (isPortrait) (dm.widthPixels * 0.44f).toInt() else (dm.widthPixels * 0.25f).toInt().coerceIn(280, 460)
        val wingH = if (isPortrait) (dm.heightPixels * 0.52f).toInt() else WindowManager.LayoutParams.MATCH_PARENT

        val lpBtn = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = 10
        }

        // === SAYAP KIRI: ALAT GAMING (MAKRO, ATUR HUD, STOPWATCH, CROSSHAIR, JEDA) ===
        val leftContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            background = WingChevronDrawable(isLeftWing = true)
            setPadding(18, 24, 34, 24)
        }
        val leftHeader = TextView(this).apply {
            text = "GAMING TOOLS"
            setTextColor(Color.parseColor("#FF4D6D"))
            textSize = 10.5f
            typeface = android.graphics.Typeface.MONOSPACE
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val btnMacro = makeWingButton(if (CyberXMacroService.isRunningMacro) "STOP MAKRO" else "MAKRO GLOO", "#10B981") { b ->
            val svc = CyberXMacroService.instance
            if (svc == null) {
                Toast.makeText(this, "Aktifkan Layanan Aksesibilitas CyberX Macro dulu!", Toast.LENGTH_LONG).show()
                return@makeWingButton
            }
            if (CyberXMacroService.isRunningMacro) {
                svc.stopMacro()
                b.text = "MAKRO GLOO"
                b.setBackgroundColor(Color.parseColor("#CC141B2D"))
            } else {
                if (isEditingHud) {
                    isEditingHud = false
                    clearMarkers()
                }
                svc.startMacro(loadMacroPoints(), prefs.macroDelayMs)
                b.text = "STOP MAKRO"
                b.setBackgroundColor(Color.parseColor("#CCFF1744"))
            }
        }
        val btnEditHud = makeWingButton(if (isEditingHud) "KUNCI TITIK" else "ATUR TITIK HUD", "#00E5FF") { b ->
            isEditingHud = !isEditingHud
            if (isEditingHud) {
                CyberXMacroService.instance?.stopMacro()
                showDraggableMarkers()
                b.text = "KUNCI TITIK"
                Toast.makeText(this, "Geser titik ke tombol Gloo Wall!", Toast.LENGTH_SHORT).show()
            } else {
                clearMarkers()
                b.text = "ATUR TITIK HUD"
                Toast.makeText(this, "Titik makro disimpan & dikunci!", Toast.LENGTH_SHORT).show()
            }
        }
        val btnStopwatch = makeWingButton(if (stopwatchRunning) "STOPWATCH: ON" else "STOPWATCH", "#FFFFFF") { b ->
            stopwatchRunning = !stopwatchRunning
            if (!stopwatchRunning) stopwatchSeconds = 0
            b.text = if (stopwatchRunning) "STOPWATCH: ON" else "STOPWATCH"
        }
        val btnCross = makeWingButton("CROSSHAIR: ${prefs.crosshairStyle}", "#FF4D6D") { b ->
            val next = when (prefs.crosshairStyle) {
                "OFF" -> "DOT"
                "DOT" -> "CROSS"
                "CROSS" -> "CIRCLE"
                else -> "OFF"
            }
            prefs.crosshairStyle = next
            crosshairView?.style = next
            crosshairView?.invalidate()
            b.text = "CROSSHAIR: $next"
        }
        val btnDelay = makeWingButton("JEDA: ${prefs.macroDelayMs}ms", "#FFFFFF") { b ->
            val next = when (prefs.macroDelayMs) { 45 -> 70; 70 -> 100; 100 -> 140; else -> 45 }
            prefs.macroDelayMs = next
            b.text = "JEDA: ${next}ms"
        }
        leftContainer.addView(leftHeader)
        leftContainer.addView(btnMacro, lpBtn)
        leftContainer.addView(btnEditHud, lpBtn)
        leftContainer.addView(btnStopwatch, lpBtn)
        leftContainer.addView(btnCross, lpBtn)
        leftContainer.addView(btnDelay, lpBtn)

        val lpLeft = WindowManager.LayoutParams(
            wingW, wingH, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.START or Gravity.CENTER_VERTICAL }
        leftWingView = leftContainer
        wm.addView(leftContainer, lpLeft)

        // === SAYAP KANAN: SISTEM, DND, VOLUME, KEMBALI KE CYBERX ===
        val rightContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            background = WingChevronDrawable(isLeftWing = false)
            setPadding(34, 24, 18, 24)
        }
        val rightHeader = TextView(this).apply {
            text = "SYSTEM & HUD"
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 10.5f
            gravity = Gravity.END
            typeface = android.graphics.Typeface.MONOSPACE
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val btnDnd = makeWingButton("MODE FOKUS (DND)", "#FDE047") {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && nm.isNotificationPolicyAccessGranted) {
                val cur = nm.currentInterruptionFilter
                val target = if (cur == NotificationManager.INTERRUPTION_FILTER_PRIORITY) NotificationManager.INTERRUPTION_FILTER_ALL else NotificationManager.INTERRUPTION_FILTER_PRIORITY
                nm.setInterruptionFilter(target)
                Toast.makeText(this, if (target == NotificationManager.INTERRUPTION_FILTER_PRIORITY) "Mode Fokus DND ON!" else "Mode Fokus DND OFF", Toast.LENGTH_SHORT).show()
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
        val btnVolUp = makeWingButton("VOLUME +", "#FFFFFF") {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
        }
        val btnVolDown = makeWingButton("VOLUME -", "#FFFFFF") {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
        }
        val btnHome = makeWingButton("LOBBY CYBERX", "#00E5FF") {
            closeDualWings()
            val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            startActivity(i)
        }
        val btnClose = makeWingButton("TUTUP MENU", "#FF1744") {
            closeDualWings()
        }.apply {
            setBackgroundColor(Color.parseColor("#CCE11D48"))
        }

        rightContainer.addView(rightHeader)
        rightContainer.addView(btnDnd, lpBtn)
        rightContainer.addView(btnVolUp, lpBtn)
        rightContainer.addView(btnVolDown, lpBtn)
        rightContainer.addView(btnHome, lpBtn)
        rightContainer.addView(btnClose, lpBtn)

        val lpRight = WindowManager.LayoutParams(
            wingW, wingH, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        rightWingView = rightContainer
        wm.addView(rightContainer, lpRight)

        // === BOTTOM CENTER PILL (PERSIS 567.jpg) ===
        val pill = TextView(this).apply {
            text = "CYBERX"
            setTextColor(Color.WHITE)
            textSize = 10f
            typeface = android.graphics.Typeface.MONOSPACE
            setBackgroundColor(Color.parseColor("#CC060810"))
            setPadding(22, 8, 22, 8)
        }
        val lpPill = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = 14
        }
        bottomPillView = pill
        wm.addView(pill, lpPill)
    }

    class WingChevronDrawable(private val isLeftWing: Boolean) : android.graphics.drawable.Drawable() {
        private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.parseColor("#D9080B14")
        }
        private val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 6f
        }
        override fun draw(canvas: Canvas) {
            val w = bounds.width().toFloat()
            val h = bounds.height().toFloat()
            if (w <= 0f || h <= 0f) return
            val peak = 34f
            val path = Path()
            if (isLeftWing) {
                path.moveTo(0f, 0f)
                path.lineTo(w - peak, 0f)
                path.lineTo(w, h / 2f)
                path.lineTo(w - peak, h)
                path.lineTo(0f, h)
                path.close()
                canvas.drawPath(path, fillPaint)
                edgePaint.shader = LinearGradient(0f, 0f, 0f, h, Color.parseColor("#FF5722"), Color.parseColor("#FF1744"), Shader.TileMode.CLAMP)
                val edge = Path().apply { moveTo(w - peak, 0f); lineTo(w, h / 2f); lineTo(w - peak, h) }
                canvas.drawPath(edge, edgePaint)
            } else {
                path.moveTo(w, 0f)
                path.lineTo(peak, 0f)
                path.lineTo(0f, h / 2f)
                path.lineTo(peak, h)
                path.lineTo(w, h)
                path.close()
                canvas.drawPath(path, fillPaint)
                edgePaint.shader = LinearGradient(0f, 0f, 0f, h, Color.parseColor("#FF5722"), Color.parseColor("#FF1744"), Shader.TileMode.CLAMP)
                val edge = Path().apply { moveTo(peak, 0f); lineTo(0f, h / 2f); lineTo(peak, h) }
                canvas.drawPath(edge, edgePaint)
            }
        }
        override fun setAlpha(alpha: Int) { fillPaint.alpha = alpha }
        override fun setColorFilter(cf: android.graphics.ColorFilter?) { fillPaint.colorFilter = cf }
        @Deprecated("Deprecated in Java")
        override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
    }

    private fun loadMacroPoints(): MutableList<MacroPoint> {
        val out = mutableListOf<MacroPoint>()
        try {
            val arr = JSONArray(prefs.macroPointsJson)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(MacroPoint(o.optString("label", "${i+1}"), o.optDouble("x", 600.0).toFloat(), o.optDouble("y", 400.0).toFloat()))
            }
        } catch (_: Exception) {}
        if (out.isEmpty()) {
            out.add(MacroPoint("1:Gloo", 350f, 520f))
            out.add(MacroPoint("2:Jongkok", 1180f, 540f))
            out.add(MacroPoint("3:Pasang", 1320f, 450f))
            saveMacroPoints(out)
        }
        return out
    }

    private fun saveMacroPoints(pts: List<MacroPoint>) {
        val arr = JSONArray()
        for (p in pts) {
            arr.put(JSONObject().put("label", p.label).put("x", p.x.toDouble()).put("y", p.y.toDouble()))
        }
        prefs.macroPointsJson = arr.toString()
    }

    private fun clearMarkers() {
        for (v in markerViews) removeViewSafe(v)
        markerViews.clear()
    }

    private fun showDraggableMarkers() {
        clearMarkers()
        val pts = loadMacroPoints()
        pts.forEachIndexed { idx, pt ->
            val tv = TextView(this).apply {
                text = pt.label
                setTextColor(Color.WHITE)
                textSize = 10f
                gravity = Gravity.CENTER
                setBackgroundColor(Color.parseColor("#CCFF1744"))
                setPadding(14, 14, 14, 14)
            }
            val mlp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = pt.x.toInt() - 40
                y = pt.y.toInt() - 40
            }
            var ix = 0; var iy = 0; var tx = 0f; var ty = 0f
            tv.setOnTouchListener { _, ev ->
                when (ev.action) {
                    MotionEvent.ACTION_DOWN -> { ix = mlp.x; iy = mlp.y; tx = ev.rawX; ty = ev.rawY; true }
                    MotionEvent.ACTION_MOVE -> {
                        mlp.x = ix + (ev.rawX - tx).toInt()
                        mlp.y = iy + (ev.rawY - ty).toInt()
                        try { wm.updateViewLayout(tv, mlp) } catch (_: Exception) {}
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        pts[idx].x = ev.rawX
                        pts[idx].y = ev.rawY
                        saveMacroPoints(pts)
                        true
                    }
                    else -> false
                }
            }
            markerViews.add(tv)
            wm.addView(tv, mlp)
        }
    }

    class CrosshairOverlayView(context: Context) : View(context) {
        var style: String = "DOT"
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FF1744")
            strokeWidth = 4f
            style = Paint.Style.STROKE
        }
        override fun onDraw(canvas: Canvas) {
            if (style == "OFF") return
            val cx = width / 2f
            val cy = height / 2f
            when (style) {
                "DOT" -> {
                    paint.style = Paint.Style.FILL
                    canvas.drawCircle(cx, cy, 8f, paint)
                }
                "CROSS" -> {
                    paint.style = Paint.Style.STROKE
                    canvas.drawLine(cx - 26f, cy, cx - 8f, cy, paint)
                    canvas.drawLine(cx + 8f, cy, cx + 26f, cy, paint)
                    canvas.drawLine(cx, cy - 26f, cx, cy - 8f, paint)
                    canvas.drawLine(cx, cy + 8f, cx, cy + 26f, paint)
                    paint.style = Paint.Style.FILL
                    canvas.drawCircle(cx, cy, 4f, paint)
                }
                "CIRCLE" -> {
                    paint.style = Paint.Style.STROKE
                    canvas.drawCircle(cx, cy, 24f, paint)
                    paint.style = Paint.Style.FILL
                    canvas.drawCircle(cx, cy, 4f, paint)
                }
            }
        }
    }
}
