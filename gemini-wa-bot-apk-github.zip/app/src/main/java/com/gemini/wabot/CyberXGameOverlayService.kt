package com.gemini.wabot

import android.animation.ValueAnimator
import android.app.ActivityManager
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Shader
import android.media.AudioManager
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CyberXGameOverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var prefs: BotPrefsManager
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var hudJob: Job? = null
    private var wingRgbAnim: ValueAnimator? = null

    private var triggerView: View? = null
    private var leftWingView: View? = null
    private var rightWingView: View? = null
    private var bottomPillView: TextView? = null
    private var crosshairView: CrosshairOverlayView? = null
    private var auxLineView: AuxLineOverlayView? = null
    private var telemetryView: TextView? = null
    private var keepScreenOverlay: View? = null
    private val markerViews = mutableListOf<View>()
    private var isEditingHud = false
    private var isMenuOpen = false
    private var stopwatchRunning = false
    private var stopwatchSeconds = 0
    private var showAuxLines = false
    private var keepScreenOn = true

    private val overlayType: Int
        get() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = BotPrefsManager(this)
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        setupTriggerBubble()
        setupCrosshair()
        setupAuxLines()
        setupTelemetryHud()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (isMenuOpen) {
            removeWingViewsImmediate()
            openDualWings()
        }
    }

    override fun onDestroy() {
        hudJob?.cancel()
        wingRgbAnim?.cancel()
        scope.cancel()
        CyberXMacroService.instance?.stopMacro()
        removeViewSafe(triggerView)
        removeWingViewsImmediate()
        removeViewSafe(crosshairView)
        removeViewSafe(auxLineView)
        removeViewSafe(telemetryView)
        removeViewSafe(keepScreenOverlay)
        clearMarkers()
        super.onDestroy()
    }

    private fun removeViewSafe(v: View?) {
        if (v != null) {
            try { wm.removeView(v) } catch (_: Exception) {}
        }
    }

    private fun setupTriggerBubble() {
        val iv = ImageView(this).apply {
            setImageResource(R.drawable.ic_rm_server)
            setBackgroundColor(Color.parseColor("#E6060812"))
            setPadding(16, 16, 16, 16)
        }
        val lp = WindowManager.LayoutParams(
            106, 106, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 18
            y = 180
        }
        var initX = 0; var initY = 0; var touchX = 0f; var touchY = 0f; var moved = false
        iv.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    initX = lp.x; initY = lp.y; touchX = ev.rawX; touchY = ev.rawY; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - touchX).toInt()
                    val dy = (ev.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) > 10 || kotlin.math.abs(dy) > 10) moved = true
                    lp.x = initX + dx; lp.y = initY + dy
                    try { wm.updateViewLayout(iv, lp) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        if (isMenuOpen) closeDualWingsAnimated() else openDualWings()
                    }
                    true
                }
                else -> false
            }
        }
        triggerView = iv
        wm.addView(iv, lp)
    }

    private fun setupCrosshair() {
        val cv = CrosshairOverlayView(this).apply { style = prefs.crosshairStyle }
        val lp = WindowManager.LayoutParams(
            160, 160, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        crosshairView = cv
        wm.addView(cv, lp)
    }

    private fun setupAuxLines() {
        val av = AuxLineOverlayView(this).apply {
            visibility = if (showAuxLines) View.VISIBLE else View.GONE
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        auxLineView = av
        wm.addView(av, lp)
    }

    private fun setupTelemetryHud() {
        val tv = TextView(this).apply {
            setBackgroundColor(Color.parseColor("#99060810"))
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 10f
            setPadding(14, 6, 14, 6)
            typeface = android.graphics.Typeface.MONOSPACE
            visibility = if (prefs.showThermalHud) View.VISIBLE else View.GONE
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 14
        }
        telemetryView = tv
        wm.addView(tv, lp)
        hudJob = scope.launch {
            while (isActive) {
                if (stopwatchRunning) stopwatchSeconds++
                val bm = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val temp = (bm?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
                val lvl = bm?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
                val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val mi = ActivityManager.MemoryInfo()
                am.getMemoryInfo(mi)
                val freeMb = mi.availMem / (1024 * 1024)
                val macroOn = if (CyberXMacroService.isRunningMacro) "MAKRO: ON" else "MAKRO: OFF"
                val warn = if (temp >= 43f) " PANAS!" else ""
                val swTxt = if (stopwatchRunning) " | %02d:%02d".format(stopwatchSeconds / 60, stopwatchSeconds % 60) else ""
                tv.text = "CYBERX | ${temp}°C$warn | ${freeMb}MB | $macroOn$swTxt"
                tv.setTextColor(if (temp >= 43f) Color.parseColor("#FF1744") else Color.parseColor("#00E5FF"))

                val nowStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                val botTxt = if (prefs.gameSpaceBatterySaver) "BOT MATI" else "BOT 24H"
                bottomPillView?.text = "CYBERX   $nowStr   BAT ${lvl}%   ${temp}°C   $botTxt"
                delay(1000)
            }
        }
    }

    private fun removeWingViewsImmediate() {
        isMenuOpen = false
        wingRgbAnim?.cancel()
        wingRgbAnim = null
        removeViewSafe(leftWingView); leftWingView = null
        removeViewSafe(rightWingView); rightWingView = null
        removeViewSafe(bottomPillView); bottomPillView = null
    }

    private fun closeDualWingsAnimated() {
        isMenuOpen = false
        val lw = leftWingView
        val rw = rightWingView
        val bp = bottomPillView
        lw?.animate()?.translationX(-420f)?.alpha(0f)?.setDuration(220)?.start()
        rw?.animate()?.translationX(420f)?.alpha(0f)?.setDuration(220)?.withEndAction {
            removeWingViewsImmediate()
        }?.start()
        bp?.animate()?.alpha(0f)?.setDuration(180)?.start()
        if (rw == null) removeWingViewsImmediate()
    }

    private fun makeWingCardBtn(label: String, accentHex: String, onClick: (Button) -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 10f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = MechaChamferDrawable(
                fillColor = Color.parseColor("#D9111829"),
                strokeColorStart = Color.parseColor(accentHex),
                strokeColorEnd = Color.parseColor("#334155"),
                chamferPx = 12f,
                strokePx = 2f
            )
            setPadding(12, 10, 12, 10)
            minHeight = 0
            minimumHeight = 0
            setOnClickListener {
                animate().scaleX(0.94f).scaleY(0.94f).setDuration(70).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(100).start()
                }.start()
                onClick(this)
            }
        }
    }

    private fun openDualWings() {
        removeWingViewsImmediate()
        isMenuOpen = true
        val dm = resources.displayMetrics
        val isPortrait = resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
        val wingW = if (isPortrait) (dm.widthPixels * 0.45f).toInt() else (dm.widthPixels * 0.27f).toInt().coerceIn(300, 480)
        val wingH = if (isPortrait) (dm.heightPixels * 0.56f).toInt() else WindowManager.LayoutParams.MATCH_PARENT

        val lpBtn = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = 8
        }

        val leftDrawable = WingChevronDrawable(isLeftWing = true)
        val rightDrawable = WingChevronDrawable(isLeftWing = false)

        // === SAYAP KIRI: 7 FITUR GAMING PRO ===
        val leftContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = leftDrawable
            setPadding(16, 20, 36, 20)
        }
        val leftHeader = TextView(this).apply {
            text = "GAMING TOOLS"
            setTextColor(Color.parseColor("#FF4D6D"))
            textSize = 11f
            typeface = android.graphics.Typeface.MONOSPACE
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val leftScroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        val leftCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val btnMacro = makeWingCardBtn(if (CyberXMacroService.isRunningMacro) "STOP MAKRO" else "MAKRO GLOO WALL", "#10B981") { b ->
            val svc = CyberXMacroService.instance
            if (svc == null) {
                Toast.makeText(this, "Aktifkan Layanan Aksesibilitas CyberX Macro dulu!", Toast.LENGTH_LONG).show()
                return@makeWingCardBtn
            }
            if (CyberXMacroService.isRunningMacro) {
                svc.stopMacro()
                b.text = "MAKRO GLOO WALL"
            } else {
                if (isEditingHud) { isEditingHud = false; clearMarkers() }
                svc.startMacro(loadMacroPoints(), prefs.macroDelayMs)
                b.text = "STOP MAKRO"
            }
        }
        val btnEditHud = makeWingCardBtn(if (isEditingHud) "KUNCI TITIK HUD" else "ATUR TITIK HUD", "#00E5FF") { b ->
            isEditingHud = !isEditingHud
            if (isEditingHud) {
                CyberXMacroService.instance?.stopMacro()
                showDraggableMarkers()
                b.text = "KUNCI TITIK HUD"
                Toast.makeText(this, "Geser titik ke tombol Gloo Wall!", Toast.LENGTH_SHORT).show()
            } else {
                clearMarkers()
                b.text = "ATUR TITIK HUD"
                Toast.makeText(this, "Titik makro disimpan & dikunci!", Toast.LENGTH_SHORT).show()
            }
        }
        val btnDelay = makeWingCardBtn("JEDA MAKRO: ${prefs.macroDelayMs}ms", "#FF4D6D") { b ->
            val next = when (prefs.macroDelayMs) { 45 -> 70; 70 -> 100; 100 -> 140; else -> 45 }
            prefs.macroDelayMs = next
            b.text = "JEDA MAKRO: ${next}ms"
        }
        val btnCross = makeWingCardBtn("CROSSHAIR: ${prefs.crosshairStyle}", "#FF1744") { b ->
            val next = when (prefs.crosshairStyle) { "OFF" -> "DOT"; "DOT" -> "CROSS"; "CROSS" -> "CIRCLE"; else -> "OFF" }
            prefs.crosshairStyle = next
            crosshairView?.style = next
            crosshairView?.invalidate()
            b.text = "CROSSHAIR: $next"
        }
        val btnAux = makeWingCardBtn(if (showAuxLines) "GARIS BANTU: ON" else "GARIS BANTU: OFF", "#00E5FF") { b ->
            showAuxLines = !showAuxLines
            auxLineView?.visibility = if (showAuxLines) View.VISIBLE else View.GONE
            b.text = if (showAuxLines) "GARIS BANTU: ON" else "GARIS BANTU: OFF"
        }
        val btnStopwatch = makeWingCardBtn(if (stopwatchRunning) "STOPWATCH: ON" else "STOPWATCH: OFF", "#FDE047") { b ->
            stopwatchRunning = !stopwatchRunning
            if (!stopwatchRunning) stopwatchSeconds = 0
            b.text = if (stopwatchRunning) "STOPWATCH: ON" else "STOPWATCH: OFF"
        }
        val btnKeepOn = makeWingCardBtn(if (keepScreenOn) "LAYAR NYALA: ON" else "LAYAR NYALA: OFF", "#10B981") { b ->
            keepScreenOn = !keepScreenOn
            b.text = if (keepScreenOn) "LAYAR NYALA: ON" else "LAYAR NYALA: OFF"
            Toast.makeText(this, if (keepScreenOn) "Layar dijaga tetap menyala!" else "Mode layar normal", Toast.LENGTH_SHORT).show()
        }

        leftCol.addView(btnMacro, lpBtn)
        leftCol.addView(btnEditHud, lpBtn)
        leftCol.addView(btnDelay, lpBtn)
        leftCol.addView(btnCross, lpBtn)
        leftCol.addView(btnAux, lpBtn)
        leftCol.addView(btnStopwatch, lpBtn)
        leftCol.addView(btnKeepOn, lpBtn)
        leftScroll.addView(leftCol)
        leftContainer.addView(leftHeader)
        leftContainer.addView(leftScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val lpLeft = WindowManager.LayoutParams(
            wingW, wingH, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.START or Gravity.CENTER_VERTICAL }
        leftWingView = leftContainer
        leftContainer.translationX = -wingW.toFloat()
        leftContainer.alpha = 0f
        wm.addView(leftContainer, lpLeft)
        leftContainer.animate().translationX(0f).alpha(1f).setDuration(280).setInterpolator(DecelerateInterpolator()).start()

        // === SAYAP KANAN: 7 FITUR SISTEM, PERFORMA, BOOST RAM, DND, AUDIO ===
        val rightContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rightDrawable
            setPadding(36, 20, 16, 20)
        }
        val rightHeader = TextView(this).apply {
            text = "SYSTEM & PRO HUD"
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 11f
            gravity = Gravity.END
            typeface = android.graphics.Typeface.MONOSPACE
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val rightScroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        val rightCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val btnPerf = makeWingCardBtn("MODE: ${prefs.perfMode.uppercase()}", "#FF1744") { b ->
            val next = when (prefs.perfMode) { "eco" -> "balance"; "balance" -> "turbo"; else -> "eco" }
            prefs.perfMode = next
            b.text = "MODE: ${next.uppercase()}"
        }
        val btnBoostRam = makeWingCardBtn("BOOST RAM & CACHE", "#00E5FF") {
            System.gc()
            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            val freeMb = mi.availMem / (1024 * 1024)
            Toast.makeText(this, "RAM Dioptimalkan! Tersedia: ${freeMb} MB", Toast.LENGTH_SHORT).show()
        }
        val btnDnd = makeWingCardBtn("MODE FOKUS (DND)", "#FDE047") {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && nm.isNotificationPolicyAccessGranted) {
                val cur = nm.currentInterruptionFilter
                val target = if (cur == NotificationManager.INTERRUPTION_FILTER_PRIORITY) NotificationManager.INTERRUPTION_FILTER_ALL else NotificationManager.INTERRUPTION_FILTER_PRIORITY
                nm.setInterruptionFilter(target)
                Toast.makeText(this, if (target == NotificationManager.INTERRUPTION_FILTER_PRIORITY) "Mode Fokus DND ON!" else "Mode Fokus DND OFF", Toast.LENGTH_SHORT).show()
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
        val btnVolUp = makeWingCardBtn("VOLUME +", "#FFFFFF") {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
        }
        val btnVolDown = makeWingCardBtn("VOLUME -", "#FFFFFF") {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
        }
        val btnHome = makeWingCardBtn("LOBBY CYBERX", "#00E5FF") {
            closeDualWingsAnimated()
            val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            startActivity(i)
        }
        val btnClose = makeWingCardBtn("TUTUP MENU", "#FF1744") {
            closeDualWingsAnimated()
        }

        rightCol.addView(btnPerf, lpBtn)
        rightCol.addView(btnBoostRam, lpBtn)
        rightCol.addView(btnDnd, lpBtn)
        rightCol.addView(btnVolUp, lpBtn)
        rightCol.addView(btnVolDown, lpBtn)
        rightCol.addView(btnHome, lpBtn)
        rightCol.addView(btnClose, lpBtn)
        rightScroll.addView(rightCol)
        rightContainer.addView(rightHeader)
        rightContainer.addView(rightScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val lpRight = WindowManager.LayoutParams(
            wingW, wingH, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        rightWingView = rightContainer
        rightContainer.translationX = wingW.toFloat()
        rightContainer.alpha = 0f
        wm.addView(rightContainer, lpRight)
        rightContainer.animate().translationX(0f).alpha(1f).setDuration(280).setInterpolator(DecelerateInterpolator()).start()

        // === BOTTOM CENTER PILL ===
        val pill = TextView(this).apply {
            text = "CYBERX"
            setTextColor(Color.WHITE)
            textSize = 10f
            typeface = android.graphics.Typeface.MONOSPACE
            setBackgroundColor(Color.parseColor("#CC060810"))
            setPadding(22, 8, 22, 8)
        }
        val lpPill = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = 14
        }
        bottomPillView = pill
        pill.alpha = 0f
        wm.addView(pill, lpPill)
        pill.animate().alpha(1f).setDuration(250).start()

        // === LIVE ANIMATED RGB NEON CHEVRON BORDERS ===
        wingRgbAnim = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 2400L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { va ->
                val hue = va.animatedValue as Float
                val c1 = Color.HSVToColor(floatArrayOf(hue, 0.95f, 1f))
                val c2 = Color.HSVToColor(floatArrayOf((hue + 140f) % 360f, 0.95f, 1f))
                leftDrawable.updateRgb(c1, c2)
                rightDrawable.updateRgb(c2, c1)
            }
            start()
        }
    }

    class WingChevronDrawable(private val isLeftWing: Boolean) : android.graphics.drawable.Drawable() {
        private var colorTop = Color.parseColor("#FF1744")
        private var colorBot = Color.parseColor("#00E5FF")
        private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.parseColor("#E3070A14")
        }
        private val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 6f
        }
        fun updateRgb(c1: Int, c2: Int) {
            colorTop = c1
            colorBot = c2
            invalidateSelf()
        }
        override fun draw(canvas: Canvas) {
            val w = bounds.width().toFloat()
            val h = bounds.height().toFloat()
            if (w <= 0f || h <= 0f) return
            val peak = 32f
            val path = Path()
            if (isLeftWing) {
                path.moveTo(0f, 0f); path.lineTo(w - peak, 0f); path.lineTo(w, h / 2f); path.lineTo(w - peak, h); path.lineTo(0f, h); path.close()
                canvas.drawPath(path, fillPaint)
                edgePaint.shader = LinearGradient(0f, 0f, 0f, h, colorTop, colorBot, Shader.TileMode.CLAMP)
                val edge = Path().apply { moveTo(w - peak, 0f); lineTo(w, h / 2f); lineTo(w - peak, h) }
                canvas.drawPath(edge, edgePaint)
            } else {
                path.moveTo(w, 0f); path.lineTo(peak, 0f); path.lineTo(0f, h / 2f); path.lineTo(peak, h); path.lineTo(w, h); path.close()
                canvas.drawPath(path, fillPaint)
                edgePaint.shader = LinearGradient(0f, 0f, 0f, h, colorTop, colorBot, Shader.TileMode.CLAMP)
                val edge = Path().apply { moveTo(peak, 0f); lineTo(0f, h / 2f); lineTo(peak, h) }
                canvas.drawPath(edge, edgePaint)
            }
        }
        override fun setAlpha(alpha: Int) { fillPaint.alpha = alpha }
        override fun setColorFilter(cf: android.graphics.ColorFilter?) { fillPaint.colorFilter = cf }
        @Deprecated("Deprecated in Java")
        override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
    }

    class AuxLineOverlayView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(95, 0, 229, 255)
            strokeWidth = 2f
        }
        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            canvas.drawLine(0f, h / 2f, w, h / 2f, paint)
            canvas.drawLine(w / 2f, 0f, w / 2f, h, paint)
        }
    }

    private fun loadMacroPoints(): MutableList<MacroPoint> {
        val out = mutableListOf<MacroPoint>()
        try {
            val arr = JSONArray(prefs.macroPointsJson)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(MacroPoint(o.optString("label", "${i+1}"), o.optDouble("x", 600.0).toFloat(), o.optDouble("y", 400.0).toFloat()))
            }
        } catch (_: Exception) {}
        if (out.isEmpty()) {
            out.add(MacroPoint("1:Gloo", 350f, 520f))
            out.add(MacroPoint("2:Jongkok", 1180f, 540f))
            out.add(MacroPoint("3:Pasang", 1320f, 450f))
            saveMacroPoints(out)
        }
        return out
    }

    private fun saveMacroPoints(pts: List<MacroPoint>) {
        val arr = JSONArray()
        for (p in pts) {
            arr.put(JSONObject().put("label", p.label).put("x", p.x.toDouble()).put("y", p.y.toDouble()))
        }
        prefs.macroPointsJson = arr.toString()
    }

    private fun clearMarkers() {
        for (v in markerViews) removeViewSafe(v)
        markerViews.clear()
    }

    private fun showDraggableMarkers() {
        clearMarkers()
        val pts = loadMacroPoints()
        pts.forEachIndexed { idx, pt ->
            val tv = TextView(this).apply {
                text = pt.label
                setTextColor(Color.WHITE)
                textSize = 10f
                gravity = Gravity.CENTER
                setBackgroundColor(Color.parseColor("#CCFF1744"))
                setPadding(14, 14, 14, 14)
            }
            val mlp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = pt.x.toInt() - 40
                y = pt.y.toInt() - 40
            }
            var ix = 0; var iy = 0; var tx = 0f; var ty = 0f
            tv.setOnTouchListener { _, ev ->
                when (ev.action) {
                    MotionEvent.ACTION_DOWN -> { ix = mlp.x; iy = mlp.y; tx = ev.rawX; ty = ev.rawY; true }
                    MotionEvent.ACTION_MOVE -> {
                        mlp.x = ix + (ev.rawX - tx).toInt()
                        mlp.y = iy + (ev.rawY - ty).toInt()
                        try { wm.updateViewLayout(tv, mlp) } catch (_: Exception) {}
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        pts[idx].x = ev.rawX
                        pts[idx].y = ev.rawY
                        saveMacroPoints(pts)
                        true
                    }
                    else -> false
                }
            }
            markerViews.add(tv)
            wm.addView(tv, mlp)
        }
    }

    class CrosshairOverlayView(context: Context) : View(context) {
        var style: String = "DOT"
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FF1744")
            strokeWidth = 4f
            style = Paint.Style.STROKE
        }
        override fun onDraw(canvas: Canvas) {
            if (style == "OFF") return
            val cx = width / 2f
            val cy = height / 2f
            when (style) {
                "DOT" -> {
                    paint.style = Paint.Style.FILL
                    canvas.drawCircle(cx, cy, 8f, paint)
                }
                "CROSS" -> {
                    paint.style = Paint.Style.STROKE
                    canvas.drawLine(cx - 26f, cy, cx - 8f, cy, paint)
                    canvas.drawLine(cx + 8f, cy, cx + 26f, cy, paint)
                    canvas.drawLine(cx, cy - 26f, cx, cy - 8f, paint)
                    canvas.drawLine(cx, cy + 8f, cx, cy + 26f, paint)
                    paint.style = Paint.Style.FILL
                    canvas.drawCircle(cx, cy, 4f, paint)
                }
                "CIRCLE" -> {
                    paint.style = Paint.Style.STROKE
                    canvas.drawCircle(cx, cy, 24f, paint)
                    paint.style = Paint.Style.FILL
                    canvas.drawCircle(cx, cy, 4f, paint)
                }
            }
        }
    }
}
