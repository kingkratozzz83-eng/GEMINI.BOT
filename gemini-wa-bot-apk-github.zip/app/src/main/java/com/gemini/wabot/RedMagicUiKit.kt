package com.gemini.wabot

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Shader
import android.graphics.drawable.Drawable

class MechaChamferDrawable(
    private val fillColor: Int = Color.parseColor("#C80B0F19"),
    private var strokeColorStart: Int = Color.parseColor("#FF1744"),
    private var strokeColorEnd: Int = Color.parseColor("#00E5FF"),
    private val chamferPx: Float = 26f,
    private val strokePx: Float = 3.5f
) : Drawable() {

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = fillColor
    }

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = strokePx
    }

    private val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    fun updateNeonColors(startColor: Int, endColor: Int) {
        strokeColorStart = startColor
        strokeColorEnd = endColor
        invalidateSelf()
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        if (w <= 0f || h <= 0f) return

        val c = chamferPx.coerceAtMost(minOf(w, h) / 4f)
        val inset = strokePx / 2f

        val path = Path().apply {
            moveTo(inset + c, inset)
            lineTo(w - inset, inset)
            lineTo(w - inset, h - inset - c)
            lineTo(w - inset - c, h - inset)
            lineTo(inset, h - inset)
            lineTo(inset, inset + c)
            close()
        }

        canvas.drawPath(path, fillPaint)

        strokePaint.shader = LinearGradient(
            0f, 0f, w, h,
            strokeColorStart, strokeColorEnd,
            Shader.TileMode.CLAMP
        )
        canvas.drawPath(path, strokePaint)

        // Mecha corner accent notches (RedMagic signature HUD detail)
        accentPaint.color = strokeColorStart
        canvas.drawRect(inset + c + 8f, inset + 4f, inset + c + 36f, inset + 8f, accentPaint)
        accentPaint.color = strokeColorEnd
        canvas.drawRect(w - inset - c - 36f, h - inset - 8f, w - inset - c - 8f, h - inset - 4f, accentPaint)
    }

    override fun setAlpha(alpha: Int) {
        fillPaint.alpha = alpha
        strokePaint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        fillPaint.colorFilter = colorFilter
        strokePaint.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
