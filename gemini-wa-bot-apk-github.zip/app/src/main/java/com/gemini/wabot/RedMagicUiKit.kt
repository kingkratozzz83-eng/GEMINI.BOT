package com.gemini.wabot

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Shader
import android.graphics.drawable.Drawable

class MechaChamferDrawable(
    private val fillColor: Int = Color.parseColor("#C80B0F19"),
    private var strokeColorStart: Int = Color.parseColor("#FF1744"),
    private var strokeColorEnd: Int = Color.parseColor("#00E5FF"),
    private val chamferPx: Float = 26f,
    private val strokePx: Float = 3.5f
) : Drawable() {

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = fillColor
    }

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = strokePx
    }

    private val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    fun updateNeonColors(startColor: Int, endColor: Int) {
        strokeColorStart = startColor
        strokeColorEnd = endColor
        invalidateSelf()
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        if (w <= 0f || h <= 0f) return

        val c = chamferPx.coerceAtMost(minOf(w, h) / 4f)
        val inset = strokePx / 2f

        val path = Path().apply {
            moveTo(inset + c, inset)
            lineTo(w - inset, inset)
            lineTo(w - inset, h - inset - c)
            lineTo(w - inset - c, h - inset)
            lineTo(inset, h - inset)
            lineTo(inset, inset + c)
            close()
        }

        canvas.drawPath(path, fillPaint)

        strokePaint.shader = LinearGradient(
            0f, 0f, w, h,
            strokeColorStart, strokeColorEnd,
            Shader.TileMode.CLAMP
        )
        canvas.drawPath(path, strokePaint)

        // Mecha corner accent notches (RedMagic signature HUD detail)
        accentPaint.color = strokeColorStart
        canvas.drawRect(inset + c + 8f, inset + 4f, inset + c + 36f, inset + 8f, accentPaint)
        accentPaint.color = strokeColorEnd
        canvas.drawRect(w - inset - c - 36f, h - inset - 8f, w - inset - c - 8f, h - inset - 4f, accentPaint)
    }

    override fun setAlpha(alpha: Int) {
        fillPaint.alpha = alpha
        strokePaint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        fillPaint.colorFilter = colorFilter
        strokePaint.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

class RedMagicPortalView @JvmOverloads constructor(
    context: android.content.Context,
    attrs: android.util.AttributeSet? = null
) : android.view.View(context, attrs) {

    private data class WarpStar(var angle: Float, var dist: Float, var speed: Float, var len: Float, var isCyan: Boolean)
    private data class Spark(var x: Float, var y: Float, var vx: Float, var vy: Float, var alpha: Float, var size: Float)

    private val stars = ArrayList<WarpStar>(95)
    private val sparks = ArrayList<Spark>(40)
    private val rnd = java.util.Random()
    private var rotOuter = 0f
    private var rotInner = 0f
    private var warpBoost = 1f
    private var flashAlpha = 0f
    private var pulsePhase = 0f
    private var animator: android.animation.ValueAnimator? = null

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val streakPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }
    private val sparkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val flashPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val rectF = android.graphics.RectF()

    init {
        for (i in 0 until 95) {
            stars.add(
                WarpStar(
                    angle = rnd.nextFloat() * 360f,
                    dist = 0.08f + rnd.nextFloat() * 0.95f,
                    speed = 0.012f + rnd.nextFloat() * 0.025f,
                    len = 16f + rnd.nextFloat() * 52f,
                    isCyan = (i % 5 == 0)
                )
            )
        }
        for (i in 0 until 40) {
            sparks.add(
                Spark(
                    x = rnd.nextFloat(),
                    y = rnd.nextFloat(),
                    vx = (rnd.nextFloat() - 0.5f) * 0.004f,
                    vy = -0.004f - rnd.nextFloat() * 0.008f,
                    alpha = 0.25f + rnd.nextFloat() * 0.75f,
                    size = 2.5f + rnd.nextFloat() * 4.5f
                )
            )
        }
    }

    fun startPortal() {
        warpBoost = 1f
        flashAlpha = 0f
        animator?.cancel()
        animator = android.animation.ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1000L
            repeatCount = android.animation.ValueAnimator.INFINITE
            interpolator = android.view.animation.LinearInterpolator()
            addUpdateListener {
                rotOuter = (rotOuter + 1.6f * warpBoost) % 360f
                rotInner = (rotInner - 2.8f * warpBoost) % 360f
                pulsePhase = (pulsePhase + 0.08f) % 6.283f
                for (s in stars) {
                    s.dist += s.speed * warpBoost
                    if (s.dist > 1.25f) {
                        s.dist = 0.05f + rnd.nextFloat() * 0.12f
                        s.angle = rnd.nextFloat() * 360f
                    }
                }
                for (sp in sparks) {
                    sp.x += sp.vx * warpBoost
                    sp.y += sp.vy * warpBoost
                    if (sp.y < -0.05f) {
                        sp.y = 1.05f
                        sp.x = rnd.nextFloat()
                    }
                }
                invalidate()
            }
            start()
        }
    }

    fun triggerWarpExplosion() {
        android.animation.ValueAnimator.ofFloat(1f, 6.5f).apply {
            duration = 480L
            addUpdateListener { va ->
                warpBoost = va.animatedValue as Float
                flashAlpha = ((warpBoost - 1f) / 5.5f).coerceIn(0f, 0.75f)
            }
            start()
        }
    }

    fun stopPortal() {
        animator?.cancel()
        animator = null
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val cx = w / 2f
        val cy = h / 2f
        val maxR = kotlin.math.hypot(cx.toDouble(), cy.toDouble()).toFloat()

        // Deep obsidian-crimson core radial glow
        val corePulse = 0.22f + 0.06f * kotlin.math.sin(pulsePhase.toDouble()).toFloat()
        bgPaint.shader = android.graphics.RadialGradient(
            cx, cy, maxR * 0.85f,
            intArrayOf(Color.argb((corePulse * 255).toInt(), 255, 23, 68), Color.parseColor("#FF05060C"), Color.parseColor("#FF020205")),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, bgPaint)

        // Hyperspace warp streaks
        for (s in stars) {
            val rad = Math.toRadians(s.angle.toDouble())
            val cosA = kotlin.math.cos(rad).toFloat()
            val sinA = kotlin.math.sin(rad).toFloat()
            val r1 = s.dist * maxR
            val r2 = r1 + s.len * warpBoost * (0.4f + s.dist)
            streakPaint.strokeWidth = (1.5f + s.dist * 2.5f).coerceAtMost(5f)
            val al = (s.dist * 230f).toInt().coerceIn(30, 240)
            streakPaint.color = if (s.isCyan) Color.argb(al, 0, 229, 255) else Color.argb(al, 255, 23, 68)
            canvas.drawLine(cx + cosA * r1, cy + sinA * r1, cx + cosA * r2, cy + sinA * r2, streakPaint)
        }

        // Rotating Cyber Mecha HUD Rings
        val baseR = minOf(w, h) * 0.34f
        ringPaint.strokeWidth = 5f
        ringPaint.color = Color.argb(180, 255, 23, 68)
        rectF.set(cx - baseR, cy - baseR, cx + baseR, cy + baseR)
        for (i in 0 until 4) {
            canvas.drawArc(rectF, rotOuter + i * 90f, 58f, false, ringPaint)
        }

        val midR = baseR * 0.82f
        ringPaint.strokeWidth = 3f
        ringPaint.color = Color.argb(190, 0, 229, 255)
        rectF.set(cx - midR, cy - midR, cx + midR, cy + midR)
        for (i in 0 until 6) {
            canvas.drawArc(rectF, rotInner + i * 60f, 32f, false, ringPaint)
        }

        val innerR = baseR * (0.64f + 0.03f * kotlin.math.sin(pulsePhase.toDouble()).toFloat())
        ringPaint.strokeWidth = 2.5f
        ringPaint.color = Color.argb(210, 255, 77, 109)
        canvas.drawCircle(cx, cy, innerR, ringPaint)

        // Dragon ember sparks
        for (sp in sparks) {
            sparkPaint.color = Color.argb((sp.alpha * 220).toInt(), 255, 77, 109)
            canvas.drawCircle(sp.x * w, sp.y * h, sp.size, sparkPaint)
        }

        if (flashAlpha > 0.01f) {
            flashPaint.color = Color.argb((flashAlpha * 255).toInt(), 255, 45, 85)
            canvas.drawRect(0f, 0f, w, h, flashPaint)
        }
    }
}

class CyberXWarpView @JvmOverloads constructor(
    context: android.content.Context,
    attrs: android.util.AttributeSet? = null
) : android.view.View(context, attrs) {

    private var progress = 0f
    private var anim: android.animation.ValueAnimator? = null
    private val streakPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val flashPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD)
    }
    private val emblemPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF1744")
        style = Paint.Style.FILL
    }
    private val debris = List(36) { i ->
        val rnd = java.util.Random(i * 1337L)
        floatArrayOf(rnd.nextFloat() * 360f, 0.3f + rnd.nextFloat() * 0.9f, 4f + rnd.nextFloat() * 8f)
    }

    fun playIntro(onComplete: () -> Unit) {
        progress = 0f
        anim?.cancel()
        anim = android.animation.ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1650L
            interpolator = android.view.animation.LinearInterpolator()
            addUpdateListener { va ->
                progress = va.animatedValue as Float
                invalidate()
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    onComplete()
                }
            })
            start()
        }
    }

    fun stopIntro() {
        anim?.cancel()
        anim = null
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val cx = w / 2f
        val cy = h / 2f
        canvas.drawColor(Color.parseColor("#FF030306"))

        if (progress < 0.48f) {
            val t = progress / 0.48f
            val xSpan = (1f - t * 0.65f) * w * 0.55f
            val ySpan = (1f - t * 0.65f) * h * 0.55f
            val colors = intArrayOf(Color.parseColor("#FF1744"), Color.parseColor("#00E5FF"), Color.parseColor("#FF4D6D"), Color.WHITE)
            for (i in 0 until 4) {
                streakPaint.color = colors[i]
                streakPaint.strokeWidth = 6f + t * 8f
                val sx = if (i % 2 == 0) cx - xSpan else cx + xSpan
                val sy = if (i < 2) cy - ySpan else cy + ySpan
                canvas.drawLine(sx, sy, cx, cy, streakPaint)
            }
            flashPaint.shader = android.graphics.RadialGradient(
                cx, cy, 40f + t * 140f,
                intArrayOf(Color.WHITE, Color.argb(120, 255, 23, 68), Color.TRANSPARENT),
                null, Shader.TileMode.CLAMP
            )
            canvas.drawCircle(cx, cy, 40f + t * 140f, flashPaint)
            flashPaint.shader = null
        } else if (progress < 0.72f) {
            val t = (progress - 0.48f) / 0.24f
            val r = (1f - t * 0.2f) * maxOf(w, h) * 0.6f
            val al = ((1f - t) * 235f).toInt().coerceIn(0, 235)
            flashPaint.color = Color.argb(al, 235, 240, 255)
            canvas.drawCircle(cx, cy, r, flashPaint)
            for (d in debris) {
                val rad = Math.toRadians(d[0].toDouble())
                val dist = t * d[1] * maxOf(w, h) * 0.55f
                val dx = cx + kotlin.math.cos(rad).toFloat() * dist
                val dy = cy + kotlin.math.sin(rad).toFloat() * dist
                flashPaint.color = Color.argb(al, 20, 24, 38)
                canvas.drawRect(dx, dy, dx + d[2], dy + d[2], flashPaint)
            }
        } else {
            val t = ((progress - 0.72f) / 0.28f).coerceIn(0f, 1f)
            val al = (kotlin.math.min(1f, t * 2.2f) * 255f).toInt()
            emblemPaint.alpha = al
            val s = 44f
            val path = Path().apply {
                moveTo(cx, cy - s * 1.1f)
                lineTo(cx + s * 0.85f, cy - s * 0.2f)
                lineTo(cx + s * 0.35f, cy + s * 0.55f)
                lineTo(cx, cy + s * 0.1f)
                lineTo(cx - s * 0.35f, cy + s * 0.55f)
                lineTo(cx - s * 0.85f, cy - s * 0.2f)
                close()
            }
            canvas.drawPath(path, emblemPaint)
            textPaint.alpha = al
            textPaint.textSize = 36f
            textPaint.letterSpacing = 0.38f
            canvas.drawText("CYBERX", cx, cy + s * 1.45f, textPaint)
        }
    }
}
