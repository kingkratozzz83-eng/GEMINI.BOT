plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val runNum = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 42
val computedVersionCode = 710 + runNum

android {
    namespace = "com.gemini.wabot"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.gemini.wabot"
        minSdk = 24
        targetSdk = 34
        versionCode = computedVersionCode
        versionName = "7.1.$runNum"
        ndk {
            abiFilters += listOf("arm64-v8a", "x86_64")
        }
    }

    signingConfigs {
        create("releaseSign") {
            val ksFile = file("bot-release-key.jks")
            if (ksFile.exists()) {
                storeFile = ksFile
                storePassword = "geminiwabot123"
                keyAlias = "geminiwabot"
                keyPassword = "geminiwabot123"
            }
        }
    }

    buildTypes {
        getByName("debug") {
            val ksFile = file("bot-release-key.jks")
            if (ksFile.exists()) {
                signingConfig = signingConfigs.getByName("releaseSign")
            }
        }
        getByName("release") {
            isMinifyEnabled = false
            val ksFile = file("bot-release-key.jks")
            if (ksFile.exists()) {
                signingConfig = signingConfigs.getByName("releaseSign")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
